<?php
require_once __DIR__ . '/includes/site.php';

$d = site_data();
$counts = site_counts();
$range = site_class_range();
$stages = db_get_all("SELECT DISTINCT c.stage FROM student_academic_history h JOIN classes c ON c.id = h.class_id
    JOIN academic_sessions s ON s.id = h.session_id AND s.status = 'Active'");
$labels = ['primary' => 'Primary', 'upper_primary' => 'Upper Primary', 'secondary' => 'Secondary', 'higher_secondary' => 'Higher Secondary'];
$offered = array_values(array_filter(array_map(fn($r) => $labels[$r['stage']] ?? '', $stages)));
usort($offered, fn($a, $b) => array_search($a, $labels) <=> array_search($b, $labels));

site_page('About the school', 'about.php');
site_band('About the school', $d['since'] ? 'Teaching since ' . $d['since'] . '.' : '');
?>
<section class="sec">
    <div class="wrap split">
        <div class="reveal">
            <span class="kick">Who we are</span>
            <h2><?php echo h($d['name']); ?></h2>
            <?php if ($d['motto'] !== ''): ?><p style="font-family:var(--serif);font-style:italic;font-size:19px;color:var(--brand)"><?php echo h($d['motto']); ?></p><?php endif; ?>
            <?php if ($d['about'] !== ''): ?>
                <div class="prose"><p><?php echo h($d['about']); ?></p></div>
            <?php else: ?>
                <p style="color:var(--muted)">The school's own story will be written here soon.</p>
            <?php endif; ?>
        </div>
        <div class="reveal">
            <?php if ($d['about_img'] !== ''): ?><img src="<?php echo h($d['about_img']); ?>" alt="<?php echo h($d['name']); ?>" style="margin-bottom:16px"><?php endif; ?>
            <div class="facts">
                <?php if ($d['since']): ?><div class="fact"><span>Established</span><b><?php echo (int)$d['since']; ?></b></div><?php endif; ?>
                <?php if ($range !== ''): ?><div class="fact"><span>Classes</span><b><?php echo h($range); ?></b></div><?php endif; ?>
                <?php if ($offered): ?><div class="fact"><span>Sections</span><b><?php echo h(implode(' · ', $offered)); ?></b></div><?php endif; ?>
                <div class="fact"><span>Students</span><b><?php echo number_format($counts['students']); ?></b></div>
                <div class="fact"><span>Teachers</span><b><?php echo number_format($counts['teachers']); ?></b></div>
                <?php if ($d['udise'] !== ''): ?><div class="fact"><span>UDISE code</span><b><?php echo h($d['udise']); ?></b></div><?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php if ($d['message'] !== ''): ?>
<section class="sec tint">
    <div class="wrap message reveal">
        <div class="photo"><?php echo $d['hoi_photo'] !== '' ? '<img src="' . h($d['hoi_photo']) . '" alt="' . h($d['hoi']) . '" loading="lazy">' : site_avatar($d['hoi'] ?: 'Head', '', ' big'); ?></div>
        <div>
            <span class="kick">From the head of the institution</span>
            <blockquote><?php echo nl2br(h($d['message'])); ?></blockquote>
            <?php if ($d['hoi'] !== ''): ?><div class="who"><b><?php echo h($d['hoi']); ?></b><span>Head of the Institution</span></div><?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="sec<?php echo $d['message'] !== '' ? '' : ' tint'; ?>">
    <div class="wrap">
        <div class="head center reveal"><span class="kick">Find us</span><h2>Where the school is</h2>
            <?php if ($d['address'] !== ''): ?><p><?php echo h($d['address']); ?></p><?php endif; ?></div>
        <div style="text-align:center" class="reveal">
            <a href="contact.php" class="btn btn-brand"><i class="fas fa-location-dot"></i> Address, phone and a message to the office</a>
        </div>
    </div>
</section>
<?php site_footer();

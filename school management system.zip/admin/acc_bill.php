<?php
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/acc_helper.php';

/** The bill kept with an entry, shown only to a logged-in admin; the folder itself is never served. */
$id = (int)($_GET['id'] ?? 0);
$file = (string)(db_get_row('SELECT attachment FROM acc_entries WHERE id = ?', 'i', $id)['attachment'] ?? '');
$types = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'pdf' => 'application/pdf'];
if (!preg_match('/^bill_[0-9a-f]{24}\.(jpg|jpeg|png|webp|pdf)$/', $file, $m) || !is_file($path = acc_bills_dir() . $file)) { http_response_code(404); exit('Bill not found.'); }
header('Content-Type: ' . $types[$m[1]]);
header('Content-Disposition: inline; filename="bill-' . $id . '.' . $m[1] . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);

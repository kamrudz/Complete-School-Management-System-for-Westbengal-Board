<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/acc_helper.php';
require_once '../includes/simple_xlsx_writer.php';

/** Cash Book: day by day, cash and bank in two columns each, with every day's opening and closing — one account or all. */
$periods = acc_periods();
$period = (string)($_GET['period'] ?? '');
$from = (string)($_GET['from'] ?? ''); $to = (string)($_GET['to'] ?? '');
if (isset($periods[$period])) [, $from, $to] = $periods[$period];
if (!fee_valid_date($from)) $from = date('Y-m-01');
if (!fee_valid_date($to)) $to = date('Y-m-d');
if ($from > $to) [$from, $to] = [$to, $from];
$accounts = acc_accounts();
$account = (int)($_GET['account_id'] ?? 0); if (!isset($accounts[$account])) $account = 0;
$ids = $account ? [$account] : array_keys($accounts);
$q = array_filter(['period' => isset($periods[$period]) ? $period : null, 'from' => isset($periods[$period]) ? null : $from, 'to' => isset($periods[$period]) ? null : $to, 'account_id' => $account ?: null]);
$sum = function (array $bal) use ($ids) { $c = $b = 0; foreach ($ids as $id) { $c += $bal[$id]['cash'] ?? 0; $b += $bal[$id]['bank'] ?? 0; } return ['cash' => $c, 'bank' => $b]; };
$open = $sum(acc_balances($from, true));
$close = $sum(acc_balances($to));
$lines = acc_book_lines($from, $to, $ids);
$tot = ['cash_in' => 0, 'cash_out' => 0, 'bank_in' => 0, 'bank_out' => 0];
foreach ($lines as $l) foreach ($tot as $k => $v) $tot[$k] += $l[$k];
$title = $account ? $accounts[$account]['name'] : 'All accounts';
$range = date('d M Y', strtotime($from)) . ($from !== $to ? ' to ' . date('d M Y', strtotime($to)) : '');
$rp = fn(int $p) => round($p / 100, 2);

if (!empty($_GET['export'])) {
    $rows = exam_xlsx_title("Cash Book — $title", $range);
    $rows[] = ['Date', 'Voucher', 'Account', 'Particulars', 'Cash in', 'Cash out', 'Bank in', 'Bank out', 'Cash balance', 'Bank balance'];
    $rows[] = [date('d-m-Y', strtotime($from)), '', '', 'Opening balance', '', '', '', '', $rp($open['cash']), $rp($open['bank'])];
    $c = $open['cash']; $b = $open['bank'];
    foreach ($lines as $l) {
        $c += $l['cash_in'] - $l['cash_out']; $b += $l['bank_in'] - $l['bank_out'];
        $rows[] = [date('d-m-Y', strtotime($l['date'])), $l['voucher'], $l['account'], $l['text'] . ($l['sub'] !== '' ? ' — ' . $l['sub'] : ''),
            $l['cash_in'] ? $rp($l['cash_in']) : '', $l['cash_out'] ? $rp($l['cash_out']) : '', $l['bank_in'] ? $rp($l['bank_in']) : '', $l['bank_out'] ? $rp($l['bank_out']) : '', $rp($c), $rp($b)];
    }
    $rows[] = ['', '', '', 'Total', $rp($tot['cash_in']), $rp($tot['cash_out']), $rp($tot['bank_in']), $rp($tot['bank_out']), $rp($close['cash']), $rp($close['bank'])];
    SimpleXLSXWriter::download('Cash_Book_' . $from . '_to_' . $to . '.xlsx', $rows, 'Cash Book', exam_xlsx_opts(10, 34));
    exit();
}
$days = [];
foreach ($lines as $l) $days[$l['date']][] = $l;
$money = fn(int $p) => $p ? h(fee_num_p($p)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cash Book — <?php echo h($title); ?></title>
<?php exam_styles('acc'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 18px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .cb { font-size: 12.5px; }
    .cb th.money, .cb td.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; width: 9%; }
    .cb th.grp { text-align: center; border-bottom: 1px solid var(--ex-border); }
    .cb td small { display: block; color: #6b7d90; font-size: 11px; }
    .cb tr.day td { background: var(--ex-group); color: var(--ex-dark); font-weight: 700; }
    .cb tr.close td { background: #f7f9fc; color: #3b5168; font-weight: 600; font-size: 12px; }
    .cb tfoot td { font-weight: 800; background: var(--ex-soft); }
    .cb .in { color: #1b7a3a; } .cb .out { color: #b71c1c; }
    .cb .vno { white-space: nowrap; font-weight: 700; }
    .print-head { display: none; }
    @media print {
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .noprint, .sum { display: none !important; }
        .print-head { display: block; }
        .cb td, .cb th { white-space: normal !important; padding: 2px 4px !important; font-size: 10.5px !important; }
        .cb td.money, .cb th.money { white-space: nowrap !important; }
        .auto-table-scroll { overflow: visible !important; margin-top: 0 !important; }
        .card { border: 0; padding: 0; }
        .cb a { color: inherit; text-decoration: none; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Cash Book', 'Day by day: what came in and went out, in cash and through the bank, and what was left', 'fa-book',
        ['acc_cashbook.php?' . http_build_query($q + ['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php acc_tabs('acc_cashbook.php'); ?>

    <form method="get" class="card pick noprint">
        <div><label>Period</label><select name="period" onchange="this.form.submit()"><option value="">Dates below</option><?php foreach ($periods as $k => [$label]): ?><option value="<?php echo h($k); ?>"<?php echo $k === $period ? ' selected' : ''; ?>><?php echo h($label); ?></option><?php endforeach; ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div>
        <div><label>Account</label><select name="account_id"><option value="0">All accounts</option><?php foreach ($accounts as $id => $a): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $account ? ' selected' : ''; ?>><?php echo h($a['name']); ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('CASH BOOK — ' . mb_strtoupper($title), $range); ?></div>

    <?php if (!$accounts): ?>
    <?php exam_guard('No account yet', 'Add the school\'s accounts first.', 'acc_settings.php', 'Account Settings'); ?>
    <?php else: ?>
    <div class="sum">
        <div><b><?php echo h(fee_money_p($open['cash'])); ?> · <?php echo h(fee_money_p($open['bank'])); ?></b><small>cash · bank when <?php echo h(date('d M Y', strtotime($from))); ?> began</small></div>
        <div><b class="in"><?php echo h(fee_money_p($tot['cash_in'])); ?> · <?php echo h(fee_money_p($tot['bank_in'])); ?></b><small>came in, cash · bank</small></div>
        <div><b class="out"><?php echo h(fee_money_p($tot['cash_out'])); ?> · <?php echo h(fee_money_p($tot['bank_out'])); ?></b><small>went out, cash · bank</small></div>
        <div><b><?php echo h(fee_money_p($close['cash'])); ?> · <?php echo h(fee_money_p($close['bank'])); ?></b><small>cash · bank at the end of <?php echo h(date('d M Y', strtotime($to))); ?></small></div>
    </div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table cb">
            <thead>
                <tr><th rowspan="2">Voucher</th><?php if (!$account): ?><th rowspan="2">Account</th><?php endif; ?><th rowspan="2">Particulars</th><th colspan="2" class="grp">Cash (₹)</th><th colspan="2" class="grp">Bank (₹)</th></tr>
                <tr><th class="money">In</th><th class="money">Out</th><th class="money">In</th><th class="money">Out</th></tr>
            </thead>
            <tbody>
            <?php $cols = $account ? 2 : 3; $c = $open['cash']; $b = $open['bank'];
            if (!$days): ?>
                <tr><td colspan="<?php echo $cols + 4; ?>" style="text-align:center;color:#7a8a9a;padding:18px">Nothing came in or went out in <?php echo h($range); ?>.</td></tr>
            <?php endif;
            foreach ($days as $day => $list): ?>
                <tr class="day"><td colspan="<?php echo $cols; ?>"><?php echo h(date('l, d M Y', strtotime($day))); ?></td><td class="money" colspan="2">opening <?php echo h(fee_num_p($c)); ?></td><td class="money" colspan="2">opening <?php echo h(fee_num_p($b)); ?></td></tr>
                <?php foreach ($list as $l): $c += $l['cash_in'] - $l['cash_out']; $b += $l['bank_in'] - $l['bank_out']; ?>
                <tr>
                    <td class="vno"><?php echo h($l['voucher']); ?></td>
                    <?php if (!$account): ?><td><?php echo h($l['account']); ?></td><?php endif; ?>
                    <td><?php echo h($l['text']); ?><?php echo $l['sub'] !== '' ? '<small>' . h($l['sub']) . '</small>' : ''; ?></td>
                    <td class="money in"><?php echo $money($l['cash_in']); ?></td><td class="money out"><?php echo $money($l['cash_out']); ?></td>
                    <td class="money in"><?php echo $money($l['bank_in']); ?></td><td class="money out"><?php echo $money($l['bank_out']); ?></td>
                </tr>
                <?php endforeach; ?>
                <tr class="close"><td colspan="<?php echo $cols; ?>" style="text-align:right">Closing</td><td class="money" colspan="2"><?php echo h(fee_num_p($c)); ?></td><td class="money" colspan="2"><?php echo h(fee_num_p($b)); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="<?php echo $cols; ?>">Total · <?php echo h($range); ?></td><td class="money"><?php echo h(fee_num_p($tot['cash_in'])); ?></td><td class="money"><?php echo h(fee_num_p($tot['cash_out'])); ?></td><td class="money"><?php echo h(fee_num_p($tot['bank_in'])); ?></td><td class="money"><?php echo h(fee_num_p($tot['bank_out'])); ?></td></tr>
                <tr><td colspan="<?php echo $cols; ?>">Closing balance</td><td class="money" colspan="2"><?php echo h(fee_money_p($close['cash'])); ?></td><td class="money" colspan="2"><?php echo h(fee_money_p($close['bank'])); ?></td></tr>
            </tfoot>
        </table>
    </div>
    <p class="note noprint">A day's fees are shown per fee head as one line, with the receipt numbers they cover; a deposit, withdrawal or transfer shows both sides on one line.</p>
    <?php endif; ?>
</div>
</body>
</html>

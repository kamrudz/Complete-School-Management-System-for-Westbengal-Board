<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/acc_helper.php';

/** New Entry: an expense, an income, cash to the bank or back, or money from one account to another — each with its voucher number. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$forms = ['expense' => ['Expense', 'fa-arrow-up', 'Money paid out — with the bill'], 'income' => ['Income', 'fa-arrow-down', 'Money received other than fees'],
          'contra' => ['Deposit / Withdraw', 'fa-exchange-alt', 'Cash into the bank, or the bank into cash'], 'transfer' => ['Transfer', 'fa-random', 'From one account to another']];
$form = (string)($_GET['kind'] ?? $_POST['form'] ?? 'expense');
if (!isset($forms[$form])) $form = 'expense';
$self = fn(array $q = []) => 'acc_entry.php?' . http_build_query(['kind' => $form] + $q);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $file = '';
    try {
        $token = (string)($_POST['token'] ?? '');
        if ($token === '' || !isset($_SESSION['acc_entry_tokens'][$token])) throw new RuntimeException('This entry was saved already, or the page is old — nothing was saved twice.');
        unset($_SESSION['acc_entry_tokens'][$token]);
        $amount = acc_amount_in($_POST['amount'] ?? '');
        if (!$amount) throw new RuntimeException('Give the amount in rupees, like 2500 or 2500.50.');
        if (!empty($_FILES['bill']['name'])) {
            $up = acc_bill_store($_FILES['bill']);
            if (!$up['ok']) throw new RuntimeException('Bill: ' . $up['error'] . ' A photo (JPG, PNG) or a PDF of up to 3 MB.');
            $file = (string)$up['filename'];
        }
        $kind = $form === 'contra' ? ((string)($_POST['move'] ?? '') === 'withdraw' ? 'withdraw' : 'deposit') : $form;
        [$id, $no] = acc_entry_create(['kind' => $kind, 'account_id' => (int)($_POST['account_id'] ?? 0), 'to_account_id' => (int)($_POST['to_account_id'] ?? 0), 'date' => (string)($_POST['date'] ?? ''),
            'amount' => $amount, 'head_id' => (int)($_POST['head_id'] ?? 0), 'way' => (string)($_POST['way'] ?? ''), 'from_mode' => (string)($_POST['from_mode'] ?? ''), 'to_mode' => (string)($_POST['to_mode'] ?? ''),
            'reference' => (string)($_POST['reference'] ?? ''), 'party' => (string)($_POST['party'] ?? ''), 'bill_no' => (string)($_POST['bill_no'] ?? ''), 'bill_date' => (string)($_POST['bill_date'] ?? ''),
            'description' => (string)($_POST['description'] ?? ''), 'attachment' => $file !== '' ? $file : null], $admin_id);
        $_SESSION['acc_last_entry'] = $id;
        header('Location: ' . $self(['done' => 1]));
    } catch (RuntimeException $e) {
        if ($file !== '') @unlink(acc_bills_dir() . $file);
        $_SESSION['error'] = $e->getMessage();
        $_SESSION['acc_entry_form'] = array_intersect_key($_POST, array_flip(['account_id', 'to_account_id', 'date', 'amount', 'head_id', 'way', 'move', 'from_mode', 'to_mode', 'reference', 'party', 'bill_no', 'bill_date', 'description']));
        header('Location: ' . $self());
    }
    exit();
}

$accounts = acc_accounts(true);
$heads = $form === 'expense' || $form === 'income' ? acc_heads($form, null, true) : [];
$now = acc_balances();
$old = $_SESSION['acc_entry_form'] ?? [];
unset($_SESSION['acc_entry_form']);
$v = fn(string $k, string $d = '') => (string)($old[$k] ?? $d);
$last = null;
if (!empty($_GET['done']) && !empty($_SESSION['acc_last_entry'])) $last = db_get_row('SELECT e.*, a.name AS account_name FROM acc_entries e JOIN acc_accounts a ON a.id = e.account_id WHERE e.id = ?', 'i', (int)$_SESSION['acc_last_entry']);
$token = bin2hex(random_bytes(16));
$_SESSION['acc_entry_tokens'][$token] = time();
$_SESSION['acc_entry_tokens'] = array_slice($_SESSION['acc_entry_tokens'], -20, null, true);
$acc_options = function (string $selected) use ($accounts, $now) {
    $s = '<option value="">Choose…</option>';
    foreach ($accounts as $id => $a) $s .= '<option value="' . $id . '" data-type="' . h($a['type']) . '" data-cash="' . $now[$id]['cash'] . '" data-bank="' . $now[$id]['bank'] . '"' . ((string)$id === $selected ? ' selected' : '') . '>' . h($a['name']) . '</option>';
    return $s;
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Entry</title>
<?php exam_styles('acc'); ?>
<style>
    .kinds { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .kinds a { display: flex; gap: 10px; align-items: center; padding: 12px 14px; border-radius: 12px; border: 1px solid var(--ex-border); background: #fff; color: var(--ex-dark); text-decoration: none; }
    .kinds a i { width: 34px; height: 34px; border-radius: 10px; background: var(--ex-soft); display: flex; align-items: center; justify-content: center; }
    .kinds a b { display: block; font-size: 14px; } .kinds a small { color: #6b7d90; font-size: 11.5px; }
    .kinds a.on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); } .kinds a.on i { background: rgba(255,255,255,.18); } .kinds a.on small { color: var(--ex-sub); }
    .entry { max-width: 860px; }
    .pf .row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
    .bal { font-size: 12px; color: #5b6b7c; margin-top: 4px; min-height: 16px; } .bal b { color: var(--ex-dark); }
    .ways { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 4px; }
    .ways label { display: flex; align-items: center; gap: 6px; border: 1px solid #c9d6e2; border-radius: 9px; padding: 7px 11px; font-size: 13px; font-weight: 600; cursor: pointer; text-transform: none; margin: 0; }
    .ways label:has(input:checked) { border-color: var(--ex-light); background: var(--ex-soft); color: var(--ex-dark); }
    .ways input { width: auto; height: auto; accent-color: var(--ex-light); }
    .amount input { font-size: 20px !important; font-weight: 700; height: 46px !important; font-variant-numeric: tabular-nums; }
    .words { font-size: 12px; color: #5b6b7c; min-height: 16px; margin-top: 4px; }
    .done { background: #e8f0fe; border: 1px solid var(--ex-border); border-radius: 14px; padding: 12px 16px; margin-bottom: 14px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; color: var(--ex-dark); }
    .done b { font-size: 15px; } .done .sp { margin-left: auto; display: flex; gap: 8px; }
    @media (max-width: 640px) { .pf .row3, .pf .row { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('New Entry', 'Money in, money out, cash to the bank, one account to another — each gets its voucher number', 'fa-pen', ['acc_vouchers.php' => '<i class="fas fa-file-invoice-dollar"></i> Vouchers']); ?>
    <?php acc_tabs('acc_entry.php'); exam_flash(); ?>

    <?php if ($last): ?>
    <div class="done">
        <i class="fas fa-check-circle" style="font-size:22px"></i>
        <div><b><?php echo h($last['voucher_no']); ?> saved — <?php echo h(fee_money($last['amount'])); ?></b><br><small><?php echo h(ACC_KINDS[$last['kind']] . ' · ' . $last['account_name'] . ($last['party'] ? ' · ' . $last['party'] : '') . ' · ' . date('d M Y', strtotime($last['entry_date']))); ?></small></div>
        <span class="sp"><a class="btn btn-primary btn-sm" target="_blank" href="<?php echo h('acc_voucher.php?id=' . (int)$last['id']); ?>"><i class="fas fa-print"></i> Print voucher</a></span>
    </div>
    <?php endif; ?>

    <div class="kinds">
        <?php foreach ($forms as $k => [$label, $icon, $hint]): ?>
        <a href="<?php echo h('acc_entry.php?kind=' . $k); ?>" class="<?php echo $k === $form ? 'on' : ''; ?>"><i class="fas <?php echo h($icon); ?>"></i><span><b><?php echo h($label); ?></b><small><?php echo h($hint); ?></small></span></a>
        <?php endforeach; ?>
    </div>

<?php if (!$accounts): ?>
    <?php exam_guard('No account yet', 'Add the school\'s accounts and what they start with first.', 'acc_settings.php', 'Account Settings'); ?>
<?php elseif (($form === 'expense' || $form === 'income') && !$heads): ?>
    <?php exam_guard('No ' . $form . ' head yet', 'Add the heads (or "Add the usual heads") first.', 'acc_settings.php?tab=heads', 'Income & Expense Heads'); ?>
<?php elseif ($form === 'transfer' && count($accounts) < 2): ?>
    <?php exam_guard('Only one account', 'A transfer needs two accounts that are on.', 'acc_settings.php', 'Account Settings'); ?>
<?php else: ?>
    <form method="post" class="card pf entry" id="entryForm" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="form" value="<?php echo h($form); ?>"><input type="hidden" name="token" value="<?php echo h($token); ?>">
        <h2><i class="fas <?php echo h($forms[$form][1]); ?>"></i> <?php echo h($forms[$form][0]); ?></h2>
        <?php if ($form === 'transfer'): ?>
        <div class="row">
            <div><label>From account</label><select name="account_id" id="eAcc" required><?php echo $acc_options($v('account_id')); ?></select><div class="bal" id="eBal"></div></div>
            <div><label>Leaves as</label><div class="ways"><?php foreach (ACC_MODES as $m => $label): ?><label><input type="radio" name="from_mode" value="<?php echo $m; ?>"<?php echo $v('from_mode', 'bank') === $m ? ' checked' : ''; ?>> <?php echo $label; ?></label><?php endforeach; ?></div></div>
        </div>
        <div class="row">
            <div><label>To account</label><select name="to_account_id" id="eTo" required><?php echo $acc_options($v('to_account_id')); ?></select><div class="bal" id="eToBal"></div></div>
            <div><label>Arrives as</label><div class="ways"><?php foreach (ACC_MODES as $m => $label): ?><label><input type="radio" name="to_mode" value="<?php echo $m; ?>"<?php echo $v('to_mode', 'bank') === $m ? ' checked' : ''; ?>> <?php echo $label; ?></label><?php endforeach; ?></div></div>
        </div>
        <?php else: ?>
        <div class="row">
            <div><label>Account</label><select name="account_id" id="eAcc" required><?php echo $acc_options($v('account_id')); ?></select><div class="bal" id="eBal"></div></div>
            <?php if ($form === 'contra'): ?>
            <div><label>Move</label><div class="ways"><label><input type="radio" name="move" value="deposit"<?php echo $v('move', 'deposit') === 'deposit' ? ' checked' : ''; ?>> Cash → Bank (deposit)</label><label><input type="radio" name="move" value="withdraw"<?php echo $v('move') === 'withdraw' ? ' checked' : ''; ?>> Bank → Cash (withdraw)</label></div></div>
            <?php else: ?>
            <div><label><?php echo $form === 'income' ? 'Income head' : 'Expense head'; ?></label><select name="head_id" id="eHead" required><option value="">Choose…</option><?php foreach ($heads as $hid => $hd): ?><option value="<?php echo (int)$hid; ?>" data-for="<?php echo h((string)$hd['for_type']); ?>"<?php echo (string)$hid === $v('head_id') ? ' selected' : ''; ?>><?php echo h($hd['name']); ?></option><?php endforeach; ?></select></div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="row3">
            <div><label>Date</label><input type="date" name="date" value="<?php echo h($v('date', date('Y-m-d'))); ?>" max="<?php echo date('Y-m-d'); ?>" required></div>
            <div class="amount" style="grid-column:span 2"><label>Amount (₹)</label><input type="text" name="amount" id="eAmt" inputmode="decimal" value="<?php echo h($v('amount')); ?>" placeholder="0.00" required><div class="words" id="eWords"></div></div>
        </div>
        <?php if ($form === 'expense' || $form === 'income'): ?>
        <label><?php echo $form === 'income' ? 'Received as' : 'Paid by'; ?></label>
        <div class="ways"><?php foreach (ACC_WAYS as $w => $label): ?><label><input type="radio" name="way" value="<?php echo $w; ?>"<?php echo $v('way', 'cash') === $w ? ' checked' : ''; ?>> <?php echo $label; ?></label><?php endforeach; ?></div>
        <div class="row">
            <div id="eRefBox"><label id="eRefLabel">Number</label><input type="text" name="reference" id="eRef" maxlength="80" value="<?php echo h($v('reference')); ?>"></div>
            <div><label><?php echo $form === 'income' ? 'Received from' : 'Paid to'; ?></label><input type="text" name="party" maxlength="150" value="<?php echo h($v('party')); ?>" required placeholder="<?php echo $form === 'income' ? 'e.g. District MDM Cell' : 'e.g. Sarkar Stationery'; ?>"></div>
        </div>
        <?php if ($form === 'expense'): ?>
        <div class="row"><div><label>Bill number</label><input type="text" name="bill_no" maxlength="50" value="<?php echo h($v('bill_no')); ?>"></div><div><label>Bill date</label><input type="date" name="bill_date" max="<?php echo date('Y-m-d'); ?>" value="<?php echo h($v('bill_date')); ?>"></div></div>
        <?php endif; ?>
        <?php else: ?>
        <label>Number <small style="text-transform:none;font-weight:400">(deposit slip, cheque or UTR — if any)</small></label><input type="text" name="reference" maxlength="100" value="<?php echo h($v('reference')); ?>">
        <?php endif; ?>
        <label>What for</label><input type="text" name="description" maxlength="255" value="<?php echo h($v('description')); ?>" placeholder="<?php echo $form === 'expense' ? 'e.g. Chalk, registers and ink for the exam' : ''; ?>">
        <?php if ($form === 'expense' || $form === 'income'): ?>
        <label>Bill or letter <small style="text-transform:none;font-weight:400">(photo or PDF, up to 3 MB — optional)</small></label><input type="file" name="bill" accept=".jpg,.jpeg,.png,.webp,.pdf,image/*,application/pdf" style="height:auto;padding:6px">
        <?php endif; ?>
        <div class="acts"><button type="submit" class="btn btn-success" id="eSave"><i class="fas fa-save"></i> Save</button></div>
    </form>
<?php endif; ?>
</div>
<script>
(function () {
    var form = document.getElementById('entryForm');
    if (!form) return;
    var money = function (p) { return '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    var tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    function inWords(n) {
        if (n === 0) return 'Zero';
        var out = '';
        [[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand'], [100, 'Hundred']].forEach(function (u) { if (n >= u[0]) { out += inWords(Math.floor(n / u[0])) + ' ' + u[1] + ' '; n %= u[0]; } });
        return (out + (n < 20 ? ones[n] : tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : ''))).trim();
    }
    function bal(sel, box) {
        var o = sel.options[sel.selectedIndex];
        document.getElementById(box).innerHTML = o && o.value ? 'Now: cash <b>' + money(+o.dataset.cash) + '</b> · bank <b>' + money(+o.dataset.bank) + '</b>' : '';
    }
    var acc = document.getElementById('eAcc'), to = document.getElementById('eTo'), head = document.getElementById('eHead');
    function heads() {
        if (!head) return;
        var t = acc.options[acc.selectedIndex] ? acc.options[acc.selectedIndex].dataset.type : '';
        Array.prototype.forEach.call(head.options, function (o) { if (!o.value) return; var ok = !o.dataset.for || o.dataset.for === t; o.hidden = !ok; o.disabled = !ok; if (!ok && o.selected) head.value = ''; });
    }
    acc.addEventListener('change', function () { bal(acc, 'eBal'); heads(); }); bal(acc, 'eBal'); heads();
    if (to) { to.addEventListener('change', function () { bal(to, 'eToBal'); }); bal(to, 'eToBal'); }
    var amt = document.getElementById('eAmt');
    function words() {
        var x = String(amt.value).replace(/,/g, '').trim(), p = /^\d{1,9}(\.\d{1,2})?$/.test(x) ? Math.round(parseFloat(x) * 100) : 0;
        document.getElementById('eWords').textContent = p ? 'Rupees ' + inWords(Math.floor(p / 100)) + (p % 100 ? ' and ' + inWords(p % 100) + ' Paise' : '') + ' Only' : '';
    }
    amt.addEventListener('input', words); words();
    var ref = document.getElementById('eRef');
    function way() {
        var w = form.querySelector('input[name=way]:checked');
        if (!w || !ref) return;
        document.getElementById('eRefBox').style.visibility = w.value === 'cash' ? 'hidden' : 'visible';
        document.getElementById('eRefLabel').textContent = { cheque: 'Cheque number', transfer: 'UTR / transaction number', upi: 'UPI transaction ID' }[w.value] || 'Number';
        ref.required = w.value !== 'cash';
    }
    Array.prototype.forEach.call(form.querySelectorAll('input[name=way]'), function (r) { r.addEventListener('change', way); }); way();
    form.addEventListener('submit', function () { document.getElementById('eSave').disabled = true; });
})();
</script>
</body>
</html>

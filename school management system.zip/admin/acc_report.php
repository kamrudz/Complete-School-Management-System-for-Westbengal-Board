<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/acc_helper.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Account reports: balances on a date, one account's statement, Receipts & Payments (the audit statement), the expense
 * register, a grant's utilisation for a financial year, the Mid-Day Meal month by month, and the bank reconciliation.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$reports = ['balances' => ['Balances', 'fa-balance-scale'], 'statement' => ['Statement', 'fa-file-alt'], 'rp' => ['Receipts & Payments', 'fa-columns'],
    'expenses' => ['Expense Register', 'fa-list-ul'], 'uc' => ['Grant UC', 'fa-certificate'], 'mdm' => ['Mid-Day Meal', 'fa-utensils'], 'bank' => ['Bank Reconciliation', 'fa-check-double']];
$type = (string)($_GET['type'] ?? $_POST['type'] ?? 'balances');
if (!isset($reports[$type])) $type = 'balances';
$periods = acc_periods();
$period = (string)($_GET['period'] ?? '');
$from = (string)($_GET['from'] ?? ''); $to = (string)($_GET['to'] ?? '');
if (isset($periods[$period])) [, $from, $to] = $periods[$period];
if (!fee_valid_date($from)) $from = $type === 'mdm' || $type === 'rp' ? acc_fy_range(acc_fy(date('Y-m-d')))[0] : date('Y-m-01');
if (!fee_valid_date($to)) $to = date('Y-m-d');
if ($from > $to) [$from, $to] = [$to, $from];
$on = (string)($_GET['on'] ?? $_POST['on'] ?? '');
if (!fee_valid_date($on) || $on > date('Y-m-d')) $on = date('Y-m-d');
$accounts = acc_accounts();
$of_type = fn(string $t) => array_filter($accounts, fn($a) => $a['type'] === $t);
$choices = match ($type) { 'uc' => $of_type('grant'), 'mdm' => $of_type('mdm') ?: $accounts, default => $accounts };
$account = (int)($_GET['account_id'] ?? $_POST['account_id'] ?? 0);
$all_allowed = in_array($type, ['rp', 'expenses'], true);
if (!isset($choices[$account])) $account = $all_allowed ? 0 : (int)array_key_first($choices);
$mode = (string)($_GET['mode'] ?? 'bank'); if (!isset(ACC_MODES[$mode])) $mode = 'bank';
$fys = array_values(array_map(fn($k) => substr($k, 3), array_filter(array_keys($periods), fn($k) => str_starts_with($k, 'fy:'))));
$fy = (string)($_GET['fy'] ?? ''); if (!in_array($fy, $fys, true)) $fy = acc_fy(date('Y-m-d'));
$head = (int)($_GET['head_id'] ?? 0);
$q = array_filter(['type' => $type, 'period' => isset($periods[$period]) ? $period : null, 'from' => isset($periods[$period]) ? null : $from, 'to' => isset($periods[$period]) ? null : $to,
    'on' => in_array($type, ['balances', 'bank'], true) ? $on : null, 'account_id' => $account ?: null, 'mode' => $type === 'statement' ? $mode : null, 'fy' => $type === 'uc' ? $fy : null, 'head_id' => $type === 'expenses' && $head ? $head : null]);
$link = fn(array $over = []) => 'acc_report.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));
$range = date('d M Y', strtotime($from)) . ($from !== $to ? ' to ' . date('d M Y', strtotime($to)) : '');
$rp = fn(int $p) => round($p / 100, 2);
$export = !empty($_GET['export']);
$xlsx = function (string $title, string $note, array $head, array $rows, string $file) {
    $out = exam_xlsx_title($title, $note);
    $out[] = $head;
    foreach ($rows as $r) $out[] = $r;
    SimpleXLSXWriter::download($file, $out, 'Report', exam_xlsx_opts(count($head), 32));
    exit();
};
$sum_bal = function (array $bal, array $ids) { $t = ['cash' => 0, 'bank' => 0]; foreach ($ids as $id) { $t['cash'] += $bal[$id]['cash'] ?? 0; $t['bank'] += $bal[$id]['bank'] ?? 0; } return $t; };
$opened_in = function (array $ids, string $f, string $t) use ($accounts) { $s = 0; foreach ($ids as $id) if ($accounts[$id]['opening_date'] > $f && $accounts[$id]['opening_date'] <= $t) $s += fee_paise($accounts[$id]['opening_cash']) + fee_paise($accounts[$id]['opening_bank']); return $s; };
/** Valid entries of some accounts in a period, summed by what they were: [receipts => label => paise, payments => label => paise]. Moves inside the view are left out. */
$moves = function (array $ids, string $f, string $t) {
    $view = array_flip($ids);
    $r = []; $p = [];
    foreach (db_get_all('SELECT e.kind, e.direction, e.description, hd.name AS head_name, p.account_id AS pair_acc, pa.name AS pair_name, SUM(e.amount) AS amt FROM acc_entries e
        LEFT JOIN acc_heads hd ON hd.id = e.head_id LEFT JOIN acc_entries p ON p.id = e.pair_id LEFT JOIN acc_accounts pa ON pa.id = p.account_id
        WHERE e.status = \'valid\' AND e.entry_date BETWEEN ? AND ? AND e.account_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ")
        GROUP BY e.kind, e.direction, e.description, hd.name, p.account_id, pa.name ORDER BY e.kind, hd.name, e.description", 'ss' . str_repeat('i', count($ids)), $f, $t, ...$ids) as $m) {
        $amt = fee_paise($m['amt']);
        if ($m['kind'] === 'fee') $r['Fees — ' . $m['description']] = ($r['Fees — ' . $m['description']] ?? 0) + $amt;
        elseif ($m['kind'] === 'income') $r[(string)$m['head_name']] = ($r[(string)$m['head_name']] ?? 0) + $amt;
        elseif ($m['kind'] === 'expense') $p[(string)$m['head_name']] = ($p[(string)$m['head_name']] ?? 0) + $amt;
        elseif ($m['kind'] === 'transfer' && !isset($view[(int)$m['pair_acc']])) {
            if ($m['direction'] === 'in') $r['Transfer from ' . $m['pair_name']] = ($r['Transfer from ' . $m['pair_name']] ?? 0) + $amt;
            else $p['Transfer to ' . $m['pair_name']] = ($p['Transfer to ' . $m['pair_name']] ?? 0) + $amt;
        }
    }
    return ['receipts' => $r, 'payments' => $p];
};

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $type === 'bank') {
    verify_csrf_or_die();
    try {
        if (!$account) throw new RuntimeException('Choose the account.');
        $act = (string)($_POST['act'] ?? '');
        $keys = json_decode((string)($_POST['lines'] ?? ''), true);
        if (!is_array($keys) || !$keys) throw new RuntimeException('Tick the entries first.');
        $date = (string)($_POST['cleared_on'] ?? '');
        if ($act === 'clear' && (!fee_valid_date($date) || $date > date('Y-m-d'))) throw new RuntimeException('Give the date the bank shows them — today or earlier.');
        $n = 0;
        foreach ($keys as $k) {
            if (!is_string($k) || !preg_match('/^([re]):(\d+)$/', $k, $m)) continue;
            $col = $m[1] === 'r' ? 'fee_receipt_id' : 'id';
            $n += db_execute("UPDATE acc_entries SET cleared_on = ? WHERE $col = ? AND account_id = ? AND mode = 'bank' AND status = 'valid'" . ($act === 'clear' ? ' AND entry_date <= ?' : ''),
                $act === 'clear' ? 'siis' : 'sii', ...($act === 'clear' ? [$date, (int)$m[2], $account, $date] : [null, (int)$m[2], $account]));
        }
        acc_log($admin_id, $act === 'clear' ? 'ACC_BANK_CLEARED' : 'ACC_BANK_UNCLEARED', 'acc_entries', null, null, ['account' => $account, 'lines' => $keys, 'date' => $act === 'clear' ? $date : null]);
        $_SESSION['success'] = $act === 'clear' ? "$n entr" . ($n === 1 ? 'y' : 'ies') . ' marked as in the passbook on ' . date('d M Y', strtotime($date)) . '.' : "$n entr" . ($n === 1 ? 'y' : 'ies') . ' marked as not in the passbook yet.';
    } catch (RuntimeException $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    header('Location: ' . $link());
    exit();
}

$data = [];
if ($type === 'balances') {
    $bal = acc_balances($on);
    foreach ($accounts as $id => $a) if ($a['opening_date'] <= $on || $bal[$id]['cash'] || $bal[$id]['bank']) $data[$id] = $a + $bal[$id];
    if ($export) $xlsx('Account balances', 'At the end of ' . date('d M Y', strtotime($on)), ['Account', 'Type', 'Bank', 'Cash', 'Bank balance', 'Total'],
        array_map(fn($a) => [$a['name'], ACC_TYPES[$a['type']][0], acc_bank_line($a), $rp($a['cash']), $rp($a['bank']), $rp($a['cash'] + $a['bank'])], $data), 'Account_balances_' . $on . '.xlsx');
}
if ($type === 'statement' && $account) {
    $open = acc_balance($account, $from, true)[$mode];
    $bal = $open;
    foreach (acc_book_lines($from, $to, [$account]) as $l) {
        $in = $l[$mode . '_in']; $out = $l[$mode . '_out'];
        if (!$in && !$out) continue;
        $bal += $in - $out;
        $data[] = $l + ['in' => $in, 'out' => $out, 'balance' => $bal];
    }
    $close = acc_balance($account, $to)[$mode];
    if ($export) $xlsx('Statement — ' . $accounts[$account]['name'] . ' (' . ACC_MODES[$mode] . ')', $range, ['Date', 'Voucher', 'Particulars', 'In', 'Out', 'Balance'],
        array_merge([[date('d-m-Y', strtotime($from)), '', 'Opening balance', '', '', $rp($open)]],
            array_map(fn($l) => [date('d-m-Y', strtotime($l['date'])), $l['voucher'], $l['text'] . ($l['sub'] !== '' ? ' — ' . $l['sub'] : ''), $l['in'] ? $rp($l['in']) : '', $l['out'] ? $rp($l['out']) : '', $rp($l['balance'])], $data)),
        'Statement_' . preg_replace('/[^A-Za-z0-9]+/', '_', $accounts[$account]['name']) . "_{$mode}_{$from}_to_$to.xlsx");
}
if ($type === 'rp' && $accounts) {
    $ids = $account ? [$account] : array_keys($accounts);
    $open = $sum_bal(acc_balances($from, true), $ids);
    $close = $sum_bal(acc_balances($to), $ids);
    $newly = $opened_in($ids, $from, $to);
    $data = $moves($ids, $from, $to);
    $left = $open['cash'] + $open['bank'] + $newly + array_sum($data['receipts']);
    $right = array_sum($data['payments']) + $close['cash'] + $close['bank'];
    if ($export) {
        $rows = [['RECEIPTS', ''], ['Opening balance — cash', $rp($open['cash'])], ['Opening balance — bank', $rp($open['bank'])]];
        if ($newly) $rows[] = ['Opening balances of accounts opened in the period', $rp($newly)];
        foreach ($data['receipts'] as $k => $v) $rows[] = [$k, $rp($v)];
        $rows[] = ['Total', $rp($left)]; $rows[] = ['', '']; $rows[] = ['PAYMENTS', ''];
        foreach ($data['payments'] as $k => $v) $rows[] = [$k, $rp($v)];
        array_push($rows, ['Closing balance — cash', $rp($close['cash'])], ['Closing balance — bank', $rp($close['bank'])], ['Total', $rp($right)]);
        $xlsx('Receipts and Payments — ' . ($account ? $accounts[$account]['name'] : 'all accounts'), $range, ['Particulars', 'Amount (₹)'], $rows, 'Receipts_and_Payments_' . $from . '_to_' . $to . '.xlsx');
    }
}
if ($type === 'expenses') {
    $where = ["e.status = 'valid'", "e.kind = 'expense'", 'e.entry_date BETWEEN ? AND ?']; $types = 'ss'; $params = [$from, $to];
    if ($account) { $where[] = 'e.account_id = ?'; $types .= 'i'; $params[] = $account; }
    if ($head) { $where[] = 'e.head_id = ?'; $types .= 'i'; $params[] = $head; }
    $data = db_get_all('SELECT e.*, a.name AS account_name, hd.name AS head_name FROM acc_entries e JOIN acc_accounts a ON a.id = e.account_id LEFT JOIN acc_heads hd ON hd.id = e.head_id WHERE ' . implode(' AND ', $where) . ' ORDER BY hd.sort_order, hd.name, e.entry_date, e.id', $types, ...$params);
    if ($export) $xlsx('Expense register' . ($account ? ' — ' . $accounts[$account]['name'] : ''), $range, ['Head', 'Date', 'Voucher', 'Account', 'Paid to', 'Bill', 'Paid by', 'What for', 'Amount'],
        array_map(fn($r) => [(string)$r['head_name'], date('d-m-Y', strtotime($r['entry_date'])), $r['voucher_no'], $r['account_name'], (string)$r['party'], trim($r['bill_no'] . ($r['bill_date'] ? ' ' . date('d-m-Y', strtotime($r['bill_date'])) : '')),
            $r['mode'] === 'cash' ? 'Cash' : (string)$r['reference'], (string)$r['description'], $rp(fee_paise($r['amount']))], $data), 'Expense_register_' . $from . '_to_' . $to . '.xlsx');
}
if ($type === 'uc' && $account) {
    [$f, $t] = acc_fy_range($fy);
    $a = $accounts[$account];
    $open = array_sum(acc_balance($account, $f, true)) + $opened_in([$account], $f, $t);
    $close = array_sum(acc_balance($account, $t));
    $data = $moves([$account], $f, $t);
    $got = array_sum($data['receipts']); $spent = array_sum($data['payments']);
    $receipts = db_get_all("SELECT e.entry_date, e.party, e.reference, e.amount, hd.name AS head_name, e.kind, e.description, pa.name AS pair_name FROM acc_entries e LEFT JOIN acc_heads hd ON hd.id = e.head_id
        LEFT JOIN acc_entries p ON p.id = e.pair_id LEFT JOIN acc_accounts pa ON pa.id = p.account_id
        WHERE e.account_id = ? AND e.status = 'valid' AND e.direction = 'in' AND e.kind IN ('income', 'fee', 'transfer') AND e.entry_date BETWEEN ? AND ? ORDER BY e.entry_date, e.id", 'iss', $account, $f, $t);
    if ($export) {
        $rows = [['Unspent at the start of the year', $rp($open)]];
        foreach ($receipts as $r) $rows[] = ['Received ' . date('d-m-Y', strtotime($r['entry_date'])) . ' — ' . ($r['head_name'] ?: ($r['kind'] === 'fee' ? 'Fees — ' . $r['description'] : 'Transfer from ' . $r['pair_name'])) . ($r['party'] ? ', ' . $r['party'] : ''), $rp(fee_paise($r['amount']))];
        $rows[] = ['Total available', $rp($open + $got)];
        foreach ($data['payments'] as $k => $v) $rows[] = ['Spent — ' . $k, $rp($v)];
        array_push($rows, ['Total spent', $rp($spent)], ['Unspent at the end of the year', $rp($close)]);
        $xlsx('Utilisation certificate — ' . $a['name'], 'Financial year ' . $fy, ['Particulars', 'Amount (₹)'], $rows, 'UC_' . preg_replace('/[^A-Za-z0-9]+/', '_', $a['name']) . "_$fy.xlsx");
    }
}
if ($type === 'mdm' && $account) {
    $mheads = [];
    $months = [];
    $last = min($to, date('Y-m-d'));
    for ($m = substr($from, 0, 7); $m <= substr($last, 0, 7); $m = date('Y-m', strtotime("$m-01 +1 month"))) {
        $mf = max($from, "$m-01"); $mt = min($last, date('Y-m-t', strtotime("$m-01")));
        $mv = $moves([$account], $mf, $mt);
        $open = array_sum(acc_balance($account, $mf, true)) + $opened_in([$account], $mf, $mt);
        foreach (array_keys($mv['payments']) as $k) $mheads[$k] = true;
        $months[$m] = ['label' => date('F Y', strtotime("$m-01")), 'open' => $open, 'got' => array_sum($mv['receipts']), 'spent' => $mv['payments'], 'close' => array_sum(acc_balance($account, $mt))];
    }
    $mheads = array_keys($mheads);
    $data = $months;
    if ($export) $xlsx('Mid-Day Meal — ' . $accounts[$account]['name'], $range, array_merge(['Month', 'Opening', 'Received'], $mheads, ['Spent', 'Closing']),
        array_map(fn($r) => array_merge([$r['label'], $rp($r['open']), $rp($r['got'])], array_map(fn($k) => $rp($r['spent'][$k] ?? 0), $mheads), [$rp(array_sum($r['spent'])), $rp($r['close'])]), array_values($months)), 'MDM_' . $from . '_to_' . $to . '.xlsx');
}
if ($type === 'bank' && $account) {
    $book = acc_balance($account, $on)['bank'];
    $lines = [];
    foreach (db_get_all("SELECT e.*, hd.name AS head_name, pa.name AS pair_name FROM acc_entries e LEFT JOIN acc_heads hd ON hd.id = e.head_id
        LEFT JOIN acc_entries p ON p.id = e.pair_id LEFT JOIN acc_accounts pa ON pa.id = p.account_id
        WHERE e.account_id = ? AND e.mode = 'bank' AND e.status = 'valid' AND e.entry_date <= ? AND (e.cleared_on IS NULL OR e.cleared_on > ?) ORDER BY e.entry_date, e.id", 'iss', $account, $on, $on) as $e) {
        $k = $e['kind'] === 'fee' ? 'r:' . $e['fee_receipt_id'] : 'e:' . $e['id'];
        if (!isset($lines[$k])) $lines[$k] = ['date' => $e['entry_date'], 'voucher' => $e['kind'] === 'fee' ? (string)$e['reference'] : (string)$e['voucher_no'], 'text' => match ($e['kind']) { 'fee' => 'Fees', 'deposit' => 'Cash deposited in the bank', 'withdraw' => 'Cash drawn from the bank',
            'transfer' => ($e['direction'] === 'out' ? 'Transfer to ' : 'Transfer from ') . $e['pair_name'], default => (string)$e['head_name'] },
            'party' => (string)$e['party'], 'ref' => $e['kind'] === 'fee' ? '' : (string)$e['reference'], 'in' => 0, 'out' => 0];
        $lines[$k][$e['direction']] += fee_paise($e['amount']);
    }
    $pending_in = array_sum(array_column($lines, 'in')); $pending_out = array_sum(array_column($lines, 'out'));
    $expected = $book - $pending_in + $pending_out;
    $passbook = acc_amount_in($_GET['passbook'] ?? '');
    $cleared = db_get_all("SELECT e.*, hd.name AS head_name FROM acc_entries e LEFT JOIN acc_heads hd ON hd.id = e.head_id WHERE e.account_id = ? AND e.mode = 'bank' AND e.status = 'valid' AND e.cleared_on IS NOT NULL AND e.cleared_on BETWEEN DATE_SUB(?, INTERVAL 31 DAY) AND ? ORDER BY e.cleared_on DESC, e.id DESC", 'iss', $account, $on, $on);
    $data = $lines;
}
$expense_heads = acc_heads('expense');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h('Account Reports — ' . $reports[$type][0]); ?></title>
<?php exam_styles('acc'); ?>
<style>
    .seg { display: inline-flex; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 14px; }
    .seg a { padding: 7px 12px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; } .seg a i { margin-right: 6px; }
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tfoot td, .ex-table tr.tot td { font-weight: 700; background: var(--ex-soft); }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; }
    .ex-table .in { color: #1b7a3a; } .ex-table .out { color: #b71c1c; } .ex-table .neg { color: #b71c1c; font-weight: 700; }
    .ex-table tr.open td, .ex-table tr.grp td { background: var(--ex-group); font-weight: 700; color: var(--ex-dark); }
    .type { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: var(--ex-soft); color: var(--ex-dark); border: 1px solid var(--ex-border); white-space: nowrap; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; align-items: start; }
    .two .card { margin: 0; }
    .cert { font-size: 13.5px; line-height: 1.7; margin: 10px 0 0; }
    .signs { display: flex; justify-content: space-between; gap: 20px; margin-top: 22mm; font-size: 12px; }
    .signs div { flex: 1; border-top: 1px solid #333; text-align: center; padding-top: 3px; }
    .ok { color: #1b7a3a; font-weight: 700; } .bad { color: #b71c1c; font-weight: 700; }
    .print-head { display: none; }
    @media (max-width: 900px) { .two { grid-template-columns: 1fr; } }
    @media print {
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .seg, .noprint, .alert { display: none !important; }
        .print-head { display: block; }
        .ex-table td, .ex-table th { white-space: normal !important; padding: 3px 5px !important; font-size: 11px !important; }
        .ex-table td.money { white-space: nowrap !important; }
        .auto-table-scroll { overflow: visible !important; margin-top: 0 !important; }
        .card { border: 0; padding: 0; }
        .two { grid-template-columns: 1fr 1fr; }
        .ex-table a { color: inherit; text-decoration: none; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Account Reports', 'Where the money is, how each account moved, and the statements the audit asks for', 'fa-chart-line',
        $type === 'bank' ? ['javascript:window.print()' => '<i class="fas fa-print"></i> Print'] : [$link(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php acc_tabs('acc_report.php'); exam_flash(); ?>
    <div class="seg">
        <?php foreach ($reports as $k => [$label, $icon]): ?><a href="<?php echo h('acc_report.php?type=' . $k); ?>" class="<?php echo $k === $type ? 'on' : ''; ?>"><i class="fas <?php echo h($icon); ?>"></i><?php echo h($label); ?></a><?php endforeach; ?>
    </div>
<?php
    $period_fields = function () use ($periods, $period, $from, $to) { ?>
        <div><label>Period</label><select name="period" onchange="this.form.submit()"><option value="">Dates below</option><?php foreach ($periods as $k => [$label]): ?><option value="<?php echo h($k); ?>"<?php echo $k === $period ? ' selected' : ''; ?>><?php echo h($label); ?></option><?php endforeach; ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div>
    <?php };
    $account_field = function (bool $all) use ($choices, $account) { ?>
        <div><label>Account</label><select name="account_id"><?php if ($all): ?><option value="0">All accounts</option><?php endif; ?><?php foreach ($choices as $id => $x): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $account ? ' selected' : ''; ?>><?php echo h($x['name']); ?></option><?php endforeach; ?></select></div>
    <?php };
?>

<?php if (!$accounts): ?>
    <?php exam_guard('No account yet', 'Add the school\'s accounts first.', 'acc_settings.php', 'Account Settings'); ?>

<?php elseif ($type === 'balances'): $tc = array_sum(array_column($data, 'cash')); $tb = array_sum(array_column($data, 'bank')); ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="balances">
        <div><label>At the end of</label><input type="date" name="on" value="<?php echo h($on); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('ACCOUNT BALANCES', 'At the end of ' . date('d M Y', strtotime($on))); ?></div>
    <div class="sum">
        <div><b><?php echo h(fee_money_p($tc)); ?></b><small>cash in hand</small></div>
        <div><b><?php echo h(fee_money_p($tb)); ?></b><small>in the bank</small></div>
        <div><b><?php echo h(fee_money_p($tc + $tb)); ?></b><small>in all, <?php echo h(date('d M Y', strtotime($on))); ?></small></div>
    </div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Account</th><th>Type</th><th class="money">Cash</th><th class="money">Bank</th><th class="money">Total</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($data as $id => $a): ?>
            <tr>
                <td><b><?php echo h($a['name']); ?></b><?php $bl = acc_bank_line($a); echo $bl !== '' ? '<small>' . h($bl) . '</small>' : ''; ?></td>
                <td><span class="type"><i class="fas <?php echo h(ACC_TYPES[$a['type']][1]); ?>"></i><?php echo h(ACC_TYPES[$a['type']][0]); ?></span></td>
                <td class="money <?php echo $a['cash'] < 0 ? 'neg' : ''; ?>"><?php echo h(fee_money_p($a['cash'])); ?></td>
                <td class="money <?php echo $a['bank'] < 0 ? 'neg' : ''; ?>"><?php echo h(fee_money_p($a['bank'])); ?></td>
                <td class="money"><b><?php echo h(fee_money_p($a['cash'] + $a['bank'])); ?></b></td>
                <td class="noprint" style="white-space:nowrap"><a class="btn btn-secondary btn-sm" href="<?php echo h('acc_report.php?' . http_build_query(['type' => 'statement', 'account_id' => $id, 'mode' => 'bank'])); ?>">Statement</a> <a class="btn btn-secondary btn-sm" href="<?php echo h('acc_cashbook.php?account_id=' . $id); ?>">Cash Book</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="2">Total</td><td class="money"><?php echo h(fee_money_p($tc)); ?></td><td class="money"><?php echo h(fee_money_p($tb)); ?></td><td class="money"><?php echo h(fee_money_p($tc + $tb)); ?></td><td class="noprint"></td></tr></tfoot>
        </table>
    </div>

<?php elseif ($type === 'statement'): $a = $accounts[$account]; ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="statement">
        <?php $account_field(false); ?>
        <div><label>Money</label><select name="mode"><option value="bank"<?php echo $mode === 'bank' ? ' selected' : ''; ?>>In the bank — like the passbook</option><option value="cash"<?php echo $mode === 'cash' ? ' selected' : ''; ?>>Cash in hand</option></select></div>
        <?php $period_fields(); ?>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('STATEMENT — ' . mb_strtoupper($a['name']) . ' (' . mb_strtoupper(ACC_MODES[$mode]) . ')', trim(acc_bank_line($a) . ' · ' . $range, ' ·')); ?></div>
    <div class="sum">
        <div><b><?php echo h(fee_money_p($open)); ?></b><small>when <?php echo h(date('d M Y', strtotime($from))); ?> began</small></div>
        <div><b style="color:#1b7a3a"><?php echo h(fee_money_p(array_sum(array_column($data, 'in')))); ?></b><small>came in</small></div>
        <div><b style="color:#b71c1c"><?php echo h(fee_money_p(array_sum(array_column($data, 'out')))); ?></b><small>went out</small></div>
        <div><b><?php echo h(fee_money_p($close)); ?></b><small>at the end of <?php echo h(date('d M Y', strtotime($to))); ?></small></div>
    </div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Date</th><th>Voucher</th><th>Particulars</th><th class="money">In</th><th class="money">Out</th><th class="money">Balance</th></tr></thead>
            <tbody>
            <tr class="open"><td><?php echo h(date('d M Y', strtotime($from))); ?></td><td></td><td>Opening balance</td><td></td><td></td><td class="money"><?php echo h(fee_money_p($open)); ?></td></tr>
            <?php foreach ($data as $l): ?>
            <tr>
                <td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($l['date']))); ?></td>
                <td style="white-space:nowrap;font-weight:700"><?php echo h($l['voucher']); ?></td>
                <td><?php echo h($l['text']); ?><?php echo $l['sub'] !== '' ? '<small>' . h($l['sub']) . '</small>' : ''; ?></td>
                <td class="money in"><?php echo $l['in'] ? h(fee_num_p($l['in'])) : ''; ?></td>
                <td class="money out"><?php echo $l['out'] ? h(fee_num_p($l['out'])) : ''; ?></td>
                <td class="money <?php echo $l['balance'] < 0 ? 'neg' : ''; ?>"><?php echo h(fee_num_p($l['balance'])); ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (!$data): ?><tr><td colspan="6" style="text-align:center;color:#7a8a9a;padding:16px">No <?php echo $mode === 'bank' ? 'bank' : 'cash'; ?> entries in <?php echo h($range); ?>.</td></tr><?php endif; ?>
            </tbody>
            <tfoot><tr><td colspan="3">Closing balance · <?php echo h(date('d M Y', strtotime($to))); ?></td><td class="money"><?php echo h(fee_num_p(array_sum(array_column($data, 'in')))); ?></td><td class="money"><?php echo h(fee_num_p(array_sum(array_column($data, 'out')))); ?></td><td class="money"><?php echo h(fee_money_p($close)); ?></td></tr></tfoot>
        </table>
    </div>

<?php elseif ($type === 'rp'): ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="rp">
        <?php $account_field(true); $period_fields(); ?>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('RECEIPTS AND PAYMENTS ACCOUNT' . ($account ? ' — ' . mb_strtoupper($accounts[$account]['name']) : ''), $range); ?></div>
    <?php if ($left !== $right): ?><div class="ex-guard"><i class="fas fa-exclamation-triangle big"></i><div><b>The two sides do not agree</b>Receipts <?php echo h(fee_money_p($left)); ?>, payments <?php echo h(fee_money_p($right)); ?>.</div></div><?php endif; ?>
    <div class="two">
        <div class="card" style="overflow-x:auto">
            <h2>Receipts</h2>
            <table class="ex-table">
                <tbody>
                <tr class="grp"><td>Opening balance</td><td class="money"></td></tr>
                <tr><td>Cash in hand</td><td class="money"><?php echo h(fee_num_p($open['cash'])); ?></td></tr>
                <tr><td>In the bank</td><td class="money"><?php echo h(fee_num_p($open['bank'])); ?></td></tr>
                <?php if ($newly): ?><tr><td>Accounts opened in the period</td><td class="money"><?php echo h(fee_num_p($newly)); ?></td></tr><?php endif; ?>
                <tr class="grp"><td>Received</td><td class="money"></td></tr>
                <?php foreach ($data['receipts'] as $k => $v): ?><tr><td><?php echo h($k); ?></td><td class="money"><?php echo h(fee_num_p($v)); ?></td></tr><?php endforeach; ?>
                <?php if (!$data['receipts']): ?><tr><td colspan="2" style="color:#7a8a9a">Nothing received.</td></tr><?php endif; ?>
                </tbody>
                <tfoot><tr><td>Total</td><td class="money"><?php echo h(fee_money_p($left)); ?></td></tr></tfoot>
            </table>
        </div>
        <div class="card" style="overflow-x:auto">
            <h2>Payments</h2>
            <table class="ex-table">
                <tbody>
                <tr class="grp"><td>Paid</td><td class="money"></td></tr>
                <?php foreach ($data['payments'] as $k => $v): ?><tr><td><?php echo h($k); ?></td><td class="money"><?php echo h(fee_num_p($v)); ?></td></tr><?php endforeach; ?>
                <?php if (!$data['payments']): ?><tr><td colspan="2" style="color:#7a8a9a">Nothing paid.</td></tr><?php endif; ?>
                <tr class="grp"><td>Closing balance</td><td class="money"></td></tr>
                <tr><td>Cash in hand</td><td class="money"><?php echo h(fee_num_p($close['cash'])); ?></td></tr>
                <tr><td>In the bank</td><td class="money"><?php echo h(fee_num_p($close['bank'])); ?></td></tr>
                </tbody>
                <tfoot><tr><td>Total</td><td class="money"><?php echo h(fee_money_p($right)); ?></td></tr></tfoot>
            </table>
        </div>
    </div>
    <p class="note noprint">Money moved between cash and bank, or between the accounts shown, is left out — it neither came in nor went out.</p>

<?php elseif ($type === 'expenses'): $groups = []; foreach ($data as $r) $groups[(string)$r['head_name']][] = $r; $grand = array_sum(array_map(fn($r) => fee_paise($r['amount']), $data)); ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="expenses">
        <?php $account_field(true); ?>
        <div><label>Head</label><select name="head_id"><option value="0">All heads</option><?php foreach ($expense_heads as $id => $hd): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $head ? ' selected' : ''; ?>><?php echo h($hd['name']); ?></option><?php endforeach; ?></select></div>
        <?php $period_fields(); ?>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('EXPENSE REGISTER' . ($account ? ' — ' . mb_strtoupper($accounts[$account]['name']) : ''), $range); ?></div>
    <div class="sum">
        <div><b style="color:#b71c1c"><?php echo h(fee_money_p($grand)); ?></b><small>spent · <?php echo h($range); ?></small></div>
        <div><b><?php echo count($data); ?></b><small>payment voucher(s)</small></div>
        <div><b><?php echo count($groups); ?></b><small>head(s)</small></div>
    </div>
    <?php if (!$data): ?>
    <div class="ex-empty"><i class="fas fa-list-ul"></i>No expenses in <?php echo h($range); ?>.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Date</th><th>Voucher</th><?php if (!$account): ?><th>Account</th><?php endif; ?><th>Paid to</th><th>Bill</th><th>Paid by</th><th class="money">Amount</th></tr></thead>
            <tbody>
            <?php $cols = $account ? 5 : 6; foreach ($groups as $hname => $list): $sub = array_sum(array_map(fn($r) => fee_paise($r['amount']), $list)); ?>
                <tr class="grp"><td colspan="<?php echo $cols; ?>"><?php echo h($hname); ?></td><td class="money"><?php echo h(fee_num_p($sub)); ?></td></tr>
                <?php foreach ($list as $r): ?>
                <tr>
                    <td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($r['entry_date']))); ?></td>
                    <td style="white-space:nowrap;font-weight:700"><a href="<?php echo h('acc_voucher.php?id=' . (int)$r['id']); ?>" target="_blank"><?php echo h($r['voucher_no']); ?></a></td>
                    <?php if (!$account): ?><td><?php echo h($r['account_name']); ?></td><?php endif; ?>
                    <td><?php echo h((string)$r['party']); ?><?php echo $r['description'] ? '<small>' . h($r['description']) . '</small>' : ''; ?></td>
                    <td><?php echo h(trim($r['bill_no'] . ($r['bill_date'] ? ' · ' . date('d M Y', strtotime($r['bill_date'])) : ''))); ?><?php echo $r['attachment'] ? ' <a class="noprint" target="_blank" href="' . h('acc_bill.php?id=' . (int)$r['id']) . '"><i class="fas fa-paperclip"></i></a>' : ''; ?></td>
                    <td><?php echo h($r['mode'] === 'cash' ? 'Cash' : (string)$r['reference']); ?></td>
                    <td class="money"><?php echo h(fee_num_p(fee_paise($r['amount']))); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="<?php echo $cols; ?>">Total</td><td class="money"><?php echo h(fee_money_p($grand)); ?></td></tr></tfoot>
        </table>
    </div>
    <?php endif; ?>

<?php elseif ($type === 'uc'): ?>
    <?php if (!$choices): ?>
    <?php exam_guard('No grant account', 'Add an account of the Grant type in Account Settings.', 'acc_settings.php', 'Account Settings'); ?>
    <?php else: $a = $accounts[$account]; ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="uc">
        <?php $account_field(false); ?>
        <div><label>Financial year</label><select name="fy"><?php foreach ($fys as $x): ?><option value="<?php echo h($x); ?>"<?php echo $x === $fy ? ' selected' : ''; ?>><?php echo h("$x (April–March)"); ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="card">
        <?php exam_school_header('UTILISATION CERTIFICATE', $a['name'] . ' · Financial year ' . $fy . (acc_bank_line($a) !== '' ? ' · ' . acc_bank_line($a) : '')); ?>
        <table class="ex-table">
            <tbody>
            <tr><td>Unspent at the start of the year (1 April)</td><td class="money"><?php echo h(fee_num_p($open)); ?></td></tr>
            <tr class="grp"><td colspan="2">Received during the year</td></tr>
            <?php foreach ($receipts as $r): ?><tr><td><?php echo h(date('d M Y', strtotime($r['entry_date'])) . ' — ' . ($r['head_name'] ?: ($r['kind'] === 'fee' ? 'Fees — ' . $r['description'] : 'Transfer from ' . $r['pair_name'])) . ($r['party'] ? ', ' . $r['party'] : '') . ($r['reference'] ? ' (' . $r['reference'] . ')' : '')); ?></td><td class="money"><?php echo h(fee_num_p(fee_paise($r['amount']))); ?></td></tr><?php endforeach; ?>
            <?php if (!$receipts): ?><tr><td colspan="2" style="color:#7a8a9a">Nothing received.</td></tr><?php endif; ?>
            <tr class="tot"><td>Total available</td><td class="money"><?php echo h(fee_num_p($open + $got)); ?></td></tr>
            <tr class="grp"><td colspan="2">Spent during the year</td></tr>
            <?php foreach ($data['payments'] as $k => $v): ?><tr><td><?php echo h($k); ?></td><td class="money"><?php echo h(fee_num_p($v)); ?></td></tr><?php endforeach; ?>
            <?php if (!$data['payments']): ?><tr><td colspan="2" style="color:#7a8a9a">Nothing spent.</td></tr><?php endif; ?>
            <tr class="tot"><td>Total spent</td><td class="money"><?php echo h(fee_num_p($spent)); ?></td></tr>
            <tr class="tot"><td>Unspent at the end of the year (31 March)</td><td class="money"><?php echo h(fee_money_p($close)); ?></td></tr>
            </tbody>
        </table>
        <?php if ($open + $got - $spent !== $close): ?><p class="bad">The figures do not agree: <?php echo h(fee_money_p($open + $got - $spent)); ?> worked out, <?php echo h(fee_money_p($close)); ?> in the books.</p><?php endif; ?>
        <p class="cert">Certified that out of <?php echo h(fee_money_p($open + $got)); ?> available in <?php echo h($fy); ?> — <?php echo h(fee_money_p($open)); ?> unspent from the year before and <?php echo h(fee_money_p($got)); ?> received during the year — a sum of <b><?php echo h(fee_money_p($spent)); ?></b> (<?php echo h(fee_words($spent)); ?>) has been spent on the purposes for which it was given, and <b><?php echo h(fee_money_p($close)); ?></b> remains unspent at the end of the year.</p>
        <div class="signs"><?php foreach (array_slice(array_values(array_filter(explode('|', (string)acc_settings()['signatures']))), 1) ?: ['Headmaster / TIC', 'Secretary / President'] as $s): ?><div><?php echo h($s); ?></div><?php endforeach; ?></div>
    </div>
    <?php endif; ?>

<?php elseif ($type === 'mdm'): ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="mdm">
        <?php $account_field(false); $period_fields(); ?>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('MID-DAY MEAL — ' . mb_strtoupper($accounts[$account]['name']), $range); ?></div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Month</th><th class="money">Opening</th><th class="money">Received</th><?php foreach ($mheads as $k): ?><th class="money"><?php echo h(preg_replace('/^MDM:\s*/i', '', $k)); ?></th><?php endforeach; ?><th class="money">Spent</th><th class="money">Closing</th></tr></thead>
            <tbody>
            <?php foreach ($data as $r): ?>
            <tr><td><b><?php echo h($r['label']); ?></b></td><td class="money"><?php echo h(fee_num_p($r['open'])); ?></td><td class="money in"><?php echo $r['got'] ? h(fee_num_p($r['got'])) : ''; ?></td>
                <?php foreach ($mheads as $k): ?><td class="money"><?php echo !empty($r['spent'][$k]) ? h(fee_num_p($r['spent'][$k])) : ''; ?></td><?php endforeach; ?>
                <td class="money out"><?php echo array_sum($r['spent']) ? h(fee_num_p(array_sum($r['spent']))) : ''; ?></td><td class="money"><b><?php echo h(fee_num_p($r['close'])); ?></b></td></tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><td class="money"><?php echo $data ? h(fee_num_p(reset($data)['open'])) : ''; ?></td><td class="money"><?php echo h(fee_num_p(array_sum(array_column($data, 'got')))); ?></td>
                <?php foreach ($mheads as $k): ?><td class="money"><?php echo h(fee_num_p(array_sum(array_map(fn($r) => $r['spent'][$k] ?? 0, $data)))); ?></td><?php endforeach; ?>
                <td class="money"><?php echo h(fee_num_p(array_sum(array_map(fn($r) => array_sum($r['spent']), $data)))); ?></td><td class="money"><?php echo $data ? h(fee_num_p(end($data)['close'])) : ''; ?></td></tr></tfoot>
        </table>
    </div>

<?php elseif ($type === 'bank'): $a = $accounts[$account]; ?>
    <form method="get" class="card pick noprint"><input type="hidden" name="type" value="bank">
        <?php $account_field(false); ?>
        <div><label>As on</label><input type="date" name="on" value="<?php echo h($on); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <div><label>Passbook balance (₹)</label><input type="text" name="passbook" inputmode="decimal" value="<?php echo $passbook !== null ? h(fee_rupees($passbook)) : ''; ?>" placeholder="what the passbook shows"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('BANK RECONCILIATION — ' . mb_strtoupper($a['name']), trim(acc_bank_line($a) . ' · As on ' . date('d M Y', strtotime($on)), ' ·')); ?></div>
    <div class="card" style="max-width:720px">
        <table class="ex-table">
            <tbody>
            <tr><td>Balance in the books (bank)</td><td class="money"><?php echo h(fee_money_p($book)); ?></td></tr>
            <tr><td>Less: money in the books, not yet in the passbook</td><td class="money out">− <?php echo h(fee_num_p($pending_in)); ?></td></tr>
            <tr><td>Add: payments in the books (cheques issued), not yet out of the passbook</td><td class="money in">+ <?php echo h(fee_num_p($pending_out)); ?></td></tr>
            <tr class="tot"><td>The passbook should show</td><td class="money"><?php echo h(fee_money_p($expected)); ?></td></tr>
            <?php if ($passbook !== null): ?>
            <tr><td>The passbook shows</td><td class="money"><?php echo h(fee_money_p($passbook)); ?></td></tr>
            <tr class="tot"><td>Difference</td><td class="money <?php echo $passbook === $expected ? 'ok' : 'bad'; ?>"><?php echo $passbook === $expected ? 'None — it agrees' : h(fee_money_p($passbook - $expected)); ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <form method="post" class="card" id="recon" action="<?php echo h($link()); ?>">
        <?php echo csrf_field(); ?><input type="hidden" name="type" value="bank"><input type="hidden" name="account_id" value="<?php echo (int)$account; ?>"><input type="hidden" name="on" value="<?php echo h($on); ?>"><input type="hidden" name="lines" id="reconLines"><input type="hidden" name="act" value="clear">
        <h2>Not in the passbook yet <small><?php echo count($data); ?> entr<?php echo count($data) === 1 ? 'y' : 'ies'; ?></small></h2>
        <?php if (!$data): ?>
        <div class="ex-empty"><i class="fas fa-check-circle" style="color:#1b7a3a"></i>Every bank entry up to <?php echo h(date('d M Y', strtotime($on))); ?> is in the passbook.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th class="noprint"><input type="checkbox" id="reconAll"></th><th>Date</th><th>Voucher</th><th>Particulars</th><th class="money">In</th><th class="money">Out</th></tr></thead>
            <tbody>
            <?php foreach ($data as $k => $l): ?>
            <tr><td class="noprint"><input type="checkbox" class="rc" value="<?php echo h($k); ?>"></td><td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($l['date']))); ?></td><td style="white-space:nowrap;font-weight:700"><?php echo h($l['voucher']); ?></td>
                <td><?php echo h($l['text']); ?><?php echo $l['party'] !== '' || $l['ref'] !== '' ? '<small>' . h(implode(' · ', array_filter([$l['party'], $l['ref']]))) . '</small>' : ''; ?></td>
                <td class="money in"><?php echo $l['in'] ? h(fee_num_p($l['in'])) : ''; ?></td><td class="money out"><?php echo $l['out'] ? h(fee_num_p($l['out'])) : ''; ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="pick noprint" style="margin-top:10px"><div><label>The passbook shows them on</label><input type="date" name="cleared_on" value="<?php echo h($on); ?>" max="<?php echo date('Y-m-d'); ?>"></div><button type="submit" class="btn btn-success"><i class="fas fa-check-double"></i> Mark the ticked ones as in the passbook</button></div>
        <?php endif; ?>
    </form>
    <?php if ($cleared): ?>
    <form method="post" class="card noprint" id="unrecon" action="<?php echo h($link()); ?>">
        <?php echo csrf_field(); ?><input type="hidden" name="type" value="bank"><input type="hidden" name="account_id" value="<?php echo (int)$account; ?>"><input type="hidden" name="on" value="<?php echo h($on); ?>"><input type="hidden" name="act" value="unclear"><input type="hidden" name="lines" id="unLines">
        <h2>Marked as in the passbook <small>in the 31 days up to <?php echo h(date('d M Y', strtotime($on))); ?></small></h2>
        <table class="ex-table">
            <thead><tr><th>In the passbook on</th><th>Date</th><th>Voucher</th><th class="money">Amount</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($cleared as $e): $k = $e['kind'] === 'fee' ? 'r:' . $e['fee_receipt_id'] : 'e:' . $e['id']; ?>
            <tr><td><?php echo h(date('d M Y', strtotime($e['cleared_on']))); ?></td><td><?php echo h(date('d M Y', strtotime($e['entry_date']))); ?></td><td><b><?php echo h($e['kind'] === 'fee' ? $e['reference'] : $e['voucher_no']); ?></b> <?php echo h($e['kind'] === 'fee' ? $e['description'] : (string)$e['head_name']); ?></td>
                <td class="money <?php echo $e['direction'] === 'in' ? 'in' : 'out'; ?>"><?php echo h(fee_num_p(fee_paise($e['amount']))); ?></td>
                <td><button type="submit" class="btn btn-secondary btn-sm" onclick="document.getElementById('unLines').value = JSON.stringify([<?php echo h(json_encode($k)); ?>])" title="Not in the passbook after all"><i class="fas fa-undo"></i></button></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </form>
    <?php endif; ?>
    <script>
    (function () {
        var f = document.getElementById('recon'), all = document.getElementById('reconAll');
        if (!f || !all) return;
        var boxes = Array.prototype.slice.call(f.querySelectorAll('.rc'));
        all.addEventListener('change', function () { boxes.forEach(function (b) { b.checked = all.checked; }); });
        f.addEventListener('submit', function (e) {
            var keys = boxes.filter(function (b) { return b.checked; }).map(function (b) { return b.value; });
            if (!keys.length) { e.preventDefault(); alert('Tick the entries the passbook shows.'); return; }
            document.getElementById('reconLines').value = JSON.stringify(keys);
        });
    })();
    </script>
<?php endif; ?>
</div>
</body>
</html>

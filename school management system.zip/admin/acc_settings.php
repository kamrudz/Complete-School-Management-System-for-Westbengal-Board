<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/acc_helper.php';

/** Account Settings: the school's accounts and what they started with, the income and expense heads, and the options. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$tabs = ['accounts' => ['Accounts', 'fa-university'], 'heads' => ['Income & Expense Heads', 'fa-tags'], 'options' => ['Options', 'fa-sliders-h']];
$tab = (string)($_GET['tab'] ?? $_POST['tab'] ?? 'accounts');
if (!isset($tabs[$tab])) $tab = 'accounts';
$go = function (string $kind = '', string $msg = '') use ($tab) { if ($kind !== '') $_SESSION[$kind] = $msg; header('Location: acc_settings.php?tab=' . $tab); exit(); };
$usual_accounts = [['School Fund', 'school_fund'], ['Fine Account', 'fine'], ['Board Fees', 'board_fees'], ['Mid-Day Meal', 'mdm'], ['Composite Grant', 'grant'], ['Festival Fund', 'festival']];
$usual_heads = [
    ['income', 'Grant received', 'grant'], ['income', 'MDM cooking cost received', 'mdm'], ['income', 'Bank interest', null], ['income', 'Donation', null],
    ['income', 'Sale of forms', null], ['income', 'Miscellaneous income', null],
    ['expense', 'Stationery', null], ['expense', 'Printing and photocopy', null], ['expense', 'Electricity', null], ['expense', 'Internet and phone', null],
    ['expense', 'Repair and maintenance', null], ['expense', 'Cleaning and sanitation', null], ['expense', 'Drinking water', null], ['expense', 'Examination expenses', null],
    ['expense', 'Sports', null], ['expense', 'Cultural programme', null], ['expense', 'Prizes and awards', null], ['expense', 'Travel and conveyance', null],
    ['expense', 'Honorarium', null], ['expense', 'Bank charges', null], ['expense', 'Audit fee', null], ['expense', 'Board fees sent to the Board', 'board_fees'],
    ['expense', 'MDM: bazar and groceries', 'mdm'], ['expense', 'MDM: oil and spices', 'mdm'], ['expense', 'MDM: fuel / LPG', 'mdm'], ['expense', 'MDM: cook honorarium', 'mdm'],
    ['expense', 'MDM: utensils and kitchen', 'mdm'], ['expense', 'Puja and Jalsa expenses', 'festival'], ['expense', 'Miscellaneous expenses', null],
];
$account_used = fn(int $id) => (bool)db_get_row('SELECT 1 FROM acc_entries WHERE account_id = ? UNION ALL SELECT 1 FROM fee_types WHERE account_id = ? UNION ALL SELECT 1 FROM acc_settings WHERE fee_account_id = ? LIMIT 1', 'iii', $id, $id, $id);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'save_account') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $type = (string)($_POST['type'] ?? '');
            $no = preg_replace('/\s+/', '', (string)($_POST['account_no'] ?? ''));
            $ifsc = strtoupper(trim((string)($_POST['ifsc'] ?? '')));
            $date = trim((string)($_POST['opening_date'] ?? ''));
            $cash = acc_amount_in(trim((string)($_POST['opening_cash'] ?? '')) ?: '0');
            $bank = acc_amount_in(trim((string)($_POST['opening_bank'] ?? '')) ?: '0');
            if ($name === '' || mb_strlen($name) > 100) throw new RuntimeException('Give the account a name (up to 100 letters).');
            if (!isset(ACC_TYPES[$type])) throw new RuntimeException('Choose the type of account.');
            if (!preg_match('/^[A-Za-z0-9-]{0,30}$/', $no)) throw new RuntimeException('Account number: up to 30 letters or digits.');
            if ($ifsc !== '' && !preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $ifsc)) throw new RuntimeException('IFSC: 11 characters, like SBIN0001234.');
            if (!fee_valid_date($date) || $date > date('Y-m-d')) throw new RuntimeException('Give the date the balances below are on — today or earlier.');
            if ($cash === null || $bank === null) throw new RuntimeException('Opening cash and bank: amounts in rupees, like 2500 or 2500.50.');
            $data = ['name' => $name, 'type' => $type, 'bank_name' => mb_substr(trim((string)($_POST['bank_name'] ?? '')), 0, 100) ?: null, 'branch' => mb_substr(trim((string)($_POST['branch'] ?? '')), 0, 100) ?: null,
                'account_no' => $no !== '' ? $no : null, 'ifsc' => $ifsc !== '' ? $ifsc : null, 'opening_date' => $date, 'opening_cash' => fee_rupees($cash), 'opening_bank' => fee_rupees($bank),
                'is_active' => !empty($_POST['is_active']) ? 1 : 0, 'sort_order' => max(0, min(999, (int)($_POST['sort_order'] ?? 0))), 'note' => mb_substr(trim((string)($_POST['note'] ?? '')), 0, 255) ?: null];
            try {
                if ($id) {
                    $old = db_get_row('SELECT * FROM acc_accounts WHERE id = ?', 'i', $id);
                    if (!$old) throw new RuntimeException('That account is gone — reload the page.');
                    $first = (string)(db_get_row('SELECT MIN(entry_date) AS d FROM acc_entries WHERE account_id = ?', 'i', $id)['d'] ?? '');
                    if ($first !== '' && $date > $first) throw new RuntimeException("{$old['name']} has entries from " . date('d M Y', strtotime($first)) . ' — the opening date must be on or before that.');
                    $moved = $old['opening_date'] !== $date || fee_paise($old['opening_cash']) !== $cash || fee_paise($old['opening_bank']) !== $bank;
                    if ($moved && (acc_locked($old['opening_date']) || acc_locked($date))) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . ' — the opening balance of this account cannot change.');
                    db_update('acc_accounts', $data, ['id' => $id], 'i');
                    acc_log($admin_id, 'ACC_ACCOUNT_UPDATED', 'acc_accounts', $id, $old, $data);
                } else {
                    if (acc_locked($date)) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . ' — open the account from a later date.');
                    $id = (int)db_insert('acc_accounts', $data + ['created_by' => $admin_id ?: null]);
                    acc_log($admin_id, 'ACC_ACCOUNT_ADDED', 'acc_accounts', $id, null, $data);
                }
            } catch (mysqli_sql_exception $e) {
                throw new RuntimeException($e->getCode() === 1062 ? "An account called $name is already there." : 'Could not save: ' . $e->getMessage());
            }
            $go('success', "$name saved.");
        }
        if ($act === 'delete_account') {
            $a = db_get_row('SELECT * FROM acc_accounts WHERE id = ?', 'i', (int)($_POST['id'] ?? 0));
            if (!$a) throw new RuntimeException('That account is gone — reload the page.');
            if ($account_used((int)$a['id'])) throw new RuntimeException("{$a['name']} has entries or fee heads, or takes fee money by default — switch it off instead.");
            db_execute('DELETE FROM acc_accounts WHERE id = ?', 'i', (int)$a['id']);
            acc_log($admin_id, 'ACC_ACCOUNT_DELETED', 'acc_accounts', (int)$a['id'], $a, null);
            $go('success', "{$a['name']} deleted.");
        }
        if ($act === 'add_usual_accounts') {
            $have = array_change_key_case(array_flip(array_column(acc_accounts(), 'name')), CASE_LOWER);
            $order = (int)(db_get_row('SELECT COALESCE(MAX(sort_order), 0) AS m FROM acc_accounts')['m'] ?? 0);
            $n = 0;
            db_begin_transaction();
            try {
                foreach ($usual_accounts as [$name, $type]) {
                    if (isset($have[mb_strtolower($name)])) continue;
                    db_insert('acc_accounts', ['name' => $name, 'type' => $type, 'opening_date' => date('Y-m-d'), 'opening_cash' => '0.00', 'opening_bank' => '0.00', 'sort_order' => $order += 10, 'created_by' => $admin_id ?: null]);
                    $n++;
                }
                $school = array_key_first(array_filter(acc_accounts(), fn($a) => $a['type'] === 'school_fund'));
                if (!acc_settings(true)['fee_account_id'] && $school) db_execute('UPDATE acc_settings SET fee_account_id = ? WHERE id = 1', 'i', $school);
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The accounts could not be added: ' . $e->getMessage());
            }
            if ($n) acc_log($admin_id, 'ACC_ACCOUNTS_ADDED', 'acc_accounts', null, null, "$n usual account(s)");
            $go('success', $n ? "$n account(s) added — give each its bank details and opening balance, then choose where each fee goes." : 'The usual accounts are all there already.');
        }
        if ($act === 'post_fees') {
            [$n, $left] = acc_post_pending_fee_receipts($admin_id);
            if (!$n) throw new RuntimeException('No receipt could go in — choose an account for every fee head, or a default fee account in Options, first.');
            $go('success', "$n fee receipt(s) are now in the accounts." . ($left ? " $left still wait: a fee head of theirs has no account, or they are in the closed books." : ''));
        }
        if ($act === 'save_fee_map') {
            $map = json_decode((string)($_POST['map'] ?? ''), true);
            if (!is_array($map)) throw new RuntimeException('The choices did not arrive — try again.');
            $fees = fee_heads(); $accs = acc_accounts(); $n = 0;
            foreach ($map as $fid => $aid) {
                if (!isset($fees[(int)$fid]) || !is_int($aid) || ($aid && !isset($accs[$aid]))) throw new RuntimeException('A fee head or account is not there any more — reload the page.');
            }
            foreach ($map as $fid => $aid) {
                if ((int)$fees[(int)$fid]['account_id'] === $aid) continue;
                $n += db_execute('UPDATE fee_types SET account_id = ? WHERE id = ?', 'ii', $aid ?: null, (int)$fid);
                acc_log($admin_id, 'ACC_FEE_HEAD_ACCOUNT', 'fee_types', (int)$fid, ['account' => $fees[(int)$fid]['account_id']], ['account' => $aid ?: null]);
            }
            $go('success', $n ? "$n fee head(s) now go to the account chosen." : 'Nothing changed.');
        }
        if ($act === 'save_head') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $kind = (string)($_POST['kind'] ?? '');
            $for = (string)($_POST['for_type'] ?? '');
            if ($name === '' || mb_strlen($name) > 100) throw new RuntimeException('Give the head a name (up to 100 letters).');
            if (!in_array($kind, ['income', 'expense'], true)) throw new RuntimeException('Choose income or expense.');
            if ($for !== '' && !isset(ACC_TYPES[$for])) throw new RuntimeException('Choose which accounts the head is for.');
            $data = ['name' => $name, 'kind' => $kind, 'for_type' => $for !== '' ? $for : null, 'is_active' => !empty($_POST['is_active']) ? 1 : 0, 'sort_order' => max(0, min(999, (int)($_POST['sort_order'] ?? 0)))];
            try {
                if ($id) {
                    $old = db_get_row('SELECT * FROM acc_heads WHERE id = ?', 'i', $id);
                    if (!$old) throw new RuntimeException('That head is gone — reload the page.');
                    if ($old['kind'] !== $kind && db_get_row('SELECT 1 FROM acc_entries WHERE head_id = ? LIMIT 1', 'i', $id)) throw new RuntimeException("{$old['name']} has entries, so it stays " . ($old['kind'] === 'income' ? 'an income' : 'an expense') . ' head.');
                    db_update('acc_heads', $data, ['id' => $id], 'i');
                    acc_log($admin_id, 'ACC_HEAD_UPDATED', 'acc_heads', $id, $old, $data);
                } else {
                    $id = (int)db_insert('acc_heads', $data);
                    acc_log($admin_id, 'ACC_HEAD_ADDED', 'acc_heads', $id, null, $data);
                }
            } catch (mysqli_sql_exception $e) {
                throw new RuntimeException($e->getCode() === 1062 ? "There is already " . ($kind === 'income' ? 'an income' : 'an expense') . " head called $name." : 'Could not save: ' . $e->getMessage());
            }
            $go('success', "$name saved.");
        }
        if ($act === 'delete_head') {
            $hd = db_get_row('SELECT * FROM acc_heads WHERE id = ?', 'i', (int)($_POST['id'] ?? 0));
            if (!$hd) throw new RuntimeException('That head is gone — reload the page.');
            if (db_get_row('SELECT 1 FROM acc_entries WHERE head_id = ? LIMIT 1', 'i', (int)$hd['id'])) throw new RuntimeException("{$hd['name']} has entries — switch it off instead.");
            db_execute('DELETE FROM acc_heads WHERE id = ?', 'i', (int)$hd['id']);
            acc_log($admin_id, 'ACC_HEAD_DELETED', 'acc_heads', (int)$hd['id'], $hd, null);
            $go('success', "{$hd['name']} deleted.");
        }
        if ($act === 'add_usual_heads') {
            $have = [];
            foreach (acc_heads() as $hd) $have[$hd['kind'] . '|' . mb_strtolower($hd['name'])] = true;
            $order = ['income' => 0, 'expense' => 0];
            foreach (db_get_all('SELECT kind, MAX(sort_order) AS m FROM acc_heads GROUP BY kind') as $r) $order[$r['kind']] = (int)$r['m'];
            $n = 0;
            foreach ($usual_heads as [$kind, $name, $for]) {
                if (isset($have[$kind . '|' . mb_strtolower($name)])) continue;
                db_insert('acc_heads', ['name' => $name, 'kind' => $kind, 'for_type' => $for, 'is_active' => 1, 'sort_order' => $order[$kind] += 10]);
                $n++;
            }
            if ($n) acc_log($admin_id, 'ACC_HEADS_ADDED', 'acc_heads', null, null, "$n usual head(s)");
            $go('success', $n ? "$n head(s) added." : 'The usual heads are all there already.');
        }
        if ($act === 'save_options') {
            $fee_acc = (int)($_POST['fee_account_id'] ?? 0);
            $lock = trim((string)($_POST['lock_date'] ?? ''));
            if ($fee_acc && !isset(acc_accounts()[$fee_acc])) throw new RuntimeException('Choose the fee account again.');
            if ($lock !== '' && (!fee_valid_date($lock) || $lock >= date('Y-m-d'))) throw new RuntimeException('The books can be closed up to yesterday at the latest.');
            $signs = array_values(array_filter(array_map(fn($s) => mb_substr(trim(str_replace('|', '/', (string)$s)), 0, 40), (array)($_POST['sign'] ?? [])), fn($s) => $s !== ''));
            if (!$signs) throw new RuntimeException('Give at least one name to sign a voucher.');
            $old = acc_settings(true);
            $data = ['fee_account_id' => $fee_acc ?: null, 'lock_date' => $lock !== '' ? $lock : null, 'signatures' => implode('|', array_slice($signs, 0, 4)), 'updated_by' => $admin_id ?: null];
            db_update('acc_settings', $data, ['id' => 1], 'i');
            acc_log($admin_id, 'ACC_OPTIONS_SAVED', 'acc_settings', 1, $old, $data);
            $go('success', 'Options saved.');
        }
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage());
    }
    $go();
}

$accounts = acc_accounts();
$now = acc_balances();
$heads = acc_heads();
$settings = acc_settings(true);
$used_accounts = [];
foreach (db_get_all('SELECT DISTINCT account_id AS id FROM acc_entries UNION SELECT DISTINCT account_id FROM fee_types WHERE account_id IS NOT NULL') as $r) $used_accounts[(int)$r['id']] = true;
if ($settings['fee_account_id']) $used_accounts[(int)$settings['fee_account_id']] = true;
$used_heads = array_flip(array_map('intval', array_column(db_get_all('SELECT DISTINCT head_id FROM acc_entries WHERE head_id IS NOT NULL'), 'head_id')));
$usual_missing = count(array_diff(array_map(fn($u) => mb_strtolower($u[0]), $usual_accounts), array_map('mb_strtolower', array_column($accounts, 'name'))));
$heads_missing = count(array_diff(array_map(fn($u) => $u[0] . '|' . mb_strtolower($u[1]), $usual_heads), array_map(fn($hd) => $hd['kind'] . '|' . mb_strtolower($hd['name']), $heads)));
$fee_heads = fee_heads();
$pending = acc_fee_receipts_pending();
$early = acc_fee_receipts_before_books();
$ready = !array_filter($fee_heads, fn($f) => !$f['account_id']) || $settings['fee_account_id'];
$signs = array_pad(explode('|', (string)$settings['signatures']), 4, '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account Settings</title>
<?php exam_styles('acc'); ?>
<style>
    .seg { display: inline-flex; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 14px; }
    .seg a { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; } .seg a i { margin-right: 6px; }
    .card-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
    .card-head h2 { margin: 0; } .card-head .acts { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tr.grp td { background: var(--ex-group); color: var(--ex-dark); font-weight: 700; font-size: 12.5px; }
    .ex-table tr.off td { color: #98a6b5; }
    .ex-table tfoot td { font-weight: 700; background: var(--ex-soft); }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; font-weight: 400; }
    .type { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: var(--ex-soft); color: var(--ex-dark); border: 1px solid var(--ex-border); }
    .opt-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 14px; }
    .opt-grid .card { margin: 0; }
    .pf .row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
    .modal .box { width: min(600px, 94vw); }
    .modal .box h3 { margin: 0 0 6px; color: var(--ex-dark); font-size: 16px; }
    .map td { padding: 6px 9px; }
    @media (max-width: 640px) { .pf .row3, .pf .row { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Account Settings', 'The school\'s accounts and what they started with, the income and expense heads, and the options', 'fa-sliders-h'); ?>
    <?php acc_tabs('acc_settings.php'); exam_flash(); ?>

    <div class="seg">
        <?php foreach ($tabs as $k => [$label, $icon]): ?><a href="<?php echo h('acc_settings.php?tab=' . $k); ?>" class="<?php echo $k === $tab ? 'on' : ''; ?>"><i class="fas <?php echo h($icon); ?>"></i><?php echo h($label); ?></a><?php endforeach; ?>
    </div>

<?php if ($tab === 'accounts'): ?>
    <div class="card">
        <div class="card-head">
            <h2>Accounts <small><?php echo count($accounts); ?> account(s)</small></h2>
            <div class="acts">
                <?php if ($usual_missing): ?>
                <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="tab" value="accounts"><button type="submit" name="act" value="add_usual_accounts" class="btn btn-secondary btn-sm"><i class="fas fa-magic"></i> Add the usual accounts</button></form>
                <?php endif; ?>
                <button type="button" class="btn btn-success btn-sm" onclick="accOpen(null)"><i class="fas fa-plus"></i> Add account</button>
            </div>
        </div>
        <?php if (!$accounts): ?>
        <div class="ex-empty"><i class="fas fa-university"></i>No accounts yet. "Add the usual accounts" puts in School Fund, Fine, Board Fees, Mid-Day Meal, Composite Grant and Festival Fund — then give each its bank details and the balance it starts with.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Account</th><th>Type</th><th>From</th><th class="money">Opening cash</th><th class="money">Opening bank</th><th class="money">Cash now</th><th class="money">Bank now</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($accounts as $id => $a): [$tl, $ti] = ACC_TYPES[$a['type']]; ?>
            <tr class="<?php echo $a['is_active'] ? '' : 'off'; ?>">
                <td><b><?php echo h($a['name']); ?></b><?php $bl = acc_bank_line($a); echo $bl !== '' ? '<small>' . h($bl) . '</small>' : '<small>no bank details yet</small>'; ?></td>
                <td><span class="type"><i class="fas <?php echo h($ti); ?>"></i><?php echo h($tl); ?></span></td>
                <td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($a['opening_date']))); ?></td>
                <td class="money"><?php echo h(fee_money($a['opening_cash'])); ?></td>
                <td class="money"><?php echo h(fee_money($a['opening_bank'])); ?></td>
                <td class="money"><b><?php echo h(fee_money_p($now[$id]['cash'])); ?></b></td>
                <td class="money"><b><?php echo h(fee_money_p($now[$id]['bank'])); ?></b></td>
                <td><?php echo $a['is_active'] ? '<span class="chip ok">On</span>' : '<span class="chip off">Off</span>'; ?><?php echo (int)$settings['fee_account_id'] === $id ? ' <span class="chip warn" title="Fee money with no account of its own comes here">fee default</span>' : ''; ?></td>
                <td style="white-space:nowrap">
                    <button type="button" class="btn btn-warning btn-sm" onclick="accOpen(<?php echo h(json_encode($a)); ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                    <?php if (empty($used_accounts[$id])): ?>
                    <form method="post" style="display:inline" onsubmit="return confirm(<?php echo h(json_encode('Delete the account ' . $a['name'] . '?')); ?>)"><?php echo csrf_field(); ?><input type="hidden" name="tab" value="accounts"><input type="hidden" name="id" value="<?php echo (int)$id; ?>"><button type="submit" name="act" value="delete_account" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button></form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="5">Total</td><td class="money"><?php echo h(fee_money_p(array_sum(array_column($now, 'cash')))); ?></td><td class="money"><?php echo h(fee_money_p(array_sum(array_column($now, 'bank')))); ?></td><td colspan="2"></td></tr></tfoot>
        </table>
        </div>
        <p class="note">An account that has entries, fee heads or takes fee money by default cannot be deleted — switch it off instead.</p>
        <?php endif; ?>
    </div>

    <?php if ($accounts && $fee_heads):
        $first_of = [];
        foreach ($accounts as $aid => $a) if ($a['is_active'] && !isset($first_of[$a['type']])) $first_of[$a['type']] = $aid;
        $suggest = fn(array $fh) => $fh['charge'] === 'any' ? 'fine' : (!$fh['slip'] ? 'festival' : (in_array($fh['category'], ['registration', 'form_fillup'], true) ? 'board_fees' : 'school_fund'));
        $default = $accounts[(int)$settings['fee_account_id']] ?? null;
        $suggested = 0; ?>
    <form method="post" class="card" id="feeMap">
        <?php echo csrf_field(); ?><input type="hidden" name="tab" value="accounts"><input type="hidden" name="act" value="save_fee_map"><input type="hidden" name="map" id="mapJson">
        <div class="card-head"><h2>Where fee money goes <small>every fee receipt is shared out over these accounts, head by head</small></h2></div>
        <table class="ex-table map">
            <thead><tr><th>Fee</th><th>Slip</th><th>Goes to</th></tr></thead>
            <tbody>
            <?php foreach ($fee_heads as $fid => $fh):
                $pick = (int)$fh['account_id'] ?: (int)($first_of[$suggest($fh)] ?? 0);
                $new = !$fh['account_id'] && $pick;
                if ($new) $suggested++; ?>
            <tr class="<?php echo $fh['is_active'] ? '' : 'off'; ?>" data-fee="<?php echo (int)$fid; ?>">
                <td><b><?php echo h($fh['type_name']); ?></b></td><td><?php echo $fh['slip'] ? 'Yes' : '<span class="chip warn">No</span>'; ?></td>
                <td><select class="mapSel" style="height:34px;border:1px solid #c9d6e2;border-radius:7px;padding:4px 8px;min-width:220px"><option value="0"><?php echo h($default ? 'Default — ' . $default['name'] : 'Default (not chosen yet)'); ?></option>
                    <?php foreach ($accounts as $aid => $a): ?><option value="<?php echo (int)$aid; ?>"<?php echo $aid === $pick ? ' selected' : ''; ?>><?php echo h($a['name']); ?></option><?php endforeach; ?></select>
                    <?php echo $new ? ' <span class="chip warn">suggested — not saved yet</span>' : ''; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="acts" style="margin-top:10px"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save where fees go</button></div>
        <p class="note"><?php echo $suggested ? "$suggested fee(s) show a suggestion — look them over (money kept without a slip, such as Puja and Jalsa, belongs in a cash account like Festival) and save. " : ''; ?>A head left on Default goes to the fee account chosen in Options.</p>
    </form>
    <?php if ($pending || $early['n']): $psum = array_sum(array_map(fn($r) => fee_paise($r['amount']), $pending)); ?>
    <div class="card" style="border-color:#f0c987;background:#fffaf0">
        <div class="card-head"><h2><i class="fas fa-inbox"></i> Fee receipts not in the accounts yet</h2>
            <?php if ($pending && $ready): ?><div class="acts"><form method="post" onsubmit="return confirm(<?php echo h(json_encode('Put ' . count($pending) . ' fee receipt(s), ' . fee_money_p($psum) . ', in the accounts?')); ?>)"><?php echo csrf_field(); ?><input type="hidden" name="tab" value="accounts"><button type="submit" name="act" value="post_fees" class="btn btn-success btn-sm"><i class="fas fa-file-import"></i> Put them in the accounts</button></form></div><?php endif; ?></div>
        <?php if ($pending): ?><p class="note" style="margin:0"><b><?php echo count($pending); ?> receipt(s), <?php echo h(fee_money_p($psum)); ?></b> — <?php echo h(reset($pending)['receipt_no'] . (count($pending) > 1 ? ' to ' . end($pending)['receipt_no'] : '')); ?>, taken before the accounts were set up or while a fee head had no account.
            <?php echo $ready ? 'Each goes in by its fee heads, as cash or bank, on the day it was taken.' : 'First choose an account for every fee head above, or a default fee account in Options.'; ?></p><?php endif; ?>
        <?php if ($early['n']): ?><p class="note"><?php echo $early['n']; ?> receipt(s), <?php echo h(fee_money_p($early['amount'])); ?>, were taken before <?php echo h(date('d M Y', strtotime($early['from']))); ?>, when the accounts begin — their money belongs in the opening balances, so they are not put in.</p><?php endif; ?>
    </div>
    <?php endif; ?>
    <script>
    document.getElementById('feeMap').addEventListener('submit', function () {
        var map = {};
        Array.prototype.forEach.call(this.querySelectorAll('tr[data-fee]'), function (tr) { map[tr.dataset.fee] = +tr.querySelector('.mapSel').value; });
        document.getElementById('mapJson').value = JSON.stringify(map);
    });
    </script>
    <?php endif; ?>

    <div class="modal" id="accModal">
        <form class="box pf" method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tab" value="accounts"><input type="hidden" name="act" value="save_account"><input type="hidden" name="id" id="aId">
            <h3 id="aTitle">Add account</h3>
            <div class="row"><div><label>Name</label><input type="text" name="name" id="aName" maxlength="100" required placeholder="e.g. School Fund"></div>
                <div><label>Type</label><select name="type" id="aType"><?php foreach (ACC_TYPES as $k => [$label, , $hint]): ?><option value="<?php echo h($k); ?>" title="<?php echo h($hint); ?>"><?php echo h($label); ?></option><?php endforeach; ?></select></div></div>
            <div class="row"><div><label>Bank</label><input type="text" name="bank_name" id="aBank" maxlength="100" placeholder="e.g. State Bank of India"></div><div><label>Branch</label><input type="text" name="branch" id="aBranch" maxlength="100"></div></div>
            <div class="row"><div><label>Account number</label><input type="text" name="account_no" id="aNo" maxlength="30" inputmode="numeric"></div><div><label>IFSC</label><input type="text" name="ifsc" id="aIfsc" maxlength="11" style="text-transform:uppercase" placeholder="SBIN0001234"></div></div>
            <div class="row3"><div><label>Balances on</label><input type="date" name="opening_date" id="aDate" max="<?php echo date('Y-m-d'); ?>" required></div>
                <div><label>Cash in hand (₹)</label><input type="text" name="opening_cash" id="aCash" inputmode="decimal" placeholder="0.00"></div>
                <div><label>In the bank (₹)</label><input type="text" name="opening_bank" id="aBankAmt" inputmode="decimal" placeholder="0.00"></div></div>
            <div class="row"><div><label>Order</label><input type="number" name="sort_order" id="aOrder" min="0" max="999" value="0"></div><div><label>Note</label><input type="text" name="note" id="aNote" maxlength="255"></div></div>
            <label class="chk"><input type="checkbox" name="is_active" id="aActive" value="1" checked> On — can take entries</label>
            <p class="note">The balances are what the account held when that day began — every entry of the account is from that date on.</p>
            <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('accModal').classList.remove('open')">Cancel</button></div>
        </form>
    </div>
    <script>
    function accOpen(a) {
        var f = function (id) { return document.getElementById(id); };
        f('aTitle').textContent = a ? 'Edit ' + a.name : 'Add account';
        f('aId').value = a ? a.id : '';
        f('aName').value = a ? a.name : '';
        f('aType').value = a ? a.type : 'school_fund';
        f('aBank').value = a && a.bank_name ? a.bank_name : '';
        f('aBranch').value = a && a.branch ? a.branch : '';
        f('aNo').value = a && a.account_no ? a.account_no : '';
        f('aIfsc').value = a && a.ifsc ? a.ifsc : '';
        f('aDate').value = a ? a.opening_date : <?php echo json_encode(date('Y-m-d')); ?>;
        f('aCash').value = a && +a.opening_cash ? a.opening_cash : '';
        f('aBankAmt').value = a && +a.opening_bank ? a.opening_bank : '';
        f('aOrder').value = a ? a.sort_order : 0;
        f('aNote').value = a && a.note ? a.note : '';
        f('aActive').checked = a ? !!+a.is_active : true;
        f('accModal').classList.add('open');
        f('aName').focus();
    }
    document.getElementById('accModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
    </script>

<?php elseif ($tab === 'heads'): ?>
    <div class="card">
        <div class="card-head">
            <h2>Income and expense heads <small><?php echo count($heads); ?> head(s)</small></h2>
            <div class="acts">
                <?php if ($heads_missing): ?>
                <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="tab" value="heads"><button type="submit" name="act" value="add_usual_heads" class="btn btn-secondary btn-sm"><i class="fas fa-magic"></i> Add the usual heads</button></form>
                <?php endif; ?>
                <button type="button" class="btn btn-success btn-sm" onclick="headOpen(null)"><i class="fas fa-plus"></i> Add head</button>
            </div>
        </div>
        <?php if (!$heads): ?>
        <div class="ex-empty"><i class="fas fa-tags"></i>No heads yet. "Add the usual heads" puts in the common income heads (grant, MDM cooking cost, bank interest, donation…) and expense heads (stationery, electricity, repair, exam, MDM bazar, fuel, cook…).</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Head</th><th>For</th><th>Status</th><th class="num">Order</th><th></th></tr></thead>
            <tbody>
            <?php foreach (['income' => ['Income', 'fa-arrow-down'], 'expense' => ['Expense', 'fa-arrow-up']] as $kind => [$label, $icon]):
                $rows = array_filter($heads, fn($hd) => $hd['kind'] === $kind);
                if (!$rows) continue; ?>
                <tr class="grp"><td colspan="5"><i class="fas <?php echo h($icon); ?>"></i> <?php echo h($label); ?></td></tr>
                <?php foreach ($rows as $id => $hd): ?>
                <tr class="<?php echo $hd['is_active'] ? '' : 'off'; ?>">
                    <td><b><?php echo h($hd['name']); ?></b></td>
                    <td><?php echo $hd['for_type'] ? '<span class="type"><i class="fas ' . h(ACC_TYPES[$hd['for_type']][1]) . '"></i>' . h(ACC_TYPES[$hd['for_type']][0]) . ' only</span>' : 'All accounts'; ?></td>
                    <td><?php echo $hd['is_active'] ? '<span class="chip ok">On</span>' : '<span class="chip off">Off</span>'; ?></td>
                    <td class="num"><?php echo (int)$hd['sort_order']; ?></td>
                    <td style="white-space:nowrap">
                        <button type="button" class="btn btn-warning btn-sm" onclick="headOpen(<?php echo h(json_encode($hd)); ?>)" title="Edit"><i class="fas fa-edit"></i></button>
                        <?php if (!isset($used_heads[$id])): ?>
                        <form method="post" style="display:inline" onsubmit="return confirm(<?php echo h(json_encode('Delete the head ' . $hd['name'] . '?')); ?>)"><?php echo csrf_field(); ?><input type="hidden" name="tab" value="heads"><input type="hidden" name="id" value="<?php echo (int)$id; ?>"><button type="submit" name="act" value="delete_head" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button></form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">A head with entries cannot be deleted — switch it off instead. A head "for" one type of account is offered only for those accounts.</p>
        <?php endif; ?>
    </div>

    <div class="modal" id="headModal">
        <form class="box pf" method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tab" value="heads"><input type="hidden" name="act" value="save_head"><input type="hidden" name="id" id="hId">
            <h3 id="hTitle">Add head</h3>
            <label>Name</label><input type="text" name="name" id="hName" maxlength="100" required>
            <div class="row"><div><label>Kind</label><select name="kind" id="hKind"><option value="expense">Expense — money going out</option><option value="income">Income — money coming in</option></select></div>
                <div><label>For</label><select name="for_type" id="hFor"><option value="">All accounts</option><?php foreach (ACC_TYPES as $k => [$label]): ?><option value="<?php echo h($k); ?>"><?php echo h($label); ?> only</option><?php endforeach; ?></select></div></div>
            <div class="row"><div><label>Order</label><input type="number" name="sort_order" id="hOrder" min="0" max="999" value="0"></div><div></div></div>
            <label class="chk"><input type="checkbox" name="is_active" id="hActive" value="1" checked> On — offered in entries</label>
            <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('headModal').classList.remove('open')">Cancel</button></div>
        </form>
    </div>
    <script>
    function headOpen(h) {
        var f = function (id) { return document.getElementById(id); };
        f('hTitle').textContent = h ? 'Edit ' + h.name : 'Add head';
        f('hId').value = h ? h.id : '';
        f('hName').value = h ? h.name : '';
        f('hKind').value = h ? h.kind : 'expense';
        f('hFor').value = h && h.for_type ? h.for_type : '';
        f('hOrder').value = h ? h.sort_order : 0;
        f('hActive').checked = h ? !!+h.is_active : true;
        f('headModal').classList.add('open');
        f('hName').focus();
    }
    document.getElementById('headModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
    </script>

<?php else: ?>
    <form method="post" class="pf" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="tab" value="options"><input type="hidden" name="act" value="save_options">
        <div class="opt-grid">
            <div class="card">
                <h2><i class="fas fa-money-bill-wave"></i> Fee money</h2>
                <label>A fee head with no account of its own goes to</label>
                <select name="fee_account_id"><option value="0">— choose —</option><?php foreach ($accounts as $id => $a): ?><option value="<?php echo $id; ?>"<?php echo (int)$settings['fee_account_id'] === $id ? ' selected' : ''; ?>><?php echo h($a['name']); ?></option><?php endforeach; ?></select>
                <p class="note">Each fee head can have its own account in Fee Settings; this one takes the rest.</p>
            </div>
            <div class="card">
                <h2><i class="fas fa-lock"></i> Books closed</h2>
                <label>Closed up to</label>
                <input type="date" name="lock_date" value="<?php echo h($settings['lock_date'] ?? ''); ?>" max="<?php echo date('Y-m-d', strtotime('-1 day')); ?>">
                <p class="note">After the audit, close the books: no entry can be made or cancelled on or before this date. Leave it empty to keep every date open.</p>
            </div>
            <div class="card">
                <h2><i class="fas fa-signature"></i> Signed on a voucher</h2>
                <?php foreach ($signs as $i => $s): ?><input type="text" name="sign[]" maxlength="40" value="<?php echo h($s); ?>" placeholder="<?php echo h(['Prepared by', 'Headmaster / TIC', 'Secretary / President', 'another (optional)'][$i]); ?>" style="margin-top:6px"><?php endforeach; ?>
                <p class="note">Up to four, printed left to right at the foot of a voucher.</p>
            </div>
        </div>
        <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save options</button></div>
    </form>
<?php endif; ?>
</div>
</body>
</html>

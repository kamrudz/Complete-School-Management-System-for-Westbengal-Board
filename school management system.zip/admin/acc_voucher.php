<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/acc_helper.php';

/** A voucher to print and sign: payment, receipt or contra (cash to bank, bank to cash, one account to another). Read-only. */
$e = db_get_row('SELECT e.*, a.name AS account_name, a.bank_name, a.account_no, hd.name AS head_name, cr.full_name AS made_by, ca.full_name AS cancelled_name
    FROM acc_entries e JOIN acc_accounts a ON a.id = e.account_id LEFT JOIN acc_heads hd ON hd.id = e.head_id
    LEFT JOIN admins cr ON cr.id = e.created_by LEFT JOIN admins ca ON ca.id = e.cancelled_by WHERE e.id = ?', 'i', (int)($_GET['id'] ?? 0));
if (!$e) { http_response_code(404); exit('Voucher not found.'); }
if ($e['kind'] === 'fee') { header('Location: fee_receipt.php?id=' . (int)$e['fee_receipt_id']); exit(); }
$pair = $e['pair_id'] ? db_get_row('SELECT p.*, a.name AS account_name FROM acc_entries p JOIN acc_accounts a ON a.id = p.account_id WHERE p.id = ?', 'i', (int)$e['pair_id']) : null;
[$out, $in] = $e['direction'] === 'out' ? [$e, $pair] : [$pair, $e];
$title = ['expense' => 'PAYMENT VOUCHER', 'income' => 'RECEIPT VOUCHER'][$e['kind']] ?? 'CONTRA VOUCHER';
$amount = fee_paise($e['amount']);
$cancelled = $e['status'] === 'cancelled';
$signs = array_values(array_filter(explode('|', (string)acc_settings()['signatures'])));
$where = fn(?array $x) => $x ? $x['account_name'] . ' — ' . ($x['mode'] === 'cash' ? 'cash' : 'bank') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($e['voucher_no'] . ' — ' . ucfirst(strtolower($title))); ?></title>
<style>
    @page { size: A4 portrait; margin: 10mm 12mm; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: 'Segoe UI', Arial, sans-serif; color: #111; background: #e9edf1; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .bar { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #cfd8e2; padding: 10px 16px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; font-size: 13px; color: #33475b; }
    .bar .sp { margin-left: auto; display: flex; gap: 8px; }
    .bar a, .bar button { border: 0; border-radius: 8px; padding: 8px 14px; font-size: 13px; font-weight: 600; cursor: pointer; background: #e4e9ef; color: #1f2d3a; text-decoration: none; font-family: inherit; }
    .bar .go { background: #1e3a8a; color: #fff; }
    .sheet { width: 210mm; margin: 14px auto; background: #fff; padding: 10mm 12mm; box-shadow: 0 2px 14px rgba(0,0,0,.14); }
    .v { position: relative; border: 1.3px solid #333; border-radius: 6px; padding: 6mm 7mm 5mm; overflow: hidden; }
    .v .school-head { margin-bottom: 6px !important; }
    table.meta { width: 100%; border-collapse: collapse; font-size: 12.5px; margin: 4px 0 8px; }
    table.meta td { padding: 4px 6px; border-bottom: 1px solid #e3e3e3; vertical-align: top; }
    table.meta td.l { color: #555; width: 18%; white-space: nowrap; }
    table.meta td.v2 { font-weight: 600; }
    .no { font-size: 15px; font-weight: 800; letter-spacing: .5px; }
    .amt { display: flex; align-items: center; gap: 14px; border: 1.2px solid #333; border-radius: 6px; padding: 8px 12px; margin: 6px 0; }
    .amt b { font-size: 22px; font-variant-numeric: tabular-nums; white-space: nowrap; } .amt span { font-size: 12.5px; font-style: italic; }
    .for { font-size: 12.5px; min-height: 18px; margin: 6px 0 2px; }
    .signs { display: flex; justify-content: space-between; gap: 14px; margin-top: 16mm; font-size: 11.5px; }
    .signs div { flex: 1; border-top: 1px solid #333; text-align: center; padding-top: 3px; }
    .made { font-size: 10.5px; color: #666; margin-top: 4px; }
    .void { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; pointer-events: none; }
    .void span { transform: rotate(-18deg); font-size: 60px; font-weight: 900; color: rgba(183,28,28,.16); border: 6px solid rgba(183,28,28,.16); padding: 0 22px; border-radius: 12px; letter-spacing: 6px; }
    .voidnote { font-size: 11px; color: #8e1b1b; font-weight: 700; margin-top: 4px; }
    @media screen and (max-width: 840px) { .sheet { width: auto; margin: 8px; padding: 10px; } }
    @media print { body { background: #fff; } .bar { display: none; } .sheet { margin: 0; box-shadow: none; width: auto; padding: 0; } }
</style>
</head>
<body>
<div class="bar">
    <span><b><?php echo h($e['voucher_no']); ?></b> · <?php echo h(fee_money_p($amount)); ?><?php echo $cancelled ? ' · <b style="color:#b71c1c">CANCELLED</b>' : ''; ?></span>
    <span class="sp"><a href="acc_vouchers.php">&larr; Vouchers</a><a href="acc_entry.php">New entry</a><button type="button" class="go" onclick="window.print()">&#128424; Print</button></span>
</div>
<div class="sheet">
    <div class="v">
        <?php exam_school_header($title, $e['kind'] === 'expense' || $e['kind'] === 'income' ? $e['account_name'] : ''); ?>
        <table class="meta">
            <tr><td class="l">Voucher No.</td><td class="v2 no"><?php echo h($e['voucher_no']); ?></td><td class="l">Date</td><td class="v2"><?php echo h(date('d M Y', strtotime($e['entry_date']))); ?></td></tr>
            <?php if ($e['kind'] === 'expense' || $e['kind'] === 'income'): ?>
            <tr><td class="l">Head</td><td class="v2"><?php echo h((string)$e['head_name']); ?></td><td class="l"><?php echo $e['kind'] === 'income' ? 'Received as' : 'Paid by'; ?></td><td class="v2"><?php echo h($e['reference'] ?: 'Cash'); ?></td></tr>
            <tr><td class="l"><?php echo $e['kind'] === 'income' ? 'Received from' : 'Paid to'; ?></td><td class="v2" colspan="3"><?php echo h((string)$e['party']); ?></td></tr>
            <?php if ($e['bill_no'] || $e['bill_date']): ?><tr><td class="l">Bill</td><td class="v2" colspan="3"><?php echo h(trim(($e['bill_no'] ? 'No. ' . $e['bill_no'] : '') . ($e['bill_date'] ? ' dated ' . date('d M Y', strtotime($e['bill_date'])) : ''))); ?></td></tr><?php endif; ?>
            <?php else: ?>
            <tr><td class="l">From</td><td class="v2"><?php echo h($where($out)); ?></td><td class="l">To</td><td class="v2"><?php echo h($where($in)); ?></td></tr>
            <?php if ($e['reference']): ?><tr><td class="l">Number</td><td class="v2" colspan="3"><?php echo h($e['reference']); ?></td></tr><?php endif; ?>
            <?php endif; ?>
        </table>
        <div class="amt"><b><?php echo h(fee_money_p($amount)); ?></b><span><?php echo h(fee_words($amount)); ?></span></div>
        <div class="for"><?php echo $e['description'] ? '<b>For:</b> ' . h($e['description']) : ''; ?></div>
        <?php if ($cancelled): ?><div class="voidnote">Cancelled on <?php echo h(date('d M Y', strtotime($e['cancelled_at']))); ?><?php echo $e['cancelled_name'] ? ' by ' . h($e['cancelled_name']) : ''; ?> — <?php echo h($e['cancel_reason']); ?></div><?php endif; ?>
        <div class="signs"><?php foreach ($signs as $s): ?><div><?php echo h($s); ?></div><?php endforeach; ?><?php if ($e['kind'] === 'expense'): ?><div>Received the money</div><?php endif; ?></div>
        <div class="made">Entered by <?php echo h($e['made_by'] ?: '—'); ?> on <?php echo h(date('d M Y, g:i a', strtotime($e['created_at']))); ?></div>
        <?php if ($cancelled): ?><div class="void"><span>CANCELLED</span></div><?php endif; ?>
    </div>
</div>
</body>
</html>

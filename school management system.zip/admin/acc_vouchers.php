<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/acc_helper.php';
require_once '../includes/simple_xlsx_writer.php';

/** Vouchers: every entry of the accounts — find it, print it again, see its bill, or cancel it with a reason; Excel. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$periods = acc_periods();
$period = (string)$in('period', '');
$from = (string)$in('from', ''); $to = (string)$in('to', '');
if (isset($periods[$period])) [, $from, $to] = $periods[$period];
if (!fee_valid_date($from)) $from = date('Y-m-01');
if (!fee_valid_date($to)) $to = date('Y-m-d');
if ($from > $to) [$from, $to] = [$to, $from];
$accounts = acc_accounts();
$account = (int)$in('account_id', 0); if (!isset($accounts[$account])) $account = 0;
$kind = (string)$in('kind', ''); if (!isset(ACC_KINDS[$kind])) $kind = '';
$heads = acc_heads();
$head = (int)$in('head_id', 0); if (!isset($heads[$head])) $head = 0;
$status = (string)$in('status', ''); if (!in_array($status, ['valid', 'cancelled'], true)) $status = '';
$search = trim((string)$in('search', ''));
$q = array_filter(['period' => isset($periods[$period]) ? $period : null, 'from' => isset($periods[$period]) ? null : $from, 'to' => isset($periods[$period]) ? null : $to, 'account_id' => $account ?: null,
    'kind' => $kind ?: null, 'head_id' => $head ?: null, 'status' => $status ?: null, 'search' => $search !== '' ? $search : null]);
$self = fn(array $over = []) => 'acc_vouchers.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    try {
        if (($_POST['act'] ?? '') !== 'cancel') throw new RuntimeException('Nothing to do.');
        $no = acc_cancel_entry((int)($_POST['entry_id'] ?? 0), (string)($_POST['reason'] ?? ''), $admin_id);
        $_SESSION['success'] = "$no cancelled — its money is back where it was.";
    } catch (RuntimeException $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    header('Location: ' . $self(['page' => null]));
    exit();
}

$where = ['e.entry_date BETWEEN ? AND ?']; $types = 'ss'; $params = [$from, $to];
if ($account) { $where[] = 'e.account_id = ?'; $types .= 'i'; $params[] = $account; }
if ($kind) { $where[] = 'e.kind = ?'; $types .= 's'; $params[] = $kind; }
if ($head) { $where[] = 'e.head_id = ?'; $types .= 'i'; $params[] = $head; }
if ($status) { $where[] = 'e.status = ?'; $types .= 's'; $params[] = $status; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(e.voucher_no LIKE ? OR e.party LIKE ? OR e.reference LIKE ? OR e.description LIKE ? OR e.bill_no LIKE ?)';
    $types .= 'sssss'; array_push($params, $like, $like, $like, $like, $like);
}
$from_sql = 'FROM acc_entries e JOIN acc_accounts a ON a.id = e.account_id LEFT JOIN acc_heads hd ON hd.id = e.head_id LEFT JOIN acc_accounts pa ON pa.id = (SELECT p.account_id FROM acc_entries p WHERE p.id = e.pair_id) WHERE ' . implode(' AND ', $where);
$moves = $account ? "'fee', 'income', 'expense', 'transfer'" : "'fee', 'income', 'expense'";
$sum = db_get_row("SELECT COUNT(*) AS n, COALESCE(SUM(IF(e.status = 'valid' AND e.direction = 'in' AND e.kind IN ($moves), e.amount, 0)), 0) AS money_in,
    COALESCE(SUM(IF(e.status = 'valid' AND e.direction = 'out' AND e.kind IN ($moves), e.amount, 0)), 0) AS money_out $from_sql", $types, ...$params);
$select = "SELECT e.*, a.name AS account_name, hd.name AS head_name, pa.name AS pair_account $from_sql ORDER BY e.entry_date DESC, e.id DESC";

if (!empty($_GET['export'])) {
    $rows = exam_xlsx_title('Vouchers · ' . date('d M Y', strtotime($from)) . ' to ' . date('d M Y', strtotime($to)) . ($account ? ' · ' . $accounts[$account]['name'] : ''));
    $rows[] = ['Date', 'Voucher', 'Account', 'Kind', 'Head', 'Party', 'Cash/Bank', 'Reference', 'In', 'Out', 'Bill no.', 'What for', 'Status'];
    foreach (db_get_all($select, $types, ...$params) as $r) {
        $rows[] = [date('d-m-Y', strtotime($r['entry_date'])), $r['voucher_no'] ?: (string)$r['reference'], $r['account_name'], ACC_KINDS[$r['kind']], $r['kind'] === 'fee' ? (string)$r['description'] : (string)$r['head_name'], (string)$r['party'],
            ACC_MODES[$r['mode']], (string)$r['reference'], $r['direction'] === 'in' ? round(fee_paise($r['amount']) / 100, 2) : '', $r['direction'] === 'out' ? round(fee_paise($r['amount']) / 100, 2) : '',
            (string)$r['bill_no'], $r['kind'] === 'fee' ? '' : (string)$r['description'], $r['status'] === 'valid' ? 'Valid' : 'Cancelled — ' . $r['cancel_reason']];
    }
    SimpleXLSXWriter::download('Vouchers_' . $from . '_to_' . $to . '.xlsx', $rows, 'Vouchers', exam_xlsx_opts(13, 26));
    exit();
}

$per = 50;
$total = (int)$sum['n'];
$pages = max(1, (int)ceil($total / $per));
$page = min($pages, max(1, (int)($_GET['page'] ?? 1)));
$list = $total ? db_get_all($select . ' LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $types, ...$params) : [];
$range = date('d M Y', strtotime($from)) . ($from !== $to ? ' to ' . date('d M Y', strtotime($to)) : '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vouchers</title>
<?php exam_styles('acc'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tr.void td { color: #98a6b5; } .ex-table tr.void td.money { text-decoration: line-through; }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; }
    .ex-table .vno { font-weight: 700; white-space: nowrap; }
    .in { color: #1b7a3a; font-weight: 700; } .out { color: #b71c1c; font-weight: 700; }
    .kind { font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; background: var(--ex-soft); color: var(--ex-dark); border: 1px solid var(--ex-border); white-space: nowrap; }
    .pg { display: flex; gap: 4px; justify-content: center; margin-top: 12px; flex-wrap: wrap; }
    .pg a, .pg span { min-width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; background: #fff; color: var(--ex-dark); text-decoration: none; font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg span { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Vouchers', 'Every entry of the accounts — find it, print it again, see its bill, or cancel it with a reason', 'fa-file-invoice-dollar',
        ['acc_entry.php' => '<i class="fas fa-pen"></i> New entry', $self(['export' => 1, 'page' => null]) => '<i class="fas fa-file-excel"></i> Excel']); ?>
    <?php acc_tabs('acc_vouchers.php'); exam_flash(); ?>

    <form method="get" class="card pick">
        <div><label>Period</label><select name="period" onchange="this.form.submit()"><option value="">Dates below</option><?php foreach ($periods as $k => [$label]): ?><option value="<?php echo h($k); ?>"<?php echo $k === $period ? ' selected' : ''; ?>><?php echo h($label); ?></option><?php endforeach; ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div>
        <div><label>Account</label><select name="account_id"><option value="0">All accounts</option><?php foreach ($accounts as $id => $a): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $account ? ' selected' : ''; ?>><?php echo h($a['name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Kind</label><select name="kind"><option value="">Any</option><?php echo exam_options(ACC_KINDS, $kind); ?></select></div>
        <div><label>Head</label><select name="head_id"><option value="0">Any</option><?php foreach ($heads as $id => $hd): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $head ? ' selected' : ''; ?>><?php echo h(($hd['kind'] === 'income' ? 'In: ' : 'Out: ') . $hd['name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Status</label><select name="status"><option value="">Any</option><option value="valid"<?php echo $status === 'valid' ? ' selected' : ''; ?>>Valid</option><option value="cancelled"<?php echo $status === 'cancelled' ? ' selected' : ''; ?>>Cancelled</option></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Voucher, party, bill, cheque…"></div>
        <button type="submit" class="btn btn-primary" onclick="this.form.period.value = ''"><i class="fas fa-filter"></i> Show</button>
    </form>

    <div class="sum">
        <div><b class="in"><?php echo h(fee_money($sum['money_in'])); ?></b><small>came in — fees and income<?php echo $account ? ', transfers in' : ''; ?> · <?php echo h($range); ?></small></div>
        <div><b class="out"><?php echo h(fee_money($sum['money_out'])); ?></b><small>went out — expenses<?php echo $account ? ', transfers out' : ''; ?></small></div>
        <div><b><?php echo (int)$sum['n']; ?></b><small>entries (cancelled ones too)</small></div>
    </div>

    <?php if (!$list): ?>
    <div class="ex-empty"><i class="fas fa-file-invoice-dollar"></i>No entries in <?php echo h($range); ?><?php echo $account || $kind || $head || $status || $search !== '' ? ' for this choice' : ''; ?>.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Date</th><th>Voucher</th><th>Account</th><th>What</th><th>Party</th><th>Cash / Bank</th><th class="money">In</th><th class="money">Out</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($list as $r): $void = $r['status'] !== 'valid'; ?>
            <tr class="<?php echo $void ? 'void' : ''; ?>">
                <td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($r['entry_date']))); ?></td>
                <td class="vno"><?php echo $r['kind'] === 'fee' ? '<span title="Fee receipt">' . h($r['reference']) . '</span>' : h($r['voucher_no']); ?><?php echo $void ? ' ' . fee_state_chip('cancelled') : ''; ?></td>
                <td><?php echo h($r['account_name']); ?><?php echo $r['pair_account'] && $r['pair_account'] !== $r['account_name'] ? '<small>' . ($r['direction'] === 'out' ? 'to ' : 'from ') . h($r['pair_account']) . '</small>' : ''; ?></td>
                <td><span class="kind"><?php echo h(ACC_KINDS[$r['kind']]); ?></span> <?php echo h($r['kind'] === 'fee' ? (string)$r['description'] : (string)$r['head_name']); ?>
                    <?php if ($r['kind'] !== 'fee' && $r['description']): ?><small><?php echo h($r['description']); ?></small><?php endif; ?>
                    <?php if ($void && $r['cancel_reason']): ?><small>Cancelled: <?php echo h($r['cancel_reason']); ?></small><?php endif; ?></td>
                <td><?php echo h((string)$r['party']); ?><?php echo $r['bill_no'] ? '<small>Bill ' . h($r['bill_no']) . ($r['bill_date'] ? ', ' . h(date('d M Y', strtotime($r['bill_date']))) : '') . '</small>' : ''; ?></td>
                <td><?php echo h(ACC_MODES[$r['mode']]); ?><?php echo $r['reference'] && $r['kind'] !== 'fee' ? '<small>' . h($r['reference']) . '</small>' : ''; ?></td>
                <td class="money"><?php echo $r['direction'] === 'in' ? '<span class="in">' . h(fee_money($r['amount'])) . '</span>' : ''; ?></td>
                <td class="money"><?php echo $r['direction'] === 'out' ? '<span class="out">' . h(fee_money($r['amount'])) . '</span>' : ''; ?></td>
                <td style="white-space:nowrap">
                    <?php if ($r['attachment']): ?><a class="btn btn-secondary btn-sm" target="_blank" href="<?php echo h('acc_bill.php?id=' . (int)$r['id']); ?>" title="See the bill"><i class="fas fa-paperclip"></i></a><?php endif; ?>
                    <?php if ($r['kind'] === 'fee'): ?><a class="btn btn-secondary btn-sm" target="_blank" href="<?php echo h('fee_receipt.php?id=' . (int)$r['fee_receipt_id']); ?>" title="The fee receipt"><i class="fas fa-receipt"></i></a>
                    <?php else: ?><a class="btn btn-secondary btn-sm" target="_blank" href="<?php echo h('acc_voucher.php?id=' . (int)$r['id']); ?>" title="Print the voucher"><i class="fas fa-print"></i></a>
                    <?php if (!$void): ?><button type="button" class="btn btn-danger btn-sm" title="Cancel" onclick="cancelEntry(<?php echo (int)$r['id']; ?>, <?php echo h(json_encode($r['voucher_no'] . ' — ' . fee_money($r['amount']))); ?>)"><i class="fas fa-ban"></i></button><?php endif; ?>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1): ?>
        <div class="pg"><?php for ($i = 1; $i <= $pages; $i++): ?><?php echo $i === $page ? '<span>' . $i . '</span>' : '<a href="' . h($self(['page' => $i])) . '">' . $i . '</a>'; ?><?php endfor; ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<div class="modal" id="cancelModal">
    <form method="post" class="box pf" action="<?php echo h($self(['page' => null])); ?>">
        <?php echo csrf_field(); ?><input type="hidden" name="act" value="cancel"><input type="hidden" name="entry_id" id="cId">
        <h3 style="margin:0 0 6px;color:var(--ex-dark)">Cancel <span id="cWhat"></span></h3>
        <p class="note" style="margin:0">The voucher stays in the books, marked cancelled; its money goes back where it was. A deposit or transfer is cancelled on both sides.</p>
        <label>Reason</label><input type="text" name="reason" maxlength="255" required placeholder="e.g. entered twice">
        <div class="acts"><button type="submit" class="btn btn-danger"><i class="fas fa-ban"></i> Cancel the voucher</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('cancelModal').classList.remove('open')">Keep it</button></div>
    </form>
</div>
<script>
function cancelEntry(id, what) {
    document.getElementById('cId').value = id;
    document.getElementById('cWhat').textContent = what;
    document.getElementById('cancelModal').classList.add('open');
}
document.getElementById('cancelModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

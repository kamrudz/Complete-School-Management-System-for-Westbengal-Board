<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

// Exactly one session is Active: the chosen one becomes Active and every other one Inactive, in one statement.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: sessions.php'); exit; }
verify_csrf_or_die();

$id = (int)($_POST['id'] ?? 0);
$session = $id > 0 ? db_get_row('SELECT session_name FROM academic_sessions WHERE id = ?', 'i', $id) : null;
if (!$session) {
    $_SESSION['error'] = 'Academic Session not found.';
    header('Location: sessions.php'); exit;
}

db_execute("UPDATE academic_sessions SET status = IF(id = ?, 'Active', 'Inactive')", 'i', $id);
log_action((int)($_SESSION['admin_id'] ?? 0), 'SESSION_ACTIVATED', 'academic_sessions', $id, null, ['session_name' => $session['session_name']]);
$_SESSION['success'] = "Session {$session['session_name']} is now the active session.";
header('Location: sessions.php'); exit;

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $publisher = trim($_POST['publisher'] ?? '');
    $isbn = trim($_POST['isbn'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $edition = trim($_POST['edition'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $shelf_location = trim($_POST['shelf_location'] ?? '');
    $copies = max(1, (int)($_POST['copies'] ?? 1));

    if ($title === '') {
        $_SESSION['error'] = "Book title is required!";
        header("Location: add_book.php");
        exit();
    }

    mysqli_begin_transaction($conn);
    try {
        $stmt = mysqli_prepare($conn, "INSERT INTO library_books (title, author, publisher, isbn, category_id, edition, price, shelf_location) VALUES (?,?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "ssssisds", $title, $author, $publisher, $isbn, $category_id, $edition, $price, $shelf_location);
        mysqli_stmt_execute($stmt);
        $book_id = mysqli_insert_id($conn);

        $copy_stmt = mysqli_prepare($conn, "INSERT INTO library_book_copies (book_id, accession_no, status, added_date) VALUES (?,?,'Available', CURDATE())");
        $generated = [];
        for ($i = 0; $i < $copies; $i++) {
            $acc_no = next_accession_no($conn); // Re-checks the fresh MAX each time, so calling it repeatedly in a loop never duplicates
            mysqli_stmt_bind_param($copy_stmt, "is", $book_id, $acc_no);
            if (!mysqli_stmt_execute($copy_stmt)) {
                // Extremely rare: two admins saved a book in the same instant and both
                // landed on the same accession number. The UNIQUE key on accession_no
                // rejects the duplicate at the DB level — we throw here so the whole
                // book (title + all copies) rolls back cleanly and the admin just
                // retries, instead of silently reporting success for a copy that
                // was never actually saved.
                throw new Exception('Accession number collision — please retry.');
            }
            $generated[] = $acc_no;
        }
        mysqli_commit($conn);
        $_SESSION['success'] = "\"$title\" added with $copies " . ($copies == 1 ? 'copy' : 'copies') . " — Accession No: " . implode(', ', $generated);
        header("Location: books.php");
        exit();
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Something went wrong, please try again.";
        header("Location: add_book.php");
        exit();
    }
}

$categories = mysqli_query($conn, "SELECT * FROM library_categories ORDER BY category_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 700px; }
.form-row { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 16px; }
.form-group { flex: 1; min-width: 200px; }
.form-group label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-group input, .form-group select { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-error { background: #f8d7da; color: #842029; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-book-medical"></i> Add New Book</div>
        <a href="books.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Book List</a>
    </div>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group" style="flex-basis:100%;">
                    <label>Book Title *</label>
                    <input type="text" name="title" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Author</label><input type="text" name="author"></div>
                <div class="form-group"><label>Publisher</label><input type="text" name="publisher"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>ISBN</label><input type="text" name="isbn"></div>
                <div class="form-group"><label>Edition</label><input type="text" name="edition"></div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Category</label>
                    <select name="category_id">
                        <option value="">-- Select --</option>
                        <?php while ($c = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['category_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group"><label>Shelf Location</label><input type="text" name="shelf_location" placeholder="e.g. Rack-3, Shelf-B"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Price (₹) — this is the fine amount if lost</label><input type="number" step="0.01" min="0" name="price" required></div>
                <div class="form-group"><label>Number of Copies *</label><input type="number" min="1" name="copies" value="1" required></div>
            </div>
            <p style="font-size:12px; color:#6c7a8a; margin-bottom:15px;"><i class="fas fa-info-circle"></i> A separate Accession No is auto-generated for each copy (in the style LIB-<?php echo date('Y'); ?>-001).</p>
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save Book</button>
        </form>
    </div>
</div>
</body>
</html>

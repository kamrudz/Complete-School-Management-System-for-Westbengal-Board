<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/class_helper.php';
require_once '../includes/logger.php';

if (isset($_POST['save_class'])) {
    verify_csrf_or_die();
    $name = class_name_normalise($_POST['class_name'] ?? '');
    $stage = (string)($_POST['stage'] ?? '');
    $board = !empty($_POST['board_exam']) ? 1 : 0;
    $error = class_name_error($name) ?? (class_stage_valid($stage) ? null : 'Choose the stage this class belongs to.');
    if ($error === null) {
        try {
            $id = db_insert('classes', ['class_name' => $name, 'sort_order' => class_sort_order($name), 'stage' => $stage, 'board_exam' => $board]);
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1062) throw $e;   // the unique name is the guard against doubles
            $error = "Class $name already exists.";
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header('Location: add_class.php'); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'CLASS_ADDED', 'classes', (int)$id, null, ['class_name' => $name, 'stage' => $stage, 'board_exam' => $board]);
    $_SESSION['success'] = "Class $name added.";
    header('Location: classes.php'); exit;
}

$available = class_roman_available();
$stage_of = array_combine(class_roman_list(), array_map('class_stage_of_name', class_roman_list()));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:760px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-plus-circle"></i> Add New Class</div>
        <a href="classes.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Classes</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <?php if (!$available): ?>
    <div class="empty-state"><i class="fas fa-check-circle"></i><h3>All classes are added</h3><p>I থেকে XII — সব ক্লাস ইতিমধ্যে যোগ করা আছে।</p></div>
    <?php else: ?>
    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label><i class="fas fa-chalkboard"></i> Class <span class="required">*</span></label>
            <select name="class_name" id="class_name" required autofocus>
                <option value="">— select —</option>
                <?php foreach ($available as $r): ?><option value="<?php echo $r; ?>"><?php echo $r; ?></option><?php endforeach; ?>
            </select>
            <div class="form-hint">শুধু Roman সংখ্যা (I–XII)। যেগুলো ইতিমধ্যে যোগ হয়েছে সেগুলো তালিকায় নেই। সিরিয়াল নিজে থেকে ঠিক হবে (V=৫, XII=১২)।</div>
        </div>
        <div class="form-group">
            <label><i class="fas fa-layer-group"></i> Stage <span class="required">*</span></label>
            <select name="stage" id="stage" required>
                <?php foreach (class_stages() as $k => $s): ?><option value="<?php echo $k; ?>"><?php echo htmlspecialchars($s['label'] . ' (' . $s['classes'] . ')', ENT_QUOTES, 'UTF-8'); ?></option><?php endforeach; ?>
            </select>
            <div class="form-hint">এটাই ঠিক করে দেয় class-টা কোন নিয়মে চলবে — grade band, project/formative কলাম, কোন module-এ পড়বে। ক্লাস বাছলে নিজে থেকে বসে যাবে, দরকার হলে বদলে দিন।</div>
        </div>
        <div class="form-group">
            <label style="display:flex;align-items:center;gap:8px;font-weight:400"><input type="checkbox" name="board_exam" value="1" id="board" style="width:auto"> এই class-এর পরীক্ষা <b>board</b> নেয়, স্কুল নয় (যেমন Class XII)</label>
            <div class="form-hint">টিক দিলে স্কুলের পরীক্ষা/marks entry ঐ class-এ থাকবে না — শুধু subject combination ও registration থাকবে।</div>
        </div>
        <div class="btn-group">
            <button type="submit" name="save_class" class="btn btn-success"><i class="fas fa-save"></i> Add Class</button>
            <a href="classes.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
    <script>
    // choosing the class suggests its usual stage (and the board tick for XII); both can still be changed
    (function () {
        var stageOf = <?php echo json_encode($stage_of); ?>, cls = document.getElementById('class_name');
        cls.addEventListener('change', function () {
            if (stageOf[cls.value]) document.getElementById('stage').value = stageOf[cls.value];
            document.getElementById('board').checked = cls.value === 'XII';
        });
    })();
    </script>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Photographs for the gallery. Several at a time, because an event is never one picture, and each one is
 * made smaller as it is saved so the website stays quick.
 */
function compress_gallery_image($source_path, $quality = 75, $max_width = 1200, $max_height = 900) {
    $info = @getimagesize($source_path);
    if (!$info) return false;

    [$width, $height, $type] = $info;
    if ($width <= $max_width && $height <= $max_height) return true;

    $ratio = min($max_width / $width, $max_height / $height, 1);
    $new_width = max(1, (int)round($width * $ratio));
    $new_height = max(1, (int)round($height * $ratio));

    switch ($type) {
        case IMAGETYPE_JPEG: $src = @imagecreatefromjpeg($source_path); break;
        case IMAGETYPE_PNG:  $src = @imagecreatefrompng($source_path); break;
        case IMAGETYPE_GIF:  $src = @imagecreatefromgif($source_path); break;
        case IMAGETYPE_WEBP: $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($source_path) : false; break;
        default: return false;
    }
    if (!$src) return false;

    $dst = imagecreatetruecolor($new_width, $new_height);
    if (in_array($type, [IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefilledrectangle($dst, 0, 0, $new_width, $new_height, $transparent);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    imagedestroy($src);

    switch ($type) {
        case IMAGETYPE_JPEG: $ok = imagejpeg($dst, $source_path, $quality); break;
        case IMAGETYPE_PNG:  $ok = imagepng($dst, $source_path, 7); break;
        case IMAGETYPE_GIF:  $ok = imagegif($dst, $source_path); break;
        case IMAGETYPE_WEBP: $ok = function_exists('imagewebp') ? imagewebp($dst, $source_path, $quality) : false; break;
        default: $ok = false;
    }
    imagedestroy($dst);
    return (bool)$ok;
}
$total = (int)(db_get_row('SELECT COUNT(*) n FROM gallery')['n'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_photo'])) {
    verify_csrf_or_die();
    $title = trim((string)($_POST['title'] ?? ''));
    $files = $_FILES['photo'] ?? [];
    $count = is_array($files['name'] ?? null) ? count($files['name']) : 0;

    if ($title === '') { $_SESSION['error'] = 'Give the photographs a title — the same one is used for all of them.'; header('Location: add_gallery.php'); exit(); }
    if (!$count || ($count === 1 && ($files['error'][0] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE)) {
        $_SESSION['error'] = 'Choose at least one photograph.';
        header('Location: add_gallery.php');
        exit();
    }

    $saved = 0;
    $failed = [];
    for ($i = 0; $i < $count; $i++) {
        $one = ['name' => $files['name'][$i], 'type' => $files['type'][$i], 'tmp_name' => $files['tmp_name'][$i],
            'error' => $files['error'][$i], 'size' => $files['size'][$i]];
        if ($one['error'] === UPLOAD_ERR_NO_FILE) continue;
        $upload = safe_uploaded_file($one, '../uploads/gallery/',
            ['jpg', 'jpeg', 'png', 'gif', 'webp'], ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], 'gallery_', 5 * 1024 * 1024);
        if (!$upload['ok'] || $upload['filename'] === '') { $failed[] = $one['name'] . ' — ' . ($upload['error'] ?: 'not a photograph'); continue; }
        compress_gallery_image('../uploads/gallery/' . $upload['filename'], 75, 1200, 900);
        $one_title = $count > 1 ? mb_substr($title, 0, 190) . ' ' . ($saved + 1) : mb_substr($title, 0, 200);
        if (db_execute('INSERT INTO gallery (title, photo) VALUES (?, ?)', 'ss', $one_title, $upload['filename']) === false) {
            app_unlink_upload('../uploads/gallery/', $upload['filename']);
            $failed[] = $one['name'] . ' — could not be saved';
            continue;
        }
        $saved++;
    }

    if ($saved) $_SESSION['success'] = $saved . ' photograph(s) added.' . ($failed ? ' ' . count($failed) . ' could not be taken.' : '');
    if ($failed && !$saved) $_SESSION['error'] = 'Nothing was added. ' . implode(' · ', array_slice($failed, 0, 3));
    elseif ($failed) $_SESSION['error'] = implode(' · ', array_slice($failed, 0, 3));
    header('Location: ' . ($saved ? 'gallery.php' : 'add_gallery.php'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add photos</title>
<?php exam_styles('web'); ?>
<style>
    .drop { border: 2px dashed var(--ex-border); border-radius: 12px; padding: 22px; text-align: center; background: var(--ex-soft); cursor: pointer; }
    .drop i { font-size: 26px; color: var(--ex-light); display: block; margin-bottom: 8px; }
    .drop input { display: none; }
    .picked { margin-top: 10px; font-size: 13px; color: #41566c; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Add photos', 'Several at a time — each one is made smaller as it is saved', 'fa-images',
        ['gallery.php' => '<i class="fas fa-arrow-left"></i> All photographs']); ?>
    <?php exam_tabs('gallery.php', WEB_PAGES); exam_flash(); ?>

    <form method="post" class="card pf" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>Title</label>
        <input type="text" name="title" maxlength="200" required placeholder="e.g. Annual Sports 2026">
        <p class="note">Choosing several photographs numbers them: "Annual Sports 2026 1", "… 2", and so on. You can correct any title afterwards.</p>

        <label>Photographs</label>
        <label class="drop" for="pick">
            <i class="fas fa-cloud-arrow-up"></i>
            Click to choose photographs
            <input type="file" id="pick" name="photo[]" accept="image/*" multiple required>
            <div class="picked" id="picked">JPG, PNG, GIF or WEBP · up to 5 MB each</div>
        </label>

        <div class="acts">
            <button type="submit" name="save_photo" class="btn btn-success"><i class="fas fa-upload"></i> Add them</button>
            <a href="gallery.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
    <p class="note" style="text-align:center"><?php echo number_format($total); ?> photograph(s) in the gallery.</p>
</div>
<script>
document.getElementById('pick').addEventListener('change', function () {
    var n = this.files.length;
    document.getElementById('picked').textContent = n ? n + ' photograph(s) chosen' : 'JPG, PNG, GIF or WEBP · up to 5 MB each';
});
</script>
</body>
</html>

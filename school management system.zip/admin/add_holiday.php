<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * One form for a holiday, new or already listed. edit_holiday.php forwards here with its id.
 * The list decides which days attendance is taken on, so a day already covered is pointed out and has to
 * be allowed on purpose before it is saved twice.
 */
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$holiday = $id ? db_get_row('SELECT * FROM holidays WHERE id = ?', 'i', $id) : null;
if ($id && !$holiday) { $_SESSION['error'] = 'That holiday is gone — look at the list again.'; header('Location: holidays.php'); exit(); }

$old = $holiday ?: ['holiday_name' => '', 'holiday_type' => 'public', 'description' => '', 'is_long_vacation' => 0,
    'holiday_date' => date('Y-m-d'), 'start_date' => '', 'end_date' => ''];
if (isset($_SESSION['holiday_old'])) { $old = $_SESSION['holiday_old'] + $old; unset($_SESSION['holiday_old']); }
$clash_shown = !empty($_SESSION['holiday_clash']);
unset($_SESSION['holiday_clash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_holiday'])) {
    verify_csrf_or_die();
    $name = trim((string)($_POST['holiday_name'] ?? ''));
    $type = (string)($_POST['holiday_type'] ?? '');
    $description = trim((string)($_POST['description'] ?? ''));
    $long = !empty($_POST['is_long_vacation']) ? 1 : 0;
    $holiday_date = trim((string)($_POST['holiday_date'] ?? ''));
    $start_date = trim((string)($_POST['start_date'] ?? ''));
    $end_date = trim((string)($_POST['end_date'] ?? ''));
    $_SESSION['holiday_old'] = ['holiday_name' => $name, 'holiday_type' => $type, 'description' => $description,
        'is_long_vacation' => $long, 'holiday_date' => $holiday_date, 'start_date' => $start_date, 'end_date' => $end_date];
    $back = 'Location: add_holiday.php' . ($id ? '?id=' . $id : '');
    $error = '';

    if ($name === '') $error = 'Give the holiday a name.';
    elseif (mb_strlen($name) > 200) $error = 'The name cannot be longer than 200 letters.';
    elseif (!app_valid_holiday_type($type)) $error = 'Choose what kind of holiday it is.';
    elseif ($long) {
        if (!app_valid_date($start_date) || !app_valid_date($end_date)) $error = 'Give both the first and the last day of the vacation.';
        elseif ($end_date < $start_date) $error = 'The last day cannot come before the first day.';
        elseif ((int)((new DateTime($start_date))->diff(new DateTime($end_date))->days) > 365) $error = 'A vacation longer than a year is almost certainly a mistake.';
    } elseif (!app_valid_date($holiday_date)) $error = 'Give the date of the holiday.';

    if ($error === '') {
        [$from, $to] = $long ? [$start_date, $end_date] : [$holiday_date, $holiday_date];
        $overlaps = holiday_overlaps($from, $to, $id);
        if ($overlaps && empty($_POST['allow_overlap'])) {
            $names = array_slice(array_column($overlaps, 'holiday_name'), 0, 3);
            $error = 'These days are already covered by ' . implode(', ', $names) . '. Tick the box below if both really belong on the list.';
            $_SESSION['holiday_clash'] = 1;
        }
    }

    if ($error !== '') {
        $_SESSION['error'] = $error;
        header($back);
        exit();
    }

    unset($_SESSION['holiday_old']);
    if ($long) {
        $total = (int)((new DateTime($start_date))->diff(new DateTime($end_date))->days) + 1;
        $data = ['holiday_name' => $name, 'holiday_date' => $start_date, 'start_date' => $start_date, 'end_date' => $end_date,
            'holiday_type' => $type, 'description' => $description, 'is_long_vacation' => 1, 'total_days' => $total];
        $sql = 'holiday_name = ?, holiday_date = ?, start_date = ?, end_date = ?, holiday_type = ?, description = ?, is_long_vacation = 1, total_days = ?';
        $bind = ['ssssssi', $name, $start_date, $start_date, $end_date, $type, $description, $total];
    } else {
        $data = ['holiday_name' => $name, 'holiday_date' => $holiday_date, 'start_date' => null, 'end_date' => null,
            'holiday_type' => $type, 'description' => $description, 'is_long_vacation' => 0, 'total_days' => 1];
        $sql = 'holiday_name = ?, holiday_date = ?, start_date = NULL, end_date = NULL, holiday_type = ?, description = ?, is_long_vacation = 0, total_days = 1';
        $bind = ['ssss', $name, $holiday_date, $type, $description];
    }

    if ($id) {
        $bind[] = $id;
        $bind[0] .= 'i';
        $done = db_execute("UPDATE holidays SET $sql WHERE id = ?", ...$bind);
    } else {
        $done = db_insert('holidays', $data);
    }

    if ($done === false) { $_SESSION['error'] = 'The holiday could not be saved. Try again.'; header($back); exit(); }
    $when = $long ? date('d M Y', strtotime($start_date)) . ' to ' . date('d M Y', strtotime($end_date)) : date('d M Y', strtotime($holiday_date));
    $_SESSION['success'] = $name . ' — ' . $when . ' — is on the list. Attendance is not taken on those days.';
    header('Location: holidays.php?year=' . (int)date('Y', strtotime($long ? $start_date : $holiday_date)));
    exit();
}

$is_long = !empty($old['is_long_vacation']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $id ? 'Change the holiday' : 'Add a holiday'; ?></title>
<?php exam_styles('web'); ?>
<style>
    .pf textarea { height: auto; min-height: 90px; font-family: inherit; }
    .pf .two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 680px) { .pf .two { grid-template-columns: 1fr; } }
    .when-box { border: 1px solid #dfe7ef; border-radius: 10px; padding: 12px 14px; margin-top: 10px; background: #fcfdfe; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner($id ? 'Change the holiday' : 'Add a holiday', 'Attendance is never taken on a day that is on this list', 'fa-umbrella-beach',
        ['holidays.php' => '<i class="fas fa-arrow-left"></i> The holiday list']); ?>
    <?php exam_tabs('holidays.php', WEB_PAGES); exam_flash(); ?>

    <form method="post" class="card pf" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$id; ?>">
        <label>Name</label>
        <input type="text" name="holiday_name" maxlength="200" required value="<?php echo h($old['holiday_name']); ?>" placeholder="e.g. Durga Puja">

        <div class="two">
            <div>
                <label>What kind</label>
                <select name="holiday_type">
                    <?php foreach (HOLIDAY_TYPES as $k => [$label]): ?>
                        <option value="<?php echo h($k); ?>"<?php echo $old['holiday_type'] === $k ? ' selected' : ''; ?>><?php echo h($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>How long</label>
                <label class="chk" style="margin-top:8px"><input type="checkbox" name="is_long_vacation" id="longBox" value="1"<?php echo $is_long ? ' checked' : ''; ?>> More than one day (a vacation)</label>
            </div>
        </div>

        <div class="when-box" id="oneDay" style="<?php echo $is_long ? 'display:none' : ''; ?>">
            <label>The day</label>
            <input type="date" name="holiday_date" value="<?php echo h($old['holiday_date'] ?: date('Y-m-d')); ?>">
        </div>

        <div class="when-box two" id="manyDays" style="<?php echo $is_long ? '' : 'display:none'; ?>">
            <div><label>First day</label><input type="date" name="start_date" value="<?php echo h($old['start_date']); ?>"></div>
            <div><label>Last day</label><input type="date" name="end_date" value="<?php echo h($old['end_date']); ?>"></div>
        </div>

        <label>Note <small style="text-transform:none;font-weight:400">optional</small></label>
        <textarea name="description" rows="2" placeholder="Anything worth remembering about this holiday"><?php echo h($old['description']); ?></textarea>

        <?php if ($clash_shown): ?>
        <label class="chk"><input type="checkbox" name="allow_overlap" value="1"> Yes, keep both — I know these days are already on the list</label>
        <?php endif; ?>

        <div class="acts">
            <button type="submit" name="save_holiday" class="btn btn-success"><i class="fas fa-save"></i> <?php echo $id ? 'Save the changes' : 'Add it to the list'; ?></button>
            <a href="holidays.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<script>
(function () {
    var box = document.getElementById('longBox'), one = document.getElementById('oneDay'), many = document.getElementById('manyDays');
    function show() { one.style.display = box.checked ? 'none' : ''; many.style.display = box.checked ? '' : 'none'; }
    box.addEventListener('change', show);
    show();
})();
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/** One form for a notice, new or already written. edit_notice.php forwards here with its id. */
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$notice = $id ? db_get_row('SELECT * FROM notices WHERE id = ?', 'i', $id) : null;
if ($id && !$notice) { $_SESSION['error'] = 'That notice is gone — look at the list again.'; header('Location: notices.php'); exit(); }

$old = $notice ?: ['notice_title' => '', 'notice_details' => '', 'publish_date' => date('Y-m-d'), 'status' => 'Published', 'attachment' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $title = trim((string)($_POST['notice_title'] ?? ''));
    $details = trim((string)($_POST['notice_details'] ?? ''));
    $date = trim((string)($_POST['publish_date'] ?? ''));
    $status = (string)($_POST['status'] ?? 'Published');
    if (!in_array($status, ['Draft', 'Published'], true)) $status = 'Published';
    $old = ['notice_title' => $title, 'notice_details' => $details, 'publish_date' => $date, 'status' => $status, 'attachment' => $notice['attachment'] ?? ''];
    $error = '';

    if ($title === '') $error = 'Give the notice a title.';
    elseif (mb_strlen($title) > 255) $error = 'The title cannot be longer than 255 letters.';
    elseif (!app_valid_date($date)) $error = 'Give the date the notice is for.';
    elseif ($details === '' && empty($_FILES['attachment']['name']) && empty($notice['attachment'])) $error = 'Write the notice, or attach a file with it.';

    $upload = ['ok' => true, 'filename' => ''];
    if ($error === '' && !empty($_FILES['attachment']['name'])) {
        $upload = safe_uploaded_file($_FILES['attachment'], '../uploads/notices/',
            ['pdf', 'jpg', 'jpeg', 'png'], ['application/pdf', 'image/jpeg', 'image/png'], 'notice_', 5 * 1024 * 1024);
        if (!$upload['ok']) $error = 'The file could not be taken: ' . $upload['error'];
    }

    if ($error !== '') {
        $_SESSION['error'] = $error;
    } else {
        $attachment = $upload['filename'] !== '' ? $upload['filename'] : (string)($notice['attachment'] ?? '');
        if ($id) {
            $done = db_execute('UPDATE notices SET notice_title = ?, notice_details = ?, publish_date = ?, status = ?, attachment = ? WHERE id = ?',
                'sssssi', $title, $details, $date, $status, $attachment, $id);
        } else {
            $done = db_execute('INSERT INTO notices (notice_title, notice_details, publish_date, status, attachment) VALUES (?, ?, ?, ?, ?)',
                'sssss', $title, $details, $date, $status, $attachment);
        }
        if ($done === false) {
            if ($upload['filename'] !== '') app_unlink_upload('../uploads/notices/', $upload['filename']);
            $_SESSION['error'] = 'The notice could not be saved. Try again.';
        } else {
            if ($upload['filename'] !== '' && !empty($notice['attachment'])) app_unlink_upload('../uploads/notices/', $notice['attachment']);
            $when = $status === 'Draft' ? 'kept as a draft'
                : ($date > date('Y-m-d') ? 'saved — it goes on the website on ' . date('d M Y', strtotime($date)) : 'saved and is on the website now');
            $_SESSION['success'] = $title . ' ' . $when . '.';
            header('Location: notices.php');
            exit();
        }
    }
    header('Location: ' . ($id ? 'add_notice.php?id=' . $id : 'add_notice.php'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $id ? 'Change the notice' : 'Write a notice'; ?></title>
<?php exam_styles('web'); ?>
<style>
    .pf textarea { height: auto; min-height: 170px; font-family: inherit; line-height: 1.6; }
    .pf .two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 680px) { .pf .two { grid-template-columns: 1fr; } }
    .have { display: flex; align-items: center; gap: 8px; font-size: 13px; margin-top: 6px; color: #41566c; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner($id ? 'Change the notice' : 'Write a notice', 'It reaches the website on its date, once it is published', 'fa-bullhorn',
        ['notices.php' => '<i class="fas fa-arrow-left"></i> All notices']); ?>
    <?php exam_tabs('notices.php', WEB_PAGES); exam_flash(); ?>

    <form method="post" class="card pf" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$id; ?>">
        <label>Title</label>
        <input type="text" name="notice_title" maxlength="255" required value="<?php echo h($old['notice_title']); ?>" placeholder="e.g. Summer vacation from 5 May">

        <label>The notice</label>
        <textarea name="notice_details" rows="8" placeholder="What everyone should know. Write it the way it should be read."><?php echo h($old['notice_details']); ?></textarea>

        <div class="two">
            <div>
                <label>Date of the notice</label>
                <input type="date" name="publish_date" required value="<?php echo h($old['publish_date']); ?>">
                <p class="note">A later date keeps it off the website until that day.</p>
            </div>
            <div>
                <label>On the website</label>
                <select name="status">
                    <option value="Published"<?php echo $old['status'] === 'Published' ? ' selected' : ''; ?>>Published — show it</option>
                    <option value="Draft"<?php echo $old['status'] === 'Draft' ? ' selected' : ''; ?>>Draft — keep it to myself</option>
                </select>
                <p class="note">A draft stays here until you publish it.</p>
            </div>
        </div>

        <label>File with the notice <small style="text-transform:none;font-weight:400">optional · PDF or picture, up to 5 MB</small></label>
        <input type="file" name="attachment" accept=".pdf,.jpg,.jpeg,.png">
        <?php if (!empty($old['attachment'])): ?>
            <div class="have"><i class="fas fa-paperclip"></i>
                <a href="<?php echo h('../uploads/notices/' . $old['attachment']); ?>" target="_blank">The file already attached</a>
                — choosing another one replaces it.</div>
        <?php endif; ?>

        <div class="acts">
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?php echo $id ? 'Save the changes' : 'Save the notice'; ?></button>
            <a href="notices.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
</body>
</html>

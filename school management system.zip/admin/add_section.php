<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/section_helper.php';
require_once '../includes/logger.php';

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');

if (isset($_POST['save_sections'])) {
    verify_csrf_or_die();
    $session_id = (int)($_POST['session_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);
    $names = array_values(array_unique(array_filter(array_map('section_name_normalise', preg_split('/[\s,]+/', (string)($_POST['section_names'] ?? ''))))));
    $back = 'Location: add_section.php?' . http_build_query(['session_id' => $session_id, 'class_id' => $class_id]);

    $session_ok = in_array($session_id, array_map('intval', array_column($sessions, 'id')), true);
    $class = null; foreach ($classes as $c) if ((int)$c['id'] === $class_id) $class = $c;
    $invalid = array_values(array_filter($names, fn($n) => section_name_error($n) !== null));
    if (!$session_ok || !$class) {
        $_SESSION['error'] = 'Choose a session and a class.';
    } elseif (!$names) {
        $_SESSION['error'] = 'Type at least one section name.';
    } elseif ($invalid) {
        $_SESSION['error'] = 'Not accepted (1–3 capital letters or digits): ' . implode(', ', $invalid) . ' — nothing was added.';
    } else {
        $added = []; $existing = [];
        foreach ($names as $n) {
            try {
                db_insert('sections', ['session_id' => $session_id, 'class_id' => $class_id, 'section_name' => $n]);
                $added[] = $n;
            } catch (mysqli_sql_exception $e) {
                if ((int)$e->getCode() !== 1062) throw $e;   // the unique (session, class, name) is the guard against doubles
                $existing[] = $n;
            }
        }
        if ($added) log_action((int)($_SESSION['admin_id'] ?? 0), 'SECTIONS_ADDED', 'sections', $class_id, null, ['session_id' => $session_id, 'sections' => $added]);
        $msg = $added ? 'Class ' . $class['class_name'] . ': added ' . implode(', ', $added) . '.' : '';
        if ($existing) $msg .= ($msg ? ' ' : '') . 'Already there: ' . implode(', ', $existing) . '.';
        $_SESSION[$added ? 'success' : 'error'] = $msg;
    }
    header($back); exit;
}

$active_id = 0; foreach ($sessions as $s) if ($s['status'] === 'Active') $active_id = (int)$s['id'];
$session_id = (int)($_GET['session_id'] ?? $active_id);
$class_id = (int)($_GET['class_id'] ?? 0);
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sections</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:820px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-plus-circle"></i> Add Sections</div>
        <a href="sections.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Sections</a>
    </div>
    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group"><label><i class="fas fa-calendar-alt"></i> Session <span class="required">*</span></label>
                <select name="session_id" required>
                    <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === $session_id ? 'selected' : ''; ?>><?php echo $h($s['session_name']) . ($s['status'] === 'Active' ? ' (Active)' : ''); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label><i class="fas fa-chalkboard"></i> Class <span class="required">*</span></label>
                <select name="class_id" required>
                    <option value="">— select —</option>
                    <?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo $h($c['class_name']); ?></option><?php endforeach; ?>
                </select></div>
        </div>
        <div class="form-group"><label><i class="fas fa-layer-group"></i> Section names <span class="required">*</span></label>
            <input type="text" name="section_names" id="names" placeholder="A, B, C, D" required autocomplete="off" style="text-transform:uppercase">
            <div class="form-hint">Separate with commas or spaces. Each name is 1–3 capital letters or digits (A, B, A1, SC). Names the class already has are skipped.</div>
        </div>
        <div class="row-actions" style="flex-wrap:wrap;margin-bottom:15px">
            <span class="form-hint" style="margin:0 6px 0 0"><i class="fas fa-bolt"></i> Quick:</span>
            <?php foreach (range('A', 'H') as $l): ?><button type="button" class="btn btn-secondary btn-sm" data-add="<?php echo $l; ?>"><?php echo $l; ?></button><?php endforeach; ?>
            <button type="button" class="btn btn-secondary btn-sm" data-add="A B C D E F">A–F</button>
        </div>
        <div class="btn-group">
            <button type="submit" name="save_sections" class="btn btn-success"><i class="fas fa-save"></i> Add Sections</button>
            <a href="sections.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
<script>
// a quick button adds its names to the box, skipping any already typed
document.querySelectorAll('[data-add]').forEach(function (b) {
    b.addEventListener('click', function () {
        var box = document.getElementById('names'), have = box.value.toUpperCase().split(/[\s,]+/).filter(Boolean);
        b.dataset.add.split(' ').forEach(function (n) { if (have.indexOf(n) < 0) have.push(n); });
        box.value = have.join(', ');
        box.focus();
    });
});
</script>
</body>
</html>

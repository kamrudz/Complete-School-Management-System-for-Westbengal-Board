<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/session_helper.php';
require_once '../includes/logger.php';

if (isset($_POST['save_session'])) {
    verify_csrf_or_die();
    $name = trim((string)($_POST['session_name'] ?? ''));
    $error = session_name_error($name);
    if ($error === null) {
        try {
            $id = db_insert('academic_sessions', ['session_name' => $name]);
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1062) throw $e;   // the unique name is the guard against doubles
            $error = "Session '$name' already exists.";
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header('Location: add_session.php'); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'SESSION_ADDED', 'academic_sessions', (int)$id, null, ['session_name' => $name]);
    $_SESSION['success'] = "Session '$name' added.";
    header('Location: sessions.php'); exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Academic Session</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:640px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-plus-circle"></i> Add Academic Session</div>
        <a href="sessions.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Sessions</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Session Name</label>
            <input type="text" name="session_name" placeholder="e.g. 2026 or 2026-2027" required maxlength="9" pattern="\d{4}(-\d{4})?" title="2026 or 2026-2027" autofocus>
            <div class="form-hint">One year (2026) or two years in a row (2026-2027). Each name can be used once.</div>
        </div>
        <div class="btn-group">
            <button type="submit" name="save_session" class="btn btn-success"><i class="fas fa-save"></i> Save Session</button>
            <a href="sessions.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
</body>
</html>

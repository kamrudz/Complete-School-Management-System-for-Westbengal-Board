<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/staff_form.php';
require_once '../includes/photo_helper.php';
require_once '../includes/misc_helper.php';

/**
 * Add Staff. Employee ID (the school's own, e.g. ULPHS-ST-0001) is always auto-allocated; staff_type follows the designation; every field passes staff_validate() and the
 * UNIQUE keys (employee id, email, Aadhaar, PAN) before the row is written.
 */
$errors = []; $old = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_staff'])) {
    verify_csrf_or_die();
    $old = $_POST;
    unset($old['employee_id']);                       // always auto-assigned (ULPHS-ST-NNNN)
    [$data, $errors] = staff_validate($old);

    $photo = process_student_photo($_FILES['photo'] ?? [], '../uploads/staff/', 10240, 320, 'staff_');
    if (!$photo['ok']) $errors[] = 'Photo: ' . $photo['error'];

    if (!$errors) {
        $data['photo'] = $photo['filename'] ?: null;
        try {
            $id = db_insert('staff', $data);
            if ($id === false) throw new RuntimeException('insert failed');
        } catch (mysqli_sql_exception $e) {
            if ($photo['filename']) app_unlink_upload('../uploads/staff/', $photo['filename']);
            $errors[] = (int)$e->getCode() === 1062 ? 'Employee ID / email / Aadhaar / PAN already exists for another staff member.' : 'Could not save: ' . $e->getMessage();
        }
        if (!$errors) {
            $pw = $data['can_login'] ? staff_set_default_password((int)$id, $data['date_of_birth']) : null;
            log_action((int)($_SESSION['admin_id'] ?? 0), 'STAFF_ADDED', 'staff', (string)$id, null, "{$data['staff_name']} ({$data['employee_id']}), {$data['designation']}" . ($pw ? ', portal login created with the default password' : ''));
            $_SESSION['success'] = "{$data['staff_name']} added — Employee ID {$data['employee_id']}." . ($pw ? " Teacher portal: username {$data['state_govt_id']}, password {$pw} (must be changed at first login)." : '');
            header('Location: view_staff.php?id=' . (int)$id); exit();
        }
    }
}
$v = $old ?: ['service_status' => 'Active', 'can_login' => 1];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Staff</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php staff_form_styles(); ?>
<style>
    .sf-banner { background: linear-gradient(135deg, #1f4e79 0%, #2b78b6 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 6px; box-shadow: 0 8px 24px rgba(31,78,121,.25); }
    .sf-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .sf-banner h1 { margin: 0; font-size: 21px; } .sf-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e6f5; }
    .sf-banner .links { margin-left: auto; display: flex; gap: 8px; }
    .sf-banner .links a { background: #fff; color: #1f4e79; padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="sf-banner">
        <div class="ico"><i class="fas fa-user-plus"></i></div>
        <div><h1>Add Staff</h1><p>Teachers and non-teaching staff. Portal username = State Govt ID; first password = Teacher@&lt;birth year&gt;.</p></div>
        <div class="links"><a href="staff.php"><i class="fas fa-arrow-left"></i> Staff list</a></div>
    </div>
    <?php if ($errors): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><ul><?php foreach ($errors as $e): ?><li><?php echo sf_h($e); ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php staff_form_render($v, 'add'); ?>
        <div class="sf-actions">
            <a href="staff.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" name="save_staff" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save Staff</button>
        </div>
    </form>
</div>
</body>
</html>

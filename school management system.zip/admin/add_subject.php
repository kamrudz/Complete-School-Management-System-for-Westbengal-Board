<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/subject_helper.php';
require_once '../includes/logger.php';

if (isset($_POST['save_subjects'])) {
    verify_csrf_or_die();
    $codes = (array)($_POST['subject_code'] ?? []);
    $added = []; $existing = []; $invalid = [];
    foreach ((array)($_POST['subject_name'] ?? []) as $key => $name) {
        $name = subject_name_normalise($name);
        if ($name === '') continue;
        $r = subject_insert($name, (string)($codes[$key] ?? ''));
        if ($r === 'added') $added[] = $name;
        elseif ($r === 'duplicate') $existing[] = $name;
        else $invalid[] = "$name — $r";
    }
    if ($added) log_action((int)($_SESSION['admin_id'] ?? 0), 'SUBJECTS_ADDED', 'subjects', null, null, ['subjects' => $added]);
    $parts = [];
    if ($added) $parts[] = 'Added: ' . implode(', ', $added) . '.';
    if ($existing) $parts[] = 'Already there: ' . implode(', ', $existing) . '.';
    if ($invalid) $parts[] = 'Not accepted: ' . implode(' · ', $invalid);
    $_SESSION[$added && !$invalid ? 'success' : 'error'] = $parts ? implode(' ', $parts) : 'Type at least one subject name.';
    header('Location: add_subject.php'); exit;
}
$quick = ['Bengali', 'English', 'Mathematics', 'Science', 'History', 'Geography', 'ICT', 'GK', 'Physical Education', 'Work Education'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Subjects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>#rows input { width: 100%; padding: 8px 10px; border: 2px solid var(--gray-light); border-radius: 8px; font-size: 14px; }</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:820px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-plus-circle"></i> Add Subjects</div>
        <a href="subjects.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Subjects</a>
    </div>
    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($_SESSION[$kind], ENT_QUOTES, 'UTF-8'); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <table class="table">
            <thead><tr><th style="width:62%">Subject name</th><th>Code (optional)</th></tr></thead>
            <tbody id="rows">
            <?php for ($i = 0; $i < 3; $i++): ?><tr><td><input type="text" name="subject_name[]" placeholder="e.g. Mathematics"></td><td><input type="text" name="subject_code[]" placeholder="e.g. MATH" style="text-transform:uppercase"></td></tr><?php endfor; ?>
            </tbody>
        </table>
        <div class="row-actions" style="flex-wrap:wrap;margin:12px 0">
            <button type="button" class="btn btn-secondary btn-sm" id="more"><i class="fas fa-plus"></i> Another row</button>
            <span class="form-hint" style="margin:0 6px 0 12px"><i class="fas fa-bolt"></i> Quick:</span>
            <?php foreach ($quick as $q): ?><button type="button" class="btn btn-secondary btn-sm" data-name="<?php echo $q; ?>"><?php echo $q; ?></button><?php endforeach; ?>
        </div>
        <div class="form-hint">Blank rows are ignored; a subject that already exists is reported and skipped.</div>
        <div class="btn-group">
            <button type="submit" name="save_subjects" class="btn btn-success"><i class="fas fa-save"></i> Add Subjects</button>
            <a href="subjects.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
<script>
(function () {
    var rows = document.getElementById('rows'), blank = rows.rows[0].cloneNode(true);
    function addRow() { var r = blank.cloneNode(true); rows.appendChild(r); return r; }
    document.getElementById('more').addEventListener('click', addRow);
    // a quick button fills the first empty name, adding a row when every row is taken
    document.querySelectorAll('[data-name]').forEach(function (b) {
        b.addEventListener('click', function () {
            var empty = Array.prototype.find.call(rows.querySelectorAll('input[name="subject_name[]"]'), function (i) { return i.value.trim() === ''; });
            (empty || addRow().querySelector('input')).value = b.dataset.name;
        });
    });
})();
</script>
</body>
</html>

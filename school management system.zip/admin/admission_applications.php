<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/admission_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/** Applications: look through them class by class, open one to check its details and documents, then select, waitlist or reject it. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$settings = adm_settings();
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$session_id = (int)$in('session_id', 0) ?: (int)$settings['admission_session_id'];
if (!isset($sessions[$session_id])) $session_id = adm_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$class_id = (int)$in('class_id', 0);
if (!isset($classes[$class_id])) $class_id = 0;
$status = (string)$in('status', '');
if (!isset(ADM_STATUS[$status])) $status = '';
$search = trim((string)$in('search', ''));
$centres = array_column(db_get_all('SELECT id, name FROM admission_centres ORDER BY name'), 'name', 'id');
$centre = (string)$in('centre', '');   // a centre id, or 'web' for the ones made from the website
if ($centre !== 'web' && !isset($centres[(int)$centre])) $centre = '';
$q = array_filter(['session_id' => $session_id, 'class_id' => $class_id ?: null, 'status' => $status ?: null, 'search' => $search !== '' ? $search : null, 'centre' => $centre !== '' ? $centre : null]);
$self = fn(array $over = []) => 'admission_applications.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));
$go = function (string $kind = '', string $msg = '', ?string $url = null) use ($self) {
    if ($kind !== '') $_SESSION[$kind] = $msg;
    header('Location: ' . ($url ?? $self()));
    exit();
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    $id = (int)($_POST['app_id'] ?? 0);
    try {
        $app = $id ? db_get_row('SELECT * FROM admission_applications WHERE id = ?', 'i', $id) : null;
        if (!$app) throw new RuntimeException('That application is gone — look at the list again.');
        if ($act === 'docs') {
            $on = !empty($_POST['docs_checked']) ? 1 : 0;
            db_execute('UPDATE admission_applications SET docs_checked = ? WHERE id = ?', 'ii', $on, $id);
            adm_log($admin_id, 'ADMISSION_DOCS_CHECKED', $id, null, ['application' => $app['application_ref'], 'checked' => $on]);
            $go('success', $on ? 'Marked as documents checked.' : 'The documents-checked mark is off.', $self(['open' => $id]));
        }
        if ($act === 'decide') {
            $to = (string)($_POST['to'] ?? '');
            if (!in_array($to, ['Pending', 'Admitted', 'Waitlisted', 'Rejected'], true)) throw new RuntimeException('Choose what to do with it.');
            if ($app['application_status'] === 'Enrolled') throw new RuntimeException('A student has already been made from this application, so it can no longer be changed.');
            $reason = mb_substr(trim((string)($_POST['reject_reason'] ?? '')), 0, 255);
            if ($to === 'Rejected' && $reason === '') throw new RuntimeException('Give the reason it was not taken.');
            $note = mb_substr(trim((string)($_POST['admin_note'] ?? '')), 0, 255);
            db_execute('UPDATE admission_applications SET application_status = ?, reject_reason = ?, admin_note = ? WHERE id = ?',
                'sssi', $to, $to === 'Rejected' ? $reason : null, $note ?: null, $id);
            adm_log($admin_id, 'ADMISSION_DECIDED', $id, ['status' => $app['application_status']], ['application' => $app['application_ref'], 'status' => $to, 'reason' => $reason]);
            $go('success', $app['application_ref'] . ' — ' . ADM_STATUS[$to][0] . '.', $self(['open' => $id]));
        }
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage(), $self(['open' => $id ?: null]));
    }
    $go();
}

$where = ['aa.session_id = ?']; $types = 'i'; $params = [$session_id];
if ($class_id) { $where[] = 'aa.class_id = ?'; $types .= 'i'; $params[] = $class_id; }
if ($status !== '') { $where[] = 'aa.application_status = ?'; $types .= 's'; $params[] = $status; }
if ($centre === 'web') $where[] = 'aa.centre_id IS NULL';
elseif ($centre !== '') { $where[] = 'aa.centre_id = ?'; $types .= 'i'; $params[] = (int)$centre; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(aa.application_ref LIKE ? OR aa.student_name LIKE ? OR aa.guardian_mobile LIKE ? OR aa.father_name LIKE ?)';
    $types .= 'ssss'; array_push($params, $like, $like, $like, $like);
}
$from = 'FROM admission_applications aa JOIN classes c ON c.id = aa.class_id WHERE ' . implode(' AND ', $where);
$rows = db_get_all("SELECT aa.*, c.class_name, c.stage $from ORDER BY c.sort_order, aa.application_status = 'Rejected', aa.created_at DESC", $types, ...$params);

// how each class stands: applications, selected and the seats it has
$seats = adm_open_classes($session_id);
$by_class = [];
foreach (db_get_all("SELECT class_id, application_status, COUNT(*) n FROM admission_applications WHERE session_id = ? GROUP BY class_id, application_status", 'i', $session_id) as $r) {
    $by_class[(int)$r['class_id']][$r['application_status']] = (int)$r['n'];
}
$counts = [];
foreach (ADM_STATUS as $k => $_) $counts[$k] = (int)(db_get_row("SELECT COUNT(*) n $from AND aa.application_status = ?", $types . 's', ...array_merge($params, [$k]))['n'] ?? 0);

if (!empty($_GET['export'])) {
    $out = exam_xlsx_title('Admission applications · ' . exam_session_name($session_id) . ($class_id ? ' · Class ' . $classes[$class_id]['name'] : ''));
    $out[] = ['Application No.', 'Applied on', 'Made at', 'Student', 'Class', 'Date of birth', 'Gender', 'Father', 'Mother', 'Guardian mobile', 'Previous school', 'Madhyamik %', 'Documents checked', 'Status', 'Reason / note'];
    foreach ($rows as $r) {
        $out[] = [$r['application_ref'], date('d-m-Y', strtotime($r['created_at'])), $r['centre_id'] ? ($centres[(int)$r['centre_id']] ?? 'Centre') : 'Website', $r['student_name'], 'Class ' . $r['class_name'],
            $r['dob'] ? date('d-m-Y', strtotime($r['dob'])) : '', (string)$r['gender'], (string)$r['father_name'], (string)$r['mother_name'],
            (string)$r['guardian_mobile'], (string)$r['previous_school'], $r['mp_percentage'] !== null ? (float)$r['mp_percentage'] : '',
            $r['docs_checked'] ? 'Yes' : 'No', ADM_STATUS[$r['application_status']][0] ?? $r['application_status'], (string)($r['reject_reason'] ?: $r['admin_note'])];
    }
    SimpleXLSXWriter::download('Admission_applications_' . exam_session_name($session_id) . '.xlsx', $out, 'Applications', exam_xlsx_opts(15, 24));
    exit();
}

$open_id = (int)$in('open', 0);
$open = $open_id ? db_get_row('SELECT aa.*, c.class_name, c.stage FROM admission_applications aa JOIN classes c ON c.id = aa.class_id WHERE aa.id = ? AND aa.session_id = ?', 'ii', $open_id, $session_id) : null;
$open_subjects = [];
if ($open) {
    $ids = array_values(array_filter(array_map('intval', [$open['xi_main_subject_1'], $open['xi_main_subject_2'], $open['xi_main_subject_3'], $open['xi_additional_subject']])));
    if ($ids) $open_subjects = array_column(db_get_all('SELECT id, subject_name FROM subjects WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', str_repeat('i', count($ids)), ...$ids), 'subject_name', 'id');
    $open_third = $open['third_language_id'] ? (string)(db_get_row('SELECT subject_name FROM subjects WHERE id = ?', 'i', (int)$open['third_language_id'])['subject_name'] ?? '') : '';
    $open_mp = json_decode((string)$open['mp_subjects_json'], true) ?: [];
}
$session_name = exam_session_name($session_id);
$chip = fn(string $st) => '<span class="chip ' . h(ADM_STATUS[$st][1] ?? 'off') . '">' . h(ADM_STATUS[$st][0] ?? $st) . '</span>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admission Applications</title>
<?php exam_styles('adm'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.num, .ex-table th.num { text-align: center; }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; }
    .lay { display: grid; grid-template-columns: minmax(0, 1fr) 420px; gap: 14px; align-items: start; }
    .one { position: sticky; top: 70px; max-height: calc(100vh - 90px); overflow: auto; }
    .one h2 small { display: block; font-weight: 400; color: #6b7d90; margin-top: 3px; }
    .kv { width: 100%; border-collapse: collapse; font-size: 13px; }
    .kv td { padding: 6px 2px; border-bottom: 1px solid #f0e8e0; vertical-align: top; }
    .kv td.k { color: #6b7d90; width: 42%; }
    .kv td.v { font-weight: 600; }
    .docs { display: flex; gap: 7px; flex-wrap: wrap; margin-top: 10px; }
    .docs a { padding: 6px 11px; border-radius: 8px; background: var(--ex-soft); border: 1px solid var(--ex-border); color: var(--ex-dark); text-decoration: none; font-size: 12.5px; font-weight: 600; }
    .decide { display: flex; gap: 7px; flex-wrap: wrap; margin-top: 12px; }
    .seatline { font-size: 12px; color: #6b7d90; }
    .seatline b { color: var(--ex-dark); }
    @media (max-width: 1100px) { .lay { grid-template-columns: 1fr; } .one { position: static; max-height: none; } }
    @media print { nav.main-navbar-2tier, .ex-banner, .ex-tabs, .noprint, .one { display: none !important; } .card { border: 0; padding: 0; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Admission Applications', 'Check the details and documents, then select, waitlist or reject', 'fa-list',
        ['admission_merit.php' => '<i class="fas fa-ranking-star"></i> Merit List', $self(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php adm_tabs('admission_applications.php'); exam_flash(); ?>

    <form method="get" class="card pick noprint">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="0">All classes</option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo (int)$cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Status</label><select name="status" onchange="this.form.submit()"><option value="">All</option><?php foreach (ADM_STATUS as $k => [$label]): ?><option value="<?php echo h($k); ?>"<?php echo $k === $status ? ' selected' : ''; ?>><?php echo h($label); ?></option><?php endforeach; ?></select></div>
        <?php if ($centres): ?><div><label>Made at</label><select name="centre" onchange="this.form.submit()"><option value="">Anywhere</option><option value="web"<?php echo $centre === 'web' ? ' selected' : ''; ?>>The website</option><?php echo exam_options($centres, $centre); ?></select></div><?php endif; ?>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Application No., name, mobile"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>

    <div class="sum noprint">
        <?php foreach (ADM_STATUS as $k => [$label]): ?><div><b><?php echo (int)$counts[$k]; ?></b><small><?php echo h($label); ?></small></div><?php endforeach; ?>
    </div>

    <?php if ($by_class): ?>
    <div class="card noprint" style="overflow-x:auto">
        <h2>By class</h2>
        <table class="ex-table">
            <thead><tr><th>Class</th><th class="num">Applications</th><th class="num">Selected</th><th class="num">Waiting</th><th class="num">Enrolled</th><th class="num">Seats</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($classes as $cid => $c): $b = $by_class[$cid] ?? null; if (!$b) continue;
                $sel = (int)($b['Admitted'] ?? 0) + (int)($b['Enrolled'] ?? 0); $cap = $seats[$cid]['seats'] ?? null; ?>
            <tr>
                <td><b>Class <?php echo h($c['name']); ?></b></td>
                <td class="num"><?php echo array_sum($b); ?></td>
                <td class="num"><?php echo (int)($b['Admitted'] ?? 0); ?></td>
                <td class="num"><?php echo (int)($b['Waitlisted'] ?? 0); ?></td>
                <td class="num"><?php echo (int)($b['Enrolled'] ?? 0); ?></td>
                <td class="num"><?php echo $cap === null ? '—' : '<span class="seatline"><b>' . $sel . '</b> / ' . (int)$cap . '</span>'; ?></td>
                <td><a href="<?php echo h($self(['class_id' => $cid, 'open' => null])); ?>">See them</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div class="<?php echo $open ? 'lay' : ''; ?>">
    <div>
    <?php if (!$rows): ?>
    <div class="ex-empty"><i class="fas fa-inbox"></i>No application matches. They arrive from the website's admission form.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Application</th><th>Student</th><th>Class</th><th>Guardian</th><th class="num">Madhyamik</th><th class="num">Docs</th><th>Status</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
            <tr<?php echo $open && (int)$r['id'] === (int)$open['id'] ? ' style="background:var(--ex-soft)"' : ''; ?>>
                <td><b><?php echo h($r['application_ref']); ?></b><small><?php echo h(date('d M Y', strtotime($r['created_at'])) . ($r['centre_id'] ? ' · ' . ($centres[(int)$r['centre_id']] ?? 'a centre') : '')); ?></small></td>
                <td><b><?php echo h($r['student_name']); ?></b><small><?php echo h(($r['gender'] ? $r['gender'] . ' · ' : '') . ($r['dob'] ? date('d-m-Y', strtotime($r['dob'])) : '')); ?></small></td>
                <td>Class <?php echo h($r['class_name']); ?></td>
                <td><?php echo h($r['father_name'] ?: $r['guardian_name']); ?><small><i class="fas fa-phone" style="font-size:10px"></i> <?php echo h($r['guardian_mobile']); ?></small></td>
                <td class="num"><?php echo $r['mp_percentage'] !== null ? h(rtrim(rtrim($r['mp_percentage'], '0'), '.')) . '%' : '—'; ?></td>
                <td class="num"><?php echo $r['docs_checked'] ? '<i class="fas fa-check" style="color:#1b7a3a"></i>' : '—'; ?></td>
                <td><?php echo $chip($r['application_status']); ?><?php echo $r['application_status'] === 'Rejected' && $r['reject_reason'] ? '<small>' . h($r['reject_reason']) . '</small>' : ''; ?></td>
                <td class="noprint" style="white-space:nowrap">
                    <a class="btn btn-secondary btn-sm" href="<?php echo h($self(['open' => (int)$r['id']])); ?>" title="Open"><i class="fas fa-eye"></i></a>
                    <?php if ($r['application_status'] === 'Admitted'): ?><a class="btn btn-success btn-sm" href="<?php echo h('admission_finalize.php?id=' . (int)$r['id']); ?>" title="Finalize"><i class="fas fa-user-check"></i></a><?php endif; ?>
                    <?php if ($r['application_status'] === 'Enrolled' && $r['admitted_student_id']): ?><a class="btn btn-secondary btn-sm" href="<?php echo h(student_page_url('view_student.php', $r['admitted_student_id'])); ?>" title="The student"><i class="fas fa-user"></i></a><?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    </div>

    <?php if ($open): ?>
    <div class="card one noprint">
        <h2><?php echo h($open['student_name']); ?> <?php echo $chip($open['application_status']); ?><small><?php echo h($open['application_ref'] . ' · Class ' . $open['class_name'] . ' · ' . (ADM_STAGES[$open['stage']] ?? '')); ?></small></h2>
        <table class="kv">
            <?php
            $show = ['Date of birth' => $open['dob'] ? date('d-m-Y', strtotime($open['dob'])) : '', 'Gender' => $open['gender'], 'Religion' => $open['religion'], 'Caste' => $open['caste'],
                'Aadhaar' => $open['student_aadhaar'], 'Banglar Shiksha ID' => $open['banglarshiksha_id'], 'PEN' => $open['pen_id'], 'APAAR' => $open['apaar_id'],
                'Birth registration' => $open['birth_registration_number'], 'Father' => $open['father_name'], 'Mother' => $open['mother_name'],
                'Guardian' => trim(($open['guardian_name'] ?? '') . ' ' . ($open['guardian_relation'] ? '(' . $open['guardian_relation'] . ')' : '')),
                'Mobile' => $open['guardian_mobile'], 'Address' => trim(implode(', ', array_filter([$open['village'], $open['post_office'], $open['police_station'], $open['district'], $open['pin_code']]))),
                'Previous school' => $open['previous_school'], 'Last class' => trim(($open['previous_class'] ?? '') . ' ' . ($open['previous_result'] ? '· ' . $open['previous_result'] : '')),
                'TC number' => $open['tc_no'], 'Third language' => $open_third ?? ''];
            if ($open['stage'] === 'higher_secondary') {
                $show['Madhyamik'] = trim(($open['mp_board'] ?? '') . ' ' . ($open['mp_year'] ?? '') . ($open['mp_roll_no'] ? ' · Roll ' . $open['mp_roll_no'] : '') . ($open['mp_registration_no'] ? ' · Reg ' . $open['mp_registration_no'] : ''));
                $show['Marks'] = $open['mp_total_marks'] !== null ? rtrim(rtrim($open['mp_total_marks'], '0'), '.') . ' / ' . rtrim(rtrim($open['mp_total_full_marks'], '0'), '.') . ' = ' . rtrim(rtrim($open['mp_percentage'], '0'), '.') . '%' : '';
                $show['Subjects chosen'] = implode(', ', $open_subjects);
            }
            if ($open['is_same_school_student']) $show['Own student'] = 'Yes' . ($open['previous_student_id'] ? ' · ' . $open['previous_student_id'] : '');
            foreach ($show as $k => $value): if (trim((string)$value) === '') continue; ?>
            <tr><td class="k"><?php echo h($k); ?></td><td class="v"><?php echo h($value); ?></td></tr>
            <?php endforeach; ?>
        </table>
        <?php if (!empty($open_mp)): ?>
        <table class="ex-table" style="margin-top:10px">
            <thead><tr><th>Madhyamik subject</th><th class="num">Full</th><th class="num">Got</th></tr></thead>
            <tbody><?php foreach ($open_mp as $m): ?><tr><td><?php echo h($m['subject'] ?? ''); ?></td><td class="num"><?php echo h($m['full_marks'] ?? ''); ?></td><td class="num"><?php echo h($m['marks_obtained'] ?? ''); ?></td></tr><?php endforeach; ?></tbody>
        </table>
        <?php endif; ?>

        <div class="docs">
            <?php $any = false; foreach (ADM_DOCS as $k => [$label]): if (empty($open[$k])) continue; $any = true; ?>
            <a href="<?php echo h('admission_doc.php?' . http_build_query(['id' => (int)$open['id'], 'type' => $k])); ?>" target="_blank"><i class="fas fa-file"></i> <?php echo h($label); ?></a>
            <?php endforeach; ?>
            <?php if (!$any): ?><span class="note" style="margin:0">No document uploaded.</span><?php endif; ?>
        </div>

        <form method="post" style="margin-top:12px">
            <?php echo csrf_field(); ?><?php foreach ($q as $k => $val): ?><input type="hidden" name="<?php echo h($k); ?>" value="<?php echo h($val); ?>"><?php endforeach; ?>
            <input type="hidden" name="act" value="docs"><input type="hidden" name="app_id" value="<?php echo (int)$open['id']; ?>">
            <label class="chk" style="display:flex;align-items:center;gap:8px;font-size:13px"><input type="checkbox" name="docs_checked" value="1" onchange="this.form.submit()" <?php echo $open['docs_checked'] ? 'checked' : ''; ?>> The original documents have been checked</label>
        </form>

        <?php if ($open['application_status'] !== 'Enrolled'): ?>
        <form method="post" class="pf" id="decideForm">
            <?php echo csrf_field(); ?><?php foreach ($q as $k => $val): ?><input type="hidden" name="<?php echo h($k); ?>" value="<?php echo h($val); ?>"><?php endforeach; ?>
            <input type="hidden" name="act" value="decide"><input type="hidden" name="app_id" value="<?php echo (int)$open['id']; ?>"><input type="hidden" name="to" id="decideTo">
            <label>Note for the office <small style="text-transform:none;font-weight:400">optional</small></label>
            <input type="text" name="admin_note" maxlength="255" value="<?php echo h($open['admin_note'] ?? ''); ?>">
            <div id="reasonBox" style="display:none"><label>Reason for not taking</label><input type="text" name="reject_reason" id="reasonInput" maxlength="255" value="<?php echo h($open['reject_reason'] ?? ''); ?>"></div>
            <div class="decide">
                <?php if ($open['application_status'] !== 'Admitted'): ?><button type="button" class="btn btn-success btn-sm" data-to="Admitted"><i class="fas fa-check"></i> Select</button><?php endif; ?>
                <?php if ($open['application_status'] !== 'Waitlisted'): ?><button type="button" class="btn btn-warning btn-sm" data-to="Waitlisted"><i class="fas fa-hourglass-half"></i> Waiting list</button><?php endif; ?>
                <?php if ($open['application_status'] !== 'Rejected'): ?><button type="button" class="btn btn-danger btn-sm" data-to="Rejected"><i class="fas fa-ban"></i> Not taken</button><?php endif; ?>
                <?php if ($open['application_status'] !== 'Pending'): ?><button type="button" class="btn btn-secondary btn-sm" data-to="Pending"><i class="fas fa-undo"></i> Back to pending</button><?php endif; ?>
            </div>
        </form>
        <?php endif; ?>
        <?php if ($open['application_status'] === 'Admitted'): ?>
        <div class="acts" style="margin-top:12px"><a class="btn btn-success" href="<?php echo h('admission_finalize.php?id=' . (int)$open['id']); ?>"><i class="fas fa-user-check"></i> Finalize — make the student</a></div>
        <?php elseif ($open['application_status'] === 'Enrolled' && $open['admitted_student_id']): ?>
        <div class="acts" style="margin-top:12px">
            <a class="btn btn-secondary" href="<?php echo h(student_page_url('view_student.php', $open['admitted_student_id'])); ?>"><i class="fas fa-user"></i> <?php echo h($open['admitted_student_id']); ?></a>
            <a class="btn btn-success" href="<?php echo h('collect_fee.php?' . http_build_query(['uid' => $open['admitted_student_id'], 'session_id' => (int)$open['session_id']])); ?>"><i class="fas fa-cash-register"></i> Collect the fee</a>
        </div>
        <?php endif; ?>
        <p class="note"><a href="<?php echo h($self(['open' => null])); ?>">Close</a></p>
    </div>
    <?php endif; ?>
    </div>
</div>
<script>
(function () {
    var form = document.getElementById('decideForm');
    if (!form) return;
    Array.prototype.forEach.call(form.querySelectorAll('button[data-to]'), function (b) {
        b.addEventListener('click', function () {
            var to = b.dataset.to;
            if (to === 'Rejected') {
                var box = document.getElementById('reasonBox');
                if (box.style.display === 'none') { box.style.display = ''; document.getElementById('reasonInput').focus(); return; }
                if (document.getElementById('reasonInput').value.trim() === '') { document.getElementById('reasonInput').focus(); return; }
            }
            if (!confirm(b.textContent.trim() + '?')) return;
            document.getElementById('decideTo').value = to;
            form.submit();
        });
    });
})();
</script>
</body>
</html>

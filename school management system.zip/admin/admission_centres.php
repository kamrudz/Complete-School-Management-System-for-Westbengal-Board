<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/admission_helper.php';
require_once '../includes/centre_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Application centres: the cyber cafés allowed to make admission applications. Each has its own username and
 * password; a centre is never deleted, only switched off, so the applications it made keep its name.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$edit_id = (int)($_GET['edit'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    $back = 'admission_centres.php';
    try {
        if ($act === 'save') {
            $name = trim((string)($_POST['name'] ?? ''));
            $owner = trim((string)($_POST['owner_name'] ?? ''));
            $place = trim((string)($_POST['place'] ?? ''));
            $phone = preg_replace('/\D/', '', (string)($_POST['phone'] ?? ''));
            $username = strtolower(trim((string)($_POST['username'] ?? '')));
            $password = (string)($_POST['password'] ?? '');
            if ($name === '' || mb_strlen($name) > 120) throw new RuntimeException('Give the centre a name (up to 120 letters).');
            if ($phone !== '' && !preg_match('/^[6-9]\d{9}$/', $phone)) throw new RuntimeException('The phone must be a 10-digit mobile number.');
            if (!centre_username_ok($username)) throw new RuntimeException('The username takes 4 to 40 small letters, digits, dots, dashes or underscores.');
            if (db_get_row('SELECT id FROM admission_centres WHERE username = ? AND id <> ?', 'si', $username, $id)) throw new RuntimeException("The username $username is already taken.");
            if ($id) {
                if (!db_get_row('SELECT id FROM admission_centres WHERE id = ?', 'i', $id)) throw new RuntimeException('That centre is gone — look at the list again.');
                db_execute('UPDATE admission_centres SET name = ?, owner_name = ?, place = ?, phone = ?, username = ? WHERE id = ?', 'sssssi',
                    $name, $owner ?: null, $place ?: null, $phone ?: null, $username, $id);
                if ($password !== '') {
                    if ($why = centre_password_problem($password)) throw new RuntimeException($why);
                    db_execute('UPDATE admission_centres SET password_hash = ? WHERE id = ?', 'si', password_hash($password, PASSWORD_DEFAULT), $id);
                }
                if (function_exists('log_action')) log_action($admin_id, 'CENTRE_SAVED', 'admission_centres', (string)$id, null, $name . ($password !== '' ? ' (new password)' : ''));
                $_SESSION['success'] = $name . ' is saved.' . ($password !== '' ? ' The new password works from now on.' : '');
            } else {
                if ($why = centre_password_problem($password)) throw new RuntimeException($why);
                db_execute('INSERT INTO admission_centres (name, owner_name, place, phone, username, password_hash, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)', 'ssssssi',
                    $name, $owner ?: null, $place ?: null, $phone ?: null, $username, password_hash($password, PASSWORD_DEFAULT), $admin_id ?: null);
                if (function_exists('log_action')) log_action($admin_id, 'CENTRE_ADDED', 'admission_centres', (string)db_get_row('SELECT id FROM admission_centres WHERE username = ?', 's', $username)['id'], null, $name);
                $_SESSION['success'] = $name . ' can now log in as "' . $username . '". Give them the password you chose.';
            }
        } elseif ($act === 'switch') {
            $row = db_get_row('SELECT id, name, is_active FROM admission_centres WHERE id = ?', 'i', $id);
            if (!$row) throw new RuntimeException('That centre is gone — look at the list again.');
            $to = (int)$row['is_active'] ? 0 : 1;
            db_execute('UPDATE admission_centres SET is_active = ? WHERE id = ?', 'ii', $to, $id);
            if (function_exists('log_action')) log_action($admin_id, $to ? 'CENTRE_ON' : 'CENTRE_OFF', 'admission_centres', (string)$id, null, $row['name']);
            $_SESSION['success'] = $row['name'] . ($to ? ' can make applications again.' : ' is switched off — it is logged out at its next click, and its applications keep its name.');
        }
    } catch (RuntimeException $e) {
        $_SESSION['error'] = $e->getMessage();
        $_SESSION['centre_old'] = $_POST;
        unset($_SESSION['centre_old']['password'], $_SESSION['centre_old']['csrf_token']);
        if ($id) $back .= '?edit=' . $id;
    }
    header('Location: ' . $back);
    exit();
}

$mode = adm_mode();
$rows = db_get_all("SELECT c.*, COUNT(a.id) apps, SUM(DATE(a.created_at) = CURDATE()) today, SUM(a.application_status = 'Pending') pending, MAX(a.created_at) last_app
    FROM admission_centres c LEFT JOIN admission_applications a ON a.centre_id = c.id
    GROUP BY c.id ORDER BY c.is_active DESC, c.name");
$editing = $edit_id ? (array_values(array_filter($rows, fn($r) => (int)$r['id'] === $edit_id))[0] ?? null) : null;
$old = $_SESSION['centre_old'] ?? ($editing ?: []);
unset($_SESSION['centre_old']);
$web = (int)(db_get_row('SELECT COUNT(*) n FROM admission_applications WHERE centre_id IS NULL')['n'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application Centres</title>
<?php exam_styles('adm'); ?>
<style>
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 700px) { .two { grid-template-columns: 1fr; } }
    .acts { display: flex; gap: 5px; flex-wrap: wrap; }
    .acts form { display: inline; }
    tr.off td { color: #98a6b5; }
    .uid { color: #93a2b2; font-size: 11.5px; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Application Centres', 'The cyber cafés allowed to make admission applications, each with its own login', 'fa-store',
        ['admission_settings.php' => '<i class="fas fa-sliders-h"></i> Who can apply', '../centre/login.php' => '<i class="fas fa-external-link-alt"></i> The centre login']); ?>
    <?php adm_tabs('admission_centres.php'); exam_flash(); ?>

    <div class="ex-guard" style="<?php echo $mode === 'centres' ? '' : 'background:#f2f8f5;border-color:#bfe0d1;color:#1d5c46'; ?>">
        <i class="fas fa-circle-info big"></i>
        <div><b>Right now: <?php echo h(ADM_MODES[$mode][0]); ?></b>
            <?php echo h(ADM_MODES[$mode][1]); ?> Change it in <a href="admission_settings.php">Admission Settings</a>.
            <?php echo $mode === 'public' ? 'A centre that logs in can still apply, and its applications carry its name.' : ''; ?></div>
    </div>

    <form method="post" class="card pf" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?php echo (int)($editing['id'] ?? 0); ?>">
        <h2><i class="fas fa-<?php echo $editing ? 'pen' : 'plus'; ?>"></i> <?php echo $editing ? 'Change ' . h($editing['name']) : 'Add a centre'; ?></h2>
        <div class="two">
            <div><label>Name of the centre</label><input type="text" name="name" maxlength="120" required value="<?php echo h($old['name'] ?? ''); ?>" placeholder="e.g. Rahman Cyber Point"></div>
            <div><label>Owner</label><input type="text" name="owner_name" maxlength="100" value="<?php echo h($old['owner_name'] ?? ''); ?>"></div>
            <div><label>Where</label><input type="text" name="place" maxlength="150" value="<?php echo h($old['place'] ?? ''); ?>" placeholder="e.g. Mothabari bazar"></div>
            <div><label>Phone</label><input type="text" name="phone" maxlength="10" inputmode="numeric" value="<?php echo h($old['phone'] ?? ''); ?>" placeholder="Shown to parents on the website"></div>
            <div><label>Username</label><input type="text" name="username" maxlength="40" required value="<?php echo h($old['username'] ?? ''); ?>" placeholder="e.g. rahman.cyber" autocapitalize="none" spellcheck="false"></div>
            <div><label>Password <?php echo $editing ? '<small style="text-transform:none;font-weight:400">— leave blank to keep the old one</small>' : ''; ?></label>
                <input type="password" name="password" maxlength="100" <?php echo $editing ? '' : 'required'; ?> autocomplete="new-password" placeholder="At least 8, with letters and a digit"></div>
        </div>
        <p class="note">The name, place and phone are shown to parents on the website while applications go through centres. The username and password are given to the centre by you; the school never sees the password again.</p>
        <div class="acts" style="margin-top:12px">
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?php echo $editing ? 'Save the changes' : 'Add the centre'; ?></button>
            <?php if ($editing): ?><a href="admission_centres.php" class="btn btn-secondary">Cancel</a><?php endif; ?>
        </div>
    </form>

    <div class="card">
        <h2><i class="fas fa-store"></i> Centres <small><?php echo count($rows); ?> · <?php echo $web; ?> application(s) were made from the website directly</small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-store"></i>No centre yet. Add the first one above.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Centre</th><th>Username</th><th class="num">Today</th><th class="num">Pending</th><th class="num">All</th><th>Last login</th><th>On</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr class="<?php echo (int)$r['is_active'] ? '' : 'off'; ?>">
                    <td><b><?php echo h($r['name']); ?></b><div class="uid"><?php echo h(trim(($r['place'] ?? '') . ($r['phone'] ? ' · ' . $r['phone'] : '') . ($r['owner_name'] ? ' · ' . $r['owner_name'] : ''), ' ·')); ?></div></td>
                    <td><?php echo h($r['username']); ?></td>
                    <td class="num"><?php echo (int)$r['today']; ?></td>
                    <td class="num"><?php echo (int)$r['pending']; ?></td>
                    <td class="num"><b><?php echo (int)$r['apps']; ?></b></td>
                    <td><?php echo $r['last_login_at'] ? h(date('d M Y, g:i a', strtotime($r['last_login_at']))) : '<span class="uid">never</span>'; ?></td>
                    <td><span class="chip <?php echo (int)$r['is_active'] ? 'ok' : 'off'; ?>"><?php echo (int)$r['is_active'] ? 'On' : 'Off'; ?></span></td>
                    <td>
                        <div class="acts">
                            <a href="<?php echo h('admission_applications.php?centre=' . (int)$r['id']); ?>" class="btn btn-info btn-sm" title="Its applications"><i class="fas fa-list"></i></a>
                            <a href="<?php echo h('admission_centres.php?edit=' . (int)$r['id']); ?>" class="btn btn-warning btn-sm" title="Change, or give a new password"><i class="fas fa-pen"></i></a>
                            <form method="post" onsubmit="return confirm('<?php echo (int)$r['is_active'] ? 'Switch this centre off? It is logged out at once and cannot make applications.' : 'Let this centre make applications again?'; ?>')">
                                <?php echo csrf_field(); ?><input type="hidden" name="act" value="switch"><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-<?php echo (int)$r['is_active'] ? 'secondary' : 'success'; ?> btn-sm" title="<?php echo (int)$r['is_active'] ? 'Switch off' : 'Switch on'; ?>"><i class="fas fa-power-off"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
        <p class="note">A centre is never deleted — switching it off stops it at once and keeps its name on the applications it made. Each centre may send up to <?php echo CENTRE_DAILY_LIMIT; ?> applications a day.</p>
    </div>
</div>
</body>
</html>

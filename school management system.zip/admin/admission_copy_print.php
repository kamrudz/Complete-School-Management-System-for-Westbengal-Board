<?php
/** The office copy of an admission application: the same A4 sheet as the applicant's, with ID numbers in full. */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/admission_copy.php';

$id = (int)($_GET['id'] ?? 0);
$app = $id ? db_get_row('SELECT aa.*, c.class_name, c.stage, s.session_name FROM admission_applications aa
    JOIN classes c ON c.id = aa.class_id LEFT JOIN academic_sessions s ON s.id = aa.session_id WHERE aa.id = ? LIMIT 1', 'i', $id) : null;
if (!$app) { http_response_code(404); exit('That application is not here.'); }
adm_copy_render($app, '../', true, 'admission_applications.php?open=' . $id);

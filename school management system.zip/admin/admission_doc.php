<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/admission_helper.php';

/**
 * Shows one document of an application to a logged-in admin: ?id=<application>&type=photo|signature|…
 * The files sit in uploads/admission/docs/, which Apache refuses to serve, so this is the only way in.
 */
$id = (int)($_GET['id'] ?? 0);
$type = (string)($_GET['type'] ?? '');
if ($id <= 0 || !isset(ADM_DOCS[$type])) { http_response_code(400); exit('Bad request.'); }

$row = db_get_row('SELECT ' . db_identifier($type) . ' AS f, application_ref FROM admission_applications WHERE id = ?', 'i', $id);
$path = $row ? admission_doc_path($row['f']) : null;
if (!$path) { http_response_code(404); exit('No document on file.'); }

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], true)) $mime = 'application/octet-stream';
$ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'][$mime] ?? 'bin';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . (!empty($_GET['dl']) ? 'attachment' : 'inline') . '; filename="' . $row['application_ref'] . '-' . $type . '.' . $ext . '"');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex');
readfile($path);
exit();

<?php
/**
 * admission_finalize.php (admin/)
 * For an 'Admitted' application: admin REVIEWS the already-collected data
 * (student, guardian, address, bank, documents), edits anything if needed
 * after physical document verification, assigns Section + Roll No, and this
 * creates the REAL students + guardians + student_academic_history records.
 * An own student coming back (Class X → XI, say) is not made again: the same student (School UID) is continued.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/student_helper.php';
require_once '../includes/admission_helper.php';
require_once '../includes/photo_helper.php';
require_once '../includes/hs_helper.php';   // Class XI subject combination
require_once '../includes/logger.php';
require_once '../includes/admission_helper.php';

$app_id = (int)($_GET['id'] ?? $_POST['app_id'] ?? 0);
$app = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT aa.*, c.class_name FROM admission_applications aa
    JOIN classes c ON c.id = aa.class_id
    WHERE aa.id='$app_id' LIMIT 1
"));

if (!$app) { die("Application not found."); }
if ($app['application_status'] !== 'Admitted') {
    die("This application is not at the 'Admitted' stage, so it cannot be finalized. (Current status: " . htmlspecialchars($app['application_status']) . ")");
}

$section_stmt = mysqli_prepare($conn, "SELECT * FROM sections WHERE class_id=? AND session_id=? ORDER BY section_name");
mysqli_stmt_bind_param($section_stmt, 'ii', $app['class_id'], $app['session_id']);
mysqli_stmt_execute($section_stmt);
$sections = mysqli_stmt_get_result($section_stmt);
$error = '';
function v($app, $key) { return htmlspecialchars($_POST[$key] ?? $app[$key] ?? ''); }

// an own student coming back is found here on the server — by the School UID the application names and by its
// Banglar Shiksha ID, PEN and APAAR, with the same date of birth — and continued; the form's hidden fields are not trusted
$posted = $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalize']);
$field = fn($k) => $posted ? trim((string)($_POST[$k] ?? '')) : (string)($app[$k] ?? '');
$same = admission_same_school(['previous_student_id' => $app['previous_student_id'] ?? '', 'banglarshiksha_id' => $field('banglarshiksha_id'),
    'pen_id' => $field('pen_id'), 'apaar_id' => $field('apaar_id'), 'dob' => $field('dob')]);
$continue = $same['student'] ?? null;
$continue_problem = $continue ? admission_continue_problem($continue, (int)$app['session_id']) : '';

if ($posted) {
    verify_csrf_or_die();

    $p = function($key) { return trim($_POST[$key] ?? ''); };
    $father_aadhaar_na = isset($_POST['father_aadhaar_na']) ? 1 : 0;
    $mother_aadhaar_na = isset($_POST['mother_aadhaar_na']) ? 1 : 0;
    $section_id = (int)($_POST['section_id'] ?? 0);
    $roll_no    = $p('roll_no');

    if (isset($same['conflict'])) {
        $error = $same['conflict'];
    } elseif ($continue_problem !== '') {
        $error = $continue_problem;
    } elseif ($p('father_name') === '' || $p('mother_name') === '' || $section_id <= 0 || $roll_no === '') {
        $error = "Father Name, Mother Name, Section and Roll No are all needed.";
    } elseif (!db_get_row('SELECT id FROM sections WHERE id = ? AND class_id = ? AND session_id = ?', 'iii', $section_id, $app['class_id'], $app['session_id'])) {
        $error = 'Choose a section of this class.';
    } elseif (!$father_aadhaar_na && strlen($p('father_aadhaar')) !== 12) {
        $error = "The father's Aadhaar must be 12 digits, or tick 'Not Available'.";
    } elseif (!$mother_aadhaar_na && strlen($p('mother_aadhaar')) !== 12) {
        $error = "The mother's Aadhaar must be 12 digits, or tick 'Not Available'.";
    } else {
        mysqli_begin_transaction($conn);
        try {
        // ---------- 1) Guardian (Existing Guardian Link Logic) ----------
        $existing_g_id = (int)($_POST['existing_guardian_id'] ?? 0);
        $guardian_id = 0;

        if ($existing_g_id > 0 && !$continue) {
            $chk = mysqli_prepare($conn, "SELECT guardian_id FROM guardians WHERE guardian_id=? LIMIT 1");
            mysqli_stmt_bind_param($chk, 'i', $existing_g_id);
            mysqli_stmt_execute($chk);
            if (mysqli_fetch_assoc(mysqli_stmt_get_result($chk))) { $guardian_id = $existing_g_id; }
            mysqli_stmt_close($chk);
        }

        if ($guardian_id === 0 && !$continue) {   // a continued student keeps their guardian
            $guardian_data = [
                'father_name'                  => ['v' => $p('father_name'), 't' => 's'],
                'father_aadhaar'               => ['v' => $father_aadhaar_na ? '' : $p('father_aadhaar'), 't' => 's'],
                'father_aadhaar_not_available' => ['v' => $father_aadhaar_na, 't' => 'i'],
                'father_voter_id'              => ['v' => $p('father_voter_id'), 't' => 's'],
                'father_mobile'                => ['v' => $p('father_mobile'), 't' => 's'],
                'father_occupation'            => ['v' => $p('father_occupation'), 't' => 's'],
                'father_qualification'         => ['v' => $p('father_qualification'), 't' => 's'],
                'annual_income'                => ['v' => $p('annual_income') !== '' ? $p('annual_income') : 0, 't' => 'd'],
                'mother_name'                  => ['v' => $p('mother_name'), 't' => 's'],
                'mother_aadhaar'               => ['v' => $mother_aadhaar_na ? '' : $p('mother_aadhaar'), 't' => 's'],
                'mother_aadhaar_not_available' => ['v' => $mother_aadhaar_na, 't' => 'i'],
                'mother_voter_id'              => ['v' => $p('mother_voter_id'), 't' => 's'],
                'mother_occupation'            => ['v' => $p('mother_occupation'), 't' => 's'],
                'guardian_name'                => ['v' => $p('guardian_name'), 't' => 's'],
                'guardian_relation'            => ['v' => $p('guardian_relation'), 't' => 's'],
                'guardian_contact'             => ['v' => $p('guardian_contact'), 't' => 's'],
            ];
            $guardian_id = db_insert_assoc($conn, 'guardians', $guardian_data);
        }

        // ---------- 2) Copy documents ----------
        $copy_doc = function($filename, $dir) {
            $src = admission_doc_path($filename);
            if (!$src) return null;
            $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION)) ?: 'jpg';
            $new_name = 'sig_' . bin2hex(random_bytes(8)) . '.' . $ext;
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            return @copy($src, $dir . $new_name) ? $new_name : null;
        };
        // the photo is re-processed like every other student photo (upright, 320 px, ≤ 10 KB); documents are copied as they are
        $photo_name = null;
        $photo_src = admission_doc_path($app['photo'] ?? '');
        if ($photo_src) {
            $pr = process_student_photo_path($photo_src, '../uploads/students/');
            $photo_name = $pr['ok'] ? $pr['filename'] : $copy_doc($app['photo'], '../uploads/students/');
        }
        $signature_name  = $copy_doc($app['signature'], '../uploads/students/signatures/');
        $birth_cert_name = student_doc_copy_path((string)admission_doc_path($app['birth_certificate'] ?? ''), 'birth');
        $aadhaar_name    = student_doc_copy_path((string)admission_doc_path($app['student_aadhaar_image'] ?? ''), 'aadhaar');

        // ---------- 3) Student ----------
        $adm_row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(CAST(admission_no AS UNSIGNED)) AS max_no FROM students"));
        $admission_no = (string)((int)($adm_row['max_no'] ?? 0) + 1);

        $student_data = [
            'guardian_id'        => ['v' => $guardian_id, 't' => 'i'],
            'admission_no'       => ['v' => $admission_no, 't' => 's'],
            'admission_year'     => ['v' => (int)date('Y'), 't' => 'i'],
            'admission_date'     => ['v' => date('Y-m-d'), 't' => 's'],
            'banglarshiksha_id'  => ['v' => $p('banglarshiksha_id'), 't' => 's'],
            'pen_id'             => ['v' => $p('pen_id') ?: null, 't' => 's'],
            'apaar_id'           => ['v' => $p('apaar_id') ?: null, 't' => 's'],
            'student_name'       => ['v' => $p('student_name'), 't' => 's'],
            'name_as_per_aadhaar'=> ['v' => $p('name_as_per_aadhaar'), 't' => 's'],
            'dob'                => ['v' => $p('dob'), 't' => 's'],
            'gender'             => ['v' => $p('gender'), 't' => 's'],
            'blood_group'        => ['v' => $p('blood_group'), 't' => 's'],
            'religion'           => ['v' => $p('religion'), 't' => 's'],
            'caste'              => ['v' => $p('caste'), 't' => 's'],
            'sub_caste'          => ['v' => $p('sub_caste'), 't' => 's'],
            'disability'         => ['v' => $p('disability'), 't' => 's'],
            'disability_type'    => ['v' => $p('disability_type'), 't' => 's'],
            'birth_registration_number' => ['v' => $p('birth_registration_number'), 't' => 's'],
            'student_aadhaar'    => ['v' => $p('student_aadhaar') ?: null, 't' => 's'],
            'village'            => ['v' => $p('village'), 't' => 's'],
            'post_office'        => ['v' => $p('post_office'), 't' => 's'],
            'police_station'     => ['v' => $p('police_station'), 't' => 's'],
            'district'           => ['v' => $p('district'), 't' => 's'],
            'state'              => ['v' => $p('state'), 't' => 's'],
            'pin_code'           => ['v' => $p('pin_code'), 't' => 's'],
            'mobile'             => ['v' => $p('student_mobile') ?: $p('guardian_contact'), 't' => 's'],
            'email'              => ['v' => $p('student_email'), 't' => 's'],
            'bank_name'          => ['v' => $p('bank_name'), 't' => 's'],
            'branch_name'        => ['v' => $p('branch_name'), 't' => 's'],
            'account_number'     => ['v' => $p('account_number'), 't' => 's'],
            'ifsc_code'          => ['v' => $p('ifsc_code'), 't' => 's'],
            'photo'              => ['v' => $photo_name, 't' => 's'],
            'signature'          => ['v' => $signature_name, 't' => 's'],
            'birth_certificate'  => ['v' => $birth_cert_name, 't' => 's'],
            'student_aadhaar_image' => ['v' => $aadhaar_name, 't' => 's'],
            'remarks'            => ['v' => "Created from Online Admission (Ref: {$app['application_ref']})", 't' => 's'],
        ];
        if ($continue) {
            // one of ours: the same student goes on — the profile from this form, the old files kept unless new ones came
            $student_id = $continue['id'];
            $profile = array_map(fn($spec) => $spec['v'], $student_data);
            unset($profile['guardian_id'], $profile['admission_no'], $profile['admission_year'], $profile['admission_date'], $profile['remarks']);
            foreach (['photo', 'signature', 'birth_certificate', 'student_aadhaar_image'] as $k) if (empty($profile[$k])) unset($profile[$k]);
            if ($dup = student_duplicates($profile, $student_id)) throw new RuntimeException(reset($dup));
            db_update('students', student_blank_ids_to_null($profile) + ['student_status' => 'Active'], ['id' => $student_id]);
        } else {
            // the School UID is allocated inside student_insert() and IS the primary key
            $student_id = student_insert($conn, array_map(fn($spec) => $spec['v'], $student_data), (int)date('Y'));
        }

// ---------- 4) Third language, when the applicant chose one ----------
        if (!empty($app['third_language_id'])) {
            db_execute('INSERT INTO student_third_language (student_id, subject_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE subject_id = VALUES(subject_id)',
                'si', $student_id, (int)$app['third_language_id']);
        }

// ---------- 4) Academic history ----------
        $hist_data = [
            'student_id'      => ['v' => $student_id, 't' => 's'],
            'session_id'      => ['v' => $app['session_id'], 't' => 'i'],
            'class_id'        => ['v' => $app['class_id'], 't' => 'i'],
            'section_id'      => ['v' => $section_id, 't' => 'i'],
            'roll_no'         => ['v' => $roll_no, 't' => 's'],
            'previous_school' => ['v' => $p('previous_school'), 't' => 's'],
        ];
        if (!db_insert_assoc($conn, 'student_academic_history', $hist_data)) { throw new RuntimeException('Academic history could not be created.'); }

        // ---------- 4b) Class XI subject combination (one row per subject; compulsory ones are added by the helper) ----------
        if (!empty($app['xi_main_subject_1'])) {
            $chosen = array_values(array_filter(array_map('intval', [$app['xi_main_subject_1'], $app['xi_main_subject_2'], $app['xi_main_subject_3'], $app['xi_additional_subject']])));
            $r = hs_subjects_save((int)$app['session_id'], (int)$app['class_id'], $student_id, $chosen, (int)($_SESSION['admin_id'] ?? 0), false);
            if (!$r['ok']) { throw new RuntimeException('HS subject selection could not be saved: ' . $r['error']); }
        }

        // ---------- 4c) Madhyamik marks ----------
        if (!empty($app['mp_board']) || !empty($app['mp_subjects_json'])) {
            if ($continue) db_execute('DELETE FROM hs_student_mp_marks WHERE student_id = ?', 's', $student_id);   // this result replaces an older one
            $mp_data = [
                'student_id'          => ['v' => $student_id, 't' => 's'],
                'application_id'      => ['v' => $app_id, 't' => 'i'],
                'mp_board'            => ['v' => $app['mp_board'], 't' => 's'],
                'mp_year'             => ['v' => $app['mp_year'], 't' => 's'],
                'mp_roll_no'          => ['v' => $app['mp_roll_no'], 't' => 's'],
                'mp_total_marks'      => ['v' => $app['mp_total_marks'], 't' => 'd'],
                'mp_total_full_marks' => ['v' => $app['mp_total_full_marks'], 't' => 'd'],
                'mp_percentage'       => ['v' => $app['mp_percentage'], 't' => 'd'],
            ];
            $mp_marks_id = db_insert_assoc($conn, 'hs_student_mp_marks', $mp_data);
            if (!$mp_marks_id) { throw new RuntimeException('Madhyamik marks could not be saved.'); }

            if ($mp_marks_id) {
                $mp_subjects = json_decode($app['mp_subjects_json'] ?? '[]', true);
                if (!empty($mp_subjects)) {
                    foreach ($mp_subjects as $sub) {
                        $subj_name = trim($sub['subject'] ?? '');
                        if ($subj_name === '') continue;
                        $subj_data = [
                            'mp_marks_id'    => ['v' => $mp_marks_id, 't' => 'i'],
                            'subject_name'   => ['v' => $subj_name, 't' => 's'],
                            'full_marks'     => ['v' => $sub['full_marks'] ?? null, 't' => 'd'],
                            'marks_obtained' => ['v' => $sub['marks_obtained'] ?? null, 't' => 'd'],
                        ];
                        if (!db_insert_assoc($conn, 'hs_student_mp_subject_marks', $subj_data)) { throw new RuntimeException('Madhyamik subject marks could not be saved.'); }
                    }
                }
            }
        }

        $enroll_stmt = mysqli_prepare($conn, "UPDATE admission_applications SET application_status='Enrolled', admitted_student_id=? WHERE id=? AND application_status='Admitted'");
        mysqli_stmt_bind_param($enroll_stmt, 'si', $student_id, $app_id);
        if (!mysqli_stmt_execute($enroll_stmt) || mysqli_stmt_affected_rows($enroll_stmt) !== 1) { mysqli_stmt_close($enroll_stmt); throw new RuntimeException('Application status update failed.'); }
        mysqli_stmt_close($enroll_stmt);
        mysqli_commit($conn);

        if ($continue) {
            log_action((int)($_SESSION['admin_id'] ?? 0), 'ADMISSION_CONTINUED', 'students', $student_id, null,
                ['application' => $app['application_ref'], 'session_id' => (int)$app['session_id'], 'class_id' => (int)$app['class_id']]);
            $_SESSION['success'] = "✅ {$continue['student_name']} continues with the same School UID {$student_id} — now in Class {$app['class_name']}. Anything else that needs correcting can be done from here.";
        } else {
            $_SESSION['success'] = "✅ Student enrolled successfully! Anything else that needs correcting can be done from here.";
        }
        header('Location: ' . student_page_url('edit_student.php', $student_id));
        exit();
        } catch (Throwable $e) {
            mysqli_rollback($conn);
            error_log('Admission finalize failed for application ' . $app_id . ': ' . $e->getMessage());
            $error = ($e instanceof RuntimeException && stripos($e->getMessage(), 'already belongs') !== false)
                ? 'Enrollment failed: ' . $e->getMessage() . ' No database changes were saved.'
                : 'Enrollment failed. No database changes were saved. Please check the data and try again.';
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalize Enrollment</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .card-box { background:#fff; border:1px solid #e4edf6; border-radius:12px; padding:22px; max-width:800px; }
        .section-title { font-size:14px; font-weight:700; color:#003366; margin:20px 0 12px; padding-bottom:6px; border-bottom:2px solid #e4edf6; }
        .section-title:first-child { margin-top:0; }
        .form-row { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-bottom:14px; }
        .form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:14px; margin-bottom:14px; }
        .form-group label { display:block; font-weight:600; font-size:13px; color:#1a3b55; margin-bottom:5px; }
        .form-group input, .form-group select { width:100%; padding:9px 12px; border:2px solid #e4edf6; border-radius:8px; font-size:14px; box-sizing:border-box; }
        .na-check { display:flex; align-items:center; gap:6px; margin-top:5px; font-size:12px; color:#6c7a8a; }
        .info-strip { background:#e8f4ff; border-left:4px solid #003366; padding:10px 14px; border-radius:0 8px 8px 0; margin-bottom:18px; font-size:13px; color:#1a3b55; }
        .btn-save { padding:11px 28px; background:#28a745; color:#fff; border:none; border-radius:8px; font-weight:700; font-size:14px; cursor:pointer; }
        .alert-danger { background:#f8d7da; color:#721c24; padding:10px 16px; border-radius:8px; margin-bottom:16px; }
        .doc-links { display:flex; gap:14px; flex-wrap:wrap; margin-bottom:18px; }
        .doc-links a { background:#f0f4f9; padding:8px 14px; border-radius:8px; font-size:12px; text-decoration:none; color:#1a3b55; font-weight:600; }
        .readonly-field { background-color: #f4f7fa; cursor: not-allowed; }
        @media (max-width:700px) { .form-row, .form-row-3 { grid-template-columns:1fr; } }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-title" style="margin-bottom:14px;"><i class="fas fa-user-graduate"></i> Finalize Enrollment</div>

    <div class="info-strip">
        <strong><?php echo htmlspecialchars($app['student_name']); ?></strong> — Ref: <?php echo htmlspecialchars($app['application_ref']); ?> |
        Class: <?php echo htmlspecialchars($app['class_name']); ?>
    </div>

    <?php if (!empty($app['mp_board']) || !empty($app['mp_subjects_json'])): ?>
    <div class="info-strip" style="border-left-color:#4f9c8c; background:#eaf7f2; color:#1c6e5a;">
        <strong><i class="fas fa-book"></i> Madhyamik Details:</strong>
        Board: <?php echo htmlspecialchars($app['mp_board'] ?? '-'); ?> |
        Year: <?php echo htmlspecialchars($app['mp_year'] ?? '-'); ?> |
        Roll No: <?php echo htmlspecialchars($app['mp_roll_no'] ?? '-'); ?> |
        Total: <?php echo htmlspecialchars($app['mp_total_marks'] ?? '-'); ?> / <?php echo htmlspecialchars($app['mp_total_full_marks'] ?? '-'); ?> |
        Percentage: <?php echo htmlspecialchars($app['mp_percentage'] ?? '-'); ?>%
        <?php
            $mp_subjects = json_decode($app['mp_subjects_json'] ?? '[]', true);
            if (!empty($mp_subjects)):
        ?>
        <table style="width:100%; margin-top:10px; border-collapse:collapse; font-size:12.5px;">
            <thead><tr><th style="text-align:left; padding:5px 8px; border-bottom:1px solid #c7e6dc;">Subject</th><th style="text-align:left; padding:5px 8px; border-bottom:1px solid #c7e6dc;">Full Marks</th><th style="text-align:left; padding:5px 8px; border-bottom:1px solid #c7e6dc;">Marks Obtained</th></tr></thead>
            <tbody>
                <?php foreach ($mp_subjects as $sub): ?>
                <tr>
                    <td style="padding:4px 8px;"><?php echo htmlspecialchars($sub['subject'] ?? ''); ?></td>
                    <td style="padding:4px 8px;"><?php echo htmlspecialchars($sub['full_marks'] ?? ''); ?></td>
                    <td style="padding:4px 8px;"><?php echo htmlspecialchars($sub['marks_obtained'] ?? ''); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($app['xi_main_subject_1'])):
        $xi_subj_ids = array_filter([$app['xi_main_subject_1'], $app['xi_main_subject_2'], $app['xi_main_subject_3'], $app['xi_additional_subject']]);
        $xi_subj_names = [];
        if (!empty($xi_subj_ids)) {
            $ids_csv = implode(',', array_map('intval', $xi_subj_ids));
            $sr = mysqli_query($conn, "SELECT id, subject_name FROM subjects WHERE id IN ($ids_csv)");
            while ($srow = mysqli_fetch_assoc($sr)) { $xi_subj_names[$srow['id']] = $srow['subject_name']; }
        }
    ?>
    <div class="info-strip" style="border-left-color:#4f9c8c; background:#eaf7f2; color:#1c6e5a;">
        <strong><i class="fas fa-list-ol"></i> Class XI Subject Choice:</strong>
        Main 1: <?php echo htmlspecialchars($xi_subj_names[$app['xi_main_subject_1']] ?? '-'); ?> |
        Main 2: <?php echo htmlspecialchars($xi_subj_names[$app['xi_main_subject_2']] ?? '-'); ?> |
        Main 3: <?php echo htmlspecialchars($xi_subj_names[$app['xi_main_subject_3']] ?? '-'); ?> |
        Additional: <?php echo htmlspecialchars($xi_subj_names[$app['xi_additional_subject']] ?? '-'); ?>
    </div>
    <?php endif; ?>

    <div class="doc-links">
        <?php foreach (ADM_DOCS as $__k => $__d): if (empty($app[$__k])) continue; ?>
        <a href="<?php echo htmlspecialchars('admission_doc.php?id=' . (int)$app['id'] . '&type=' . $__k); ?>" target="_blank"><i class="fas fa-file"></i> <?php echo htmlspecialchars($__d[0]); ?></a>
        <?php endforeach; ?>
    </div>

    <?php if (isset($same['conflict']) && !$error): ?><div class="alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($same['conflict']); ?></div><?php endif; ?>
    <?php if ($continue): $last = db_get_row('SELECT c.class_name, a.session_name FROM student_academic_history h JOIN classes c ON c.id = h.class_id JOIN academic_sessions a ON a.id = h.session_id WHERE h.student_id = ? ORDER BY h.id DESC LIMIT 1', 's', $continue['id']); ?>
    <div class="info-strip" style="border-left-color:#1b7a3a; background:#eaf7ee; color:#1b5e20;">
        <strong><i class="fas fa-user-check"></i> A student of this school:</strong> <?php echo htmlspecialchars($continue['id'] . ' ' . $continue['student_name']); ?>
        · Father <?php echo htmlspecialchars($continue['father_name'] ?? '—'); ?> · DOB <?php echo htmlspecialchars($continue['dob']); ?>
        · last <?php echo $last ? htmlspecialchars('Class ' . $last['class_name'] . ' (' . $last['session_name'] . ')') : '—'; ?> · <?php echo htmlspecialchars($continue['student_status']); ?>
        · found by <?php echo htmlspecialchars(implode(', ', $same['by'])); ?>.<br>
        Finalize continues this student with the same School UID — no new student is made, and the guardian stays linked.
        <?php if ($continue_problem !== ''): ?><br><b style="color:#c62828"><?php echo htmlspecialchars($continue_problem); ?></b><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?><div class="alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="card-box">
        <p style="font-size:12px; color:#6c7a8a; margin-top:0;"><i class="fas fa-info-circle"></i> Everything below is filled in from the online application. Check it against the documents, correct whatever is needed, then give the Section and Roll No and finalize.</p>
        <form method="POST" id="finalizeForm"<?php echo $continue ? ' data-checked="true"' : ''; /* a continued student keeps their guardian: no guardian check */ ?>>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="app_id" value="<?php echo $app_id; ?>">
            <input type="hidden" name="existing_guardian_id" id="existing_guardian_id" value="0">

            <div class="section-title">Student Information</div>
            <div class="form-row">
                <div class="form-group"><label>Student Name *</label><input type="text" name="student_name" required value="<?php echo v($app,'student_name'); ?>"></div>
                <div class="form-group"><label>Name as per Aadhaar</label><input type="text" name="name_as_per_aadhaar" value="<?php echo v($app,'name_as_per_aadhaar'); ?>"></div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>DOB</label><input type="date" name="dob" value="<?php echo v($app,'dob'); ?>"></div>
                <div class="form-group"><label>Gender</label>
                    <select name="gender">
                        <?php foreach (['','Male','Female','Other'] as $g): ?>
                        <option value="<?php echo $g; ?>" <?php echo ($app['gender'] === $g) ? 'selected' : ''; ?>><?php echo $g ?: 'Select'; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Blood Group</label><input type="text" name="blood_group" value="<?php echo v($app,'blood_group'); ?>"></div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>Religion</label><input type="text" name="religion" value="<?php echo v($app,'religion'); ?>"></div>
                <div class="form-group"><label>Caste</label><input type="text" name="caste" value="<?php echo v($app,'caste'); ?>"></div>
                <div class="form-group"><label>Sub Caste</label><input type="text" name="sub_caste" value="<?php echo v($app,'sub_caste'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Disability</label><input type="text" name="disability" value="<?php echo v($app,'disability'); ?>"></div>
                <div class="form-group"><label>Disability Type</label><input type="text" name="disability_type" value="<?php echo v($app,'disability_type'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Birth Registration No.</label><input type="text" name="birth_registration_number" value="<?php echo v($app,'birth_registration_number'); ?>"></div>
                <div class="form-group"><label>Student Aadhaar No.</label><input type="text" id="stu_aadhaar" name="student_aadhaar" maxlength="12" value="<?php echo v($app,'student_aadhaar'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Student Mobile</label><input type="text" name="student_mobile" value="<?php echo v($app,'student_mobile'); ?>"></div>
                <div class="form-group"><label>Student Email</label><input type="email" name="student_email" value="<?php echo v($app,'student_email'); ?>"></div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>Banglar Shiksha ID</label><input type="text" name="banglarshiksha_id" value="<?php echo v($app,'banglarshiksha_id'); ?>"></div>
                <div class="form-group"><label>PEN ID</label><input type="text" name="pen_id" value="<?php echo v($app,'pen_id'); ?>"></div>
                <div class="form-group"><label>APAAR ID</label><input type="text" name="apaar_id" value="<?php echo v($app,'apaar_id'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Previous School</label><input type="text" name="previous_school" value="<?php echo v($app,'previous_school'); ?>"></div>
            </div>

            <div class="section-title">Guardian Information</div>
            <div class="form-row">
                <div class="form-group"><label>Father Name *</label><input type="text" name="father_name" required value="<?php echo v($app,'father_name'); ?>"></div>
                <div class="form-group">
                    <label>Father Aadhaar (12 digit)</label>
                    <input type="text" name="father_aadhaar" maxlength="12" id="fa_aadhaar" value="<?php echo v($app,'father_aadhaar'); ?>" <?php echo !empty($app['father_aadhaar_not_available']) ? 'disabled' : ''; ?>>
                    <div class="na-check"><input type="checkbox" name="father_aadhaar_na" id="fa_na" onchange="document.getElementById('fa_aadhaar').disabled=this.checked;" <?php echo !empty($app['father_aadhaar_not_available']) ? 'checked' : ''; ?>> Not Available</div>
                </div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>Father Voter ID</label><input type="text" name="father_voter_id" value="<?php echo v($app,'father_voter_id'); ?>"></div>
                <div class="form-group"><label>Father Mobile</label><input type="text" name="father_mobile" value="<?php echo v($app,'father_mobile'); ?>"></div>
                <div class="form-group"><label>Father Occupation</label><input type="text" name="father_occupation" value="<?php echo v($app,'father_occupation'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Father Qualification</label><input type="text" name="father_qualification" value="<?php echo v($app,'father_qualification'); ?>"></div>
                <div class="form-group"><label>Annual Income (₹)</label><input type="number" step="0.01" name="annual_income" value="<?php echo v($app,'annual_income'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Mother Name *</label><input type="text" name="mother_name" required value="<?php echo v($app,'mother_name'); ?>"></div>
                <div class="form-group">
                    <label>Mother Aadhaar (12 digit)</label>
                    <input type="text" name="mother_aadhaar" maxlength="12" id="ma_aadhaar" value="<?php echo v($app,'mother_aadhaar'); ?>" <?php echo !empty($app['mother_aadhaar_not_available']) ? 'disabled' : ''; ?>>
                    <div class="na-check"><input type="checkbox" name="mother_aadhaar_na" id="ma_na" onchange="document.getElementById('ma_aadhaar').disabled=this.checked;" <?php echo !empty($app['mother_aadhaar_not_available']) ? 'checked' : ''; ?>> Not Available</div>
                </div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>Mother Voter ID</label><input type="text" name="mother_voter_id" value="<?php echo v($app,'mother_voter_id'); ?>"></div>
                <div class="form-group"></div>
                <div class="form-group"><label>Mother Occupation</label><input type="text" name="mother_occupation" value="<?php echo v($app,'mother_occupation'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Guardian Name</label><input type="text" name="guardian_name" value="<?php echo v($app,'guardian_name'); ?>"></div>
                <div class="form-group"><label>Guardian Relation</label><input type="text" name="guardian_relation" value="<?php echo v($app,'guardian_relation'); ?>"></div>
            </div>
            <div class="form-group"><label>Guardian Contact</label><input type="text" name="guardian_contact" value="<?php echo htmlspecialchars($_POST['guardian_contact'] ?? $app['guardian_mobile']); ?>"></div>

            <div class="section-title">Address</div>
            <div class="form-row">
                <div class="form-group"><label>Village/Street</label><input type="text" name="village" value="<?php echo v($app,'village'); ?>"></div>
                <div class="form-group"><label>Post Office</label><input type="text" name="post_office" value="<?php echo v($app,'post_office'); ?>"></div>
            </div>
            <div class="form-row-3">
                <div class="form-group"><label>Police Station</label><input type="text" name="police_station" value="<?php echo v($app,'police_station'); ?>"></div>
                <div class="form-group"><label>District</label><input type="text" name="district" value="<?php echo v($app,'district'); ?>"></div>
                <div class="form-group"><label>State</label><input type="text" name="state" value="<?php echo v($app,'state'); ?>"></div>
            </div>
            <div class="form-group" style="max-width:200px; margin-bottom:14px;"><label>PIN Code</label><input type="text" name="pin_code" value="<?php echo v($app,'pin_code'); ?>"></div>

            <div class="section-title">Bank Details</div>
            <div class="form-row">
                <div class="form-group"><label>IFSC Code</label><input type="text" name="ifsc_code" id="ifsc_code" maxlength="11" value="<?php echo v($app,'ifsc_code'); ?>"></div>
                <div class="form-group"><label>Account Number</label><input type="text" name="account_number" value="<?php echo v($app,'account_number'); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Bank Name</label><input type="text" name="bank_name" id="bank_name" class="readonly-field" readonly value="<?php echo v($app,'bank_name'); ?>"></div>
                <div class="form-group"><label>Branch Name</label><input type="text" name="branch_name" id="branch_name" class="readonly-field" readonly value="<?php echo v($app,'branch_name'); ?>"></div>
            </div>

            <div class="section-title">Class Assignment</div>
            <div class="form-row">
                <div class="form-group">
                    <label>Section *</label>
                    <select name="section_id" required>
                        <option value="">-- Select --</option>
                        <?php while ($sec = mysqli_fetch_assoc($sections)): ?>
                        <option value="<?php echo $sec['id']; ?>"><?php echo htmlspecialchars($sec['section_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group"><label>Roll No *</label><input type="text" name="roll_no" required></div>
            </div>

            <button type="submit" name="finalize" class="btn-save"<?php echo isset($same['conflict']) || $continue_problem !== '' ? ' disabled' : ''; ?>><i class="fas fa-check-circle"></i> <?php echo $continue ? 'Continue this student &amp; Enroll' : 'Create Student &amp; Enroll'; ?></button>
        </form>
    </div>
</div>

<script>
// ----- Aadhaar Validation Verhoeff Algorithm -----
const d = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7], [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3], [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]
];
const p = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7], [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]
];

function validateAadhaar(aadhaar) {
    if (aadhaar.length !== 12 || !/^\d+$/.test(aadhaar)) return false;
    let c = 0;
    let invertedArray = aadhaar.split('').reverse().map(Number);
    for (let i = 0; i < invertedArray.length; i++) {
        c = d[c][p[i % 8][invertedArray[i]]];
    }
    return c === 0;
}

function attachAadhaarLiveCheck(inputId) {
    const input = document.getElementById(inputId);
    if (!input) return;

    const errorSpan = document.createElement('span');
    errorSpan.style.color = 'red';
    errorSpan.style.fontSize = '12px';
    errorSpan.style.display = 'none';
    errorSpan.style.marginTop = '4px';
    errorSpan.innerHTML = '<i class="fas fa-times-circle"></i> Invalid Aadhaar Number!';
    input.parentNode.appendChild(errorSpan);

    input.addEventListener('input', function() {
        this.value = this.value.replace(/\D/g, ''); 
        const val = this.value;
        const submitBtn = document.querySelector('button[name="finalize"]');

        if (val.length === 12) {
            if (validateAadhaar(val)) {
                errorSpan.style.display = 'none';
                this.style.borderColor = 'green';
                submitBtn.disabled = false;
            } else {
                errorSpan.style.display = 'block';
                this.style.borderColor = 'red';
                submitBtn.disabled = true;
            }
        } else if (val.length > 0 && val.length < 12) {
            errorSpan.style.display = 'none';
            this.style.borderColor = '#e4edf6';
            submitBtn.disabled = false;
        }
    });
}

attachAadhaarLiveCheck('fa_aadhaar');
attachAadhaarLiveCheck('ma_aadhaar');
attachAadhaarLiveCheck('stu_aadhaar');


// ----- IFSC Live Fetch API -----
const ifscInput = document.getElementById('ifsc_code');
const bankNameInput = document.getElementById('bank_name');
const branchNameInput = document.getElementById('branch_name');

if(ifscInput) {
    const ifscError = document.createElement('span');
    ifscError.style.color = 'red';
    ifscError.style.fontSize = '12px';
    ifscError.style.display = 'none';
    ifscError.style.marginTop = '4px';
    ifscError.innerHTML = '<i class="fas fa-times-circle"></i> Invalid IFSC Code!';
    ifscInput.parentNode.appendChild(ifscError);

    ifscInput.addEventListener('input', function() {
        this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
        let val = this.value;
        const submitBtn = document.querySelector('button[name="finalize"]');

        if (val.length === 11) {
            fetch('https://ifsc.razorpay.com/' + val)
            .then(response => {
                if(response.ok) return response.json();
                throw new Error('Invalid IFSC');
            })
            .then(data => {
                bankNameInput.value = data.BANK;
                branchNameInput.value = data.BRANCH;
                ifscError.style.display = 'none';
                this.style.borderColor = 'green';
                submitBtn.disabled = false;
            })
            .catch(err => {
                bankNameInput.value = '';
                branchNameInput.value = '';
                ifscError.style.display = 'block';
                this.style.borderColor = 'red';
                submitBtn.disabled = true;
            });
        } else {
            bankNameInput.value = '';
            branchNameInput.value = '';
            ifscError.style.display = 'none';
            this.style.borderColor = '#e4edf6';
        }
    });
}

// ----- Guardian Popup Check Logic -----
document.getElementById('finalizeForm').addEventListener('submit', function(e) {
    if (this.dataset.checked === 'true') return true;
    
    e.preventDefault();
    let form = this;
    let submitBtn = form.querySelector('button[name="finalize"]');
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking Guardian...';
    submitBtn.disabled = true;

    let params = new URLSearchParams({
        father_aadhaar: document.getElementById('fa_aadhaar') ? document.getElementById('fa_aadhaar').value : '',
        mother_aadhaar: document.getElementById('ma_aadhaar') ? document.getElementById('ma_aadhaar').value : '',
        father_mobile: form.querySelector('input[name="father_mobile"]').value,
        guardian_contact: form.querySelector('input[name="guardian_contact"]').value,
        father_name: form.querySelector('input[name="father_name"]').value,
        mother_name: form.querySelector('input[name="mother_name"]').value,
        guardian_name: form.querySelector('input[name="guardian_name"]').value
    });

    fetch('check_guardian_match.php?' + params.toString())
    .then(response => response.json())
    .then(data => {
        if (data.matched) {
            let sibText = data.siblings.map(s => s.name + " (Class: " + s.class + ")").join(", ");
            let msg = "This guardian (" + data.guardian_label + ") already has " + data.sibling_count + " student(s) in the school:\n" +
                      sibText + "\n\nLink this new student to that same guardian?\n\n" +
                      "[OK] links them; [Cancel] makes a new guardian.";
            
            if (confirm(msg)) {
                document.getElementById('existing_guardian_id').value = data.guardian_id;
            } else {
                document.getElementById('existing_guardian_id').value = 0;
            }
        } else {
            document.getElementById('existing_guardian_id').value = 0;
        }
        form.dataset.checked = 'true';
        form.submit();
    })
    .catch(error => {
        console.error('Guardian checking error:', error);
        form.dataset.checked = 'true';
        form.submit();
    });
});
</script>

</body>
</html>
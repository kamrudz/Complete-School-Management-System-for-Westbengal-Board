<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/admission_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Merit List: Class XI applications in order of the Madhyamik percentage — the higher total first when two are level,
 * and the earlier application first when those are level too. Seats for each subject are counted as the list is walked,
 * so "Select by seats" takes everyone who fits and puts the rest on the waiting list.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$settings = adm_settings();
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$session_id = (int)$in('session_id', 0) ?: (int)$settings['admission_session_id'];
if (!isset($sessions[$session_id])) $session_id = adm_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$hs_classes = array_filter(adm_open_classes($session_id), fn($c) => $c['stage'] === 'higher_secondary');
if (!$hs_classes) $hs_classes = array_filter($classes, fn($c) => $c['stage'] === 'higher_secondary');
$class_id = (int)$in('class_id', 0);
if (!isset($hs_classes[$class_id])) $class_id = (int)array_key_first($hs_classes);
$q = array_filter(['session_id' => $session_id, 'class_id' => $class_id ?: null]);
$self = fn(array $over = []) => 'admission_merit.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));
$go = function (string $kind = '', string $msg = '') use ($self) {
    if ($kind !== '') $_SESSION[$kind] = $msg;
    header('Location: ' . $self());
    exit();
};

$subject_seats = adm_subject_seats($session_id);
$subject_names = $class_id ? adm_xi_subjects($session_id, $class_id) : [];
$class_seats = $class_id ? (adm_open_classes($session_id)[$class_id]['seats'] ?? null) : null;
$min_percent = $class_id ? (adm_open_classes($session_id)[$class_id]['min_percent'] ?? null) : null;

/**
 * The list in merit order, each row carrying what it would take: 'rank', 'subjects' (ids), and — walking down from the
 * top — 'fits' (the seats are there) or why not. Applications already Enrolled or Rejected keep their place but take no seat.
 */
function merit_rows(int $session_id, int $class_id, array $subject_seats, ?int $class_seats, $min_percent): array {
    $rows = db_get_all("SELECT aa.*, c.class_name FROM admission_applications aa JOIN classes c ON c.id = aa.class_id
        WHERE aa.session_id = ? AND aa.class_id = ? AND aa.application_status <> 'Rejected'
        ORDER BY aa.mp_percentage IS NULL, aa.mp_percentage DESC, aa.mp_total_marks DESC, aa.created_at, aa.id", 'ii', $session_id, $class_id);
    $used = [];
    $taken = 0;
    $rank = 0;
    foreach ($rows as &$r) {
        $r['rank'] = ++$rank;
        $r['subjects'] = array_values(array_filter(array_map('intval', [$r['xi_main_subject_1'], $r['xi_main_subject_2'], $r['xi_main_subject_3'], $r['xi_additional_subject']])));
        $r['why'] = '';
        if ($min_percent !== null && (float)$r['mp_percentage'] < (float)$min_percent) $r['why'] = 'below the lowest %';
        elseif ($class_seats !== null && $taken >= $class_seats) $r['why'] = 'the class is full';
        else {
            foreach ($r['subjects'] as $sid) {
                if (isset($subject_seats[$sid]) && ($used[$sid] ?? 0) >= $subject_seats[$sid]) { $r['why'] = 'a subject is full'; break; }
            }
        }
        $r['fits'] = $r['why'] === '';
        if ($r['fits']) {
            $taken++;
            foreach ($r['subjects'] as $sid) $used[$sid] = ($used[$sid] ?? 0) + 1;
        }
    }
    unset($r);
    return [$rows, $used, $taken];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    try {
        if (!$class_id) throw new RuntimeException('Choose the class.');
        if (($_POST['act'] ?? '') !== 'select') throw new RuntimeException('Nothing to do.');
        [$rows] = merit_rows($session_id, $class_id, $subject_seats, $class_seats, $min_percent);
        $pick = []; $wait = [];
        foreach ($rows as $r) {
            if (in_array($r['application_status'], ['Enrolled', 'Rejected'], true)) continue;
            if ($r['fits']) $pick[] = (int)$r['id']; else $wait[] = (int)$r['id'];
        }
        if (!$pick && !$wait) throw new RuntimeException('There is nothing to go through yet.');
        db_begin_transaction();
        try {
            foreach ([['Admitted', $pick], ['Waitlisted', $wait]] as [$to, $ids]) {
                if (!$ids) continue;
                db_execute("UPDATE admission_applications SET application_status = ?, merit_rank = NULL WHERE id IN (" . implode(',', array_fill(0, count($ids), '?')) . ")",
                    's' . str_repeat('i', count($ids)), $to, ...$ids);
            }
            foreach ($rows as $r) db_execute('UPDATE admission_applications SET merit_rank = ? WHERE id = ?', 'ii', (int)$r['rank'], (int)$r['id']);
            db_commit();
        } catch (Throwable $e) {
            db_rollback();
            throw new RuntimeException('Nothing was changed: ' . $e->getMessage());
        }
        adm_log($admin_id, 'ADMISSION_MERIT_SELECTED', null, null, ['session' => exam_session_name($session_id), 'class' => $classes[$class_id]['name'] ?? '', 'selected' => count($pick), 'waiting' => count($wait)]);
        $go('success', count($pick) . ' selected, ' . count($wait) . ' on the waiting list.');
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage());
    }
    $go();
}

[$rows, $used, $taken] = $class_id ? merit_rows($session_id, $class_id, $subject_seats, $class_seats, $min_percent) : [[], [], 0];
$session_name = exam_session_name($session_id);
$class_name = $class_id ? ($classes[$class_id]['name'] ?? '') : '';

if (!empty($_GET['export']) && $rows) {
    $out = exam_xlsx_title("Merit list · Class $class_name · $session_name");
    $out[] = ['Rank', 'Application No.', 'Student', 'Father', 'Mobile', 'Madhyamik %', 'Total', 'Subjects', 'Seats', 'Status'];
    foreach ($rows as $r) {
        $out[] = [(int)$r['rank'], $r['application_ref'], $r['student_name'], (string)$r['father_name'], (string)$r['guardian_mobile'],
            $r['mp_percentage'] !== null ? (float)$r['mp_percentage'] : '', $r['mp_total_marks'] !== null ? (float)$r['mp_total_marks'] : '',
            implode(', ', array_map(fn($sid) => $subject_names[$sid] ?? "#$sid", $r['subjects'])),
            $r['fits'] ? 'Fits' : $r['why'], ADM_STATUS[$r['application_status']][0] ?? $r['application_status']];
    }
    SimpleXLSXWriter::download("Merit_list_Class_{$class_name}_$session_name.xlsx", $out, 'Merit', exam_xlsx_opts(10, 26));
    exit();
}
$done = count(array_filter($rows, fn($r) => in_array($r['application_status'], ['Admitted', 'Enrolled'], true)));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Merit List</title>
<?php exam_styles('adm'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.num, .ex-table th.num { text-align: center; font-variant-numeric: tabular-nums; }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; }
    .ex-table tr.no td { color: #98a6b5; }
    .seats { display: flex; gap: 7px; flex-wrap: wrap; margin-top: 8px; }
    .seats span { padding: 4px 10px; border-radius: 999px; border: 1px solid var(--ex-border); background: #fff; font-size: 12px; }
    .seats span.full { background: #fdecea; border-color: #f5b5b0; color: #8e1b1b; font-weight: 700; }
    .print-head { display: none; }
    @media print { nav.main-navbar-2tier, .ex-banner, .ex-tabs, .noprint { display: none !important; } .print-head { display: block; } .card { border: 0; padding: 0; }
        .ex-table td, .ex-table th { white-space: normal !important; padding: 3px 5px !important; font-size: 11px !important; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Merit List', 'Class XI in order of the Madhyamik percentage, with the seats of each subject counted', 'fa-ranking-star',
        ['admission_applications.php' => '<i class="fas fa-list"></i> Applications'] + ($rows ? [$self(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print'] : [])); ?>
    <?php adm_tabs('admission_merit.php'); exam_flash(); ?>

    <form method="get" class="card pick noprint">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><?php foreach ($hs_classes as $cid => $c): ?><option value="<?php echo (int)$cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('MERIT LIST — CLASS ' . mb_strtoupper($class_name), 'Session ' . $session_name . ($min_percent !== null ? ' · lowest ' . rtrim(rtrim($min_percent, '0'), '.') . '%' : '')); ?></div>

    <?php if (!$hs_classes): ?>
    <?php exam_guard('No Higher Secondary class', ' Open Class XI for admission in Admission Settings first.', 'admission_settings.php', 'Admission Settings'); ?>
    <?php elseif (!$rows): ?>
    <div class="ex-empty"><i class="fas fa-ranking-star"></i>No Class <?php echo h($class_name); ?> application in <?php echo h($session_name); ?> yet.</div>
    <?php else: ?>
    <div class="sum noprint">
        <div><b><?php echo count($rows); ?></b><small>applications</small></div>
        <div><b><?php echo $taken; ?></b><small>fit the seats</small></div>
        <div><b><?php echo $done; ?></b><small>selected already</small></div>
        <div><b><?php echo $class_seats === null ? '—' : (int)$class_seats; ?></b><small>seats in the class</small></div>
    </div>
    <?php if ($subject_names): ?>
    <div class="card noprint">
        <h2>Seats, subject by subject <small>as the list above would fill them</small></h2>
        <div class="seats">
            <?php foreach ($subject_names as $sid => $sname): $cap = $subject_seats[$sid] ?? null; $u = (int)($used[$sid] ?? 0); ?>
            <span class="<?php echo $cap !== null && $u >= $cap ? 'full' : ''; ?>"><?php echo h($sname); ?>: <b><?php echo $u; ?></b><?php echo $cap !== null ? ' / ' . (int)$cap : ''; ?></span>
            <?php endforeach; ?>
        </div>
        <p class="note">A subject with no number has no limit. Set them in <a href="admission_settings.php?<?php echo h(http_build_query(['session_id' => $session_id])); ?>#subjects">Admission Settings</a>.</p>
    </div>
    <?php endif; ?>

    <form method="post" class="card noprint" onsubmit="return confirm('Select by the merit list? Everyone who does not fit the seats goes on the waiting list.')" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="act" value="select">
        <div><b>Select by seats</b><div class="note" style="margin:2px 0 0">Going down the list above, everyone who fits the seats is selected and the rest go on the waiting list. Applications already rejected or enrolled are left alone.</div></div>
        <button type="submit" class="btn btn-success" style="margin-left:auto"><i class="fas fa-check-double"></i> Select <?php echo $taken; ?></button>
    </form>

    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th class="num">#</th><th>Student</th><th>Application</th><th class="num">Madhyamik</th><th>Subjects</th><th>Seats</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
            <tr class="<?php echo $r['fits'] ? '' : 'no'; ?>">
                <td class="num"><b><?php echo (int)$r['rank']; ?></b></td>
                <td><b><?php echo h($r['student_name']); ?></b><small><?php echo h($r['father_name'] ?: ''); ?><?php echo $r['guardian_mobile'] ? ' · ' . h($r['guardian_mobile']) : ''; ?></small></td>
                <td><?php echo h($r['application_ref']); ?><small><?php echo h(date('d M Y', strtotime($r['created_at']))); ?></small></td>
                <td class="num"><b><?php echo $r['mp_percentage'] !== null ? h(rtrim(rtrim($r['mp_percentage'], '0'), '.')) . '%' : '—'; ?></b>
                    <small><?php echo $r['mp_total_marks'] !== null ? h(rtrim(rtrim($r['mp_total_marks'], '0'), '.')) . ' / ' . h(rtrim(rtrim($r['mp_total_full_marks'], '0'), '.')) : ''; ?></small></td>
                <td style="font-size:12px"><?php echo h(implode(', ', array_map(fn($sid) => $subject_names[$sid] ?? "#$sid", $r['subjects']))); ?></td>
                <td><?php echo $r['fits'] ? '<span class="chip ok">Fits</span>' : '<span class="chip warn">' . h($r['why']) . '</span>'; ?></td>
                <td><span class="chip <?php echo h(ADM_STATUS[$r['application_status']][1] ?? 'off'); ?>"><?php echo h(ADM_STATUS[$r['application_status']][0] ?? $r['application_status']); ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <p class="note">Order: the Madhyamik percentage, then the total marks, then whoever applied first. Rejected applications are left out.</p>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

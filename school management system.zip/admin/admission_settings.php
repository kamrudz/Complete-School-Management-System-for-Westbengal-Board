<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/admission_helper.php';
require_once '../includes/centre_helper.php';
require_once '../includes/exam_ui.php';

/** Admission Settings: when admission is open, which classes and how many seats, Class XI subject seats, and what each stage must give. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$settings = adm_settings();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0) ?: (int)$settings['admission_session_id'];
if (!isset($sessions[$session_id])) $session_id = adm_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$go = function (string $kind = '', string $msg = '', string $anchor = '') use ($session_id) {
    if ($kind !== '') $_SESSION[$kind] = $msg;
    header('Location: admission_settings.php?' . http_build_query(['session_id' => $session_id]) . $anchor);
    exit();
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'save_window') {
            $target = (int)($_POST['admission_session_id'] ?? 0);
            if (!isset($sessions[$target])) throw new RuntimeException('Choose the session admission is for.');
            $date = function (string $k): ?string {
                $v = trim((string)($_POST[$k] ?? ''));
                if ($v === '') return null;
                $d = DateTime::createFromFormat('!Y-m-d', $v);
                if (!$d || $d->format('Y-m-d') !== $v) throw new RuntimeException('Give a date in the right form.');
                return $v;
            };
            $start = $date('admission_start');
            $end = $date('admission_end');
            if ($start && $end && $start > $end) throw new RuntimeException('The last date cannot be before the starting date.');
            $data = ['admission_open' => !empty($_POST['admission_open']) ? 1 : 0, 'admission_session_id' => $target,
                'admission_start' => $start, 'admission_end' => $end, 'admission_notice' => mb_substr(trim((string)($_POST['admission_notice'] ?? '')), 0, 1000) ?: null];
            $mode = (string)($_POST['admission_mode'] ?? 'public');
            if (!isset(ADM_MODES[$mode])) throw new RuntimeException('Choose who may apply.');
            if ($mode === 'centres' && !db_get_row('SELECT 1 FROM admission_centres WHERE is_active = 1')) throw new RuntimeException('Add at least one centre that is switched on before sending every applicant to the centres.');
            $data['admission_mode'] = $mode;
            db_update('school_settings', $data, ['id' => 1], 'i');
            adm_log($admin_id, 'ADMISSION_WINDOW_SAVED', null, $settings, $data);
            $go('success', 'Saved. ' . (adm_closed_reason($data + $settings) ?: 'The form is taking applications now.'));
        }
        if ($act === 'save_classes') {
            $rows = json_decode((string)($_POST['rows'] ?? ''), true);
            if (!is_array($rows)) throw new RuntimeException('The classes did not arrive — try again.');
            $keep = [];
            foreach ($rows as $r) {
                $cid = (int)($r['class'] ?? 0);
                if (!isset($classes[$cid]) || empty($r['on'])) continue;
                $seats = trim((string)($r['seats'] ?? ''));
                $min = trim((string)($r['min'] ?? ''));
                if ($seats !== '' && !preg_match('/^\d{1,4}$/', $seats)) throw new RuntimeException("Class {$classes[$cid]['name']}: seats must be a number up to 9999.");
                if ($min !== '' && (!is_numeric($min) || (float)$min < 0 || (float)$min > 100)) throw new RuntimeException("Class {$classes[$cid]['name']}: the lowest % must be between 0 and 100.");
                $keep[$cid] = ['seats' => $seats !== '' ? (int)$seats : null, 'min' => $min !== '' ? number_format((float)$min, 2, '.', '') : null];
            }
            db_begin_transaction();
            try {
                db_execute('DELETE FROM class_admission_seats WHERE session_id = ?' . ($keep ? ' AND class_id NOT IN (' . implode(',', array_keys($keep)) . ')' : ''), 'i', $session_id);
                foreach ($keep as $cid => $r) {
                    db_execute('INSERT INTO class_admission_seats (session_id, class_id, seats, min_percent) VALUES (?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE seats = VALUES(seats), min_percent = VALUES(min_percent)', 'iiis', $session_id, $cid, $r['seats'], $r['min']);
                }
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The classes could not be saved: ' . $e->getMessage());
            }
            adm_log($admin_id, 'ADMISSION_CLASSES_SAVED', null, null, ['session' => exam_session_name($session_id), 'classes' => count($keep)]);
            $go('success', count($keep) . ' class(es) open for admission in ' . exam_session_name($session_id) . '.');
        }
        if ($act === 'save_subject_seats') {
            $rows = json_decode((string)($_POST['rows'] ?? ''), true);
            if (!is_array($rows)) throw new RuntimeException('The subject seats did not arrive — try again.');
            $xi = 0;
            foreach (adm_open_classes($session_id) as $cid => $c) if ($c['stage'] === 'higher_secondary') { $xi = $cid; break; }
            $offered = $xi ? adm_xi_subjects($session_id, $xi) : [];
            $keep = [];
            foreach ($rows as $sid => $seats) {
                $sid = (int)$sid;
                $seats = trim((string)$seats);
                if (!isset($offered[$sid]) || $seats === '') continue;
                if (!preg_match('/^\d{1,4}$/', $seats)) throw new RuntimeException("{$offered[$sid]}: seats must be a number up to 9999.");
                $keep[$sid] = (int)$seats;
            }
            db_begin_transaction();
            try {
                db_execute('DELETE FROM admission_subject_seats WHERE session_id = ?' . ($keep ? ' AND subject_id NOT IN (' . implode(',', array_keys($keep)) . ')' : ''), 'i', $session_id);
                foreach ($keep as $sid => $seats) db_execute('INSERT INTO admission_subject_seats (session_id, subject_id, seats) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE seats = VALUES(seats)', 'iii', $session_id, $sid, $seats);
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The subject seats could not be saved: ' . $e->getMessage());
            }
            adm_log($admin_id, 'ADMISSION_SUBJECT_SEATS_SAVED', null, null, ['session' => exam_session_name($session_id), 'subjects' => count($keep)]);
            $go('success', 'Class XI subject seats saved.', '#subjects');
        }
        if ($act === 'save_villages') {
            $rule = (string)($_POST['village_rule'] ?? 'all');
            if (!in_array($rule, ['all', 'listed'], true)) throw new RuntimeException('Choose who may apply.');
            $names = [];
            foreach (preg_split('/\r\n|\r|\n|,/', (string)($_POST['villages'] ?? '')) as $line) {
                $name = preg_replace('/\s+/', ' ', trim($line));
                if ($name === '') continue;
                if (mb_strlen($name) > 100) throw new RuntimeException('The village "' . mb_substr($name, 0, 30) . '…" is longer than 100 letters.');
                $names[mb_strtolower($name)] ??= $name;   // the first spelling given is the one kept
            }
            if (count($names) > 300) throw new RuntimeException('Up to 300 villages can be listed.');
            if ($rule === 'listed' && !$names) throw new RuntimeException('List at least one village before keeping admission to the listed villages.');
            db_begin_transaction();
            try {
                db_execute('DELETE FROM admission_villages WHERE session_id = ?', 'i', $session_id);
                foreach ($names as $name) db_execute('INSERT INTO admission_villages (session_id, name) VALUES (?, ?)', 'is', $session_id, $name);
                db_execute('UPDATE school_settings SET admission_village_rule = ? WHERE id = 1', 's', $rule);
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The villages could not be saved: ' . $e->getMessage());
            }
            adm_log($admin_id, 'ADMISSION_VILLAGES_SAVED', null, null, ['session' => exam_session_name($session_id), 'rule' => $rule, 'villages' => count($names)]);
            $go('success', $rule === 'all' ? 'Saved. Students from any village may apply.' : 'Saved. Only students from the ' . count($names) . ' listed village(s) may apply.', '#villages');
        }
        if ($act === 'save_items') {
            $stage = (string)($_POST['stage'] ?? '');
            if (!isset(ADM_STAGES[$stage])) throw new RuntimeException('Choose the stage.');
            $ticked = is_array($_POST['req'] ?? null) ? $_POST['req'] : [];
            db_begin_transaction();
            try {
                db_execute('DELETE FROM admission_requirements WHERE session_id = ? AND stage = ?', 'is', $session_id, $stage);
                foreach (ADM_ITEMS as $item => [, , $asked]) {
                    if (!in_array($stage, $asked, true)) continue;
                    db_execute('INSERT INTO admission_requirements (session_id, stage, item, required) VALUES (?, ?, ?, ?)', 'issi', $session_id, $stage, $item, !empty($ticked[$item]) ? 1 : 0);
                }
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The settings could not be saved: ' . $e->getMessage());
            }
            adm_log($admin_id, 'ADMISSION_ITEMS_SAVED', null, null, ['session' => exam_session_name($session_id), 'stage' => $stage]);
            $go('success', ADM_STAGES[$stage] . ': what must be given is saved.', '#items');
        }
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage());
    }
    $go();
}

$open = adm_open_classes($session_id);
$stage = (string)($_GET['stage'] ?? '');
if (!isset(ADM_STAGES[$stage])) {
    $stages_here = array_values(array_unique(array_map(fn($c) => $c['stage'], $open)));
    $stage = $stages_here[0] ?? 'upper_primary';
}
$need = adm_requirements($session_id, $stage);
$xi_class = 0;
foreach ($open as $cid => $c) if ($c['stage'] === 'higher_secondary') { $xi_class = $cid; break; }
$xi_subjects = $xi_class ? adm_xi_subjects($session_id, $xi_class) : [];
$subject_seats = adm_subject_seats($session_id);
$counts = array_column(db_get_all("SELECT class_id, COUNT(*) n FROM admission_applications WHERE session_id = ? AND application_status <> 'Rejected' GROUP BY class_id", 'i', $session_id), 'n', 'class_id');
$closed = adm_closed_reason($settings);
$session_name = exam_session_name($session_id);
$groups = [];
foreach (ADM_ITEMS as $item => [$label, $group, $asked]) if (in_array($stage, $asked, true)) $groups[$group][$item] = $label;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admission Settings</title>
<?php exam_styles('adm'); ?>
<style>
    .card-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
    .card-head h2 { margin: 0; }
    .card-head .acts { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    .ex-table input.n { width: 86px; height: 32px; text-align: right; border: 1px solid #c9d6e2; border-radius: 6px; padding: 4px 8px; font-size: 13px; font-variant-numeric: tabular-nums; }
    .ex-table input.n.bad { border-color: #d32f2f; background: #fff2f2; }
    .ex-table input[type=checkbox] { width: 17px; height: 17px; accent-color: var(--ex-light); }
    .ex-table tr.off td { color: #98a6b5; }
    .seg { display: inline-flex; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 12px; }
    .seg a { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; }
    .item-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 12px; margin-top: 6px; }
    .item-grid fieldset { border: 1px solid #dfe7ef; border-radius: 10px; padding: 8px 12px 10px; margin: 0; }
    .item-grid legend { font-size: 11.5px; font-weight: 700; color: var(--ex-dark); text-transform: uppercase; padding: 0 4px; }
    .item-grid .chk { display: flex; align-items: center; gap: 8px; margin-top: 7px; font-size: 13px; }
    .item-grid .chk input { width: 17px; height: 17px; accent-color: var(--ex-light); }
    .state { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; font-size: 13px; }
    .pf .row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
    @media (max-width: 760px) { .pf .row3, .pf .row { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Admission Settings', 'When admission is open, which classes and seats, and what each stage must give', 'fa-sliders-h',
        ['admission_applications.php' => '<i class="fas fa-list"></i> Applications', '../admission.php' => '<i class="fas fa-external-link-alt"></i> See the form']); ?>
    <?php adm_tabs('admission_settings.php'); exam_flash(); ?>

    <form method="get" class="card pick">
        <div><label>Settings of session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div class="note" style="margin:0 0 0 6px;align-self:center">The classes, seats and stage settings below belong to this session.</div>
    </form>

    <form method="post" class="card pf" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_window">
        <div class="card-head">
            <h2><i class="fas fa-toggle-on"></i> The admission window</h2>
            <div class="acts state"><?php echo $closed === '' ? '<span class="chip ok">Taking applications</span>' : '<span class="chip off">' . h($closed) . '</span>'; ?></div>
        </div>
        <label class="chk" style="display:flex;align-items:center;gap:8px;text-transform:none;font-weight:600;color:#1f2d3a"><input type="checkbox" name="admission_open" value="1" style="width:auto;height:auto" <?php echo !empty($settings['admission_open']) ? 'checked' : ''; ?>> Admission is open — the form takes applications from the website</label>
        <label style="margin-top:14px">Who may apply</label>
        <div style="display:grid;gap:8px">
            <?php $cur_mode = adm_mode(); foreach (ADM_MODES as $k => [$lbl, $note]): ?>
            <label class="chk" style="display:flex;align-items:flex-start;gap:9px;text-transform:none;font-weight:600;color:#1f2d3a;border:1px solid #e3d7c9;border-radius:9px;padding:9px 12px"><input type="radio" name="admission_mode" value="<?php echo h($k); ?>" style="width:auto;height:auto;margin-top:3px" <?php echo $k === $cur_mode ? 'checked' : ''; ?>><span><?php echo h($lbl); ?><br><small style="font-weight:400;color:#6b7d90"><?php echo h($note); ?><?php echo $k === 'centres' ? ' <a href="admission_centres.php">Manage the centres</a>' : ''; ?></small></span></label>
            <?php endforeach; ?>
        </div>
        <div class="row3">
            <div><label>Admission is for the session</label><select name="admission_session_id"><?php echo exam_options($sessions, (int)$settings['admission_session_id'] ?: $session_id); ?></select></div>
            <div><label>Starting date <small style="text-transform:none;font-weight:400">optional</small></label><input type="date" name="admission_start" value="<?php echo h($settings['admission_start'] ?? ''); ?>"></div>
            <div><label>Last date <small style="text-transform:none;font-weight:400">optional</small></label><input type="date" name="admission_end" value="<?php echo h($settings['admission_end'] ?? ''); ?>"></div>
        </div>
        <label>Notice shown on the form</label>
        <textarea name="admission_notice" rows="2" maxlength="1000" placeholder="e.g. The admission fee is paid at the school. Please bring the original documents."><?php echo h($settings['admission_notice'] ?? ''); ?></textarea>
        <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save the window</button></div>
    </form>

    <form method="post" class="card" id="classForm" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_classes"><input type="hidden" name="rows" id="classRows">
        <div class="card-head">
            <h2><i class="fas fa-chalkboard"></i> Classes open for admission <small><?php echo h($session_name); ?></small></h2>
        </div>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th style="width:40px"></th><th>Class</th><th>Stage</th><th class="num">Seats</th><th class="num">Lowest % <small style="font-weight:400;text-transform:none">XI only</small></th><th class="num">Applications</th></tr></thead>
            <tbody>
            <?php foreach ($classes as $cid => $c): $row = $open[$cid] ?? null; $hs = $c['stage'] === 'higher_secondary'; ?>
            <tr class="<?php echo $row ? '' : 'off'; ?>" data-class="<?php echo (int)$cid; ?>">
                <td><input type="checkbox" class="on" <?php echo $row ? 'checked' : ''; ?> aria-label="<?php echo h('Open Class ' . $c['name']); ?>"></td>
                <td><b>Class <?php echo h($c['name']); ?></b></td>
                <td><?php echo h(ADM_STAGES[$c['stage']] ?? $c['stage']); ?></td>
                <td class="num"><input type="text" class="n seats" inputmode="numeric" maxlength="4" value="<?php echo $row && $row['seats'] !== null ? (int)$row['seats'] : ''; ?>" placeholder="any"></td>
                <td class="num"><?php if ($hs): ?><input type="text" class="n min" inputmode="decimal" maxlength="6" value="<?php echo $row && $row['min_percent'] !== null ? h(rtrim(rtrim($row['min_percent'], '0'), '.')) : ''; ?>" placeholder="—"><?php else: ?>—<?php endif; ?></td>
                <td class="num"><?php echo (int)($counts[$cid] ?? 0); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">Only a ticked class shows on the form. Seats left blank means no limit; the merit list and the counts still work.</p>
        <div class="acts" style="margin-top:10px"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save the classes</button></div>
    </form>

    <?php if ($xi_subjects): ?>
    <form method="post" class="card" id="subjectForm" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_subject_seats"><input type="hidden" name="rows" id="subjectRows">
        <div class="card-head" id="subjects"><h2><i class="fas fa-flask"></i> Class XI seats, subject by subject</h2></div>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Subject</th><th class="num">Seats</th><th>Subject</th><th class="num">Seats</th></tr></thead>
            <tbody>
            <?php $pairs = array_chunk($xi_subjects, 2, true); foreach ($pairs as $pair): ?>
            <tr><?php foreach ($pair as $sid => $name): ?>
                <td><b><?php echo h($name); ?></b></td>
                <td class="num"><input type="text" class="n seat" data-subject="<?php echo (int)$sid; ?>" inputmode="numeric" maxlength="4" value="<?php echo isset($subject_seats[$sid]) ? (int)$subject_seats[$sid] : ''; ?>" placeholder="any"></td>
            <?php endforeach; ?><?php echo count($pair) === 1 ? '<td></td><td></td>' : ''; ?></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">A main or additional subject whose seats are full puts the next applicant on the waiting list. Blank means no limit.</p>
        <div class="acts" style="margin-top:10px"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save the subject seats</button></div>
    </form>
    <?php endif; ?>

    <?php $vrule = adm_village_rule(); $vlist = adm_villages($session_id);
          $vseen = db_get_all("SELECT TRIM(s.village) v, COUNT(*) n FROM students s WHERE s.student_status = 'Active' AND TRIM(COALESCE(s.village, '')) <> '' GROUP BY v ORDER BY n DESC LIMIT 40"); ?>
    <form method="post" class="card pf" id="villages" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_villages">
        <div class="card-head"><h2><i class="fas fa-map-location-dot"></i> Which villages may apply <small><?php echo h($session_name); ?></small></h2>
            <div class="acts state"><span class="chip <?php echo $vrule === 'all' ? 'ok' : 'warn'; ?>"><?php echo $vrule === 'all' ? 'Open to all' : count($vlist) . ' village(s) only'; ?></span></div></div>
        <div style="display:grid;gap:8px">
            <label class="chk" style="display:flex;gap:9px;text-transform:none;font-weight:600;color:#1f2d3a"><input type="radio" name="village_rule" value="all" style="width:auto;height:auto" <?php echo $vrule === 'all' ? 'checked' : ''; ?>> Open to all — students from any village may apply</label>
            <label class="chk" style="display:flex;gap:9px;text-transform:none;font-weight:600;color:#1f2d3a"><input type="radio" name="village_rule" value="listed" style="width:auto;height:auto" <?php echo $vrule === 'listed' ? 'checked' : ''; ?>> Only students from the villages below</label>
        </div>
        <label>Villages <small style="text-transform:none;font-weight:400">one on each line</small></label>
        <textarea name="villages" id="villageBox" rows="7" placeholder="Uttar Lakshmipur&#10;Mothabari"><?php echo h(implode("\n", $vlist)); ?></textarea>
        <?php if ($vseen): ?>
        <p class="note">The villages your students come from now — click one to add it:</p>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">
            <?php foreach ($vseen as $v): ?><button type="button" class="btn btn-secondary btn-sm vadd" data-v="<?php echo h($v['v']); ?>"><?php echo h($v['v']); ?> <small style="opacity:.7"><?php echo (int)$v['n']; ?></small></button><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <p class="note">With the list on, the form offers these villages to choose from instead of a box to type in, and refuses any other. The list belongs to the session chosen at the top; "Open to all" keeps it saved for later.</p>
        <div class="acts" style="margin-top:10px"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save the villages</button></div>
    </form>
    <script>
    document.querySelectorAll('.vadd').forEach(function (b) {
        b.addEventListener('click', function () {
            var box = document.getElementById('villageBox'), v = b.getAttribute('data-v'),
                have = box.value.split(/\n/).map(function (x) { return x.trim().toLowerCase(); });
            if (have.indexOf(v.toLowerCase()) === -1) box.value = (box.value.trim() ? box.value.trim() + '\n' : '') + v;
            b.disabled = true;
        });
    });
    </script>
    <form method="post" class="card" id="items" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_items"><input type="hidden" name="stage" value="<?php echo h($stage); ?>">
        <div class="card-head"><h2><i class="fas fa-asterisk"></i> What each stage must give</h2></div>
        <div class="seg">
            <?php foreach (ADM_STAGES as $k => $label): ?><a href="<?php echo h('admission_settings.php?' . http_build_query(['session_id' => $session_id, 'stage' => $k]) . '#items'); ?>" class="<?php echo $k === $stage ? 'on' : ''; ?>"><?php echo h($label); ?></a><?php endforeach; ?>
        </div>
        <div class="item-grid">
            <?php foreach ($groups as $group => $items): ?>
            <fieldset><legend><?php echo h($group); ?></legend>
                <?php foreach ($items as $item => $label): ?><label class="chk"><input type="checkbox" name="req[<?php echo h($item); ?>]" value="1" <?php echo !empty($need[$item]) ? 'checked' : ''; ?>> <?php echo h($label); ?></label><?php endforeach; ?>
            </fieldset>
            <?php endforeach; ?>
        </div>
        <p class="note">A ticked item must be filled in or uploaded before the form is accepted. The student's name, class and the guardian's mobile are always needed, and Class XI always gives its Madhyamik details and subject choice.</p>
        <div class="acts" style="margin-top:10px"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save <?php echo h(ADM_STAGES[$stage]); ?></button></div>
    </form>
</div>
<script>
(function () {
    var num = function (v, max) { v = v.trim(); return v === '' || (new RegExp('^\\d{1,' + max + '}$')).test(v); };
    var cf = document.getElementById('classForm');
    cf.addEventListener('submit', function (e) {
        var rows = [], bad = false;
        Array.prototype.forEach.call(cf.querySelectorAll('tr[data-class]'), function (tr) {
            var on = tr.querySelector('.on').checked, seats = tr.querySelector('.seats'), min = tr.querySelector('.min');
            var okSeats = num(seats.value, 4), okMin = !min || min.value.trim() === '' || (!isNaN(min.value) && +min.value >= 0 && +min.value <= 100);
            seats.classList.toggle('bad', on && !okSeats);
            if (min) min.classList.toggle('bad', on && !okMin);
            if (on && (!okSeats || !okMin)) bad = true;
            rows.push({ class: +tr.dataset.class, on: on ? 1 : 0, seats: seats.value.trim(), min: min ? min.value.trim() : '' });
        });
        if (bad) { e.preventDefault(); return; }
        document.getElementById('classRows').value = JSON.stringify(rows);
    });
    var sf = document.getElementById('subjectForm');
    if (sf) sf.addEventListener('submit', function (e) {
        var rows = {}, bad = false;
        Array.prototype.forEach.call(sf.querySelectorAll('.seat'), function (i) {
            var ok = num(i.value, 4);
            i.classList.toggle('bad', !ok);
            if (!ok) bad = true; else rows[i.dataset.subject] = i.value.trim();
        });
        if (bad) { e.preventDefault(); return; }
        document.getElementById('subjectRows').value = JSON.stringify(rows);
    });
})();
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/card_document_helper.php");
require_once("../includes/base_url.php");
require_once("../includes/admit_card_helper.php");
require_once("../includes/security.php");

$stage = 1;
if (isset($_GET['stage2'])) $stage = 2;
if (isset($_POST['stage3'])) $stage = 3;

// ===== Common lookups =====
$exams_q = mysqli_query($conn, "
    SELECT e.id, e.exam_name, s.session_name
    FROM exams e LEFT JOIN academic_sessions s ON e.session_id = s.id
    WHERE e.exam_type='v-x'
    ORDER BY e.session_id DESC, e.exam_order ASC
");
$exams = [];
while ($row = mysqli_fetch_assoc($exams_q)) { $exams[] = $row; }

$classes = mysqli_query($conn, "SELECT id, class_name FROM classes ORDER BY sort_order ASC");

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bulk Admit Card</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 700px; }
.form-row { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 18px; }
.form-group { flex: 1; min-width: 180px; }
.form-group label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-group select { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }

table.stu-select { width: 100%; border-collapse: collapse; margin-top: 15px; }
table.stu-select th, table.stu-select td { padding: 8px 10px; border-bottom: 1px solid #e4edf6; font-size: 13px; text-align: left; }
table.stu-select th { background: #003366; color: #fff; }
.select-all-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }

/* ===== Print sheet ===== */
.toolbar { max-width: 900px; margin: 0 auto 15px auto; display: flex; gap: 10px; justify-content: flex-end; }
.toolbar button, .toolbar a { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; text-decoration: none; font-size: 14px; cursor: pointer; }
.print-sheet { max-width: 900px; margin: 0 auto; display: flex; flex-direction: column; gap: 6mm; background: #fff; padding: 10mm; }

.admit-card { border-radius: 3mm; box-shadow: 0 2px 8px rgba(0,0,0,0.15); overflow: hidden; background: #fff; break-inside: avoid; page-break-inside: avoid; }
.ac-header { background: #003366; color: #fff; padding: 3mm 5mm; display: flex; align-items: center; gap: 3mm; }
.ac-header img.logo { height: 10mm; width: 10mm; object-fit: contain; background: #fff; border-radius: 50%; padding: 0.7mm; }
.ac-header .school-name { font-weight: bold; font-size: 3.4mm; line-height: 1.3; }
.ac-header .school-name small { display: block; font-weight: normal; opacity: 0.85; font-size: 2.4mm; }

.ac-body { display: flex; padding: 4mm 5mm; gap: 4mm; border-bottom: 0.3mm dashed #ccc; }
.ac-photo { width: 20mm; height: 24mm; object-fit: cover; border: 0.4mm solid #003366; border-radius: 1mm; background: #ddd; }
.ac-info { flex: 1; font-size: 2.6mm; line-height: 1.7; color: #222; }
.ac-info .stu-name { font-size: 3.4mm; font-weight: bold; color: #003366; margin-bottom: 0.6mm; }
.ac-info b { color: #003366; min-width: 20mm; display: inline-block; }
.ac-qr { text-align: center; }
.ac-qr img { width: 18mm; height: 18mm; }

.ac-seat { background: #eaf2fb; padding: 2mm 5mm; font-size: 2.6mm; color: #003366; font-weight: 600; }

.ac-schedule { padding: 4mm 5mm; }
table.sched { width: 100%; border-collapse: collapse; font-size: 2.4mm; }
table.sched th, table.sched td { border: 0.3mm solid #dde6ee; padding: 1.3mm 2mm; text-align: left; }
table.sched th { background: #f5f8fb; color: #003366; }

@media print {
    body { background: #fff; }
    .toolbar, .no-print { display: none !important; }
    .print-sheet { padding: 0; }
    .admit-card { box-shadow: none; border: 0.2mm solid #ccc; page-break-after: always; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<?php if ($stage === 1): ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-portrait"></i> Bulk Admit Card <span>Exam + Class wise generate</span></div>
        <a href="admit_card_home.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
    <div class="form-card">
        <form method="GET" action="admit_card_bulk.php">
            <input type="hidden" name="stage2" value="1">
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-file-signature"></i> Exam</label>
                    <select name="exam_id" required>
                        <option value="">-- Select Exam --</option>
                        <?php foreach ($exams as $e): ?>
                        <option value="<?php echo $e['id']; ?>"><?php echo htmlspecialchars($e['exam_name'].' ('.($e['session_name'] ?? '').')'); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-layer-group"></i> Class</label>
                    <select name="class_id" id="class_id" required onchange="loadSections()">
                        <option value="">-- Select Class --</option>
                        <?php mysqli_data_seek($classes, 0); while ($c = mysqli_fetch_assoc($classes)): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['class_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-object-group"></i> Section</label>
                    <select name="section_id" id="section_id">
                        <option value="">All Sections</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success"><i class="fas fa-arrow-right"></i> Next: Select Students</button>
        </form>
    </div>
</div>
<script>
async function loadSections(){
    const classId = document.getElementById('class_id').value;
    const sectionSelect = document.getElementById('section_id');
    sectionSelect.innerHTML = '<option value="">All Sections</option>';
    if(!classId) return;
    try {
        const res = await fetch('get_sections.php?class_id=' + classId);
        const html = await res.text();
        sectionSelect.innerHTML = '<option value="">All Sections</option>' + html;
    } catch(e) { /* get_sections.php not reachable - "All Sections" still works */ }
}
</script>

<?php elseif ($stage === 2):
    $exam_id    = (int)($_GET['exam_id'] ?? 0);
    $class_id   = (int)($_GET['class_id'] ?? 0);
    $section_id = (int)($_GET['section_id'] ?? 0);

    $exam_row = document_get_exam($conn, 'v-x', $exam_id);
    $session_id = $exam_row ? (int)$exam_row['session_id'] : 0;
    $q = document_get_students_for_class($conn, $session_id, $class_id, $section_id);
    $class_row = ['class_name' => document_get_class_name($conn, $class_id)];
?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-portrait"></i> Select Students <span><?php echo htmlspecialchars(($exam_row['exam_name'] ?? '').' — '.($class_row['class_name'] ?? '')); ?></span></div>
        <a href="admit_card_bulk.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Change Filter</a>
    </div>
    <form method="POST" action="admit_card_bulk.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="stage3" value="1">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">

        <div class="select-all-bar">
            <label><input type="checkbox" id="selectAll" checked onclick="toggleAll(this)"> Select All</label>
            <button type="submit" class="btn btn-success"><i class="fas fa-print"></i> Generate & Print Selected</button>
        </div>

        <table class="stu-select">
            <tr><th></th><th>Roll</th><th>Name</th><th>Section</th><th>Admission No</th></tr>
            <?php $count = 0; while ($row = mysqli_fetch_assoc($q)): $count++; ?>
            <tr>
                <td><input type="checkbox" name="student_ids[]" value="<?php echo $row['id']; ?>" checked class="stu-cb"></td>
                <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                <td><?php echo htmlspecialchars($row['section_name'] ?? '-'); ?></td>
                <td><?php echo htmlspecialchars($row['admission_no']); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php if ($count === 0): ?>
            <p style="text-align:center; color:#a4161a; padding:20px;">এই class/section এ কোনো active student পাওয়া যায়নি।</p>
        <?php endif; ?>
    </form>
</div>
<script>
function toggleAll(el){
    document.querySelectorAll('.stu-cb').forEach(cb => cb.checked = el.checked);
}
</script>

<?php else: // stage 3 - print
    verify_csrf_or_die();
    $exam_id  = (int)($_POST['exam_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);
    $student_ids = array_map('student_uid_clean', $_POST['student_ids'] ?? []);

    if (empty($student_ids)) {
        echo "<div class='page-box'><p>কোনো student select করা হয়নি। <a href='admit_card_bulk.php'>ফিরে যান</a></p></div></body></html>";
        exit();
    }

    $exam = document_get_exam($conn, 'v-x', $exam_id);
    if (!$exam) {
        echo "<div class='page-box'><p>Invalid exam.</p></div></body></html>";
        exit();
    }
    $session_id = (int)$exam['session_id'];
    $students_q = document_get_selected_students($conn, $session_id, $student_ids, $class_id);
    if ($students_q === false) {
        echo "<div class='page-box'><p>Invalid student selection.</p></div></body></html>";
        exit();
    }
    $school = document_get_school_settings($conn);
?>
<div class="toolbar">
    <a href="admit_card_bulk.php"><i class="fas fa-arrow-left"></i> Back</a>
    <button onclick="window.print()"><i class="fas fa-print"></i> Print / Save as PDF</button>
</div>
<div class="print-sheet">
<?php while ($student = mysqli_fetch_assoc($students_q)):
    $card = ensure_admit_card($conn, $student['id'], 'v-x', $exam_id);
    $data = get_admit_card_data($conn, 'v-x', $exam_id, $student['id'], (int)$student['class_id']);
    $qr_src = "admit_card_qr.php?token=" . htmlspecialchars($card['verification_token']);
?>
    <div class="admit-card">
        <div class="ac-header">
            <?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name">
                <?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?>
                <small>ADMIT CARD — <?php echo htmlspecialchars($exam['exam_name'] ?? '').' ('.htmlspecialchars($exam['session_name'] ?? '').')'; ?></small>
            </div>
        </div>
        <div class="ac-body">
            <?php if (!empty($student['photo'])): ?><img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="ac-photo"><?php else: ?><div class="ac-photo"></div><?php endif; ?>
            <div class="ac-info">
                <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
                <div><b>Class</b> <?php echo htmlspecialchars($student['class_name'] ?? '-'); ?> &nbsp; <b>Sec</b> <?php echo htmlspecialchars($student['section_name'] ?? '-'); ?> &nbsp; <b>Roll</b> <?php echo htmlspecialchars($student['roll_no'] ?? '-'); ?></div>
                <div><b>Adm No</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?></div>
            </div>
            <div class="ac-qr"><img src="<?php echo $qr_src; ?>" alt="QR"></div>
        </div>
        <?php if (!empty($data['seat'])): ?>
        <div class="ac-seat">
            <i class="fas fa-chair"></i> Room: <?php echo htmlspecialchars($data['seat']['room_name'] ?? '-'); ?>
            &nbsp; Seat No: <?php echo htmlspecialchars($data['seat']['seat_no']); ?>
        </div>
        <?php else: ?>
        <div class="ac-seat" style="background:#fdecec;color:#a4161a;">Seating plan এখনো তৈরি হয়নি</div>
        <?php endif; ?>
        <div class="ac-schedule">
            <table class="sched">
                <tr><th>Date</th><th>Subject</th><th>Shift</th><th>Time</th><th>F.M.</th></tr>
                <?php foreach ($data['routine'] as $r): ?>
                <tr>
                    <td><?php echo date('jS M y', strtotime($r['exam_date'])); ?></td>
                    <td><?php echo htmlspecialchars($r['subject_name']); ?></td>
                    <td><?php echo htmlspecialchars($r['shift_name'] ?? '-'); ?></td>
                    <td><?php echo date('h:i A', strtotime($r['start_time'])).'–'.date('h:i A', strtotime($r['end_time'])); ?></td>
                    <td><?php echo isset($r['full_marks']) && $r['full_marks'] !== null ? (int)$r['full_marks'] : '—'; ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
<?php endwhile; ?>
</div>
<?php endif; ?>
</body>
</html>

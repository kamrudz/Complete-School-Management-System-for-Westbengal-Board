<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/base_url.php");
require_once("../includes/admit_card_helper.php");
require_once("../includes/card_document_helper.php");

if (student_uid_clean($_GET['id'] ?? '') === '' || !isset($_GET['exam_id']) || !is_numeric($_GET['exam_id'])) {
    $_SESSION['error'] = "Invalid request!";
    header("Location: admit_card_home.php");
    exit();
}
$student_id = student_uid_clean($_GET['id']);
$exam_id = (int)$_GET['exam_id'];
$exam_source = ($_GET['exam_source'] ?? 'v-x') === 'hs' ? 'hs' : 'v-x';

// ===== Exam info =====
$exam = document_get_exam($conn, $exam_source, $exam_id);
if (!$exam) {
    $_SESSION['error'] = "Exam not found!";
    header("Location: admit_card_home.php");
    exit();
}
$session_id = (int)$exam['session_id'];

// ===== Student + academic info =====
$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, "s", $student_id);
mysqli_stmt_execute($stmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
if (!$student) {
    $_SESSION['error'] = "Student not found!";
    header("Location: admit_card_home.php");
    exit();
}
if ($student['student_status'] !== 'Active') {
    $_SESSION['error'] = "{$student['student_name']} is {$student['student_status']} — an admit card is issued to Active students only.";
    header("Location: admit_card_home.php");
    exit();
}

$academic = document_get_student_academic($conn, $student_id, $session_id);
if (!$academic) {
    $_SESSION['error'] = 'Student is not enrolled in the exam session.';
    header('Location: admit_card_home.php');
    exit();
}
$class_id = (int)$academic['class_id'];

$school = document_get_school_settings($conn);
$card = ensure_admit_card($conn, $student_id, $exam_source, $exam_id);
$data = get_admit_card_data($conn, $exam_source, $exam_id, $student_id, $class_id);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admit Card - <?php echo htmlspecialchars($student['student_name']); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: #eef2f6; margin: 0; padding: 20px; }
.toolbar { max-width: 780px; margin: 0 auto 15px auto; display: flex; gap: 10px; justify-content: flex-end; }
.toolbar a, .toolbar button { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; text-decoration: none; font-size: 14px; cursor: pointer; }

.admit-card { max-width: 780px; margin: 0 auto; background: #fff; border-radius: 4mm; box-shadow: 0 4px 14px rgba(0,0,0,0.18); overflow: hidden; }
.ac-header { background: #003366; color: #fff; padding: 4mm 6mm; display: flex; align-items: center; gap: 4mm; }
.ac-header img.logo { height: 14mm; width: 14mm; object-fit: contain; background: #fff; border-radius: 50%; padding: 1mm; }
.ac-header .school-name { font-weight: bold; font-size: 4.5mm; line-height: 1.3; }
.ac-header .school-name small { display: block; font-weight: normal; opacity: 0.85; font-size: 3mm; }

.ac-body { display: flex; padding: 5mm 6mm; gap: 5mm; border-bottom: 0.3mm dashed #ccc; }
.ac-photo { width: 28mm; height: 34mm; object-fit: cover; border: 0.4mm solid #003366; border-radius: 1mm; background: #ddd; }
.ac-info { flex: 1; font-size: 3.2mm; line-height: 1.9; color: #222; }
.ac-info .stu-name { font-size: 4.5mm; font-weight: bold; color: #003366; margin-bottom: 1mm; }
.ac-info b { color: #003366; min-width: 26mm; display: inline-block; }
.ac-qr { text-align: center; }
.ac-qr img { width: 24mm; height: 24mm; }
.ac-qr .exam-tag { font-size: 2.6mm; color: #555; margin-top: 1mm; }

.ac-seat { background: #eaf2fb; padding: 3mm 6mm; font-size: 3.4mm; color: #003366; font-weight: 600; }

.ac-schedule { padding: 5mm 6mm; }
.ac-schedule h4 { color: #003366; font-size: 3.6mm; margin: 0 0 3mm 0; }
table.sched { width: 100%; border-collapse: collapse; font-size: 3mm; }
table.sched th, table.sched td { border: 0.3mm solid #dde6ee; padding: 2mm 3mm; text-align: left; }
table.sched th { background: #f5f8fb; color: #003366; }

.ac-note { padding: 3mm 6mm 5mm 6mm; font-size: 2.6mm; color: #a4161a; font-style: italic; }
.ac-sign { display: flex; justify-content: space-between; align-items: flex-end; padding: 0 6mm 5mm 6mm; }
.ac-sign img { height: 10mm; }
.ac-sign .sign-line { font-size: 2.8mm; border-top: 0.3mm solid #333; padding-top: 1mm; text-align: center; width: 35mm; }

@media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none !important; }
    .admit-card { box-shadow: none; border: 0.2mm solid #ccc; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<div class="toolbar">
    <a href="admit_card_home.php"><i class="fas fa-arrow-left"></i> Back</a>
    <button onclick="window.print()"><i class="fas fa-print"></i> Print</button>
</div>

<div class="admit-card">
    <div class="ac-header">
        <?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
        <div class="school-name">
            <?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?>
            <small>ADMIT CARD — <?php echo htmlspecialchars($exam['exam_name']); ?> (<?php echo htmlspecialchars($exam['session_name'] ?? ''); ?>)</small>
        </div>
    </div>

    <div class="ac-body">
        <?php if (!empty($student['photo'])): ?>
            <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="ac-photo">
        <?php else: ?><div class="ac-photo"></div><?php endif; ?>
        <div class="ac-info">
            <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
            <div><b>Class</b> <?php echo htmlspecialchars($academic['class_name'] ?? '-'); ?> &nbsp; <b>Sec</b> <?php echo htmlspecialchars($academic['section_name'] ?? '-'); ?> &nbsp; <b>Roll</b> <?php echo htmlspecialchars($academic['roll_no'] ?? '-'); ?></div>
            <div><b>Adm No</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?></div>
            <div><b>DOB</b> <?php echo !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '-'; ?></div>
        </div>
        <div class="ac-qr">
            <img src="admit_card_qr.php?token=<?php echo htmlspecialchars($card['verification_token']); ?>" alt="QR">
            <div class="exam-tag">Verify Card</div>
        </div>
    </div>

    <?php if (!empty($data['seat'])): ?>
    <div class="ac-seat">
        <i class="fas fa-chair"></i> Room: <?php echo htmlspecialchars($data['seat']['room_name'] ?? '-'); ?>
        <?php if (!empty($data['seat']['location'])): ?> (<?php echo htmlspecialchars($data['seat']['location']); ?>)<?php endif; ?>
        &nbsp;&nbsp; Seat No: <?php echo htmlspecialchars($data['seat']['seat_no']); ?>
    </div>
    <?php else: ?>
    <div class="ac-seat" style="background:#fdecec;color:#a4161a;">
        <i class="fas fa-exclamation-triangle"></i> এখনো seating plan তৈরি হয়নি — Exam Conduct → Seating Plan-এ গিয়ে আগে বসিয়ে নিন।
    </div>
    <?php endif; ?>

    <div class="ac-schedule">
        <h4><i class="fas fa-calendar-alt"></i> Exam Schedule</h4>
        <table class="sched">
            <tr><th>Date</th><th>Subject</th><th>Shift</th><th>Time</th><th>Full Marks</th></tr>
            <?php if (empty($data['routine'])): ?>
            <tr><td colspan="5" style="text-align:center;color:#a4161a;">এই ক্লাসের জন্য এখনো routine সেভ হয়নি।</td></tr>
            <?php endif; ?>
            <?php foreach ($data['routine'] as $r): ?>
            <tr>
                <td><?php echo date('jS M y', strtotime($r['exam_date'])); ?></td>
                <td><?php echo htmlspecialchars($r['subject_name']); ?></td>
                <td><?php echo htmlspecialchars($r['shift_name'] ?? '-'); ?></td>
                <td><?php echo date('h:i A', strtotime($r['start_time'])).' – '.date('h:i A', strtotime($r['end_time'])); ?></td>
                <td><?php echo isset($r['full_marks']) && $r['full_marks'] !== null ? (int)$r['full_marks'] : '—'; ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    <div class="ac-note">এই admit card পরীক্ষার হলে সাথে আনা বাধ্যতামূলক। কোনো তথ্য ভুল থাকলে অবিলম্বে অফিসে যোগাযোগ করুন।</div>
    <div class="ac-sign">
        <div></div>
        <div>
            <?php if (!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['hoi_signature']); ?>"><?php endif; ?>
            <div class="sign-line">Head of Institution</div>
        </div>
    </div>
</div>
</body>
</html>

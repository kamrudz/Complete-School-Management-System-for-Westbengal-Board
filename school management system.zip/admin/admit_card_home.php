<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

// ===== Exam list (V-X active session দিয়ে ডিফল্ট, dropdown-এ সব exam) =====
$exams_q = mysqli_query($conn, "
    SELECT e.id, e.exam_name, s.session_name
    FROM exams e LEFT JOIN academic_sessions s ON e.session_id = s.id
    WHERE e.exam_type='v-x'
    ORDER BY e.session_id DESC, e.exam_order ASC
");
$exams = [];
while ($row = mysqli_fetch_assoc($exams_q)) { $exams[] = $row; }

$search = trim($_GET['search'] ?? '');
$exam_id = (int)($_GET['exam_id'] ?? 0);
$results = [];
if ($search !== '' && $exam_id > 0) {
    $exam_stmt = mysqli_prepare($conn, "SELECT session_id FROM exams WHERE id=? AND exam_type='v-x' LIMIT 1");
    mysqli_stmt_bind_param($exam_stmt, 'i', $exam_id);
    mysqli_stmt_execute($exam_stmt);
    $exam_row = mysqli_fetch_assoc(mysqli_stmt_get_result($exam_stmt));
    $exam_session_id = (int)($exam_row['session_id'] ?? 0);
    if ($exam_session_id > 0) {
        $like = '%' . $search . '%';
        $q = mysqli_prepare($conn, "
            SELECT s.id, s.student_name, s.admission_no, s.photo,
                   h.roll_no, c.class_name, c.id AS class_id, sec.section_name
            FROM students s
            JOIN student_academic_history h ON h.student_id=s.id AND h.session_id=?
            LEFT JOIN classes c ON c.id=h.class_id
            LEFT JOIN sections sec ON sec.id=h.section_id
            WHERE s.student_status = 'Active' AND h.student_status NOT IN ('Deactivated','Deleted') AND (s.student_name LIKE ? OR s.id LIKE ? OR s.admission_no LIKE ?)
            ORDER BY s.student_name ASC LIMIT 30
        ");
        mysqli_stmt_bind_param($q, 'isss', $exam_session_id, $like, $like, $like);
        mysqli_stmt_execute($q);
        $res = mysqli_stmt_get_result($q);
        while ($r = mysqli_fetch_assoc($res)) { $results[] = $r; }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admit Card</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.option-grid { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 25px; }
.option-card { flex: 1; min-width: 260px; background: #fff; border: 1px solid #e4edf6; border-radius: 12px; padding: 25px; }
.option-card .opt-icon { width: 50px; height: 50px; border-radius: 12px; background: #eaf2fb; color: #003366; display: flex; align-items: center; justify-content: center; font-size: 22px; margin-bottom: 12px; }
.option-card h3 { margin: 0 0 6px 0; color: #003366; font-size: 17px; }
.option-card p { margin: 0 0 15px 0; font-size: 13px; color: #6c7a8a; }
.search-form { display: flex; gap: 10px; flex-wrap: wrap; }
.search-form select, .search-form input { padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.search-form input { flex: 1; min-width: 180px; }

table.stu-results { width: 100%; border-collapse: collapse; margin-top: 15px; }
table.stu-results th, table.stu-results td { padding: 10px 12px; border-bottom: 1px solid #e4edf6; font-size: 13px; text-align: left; }
table.stu-results th { background: #003366; color: #fff; }
.photo-thumb { width: 34px; height: 34px; border-radius: 6px; object-fit: cover; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-portrait"></i> Student Admit Card</div>
    </div>

    <div class="option-grid">
        <div class="option-card">
            <div class="opt-icon"><i class="fas fa-user"></i></div>
            <h3>Single Admit Card</h3>
            <p>Exam সিলেক্ট করে student খুঁজে বের করে card generate করুন</p>
            <form method="GET" class="search-form">
                <select name="exam_id" required>
                    <option value="">-- Exam --</option>
                    <?php foreach ($exams as $e): ?>
                    <option value="<?php echo $e['id']; ?>" <?php echo $e['id']==$exam_id?'selected':''; ?>>
                        <?php echo htmlspecialchars($e['exam_name'].' ('.($e['session_name'] ?? '').')'); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="search" placeholder="Name বা Admission No দিয়ে খুঁজুন..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="option-card">
            <div class="opt-icon"><i class="fas fa-layer-group"></i></div>
            <h3>Bulk Admit Card</h3>
            <p>Exam + Class অনুযায়ী একসাথে সবার card generate ও print করুন</p>
            <a href="admit_card_bulk.php" class="btn btn-success"><i class="fas fa-arrow-right"></i> Bulk এ যান</a>
        </div>
    </div>

    <?php if ($search !== '' && $exam_id > 0): ?>
    <div style="overflow-x:auto;">
    <table class="stu-results">
        <tr><th></th><th>Name</th><th>Class</th><th>Roll</th><th>Admission No</th><th>Action</th></tr>
        <?php if (empty($results)): ?>
            <tr><td colspan="6" style="text-align:center; color:#a4161a; padding:20px;">কোনো student পাওয়া যায়নি।</td></tr>
        <?php endif; ?>
        <?php foreach ($results as $row): ?>
        <tr>
            <td>
                <?php if (!empty($row['photo'])): ?>
                    <img src="../uploads/students/<?php echo htmlspecialchars($row['photo']); ?>" class="photo-thumb">
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
            <td><?php echo htmlspecialchars(($row['class_name'] ?? '-').' '.($row['section_name'] ?? '')); ?></td>
            <td><?php echo htmlspecialchars($row['roll_no'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($row['admission_no'] ?? '-'); ?></td>
            <td><a href="admit_card_generate.php?id=<?php echo $row['id']; ?>&exam_id=<?php echo $exam_id; ?>" class="btn btn-success btn-sm"><i class="fas fa-portrait"></i> Generate</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

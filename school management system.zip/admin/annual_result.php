<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Annual result of a class: every exam that counts, added up per subject (formative is never added),
 * with total, %, grade, result and rank — from result_annual(). ?print=1 A4 landscape, ?xlsx=1 Excel.
 */
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? exam_active_session_id()); if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = null;
$sort = ($_GET['sort'] ?? 'roll') === 'merit' ? 'merit' : 'roll';
$compact = !empty($_GET['compact']); $print = !empty($_GET['print']); $xlsx = !empty($_GET['xlsx']);
$ready = $class_id > 0;
$qs = "session_id=$session_id&class_id=$class_id&section=$section&section_id=" . ($section_id ?: 'all') . "&sort=$sort" . ($compact ? '&compact=1' : '');
$res = $ready ? result_annual($session_id, $class_id, $section_id, true) : null;   // also those promoted or passed out since
$students = $res['students'] ?? []; $subjects = $res['subjects'] ?? []; $exams = $res['exams'] ?? [];
if ($sort === 'merit') uasort($students, fn($a, $b) => (($a['rank'] ?? PHP_INT_MAX) <=> ($b['rank'] ?? PHP_INT_MAX)) ?: strcmp($a['section'] . $a['roll'], $b['section'] . $b['roll']));
$formative = $res['formative'] ?? false;
$title = $ready ? 'Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : ' (all sections)') : '';
$summary = ['n' => count($students)]; foreach (['PASS', 'PUC', 'FAIL', 'ABSENT'] as $s) $summary[$s] = count(array_filter($students, fn($x) => $x['status'] === $s));
$short = fn($name) => preg_replace('/^(\d)(st|nd|rd|th) /', '$1', str_ireplace('Summative', 'S', $name));
$ex_cell = function ($v): string { if ($v === null) return '<span style="color:#b8860b">—</span>'; if ($v === 'AB') return 'AB'; return exam_fmt($v); };

if ($ready && $xlsx) {
    $head = ['#', 'Sec', 'Roll', 'School UID', "Banglar
Shiksha ID", "PEN
ID", 'Student', 'Father'];
    $band = []; $b = 0;   // every other subject block gets a tint so the columns of one subject read together
    foreach ($subjects as $s) { $w = exam_subject_code($s); $b = $b === 1 ? 2 : 1; $from = count($head) + 1;
        if (!$compact) { foreach ($exams as $e) $head[] = $w . "\n" . $short($e['exam_name']); }
        $head[] = $w . "\nTotal" . ($compact ? '' : "\nof " . exam_fmt($s['full'] ?? 0));
        for ($c = $from; $c <= count($head); $c++) $band[$c] = $b; }
    array_push($head, "Grand\ntotal", "Full\nmarks", '%', 'Grade', 'Result', 'Rank', "Sub.\nfailed");
    $rows = array_merge(exam_xlsx_title('Annual Result — ' . $title, 'Session ' . exam_session_name($session_id) . '  ·  ' . implode(' + ', array_map(fn($e) => $e['exam_name'], $exams)) . '  ·  ' . exam_subject_legend($subjects)), [$head]); $i = 0;
    foreach ($students as $uid => $st) {
        $r = [++$i, $st['section'], $st['roll'], $uid, $st['bsid'], $st['pen'], $st['name'], $st['father']];
        foreach ($subjects as $sid => $s) { $x = $st['subjects'][$sid] ?? null; if (!$compact) { foreach ($exams as $e) { $v = $x['exams'][(int)$e['id']] ?? null; $r[] = $v === null ? '' : ($v === 'AB' ? 'AB' : exam_fmt($v)); } } $r[] = $x ? ($x['absent'] ? 'AB' : exam_fmt($x['obtained']) . ($x['grace'] > 0 ? '†' : '')) : 'NA'; }
        array_push($r, exam_fmt($st['total']), exam_fmt($st['full']), exam_fmt($st['pct']), $st['grade'], $st['status'], $st['rank'] ?? '', $st['failed_n']);
        $rows[] = $r;
    }
    SimpleXLSXWriter::download('annual_result_' . preg_replace('/[^A-Za-z0-9]+/', '_', $title) . '.xlsx', $rows, 'Annual', exam_xlsx_opts(count($head)) + ['band_cols' => $band]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Annual Result</title>
<?php exam_styles(); ?>
<style>
    .tab { overflow: auto; } .tab table { border-collapse: collapse; font-size: 12px; min-width: 100%; }
    .tab th, .tab td { border: 1px solid #cfd8e3; padding: 4px 6px; text-align: center; white-space: nowrap; } .tab th { background: #f3eef8; color: #3b1d5c; font-size: 11px; } .tab th small { display: block; font-weight: 400; color: #6b7d90; }
    .tab th.grp { background: #e9e1f2; } .tab td.l { text-align: left; } .tab td.f { color: #b71c1c; font-weight: 700; } .tab td.tot { font-weight: 700; } .tab td.sub, .tab th.sub { border-left: 2px solid #b7a6cc; } .tab tr.ab td { color: #888; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; } .sum span { padding: 5px 11px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 12.5px; } .sum b { margin-left: 4px; }
    .legend { font-size: 11.5px; color: #6b7d90; margin-top: 8px; }
    <?php if ($print): ?> body { background: #fff; } .page-box { padding: 8px !important; } .tab table { font-size: 10px; } .tab th, .tab td { padding: 2px 3px; } @page { size: A4 landscape; margin: 8mm; } <?php endif; ?>
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if ($print): ?>
        <?php exam_school_header('Annual Result — ' . $title, 'Session ' . exam_session_name($session_id) . ' · ' . implode(' + ', array_map(fn($e) => $e['exam_name'], $exams))); ?>
        <div class="noprint" style="margin-bottom:8px"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button> <a href="annual_result.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php else: ?>
        <?php exam_banner('Annual Result', 'The exams that count, added up per subject' . ($formative ? '; formative marks are on the report card only' : '') . '. Total, percentage, grade, result and rank for the year.', 'fa-award', $ready ? ["annual_result.php?$qs&print=1" => '<i class="fas fa-print"></i> Print', "annual_result.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel', "report_card.php?$qs" => '<i class="fas fa-id-card"></i> Report cards'] : []); ?>
        <?php exam_tabs('annual_result.php', EXAM_PAGES, "section=$section"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
            <div><label>Session</label><select name="session_id" onchange="this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
            <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
            <div><label>Order</label><select name="sort" onchange="this.form.submit()"><?php echo exam_options(['roll' => 'Roll number', 'merit' => 'Merit (rank)'], $sort); ?></select></div>
            <div><label>&nbsp;</label><label style="text-transform:none;font-weight:400;display:flex;align-items:center;gap:6px;height:38px"><input type="checkbox" name="compact" value="1" <?php echo $compact ? 'checked' : ''; ?> onchange="this.form.submit()" style="min-width:auto;height:auto"> Subject totals only</label></div>
        </form>
    <?php endif; ?>

    <?php if (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-award"></i>Select a class.</div></div>
    <?php elseif (!$exams): ?><div class="card"><div class="ex-empty"><i class="fas fa-clipboard-list"></i>No exam of <?php echo h($sessions[$session_id]); ?> counts in the annual result — see <a href="exams.php?session_id=<?php echo $session_id; ?>">Exams</a>.</div></div>
    <?php elseif (!$subjects): ?><div class="card"><div class="ex-empty"><i class="fas fa-sliders-h"></i>No full marks set for Class <?php echo h($classes[$class_id]['name']); ?> in any counting exam — <a href="exam_subject_marks.php">Full & Pass Marks</a>.</div></div>
    <?php else: ?>
    <div class="card">
        <?php if (!$print): ?><h2><i class="fas fa-award"></i> <?php echo h($title); ?> <small><?php echo h($sessions[$session_id]); ?> · <?php echo h(implode(' + ', array_map(fn($e) => $e['exam_name'], $exams))); ?><?php echo $formative ? ' · formative on the report card only' : ''; ?></small></h2><?php endif; ?>
        <?php foreach ($res['warnings'] as $w): ?><div class="alert alert-warning" style="font-size:12.5px;padding:6px 10px"><i class="fas fa-exclamation-triangle"></i> <?php echo h($w); ?></div><?php endforeach; ?>
        <div class="sum"><span>Students<b><?php echo $summary['n']; ?></b></span><span>Pass<b><?php echo $summary['PASS']; ?></b></span><span>PUC<b><?php echo $summary['PUC']; ?></b></span><span>Fail<b><?php echo $summary['FAIL']; ?></b></span><span>Absent<b><?php echo $summary['ABSENT']; ?></b></span><?php if (!result_publishable($session_id)): ?><span class="chip warn">Not all counting exams are published — annual result is not public yet</span><?php endif; ?></div>
        <div class="tab"><table>
            <thead>
            <?php if (!$compact): ?><tr><th rowspan="2">#</th><?php if (!$section_id): ?><th rowspan="2">Sec</th><?php endif; ?><th rowspan="2">Roll</th><th rowspan="2" style="text-align:left">Student</th>
                <?php foreach ($subjects as $s): ?><th class="grp sub" colspan="<?php echo count($exams) + 1; ?>"><?php echo h($s['name']); ?></th><?php endforeach; ?>
                <th rowspan="2" class="sub">Total<small>/<?php echo exam_fmt(reset($students)['full'] ?? 0); ?></small></th><th rowspan="2">%</th><th rowspan="2">Grade</th><th rowspan="2">Result</th><th rowspan="2">Rank</th></tr>
                <tr><?php foreach ($subjects as $s): ?><?php foreach ($exams as $k => $e): ?><th class="<?php echo $k === 0 ? 'sub' : ''; ?>"><?php echo h($short($e['exam_name'])); ?></th><?php endforeach; ?><th>Tot</th><?php endforeach; ?></tr>
            <?php else: ?><tr><th>#</th><?php if (!$section_id): ?><th>Sec</th><?php endif; ?><th>Roll</th><th style="text-align:left">Student</th><?php foreach ($subjects as $s): ?><th class="sub"><?php echo h($s['name']); ?></th><?php endforeach; ?><th class="sub">Total<small>/<?php echo exam_fmt(reset($students)['full'] ?? 0); ?></small></th><th>%</th><th>Grade</th><th>Result</th><th>Rank</th></tr><?php endif; ?>
            </thead>
            <tbody>
            <?php $i = 0; foreach ($students as $uid => $st): $i++; ?>
            <tr class="<?php echo $st['status'] === 'ABSENT' ? 'ab' : ''; ?>"><td><?php echo $i; ?></td><?php if (!$section_id): ?><td><?php echo h($st['section']); ?></td><?php endif; ?><td><?php echo h($st['roll']); ?></td><td class="l"><?php echo h($st['name']); ?></td>
                <?php foreach ($subjects as $sid => $s): $x = $st['subjects'][$sid] ?? null; $span = $compact ? 1 : count($exams) + 1; if (!$x): ?><td class="sub" colspan="<?php echo $span; ?>" style="color:#aaa">NA</td><?php continue; endif; ?>
                    <?php if (!$compact): ?><?php foreach ($exams as $k => $e): ?><td class="<?php echo $k === 0 ? 'sub' : ''; ?>"><?php echo $ex_cell($x['exams'][(int)$e['id']] ?? null); ?></td><?php endforeach; ?><?php endif; ?>
                    <td class="<?php echo $compact ? 'sub' : ''; ?> tot <?php echo $x['fail'] ? 'f' : ''; ?>"><?php echo $x['absent'] ? 'AB' : exam_fmt($x['obtained']) . ($x['grace'] > 0 ? '†' : ''); ?><?php if ($compact): ?><small style="color:#888;font-weight:400">/<?php echo exam_fmt($x['full']); ?></small><?php endif; ?></td>
                <?php endforeach; ?>
                <td class="sub tot"><?php echo exam_fmt($st['total']); ?></td><td><?php echo exam_fmt($st['pct']); ?></td><td class="tot"><?php echo h($st['grade']); ?></td><td><?php echo $print ? h($st['status']) : result_badge($st['status']); ?></td><td class="tot"><?php echo $st['rank'] ?? '—'; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <div class="legend">Subject total = Σ of the counting exams<?php echo $formative ? ' — formative is never added; it shows on the report card only' : ''; ?>; subject pass marks = Σ of the exams' pass marks. † includes grace · AB absent · — not entered · NA not taken · rank within the list shown.</div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

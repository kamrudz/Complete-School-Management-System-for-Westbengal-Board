<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

/**
 * A class offers a third language when two or more of its subjects this session carry the 3rd-language
 * tick (Class Subjects); each student then studies one of them. Higher Secondary has none. A choice is
 * kept per student (student_third_language) until it is changed.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$session = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1");
$session_id = (int)($session['id'] ?? 0);

$offered = array_flip(array_map('intval', array_column(db_get_all('SELECT class_id FROM class_subjects WHERE session_id = ? AND is_third_language = 1
                                                                  GROUP BY class_id HAVING COUNT(*) >= 2', 'i', $session_id), 'class_id')));
$tl_classes = [];   // class_id => name, in class order
foreach (class_rows() as $id => $c) if (isset($offered[$id]) && $c['stage'] !== 'higher_secondary') $tl_classes[$id] = $c['name'];
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? $_POST['section_id'] ?? 0);
if ($class_id && !isset($tl_classes[$class_id])) {
    $_SESSION['error'] = "এই class-এ third language চালু নেই — Class Subjects-এ ঐ class-এর ২টা ভাষায় '3rd Language' টিক দিন।";
    header('Location: assign_third_language.php'); exit;
}
$back = 'Location: assign_third_language.php?' . http_build_query(['class_id' => $class_id, 'section_id' => $section_id ?: null]);

$languages = $class_id ? db_get_all('SELECT s.id, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id
                                     WHERE cs.session_id = ? AND cs.class_id = ? AND cs.is_third_language = 1 ORDER BY s.subject_name', 'ii', $session_id, $class_id) : [];
$language_ids = array_map('intval', array_column($languages, 'id'));

/** The language a student's religion usually points to (Islam → Arabic, Hindu → Sanskrit), or null. */
function suggest_third_language(?string $religion, array $languages): ?int {
    $want = ['islam' => 'arab', 'muslim' => 'arab', 'hindu' => 'sanskrit'][strtolower(trim((string)$religion))] ?? null;
    if ($want === null) return null;
    foreach ($languages as $l) if (stripos($l['subject_name'], $want) !== false) return (int)$l['id'];
    return null;
}

/** Current students of the class (one section, or all), with their saved choice. */
function third_language_students(int $session_id, int $class_id, int $section_id): array {
    $sql = 'SELECT s.id, s.student_name, s.religion, sah.roll_no, sec.section_name, stl.subject_id AS chosen
            FROM student_academic_history sah JOIN students s ON s.id = sah.student_id AND s.student_status = "Active"
            LEFT JOIN sections sec ON sec.id = sah.section_id LEFT JOIN student_third_language stl ON stl.student_id = s.id
            WHERE sah.session_id = ? AND sah.class_id = ? AND sah.academic_status = "Current"';
    $types = 'ii'; $params = [$session_id, $class_id];
    if ($section_id) { $sql .= ' AND sah.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
    return db_get_all($sql . ' ORDER BY sec.section_name, CAST(sah.roll_no AS UNSIGNED), s.student_name', $types, ...$params);
}

if ($class_id && (isset($_POST['save_third_language']) || isset($_POST['auto_assign']))) {
    verify_csrf_or_die();
    $class_students = array_column(third_language_students($session_id, $class_id, 0), null, 'id');
    $choices = [];   // uid => subject_id, only real students of this class and only this class's languages
    if (isset($_POST['auto_assign'])) {
        foreach ($class_students as $uid => $st) if (!$st['chosen'] && ($l = suggest_third_language($st['religion'], $languages))) $choices[$uid] = $l;
        $left = count(array_filter($class_students, fn($st) => !$st['chosen'])) - count($choices);
    } else {
        foreach ((array)($_POST['choice'] ?? []) as $uid => $lang) {
            $uid = student_uid_clean($uid);
            if (isset($class_students[$uid]) && in_array((int)$lang, $language_ids, true)) $choices[$uid] = (int)$lang;
        }
    }
    $changed = 0;
    db_begin_transaction();
    try {
        foreach ($choices as $uid => $lang) {
            $changed += db_execute('INSERT INTO student_third_language (student_id, subject_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE subject_id = VALUES(subject_id)', 'si', $uid, $lang) > 0 ? 1 : 0;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); throw $e; }
    if ($changed) log_action($admin_id, isset($_POST['auto_assign']) ? 'THIRD_LANGUAGE_AUTO' : 'THIRD_LANGUAGE_SAVED', 'student_third_language', $class_id, null, ['changed' => $changed]);
    if (isset($_POST['auto_assign'])) {
        $_SESSION[$left ? 'error' : 'success'] = ($changed ? "Auto assign: $changed জনকে religion অনুযায়ী দেওয়া হল।" : 'Auto assign: নতুন কাউকে দেওয়া গেল না।')
            . ($left ? " $left জনের religion থেকে বোঝা যায়নি — তাদের হাতে বাছুন (হলুদ সারি)।" : ' সবার হয়ে গেছে।');
    } else {
        $_SESSION['success'] = $changed ? "Third language saved — $changed student(s) changed." : 'Nothing changed — every choice was already saved.';
    }
    header($back); exit;
}

$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id) : [];
$students = $class_id ? third_language_students($session_id, $class_id, $section_id) : [];
$saved = count(array_filter($students, fn($s) => $s['chosen']));
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>3rd Language Assign</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    tr.guess td { background: #fff8e1; }
    .table select { padding: 6px 10px; border: 2px solid var(--gray-light); border-radius: 6px; min-width: 150px; }
    .table select.empty { border-color: #f0ad4e; background: #fffbf0; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-language"></i> 3rd Language Assign<?php echo $class_id ? ' — Class ' . $h($tl_classes[$class_id]) : ''; ?> <small>Session <?php echo $h($session['session_name'] ?? '—'); ?></small></div>
        <a href="class_subjects.php" class="btn btn-secondary"><i class="fas fa-cog"></i> Class Subjects</a>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <form method="get" class="filter-box"><div class="filter-row">
        <div class="filter-group"><label><i class="fas fa-chalkboard"></i> Class</label>
            <select name="class_id" onchange="this.form.section_id.value='0';this.form.submit()"><option value="0">— select —</option><?php foreach ($tl_classes as $cid => $name): ?><option value="<?php echo $cid; ?>" <?php echo $cid === $class_id ? 'selected' : ''; ?>><?php echo $h($name); ?></option><?php endforeach; ?></select></div>
        <div class="filter-group"><label><i class="fas fa-layer-group"></i> Section</label>
            <select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><option value="0">All sections</option><?php foreach ($sections as $sec): ?><option value="<?php echo (int)$sec['id']; ?>" <?php echo (int)$sec['id'] === $section_id ? 'selected' : ''; ?>><?php echo $h($sec['section_name']); ?></option><?php endforeach; ?></select></div>
    </div></form>

    <?php if (!$class_id): ?>
    <div class="empty-state"><i class="fas fa-language"></i><h3>কোন class-এর ছাত্রদের বাছাই করবেন?</h3>
        <p><?php echo $tl_classes ? 'উপরে Class বাছুন। এখন third language চালু আছে: <strong>' . $h(implode(', ', $tl_classes)) . '</strong>' : 'কোনো class-এ third language চালু নেই। <a href="class_subjects.php">Class Subjects</a>-এ গিয়ে ঐ class-এর দুটো ভাষায় "3rd Language" টিক দিন।'; ?></p></div>
    <?php else: ?>
    <div class="stats-row">
        <div class="stat-card"><div class="number"><?php echo count($students); ?></div><div class="label">Students</div></div>
        <div class="stat-card"><div class="number green"><?php echo $saved; ?></div><div class="label">Saved</div></div>
        <div class="stat-card"><div class="number red"><?php echo count($students) - $saved; ?></div><div class="label">বাছাই বাকি</div></div>
    </div>
    <?php if (count($students) > $saved): ?>
    <form method="post" onsubmit="return confirm('Class <?php echo $h($tl_classes[$class_id]); ?>-এর সব section-এর বাছাই-না-করা ছাত্রদের religion অনুযায়ী assign হবে (Islam→Arabic, Hindu→Sanskrit)। আগের বাছাই বদলাবে না। চালাবেন?')" style="margin-bottom:12px">
        <?php echo csrf_field(); ?><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id; ?>">
        <button type="submit" name="auto_assign" class="btn btn-primary"><i class="fas fa-magic"></i> Auto assign (religion অনুযায়ী)</button>
        <span class="form-hint">শুধু যাদের বাছাই নেই — আগেরটা ছোঁবে না।</span>
    </form>
    <?php endif; ?>

    <?php if (!$students): ?>
    <div class="empty-state"><i class="fas fa-users-slash"></i><h3>No students</h3><p>এই ক্লাসে current session-এ কোনো active student নেই।</p></div>
    <?php else: ?>
    <form method="post" id="tl-form">
        <?php echo csrf_field(); ?><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id; ?>">
        <div class="table-responsive"><table class="table">
            <thead><tr><th>Section</th><th>Roll</th><th>Student</th><th>Religion</th><th>Third Language</th><th>Status</th></tr></thead>
            <tbody>
            <?php foreach ($students as $st): $pick = (int)$st['chosen'] ?: suggest_third_language($st['religion'], $languages); ?>
                <tr class="<?php echo $pick ? '' : 'guess'; ?>">
                    <td><?php echo $h($st['section_name'] ?: '—'); ?></td>
                    <td><?php echo $h($st['roll_no']); ?></td>
                    <td><?php echo $h($st['student_name']); ?></td>
                    <td><?php echo $h($st['religion'] ?: 'N/A'); ?></td>
                    <td><select name="choice[<?php echo $h($st['id']); ?>]" class="<?php echo $pick ? '' : 'empty'; ?>"><option value="">— select —</option>
                        <?php foreach ($languages as $l): ?><option value="<?php echo (int)$l['id']; ?>" <?php echo (int)$l['id'] === $pick ? 'selected' : ''; ?>><?php echo $h($l['subject_name']); ?></option><?php endforeach; ?></select></td>
                    <td><span class="badge badge-<?php echo $st['chosen'] ? 'success' : 'warning'; ?>"><?php echo $st['chosen'] ? 'Saved' : 'Not saved'; ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <p class="form-hint"><i class="fas fa-info-circle"></i> Religion অনুযায়ী আগে থেকে বাছা আছে — Save করার আগে চেক করে নিন। হলুদ সারি = religion থেকে বোঝা যায়নি, হাতে বাছুন। ফাঁকা রাখলে আগের বাছাই যেমন আছে তেমনই থাকবে।</p>
        <div class="btn-group"><button type="submit" name="save_third_language" class="btn btn-success"><i class="fas fa-save"></i> Save Third Language</button></div>
    </form>
    <?php endif; ?>
    <?php endif; ?>
</div>
<script>
(function () {
    var form = document.getElementById('tl-form');
    if (!form) return;
    form.addEventListener('change', function (e) {
        if (e.target.tagName !== 'SELECT') return;
        e.target.classList.toggle('empty', e.target.value === '');
        var badge = e.target.closest('tr').querySelector('.badge');
        badge.className = 'badge badge-warning';
        badge.textContent = 'Changed — not saved';
    });
    form.addEventListener('submit', function (e) {
        var blank = form.querySelectorAll('select.empty').length;
        if (blank && !confirm(blank + ' জনের ভাষা বাছা হয়নি — তাদের আগের বাছাই (থাকলে) যেমন আছে থাকবে। Save করবেন?')) e.preventDefault();
    });
})();
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/security.php';

// Try to raise limits for larger databases. On free hosts these may be
// locked by the provider and simply have no effect — that's fine, it
// won't cause an error, it just won't take effect.
@set_time_limit(120);
@ini_set('memory_limit', '256M');

// ============================================
// Pure-PHP database dump (no shell_exec / mysqldump needed —
// works on hosts like InfinityFree where shell functions are disabled).
// ============================================
function generate_backup_sql($conn, $database_name) {
    $output  = "-- ============================================\n";
    $output .= "-- SchoolMS Database Backup\n";
    $output .= "-- Database : $database_name\n";
    $output .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $output .= "-- ============================================\n\n";
    $output .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

    $tables_result = mysqli_query($conn, "SHOW TABLES");
    while ($table_row = mysqli_fetch_row($tables_result)) {
        $table = $table_row[0];

        // ---- Table structure ----
        $output .= "-- --------------------------------------------------------\n";
        $output .= "-- Table structure for `$table`\n";
        $output .= "-- --------------------------------------------------------\n\n";
        $output .= "DROP TABLE IF EXISTS `$table`;\n";

        $create_result = mysqli_query($conn, "SHOW CREATE TABLE `$table`");
        $create_row = mysqli_fetch_row($create_result);
        $output .= $create_row[1] . ";\n\n";

        // ---- Table data ----
        $data_result = mysqli_query($conn, "SELECT * FROM `$table`");

        if ($data_result && mysqli_num_rows($data_result) > 0) {
            $output .= "-- Dumping data for table `$table`\n\n";

            $field_names = [];
            while ($field = mysqli_fetch_field($data_result)) {
                $field_names[] = "`{$field->name}`";
            }
            $fields_sql = implode(',', $field_names);

            $batch = [];
            $batch_size = 200; // group INSERTs so the file stays readable & restorable
            $count = 0;

            while ($row = mysqli_fetch_row($data_result)) {
                $values = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $values[] = "NULL";
                    } else {
                        $values[] = "'" . mysqli_real_escape_string($conn, $value) . "'";
                    }
                }
                $batch[] = "(" . implode(',', $values) . ")";
                $count++;

                if ($count % $batch_size === 0) {
                    $output .= "INSERT INTO `$table` ($fields_sql) VALUES\n" . implode(",\n", $batch) . ";\n\n";
                    $batch = [];
                }
            }
            if (!empty($batch)) {
                $output .= "INSERT INTO `$table` ($fields_sql) VALUES\n" . implode(",\n", $batch) . ";\n\n";
            }
        } else {
            $output .= "-- (no data in `$table`)\n\n";
        }
    }

    $output .= "SET FOREIGN_KEY_CHECKS=1;\n";
    return $output;
}

// ============================================
// Handle download request
// ============================================
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_backup'])) {
    verify_csrf_or_die();

    $sql_content = generate_backup_sql($conn, $database);
    $filename = "schoolms_backup_" . date('Y-m-d_His') . ".sql";

    // Clear any earlier output (whitespace, notices) so the file isn't corrupted
    if (ob_get_length()) {
        ob_end_clean();
    }

    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . strlen($sql_content));
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    echo $sql_content;
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Backup</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .backup-box{background:#f8f9fa;border:1px solid #e4edf6;border-radius:12px;padding:30px;text-align:center;}
        .backup-box i.fa-database{font-size:48px;color:#1f5b8a;margin-bottom:15px;}
        .backup-box h3{color:#1a3b55;margin-bottom:8px;}
        .backup-box p{color:#6c7a8a;margin-bottom:20px;}
        .btn-backup{
            background:#28a745;color:#fff;border:none;padding:14px 30px;
            border-radius:8px;font-size:16px;text-decoration:none;display:inline-block;
        }
        .btn-backup:hover{background:#218838;color:#fff;}
        .steps-box{background:#e8f4ff;border:1px solid #c9e3ff;border-radius:10px;
            padding:16px 20px;margin-top:20px;text-align:left;font-size:14px;color:#003366;}
        .steps-box ol{margin-left:18px;line-height:1.9;}
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-database"></i> Database Backup</div>
        <a href="dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>

    <div class="backup-box">
        <i class="fas fa-database"></i>
        <h3>Backup Your Database</h3>
        <p>This creates a full .sql file of your database (students, marks, fees, attendance — everything) and downloads it straight to your computer.</p>

        <form method="post" action="backup_now.php" style="margin:0;">
            <?php echo csrf_field(); ?>
            <button type="submit" name="download_backup" value="1" class="btn-backup">
                <i class="fas fa-download"></i> Backup Now
            </button>
        </form>

        <div class="steps-box">
            <strong>এরপর যা করবেন:</strong>
            <ol>
                <li>ডাউনলোড হওয়া <code>.sql</code> ফাইলটা আপনার কম্পিউটারের কোনো নির্দিষ্ট ফোল্ডারে রাখুন।</li>
                <li>সেই ফাইলটা Google Drive এ আপলোড করে দিন (drive.google.com এ গিয়ে "New → File Upload", অথবা Google Drive Desktop app থাকলে সেই sync ফোল্ডারে ফেললেই automatic আপলোড হয়ে যাবে)।</li>
                <li>ফাইলের নামে তারিখ ও সময় থাকে (যেমন <code>schoolms_backup_2026-07-04_143022.sql</code>), তাই আলাদা আলাদা backup গুলো গুলিয়ে যাবে না।</li>
                <li>নিয়মিত (সপ্তাহে অন্তত ১-২ বার) এই বাটনে ক্লিক করে backup নেওয়ার অভ্যাস রাখুন।</li>
            </ol>
        </div>
    </div>
</div>

</body>
</html>
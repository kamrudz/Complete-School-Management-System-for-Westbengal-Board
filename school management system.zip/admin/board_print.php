<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/board_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Board print views (opened from includes/board_registration_page.php and includes/board_exam_steps.php), A4:
 *   what=slips     one verification slip per student — photo, signature, every detail the board asks for, a blank
 *                  line (marked ✱) for what is still missing, room for corrections and three signatures. The
 *                  guardian checks it before anything is entered in the board's portal. only=ready|notready;
 *                  scope=sentup&myear=Y: the exam class sent up for the exam of year Y (the form fill-up).
 *   what=register  the registration-certificate distribution register, one page per section, in roll order.
 *   what=admit     an admit-card distribution register (myear=Y; HS: sem=3|4), one page per section, in Reg. No order.
 * g=M|F: boys or girls only. Read-only.
 */
$board = (string)($_GET['board'] ?? '');
if (!isset(BOARDS[$board])) { http_response_code(404); exit('Unknown board.'); }
$B = BOARDS[$board];
$what = in_array($_GET['what'] ?? '', ['register', 'admit'], true) ? $_GET['what'] : 'slips';
$session_id = (int)($_GET['session_id'] ?? 0);
$classes = board_classes($board);
$class_id = (int)($_GET['class_id'] ?? 0);
$sentup = $what === 'slips' && ($_GET['scope'] ?? '') === 'sentup';
$myear = (int)($_GET['myear'] ?? 0);
$exam = BOARD_EXAMS[$board]['exam'];
$sem = (int)($_GET['sem'] ?? array_key_first(BOARD_EXAMS[$board]['admits']));
if ($what === 'admit' || $sentup) {   // the exam views: the exam class and an exam year
    $class_id = board_exam_class($board);
    if (!board_exam_year_ok($myear) || !isset(BOARD_EXAMS[$board]['admits'][$sem])) { http_response_code(404); exit("Choose the $exam year on the board page first."); }
}
$admit = $sem ? "Semester $sem admit" : 'Admit';
if (!isset(exam_sessions()[$session_id]) || !isset($classes[$class_id])) { http_response_code(404); exit('Choose the session and class on the registration page first.'); }
$section_id = (int)($_GET['section_id'] ?? 0);
$section = $section_id ? db_get_row('SELECT section_name FROM sections WHERE id = ? AND session_id = ? AND class_id = ?', 'iii', $section_id, $session_id, $class_id) : null;
if (!$section) $section_id = 0;
$show = isset(BOARD_SHOW[$_GET['g'] ?? '']) ? (string)($_GET['g'] ?? '') : '';
$only = in_array($_GET['only'] ?? '', ['ready', 'notready'], true) ? $_GET['only'] : '';

$exam_rows = $what === 'admit' || $sentup ? board_exam_rows($board, $myear, $class_id, $section_id, board_gender($show)) : [];
$students = $what === 'admit' ? $exam_rows : board_students($board, $session_id, $class_id, $section_id, board_gender($show));
if ($sentup) $students = array_intersect_key($students, $exam_rows);
$missing = [];
if ($what === 'slips') foreach ($students as $uid => $st) $missing[$uid] = board_missing($st, $board);
if ($what === 'slips' && $only) $students = array_filter($students, fn($st) => ($only === 'ready') === !$missing[$st['uid']]);

$session = exam_session_name($session_id);
$class = 'Class ' . $classes[$class_id] . ($section ? '-' . $section['section_name'] : '') . ($show !== '' ? ' · ' . BOARD_SHOW[$show] : '');
$title = match (true) {
    $sentup => "$exam $myear — Form Fill-up Verification Slip",
    $what === 'slips' => "{$B['name']} Registration — Verification Slip",
    $what === 'admit' => "$exam $myear — $admit Card Distribution Register",
    default => "{$B['name']} Registration Certificates — Distribution Register",
};
ob_start(); exam_school_header($title, "{$B['board']} · Session $session" . ($myear && ($sentup || $what === 'admit') ? " · $exam $myear" : ''));
$header = ob_get_clean();   // the same header on every page: read once

/** A slip's value cell: the value, or a blank line to write on; ✱ where the board needs it and it is missing or wrong. */
function board_slip_cell(string $v, ?array $miss): string {
    $cls = 'v' . ($miss ? ' need' : '');
    if ($v === '') return "<td class=\"$cls\"></td>";
    return "<td class=\"$cls\">" . h($v) . ($miss && $miss[1] !== '' ? '<span class="chk">Check: ' . h($miss[1]) . '</span>' : '') . '</td>';
}

/** Two label/value pairs to a row. $rows = [[label, value, check key | null], …]. */
function board_slip_rows(array $rows, array $miss): string {
    $out = '';
    foreach (array_chunk($rows, 2) as $pair) {
        $out .= '<tr>';
        foreach ($pair as [$label, $v, $key]) $out .= '<td class="l">' . h($label) . '</td>' . board_slip_cell(trim((string)$v), $key ? ($miss[$key] ?? null) : null);
        if (count($pair) === 1) $out .= '<td class="l"></td><td class="v"></td>';
        $out .= '</tr>';
    }
    return $out;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h(($what === 'slips' ? ($sentup ? "$exam $myear form fill-up slips" : "{$B['name']} verification slips") : ($what === 'admit' ? "$exam $myear " . strtolower($admit) . " register" : "{$B['name']} certificate register")) . ' — ' . $class); ?></title>
<style>
    @page { size: A4 portrait; margin: 10mm 12mm; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: 'Segoe UI', Arial, sans-serif; color: #111; background: #e9edf1; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .bar { position: sticky; top: 0; z-index: 5; background: #fff; border-bottom: 1px solid #cfd8e2; padding: 10px 16px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; font-size: 13px; color: #33475b; }
    .bar b { color: #111; } .bar .sp { margin-left: auto; display: flex; gap: 8px; }
    .bar button { border: 0; border-radius: 8px; padding: 8px 16px; font-size: 13.5px; font-weight: 600; cursor: pointer; background: #e4e9ef; color: #1f2d3a; }
    .bar button.go { background: <?php echo $board === 'wbchse' ? '#0f4c5c' : '#3b1d5c'; ?>; color: #fff; }
    .sheet { width: 210mm; min-height: 297mm; margin: 14px auto; background: #fff; padding: 10mm 12mm; box-shadow: 0 2px 14px rgba(0,0,0,.14); break-after: page; page-break-after: always; }
    .sheet:last-of-type { break-after: auto; page-break-after: auto; }
    .none { max-width: 520px; margin: 60px auto; background: #fff; padding: 26px; border-radius: 12px; text-align: center; color: #55677a; }
    /* slip */
    .who { display: flex; gap: 14px; margin: 4px 0 10px; }
    .who .info { flex: 1; min-width: 0; }
    .who h2 { margin: 2px 0 4px; font-size: 21px; letter-spacing: .3px; }
    .who .meta { font-size: 12.5px; color: #333; line-height: 1.7; }
    .who .meta b { font-size: 13.5px; }
    .status { margin-top: 6px; font-size: 12px; padding: 5px 8px; border-radius: 6px; display: inline-block; }
    .status.ok { background: #e6f5ea; color: #1b7a3a; } .status.bad { background: #fdecea; color: #8e1b1b; }
    .box { border: 1.5px dashed #777; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 11px; color: #666; flex: none; overflow: hidden; }
    .box img { width: 100%; height: 100%; object-fit: contain; }
    .box.need { border-color: #b71c1c; color: #8e1b1b; }
    .photo { width: 32mm; height: 40mm; } .photo img { object-fit: cover; }
    .sig { width: 62mm; height: 17mm; }
    table.f { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-bottom: 7px; }
    table.f th { text-align: left; background: #eef1f5; font-size: 11px; text-transform: uppercase; letter-spacing: .5px; padding: 4px 7px; border: 1px solid #c3ccd6; }
    table.f td { border: 1px solid #c3ccd6; padding: 4px 7px; height: 8.2mm; vertical-align: middle; }
    table.f td.l { width: 17%; color: #3d4f61; font-size: 11.5px; background: #f8f9fb; }
    table.f td.v { width: 33%; font-weight: 600; }
    table.f td.v.need { background: #fff7f6; }
    table.f td.v.need::before { content: '\2731'; float: right; color: #b71c1c; font-weight: 700; margin-left: 6px; }
    table.f td.v .chk { display: block; font-weight: 400; font-size: 10.5px; color: #b71c1c; }
    .row2 { display: flex; gap: 14px; align-items: flex-end; margin: 8px 0 4px; font-size: 12px; }
    .corr { flex: 1; border: 1px solid #c3ccd6; padding: 5px 8px; font-size: 11.5px; color: #3d4f61; }
    .corr .ln { border-bottom: 1px dotted #888; height: 7.5mm; }
    .sigs { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-top: 16mm; font-size: 11.5px; text-align: center; }
    .sigs div { border-top: 1px solid #333; padding-top: 4px; }
    .foot { font-size: 10.5px; color: #555; margin-top: 8px; line-height: 1.5; }
    /* register */
    table.reg { width: 100%; border-collapse: collapse; font-size: 12px; }
    table.reg th, table.reg td { border: 1px solid #555; padding: 4px 6px; }
    table.reg th { background: #eceff3; font-size: 10.5px; text-transform: uppercase; letter-spacing: .3px; }
    table.reg td { height: 10mm; } table.reg td.c { text-align: center; } table.reg td.uid { white-space: nowrap; font-size: 11px; } table.reg tr { break-inside: avoid; page-break-inside: avoid; }
    table.reg .dim { color: #888; font-style: italic; font-size: 11px; }
    .reg-head { display: flex; justify-content: space-between; font-size: 12.5px; margin: 0 0 6px; }
    .reg-foot { display: flex; justify-content: space-between; gap: 20px; margin-top: 16mm; font-size: 12px; } .reg-foot div { border-top: 1px solid #333; padding-top: 4px; min-width: 55mm; text-align: center; }
    @media screen and (max-width: 840px) { .sheet { width: auto; min-height: 0; margin: 8px; padding: 14px; } .who { flex-wrap: wrap; } .sigs { grid-template-columns: repeat(2, 1fr); } }
    @media print { body { background: #fff; } .bar { display: none; } .sheet { margin: 0; box-shadow: none; width: auto; min-height: 0; padding: 0; } }
</style>
</head>
<body>
<div class="bar">
    <span><b><?php echo count($students); ?></b> <?php echo $what === 'slips' ? 'slip(s)' : 'student(s)'; ?> · <?php echo h($class . ' · ' . $session . ($only ? ' · only ' . ($only === 'ready' ? 'ready' : 'not ready') : '')); ?></span>
    <span>A4, portrait — in the print dialog untick “Headers and footers”.</span>
    <span class="sp"><button type="button" onclick="window.close()">Close</button><button type="button" class="go" onclick="window.print()">&#128424; Print</button></span>
</div>

<?php if (!$students): ?>
    <div class="none">No student to print for <?php echo h($class . ' · ' . $session); ?>.</div>

<?php elseif ($what === 'slips'): foreach ($students as $uid => $st): $m = $missing[$uid];
    $mobile = trim((string)$st['mobile']) ?: (trim((string)$st['father_mobile']) ?: trim((string)$st['guardian_contact'])); ?>
<div class="sheet">
    <?php echo $header; ?>
    <div class="who">
        <div class="info">
            <h2><?php echo h($st['student_name']); ?></h2>
            <div class="meta">
                School UID <b><?php echo h($uid); ?></b> &nbsp;·&nbsp; Class <b><?php echo h($classes[$class_id]); ?></b> &nbsp;·&nbsp; Section <b><?php echo h($st['section_name'] ?? '—'); ?></b> &nbsp;·&nbsp; Roll <b><?php echo h($st['roll_no'] ?? '—'); ?></b>
                <?php if (trim((string)$st['registration_no']) !== ''): ?><br><?php echo h($B['board']); ?> Reg. No <b><?php echo h($st['registration_no']); ?></b> of <?php echo h((string)$st['registration_year']); ?><?php endif; ?>
                <?php if ($sentup): ?><br>Sent up for <b><?php echo h("$exam $myear"); ?></b><?php endif; ?>
            </div>
            <?php if ($m): ?><div class="status bad">Still needed: <?php echo h(implode(', ', array_map(fn($x) => $x[0], $m))); ?> — please write it in or bring it.</div>
            <?php else: ?><div class="status ok">&#10003; All details are in — please check each one.</div><?php endif; ?>
        </div>
        <div class="box photo<?php echo isset($m['photo']) ? ' need' : ''; ?>"><?php if (trim((string)$st['photo']) !== ''): ?><img src="../uploads/students/<?php echo rawurlencode($st['photo']); ?>" alt=""><?php else: ?>Paste a recent<br>passport-size<br>photo here<?php endif; ?></div>
    </div>

    <table class="f">
        <tr><th colspan="4">Student</th></tr>
        <?php echo board_slip_rows([
            ['Name as per Aadhaar', $st['name_as_per_aadhaar'], null], ['Date of birth', board_date($st['dob']), 'dob'],
            ['Gender', $st['gender'], 'gender'], ['Religion', $st['religion'], 'religion'],
            ['Caste', $st['caste'], 'caste'], ['Nationality', $st['nationality'], 'nationality'],
            ['Mother tongue', $st['mother_tongue'], null], ['Aadhaar no.', $st['student_aadhaar'], 'student_aadhaar'],
            ['Banglar Shiksha ID', $st['banglarshiksha_id'], 'banglarshiksha_id'], ['Mobile', $mobile, 'mobile'],
            ['PEN', $st['pen_id'], null], ['APAAR ID', $st['apaar_id'], null],
        ], $m); ?>
        <tr><th colspan="4">Parents / Guardian</th></tr>
        <?php echo board_slip_rows([
            ['Father', $st['father_name'], 'father_name'], ['Mother', $st['mother_name'], 'mother_name'],
            ['Guardian', $st['guardian_name'], null], ['Guardian phone', $st['guardian_contact'], null],
        ], $m); ?>
        <tr><th colspan="4">Address</th></tr>
        <?php echo board_slip_rows([
            ['Village / Town', $st['village'], 'village'], ['Post office', $st['post_office'], 'post_office'],
            ['Police station', $st['police_station'], 'police_station'], ['District', $st['district'], 'district'],
            ['State', $st['state'], null], ['PIN', $st['pin_code'], 'pin_code'],
        ], $m); ?>
        <?php if ($board === 'wbchse'): ?>
        <tr><th colspan="4">Madhyamik &amp; HS subjects</th></tr>
        <?php echo board_slip_rows([
            ['Madhyamik board', $st['mp_board'], 'madhyamik'], ['Madhyamik year', $st['mp_year'], 'madhyamik'],
            ['Madhyamik roll', $st['mp_roll_no'], 'madhyamik'], ['Subjects chosen', (int)$st['subject_count'] ? $st['subject_count'] . ' subject(s)' : '', 'subjects'],
        ], $m); ?>
        <tr><td class="l">HS subjects</td><?php echo str_replace('<td class="v', '<td colspan="3" class="v', board_slip_cell(trim((string)$st['subject_names']), $m['subjects'] ?? null)); ?></tr>
        <?php endif; ?>
    </table>

    <div class="row2">
        <div class="corr"><b>Corrections, if any</b> (write the right detail clearly):<div class="ln"></div><div class="ln"></div><div class="ln"></div></div>
        <div>
            <div class="box sig<?php echo isset($m['signature']) ? ' need' : ''; ?>"><?php if (trim((string)$st['signature']) !== ''): ?><img src="../uploads/students/signatures/<?php echo rawurlencode($st['signature']); ?>" alt=""><?php else: ?>Student signs here<br>(for the board)<?php endif; ?></div>
            <div style="text-align:center;font-size:11px;margin-top:3px">Student's signature on record</div>
        </div>
    </div>

    <div class="sigs"><div>Student</div><div>Guardian</div><div>Class teacher</div><div>Date</div></div>
    <div class="foot">&#10033; marks what the board needs and is not filled in (or is wrong) yet. I have checked every detail above; they are correct, or corrected in writing. — The details go to the <?php echo h($B['board']); ?> portal exactly as they stand here.</div>
</div>
<?php endforeach; ?>

<?php elseif ($what === 'admit'):
    $by_section = [];
    foreach ($students as $uid => $r) $by_section[$r['cc'] ? 'CC candidates' : 'Section ' . ($r['section_name'] ?? '—')][$uid] = $r;
    ksort($by_section, SORT_NATURAL);
    [, , $rc, $nc] = board_admit_cols($board, $sem);   // this admit's Roll and No. columns
    foreach ($by_section as $sec => $list): $given = count(array_filter($list, fn($r) => trim((string)$r[$rc]) !== '' && trim((string)$r[$nc]) !== '')); ?>
<div class="sheet">
    <?php echo $header; ?>
    <div class="reg-head"><b>Class <?php echo h($classes[$class_id]); ?> · <?php echo h($sec); ?></b><span><?php echo count($list); ?> student(s) · <?php echo $given; ?> with a Roll and No.</span></div>
    <table class="reg">
        <thead><tr><th>#</th><th>School UID</th><th>Student</th><th>Father</th><th>Reg. No</th><th>Roll</th><th>No.</th><th>Date received</th><th style="width:30mm">Signature</th></tr></thead>
        <tbody>
        <?php $n = 0; foreach ($list as $uid => $r): ?>
            <tr>
                <td class="c"><?php echo ++$n; ?></td>
                <td class="uid"><?php echo h($uid); ?></td>
                <td><b><?php echo h($r['student_name']); ?></b></td>
                <td><?php echo h((string)$r['father_name']); ?></td>
                <td><?php echo h((string)$r['registration_no']); ?></td>
                <td class="c"><?php echo trim((string)$r[$rc]) !== '' ? '<b>' . h($r[$rc]) . '</b>' : '<span class="dim">—</span>'; ?></td>
                <td class="c"><?php echo trim((string)$r[$nc]) !== '' ? '<b>' . h($r[$nc]) . '</b>' : '<span class="dim">—</span>'; ?></td>
                <td></td><td></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="reg-foot"><div>Handed out by</div><div>Class teacher</div><div>Headmaster / Headmistress</div></div>
</div>
<?php endforeach; ?>

<?php else:
    $by_section = [];
    foreach ($students as $uid => $st) $by_section[(string)($st['section_name'] ?? '—')][$uid] = $st;
    foreach ($by_section as $sec => $list): $given = count(array_filter($list, fn($st) => trim((string)$st['registration_no']) !== '')); ?>
<div class="sheet">
    <?php echo $header; ?>
    <div class="reg-head"><b>Class <?php echo h($classes[$class_id]); ?> · Section <?php echo h($sec); ?></b><span><?php echo count($list); ?> student(s) · <?php echo $given; ?> with a Reg. No</span></div>
    <table class="reg">
        <thead><tr><th>#</th><th>School UID</th><th>Student</th><th>Father</th><th>Roll</th><th>Reg. No</th><th>Year</th><th>Date received</th><th style="width:30mm">Signature</th></tr></thead>
        <tbody>
        <?php $n = 0; foreach ($list as $uid => $st): $no = trim((string)$st['registration_no']); ?>
            <tr>
                <td class="c"><?php echo ++$n; ?></td>
                <td class="uid"><?php echo h($uid); ?></td>
                <td><b><?php echo h($st['student_name']); ?></b></td>
                <td><?php echo h((string)$st['father_name']); ?></td>
                <td class="c"><?php echo h((string)$st['roll_no']); ?></td>
                <td><?php echo $no !== '' ? '<b>' . h($no) . '</b>' : '<span class="dim">not yet</span>'; ?></td>
                <td class="c"><?php echo h((string)$st['registration_year']); ?></td>
                <td></td><td></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="reg-foot"><div>Handed out by</div><div>Class teacher</div><div>Headmaster / Headmistress</div></div>
</div>
<?php endforeach; endif; ?>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

$search = trim($_GET['search'] ?? '');
$category_id = (int)($_GET['category_id'] ?? 0);
$page_num = max(1, (int)($_GET['p'] ?? 1));
$per_page = 20;
$offset = ($page_num - 1) * $per_page;

$where = "b.status='Active'";
$params = [];
$types = '';
if ($search !== '') {
    $where .= " AND (b.title LIKE CONCAT('%',?,'%') OR b.author LIKE CONCAT('%',?,'%') OR b.isbn LIKE CONCAT('%',?,'%'))";
    $params[] = $search; $params[] = $search; $params[] = $search;
    $types .= 'sss';
}
if ($category_id > 0) {
    $where .= " AND b.category_id=?";
    $params[] = $category_id;
    $types .= 'i';
}

// ===== total count (for pagination) =====
$count_stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS total FROM library_books b WHERE $where");
if ($types !== '') { mysqli_stmt_bind_param($count_stmt, $types, ...$params); }
mysqli_stmt_execute($count_stmt);
$total_rows = (int)(mysqli_fetch_assoc(mysqli_stmt_get_result($count_stmt))['total'] ?? 0);
$total_pages = max(1, (int)ceil($total_rows / $per_page));
if ($page_num > $total_pages) { $page_num = $total_pages; $offset = ($page_num - 1) * $per_page; }

// ===== page of results =====
$stmt = mysqli_prepare($conn, "
    SELECT b.*, cat.category_name,
           (SELECT COUNT(*) FROM library_book_copies c WHERE c.book_id=b.id) AS total_copies,
           (SELECT COUNT(*) FROM library_book_copies c WHERE c.book_id=b.id AND c.status='Available') AS available_copies,
           (SELECT COUNT(*) FROM library_book_copies c WHERE c.book_id=b.id AND c.status='Issued') AS issued_copies
    FROM library_books b
    LEFT JOIN library_categories cat ON cat.id = b.category_id
    WHERE $where
    ORDER BY b.title ASC
    LIMIT ? OFFSET ?
");
$bind_types = $types . 'ii';
$bind_params = array_merge($params, [$per_page, $offset]);
mysqli_stmt_bind_param($stmt, $bind_types, ...$bind_params);
mysqli_stmt_execute($stmt);
$q = mysqli_stmt_get_result($stmt);

$categories = mysqli_query($conn, "SELECT * FROM library_categories ORDER BY category_name ASC");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Books</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display:flex; gap:10px; flex-wrap:wrap; }
.filter-box input, .filter-box select { padding: 9px 12px; border: 2px solid #e4edf6; border-radius: 8px; }
.filter-box input { flex: 1; min-width: 200px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
table th, table td { padding: 10px 12px; border-bottom: 1px solid #e4edf6; text-align: left; }
table th { background: #003366; color: #fff; }
.badge { padding: 3px 10px; border-radius: 10px; font-size: 11px; font-weight: 700; }
.badge-green { background: #d4edda; color: #155724; }
.badge-red { background: #f8d7da; color: #842029; }
.pagination-bar { display: flex; justify-content: space-between; align-items: center; margin-top: 14px; flex-wrap: wrap; gap: 10px; }
.page-info { font-size: 12.5px; color: #6c7a8a; }
.page-links { display: flex; align-items: center; gap: 12px; }
.page-btn { padding: 7px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 13px; font-weight: 600; color: #003366; text-decoration: none; }
.page-btn:hover { border-color: #1f5b8a; background: #f0f7ff; }
.page-btn.disabled { pointer-events: none; opacity: 0.4; }
.page-current { font-size: 13px; font-weight: 600; color: #1a3b55; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-book"></i> Books</div>
        <a href="add_book.php" class="btn btn-success"><i class="fas fa-plus"></i> Add Book</a>
    </div>

    <form method="GET" class="filter-box">
        <input type="text" name="search" placeholder="Search by title, author, or ISBN..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="category_id">
            <option value="0">All Categories</option>
            <?php mysqli_data_seek($categories, 0); while ($c = mysqli_fetch_assoc($categories)): ?>
            <option value="<?php echo $c['id']; ?>" <?php echo $category_id==$c['id']?'selected':''; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
            <?php endwhile; ?>
        </select>
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
    </form>

    <div style="overflow-x:auto;">
    <table>
        <tr><th>Title</th><th>Author</th><th>Category</th><th>Total Copies</th><th>Available</th><th>Issued</th><th>Price</th><th>Action</th></tr>
        <?php $any = false; while ($b = mysqli_fetch_assoc($q)): $any = true; ?>
        <tr>
            <td><strong><?php echo htmlspecialchars($b['title']); ?></strong><?php if($b['edition']): ?><br><small style="color:#6c7a8a;">Ed: <?php echo htmlspecialchars($b['edition']); ?></small><?php endif; ?></td>
            <td><?php echo htmlspecialchars($b['author'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($b['category_name'] ?? '-'); ?></td>
            <td><?php echo (int)$b['total_copies']; ?></td>
            <td><span class="badge <?php echo $b['available_copies']>0?'badge-green':'badge-red'; ?>"><?php echo (int)$b['available_copies']; ?></span></td>
            <td><?php echo (int)$b['issued_copies']; ?></td>
            <td>₹<?php echo number_format($b['price'], 2); ?></td>
            <td><a href="edit_book.php?id=<?php echo $b['id']; ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a></td>
        </tr>
        <?php endwhile; ?>
        <?php if (!$any): ?><tr><td colspan="8" style="text-align:center;color:#a4161a;padding:20px;">No books found.</td></tr><?php endif; ?>
    </table>
    </div>

    <?php if ($total_pages > 1): ?>
    <div class="pagination-bar">
        <span class="page-info">Showing <?php echo $offset + 1; ?>–<?php echo min($offset + $per_page, $total_rows); ?> of <?php echo $total_rows; ?> books</span>
        <div class="page-links">
            <?php
            $qs = function($p) use ($search, $category_id) {
                return '?p=' . $p . '&search=' . urlencode($search) . '&category_id=' . $category_id;
            };
            ?>
            <a href="<?php echo $qs(max(1, $page_num - 1)); ?>" class="page-btn <?php echo $page_num <= 1 ? 'disabled' : ''; ?>"><i class="fas fa-chevron-left"></i> Prev</a>
            <span class="page-current">Page <?php echo $page_num; ?> of <?php echo $total_pages; ?></span>
            <a href="<?php echo $qs(min($total_pages, $page_num + 1)); ?>" class="page-btn <?php echo $page_num >= $total_pages ? 'disabled' : ''; ?>">Next <i class="fas fa-chevron-right"></i></a>
        </div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

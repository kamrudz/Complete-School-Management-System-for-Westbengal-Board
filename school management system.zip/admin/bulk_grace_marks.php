<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Grace marks: exam → class → subject → the students who failed that subject (marks incl. any grace < pass marks),
 * plus those already carrying grace. Grace is stored in marks.grace_marks — the marks obtained stay untouched
 * and every result page shows grace with a † mark.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = exam_list($session_id);
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = $e['exam_name'];
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$subject_id = (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0);
$subjects = ($exam && $class_id) ? array_filter(exam_subjects($session_id, $exam_id, $class_id), fn($s) => $s['configured']) : [];
$subject = $subjects[$subject_id] ?? null;
$ready = $exam && $class_id && $subject;
$max_grace = 10;
$qs = "exam_id=$exam_id&class_id=$class_id&section=$section&subject_id=$subject_id";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_grace']) && $ready) {
    verify_csrf_or_die();
    $r = marks_save_grace($session_id, $exam_id, $class_id, $subject_id, (array)($_POST['g'] ?? []), $admin_id, $max_grace);
    $_SESSION[$r['ok'] ? 'success' : 'error'] = $r['ok'] ? 'Grace marks saved for ' . $r['saved'] . ' student' . ($r['saved'] === 1 ? '' : 's') . '.' : implode('; ', $r['errors']);
    header("Location: bulk_grace_marks.php?$qs"); exit;
}

$rows = [];
if ($ready) {
    $res = result_exam($session_id, $class_id, $exam_id);
    foreach ($res['students'] as $uid => $st) {
        $s = $st['subjects'][$subject_id] ?? null; if (!$s || $s['missing']) continue;
        if ($s['fail'] || $s['grace'] > 0 || ($s['obtained'] - $s['grace']) < $s['pass']) $rows[$uid] = $st + ['sub' => $s];
    }
    $reasons = []; foreach (db_get_all('SELECT student_id, grace_reason FROM marks WHERE session_id = ? AND exam_id = ? AND subject_id = ? AND grace_marks > 0', 'iii', $session_id, $exam_id, $subject_id) as $g) $reasons[$g['student_id']] = (string)$g['grace_reason'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Grace Marks</title>
<?php exam_styles(); ?>
<style>
    .ex-table input.r { height: 32px; border: 1px solid #c9d6e2; border-radius: 6px; padding: 0 8px; font-size: 12.5px; width: 100%; min-width: 140px; }
    .ex-table td.st { font-weight: 700; font-size: 11.5px; } .ex-table td.st.p { color: #1b7a3a; } .ex-table td.st.f { color: #b71c1c; }
    .short { color: #b71c1c; font-weight: 700; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Grace Marks', 'Students who fell short of the pass marks in a subject. Grace is kept apart from the marks obtained (shown with †) and needs a reason.', 'fa-hand-holding-heart', ['tabulation_sheet.php' => '<i class="fas fa-table"></i> Tabulation']); ?>
    <?php exam_tabs('bulk_grace_marks.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No exams in this session'); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.subject_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Subject</label><select name="subject_id" onchange="this.form.submit()" <?php echo $subjects ? '' : 'disabled'; ?>><?php echo exam_options(array_map(fn($s) => $s['name'], $subjects), $subject_id, 'Select subject'); ?></select></div>
    </form>

    <?php if (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-hand-holding-heart"></i>Select exam, class and subject.</div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-hand-holding-heart"></i> <?php echo h($exam['exam_name']); ?> · Class <?php echo h($classes[$class_id]['name']); ?> · <?php echo h($subject['name']); ?> <small>pass marks <?php echo exam_fmt($subject['pass']); ?> of <?php echo exam_fmt($subject['full']); ?> · grace up to <?php echo $max_grace; ?></small></h2>
        <?php if (!$rows): ?><div class="ex-empty"><i class="fas fa-check-circle"></i>Nobody is short of the pass marks in this subject (absent students cannot be given grace).</div>
        <?php else: ?>
        <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
        <table class="ex-table"><thead><tr><th>Sec</th><th class="num">Roll</th><th>Student</th><th class="num">Obtained</th><th class="num">Short by</th><th class="num">Grace</th><th>Reason</th><th class="num">With grace</th><th class="num">Result</th></tr></thead><tbody>
        <?php foreach ($rows as $uid => $st): $s = $st['sub']; $raw = $s['obtained'] - $s['grace']; $short = max(0, $s['pass'] - $raw); ?>
        <tr data-raw="<?php echo $raw; ?>" data-pass="<?php echo $s['pass']; ?>">
            <td><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['roll']); ?></td><td><b><?php echo h($st['name']); ?></b><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($uid); ?></small></td>
            <td class="num"><?php echo $s['absent'] ? 'AB' : exam_fmt($raw); ?></td><td class="num short"><?php echo $s['absent'] ? '—' : ($short > 0 ? exam_fmt($short) : '0'); ?></td>
            <td class="num"><input class="m g" name="g[<?php echo h($uid); ?>][grace]" value="<?php echo $s['grace'] > 0 ? exam_fmt($s['grace']) : ''; ?>" inputmode="decimal" <?php echo $s['absent'] ? 'disabled' : ''; ?>></td>
            <td><input class="r" name="g[<?php echo h($uid); ?>][reason]" value="<?php echo h($reasons[$uid] ?? ''); ?>" maxlength="120" placeholder="e.g. HM's discretion" <?php echo $s['absent'] ? 'disabled' : ''; ?>></td>
            <td class="num tot"></td><td class="num st"></td>
        </tr>
        <?php endforeach; ?></tbody></table>
        <div style="margin-top:12px;display:flex;gap:10px;align-items:center"><button type="submit" name="save_grace" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save grace marks</button><span class="note" style="margin:0">Clear the box to remove grace. Only students short of the pass marks (or already with grace) are listed.</span></div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
document.querySelectorAll('tr[data-raw]').forEach(function (tr) {
    var g = tr.querySelector('input.g'), tot = tr.querySelector('.tot'), st = tr.querySelector('.st');
    function f() { if (!g || g.disabled) { tot.textContent = '—'; st.textContent = ''; return; } var v = parseFloat(g.value) || 0, t = parseFloat(tr.dataset.raw) + v; g.classList.toggle('bad', v < 0 || v > <?php echo $max_grace; ?>); tot.textContent = Math.round(t * 100) / 100 + (v > 0 ? '†' : ''); var ok = t >= parseFloat(tr.dataset.pass); st.textContent = ok ? 'Pass' : 'Fail'; st.className = 'num st ' + (ok ? 'p' : 'f'); }
    f(); if (g) g.addEventListener('input', f);
});
</script>
</body>
</html>

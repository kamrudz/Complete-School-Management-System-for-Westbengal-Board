<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/exam_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_reader.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Bulk marks upload: download the template of one exam × class (all subjects, existing marks pre-filled),
 * fill it in Excel, upload → preview (errors per row) → confirm. The School UID column is the key.
 * Cells: number · AB (absent) · NA (subject not taken, e.g. the other third language) · blank = leave unchanged.
 * Saved through marks_save_rows() per subject; rows with an error are skipped, the rest are written.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = exam_list($session_id);
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = $e['exam_name'];
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = null;
$ready = $exam && $class_id;
$subjects = $ready ? array_filter(exam_subjects($session_id, $exam_id, $class_id), fn($s) => $s['configured']) : [];
$qs = "exam_id=$exam_id&class_id=$class_id&section=$section&section_id=" . ($section_id ?: 'all');
$tmp_dir = sys_get_temp_dir();

/** Parse an uploaded workbook into per-subject rows + per-row messages. */
function bulk_parse(string $path, int $session_id, int $exam_id, int $class_id, array $subjects): array {
    $all = SimpleXLSXReader::readFirstSheet($path);
    if (count($all) < 2) return ['error' => 'The sheet has no data rows.'];
    // the header row is the one carrying the Written[..] / Project[..] labels — title rows above it are ignored
    $cols = []; $headAt = -1;
    foreach ($all as $i => $r) {
        $c = [];
        foreach ($r as $j => $label) if (preg_match('/^(Written|Project)\[(\d+)\]/i', trim((string)$label), $m)) $c[$j] = [strtolower($m[1]), (int)$m[2]];
        if ($c) { $cols = $c; $headAt = $i; break; }
    }
    if (!$cols) return ['error' => 'No subject columns found — use the downloaded template and keep its header row.'];
    $rows = array_slice($all, $headAt + 1); $offset = $headAt + 2;
    $students = exam_students($session_id, $class_id);
    $out = []; $msgs = []; $stats = ['rows' => 0, 'cells' => 0, 'absent' => 0, 'skipped' => 0, 'errors' => 0, 'na' => 0];
    foreach ($rows as $n => $r) {
        $line = $n + $offset; $uid = student_uid_clean((string)($r[0] ?? '')); if ($uid === '') continue;
        $stats['rows']++;
        $st = $students[$uid] ?? null;
        if (!$st) { $msgs[] = "Row $line: $uid is not a current student of this class — row skipped."; $stats['errors']++; continue; }
        $by = []; foreach ($cols as $i => [$type, $sid]) $by[$sid][$type] = trim((string)($r[$i] ?? ''));
        foreach ($by as $sid => $v) {
            $sub = $subjects[$sid] ?? null; if (!$sub) continue;
            $w = strtoupper($v['written'] ?? ''); $p = strtoupper($v['project'] ?? '');
            if ($w === 'NA' || $p === 'NA') { $stats['na']++; continue; }
            if (!exam_student_takes($st, $sub)) { if ($w !== '' || $p !== '') { $msgs[] = "Row $line ({$st['name']}): {$sub['name']} — does not take this subject, cell ignored."; $stats['errors']++; } continue; }
            if ($w === 'AB' || $p === 'AB') { $out[$sid][$uid] = ['absent' => 1]; $stats['absent']++; continue; }
            if ($w === '' && $p === '') { $stats['skipped']++; continue; }
            [$wv, $e1] = exam_parse_mark($w, $sub['written_full']); [$pv, $e2] = exam_parse_mark($p, $sub['project_full']);
            if ($e1 || $e2) { $msgs[] = "Row $line ({$st['name']}): {$sub['name']} — " . ($e1 ? "written $e1" : "project $e2") . ', cell skipped.'; $stats['errors']++; continue; }
            $out[$sid][$uid] = ['written' => $w, 'project' => $p]; $stats['cells']++;
        }
    }
    return ['rows' => $out, 'msgs' => $msgs, 'stats' => $stats];
}

// ── template
if ($ready && isset($_GET['download_template'])) {
    if (!$subjects) { $_SESSION['error'] = 'No full marks are set for this class in ' . $exam['exam_name'] . '.'; header("Location: bulk_marks_upload.php?$qs"); exit; }
    $students = exam_students($session_id, $class_id, $section_id); $marks = exam_marks($session_id, $exam_id, $class_id, 0, $section_id);
    // headings are broken over lines so the columns stay narrow; the Written[id] / Project[id] prefix is what the upload reads
    $head = ['School UID', 'Sec', 'Roll', 'Student'];   // grey = locked; row 3 says so
    foreach ($subjects as $sid => $s) { $c = exam_subject_code($s);   // short code keeps the column narrow; row 3 lists what each code means
        $head[] = "Written[$sid]\n$c\nmax " . exam_fmt($s['written_full']); if ($s['project_full'] > 0) $head[] = "Project[$sid]\n$c\nmax " . exam_fmt($s['project_full']); }
    $school = db_get_row('SELECT school_name FROM school_settings WHERE id = 1')['school_name'] ?? '';
    $where = 'Class ' . $classes[$class_id]['name'] . ($section_id ? ' — Section ' . $sections[$section_id] : ' — all sections');
    $rows = [
        [$school],
        [$exam['exam_name'] . '  ·  Session ' . $exam['session_name'] . '  ·  ' . $where],
        ['Type marks in the yellow columns only — the grey columns (UID, Sec, Roll, Student) and this heading are locked. AB = absent, NA = not applicable, blank = leave unchanged.'],
        [exam_subject_legend($subjects)],
        $head,
    ];
    foreach ($students as $uid => $st) {
        $r = [$uid, $st['section'], $st['roll'], $st['name']];
        foreach ($subjects as $sid => $s) {
            $m = $marks[$uid][$sid] ?? null; $take = exam_student_takes($st, $s);
            $cell = !$take ? 'NA' : ($m ? ((int)$m['is_absent'] ? 'AB' : exam_fmt($m['written_marks'])) : '');
            $r[] = $cell; if ($s['project_full'] > 0) $r[] = !$take ? 'NA' : ($m ? ((int)$m['is_absent'] ? 'AB' : exam_fmt($m['project_marks'])) : '');
        }
        $rows[] = $r;
    }
    $width = count($head);
    SimpleXLSXWriter::download('marks_' . preg_replace('/[^A-Za-z0-9]+/', '_', $exam['exam_name'] . '_class_' . $classes[$class_id]['name'] . ($section_id ? '_' . $sections[$section_id] : '')) . '.xlsx', $rows, 'Marks',
        ['title_rows' => 4, 'header_rows' => 1, 'protect' => true, 'unlocked_cols' => range(5, max(5, $width)), 'max_col_width' => 22,
         'merge_cells' => array_map(fn($r) => 'A' . $r . ':' . SimpleXLSXWriter::columnName($width) . $r, [1, 2, 3, 4])]);
    exit;
}

$preview = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    verify_csrf_or_die();
    if (isset($_POST['upload'])) {
        $f = $_FILES['file'] ?? null;
        if (!$f || (int)$f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) $_SESSION['error'] = 'Choose an .xlsx file to upload.';
        elseif ($f['size'] > 2 * 1024 * 1024) $_SESSION['error'] = 'The file is larger than 2 MB.';
        elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'xlsx' || !in_array(mime_content_type($f['tmp_name']), ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'], true)) $_SESSION['error'] = 'Only .xlsx files are accepted (save as Excel Workbook).';
        else {
            try { $p = bulk_parse($f['tmp_name'], $session_id, $exam_id, $class_id, $subjects); } catch (Throwable $e) { $p = ['error' => 'Could not read the file: ' . $e->getMessage()]; }
            if (isset($p['error'])) $_SESSION['error'] = $p['error'];
            else {
                $token = bin2hex(random_bytes(12)); $dest = $tmp_dir . DIRECTORY_SEPARATOR . 'marks_' . $token . '.xlsx';
                move_uploaded_file($f['tmp_name'], $dest);
                $_SESSION['bulk_marks'] = ['token' => $token, 'path' => $dest, 'exam_id' => $exam_id, 'class_id' => $class_id, 'time' => time()];
                $preview = $p + ['token' => $token];
            }
        }
        if (!$preview) { header("Location: bulk_marks_upload.php?$qs"); exit; }
    } elseif (isset($_POST['confirm'])) {
        $pend = $_SESSION['bulk_marks'] ?? null; unset($_SESSION['bulk_marks']);
        if (!$pend || !hash_equals($pend['token'], (string)($_POST['token'] ?? '')) || $pend['exam_id'] !== $exam_id || $pend['class_id'] !== $class_id || !is_file($pend['path'])) $_SESSION['error'] = 'The upload expired — upload the file again.';
        else {
            $p = bulk_parse($pend['path'], $session_id, $exam_id, $class_id, $subjects); @unlink($pend['path']);
            $saved = 0; $failed = [];
            foreach ($p['rows'] ?? [] as $sid => $rows) { $r = marks_save_rows($session_id, $exam_id, $class_id, (int)$sid, $rows, $admin_id); if ($r['ok']) $saved += $r['saved']; else $failed[] = $subjects[$sid]['name'] . ': ' . implode('; ', array_slice($r['errors'], 0, 3)); }
            log_action($admin_id, 'MARKS_BULK_UPLOADED', 'marks', $exam_id, null, ['class_id' => $class_id, 'saved' => $saved, 'subjects' => count($p['rows'] ?? [])]);
            $_SESSION[$failed ? 'error' : 'success'] = "$saved marks saved from the sheet" . ($failed ? '. Not saved — ' . implode(' | ', $failed) : '.');
        }
        header("Location: bulk_marks_upload.php?$qs"); exit;
    } elseif (isset($_POST['cancel'])) {
        $pend = $_SESSION['bulk_marks'] ?? null; unset($_SESSION['bulk_marks']); if ($pend && is_file($pend['path'])) @unlink($pend['path']);
        header("Location: bulk_marks_upload.php?$qs"); exit;
    }
}
$sec_opts = ['all' => 'All sections'] + $sections;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bulk Marks Upload</title>
<?php exam_styles(); ?>
<style>
    .steps { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; } @media (max-width: 900px) { .steps { grid-template-columns: 1fr; } }
    .step h3 { margin: 0 0 6px; font-size: 14px; color: #3b1d5c; } .step h3 span { display: inline-block; width: 24px; height: 24px; border-radius: 50%; background: #3b1d5c; color: #fff; text-align: center; line-height: 24px; font-size: 12px; margin-right: 6px; }
    .stats { display: flex; gap: 8px; flex-wrap: wrap; margin: 10px 0; } .stats span { padding: 6px 12px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 13px; } .stats b { font-size: 16px; display: block; }
    .msgs { max-height: 260px; overflow: auto; font-size: 12.5px; background: #fff7f7; border: 1px solid #f5b5b0; border-radius: 9px; padding: 8px 12px; } .msgs div { padding: 2px 0; border-bottom: 1px dashed #f1d3d0; }
    input[type=file] { font-size: 13px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Bulk Marks Upload', 'Download the Excel template of an exam × class, fill it in, upload. School UID is the key; blank cells are left unchanged.', 'fa-file-excel', ['marks_entry.php' => '<i class="fas fa-edit"></i> Marks Entry']); ?>
    <?php exam_tabs('bulk_marks_upload.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No exams in this session'); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options($sec_opts, $section_id ?: 'all'); ?></select></div>
    </form>

    <?php if (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-file-excel"></i>Select an exam and a class.</div></div>
    <?php elseif (!$subjects): ?><div class="card"><div class="ex-empty"><i class="fas fa-sliders-h"></i>No full marks set for Class <?php echo h($classes[$class_id]['name']); ?> in <?php echo h($exam['exam_name']); ?> — <a href="exam_subject_marks.php?exam_id=<?php echo $exam_id; ?>&class_id=<?php echo $class_id; ?>">set them first</a>.</div></div>
    <?php elseif ($preview): $s = $preview['stats']; ?>
    <div class="card">
        <h2><i class="fas fa-search"></i> Preview <small><?php echo h($exam['exam_name']); ?> · Class <?php echo h($classes[$class_id]['name']); ?> — nothing saved yet</small></h2>
        <div class="stats"><span><b><?php echo $s['rows']; ?></b>student rows</span><span><b><?php echo $s['cells']; ?></b>marks to save</span><span><b><?php echo $s['absent']; ?></b>absent (AB)</span><span><b><?php echo $s['skipped']; ?></b>blank (unchanged)</span><span><b><?php echo $s['na']; ?></b>NA</span><span style="<?php echo $s['errors'] ? 'background:#fdecea;border-color:#f5b5b0' : ''; ?>"><b><?php echo $s['errors']; ?></b>problems</span></div>
        <?php if ($preview['msgs']): ?><div class="msgs"><?php foreach ($preview['msgs'] as $m) echo '<div>' . h($m) . '</div>'; ?></div><p class="note">Problem cells are skipped; everything else is saved when you confirm.</p><?php endif; ?>
        <form method="post" style="margin-top:12px;display:flex;gap:8px"><?php echo csrf_field(); ?><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id ?: 'all'; ?>"><input type="hidden" name="token" value="<?php echo h($preview['token']); ?>">
            <button type="submit" name="confirm" value="1" class="btn btn-primary" <?php echo ($s['cells'] + $s['absent']) ? '' : 'disabled'; ?>><i class="fas fa-check"></i> Save <?php echo $s['cells'] + $s['absent']; ?> marks</button><button type="submit" name="cancel" value="1" class="btn btn-secondary">Cancel</button></form>
    </div>
    <?php else: ?>
    <div class="card"><div class="steps">
        <div class="step"><h3><span>1</span>Download the template</h3>
            <p class="note" style="margin:0 0 10px">One sheet for <?php echo h($exam['exam_name']); ?> · Class <?php echo h($classes[$class_id]['name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?>: <?php echo count($subjects); ?> subjects side by side, marks already entered are pre-filled. The sheet carries the school name, exam, session and class on top; <b>UID, Section, Roll and Student are locked</b> — only the yellow mark columns can be typed in. Type a number, <b>AB</b> for absent, leave blank to keep as is; <b>NA</b> = the student does not take that subject.</p>
            <a href="?<?php echo $qs; ?>&download_template=1" class="btn btn-secondary"><i class="fas fa-download"></i> Download .xlsx</a></div>
        <div class="step"><h3><span>2</span>Upload the filled sheet</h3>
            <form method="post" enctype="multipart/form-data" class="pf"><?php echo csrf_field(); ?><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id ?: 'all'; ?>">
                <input type="file" name="file" accept=".xlsx" required style="height:auto;padding:8px">
                <div class="acts"><button type="submit" name="upload" value="1" class="btn btn-primary"><i class="fas fa-upload"></i> Upload & preview</button></div></form>
            <p class="note">You will see a preview with any problems before anything is saved. Max 2 MB.</p></div>
    </div></div>
    <?php endif; ?>
</div>
</body>
</html>

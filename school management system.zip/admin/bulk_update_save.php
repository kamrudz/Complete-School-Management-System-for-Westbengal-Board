<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/student_fields.php';
require_once '../includes/sibling_helper.php';
require_once '../includes/security.php';
include("../includes/logger.php");

/**
 * Bulk Update — JSON save endpoint.
 *
 * Request  (POST, application/json): { csrf, session_id, changes: [ {uid, field, value}, … ] }
 * Response: { ok, saved_students, failed_students,
 *             cells: [ {uid, field, ok:true, value} | {uid, field, ok:false, error, skipped?} ],
 *             rows:  { uid: "row-level message" } }
 *
 * Phase 1 validates every changed cell against the same rules as the Add / Edit
 * forms (student_validate, student_duplicates, section-in-class, roll clash …),
 * only for the fields that actually changed. A student with any bad cell is not
 * written at all (row-atomic). Phase 2 writes each passing student in its own
 * transaction; class/section/roll changes are applied together afterwards with a
 * "roll_no = NULL first" pass so swaps survive the UNIQUE (session, class,
 * section, roll) key.
 */
header('Content-Type: application/json; charset=utf-8');
function out(array $o, int $code = 200) { http_response_code($code); echo json_encode($o, JSON_UNESCAPED_UNICODE); exit(); }

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) out(['ok' => false, 'error' => 'Bad request body.'], 400);
if (!csrf_check((string)($body['csrf'] ?? ''))) out(['ok' => false, 'error' => 'Invalid request token — reload the page.'], 403);
$session_id = (int)($body['session_id'] ?? 0);
if (!$session_id || !db_get_row('SELECT id FROM academic_sessions WHERE id = ?', 'i', $session_id)) out(['ok' => false, 'error' => 'Unknown session.'], 400);
$changes = $body['changes'] ?? [];
if (!is_array($changes) || !$changes) out(['ok' => true, 'saved_students' => 0, 'failed_students' => 0, 'cells' => [], 'rows' => []]);
if (count($changes) > 5000) out(['ok' => false, 'error' => 'Too many changes in one save (max 5000).'], 400);

$FIELDS = student_bulk_fields();
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$cells = []; $rows = [];
$cell = function (string $uid, string $field, bool $ok, string $msg = '', $value = null, bool $skipped = false) use (&$cells) {
    $c = ['uid' => $uid, 'field' => $field, 'ok' => $ok];
    if ($ok) $c['value'] = $value === null ? '' : (string)$value; else { $c['error'] = $msg; if ($skipped) $c['skipped'] = true; }
    $cells[] = $c;
};

// ---------- group by student ----------
$by = [];
foreach ($changes as $c) {
    if (!is_array($c)) continue;
    $uid = student_uid_clean($c['uid'] ?? ''); $field = (string)($c['field'] ?? '');
    if ($uid === '') { $cell((string)($c['uid'] ?? ''), $field, false, 'Unknown student.'); continue; }
    if (!isset($FIELDS[$field])) { $cell($uid, $field, false, 'This field cannot be edited here.'); continue; }
    if ($FIELDS[$field]['type'] === 'file') { $cell($uid, $field, false, 'Files are uploaded with the camera / file button, not saved from the grid.'); continue; }
    $by[$uid][$field] = trim((string)($c['value'] ?? ''));
}
if (count($by) > 300) out(['ok' => false, 'error' => 'Too many students in one save (max 300).'], 400);

// ---------- Phase 1: load + validate ----------
$plan = [];                  // uid => ['s'=>…, 'g'=>…, 'h'=>…, 'student'=>row, 'guardian'=>row|null, 'hist'=>row|null, 'changed'=>[field=>value]]
$batch_ids = [];             // government IDs seen in this batch, for in-batch duplicate detection
$batch_slots = [];           // "class|section|roll" => uid
foreach ($by as $uid => $changed) {
    $err = [];
    $student = db_get_row('SELECT * FROM students WHERE id = ?', 's', $uid);
    if (!$student) { foreach ($changed as $f => $v) $cell($uid, $f, false, 'Student not found.'); continue; }
    if ($student['student_status'] !== 'Active') { foreach ($changed as $f => $v) $cell($uid, $f, false, "Student is {$student['student_status']} — only Active students can be edited here."); continue; }
    $guardian = $student['guardian_id'] ? db_get_row('SELECT * FROM guardians WHERE guardian_id = ?', 'i', $student['guardian_id']) : null;
    $hist = db_get_row("SELECT * FROM student_academic_history WHERE student_id = ? AND session_id = ? AND academic_status = 'Current' LIMIT 1", 'si', $uid, $session_id);

    // merged values: DB row overlaid with the changes, normalised
    $s = $student; $g = $guardian ?: []; $h = $hist ?: [];
    foreach ($changed as $f => $v) {
        $d = $FIELDS[$f];
        if ($d['upper']) $v = strtoupper($v);
        if ($d['max'] && mb_strlen($v) > $d['max']) $err[$f] = "At most {$d['max']} characters.";
        if ($d['type'] === 'select' && $v !== '' && !in_array($v, $d['options'], true)) {
            // accept a case-insensitive match (pasted ISLAM → Islam), else refuse
            $hit = null; foreach ($d['options'] as $o) if (strcasecmp($o, $v) === 0) { $hit = $o; break; }
            if ($hit === null) $err[$f] = 'Not one of the allowed values.'; else $v = $hit;
        }
        if ($d['type'] === 'date' && $v !== '') {
            if (preg_match('~^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$~', $v, $m)) $v = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);   // dd/mm/yyyy from Excel
            $dt = DateTime::createFromFormat('Y-m-d', $v);
            if (!$dt || $dt->format('Y-m-d') !== $v) $err[$f] = 'Not a valid date (YYYY-MM-DD).';
        }
        $changed[$f] = $v;
        if ($d['table'] === 'students') $s[$d['col']] = $v; elseif ($d['table'] === 'guardians') $g[$d['col']] = $v; else $h[$d['col']] = $v;
    }
    if (isset($changed['disability']) && $changed['disability'] !== 'Yes') { $s['disability_type'] = ''; $s['disability_percentage'] = ''; }
    if (isset($changed['admission_date']) && $changed['admission_date'] !== '' && empty($err['admission_date']) && trim((string)($s['admission_year'] ?? '')) === '') {
        $s['admission_year'] = substr($changed['admission_date'], 0, 4); $changed['admission_year'] = $s['admission_year'];
    }

    // --- students-table rules (only the changed fields count) ---
    if (isset($changed['student_name']) && $changed['student_name'] === '') $err['student_name'] = 'Student name cannot be blank.';
    foreach (student_validate($s) as $f => $m) if (isset($changed[$f])) $err[$f] = $m;
    foreach (student_duplicates($s, $uid) as $f => $m) if (isset($changed[$f])) $err[$f] = $m;
    foreach (['banglarshiksha_id', 'pen_id', 'apaar_id', 'student_aadhaar'] as $f) {
        if (!isset($changed[$f]) || $changed[$f] === '') continue;
        $key = $f . '|' . ($f === 'banglarshiksha_id' ? student_normalize_bsid($changed[$f]) : $changed[$f]);
        if (isset($batch_ids[$key])) $err[$f] = 'The same ID is pasted for another student in this save.';
        $batch_ids[$key] = $uid;
    }
    if (isset($changed['disability_percentage']) && ($m = student_v_disability_pct($changed['disability_percentage'])) !== null) $err['disability_percentage'] = $m;
    if (isset($changed['disability_type']) && $changed['disability_type'] !== '' && ($s['disability'] ?? '') !== 'Yes') $err['disability_type'] = 'Set Disability to Yes first.';
    if (isset($changed['admission_date']) && $changed['admission_date'] !== '' && empty($err['admission_date']) && $changed['admission_date'] > date('Y-m-d')) $err['admission_date'] = 'Admission date cannot be in the future.';
    if (isset($changed['admission_year']) && $changed['admission_year'] !== '' && (!preg_match('/^\d{4}$/', $changed['admission_year']) || (int)$changed['admission_year'] < 1990 || (int)$changed['admission_year'] > (int)date('Y') + 1)) $err['admission_year'] = 'Must be a 4-digit year.';
    // --- guardian rules ---
    foreach (['father_aadhaar', 'mother_aadhaar'] as $f) if (isset($changed[$f]) && ($m = student_v_aadhaar($changed[$f])) !== null) $err[$f] = $m;
    foreach (['father_mobile', 'guardian_contact'] as $f) if (isset($changed[$f]) && ($m = student_v_mobile($changed[$f])) !== null) $err[$f] = $m;
    foreach (['father_name' => 'Father name', 'mother_name' => 'Mother name', 'guardian_name' => 'Guardian name'] as $f => $l) if (isset($changed[$f]) && ($m = student_v_name($changed[$f], $l)) !== null) $err[$f] = $m;
    if (isset($changed['guardian_email']) && ($m = student_v_email($changed['guardian_email'])) !== null) $err['guardian_email'] = $m;
    if (isset($changed['annual_income']) && $changed['annual_income'] !== '' && (!is_numeric($changed['annual_income']) || (float)$changed['annual_income'] < 0)) $err['annual_income'] = 'Must be a number ≥ 0.';
    // --- academic rules ---
    $acad = array_intersect_key($changed, array_flip(['class_id', 'section_id', 'roll_no', 'previous_school']));
    if ($acad) {
        if (!$hist) { foreach ($acad as $f => $v) $err[$f] = 'No enrolment in this session — nothing to update.'; }
        else {
            $class_id = (int)($h['class_id'] ?? 0); $section_id = (int)($h['section_id'] ?? 0); $roll = (string)($h['roll_no'] ?? '');
            if (isset($changed['roll_no']) && !preg_match('/^\d{1,4}$/', $roll)) $err['roll_no'] = 'Roll must be 1–4 digits.';
            if (isset($changed['class_id']) && !db_get_row('SELECT id FROM classes WHERE id = ?', 'i', $class_id)) $err['class_id'] = 'Unknown class.';
            if ((isset($changed['class_id']) || isset($changed['section_id'])) && empty($err['class_id'])) {
                if ($section_id <= 0) $err['section_id'] = 'Choose a section of the new class.';
                elseif (!db_get_row('SELECT id FROM sections WHERE id = ? AND class_id = ? AND session_id = ?', 'iii', $section_id, $class_id, $session_id)) $err['section_id'] = 'That section is not in this class for this session.';
            }
            if ((isset($changed['roll_no']) || isset($changed['class_id']) || isset($changed['section_id'])) && !$err) {
                $slot = "$class_id|$section_id|$roll";
                if (isset($batch_slots[$slot])) $err['roll_no'] = "Roll $roll is also given to another student in this save.";
                $batch_slots[$slot] = $uid;
                // clash with someone NOT in this batch (batch members are re-slotted together in phase 2)
                $clash = db_get_all("SELECT h.student_id, s.student_name FROM student_academic_history h JOIN students s ON s.id = h.student_id WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.roll_no = ? AND h.student_id <> ?", 'iiiss', $session_id, $class_id, $section_id, $roll, $uid);
                foreach ($clash as $c) if (!isset($by[$c['student_id']])) $err['roll_no'] = "Roll $roll already belongs to {$c['student_name']} ({$c['student_id']}).";
            }
        }
    }

    if ($err) {
        foreach ($changed as $f => $v) $cell($uid, $f, false, $err[$f] ?? 'Not saved — fix the other error(s) in this row first.', null, !isset($err[$f]));
        continue;
    }
    $plan[$uid] = ['s' => $s, 'g' => $g, 'h' => $h, 'student' => $student, 'guardian' => $guardian, 'hist' => $hist, 'changed' => $changed];
}

// ---------- Phase 2: write ----------
$saved = 0; $failed = 0; $acad_rows = [];   // uid => [hist_id, class_id, section_id, roll_no, previous_school]
foreach ($plan as $uid => $p) {
    $changed = $p['changed']; $s = $p['s']; $g = $p['g'];
    $s_cols = []; $g_cols = [];
    foreach ($changed as $f => $v) {
        $d = $FIELDS[$f];
        if ($d['table'] === 'students') $s_cols[$d['col']] = $v; elseif ($d['table'] === 'guardians') $g_cols[$d['col']] = $v;
    }
    if (isset($changed['disability'])) { $s_cols['disability_type'] = $s['disability_type']; $s_cols['disability_percentage'] = $s['disability_percentage']; }
    if (isset($changed['admission_year']) && !isset($s_cols['admission_year'])) $s_cols['admission_year'] = $changed['admission_year'];
    // normalise the students columns the way the forms do
    $norm = student_blank_ids_to_null(array_intersect_key($s_cols, array_flip(['banglarshiksha_id', 'pen_id', 'apaar_id', 'student_aadhaar', 'email'])));
    foreach ($norm as $k => $v) $s_cols[$k] = $v;
    if (array_key_exists('disability_percentage', $s_cols) && $s_cols['disability_percentage'] === '') $s_cols['disability_percentage'] = null;
    if (array_key_exists('admission_year', $s_cols)) $s_cols['admission_year'] = $s_cols['admission_year'] === '' ? null : (int)$s_cols['admission_year'];
    if (array_key_exists('annual_income', $g_cols) && $g_cols['annual_income'] === '') $g_cols['annual_income'] = null;
    if (array_key_exists('father_aadhaar', $g_cols)) $g_cols['father_aadhaar_not_available'] = $g_cols['father_aadhaar'] === '' ? 1 : 0;
    if (array_key_exists('mother_aadhaar', $g_cols)) $g_cols['mother_aadhaar_not_available'] = $g_cols['mother_aadhaar'] === '' ? 1 : 0;

    db_begin_transaction();
    try {
        if ($g_cols) {
            $gid = (int)($p['student']['guardian_id'] ?? 0);
            if ($gid > 0 && $p['guardian']) {
                db_update('guardians', $g_cols, ['guardian_id' => $gid], 'i');              // the family's own row — never re-linked
            } else {
                $gid = find_matching_guardian_id_by_score($conn, $g, 3);
                if ($gid === null) {
                    $ins = array_merge(['father_name' => '', 'father_aadhaar' => '', 'mother_name' => '', 'mother_aadhaar' => ''], $g_cols);
                    $gid = (int)db_insert('guardians', $ins);
                }
                db_execute('UPDATE students SET guardian_id = ? WHERE id = ?', 'is', $gid, $uid);
            }
        }
        if ($s_cols) db_update('students', $s_cols, ['id' => $uid], 's');
        if (isset($changed['previous_school']) && $p['hist']) db_execute('UPDATE student_academic_history SET previous_school = ? WHERE id = ?', 'si', $changed['previous_school'], $p['hist']['id']);
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        $failed++;
        $msg = (int)$e->getCode() === 1062 ? 'Another student already holds one of these IDs.' : 'Could not save (' . $e->getMessage() . ')';
        foreach ($changed as $f => $v) $cell($uid, $f, false, $msg);
        $rows[$uid] = $msg;
        continue;
    }
    // report the stored (normalised) values
    foreach ($changed as $f => $v) {
        if (in_array($f, ['class_id', 'section_id', 'roll_no'], true)) continue;      // reported after the academic pass
        $d = $FIELDS[$f];
        $stored = $d['table'] === 'students' ? ($s_cols[$d['col']] ?? $v) : ($d['table'] === 'guardians' ? ($g_cols[$d['col']] ?? $v) : $v);
        $cell($uid, $f, true, '', $stored === null ? '' : $stored);
    }
    if (isset($changed['class_id']) || isset($changed['section_id']) || isset($changed['roll_no'])) {
        $acad_rows[$uid] = [(int)$p['hist']['id'], (int)$p['h']['class_id'], (int)$p['h']['section_id'], (string)$p['h']['roll_no']];
    }
    // audit: only the changed keys
    $diff = [];
    foreach ($changed as $f => $v) $diff[$f] = ['from' => $p['student'][$FIELDS[$f]['col']] ?? $p['guardian'][$FIELDS[$f]['col']] ?? $p['hist'][$FIELDS[$f]['col']] ?? null, 'to' => $v];
    log_student_edit($admin_id, $uid, null, json_encode($diff, JSON_UNESCAPED_UNICODE));
    $saved++;
}

// ---------- academic pass: all class/section/roll changes together ----------
if ($acad_rows) {
    db_begin_transaction();
    try {
        $ids = implode(',', array_map(fn($r) => (int)$r[0], $acad_rows));
        db_execute("UPDATE student_academic_history SET roll_no = NULL WHERE id IN ($ids)");          // free every slot first so swaps work
        foreach ($acad_rows as $uid => [$hid, $cid, $sid, $roll]) db_execute('UPDATE student_academic_history SET class_id = ?, section_id = ?, roll_no = ? WHERE id = ?', 'iisi', $cid, $sid, $roll, $hid);
        db_commit();
        foreach ($acad_rows as $uid => [$hid, $cid, $sid, $roll]) foreach (['class_id' => $cid, 'section_id' => $sid, 'roll_no' => $roll] as $f => $v) if (isset($plan[$uid]['changed'][$f])) $cell($uid, $f, true, '', $v);
    } catch (Throwable $e) {
        db_rollback();
        $msg = (int)$e->getCode() === 1062 ? 'Roll clash — none of the class / section / roll changes were saved.' : 'Could not save class / section / roll (' . $e->getMessage() . ')';
        foreach ($acad_rows as $uid => $r) { foreach (['class_id', 'section_id', 'roll_no'] as $f) if (isset($plan[$uid]['changed'][$f])) $cell($uid, $f, false, $msg); $rows[$uid] = $msg; }
    }
}

out(['ok' => true, 'saved_students' => $saved, 'failed_students' => $failed + count(array_diff_key($by, $plan)), 'cells' => $cells, 'rows' => $rows]);

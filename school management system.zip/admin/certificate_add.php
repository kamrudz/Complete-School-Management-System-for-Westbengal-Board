<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== Validate Student ID =====
if(student_uid_clean($_GET['id'] ?? '') === '') {
    $_SESSION['error'] = "Invalid Student ID!";
    header("Location: students.php");
    exit();
}
$id = student_uid_clean($_GET['id']);

// ===== Get student info =====
$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$student) {
    $_SESSION['error'] = "Student not found!";
    header("Location: students.php");
    exit();
}

// ===== Guardian info =====
$guardian = null;
if(!empty($student['guardian_id'])) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM guardians WHERE guardian_id=?");
    mysqli_stmt_bind_param($stmt, "i", $student['guardian_id']);
    mysqli_stmt_execute($stmt);
    $guardian = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

// ===== Current academic info =====
$stmt = mysqli_prepare($conn, "SELECT h.*, c.class_name, sec.section_name, s.session_name
    FROM student_academic_history h
    LEFT JOIN classes c ON h.class_id = c.id
    LEFT JOIN sections sec ON h.section_id = sec.id
    LEFT JOIN academic_sessions s ON h.session_id = s.id
    WHERE h.student_id=? AND h.academic_status='Current'
    ORDER BY h.id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$academic = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$cert_type = isset($_GET['type']) && $_GET['type'] === 'BONAFIDE' ? 'BONAFIDE' : 'CHARACTER';
// A Bonafide certificate states the student IS studying here — only an Active student can get one.
// A Character certificate is also given on leaving, so Active / TC / Passed qualify; Deleted and Deactivated never.
$status_ok = ['BONAFIDE' => ['Active'], 'CHARACTER' => ['Active', 'TC', 'Passed']];
if (!in_array($student['student_status'], $status_ok[$cert_type], true)) {
    $_SESSION['error'] = "{$student['student_name']} is {$student['student_status']} — a " . ucfirst(strtolower($cert_type)) . ' certificate can only be issued to a student who is ' . implode(' / ', $status_ok[$cert_type]) . '.';
    header('Location: ' . student_page_url('view_student.php', $id));
    exit();
}

// ===== Process Save =====
if(isset($_POST['save_certificate'])) {
    verify_csrf_or_die();

    $certificate_no = trim($_POST['certificate_no'] ?? '');
    $issue_date     = $_POST['issue_date'] ?? '';
    $purpose        = trim($_POST['purpose'] ?? '');
    $type           = ($_POST['certificate_type'] ?? 'CHARACTER') === 'BONAFIDE' ? 'BONAFIDE' : 'CHARACTER';
    if (!in_array($student['student_status'], $status_ok[$type], true)) {
        $_SESSION['error'] = 'This student is not eligible for a ' . ucfirst(strtolower($type)) . ' certificate (status ' . $student['student_status'] . ').';
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }

    if(empty($certificate_no)) {
        $_SESSION['error'] = "Certificate Number is required!";
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }
    if(empty($issue_date)) {
        $_SESSION['error'] = "Issue Date is required!";
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }
    $date_obj = DateTime::createFromFormat('Y-m-d', $issue_date);
    if (!$date_obj || $date_obj->format('Y-m-d') !== $issue_date) {
        $_SESSION['error'] = "Invalid issue date!";
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }

    // Duplicate check (unique per type)
    $stmt = mysqli_prepare($conn, "SELECT id FROM certificates WHERE certificate_type=? AND certificate_no=?");
    mysqli_stmt_bind_param($stmt, "ss", $type, $certificate_no);
    mysqli_stmt_execute($stmt);
    if(mysqli_num_rows(mysqli_stmt_get_result($stmt)) > 0) {
        $_SESSION['error'] = "Certificate Number '$certificate_no' already exists for this certificate type!";
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }

    // Generate a random, unguessable verification token (256-bit)
    $token = bin2hex(random_bytes(32));

    $stmt = mysqli_prepare($conn, "INSERT INTO certificates
        (student_id, certificate_type, certificate_no, purpose, issue_date, verification_token, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?)");
    $created_by = $_SESSION['admin_id'] ?? null;
    mysqli_stmt_bind_param($stmt, "ssssssi", $id, $type, $certificate_no, $purpose, $issue_date, $token, $created_by);

    if(mysqli_stmt_execute($stmt)) {
        $new_id = mysqli_insert_id($conn);
        $_SESSION['success'] = "Certificate generated successfully! No: $certificate_no";
        header("Location: certificate_print.php?id=$new_id");
        exit();
    } else {
        $_SESSION['error'] = "Failed to generate certificate. Please try again.";
        header("Location: certificate_add.php?id=" . rawurlencode($id) . "&type=$type");
        exit();
    }
}

// ===== Auto-suggest next certificate number (per type) =====
function next_cert_no($conn, $type) {
    $prefix_default = ($type === 'BONAFIDE') ? 'BC-' . date('Y') . '-' : 'CC-' . date('Y') . '-';
    $stmt = mysqli_prepare($conn, "SELECT certificate_no FROM certificates WHERE certificate_type=? ORDER BY id DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, "s", $type);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if($row) {
        $last_no = $row['certificate_no'];
        if(preg_match('/(\d+)$/', $last_no, $m)) {
            $num = (int)$m[1];
            $prefix = substr($last_no, 0, -strlen($m[1]));
            return $prefix . str_pad($num + 1, strlen($m[1]), '0', STR_PAD_LEFT);
        }
    }
    return $prefix_default . '001';
}
$next_char_no = next_cert_no($conn, 'CHARACTER');
$next_bona_no = next_cert_no($conn, 'BONAFIDE');

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate Certificate</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.student-info-card {
    background: linear-gradient(135deg, #f8f9fa 0%, #e8f4ff 100%);
    padding: 20px; border-radius: 12px; border: 1px solid #e4edf6;
    margin-bottom: 20px; display: flex; gap: 20px; align-items: center;
}
.student-photo { width: 80px; height: 80px; border-radius: 10px; object-fit: cover; border: 3px solid #003366; }
.no-photo { width: 80px; height: 80px; background: #ddd; display: flex; align-items: center; justify-content: center; border-radius: 10px; font-size: 12px; color: #777; border: 3px solid #003366; }
.student-details { flex: 1; }
.student-details h3 { margin: 0 0 8px 0; color: #003366; font-size: 20px; }
.student-details p { margin: 3px 0; font-size: 13px; color: #1a3b55; }
.student-details strong { min-width: 120px; display: inline-block; color: #003366; }
.type-tabs { display: flex; gap: 10px; margin-bottom: 20px; }
.type-tab { flex: 1; text-align: center; padding: 14px; border-radius: 10px; border: 2px solid #e4edf6; text-decoration: none; font-weight: 600; color: #1a3b55; }
.type-tab.active { background: #003366; color: #fff; border-color: #003366; }
.form-card { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e4edf6; }
.form-group { margin-bottom: 18px; }
.form-group label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-group input, .form-group textarea { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.form-group textarea { min-height: 90px; resize: vertical; }
.required { color: #dc3545; }
.btn-group { display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap; }
.auto-suggest { font-size: 12px; color: #6c7a8a; margin-top: 4px; }
.auto-suggest strong { color: #003366; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title">
            <i class="fas fa-certificate"></i> Generate Certificate
            <span><?php echo htmlspecialchars($student['student_name']); ?></span>
        </div>
        <a href="certificate_list.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Certificates</a>
    </div>

    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'] ?? '', ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="student-info-card">
        <?php if(!empty($student['photo'])): ?>
            <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="student-photo">
        <?php else: ?>
            <div class="no-photo">No Photo</div>
        <?php endif; ?>
        <div class="student-details">
            <h3><?php echo htmlspecialchars($student['student_name']); ?></h3>
            <p><strong>Admission No:</strong> <?php echo htmlspecialchars($student['admission_no'] ?? 'N/A'); ?></p>
            <?php if($guardian): ?>
                <p><strong>Father:</strong> <?php echo htmlspecialchars($guardian['father_name']); ?></p>
            <?php endif; ?>
            <?php if($academic): ?>
                <p><strong>Class:</strong> <?php echo htmlspecialchars($academic['class_name']); ?> - <?php echo htmlspecialchars($academic['section_name'] ?? '-'); ?></p>
                <p><strong>Session:</strong> <?php echo htmlspecialchars($academic['session_name']); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="type-tabs">
        <a href="certificate_add.php?id=<?php echo $id; ?>&type=CHARACTER" class="type-tab <?php echo $cert_type==='CHARACTER'?'active':''; ?>">
            <i class="fas fa-user-check"></i> Character Certificate
        </a>
        <a href="certificate_add.php?id=<?php echo $id; ?>&type=BONAFIDE" class="type-tab <?php echo $cert_type==='BONAFIDE'?'active':''; ?>">
            <i class="fas fa-file-alt"></i> Bonafide Certificate
        </a>
    </div>

    <div class="form-card">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="certificate_type" value="<?php echo $cert_type; ?>">
            <div class="form-group">
                <label><i class="fas fa-tag"></i> Certificate Number <span class="required">*</span></label>
                <input type="text" name="certificate_no" value="<?php echo htmlspecialchars($cert_type==='BONAFIDE'?$next_bona_no:$next_char_no); ?>" required>
                <div class="auto-suggest"><i class="fas fa-lightbulb"></i> Suggested: <strong><?php echo htmlspecialchars($cert_type==='BONAFIDE'?$next_bona_no:$next_char_no); ?></strong> (আপনি চাইলে বদলাতে পারেন)</div>
            </div>
            <div class="form-group">
                <label><i class="fas fa-calendar-alt"></i> Issue Date <span class="required">*</span></label>
                <input type="date" name="issue_date" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label><i class="fas fa-comment"></i> Purpose (optional)</label>
                <textarea name="purpose" placeholder="যেমন: For admission in Class XI"></textarea>
            </div>
            <div class="btn-group">
                <button type="submit" name="save_certificate" class="btn btn-success">
                    <i class="fas fa-certificate"></i> Generate & Print
                </button>
                <a href="certificate_list.php" class="btn btn-primary"><i class="fas fa-times"></i> Cancel</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>

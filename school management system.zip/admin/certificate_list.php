<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

$search = trim($_GET['search'] ?? '');
$type_filter = $_GET['type'] ?? 'all';

$sql = "SELECT c.*, s.student_name, s.admission_no
        FROM certificates c
        LEFT JOIN students s ON s.id=c.student_id
        WHERE 1=1";
$params = [];
$types = '';
if ($search !== '') {
    $like = '%' . $search . '%';
    $sql .= " AND (s.student_name LIKE ? OR c.certificate_no LIKE ? OR s.admission_no LIKE ?)";
    array_push($params, $like, $like, $like);
    $types .= 'sss';
}
if ($type_filter === 'CHARACTER' || $type_filter === 'BONAFIDE') {
    $sql .= " AND c.certificate_type=?";
    $params[] = $type_filter;
    $types .= 's';
}
$sql .= " ORDER BY c.id DESC";
$stmt = mysqli_prepare($conn, $sql);
if ($params) mysqli_stmt_bind_param($stmt, $types, ...$params);
mysqli_stmt_execute($stmt);
$q = mysqli_stmt_get_result($stmt);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Certificates</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.filter-bar { display: flex; gap: 10px; margin-bottom: 18px; flex-wrap: wrap; }
.filter-bar input[type=text] { flex: 1; min-width: 200px; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; }
.filter-bar select { padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; }
table.cert-table { width: 100%; border-collapse: collapse; }
table.cert-table th, table.cert-table td { padding: 10px 12px; border-bottom: 1px solid #e4edf6; font-size: 13px; text-align: left; }
table.cert-table th { background: #003366; color: #fff; }
.badge-type { padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.badge-character { background: #e7f1ff; color: #084298; }
.badge-bonafide { background: #e6f9ee; color: #0a6e3a; }
.badge-revoked { background: #fbe7e9; color: #a4161a; padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; }
.action-icons a { margin-right: 8px; font-size: 15px; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-certificate"></i> Certificates <span>Character & Bonafide Certificate History</span></div>
        <a href="students.php" class="btn btn-primary"><i class="fas fa-plus"></i> Select Student to Generate</a>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-bar">
        <input type="text" name="search" placeholder="Search by name / certificate no / admission no..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="type" onchange="this.form.submit()">
            <option value="all" <?php echo $type_filter==='all'?'selected':''; ?>>All Types</option>
            <option value="CHARACTER" <?php echo $type_filter==='CHARACTER'?'selected':''; ?>>Character</option>
            <option value="BONAFIDE" <?php echo $type_filter==='BONAFIDE'?'selected':''; ?>>Bonafide</option>
        </select>
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
    </form>

    <div style="overflow-x:auto;">
    <table class="cert-table">
        <tr>
            <th>Certificate No</th>
            <th>Type</th>
            <th>Student</th>
            <th>Admission No</th>
            <th>Issue Date</th>
            <th>Purpose</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($q)): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['certificate_no']); ?></td>
            <td><span class="badge-type <?php echo $row['certificate_type']==='BONAFIDE'?'badge-bonafide':'badge-character'; ?>"><?php echo $row['certificate_type']; ?></span></td>
            <td><?php echo htmlspecialchars($row['student_name'] ?? 'N/A'); ?></td>
            <td><?php echo htmlspecialchars($row['admission_no'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($row['issue_date']); ?></td>
            <td><?php echo htmlspecialchars($row['purpose'] ?: '-'); ?></td>
            <td>
                <?php if($row['is_revoked']): ?>
                    <span class="badge-revoked"><i class="fas fa-ban"></i> Revoked</span>
                <?php else: ?>
                    <span class="badge-type badge-bonafide"><i class="fas fa-check"></i> Valid</span>
                <?php endif; ?>
            </td>
            <td class="action-icons">
                <a href="certificate_print.php?id=<?php echo $row['id']; ?>" title="View / Print"><i class="fas fa-print"></i></a>
                <?php if(!$row['is_revoked']): ?>
                <form method="POST" action="certificate_revoke.php" style="display:inline;" onsubmit="return confirm('এই certificate টা revoke করতে চান? Revoke করলে QR verify পেজে এটা invalid দেখাবে।');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="submit" title="Revoke" style="background:none;border:none;cursor:pointer;padding:0;"><i class="fas fa-ban" style="color:#dc3545;"></i></button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    </div>
</div>
</body>
</html>

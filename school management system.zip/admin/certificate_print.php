<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/card_document_helper.php");
require_once("../includes/base_url.php");

if(!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['error'] = "Invalid certificate!";
    header("Location: certificate_list.php");
    exit();
}
$id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT c.*, s.student_name, s.admission_no, s.admission_year, s.gender, s.photo, s.banglarshiksha_id, s.pen_id,
    s.dob, s.village, s.post_office, s.police_station, s.district, s.state, s.pin_code
    FROM certificates c LEFT JOIN students s ON s.id = c.student_id
    WHERE c.id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$cert = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$cert) {
    $_SESSION['error'] = "Certificate not found!";
    header("Location: certificate_list.php");
    exit();
}

$student_id = $cert['student_id'];

$guardian = null;
$stmt = mysqli_prepare($conn, "SELECT g.* FROM guardians g JOIN students s ON s.guardian_id=g.guardian_id WHERE s.id=?");
mysqli_stmt_bind_param($stmt, "s", $student_id);
mysqli_stmt_execute($stmt);
$guardian = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$stmt = mysqli_prepare($conn, "SELECT h.*, c.class_name, sec.section_name, ss.session_name
    FROM student_academic_history h
    LEFT JOIN classes c ON h.class_id = c.id
    LEFT JOIN sections sec ON h.section_id = sec.id
    LEFT JOIN academic_sessions ss ON h.session_id = ss.id
    WHERE h.student_id=?
    ORDER BY (h.academic_status='Current') DESC, h.id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $student_id);
mysqli_stmt_execute($stmt);
$academic = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

$school = document_get_school_settings($conn);

$pronoun_subj = ($cert['gender'] === 'Female') ? 'she' : 'he';
$pronoun_poss = ($cert['gender'] === 'Female') ? 'her' : 'his';
$son_daughter = ($cert['gender'] === 'Female') ? 'daughter' : 'son';
$mr_ms = ($cert['gender'] === 'Female') ? 'Ms.' : 'Mr.';

$is_char = $cert['certificate_type'] === 'CHARACTER';
$title = $is_char ? 'CHARACTER CERTIFICATE' : 'BONAFIDE CERTIFICATE';

// ===== Date of Birth (formatted) =====
$dob_formatted = !empty($cert['dob']) ? date('d-m-Y', strtotime($cert['dob'])) : '-';

// ===== Admission No with Year =====
$admission_display = htmlspecialchars($cert['admission_no'] ?? '-');
if(!empty($cert['admission_year'])) {
    $admission_display .= ' / ' . htmlspecialchars($cert['admission_year']);
}

// ===== Full Address (built from address parts) =====
$address_parts = array_filter([
    $cert['village'] ?? '',
    $cert['post_office'] ?? '',
    $cert['police_station'] ?? '',
    $cert['district'] ?? '',
    $cert['state'] ?? '',
    $cert['pin_code'] ?? ''
], function($v) { return trim((string)$v) !== ''; });
$full_address = !empty($address_parts) ? implode(', ', $address_parts) : '-';

// ===== Parent name string (for Character certificate) =====
$parent_str = htmlspecialchars($guardian['father_name'] ?? '-');
if(!empty($guardian['mother_name'])) {
    $parent_str .= ' and ' . htmlspecialchars($guardian['mother_name']);
}
$logo_url = !empty($school['logo']) ? "../uploads/" . htmlspecialchars($school['logo']) : '';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $title; ?> - <?php echo htmlspecialchars($cert['student_name']); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; background: #eef2f6; }
body { font-family: 'Georgia', 'Times New Roman', serif; }

.toolbar { max-width: 210mm; margin: 15px auto; display: flex; gap: 10px; justify-content: flex-end; }
.toolbar button, .toolbar a { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; text-decoration: none; font-family: Arial, sans-serif; font-size: 14px; cursor: pointer; }
.toolbar button:hover, .toolbar a:hover { background: #004a8f; }

/* ===================== A4 CERTIFICATE SHEET ===================== */
.certificate-sheet {
    width: 210mm;
    min-height: 297mm;
    margin: 0 auto 30px auto;
    background: #fff;
    padding: 18mm 20mm;
    border: 3px double #003366;
    position: relative;
    overflow: hidden;
    box-shadow: 0 2px 12px rgba(0,0,0,0.12);
}

/* Watermark logo, centred, large, low opacity, behind all content */
.watermark {
    position: absolute;
    top: 50%; left: 50%;
    width: 120mm; height: 120mm;
    transform: translate(-50%, -50%);
    background-repeat: no-repeat;
    background-position: center;
    background-size: contain;
    opacity: 0.08;
    z-index: 0;
    pointer-events: none;
}

.cert-inner { position: relative; z-index: 1; }

.cert-header { text-align: center; border-bottom: 2px solid #003366; padding-bottom: 15px; margin-bottom: 25px; display: flex; align-items: center; gap: 15px; }
.cert-header img.logo { height: 70px; width: 70px; object-fit: contain; flex-shrink: 0; }
.cert-header .school-text { flex: 1; text-align: center; min-width: 0; }
.cert-header .school-text h1 {
    margin: 0; color: #003366; font-size: 26px; letter-spacing: 1px;
    white-space: nowrap; overflow: hidden;
}
.cert-header .school-text p { margin: 2px 0; font-size: 12px; color: #333; font-family: Arial, sans-serif; }

.cert-title { text-align: center; font-size: 22px; font-weight: bold; letter-spacing: 3px; color: #003366; margin: 25px 0; text-decoration: underline; }
.cert-meta { display: flex; justify-content: space-between; font-family: Arial, sans-serif; font-size: 13px; margin-bottom: 20px; color: #333; }
.cert-body { font-size: 16px; line-height: 2; text-align: justify; margin-bottom: 40px; }
.cert-body b { color: #000; }
.cert-footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 60px; }
.qr-box { text-align: center; font-family: Arial, sans-serif; }
.qr-box img { width: 100px; height: 100px; border: 1px solid #ccc; padding: 4px; background: #fff; }
.qr-box p { font-size: 10px; color: #555; margin: 5px 0 0 0; max-width: 120px; }
.sign-box { text-align: center; font-family: Arial, sans-serif; }
.sign-box img.sign { height: 50px; display: block; margin: 0 auto 5px auto; }
.sign-line { border-top: 1px solid #333; width: 200px; margin: 0 auto; padding-top: 6px; font-size: 13px; }
.revoked-stamp { position: absolute; top: 45%; left: 50%; transform: translate(-50%,-50%) rotate(-25deg); font-size: 60px; color: rgba(220,53,69,0.35); font-weight: bold; border: 6px solid rgba(220,53,69,0.35); padding: 10px 30px; font-family: Arial, sans-serif; z-index: 2; }

@page { size: A4; margin: 0; }
@media print {
    html, body { background: #fff; }
    .toolbar { display: none; }
    .certificate-sheet { border: 3px double #003366; box-shadow: none; margin: 0; width: 210mm; min-height: 297mm; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<div class="toolbar">
    <a href="certificate_list.php"><i class="fas fa-arrow-left"></i> Back</a>
    <button onclick="window.print()"><i class="fas fa-print"></i> Print</button>
</div>

<div class="certificate-sheet">
    <?php if(!empty($logo_url)): ?>
        <div class="watermark" style="background-image:url('<?php echo $logo_url; ?>');"></div>
    <?php endif; ?>

    <?php if($cert['is_revoked']): ?>
        <div class="revoked-stamp">REVOKED</div>
    <?php endif; ?>

    <div class="cert-inner">

        <div class="cert-header">
            <?php if(!empty($logo_url)): ?>
                <img src="<?php echo $logo_url; ?>" class="logo">
            <?php endif; ?>
            <div class="school-text">
                <h1 class="fit-line"><?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?></h1>
                <p><?php echo htmlspecialchars($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
                <p>
                    <?php if(!empty($school['udise_code'])): ?>UDISE: <?php echo htmlspecialchars($school['udise_code']); ?> &nbsp; <?php endif; ?>
                    <?php if(!empty($school['phone'])): ?>Ph: <?php echo htmlspecialchars($school['phone']); ?> &nbsp; <?php endif; ?>
                    <?php if(!empty($school['email'])): ?><?php echo htmlspecialchars($school['email']); ?><?php endif; ?>
                </p>
            </div>
        </div>

        <div class="cert-title"><?php echo $title; ?></div>

        <div class="cert-meta">
            <span><b>Certificate No:</b> <?php echo htmlspecialchars($cert['certificate_no']); ?></span>
            <span><b>Date:</b> <?php echo date('d-m-Y', strtotime($cert['issue_date'])); ?></span>
        </div>

        <div class="cert-body">
        <?php if($is_char): ?>
            This is to certify that <b><?php echo $mr_ms; ?> <?php echo htmlspecialchars($cert['student_name']); ?></b>,
            <?php echo $son_daughter; ?> of <b><?php echo $parent_str; ?></b>, born on <b><?php echo htmlspecialchars($dob_formatted); ?></b>,
            bearing Admission No. <b><?php echo $admission_display; ?></b>
            (Banglarshiksha ID: <b><?php echo htmlspecialchars($cert['banglarshiksha_id'] ?? '-'); ?></b>, PEN ID: <b><?php echo htmlspecialchars($cert['pen_id'] ?? '-'); ?></b>),
            has been a student of this institution
            <?php if($academic): ?>, studying in Class <b><?php echo htmlspecialchars($academic['class_name']); ?></b>
            <?php if(!empty($academic['section_name'])): ?>(Section <b><?php echo htmlspecialchars($academic['section_name']); ?></b>)<?php endif; ?>
            during the academic session <b><?php echo htmlspecialchars($academic['session_name']); ?></b><?php endif; ?>.
            <br><br>
            During the entire period of <?php echo $pronoun_poss; ?> stay in this institution, <?php echo $pronoun_subj; ?> has borne a
            <b>good moral character</b>, and to the best of our knowledge and belief, <?php echo $pronoun_poss; ?> conduct and behaviour
            have always been found satisfactory and exemplary.
            <?php if(!empty($cert['purpose'])): ?>
                <br><br>This certificate is issued at the request of the student/guardian for the purpose of: <b><?php echo htmlspecialchars($cert['purpose']); ?></b>.
            <?php endif; ?>
            <br><br>We wish <?php echo $pronoun_poss; ?> a bright and successful future in all endeavours of life.
        <?php else: ?>
            This is to certify that <b><?php echo $mr_ms; ?> <?php echo htmlspecialchars($cert['student_name']); ?></b>,
            <?php echo $son_daughter; ?> of <b><?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?></b>, born on
            <b><?php echo htmlspecialchars($dob_formatted); ?></b>, residing at <b><?php echo htmlspecialchars($full_address); ?></b>,
            bearing Admission No. <b><?php echo $admission_display; ?></b>
            (Banglarshiksha ID: <b><?php echo htmlspecialchars($cert['banglarshiksha_id'] ?? '-'); ?></b>, PEN ID: <b><?php echo htmlspecialchars($cert['pen_id'] ?? '-'); ?></b>),
            is a <b>bona fide student</b> of this institution
            <?php if($academic): ?>, presently studying in Class <b><?php echo htmlspecialchars($academic['class_name']); ?></b>
            <?php if(!empty($academic['section_name'])): ?>(Section <b><?php echo htmlspecialchars($academic['section_name']); ?></b>)<?php endif; ?>
            during the academic session <b><?php echo htmlspecialchars($academic['session_name']); ?></b><?php endif; ?>.
            <?php if(!empty($cert['purpose'])): ?>
                <br><br>This certificate is issued for the purpose of: <b><?php echo htmlspecialchars($cert['purpose']); ?></b>.
            <?php else: ?>
                <br><br>This certificate is issued on the request of the student/guardian for whatever purpose it may serve.
            <?php endif; ?>
        <?php endif; ?>
        </div>

        <div class="cert-footer">
            <div class="qr-box">
                <img src="certificate_qr.php?token=<?php echo htmlspecialchars($cert['verification_token']); ?>" alt="QR">
                <p>Scan to verify this certificate online</p>
            </div>
            <div class="sign-box">
                <?php if(!empty($school['hoi_signature'])): ?>
                    <img src="../uploads/<?php echo htmlspecialchars($school['hoi_signature']); ?>" class="sign">
                <?php endif; ?>
                <div class="sign-line">
                    <?php echo htmlspecialchars($school['hoi_name'] ?? 'Head of Institution'); ?><br>
                    Head of Institution
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Keep the school name heading on a single line, no matter how long it is.
function fitOneLine(el, minPx) {
    if (!el) return;
    minPx = minPx || 14;
    el.style.whiteSpace = 'nowrap';
    var fontSize = parseFloat(window.getComputedStyle(el).fontSize);
    var guard = 0;
    while (el.scrollWidth > el.clientWidth && fontSize > minPx && guard < 60) {
        fontSize -= 0.5;
        el.style.fontSize = fontSize + 'px';
        guard++;
    }
}
function fitAll() {
    document.querySelectorAll('.fit-line').forEach(function(el){ fitOneLine(el, 15); });
}
window.addEventListener('load', fitAll);
window.addEventListener('resize', fitAll);
window.onbeforeprint = fitAll;
</script>

</body>
</html>
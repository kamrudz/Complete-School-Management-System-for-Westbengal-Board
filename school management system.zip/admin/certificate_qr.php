<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/base_url.php");
require_once("../includes/phpqrcode/qrlib.php");

$token = $_GET['token'] ?? '';
// Basic sanity check: token must look like our 64-char hex token
if(!preg_match('/^[a-f0-9]{64}$/', $token)) {
    http_response_code(400);
    exit();
}

$stmt = mysqli_prepare($conn, "SELECT id FROM certificates WHERE verification_token=? LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $token);
mysqli_stmt_execute($stmt);
$cert = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$cert) {
    http_response_code(404);
    exit();
}

$base_url = get_site_base_url($conn);
$verify_url = $base_url . "/certificate_verify.php?token=" . $token;

header('Content-Type: image/png');
// QRcode::png outputs directly to browser when $outfile is false
QRcode::png($verify_url, false, QR_ECLEVEL_M, 6, 2);
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== ONLY ALLOW POST REQUESTS =====
if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: certificate_list.php");
    exit();
}

// ===== CSRF PROTECTION =====
verify_csrf_or_die();

if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    $_SESSION['error'] = "Invalid certificate!";
    header("Location: certificate_list.php");
    exit();
}
$id = (int)$_POST['id'];
$reason = trim($_POST['revoked_reason'] ?? '');

$stmt = mysqli_prepare($conn, "UPDATE certificates SET is_revoked=1, revoked_reason=?, revoked_at=NOW() WHERE id=? AND is_revoked=0");
mysqli_stmt_bind_param($stmt, "si", $reason, $id);
mysqli_stmt_execute($stmt);

$_SESSION['success'] = "Certificate revoked successfully.";
header("Location: certificate_list.php");
exit();


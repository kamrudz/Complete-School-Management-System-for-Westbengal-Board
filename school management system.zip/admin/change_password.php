<?php
// ===== CHANGE PASSWORD =====
require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/security.php';

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_pass'])) {
    
    // ✅ CSRF Protection (এখানে থাকবে)
    verify_csrf_or_die();
    
    $admin_id = $_SESSION['admin_id'];
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    
    if(empty($current) || empty($new) || empty($confirm)) {
        $_SESSION['error'] = "All fields are required!";
        header("Location: dashboard.php?page=change_password");
        exit();
    }
    
    if($new !== $confirm) {
        $_SESSION['error'] = "New passwords do not match!";
        header("Location: dashboard.php?page=change_password");
        exit();
    }
    
    if(strlen($new) < 8) {
        $_SESSION['error'] = "Password must be at least 8 characters!";
        header("Location: dashboard.php?page=change_password");
        exit();
    }
    
    $stmt = mysqli_prepare($conn, "SELECT password FROM admins WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $admin_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    
    if(!$row) {
        $_SESSION['error'] = "Admin not found!";
        header("Location: dashboard.php?page=change_password");
        exit();
    }
    
    if(!password_verify($current, $row['password'])) {
        $_SESSION['error'] = "Current password is incorrect!";
        header("Location: dashboard.php?page=change_password");
        exit();
    }
    
    $hashed = password_hash($new, PASSWORD_DEFAULT);
    $stmt = mysqli_prepare($conn, "UPDATE admins SET password = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "si", $hashed, $admin_id);
    
    if(mysqli_stmt_execute($stmt)) {
        $_SESSION['success'] = "Password changed successfully!";
    } else {
        $_SESSION['error'] = "Failed to update password!";
    }
    
    header("Location: dashboard.php?page=change_password");
    exit();
}

header("Location: dashboard.php?page=change_password");
exit();
?>
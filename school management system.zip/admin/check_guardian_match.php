<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once '../includes/sibling_helper.php';

/**
 * While guardian details are typed on the admission form: does this family already have a guardian row,
 * and which students share it? Uses the same matching as saving does (find_matching_guardian_id_by_score).
 */
$input = [];
foreach (['father_name', 'mother_name', 'father_mobile', 'father_voter_id', 'father_aadhaar'] as $k) $input[$k] = (string)($_GET[$k] ?? '');

if (count(array_filter(sibling_profile_fields($input), fn($v) => $v !== '')) < 3) {
    echo json_encode(['matched' => false, 'reason' => 'কমপক্ষে ৫টি identity field-এর মধ্যে ৩টি তথ্য দিতে হবে।']);
    exit();
}
$guardian_id = find_matching_guardian_id_by_score($conn, $input, 3);
if ($guardian_id === null) {
    echo json_encode(['matched' => false]);
    exit();
}
$guardian = db_get_row('SELECT guardian_name, father_name FROM guardians WHERE guardian_id = ?', 'i', $guardian_id);
$siblings = array_map(fn($r) => ['name' => $r['student_name'], 'class' => $r['class_label'] ?: 'No class', 'match_score' => (int)$r['match_score']],
    find_sibling_matches_for_profile($conn, $input, 3));

echo json_encode([
    'matched'        => true,
    'guardian_id'    => $guardian_id,
    'guardian_label' => $guardian['guardian_name'] ?: $guardian['father_name'],
    'sibling_count'  => count($siblings),
    'siblings'       => $siblings,
]);

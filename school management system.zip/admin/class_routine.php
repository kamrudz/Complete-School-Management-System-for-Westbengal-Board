<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/routine_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Class routine — view / print the week of one unit (section or pair), a whole class (every unit)
 * or every class (booklet, one unit per page).  Read-only; entry is routine_entry.php.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$session_id = (int)($_GET['session_id'] ?? ($active['id'] ?? 0));
$session = null; foreach ($sessions as $ss) if ((int)$ss['id'] === $session_id) $session = $ss;
$scope = in_array($_GET['scope'] ?? '', ['unit', 'class', 'all'], true) ? $_GET['scope'] : 'unit';
$class_id = (int)($_GET['class_id'] ?? 0);
$unit = preg_match('/^[sgc]\d{1,9}$/', (string)($_GET['unit'] ?? '')) ? (string)$_GET['unit'] : '';
$units = $session_id && $class_id ? routine_units($session_id, $class_id) : [];
if ($unit && !isset($units[$unit])) $unit = '';
if ($scope === 'unit' && !$unit) $scope = $class_id ? 'class' : 'unit';
$s = routine_settings();

// what to print: list of ['class' => name, 'class_id', 'unit_key', 'label', 'section_ids']
$blocks = [];
$want = $scope === 'all' ? $classes : ($class_id ? array_filter($classes, fn($c) => (int)$c['id'] === $class_id) : []);
foreach ($want as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { if ($scope === 'unit' && $k !== $unit) continue; $blocks[] = ['class' => $c['class_name'], 'class_id' => (int)$c['id'], 'unit_key' => $k, 'label' => $u['label'], 'section_ids' => $u['section_ids']]; }
$teachers = routine_teachers();
$rendered = [];
foreach ($blocks as $b) {
    $first = $b['section_ids'][0]; $grid = routine_grid($session_id, [$first])[$first] ?? [];
    if (!$grid) { $rendered[] = $b + ['html' => '', 'codes' => [], 'n' => 0]; continue; }
    // combined partners: other units of the class with a -1 row in the same slot
    $cu = routine_units($session_id, $b['class_id']); $sec_unit = []; foreach ($cu as $k => $u) foreach ($u['section_ids'] as $sid) $sec_unit[$sid] = $k;
    $partners = [];
    foreach (db_get_all('SELECT DISTINCT day_name, period_id, section_id FROM routine WHERE session_id = ? AND class_id = ? AND group_id < 0', 'ii', $session_id, $b['class_id']) as $r) { $k = $sec_unit[(int)$r['section_id']] ?? null; if ($k && $k !== $b['unit_key']) $partners[$r['day_name']][(int)$r['period_id']][$k] = $cu[$k]['label']; }
    $ptxt = []; foreach ($partners as $d => $per) foreach ($per as $pid => $labels) $ptxt[$d][$pid] = 'with ' . implode(', ', $labels);
    $ctr = db_get_row('SELECT st.staff_name, st.short_code, sub.subject_name FROM sections s JOIN staff st ON st.id = s.class_teacher_id LEFT JOIN subjects sub ON sub.id = s.class_teacher_subject_id WHERE s.id = ?', 'i', $first);
    $b['class_teacher'] = $ctr ? $ctr['staff_name'] . ($ctr['subject_name'] ? ' (' . $ctr['subject_name'] . ', first period)' : '') : '';
    $codes = []; $n = 0;
    foreach ($grid as $d => $per) foreach ($per as $rows) { $n++; foreach ($rows as $r) if ($r['teacher_id']) $codes[(int)$r['teacher_id']] = ($r['short_code'] ?: '?') . ' = ' . $r['staff_name']; }
    ksort($codes);
    $rendered[] = $b + ['html' => routine_render_week($grid, $ptxt), 'codes' => $codes, 'n' => $n];
}
$title = $scope === 'all' ? 'All class routines' : ($scope === 'class' && $class_id ? 'Class ' . ($blocks[0]['class'] ?? '') . ' — all sections' : ($blocks ? 'Class ' . $blocks[0]['class'] . ' — ' . $blocks[0]['label'] : 'Class routine'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Class Routine</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); echo routine_view_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #0b3d5c; }
    .blk { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 14px 16px; margin-bottom: 16px; }
    .blk .hd { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; margin-bottom: 8px; } .blk .hd h2 { margin: 0; font-size: 16px; color: #0b3d5c; } .blk .hd small { color: #6b7d90; } .blk .hd a { margin-left: auto; font-size: 12.5px; }
    .blk .empty { color: #8a9aab; font-size: 13px; padding: 14px 0; }
    .print-head { display: none; }
    @media print {
        @page { size: A4 landscape; margin: 9mm; }
        html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; }
        .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; }
        .rt-banner, .lc-filter, .blk .hd a, .lc-empty { display: none !important; }
        .blk { border: 0; padding: 0; margin: 0; page-break-after: always; break-after: page; } .blk:last-child { page-break-after: auto; }
        .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #0b3d5c; padding-bottom: 5px; margin-bottom: 8px; } .print-head img { width: 42px; height: 42px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #0b3d5c; } .print-head small { color: #444; font-size: 10.5px; }
        .blk .hd h2 { font-size: 15px; }
    }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-table"></i></div>
        <div><h1>Class Routine</h1><p>Session <?php echo h($session['session_name'] ?? ''); ?> · mode <?php echo h(ROUTINE_MODES[$s['routine_mode']]); ?> · teacher shown by short code; a slot in blue is taught together with another section.</p></div>
        <div class="links"><a href="routine_entry.php<?php echo $unit ? '?session_id=' . $session_id . '&class_id=' . $class_id . '&unit=' . h($unit) : ''; ?>"><i class="fas fa-edit"></i> Entry</a><a href="teacher_routine.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-chalkboard-teacher"></i> Teacher routines</a><?php if ($rendered): ?><a href="#" class="solid" onclick="window.print();return false;"><i class="fas fa-print"></i> Print<?php echo count($rendered) > 1 ? ' (' . count($rendered) . ' pages)' : ''; ?></a><?php endif; ?></div>
    </div>
    <form method="get" class="lc-filter">
        <div><label>Session</label><select name="session_id" onchange="this.form.unit.value='';this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.unit.value='';this.form.scope.value='class';this.form.submit()"><option value="">— choose —</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="unit" onchange="this.form.scope.value=this.value?'unit':'class';this.form.submit()" <?php echo $units ? '' : 'disabled'; ?>><option value="">All sections of the class</option><?php foreach ($units as $k => $u): ?><option value="<?php echo h($k); ?>" <?php echo $k === $unit ? 'selected' : ''; ?>><?php echo h($u['label']); ?></option><?php endforeach; ?></select></div>
        <input type="hidden" name="scope" value="<?php echo h($scope); ?>">
        <button type="submit" class="btn btn-primary"><i class="fas fa-eye"></i> Show</button>
        <a href="?session_id=<?php echo $session_id; ?>&scope=all" class="btn btn-secondary"><i class="fas fa-book"></i> All classes</a>
    </form>

    <?php if (!$rendered): ?><div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class (and a section) to see its routine, or "All classes" for the booklet.</div><?php endif; ?>
    <?php foreach ($rendered as $b): ?>
    <div class="blk">
        <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?></h2><small>Class routine · session <?php echo h($session['session_name'] ?? ''); ?> · printed <?php echo date('d-m-Y'); ?></small></div></div>
        <div class="hd"><h2><i class="fas fa-chalkboard"></i> Class <?php echo h($b['class']); ?> — <?php echo h($b['label']); ?></h2><small><?php echo $b['n'] ? $b['n'] . ' periods in the week' : 'no routine yet'; ?><?php if (!empty($b['class_teacher'])): ?> · Class teacher: <b><?php echo h($b['class_teacher']); ?></b><?php endif; ?></small><a href="routine_entry.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $b['class_id']; ?>&unit=<?php echo h($b['unit_key']); ?>"><i class="fas fa-edit"></i> Edit</a></div>
        <?php if ($b['html']): echo $b['html']; ?><div class="rv-legend"><?php foreach ($b['codes'] as $c) echo '<span><b>' . h(strstr($c, ' =', true)) . '</b>' . h(strstr($c, ' =')) . '</span>'; ?></div>
        <?php else: ?><div class="empty">No routine entered for this <?php echo count($b['section_ids']) > 1 ? 'pair' : 'section'; ?> yet.</div><?php endif; ?>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>

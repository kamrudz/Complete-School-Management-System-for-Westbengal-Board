<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

/**
 * What each class studies in a session: one class_subjects row per subject taught. has_exam puts it on
 * exams, marks and results (the exam module reads the exam_class_subjects view); is_third_language marks
 * the two languages a student chooses between. Higher Secondary has no third language — there Arabic and
 * Sanskrit are ordinary subjects picked through HS registration.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name');
$session_ids = array_map('intval', array_column($sessions, 'id'));
$active_id = 0; foreach ($sessions as $s) if ($s['status'] === 'Active') $active_id = (int)$s['id'];
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? $active_id);
if (!in_array($session_id, $session_ids, true)) $session_id = $active_id;
$classes = class_rows();
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0);
if (!isset($classes[$class_id])) $class_id = 0;
$here = 'Location: class_subjects.php?' . http_build_query(['session_id' => $session_id, 'class_id' => $class_id ?: null]);

if (isset($_POST['save_class_subjects']) && $class_id) {
    verify_csrf_or_die();
    // only active subjects; "exam" and "third language" only where "taught" is ticked
    $valid = array_map('intval', array_column(db_get_all('SELECT id FROM subjects WHERE is_active = 1'), 'id'));
    $teach = array_values(array_intersect(array_unique(array_map('intval', (array)($_POST['teach'] ?? []))), $valid));
    $exam = array_intersect(array_map('intval', (array)($_POST['exam'] ?? [])), $teach);
    $third = $classes[$class_id]['stage'] === 'higher_secondary' ? [] : array_intersect(array_map('intval', (array)($_POST['third'] ?? [])), $teach);
    $existing = [];
    foreach (db_get_all('SELECT subject_id, has_exam, is_third_language FROM class_subjects WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id) as $r) $existing[(int)$r['subject_id']] = [(int)$r['has_exam'], (int)$r['is_third_language']];

    $added = $changed = $removed = 0;
    db_begin_transaction();
    try {
        foreach ($teach as $sid) {
            $flags = [in_array($sid, $exam, true) ? 1 : 0, in_array($sid, $third, true) ? 1 : 0];
            if (!isset($existing[$sid])) {
                db_insert('class_subjects', ['session_id' => $session_id, 'class_id' => $class_id, 'subject_id' => $sid, 'has_exam' => $flags[0], 'is_third_language' => $flags[1]]);
                $added++;
            } elseif ($existing[$sid] !== $flags) {
                db_execute('UPDATE class_subjects SET has_exam = ?, is_third_language = ? WHERE session_id = ? AND class_id = ? AND subject_id = ?', 'iiiii', $flags[0], $flags[1], $session_id, $class_id, $sid);
                $changed++;
            }
        }
        foreach (array_diff(array_keys($existing), $teach) as $sid) {
            db_execute('DELETE FROM class_subjects WHERE session_id = ? AND class_id = ? AND subject_id = ?', 'iii', $session_id, $class_id, $sid);
            $removed++;
        }
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        throw $e;
    }
    $counts = array_filter(['added' => $added, 'changed' => $changed, 'removed' => $removed]);
    if ($counts) log_action($admin_id, 'CLASS_SUBJECTS_SAVED', 'class_subjects', $class_id, null, ['session_id' => $session_id] + $counts);
    $_SESSION['success'] = 'Class ' . $classes[$class_id]['name'] . ': ' . ($counts ? implode(', ', array_map(fn($k, $n) => "$n $k", array_keys($counts), $counts)) : 'no changes') . '.';
    if (count($third) === 1) $_SESSION['error'] = 'Third language: only one subject is ticked. Students choose between two — tick a second one, or untick it and it stays an ordinary subject for everyone.';
    header($here); exit;
}

if (isset($_POST['remove_id'])) {
    verify_csrf_or_die();
    $row = db_get_row('SELECT cs.id, cs.class_id, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.id = ? AND cs.session_id = ?', 'ii', (int)$_POST['remove_id'], $session_id);
    if ($row) {
        db_execute('DELETE FROM class_subjects WHERE id = ?', 'i', (int)$row['id']);
        log_action($admin_id, 'CLASS_SUBJECT_REMOVED', 'class_subjects', (int)$row['id'], $row);
        $_SESSION['success'] = $row['subject_name'] . ' removed from Class ' . $classes[(int)$row['class_id']]['name'] . '.';
    }
    header($here); exit;
}

// the previous session's subjects copied into the latest session; what the latest already has is kept
$latest = $sessions ? $sessions[count($sessions) - 1] : null;
$previous = count($sessions) > 1 ? $sessions[count($sessions) - 2] : null;
if (isset($_POST['copy_forward']) && $previous) {
    verify_csrf_or_die();
    $copied = (int)db_execute('INSERT IGNORE INTO class_subjects (session_id, class_id, subject_id, has_exam, is_third_language)
        SELECT ?, cs.class_id, cs.subject_id, cs.has_exam, cs.is_third_language FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id AND s.is_active = 1
        WHERE cs.session_id = ?', 'ii', (int)$latest['id'], (int)$previous['id']);
    if ($copied) log_action($admin_id, 'CLASS_SUBJECTS_COPIED', 'class_subjects', null, null, ['from_session_id' => (int)$previous['id'], 'to_session_id' => (int)$latest['id'], 'copied' => $copied]);
    $_SESSION[$copied ? 'success' : 'error'] = $copied ? "Copied $copied class subject(s) from {$previous['session_name']} to {$latest['session_name']}." : "Nothing copied — {$latest['session_name']} already has every class subject of {$previous['session_name']}.";
    header('Location: class_subjects.php?session_id=' . (int)$latest['id']); exit;
}

$subjects = db_get_all('SELECT id, subject_name FROM subjects WHERE is_active = 1 ORDER BY subject_name');
$saved = [];   // the chosen class's rows: subject_id => [exam, third]
if ($class_id) foreach (db_get_all('SELECT subject_id, has_exam, is_third_language FROM class_subjects WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id) as $r) $saved[(int)$r['subject_id']] = [(int)$r['has_exam'], (int)$r['is_third_language']];
$is_hs = $class_id && $classes[$class_id]['stage'] === 'higher_secondary';

$by_class = [];   // every class's subjects this session
foreach (db_get_all('SELECT cs.id, cs.class_id, s.subject_name, cs.has_exam, cs.is_third_language FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id AND s.is_active = 1
                     JOIN classes c ON c.id = cs.class_id WHERE cs.session_id = ? ORDER BY c.sort_order, s.subject_name', 'i', $session_id) as $r) $by_class[(int)$r['class_id']][] = $r;
$assignments = array_sum(array_map('count', $by_class));

// classes offering a third language (two or more ticked), and how many of their students still have to choose
$tl_classes = [];
foreach (db_get_all('SELECT class_id FROM class_subjects WHERE session_id = ? AND is_third_language = 1 GROUP BY class_id HAVING COUNT(*) >= 2', 'i', $session_id) as $r) {
    if (($classes[(int)$r['class_id']]['stage'] ?? '') !== 'higher_secondary') $tl_classes[(int)$r['class_id']] = 0;
}
if ($tl_classes) {
    foreach (db_get_all("SELECT sah.class_id, COUNT(*) AS n FROM student_academic_history sah
                         JOIN students s ON s.id = sah.student_id AND s.student_status = 'Active'
                         LEFT JOIN student_third_language stl ON stl.student_id = sah.student_id
                         WHERE sah.session_id = ? AND sah.academic_status = 'Current' AND stl.id IS NULL AND sah.class_id IN (" . implode(',', array_keys($tl_classes)) . ')
                         GROUP BY sah.class_id', 'i', $session_id) as $r) $tl_classes[(int)$r['class_id']] = (int)$r['n'];
}
$session_name = ''; foreach ($sessions as $s) if ((int)$s['id'] === $session_id) $session_name = $s['session_name'];
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class Subjects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    #grid td.c, #grid th.c { text-align: center; } #grid input[type=checkbox] { width: 17px; height: 17px; cursor: pointer; } #grid input:disabled { opacity: .3; cursor: not-allowed; }
    .tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag { display: inline-flex; align-items: center; gap: 5px; padding: 3px 4px 3px 11px; background: #f0f7ff; border: 1px solid #d0dbe8; border-radius: 16px; font-size: 12.5px; color: #1a3b55; }
    .tag.no-exam { border-style: dashed; }
    .tag .flag { font-size: 10px; padding: 0 6px; border-radius: 8px; background: #fff3cd; color: #7a5a00; } .tag .flag.tl { background: #e8f4ff; color: #003366; }
    .tag .icon-btn { font-size: 11px; padding: 2px 5px; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-link"></i> Class Subjects <small>(<?php echo $h($session_name); ?>)</small></div>
        <?php if ($previous): ?>
        <form method="post" onsubmit="return confirm('Copy every class subject of <?php echo $h($previous['session_name']); ?> into <?php echo $h($latest['session_name']); ?>? Subjects it already has are kept.')">
            <?php echo csrf_field(); ?><button type="submit" name="copy_forward" class="btn btn-primary"><i class="fas fa-copy"></i> Copy <?php echo $h($previous['session_name']); ?> → <?php echo $h($latest['session_name']); ?></button>
        </form>
        <?php endif; ?>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>
    <?php if (!$active_id): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> কোনো Active Academic Session পাওয়া যায়নি — Sessions পেজ থেকে একটা Session-কে Active করুন।</div><?php endif; ?>

    <form method="get" class="filter-box"><div class="filter-row">
        <div class="filter-group"><label><i class="fas fa-calendar-alt"></i> Session</label>
            <select name="session_id" onchange="this.form.submit()"><?php foreach (array_reverse($sessions) as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === $session_id ? 'selected' : ''; ?>><?php echo $h($s['session_name']) . ($s['status'] === 'Active' ? ' (Active)' : ''); ?></option><?php endforeach; ?></select></div>
        <div class="filter-group"><label><i class="fas fa-chalkboard"></i> Class to edit</label>
            <select name="class_id" onchange="this.form.submit()"><option value="">— select —</option><?php foreach ($classes as $id => $c): ?><option value="<?php echo $id; ?>" <?php echo $id === $class_id ? 'selected' : ''; ?>><?php echo $h($c['name']); ?></option><?php endforeach; ?></select></div>
    </div></form>

    <?php if ($class_id): ?>
    <form method="post" class="form-card" id="assign">
        <h4><i class="fas fa-book"></i> Class <?php echo $h($classes[$class_id]['name']); ?> — কোন subject পড়ানো হয়, কীসের পরীক্ষা হয়</h4>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <div class="row-actions" style="margin-bottom:10px">
            <button type="button" class="btn btn-secondary btn-sm" data-all="1"><i class="fas fa-check-double"></i> All</button>
            <button type="button" class="btn btn-secondary btn-sm" data-all="0"><i class="fas fa-times"></i> None</button>
            <span class="form-hint" id="count" style="margin:0 0 0 8px"></span>
        </div>
        <div class="table-responsive"><table class="table" id="grid">
            <thead><tr><th>Subject</th><th class="c">পড়ানো হয়</th><th class="c">পরীক্ষা হয়</th><th class="c" title="২টা টিক দিলে ঐ class-এর ছাত্র একটা বাছবে">3rd Language</th></tr></thead>
            <tbody>
            <?php foreach ($subjects as $s): $sid = (int)$s['id']; $on = isset($saved[$sid]); ?>
                <tr>
                    <td><?php echo $h($s['subject_name']); ?></td>
                    <td class="c"><input type="checkbox" name="teach[]" value="<?php echo $sid; ?>" class="teach" <?php echo $on ? 'checked' : ''; ?>></td>
                    <td class="c"><input type="checkbox" name="exam[]" value="<?php echo $sid; ?>" class="exam" <?php echo $on && $saved[$sid][0] ? 'checked' : ''; ?> <?php echo $on ? '' : 'disabled'; ?>></td>
                    <td class="c"><input type="checkbox" name="third[]" value="<?php echo $sid; ?>" class="third" <?php echo $on && $saved[$sid][1] ? 'checked' : ''; ?> <?php echo $on && !$is_hs ? '' : 'disabled'; ?>></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <div class="form-hint">"পড়ানো হয়" টিক দিলে subject-টা রুটিনে আসবে। "পরীক্ষা হয়" টিক দিলে exam, marks ও result-এ আসবে। Drawing, Adult Education-এর মতো subject-এ শুধু প্রথমটা টিক দিন।
            <strong>3rd Language</strong>: যে class-এ ছাত্র Arabic/Sanskrit-এর মধ্যে একটা বাছে, সেখানে ঐ দুটোয় টিক দিন — তারপর <a href="assign_third_language.php">3rd Language Assign</a>-এ ছাত্রদের বাছাই।
            <?php if ($is_hs): ?><span style="color:#c62828">XI/XII-এ 3rd Language নেই — ওখানে Arabic/Sanskrit সাধারণ subject।</span><?php endif; ?></div>
        <div class="btn-group">
            <button type="submit" name="save_class_subjects" class="btn btn-success"><i class="fas fa-save"></i> Save Class <?php echo $h($classes[$class_id]['name']); ?></button>
            <a href="class_subjects.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $class_id; ?>" class="btn btn-secondary"><i class="fas fa-undo"></i> Reset to saved</a>
        </div>
    </form>
    <?php endif; ?>

    <div class="stats-row">
        <div class="stat-card"><div class="number"><?php echo $assignments; ?></div><div class="label">Assignments</div></div>
        <div class="stat-card"><div class="number green"><?php echo count($by_class); ?></div><div class="label">Classes</div></div>
        <div class="stat-card"><div class="number orange"><?php echo count($subjects); ?></div><div class="label">Subjects</div></div>
    </div>

    <?php if (!$by_class): ?>
    <div class="empty-state"><i class="fas fa-link"></i><h3>No subjects assigned in <?php echo $h($session_name); ?></h3><p>Choose a class above and tick its subjects.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Class</th><th>Subjects</th><th>Count</th><th>Third Language</th></tr></thead>
            <tbody>
            <?php foreach ($by_class as $cid => $rows): ?>
                <tr>
                    <td><a href="class_subjects.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $cid; ?>#assign"><strong><?php echo $h($classes[$cid]['name'] ?? ''); ?></strong></a></td>
                    <td><div class="tags">
                    <?php foreach ($rows as $r): ?>
                        <span class="tag<?php echo (int)$r['has_exam'] ? '' : ' no-exam'; ?>"><?php echo $h($r['subject_name']); ?>
                            <?php if (!(int)$r['has_exam']): ?><span class="flag" title="ক্লাস হয়, পরীক্ষা হয় না">no exam</span><?php endif; ?>
                            <?php if ((int)$r['is_third_language']): ?><span class="flag tl" title="ছাত্র একটা বাছে">3rd lang</span><?php endif; ?>
                            <form method="post" style="display:inline" onsubmit="return confirm('Remove <?php echo $h(addslashes($r['subject_name'])); ?> from Class <?php echo $h($classes[$cid]['name'] ?? ''); ?>?')">
                                <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="remove_id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="icon-btn danger" title="Remove from class"><i class="fas fa-times-circle"></i></button>
                            </form></span>
                    <?php endforeach; ?>
                    </div></td>
                    <td><span class="badge badge-info"><?php echo count($rows); ?></span></td>
                    <td><?php if (isset($tl_classes[$cid])): $left = $tl_classes[$cid]; ?>
                        <a href="assign_third_language.php?class_id=<?php echo $cid; ?>" class="btn <?php echo $left ? 'btn-warning' : 'btn-success'; ?> btn-sm"><i class="fas fa-language"></i> Assign<?php echo $left ? " ($left বাকি)" : ' ✓'; ?></a>
                    <?php else: ?><span style="color:#adb5bd">—</span><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<script>
(function () {
    var grid = document.getElementById('grid'); if (!grid) return;
    var hs = <?php echo $is_hs ? 'true' : 'false'; ?>, rows = grid.querySelectorAll('tbody tr');
    function count() {
        var n = function (c) { return grid.querySelectorAll('.' + c + ':checked').length; };
        document.getElementById('count').textContent = 'Taught: ' + n('teach') + ' · Exam: ' + n('exam') + ' · 3rd Lang: ' + n('third');
    }
    // a subject is examined and can be a third language only when it is taught; a newly taught one is examined by default
    function taught(row, on) {
        var ex = row.querySelector('.exam'), th = row.querySelector('.third'), was = !ex.disabled;
        row.querySelector('.teach').checked = on;
        ex.disabled = !on; th.disabled = !on || hs;
        if (on && !was) ex.checked = true;
        if (!on) { ex.checked = false; th.checked = false; }
    }
    rows.forEach(function (row) {
        row.querySelector('.teach').addEventListener('change', function () { taught(row, this.checked); count(); });
    });
    grid.addEventListener('change', count);
    document.querySelectorAll('[data-all]').forEach(function (b) {
        b.addEventListener('click', function () { rows.forEach(function (row) { taught(row, b.dataset.all === '1'); }); count(); });
    });
    count();
})();
</script>
</body>
</html>

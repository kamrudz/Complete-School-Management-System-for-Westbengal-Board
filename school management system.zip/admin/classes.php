<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/class_helper.php';
require_once '../includes/logger.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $class = db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $id);
    $deps = $class ? db_dependents('classes', $id) : [];
    if (!$class) {
        $_SESSION['error'] = 'Class not found.';
    } elseif ($deps) {
        $_SESSION['error'] = 'Class ' . $class['class_name'] . ' cannot be deleted — it is still used by ' . db_dependents_text($deps) . '.';
    } else {
        db_execute('DELETE FROM classes WHERE id = ?', 'i', $id);
        log_action((int)($_SESSION['admin_id'] ?? 0), 'CLASS_DELETED', 'classes', $id, ['class_name' => $class['class_name']]);
        $_SESSION['success'] = 'Class ' . $class['class_name'] . ' deleted.';
    }
    header('Location: classes.php'); exit;
}

$classes = class_rows();
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1");
$section_counts = [];   // sections of each class in the active session
if ($active) {
    foreach (db_get_all('SELECT class_id, COUNT(*) AS n FROM sections WHERE session_id = ? GROUP BY class_id', 'i', (int)$active['id']) as $r) $section_counts[(int)$r['class_id']] = (int)$r['n'];
}
$stage_colours = ['primary' => '#7a4a00', 'upper_primary' => '#0b5f3a', 'secondary' => '#1a3d7a', 'higher_secondary' => '#0f4c5c'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classes</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-chalkboard"></i> Classes <small>(<?php echo count($classes); ?>)</small></div>
        <a href="add_class.php" class="btn btn-success"><i class="fas fa-plus"></i> Add New Class</a>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($_SESSION[$kind], ENT_QUOTES, 'UTF-8'); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <?php if (!$classes): ?>
    <div class="empty-state"><i class="fas fa-chalkboard"></i><h3>No classes yet</h3><p>Click <strong>Add New Class</strong> to create the first one.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>#</th><th>Class</th><th>Stage</th><th>Sections<?php echo $active ? ' (' . htmlspecialchars($active['session_name'], ENT_QUOTES, 'UTF-8') . ')' : ''; ?></th><th>Actions</th></tr></thead>
            <tbody>
            <?php $n = 0; foreach ($classes as $id => $c): $n++; $sections = $section_counts[$id] ?? 0; ?>
                <tr>
                    <td><?php echo $n; ?></td>
                    <td><strong><?php echo htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8'); ?></strong></td>
                    <td>
                        <span class="badge" style="background:#f2f6fa;color:<?php echo $stage_colours[$c['stage']] ?? '#333'; ?>"><?php echo htmlspecialchars(class_stage_label($c['stage']), ENT_QUOTES, 'UTF-8'); ?></span>
                        <?php if ($c['board_exam']): ?><span class="badge badge-warning" title="The board holds this class's examination">board exam</span><?php endif; ?>
                    </td>
                    <td><span class="badge badge-info"><?php echo $sections; ?> section<?php echo $sections === 1 ? '' : 's'; ?></span></td>
                    <td><div class="row-actions">
                        <a href="edit_class.php?id=<?php echo $id; ?>" class="icon-btn" title="Edit"><i class="fas fa-edit"></i></a>
                        <form method="post" onsubmit="return confirm('Delete Class <?php echo htmlspecialchars($c['name'], ENT_QUOTES, 'UTF-8'); ?>?')">
                            <?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo $id; ?>">
                            <button type="submit" class="icon-btn danger" title="Delete"><i class="fas fa-trash"></i></button>
                        </form>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

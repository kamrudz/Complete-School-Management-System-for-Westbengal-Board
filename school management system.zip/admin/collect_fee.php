<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/fee_helper.php';

/**
 * Collect: one student — every fee they owe, all or part, and fines — or a whole class, a tick for each fee of each
 * student. Fees with a slip go on a receipt of the main book, the others on a receipt of the cash book.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$sessions = exam_sessions();
$session_id = (int)$in('session_id', 0);
if (!isset($sessions[$session_id])) $session_id = fee_active_session_id() ?: (int)array_key_first($sessions);
$session_name = exam_session_name($session_id);
$mode = $in('mode') === 'class' ? 'class' : 'one';
$uid = student_uid_clean($in('uid', ''));
$classes = class_rows();
$class_id = (int)$in('class_id', 0);
if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? array_column(db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id), 'section_name', 'id') : [];
$section_id = (int)$in('section_id', 0);
if (!isset($sections[$section_id])) $section_id = 0;
$roll = fn(string $k) => preg_match('/^\d{1,4}$/', trim((string)$in($k, ''))) ? (int)trim((string)$in($k)) : null;
$roll_from = $roll('roll_from');
$roll_to = $roll('roll_to');
if ($roll_from !== null && $roll_to !== null && $roll_from > $roll_to) [$roll_from, $roll_to] = [$roll_to, $roll_from];
$here = fn(array $q = []) => 'collect_fee.php?' . http_build_query(array_filter(($mode === 'class'
    ? ['mode' => 'class', 'session_id' => $session_id, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null, 'roll_from' => $roll_from, 'roll_to' => $roll_to]
    : ['session_id' => $session_id, 'uid' => $uid !== '' ? $uid : null]) + $q, fn($v) => $v !== null));
$go = function (string $url, string $kind = '', string $msg = '') { if ($kind !== '') $_SESSION[$kind] = $msg; header("Location: $url"); exit(); };

if (($_GET['ajax'] ?? '') === 'search') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? ''));
    if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $rows = db_get_all("SELECT s.id, s.student_name, s.photo, s.student_status, g.father_name, c.class_name, sec.section_name, h.roll_no, se.session_name
        FROM students s
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 JOIN academic_sessions s2 ON s2.id = h2.session_id
                                                       WHERE h2.student_id = s.id ORDER BY h2.session_id = ? DESC, s2.session_name DESC LIMIT 1)
        LEFT JOIN academic_sessions se ON se.id = h.session_id
        LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE s.student_status <> 'Deleted' AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ? OR s.mobile LIKE ?)
        ORDER BY s.student_status = 'Active' DESC, s.student_name LIMIT 15", 'isssss', $session_id, $like, $like, $like, $like, $like);
    $owing = fee_owing($session_id, array_column($rows, 'id'));
    echo json_encode(['results' => array_map(fn($r) => [
        'uid' => $r['id'], 'name' => $r['student_name'], 'father' => (string)$r['father_name'], 'status' => $r['student_status'],
        'photo' => $r['photo'] ? '../uploads/students/' . rawurlencode($r['photo']) : '',
        'where' => trim(($r['class_name'] ? 'Class ' . $r['class_name'] : '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · Roll ' . $r['roll_no'] : '') . ($r['session_name'] ? ' · ' . $r['session_name'] : '')),
        'due' => fee_money_p($owing[$r['id']] ?? 0), 'owes' => ($owing[$r['id']] ?? 0) > 0], $rows)], JSON_UNESCAPED_UNICODE);
    exit();
}

if (isset($_GET['find_class'])) {
    $row = db_get_row("SELECT h.student_id FROM student_academic_history h JOIN students s ON s.id = h.student_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.roll_no = ? AND s.student_status <> 'Deleted' LIMIT 1",
        'iiis', $session_id, (int)$_GET['find_class'], (int)($_GET['find_section'] ?? 0), trim((string)($_GET['find_roll'] ?? '')));
    if ($row) $go('collect_fee.php?' . http_build_query(['session_id' => $session_id, 'uid' => $row['student_id']]));
    $go('collect_fee.php?' . http_build_query(['session_id' => $session_id]), 'error', "No student at that class, section and roll in $session_name.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $token = (string)($_POST['token'] ?? '');
    try {
        if ($token === '' || !isset($_SESSION['fee_collect_tokens'][$token])) throw new RuntimeException('This was saved already, or the page is old — nothing was saved twice. Look again.');
        unset($_SESSION['fee_collect_tokens'][$token]);
        $raw = json_decode((string)($_POST['items'] ?? ''), true);
        if (!is_array($raw) || !$raw) throw new RuntimeException('The ticks did not arrive — try again.');
        if ($mode === 'one' && ($uid === '' || !fee_student($uid, $session_id))) throw new RuntimeException('Choose the student again.');
        $items = [];
        foreach ($raw as $r) {
            $r = is_array($r) ? array_values($r) : [];
            if ($mode === 'class') {
                $who = is_string($r[0] ?? null) ? student_uid_clean($r[0]) : '';
                if ($who === '' || !is_int($r[1] ?? null) || !is_int($r[2] ?? null) || $r[2] <= 0) throw new RuntimeException('The ticks did not arrive — try again.');
                $items[] = [$who, 'fee', $r[1], $r[2], $r[2], ''];
            } else {
                if (!in_array($r[0] ?? null, ['fee', 'bill', 'charge'], true) || !is_int($r[1] ?? null) || !is_int($r[2] ?? null) || !is_int($r[3] ?? null) || !is_string($r[4] ?? '')) throw new RuntimeException('The amounts did not arrive — try again.');
                $items[] = [$uid, $r[0], $r[1], $r[2], $r[3], (string)($r[4] ?? '')];
            }
        }
        $print = ['main' => !empty($_POST['print_main']), 'cash' => !empty($_POST['print_cash'])];
        $done = fee_collect_items($session_id, $items, (string)$in('method'), (string)$in('reference'), (string)$in('pay_date'), $mode === 'one' ? (string)$in('remarks') : '', $print, $admin_id);
        if ($mode === 'class') {
            $_SESSION['fee_collect_done'] = array_column($done, 0);
            $go($here(['done' => 1]));
        }
        $slips = array_column(array_filter($done, fn($d) => $print[$d['book']]), 0);
        if ($slips) $go('fee_receipt.php?' . http_build_query(['ids' => implode(',', $slips), 'new' => 1]));
        $go($here(), 'success', 'Saved without a slip: ' . implode(', ', array_map(fn($d) => $d[1] . ' — ' . fee_money_p($d[2]), $done)) . '.');
    } catch (RuntimeException $e) {
        $go($here(), 'error', $e->getMessage());
    }
}

$heads = fee_session_heads();
$charge_heads = fee_charge_heads();
$token = '';
$new_token = function () use (&$token) {
    $token = bin2hex(random_bytes(16));
    $_SESSION['fee_collect_tokens'][$token] = time();
    $_SESSION['fee_collect_tokens'] = array_slice($_SESSION['fee_collect_tokens'], -20, null, true);
};
$book_of = fn(array $h) => $h['slip'] ? 'main' : 'cash';
$prefix = ['main' => fee_book_prefix('main'), 'cash' => fee_book_prefix('cash')];

$student = null;
if ($mode === 'one' && $uid !== '') {
    $student = fee_student($uid, $session_id);
    if (!$student) { $_SESSION['error'] = 'Student not found, or deleted.'; $uid = ''; }
}
$fee_rows = []; $other = []; $nos = []; $recent = []; $discount = null; $owing = 0; $place = null;
if ($student) {
    $place = fee_class_students($session_id, [(int)($student['place']['class_id'] ?? 0)], 0, [$uid])[$uid] ?? null;
    $shown = [];
    foreach ($place ? fee_standing($session_id, [$uid => $place], $heads)[$uid] : [] as $hid => $c) {
        if ($c['state'] === 'na' || (isset($c['bill']) && $c['bill']['fees'] > 1 && $c['state'] !== 'paid')) continue;
        $fee_rows[$hid] = $c;
        if (isset($c['bill'])) $shown[$c['bill']['id']] = true;
    }
    $other = array_filter(fee_student_bills($uid, 0, true), fn($b) => !isset($shown[(int)$b['id']]));
    $nos = fee_bill_receipt_nos(array_keys($shown));
    $recent = array_slice(fee_student_receipts($uid), 0, 5);
    $discount = fee_discounts($session_id, [$uid])[$uid] ?? null;
    $owing = fee_owing($session_id, [$uid])[$uid] ?? 0;
    $new_token();
}

$rows = []; $cols = []; $standing = []; $done = [];
if ($mode === 'class' && $class_id) {
    $rows = fee_class_students($session_id, [$class_id], $section_id);
    if ($roll_from !== null || $roll_to !== null) $rows = array_filter($rows, function ($s) use ($roll_from, $roll_to) {
        $r = trim((string)$s['roll_no']);
        return ctype_digit($r) && ($roll_from === null || (int)$r >= $roll_from) && ($roll_to === null || (int)$r <= $roll_to);
    });
    $standing = fee_standing($session_id, $rows, $heads);
    foreach ($heads as $hid => $h) foreach ($standing as $cells) if ($cells[$hid]['state'] !== 'na') { $cols[$hid] = $h; break; }
    $bill_ids = [];
    foreach ($standing as $cells) foreach ($cells as $c) if (isset($c['bill'])) $bill_ids[] = $c['bill']['id'];
    $nos = fee_bill_receipt_nos($bill_ids);
    $open = 0;
    foreach ($standing as $cells) foreach ($cols as $hid => $h) if (in_array($cells[$hid]['state'], ['todo', 'due', 'part'], true)) $open++;
    if ($open) $new_token();
    if (!empty($_GET['done']) && !empty($_SESSION['fee_collect_done'])) {
        $ids = array_map('intval', (array)$_SESSION['fee_collect_done']);
        $done = db_get_all('SELECT id, book, receipt_no, amount, slip_given FROM fee_receipts WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY book, seq', str_repeat('i', count($ids)), ...$ids);
    }
}
$photo = fn(?string $f, string $name) => $f ? '<img src="../uploads/students/' . h(rawurlencode($f)) . '" alt="">' : '<span class="ph">' . h(mb_substr($name, 0, 1)) . '</span>';
$discount_label = fn(?array $d) => $d ? ($d['discount_type'] === 'percentage' ? rtrim(rtrim($d['discount_value'], '0'), '.') . '%' : fee_money($d['discount_value'])) . ' — ' . $d['discount_reason'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Collect</title>
<?php exam_styles('fee'); ?>
<style>
    .seg { display: inline-flex; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 14px; }
    .seg a { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; } .seg a i { margin-right: 6px; }
    .find { display: grid; grid-template-columns: 1.4fr 1fr; gap: 14px; margin-bottom: 14px; }
    .find .card { margin: 0; }
    .sbox { position: relative; }
    .sbox input { width: 100%; height: 46px; border: 1px solid #c9d6e2; border-radius: 10px; padding: 8px 14px 8px 42px; font-size: 15px; box-sizing: border-box; }
    .sbox input:focus { outline: none; border-color: var(--ex-light); box-shadow: 0 0 0 3px rgba(var(--ex-rgb), .12); }
    .sbox > i { position: absolute; left: 15px; top: 16px; color: #8a9aab; }
    .res { margin-top: 8px; border: 1px solid #dfe7ef; border-radius: 10px; overflow: hidden; display: none; max-height: 380px; overflow-y: auto; }
    .res.open { display: block; }
    .res a { display: flex; align-items: center; gap: 10px; padding: 9px 12px; border-bottom: 1px solid #eef2f6; text-decoration: none; color: #1f2d3a; }
    .res a:hover, .res a.on { background: var(--ex-soft); }
    .res a .who { flex: 1; min-width: 0; font-size: 13.5px; } .res a small { display: block; color: #6b7d90; }
    .res .due { font-weight: 700; color: #b71c1c; font-size: 12.5px; white-space: nowrap; } .res .due.clear { color: #1b7a3a; }
    .ph, .res img, .stu-card img { width: 38px; height: 38px; border-radius: 50%; object-fit: cover; background: var(--ex-soft); display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: var(--ex-dark); flex: none; }
    .stu-card { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; background: linear-gradient(135deg, var(--ex-soft), #fff); border: 1px solid var(--ex-border); border-radius: 14px; padding: 14px 16px; margin-bottom: 14px; }
    .stu-card img, .stu-card .ph { width: 64px; height: 64px; font-size: 24px; }
    .stu-card h2 { margin: 0; font-size: 19px; color: var(--ex-dark); }
    .stu-card .meta { font-size: 13px; color: #3b5168; margin-top: 3px; line-height: 1.6; }
    .stu-card .owe { margin-left: auto; text-align: right; }
    .stu-card .owe b { display: block; font-size: 24px; color: #b71c1c; font-variant-numeric: tabular-nums; } .stu-card .owe b.clear { color: #1b7a3a; }
    .stu-card .owe small { color: #6b7d90; }
    .lay { display: grid; grid-template-columns: minmax(0, 1fr) 330px; gap: 14px; align-items: start; }
    .dues td.money, .dues th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .dues input.pay { width: 100px; height: 34px; text-align: right; border: 1px solid #c9d6e2; border-radius: 7px; padding: 4px 8px; font-size: 14px; font-variant-numeric: tabular-nums; }
    .dues input.pay.bad, .dues select.bad { border-color: #d32f2f; background: #fff2f2; }
    .dues input.pay:disabled { background: #f2f4f6; color: #98a6b5; }
    .dues input[type=checkbox] { width: 18px; height: 18px; accent-color: var(--ex-light); }
    .dues tr.closed td { color: #7a8a9a; }
    .dues small { display: block; font-size: 11.5px; color: #6b7d90; margin-top: 2px; }
    .dues select.ch { height: 34px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13px; max-width: 220px; }
    .dues input.note { height: 34px; border: 1px solid #c9d6e2; border-radius: 7px; padding: 4px 8px; font-size: 13px; width: 100%; margin-top: 4px; }
    .nos { font-size: 11.5px; color: #6b7d90; }
    .pay-box { position: sticky; top: 70px; }
    .pay-box .big { font-size: 30px; font-weight: 800; color: var(--ex-dark); font-variant-numeric: tabular-nums; margin: 2px 0 8px; }
    .pay-box .words { font-size: 12px; color: #5b6b7c; min-height: 16px; }
    .methods { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-top: 6px; }
    .methods label { display: flex; align-items: center; gap: 7px; border: 1px solid #c9d6e2; border-radius: 9px; padding: 8px 10px; font-size: 13px; font-weight: 600; cursor: pointer; text-transform: none; margin: 0; }
    .methods label:has(input:checked) { border-color: var(--ex-light); background: var(--ex-soft); color: var(--ex-dark); }
    .methods input { width: auto; height: auto; accent-color: var(--ex-light); }
    .pf .chk { text-transform: none; font-weight: 600; color: #1f2d3a; align-items: flex-start; }
    .pf .chk small { display: block; font-weight: 400; color: #6b7d90; }
    .rcp td { font-size: 12.5px; }
    .chips { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; }
    .chips label { display: inline-flex; align-items: center; gap: 6px; padding: 5px 11px; border-radius: 999px; border: 1px solid var(--ex-border); background: #fff; font-size: 12.5px; font-weight: 600; color: var(--ex-dark); cursor: pointer; }
    .chips label:has(input:checked) { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
    .chips input { width: 15px; height: 15px; margin: 0; accent-color: #fff; }
    .chips .warn { background: #fff6e5; border-color: #f0c987; color: #7a4a00; }
    .cc td, .cc th { white-space: nowrap; }
    .cc th.fc, .cc td.fc { text-align: center; }
    .cc th.fc small { display: block; font-weight: 400; text-transform: none; letter-spacing: 0; color: #5b6b7c; }
    .cc td.money { text-align: right; font-variant-numeric: tabular-nums; font-weight: 700; }
    .cc input[type=checkbox] { width: 17px; height: 17px; accent-color: var(--ex-light); cursor: pointer; vertical-align: middle; }
    .cc label.pay { display: inline-flex; align-items: center; gap: 5px; font-variant-numeric: tabular-nums; cursor: pointer; margin: 0; }
    .cc small { display: block; color: #6b7d90; font-size: 11px; }
    .cc .roll { font-weight: 700; color: var(--ex-dark); }
    .cc .free { color: #98a6b5; font-size: 12px; }
    .cc tr.skip td { color: #98a6b5; }
    .bar { position: sticky; bottom: 0; z-index: 20; background: #fff; border: 1px solid var(--ex-border); border-radius: 14px; box-shadow: 0 -4px 18px rgba(0,0,0,.08); padding: 12px 16px; margin-top: 12px; }
    .bar .line { display: flex; gap: 12px; align-items: flex-end; flex-wrap: wrap; }
    .bar .tot { margin-right: auto; } .bar .tot b { display: block; font-size: 22px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .bar .tot small { color: #6b7d90; font-size: 12px; }
    .bar label.l { display: block; font-size: 11px; font-weight: 700; color: #3b5168; margin: 0 0 4px; text-transform: uppercase; }
    .bar select, .bar input[type=text], .bar input[type=date] { height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; background: #fff; }
    .bar .btn { height: 38px; }
    .bar .slips { display: flex; gap: 6px 18px; flex-wrap: wrap; margin-top: 8px; font-size: 12.5px; color: #3b5168; }
    .bar .slips label { display: flex; align-items: center; gap: 6px; margin: 0; cursor: pointer; }
    .done { background: #e6f5ea; border: 1px solid #b6e2c2; border-radius: 14px; padding: 12px 16px; margin-bottom: 14px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; color: #1b5e33; }
    .done b { font-size: 15px; } .done .sp { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .print-head { display: none; }
    @media print {
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .seg, .noprint, .bar, .done, .alert { display: none !important; }
        .print-head { display: block; }
        .cc td, .cc th { white-space: normal !important; padding: 3px 5px !important; font-size: 11px !important; }
        .cc .tick, .cc input { display: none !important; }
        .auto-table-scroll { overflow: visible !important; margin-top: 0 !important; }
        .card { border: 0; padding: 0; }
    }
    @media (max-width: 980px) { .lay, .find { grid-template-columns: 1fr; } .pay-box { position: static; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Collect', 'Take fees from one student or a whole class — fees with a slip print one, the rest are kept on record', 'fa-cash-register',
        ['fee_receipts.php' => '<i class="fas fa-receipt"></i> Receipts', 'fee_dues.php' => '<i class="fas fa-file-invoice"></i> Bills']); ?>
    <?php fee_tabs('collect_fee.php'); exam_flash(); ?>
    <div class="seg">
        <a href="<?php echo h('collect_fee.php?' . http_build_query(['session_id' => $session_id])); ?>" class="<?php echo $mode === 'one' ? 'on' : ''; ?>"><i class="fas fa-user"></i>One student</a>
        <a href="<?php echo h('collect_fee.php?' . http_build_query(['mode' => 'class', 'session_id' => $session_id])); ?>" class="<?php echo $mode === 'class' ? 'on' : ''; ?>"><i class="fas fa-users"></i>Whole class</a>
    </div>

<?php if ($mode === 'one'): ?>
    <div class="find">
        <div class="card">
            <h2>Find a student <small>name, School UID, Banglar Shiksha ID, father or mobile</small></h2>
            <div class="sbox"><i class="fas fa-search"></i><input type="text" id="q" autocomplete="off" placeholder="Type at least 2 letters…" <?php echo $student ? '' : 'autofocus'; ?>></div>
            <div class="res" id="res"></div>
        </div>
        <div class="card">
            <h2>By class, section and roll</h2>
            <form method="get" class="pick">
                <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
                <div><label>Class</label><select name="find_class" id="fClass" required style="min-width:90px"><option value=""></option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo $cid; ?>"><?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Section</label><select name="find_section" id="fSection" required style="min-width:80px"><option value=""></option></select></div>
                <div><label>Roll</label><input type="text" name="find_roll" required inputmode="numeric" maxlength="6" style="min-width:0;width:80px"></div>
                <button type="submit" class="btn btn-primary" title="Open"><i class="fas fa-arrow-right"></i></button>
            </form>
            <form method="get" class="pick" style="margin-top:8px"><?php if ($uid !== ''): ?><input type="hidden" name="uid" value="<?php echo h($uid); ?>"><?php endif; ?>
                <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            </form>
        </div>
    </div>

    <?php if ($student): $pl = $student['place']; ?>
    <div class="stu-card">
        <?php echo $photo($student['photo'], $student['student_name']); ?>
        <div>
            <h2><?php echo h($student['student_name']); ?> <span class="chip off"><?php echo h($uid); ?></span>
                <?php if ($student['student_status'] !== 'Active'): ?><span class="chip warn"><?php echo h($student['student_status']); ?></span><?php endif; ?></h2>
            <div class="meta">
                <?php if ($pl): ?>Class <?php echo h($pl['class_name'] . ($pl['section_name'] ? '-' . $pl['section_name'] : '') . ($pl['roll_no'] ? ' · Roll ' . $pl['roll_no'] : '') . ' · ' . $pl['session_name']); ?><br><?php endif; ?>
                <?php echo $student['father_name'] ? 'Father: ' . h($student['father_name']) : ''; ?><?php echo $student['phone'] ? ' · <i class="fas fa-phone"></i> ' . h($student['phone']) : ''; ?>
                <?php if ($discount): ?> · <span class="chip ok"><i class="fas fa-percent"></i> <?php echo h($discount_label($discount)); ?></span><?php endif; ?>
            </div>
        </div>
        <div class="owe"><b class="<?php echo $owing ? '' : 'clear'; ?>"><?php echo h(fee_money_p($owing)); ?></b><small><?php echo $owing ? 'owing' : 'nothing owing'; ?></small><br><a href="<?php echo h('fee_ledger.php?uid=' . rawurlencode($uid)); ?>" style="font-size:12.5px"><i class="fas fa-book"></i> Full ledger</a></div>
    </div>

    <div class="lay">
        <div>
            <div class="card" style="overflow-x:auto">
                <h2>Fees of <?php echo h($session_name); ?></h2>
                <?php if (!$place): ?>
                <p class="note" style="margin:0">Not in a class of <?php echo h($session_name); ?> — only open bills and fines can be taken here.</p>
                <?php endif; ?>
                <table class="ex-table dues" id="dues">
                    <thead><tr><th></th><th>Fee</th><th class="money">To pay</th><th class="money">Take now (₹)</th></tr></thead>
                    <tbody>
                    <?php foreach ($fee_rows as $hid => $c): $h = $heads[$hid]; $open = in_array($c['state'], ['todo', 'due', 'part'], true); ?>
                    <tr<?php echo $open ? ' data-kind="fee" data-id="' . (int)$hid . '" data-shown="' . (int)$c['owe'] . '" data-book="' . h(isset($c['bill']) ? fee_bill_book($c['bill']['id'], $heads) : $book_of($h)) . '"' : ' class="closed"'; ?>>
                        <td><?php if ($open): ?><input type="checkbox" class="tick"<?php echo $h['who_pays'] !== 'some' || isset($c['bill']) ? ' checked' : ''; ?> aria-label="<?php echo h('Take ' . $h['type_name']); ?>"><?php endif; ?></td>
                        <td><b><?php echo h($h['type_name']); ?></b><?php echo $h['slip'] ? '' : ' <span class="chip warn">no slip</span>'; ?>
                            <?php if ($c['state'] === 'todo' && $c['off']): ?><small><?php echo h(fee_money_p($c['gross'])); ?> less <?php echo h(fee_money_p($c['off'])); ?> discount</small><?php endif; ?>
                            <?php if ($c['state'] === 'part'): ?><small><?php echo h(fee_money_p($c['bill']['paid'])); ?> paid of <?php echo h(fee_money_p($c['bill']['total'])); ?></small><?php endif; ?>
                            <?php if ($c['state'] === 'paid'): ?><small><?php echo h($nos[$c['bill']['id']] ?? ''); ?></small><?php endif; ?></td>
                        <td class="money"><?php echo match ($c['state']) { 'paid' => fee_state_chip('paid'), 'zero' => '<span class="chip off">Nothing to pay</span>', default => h(fee_money_p($c['owe'])) }; ?></td>
                        <td class="money"><?php if ($open): ?><input type="text" class="pay" inputmode="decimal" value="<?php echo h(fee_rupees($c['owe'])); ?>"><?php endif; ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php foreach ($other as $id => $b): $bal = fee_paise($b['total']) - fee_paise($b['paid_amount']); ?>
                    <tr data-kind="bill" data-id="<?php echo (int)$id; ?>" data-shown="<?php echo $bal; ?>" data-book="<?php echo h(fee_bill_book((int)$id, $heads)); ?>">
                        <td><input type="checkbox" class="tick" checked aria-label="<?php echo h('Take ' . $b['title']); ?>"></td>
                        <td><b><?php echo h($b['title']); ?></b><?php echo (int)$b['session_id'] !== $session_id ? ' <span class="chip off">' . h($b['session_name']) . '</span>' : ''; ?>
                            <small><?php echo h(implode(' · ', array_map(fn($it) => $it['description'] . ' ' . fee_money($it['net']), $b['items']))); ?><?php echo fee_paise($b['paid_amount']) ? ' · ' . h(fee_money($b['paid_amount'])) . ' paid' : ''; ?></small></td>
                        <td class="money"><?php echo h(fee_money_p($bal)); ?></td>
                        <td class="money"><input type="text" class="pay" inputmode="decimal" value="<?php echo h(fee_rupees($bal)); ?>"></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if (!$fee_rows && !$other): ?><p class="note">No fee is set for this class yet — see <a href="fee_settings.php">Fee Settings</a>. A fine can still be added below.</p><?php endif; ?>
                <?php if ($charge_heads): ?>
                <div style="margin-top:10px"><button type="button" class="btn btn-warning btn-sm" id="addCharge"><i class="fas fa-plus"></i> Fine or other</button></div>
                <?php endif; ?>
            </div>
            <?php if ($recent): ?>
            <div class="card">
                <h2>Recent receipts <small><a href="<?php echo h('fee_receipts.php?' . http_build_query(['uid' => $uid])); ?>">all</a></small></h2>
                <table class="ex-table rcp">
                    <thead><tr><th>Receipt</th><th>Date</th><th class="money" style="text-align:right">Amount</th><th>Paid by</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($recent as $r): ?>
                    <tr><td><b><?php echo h($r['receipt_no']); ?></b><?php echo $r['slip_given'] ? '' : ' <span class="chip warn">no slip</span>'; ?></td><td><?php echo h(date('d M Y', strtotime($r['receipt_date']))); ?></td><td style="text-align:right"><?php echo h(fee_money($r['amount'])); ?></td>
                        <td><?php echo h(FEE_METHODS[$r['method']] ?? $r['method']); ?> <?php echo $r['status'] === 'cancelled' ? fee_state_chip('cancelled') : ''; ?></td>
                        <td><a class="btn btn-secondary btn-sm" href="<?php echo h('fee_receipt.php?id=' . (int)$r['id']); ?>" target="_blank" title="Print"><i class="fas fa-print"></i></a></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <form method="post" class="card pf pay-box" id="payForm" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="uid" value="<?php echo h($uid); ?>"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
            <input type="hidden" name="token" value="<?php echo h($token); ?>"><input type="hidden" name="items" id="items">
            <h2 style="margin-bottom:0">Take payment</h2>
            <div class="big" id="payTotal">₹0.00</div>
            <div class="words" id="payWords"></div>
            <label>Paid by</label>
            <div class="methods"><?php foreach (FEE_METHODS as $k => $label): ?><label><input type="radio" name="method" value="<?php echo h($k); ?>"<?php echo $k === 'cash' ? ' checked' : ''; ?>> <?php echo h($label); ?></label><?php endforeach; ?></div>
            <div id="refBox" style="display:none"><label id="refLabel">Reference</label><input type="text" name="reference" id="ref" maxlength="100"></div>
            <label>Date</label><input type="date" name="pay_date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" required>
            <label>Remarks</label><input type="text" name="remarks" maxlength="255" placeholder="optional">
            <label class="chk" id="mainPrint"><input type="checkbox" name="print_main" value="1" checked><span>Print the slip <small><?php echo h($prefix['main']); ?>/<?php echo h($session_name); ?>/…</small></span></label>
            <label class="chk" id="cashPrint" style="display:none"><input type="checkbox" name="print_cash" value="1"><span>Also print a slip for the no-slip fees <small>they go on <?php echo h($prefix['cash']); ?>/<?php echo h($session_name); ?>/… either way</small></span></label>
            <div class="acts"><button type="submit" class="btn btn-success" id="payBtn" style="width:100%;justify-content:center" disabled><i class="fas fa-check"></i> Collect</button></div>
        </form>
    </div>
    <template id="chargeRow">
        <tr data-kind="charge" data-shown="0">
            <td><input type="checkbox" class="tick" checked aria-label="Take this charge"></td>
            <td><select class="ch"><?php foreach ($charge_heads as $id => $hd): ?><option value="<?php echo (int)$id; ?>" data-amount="<?php echo h(fee_paise($hd['default_amount']) ? fee_rupees(fee_paise($hd['default_amount'])) : ''); ?>" data-book="<?php echo h($book_of($hd)); ?>"><?php echo h($hd['type_name']); ?></option><?php endforeach; ?></select>
                <input type="text" class="note" maxlength="80" placeholder="Note, e.g. Class IX marksheet"></td>
            <td class="money"><button type="button" class="btn btn-secondary btn-sm drop" title="Remove"><i class="fas fa-times"></i></button></td>
            <td class="money"><input type="text" class="pay" inputmode="decimal" placeholder="0.00"></td>
        </tr>
    </template>
    <?php elseif ($uid === ''): ?>
    <div class="ex-empty"><i class="fas fa-user-graduate"></i>Search for the student above — every fee they owe shows here, ready to collect.</div>
    <?php endif; ?>

<?php else: ?>
    <?php if ($done): $sum = array_sum(array_map(fn($d) => fee_paise($d['amount']), $done)); $slips = array_filter($done, fn($d) => $d['slip_given']); $cash = array_filter($done, fn($d) => $d['book'] === 'cash'); ?>
    <div class="done">
        <i class="fas fa-check-circle" style="font-size:22px"></i>
        <div><b><?php echo count($done); ?> receipt(s) — <?php echo h(fee_money_p($sum)); ?></b><br>
            <small><?php echo h(implode(' · ', array_map(function ($book) use ($done) {
                $nos = array_column(array_filter($done, fn($d) => $d['book'] === $book), 'receipt_no');
                return $nos ? ($nos[0] . (count($nos) > 1 ? ' to ' . end($nos) : '')) . ($book === 'cash' ? ' (no slip)' : '') : '';
            }, ['main', 'cash'])) ?: ''); ?></small></div>
        <span class="sp">
            <?php if ($slips): ?><a class="btn btn-success" target="_blank" href="<?php echo h('fee_receipt.php?ids=' . implode(',', array_column($slips, 'id'))); ?>"><i class="fas fa-print"></i> Print <?php echo count($slips); ?> slip(s)</a><?php endif; ?>
            <?php if ($cash && count($slips) < count($done)): ?><a class="btn btn-secondary" href="<?php echo h('fee_receipts.php?' . http_build_query(['slip' => 'no'])); ?>"><i class="fas fa-receipt"></i> No-slip receipts</a><?php endif; ?>
        </span>
    </div>
    <?php endif; ?>

    <form method="get" class="card pick noprint">
        <input type="hidden" name="mode" value="class">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value = '0'; this.form.submit()"><option value="0">Choose…</option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo $cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>><?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()"><option value="0">All sections</option><?php echo exam_options($sections, $section_id); ?></select></div>
        <div><label>Roll from</label><input type="text" name="roll_from" value="<?php echo h($roll_from ?? ''); ?>" inputmode="numeric" maxlength="4" style="min-width:0;width:90px"></div>
        <div><label>Roll to</label><input type="text" name="roll_to" value="<?php echo h($roll_to ?? ''); ?>" inputmode="numeric" maxlength="4" style="min-width:0;width:90px"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header(mb_strtoupper('Fees — Class ' . ($classes[$class_id]['name'] ?? '') . ($section_id ? '-' . $sections[$section_id] : '')), "Session $session_name" . ($roll_from !== null || $roll_to !== null ? ' · Roll ' . ($roll_from ?? 1) . ' to ' . ($roll_to ?? '…') : '')); ?></div>

    <?php if (!$class_id): ?>
    <div class="ex-empty"><i class="fas fa-users"></i>Choose a class to see its students and their fees.</div>
    <?php elseif (!$rows): ?>
    <div class="ex-empty"><i class="fas fa-user-slash"></i>No current student here<?php echo $roll_from !== null || $roll_to !== null ? ' in these rolls' : ''; ?>.</div>
    <?php elseif (!$cols): ?>
    <?php exam_guard('No fee is set for this class', ' Give the class its amounts in Fee Settings, then come back.', 'fee_settings.php?' . http_build_query(['session_id' => $session_id]), 'Fee Settings'); ?>
    <?php else: ?>
    <div class="chips noprint">
        <?php foreach ($cols as $hid => $h): ?><label title="Show or hide this fee"><input type="checkbox" class="col" value="<?php echo (int)$hid; ?>" checked> <?php echo h($h['type_name']); ?><?php echo $h['slip'] ? '' : ' · no slip'; ?></label><?php endforeach; ?>
    </div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table cc" id="cc">
            <thead><tr><th class="tick" style="width:34px"><input type="checkbox" id="all" title="Tick everyone"></th><th style="width:60px">Roll</th><th>Student</th>
                <?php foreach ($cols as $hid => $h): ?><th class="fc" data-col="<?php echo (int)$hid; ?>"><?php echo h($h['type_name']); ?><small><?php echo h(FEE_WHO_PAYS[$h['who_pays']] !== 'Everyone' ? FEE_WHO_PAYS[$h['who_pays']] : ($h['slip'] ? 'with slip' : 'no slip')); ?></small></th><?php endforeach; ?>
                <th class="money" style="text-align:right">Total</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $suid => $s): $cells = $standing[$suid]; $seen = []; $any = false; ?>
            <tr data-uid="<?php echo h($suid); ?>">
                <td class="tick"><input type="checkbox" class="row" aria-label="<?php echo h('Tick ' . $s['student_name']); ?>"></td>
                <td class="roll"><?php echo h((!$section_id && $s['section_name'] ? $s['section_name'] . ' · ' : '') . ($s['roll_no'] ?? '')); ?></td>
                <td><b><?php echo h($s['student_name']); ?></b><small><?php echo h($suid); ?></small></td>
                <?php foreach ($cols as $hid => $h): $c = $cells[$hid]; $bill = $c['bill']['id'] ?? 0; ?>
                <td class="fc" data-col="<?php echo (int)$hid; ?>"><?php
                    if (in_array($c['state'], ['todo', 'due', 'part'], true) && !isset($seen[$bill])) {
                        if ($bill) $seen[$bill] = true;
                        $any = true;
                        echo '<label class="pay"><input type="checkbox" class="cell" data-head="' . (int)$hid . '" data-owe="' . (int)$c['owe'] . '" data-book="' . h($bill ? fee_bill_book($bill, $heads) : $book_of($h)) . '" data-def="' . ($h['who_pays'] !== 'some' || $bill ? 1 : 0) . '"> ' . h(preg_replace('/\.00$/', '', fee_num_p($c['owe']))) . '</label>';
                        if ($c['state'] === 'part') echo '<small>left of ' . h(fee_money_p($c['bill']['total'])) . '</small>';
                        elseif ($c['state'] === 'todo' && $c['off']) echo '<small>after ' . h(fee_money_p($c['off'])) . ' off</small>';
                    } elseif ($c['state'] === 'paid') echo fee_state_chip('paid') . '<small>' . h($nos[$bill] ?? '') . '</small>';
                    elseif ($c['state'] === 'zero') echo '<span class="free">Nothing to pay</span>';
                    elseif ($bill && isset($seen[$bill])) echo '<small>same bill</small>';
                ?></td>
                <?php endforeach; ?>
                <td class="money" data-total>—</td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($token !== ''): ?>
    <form method="post" class="bar noprint" id="ccForm" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="mode" value="class"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <input type="hidden" name="section_id" value="<?php echo $section_id; ?>"><input type="hidden" name="roll_from" value="<?php echo h($roll_from ?? ''); ?>"><input type="hidden" name="roll_to" value="<?php echo h($roll_to ?? ''); ?>">
        <input type="hidden" name="token" value="<?php echo h($token); ?>"><input type="hidden" name="items" id="items">
        <div class="line">
            <div class="tot"><b id="ccTotal">₹0.00</b><small id="ccCount"></small></div>
            <div><label class="l">Paid by</label><select name="method" id="ccMethod"><?php echo exam_options(FEE_METHODS, 'cash'); ?></select></div>
            <div id="ccRefBox" style="display:none"><label class="l">Reference</label><input type="text" name="reference" id="ccRef" maxlength="100" placeholder="UPI ID, cheque no."></div>
            <div><label class="l">Date</label><input type="date" name="pay_date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" required></div>
            <button type="submit" class="btn btn-success" id="ccSave" disabled><i class="fas fa-check"></i> Collect</button>
        </div>
        <div class="slips">
            <label><input type="checkbox" name="print_main" value="1" checked> Print slips <span id="mainSum"></span></label>
            <label id="cashPrint"><input type="checkbox" name="print_cash" value="1"> Also print slips for the no-slip fees <span id="cashSum"></span></label>
        </div>
    </form>
    <p class="note noprint">Each student gets one receipt for the fees with a slip (<?php echo h($prefix['main']); ?>/…) and one for the fees kept without (<?php echo h($prefix['cash']); ?>/…). To take part of a fee, use One student.</p>
    <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
</div>
<script>
(function () {
    var money = function (p) { return '₹' + (p / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var refFor = function (method, box, input, label) {
        var cash = method === 'cash';
        box.style.display = cash ? 'none' : '';
        input.required = !cash;
        if (label) label.textContent = { upi: 'UPI transaction ID', bank: 'Bank reference / UTR', cheque: 'Cheque number and bank' }[method] || 'Reference';
    };
<?php if ($mode === 'one'): ?>
    var SESSION = <?php echo (int)$session_id; ?>;
    var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
    var q = document.getElementById('q'), res = document.getElementById('res'), timer = null, ctrl = null;
    q.addEventListener('input', function () {
        clearTimeout(timer);
        var v = q.value.trim();
        if (v.length < 2) { res.classList.remove('open'); return; }
        timer = setTimeout(function () {
            if (ctrl) ctrl.abort();
            ctrl = window.AbortController ? new AbortController() : null;
            fetch('collect_fee.php?ajax=search&session_id=' + SESSION + '&q=' + encodeURIComponent(v), ctrl ? { signal: ctrl.signal } : {}).then(function (r) { return r.json(); }).then(function (d) {
                res.innerHTML = d.results.length ? d.results.map(function (s) {
                    return '<a href="collect_fee.php?session_id=' + SESSION + '&uid=' + encodeURIComponent(s.uid) + '">' + (s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="ph">' + esc(s.name.charAt(0)) + '</span>')
                        + '<span class="who"><b>' + esc(s.name) + '</b> <span class="chip off">' + esc(s.uid) + '</span>' + (s.status !== 'Active' ? ' <span class="chip warn">' + esc(s.status) + '</span>' : '')
                        + '<small>' + esc(s.where) + (s.father ? ' · Father: ' + esc(s.father) : '') + '</small></span><span class="due' + (s.owes ? '' : ' clear') + '">' + (s.owes ? 'owes ' + esc(s.due) : 'clear') + '</span></a>';
                }).join('') : '<a href="#" onclick="return false"><span class="who">No student matches “' + esc(v) + '”.</span></a>';
                res.classList.add('open');
            }).catch(function () {});
        }, 220);
    });
    q.addEventListener('keydown', function (e) {
        var items = res.querySelectorAll('a[href^="collect_fee"]'), on = res.querySelector('a.on'), i = Array.prototype.indexOf.call(items, on);
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (on) on.classList.remove('on'); i = e.key === 'ArrowDown' ? Math.min(items.length - 1, i + 1) : Math.max(0, i - 1); if (items[i]) items[i].classList.add('on'); }
        if (e.key === 'Enter' && items.length) { e.preventDefault(); location.href = (on || items[0]).getAttribute('href'); }
    });
    var fc = document.getElementById('fClass'), fs = document.getElementById('fSection');
    fc.addEventListener('change', function () {
        fs.innerHTML = '<option value=""></option>';
        if (!fc.value) return;
        fetch('get_sections.php?no_placeholder=1&class_id=' + encodeURIComponent(fc.value) + '&session_id=' + SESSION).then(function (r) { return r.text(); }).then(function (html) { fs.innerHTML += html; });
    });
    var form = document.getElementById('payForm');
    if (!form) return;
    var body = document.querySelector('#dues tbody'), btn = document.getElementById('payBtn');
    var paise = function (v) { v = String(v).replace(/,/g, '').trim(); return /^\d{1,7}(\.\d{1,2})?$/.test(v) ? Math.round(parseFloat(v) * 100) : null; };
    var ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    var tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    function inWords(n) {
        if (n === 0) return 'Zero';
        var out = '', units = [[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand'], [100, 'Hundred']];
        units.forEach(function (u) { if (n >= u[0]) { out += inWords(Math.floor(n / u[0])) + ' ' + u[1] + ' '; n %= u[0]; } });
        return (out + (n < 20 ? ones[n] : tens[Math.floor(n / 10)] + (n % 10 ? ' ' + ones[n % 10] : ''))).trim();
    }
    var rows = function () { return Array.prototype.slice.call(body.querySelectorAll('tr[data-kind]')); };
    var bookOf = function (tr) { var s = tr.querySelector('select.ch'); return s ? s.options[s.selectedIndex].dataset.book : tr.dataset.book; };
    function refresh() {
        var sum = 0, bad = false, books = {};
        rows().forEach(function (tr) {
            var tick = tr.querySelector('.tick'), input = tr.querySelector('.pay');
            input.disabled = !tick.checked;
            var p = paise(input.value), limit = tr.dataset.kind === 'charge' ? 10000000 : +tr.dataset.shown;
            var wrong = tick.checked && (p === null || p <= 0 || p > limit);
            input.classList.toggle('bad', wrong);
            if (wrong) bad = true;
            else if (tick.checked) { sum += p; books[bookOf(tr)] = true; }
        });
        document.getElementById('payTotal').textContent = money(sum);
        document.getElementById('payWords').textContent = sum ? 'Rupees ' + inWords(Math.floor(sum / 100)) + (sum % 100 ? ' and ' + inWords(sum % 100) + ' Paise' : '') + ' Only' : '';
        document.getElementById('mainPrint').style.display = books.main ? '' : 'none';
        document.getElementById('cashPrint').style.display = books.cash ? '' : 'none';
        btn.disabled = bad || sum <= 0;
        btn.innerHTML = '<i class="fas fa-check"></i> ' + (sum ? 'Collect ' + money(sum) : 'Collect');
        return !bad && sum > 0 ? sum : 0;
    }
    body.addEventListener('change', refresh);
    body.addEventListener('input', refresh);
    var add = document.getElementById('addCharge');
    if (add) add.addEventListener('click', function () {
        var tr = document.getElementById('chargeRow').content.firstElementChild.cloneNode(true), ch = tr.querySelector('select.ch'), pay = tr.querySelector('.pay');
        var fill = function () { pay.value = ch.options[ch.selectedIndex].dataset.amount || ''; refresh(); };
        ch.addEventListener('change', fill);
        tr.querySelector('.drop').addEventListener('click', function () { tr.remove(); refresh(); });
        body.appendChild(tr);
        fill();
        pay.focus();
    });
    Array.prototype.forEach.call(form.querySelectorAll('input[name=method]'), function (r) {
        r.addEventListener('change', function () { refFor(r.value, document.getElementById('refBox'), document.getElementById('ref'), document.getElementById('refLabel')); });
    });
    form.addEventListener('submit', function (e) {
        var sum = refresh();
        if (!sum) { e.preventDefault(); return; }
        var items = [];
        rows().forEach(function (tr) {
            if (!tr.querySelector('.tick').checked) return;
            var p = paise(tr.querySelector('.pay').value);
            if (tr.dataset.kind === 'charge') items.push(['charge', +tr.querySelector('select.ch').value, 0, p, tr.querySelector('.note').value]);
            else items.push([tr.dataset.kind, +tr.dataset.id, +tr.dataset.shown, p, '']);
        });
        document.getElementById('items').value = JSON.stringify(items);
        if (!confirm('Collect ' + money(sum) + ' from ' + <?php echo json_encode($student['student_name'] ?? '', JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP); ?> + '?')) e.preventDefault();
        else btn.disabled = true;
    });
    refresh();
<?php else: ?>
    var form = document.getElementById('ccForm');
    if (!form) return;
    var table = document.getElementById('cc'), all = document.getElementById('all'), save = document.getElementById('ccSave');
    var trs = Array.prototype.slice.call(table.querySelectorAll('tbody tr'));
    var hidden = {};
    var cellsOf = function (tr) { return Array.prototype.filter.call(tr.querySelectorAll('input.cell'), function (c) { return !hidden[c.dataset.head]; }); };
    function setRow(tr, on) { cellsOf(tr).forEach(function (c) { c.checked = on && c.dataset.def === '1'; }); }
    function refresh() {
        var sum = 0, n = 0, books = { main: 0, cash: 0 }, ticked = 0, rowsWith = 0;
        trs.forEach(function (tr) {
            var t = 0, mine = cellsOf(tr);
            mine.forEach(function (c) { if (c.checked) { t += +c.dataset.owe; books[c.dataset.book] += +c.dataset.owe; } });
            var box = tr.querySelector('input.row');
            box.disabled = !mine.length;
            box.checked = t > 0;
            if (mine.length) rowsWith++;
            if (t > 0) { n++; ticked++; }
            tr.classList.toggle('skip', mine.length > 0 && t === 0);
            tr.querySelector('[data-total]').textContent = t ? money(t) : '—';
            sum += t;
        });
        document.getElementById('ccTotal').textContent = money(sum);
        document.getElementById('ccCount').textContent = n + ' student(s)';
        document.getElementById('mainSum').textContent = books.main ? '(' + money(books.main) + ')' : '';
        document.getElementById('cashSum').textContent = books.cash ? '(' + money(books.cash) + ')' : '';
        document.getElementById('cashPrint').style.display = books.cash ? '' : 'none';
        all.checked = rowsWith > 0 && ticked === rowsWith;
        all.indeterminate = ticked > 0 && ticked < rowsWith;
        save.disabled = !sum;
        save.innerHTML = '<i class="fas fa-check"></i> ' + (sum ? 'Collect ' + money(sum) : 'Collect');
        return sum;
    }
    trs.forEach(function (tr) {
        setRow(tr, true);
        tr.querySelector('input.row').addEventListener('change', function () { setRow(tr, this.checked); refresh(); });
        Array.prototype.forEach.call(tr.querySelectorAll('input.cell'), function (c) { c.addEventListener('change', refresh); });
    });
    all.addEventListener('change', function () { trs.forEach(function (tr) { setRow(tr, all.checked); }); refresh(); });
    Array.prototype.forEach.call(document.querySelectorAll('.chips input.col'), function (chip) {
        chip.addEventListener('change', function () {
            hidden[chip.value] = !chip.checked;
            Array.prototype.forEach.call(table.querySelectorAll('[data-col="' + chip.value + '"]'), function (el) { el.style.display = chip.checked ? '' : 'none'; });
            Array.prototype.forEach.call(table.querySelectorAll('input.cell[data-head="' + chip.value + '"]'), function (c) {
                c.checked = chip.checked && c.dataset.def === '1' && c.closest('tr').querySelector('input.row').checked;
            });
            refresh();
        });
    });
    var method = document.getElementById('ccMethod');
    method.addEventListener('change', function () { refFor(method.value, document.getElementById('ccRefBox'), document.getElementById('ccRef')); });
    form.addEventListener('submit', function (e) {
        var sum = refresh(), items = [];
        if (!sum) { e.preventDefault(); return; }
        trs.forEach(function (tr) { cellsOf(tr).forEach(function (c) { if (c.checked) items.push([tr.dataset.uid, +c.dataset.head, +c.dataset.owe]); }); });
        document.getElementById('items').value = JSON.stringify(items);
        if (!confirm('Collect ' + money(sum) + ' from ' + document.getElementById('ccCount').textContent + '?')) e.preventDefault();
        else save.disabled = true;
    });
    refresh();
<?php endif; ?>
})();
</script>
</body>
</html>

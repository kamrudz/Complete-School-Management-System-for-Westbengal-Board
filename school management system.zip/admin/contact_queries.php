<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/** What people write from the website's contact form. Opening one marks it read; nothing is ever changed. */
const QUERY_STATES = ['New' => ['Unread', 'bad'], 'Read' => ['Read', 'warn'], 'Replied' => ['Answered', 'ok']];

$status = (string)($_GET['status'] ?? '');
if (!isset(QUERY_STATES[$status])) $status = '';
$search = trim((string)($_GET['search'] ?? ''));
$per = (int)($_GET['per'] ?? 25);
if (!in_array($per, [25, 50, 100], true)) $per = 25;
$page = max(1, (int)($_GET['page'] ?? 1));
$self = fn(array $extra = []) => 'contact_queries.php?' . http_build_query(array_merge($_GET, $extra));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $id = (int)($_POST['id'] ?? 0);
    $row = $id ? db_get_row('SELECT id, name, status FROM contact_queries WHERE id = ?', 'i', $id) : null;
    if (!$row) $_SESSION['error'] = 'That message is gone — look at the list again.';
    elseif (isset($_POST['mark_replied'])) {
        db_execute("UPDATE contact_queries SET status = 'Replied' WHERE id = ?", 'i', $id);
        $_SESSION['success'] = $row['name'] . "'s message is marked answered.";
    } elseif (isset($_POST['mark_new'])) {
        db_execute("UPDATE contact_queries SET status = 'New' WHERE id = ?", 'i', $id);
        $_SESSION['success'] = $row['name'] . "'s message is unread again.";
        header('Location: ' . $self(['view' => null]));   // staying on it would read it again at once
        exit();
    }
    header('Location: ' . $self(['view' => $id]));
    exit();
}

$view = null;
if (isset($_GET['view']) && (int)$_GET['view'] > 0) {
    $view = db_get_row('SELECT * FROM contact_queries WHERE id = ? LIMIT 1', 'i', (int)$_GET['view']);
    if ($view && $view['status'] === 'New') {
        db_execute("UPDATE contact_queries SET status = 'Read' WHERE id = ?", 'i', (int)$view['id']);
        $view['status'] = 'Read';
    }
}

$counts = db_get_row("SELECT COUNT(*) total, SUM(status = 'New') new_count, SUM(status = 'Read') read_count, SUM(status = 'Replied') replied FROM contact_queries") ?: [];
$where = '1';
$types = '';
$params = [];
if ($status !== '') { $where .= ' AND status = ?'; $types .= 's'; $params[] = $status; }
if ($search !== '') {
    $where .= ' AND (name LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)';
    $types .= 'ssss';
    $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
    array_push($params, $like, $like, $like, $like);
}
$total = (int)(db_get_row("SELECT COUNT(*) n FROM contact_queries WHERE $where", $types, ...$params)['n'] ?? 0);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$rows = db_get_all("SELECT * FROM contact_queries WHERE $where ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Messages</title>
<?php exam_styles('web'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb a { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; text-decoration: none; display: block; }
    .sb a.on { border-color: var(--ex-dark); border-left-color: var(--ex-dark); background: var(--ex-soft); }
    .sb b { display: block; font-size: 21px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .msg { background: #f7fafc; border: 1px solid #e3e9f0; border-radius: 10px; padding: 14px 16px; white-space: pre-wrap; line-height: 1.65; font-size: 14px; margin-top: 10px; }
    .meta { display: flex; gap: 18px; flex-wrap: wrap; font-size: 13px; color: #41566c; }
    .meta b { color: var(--ex-dark); }
    .cut { max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #6b7d90; font-size: 12.5px; }
    tr.unread td { background: #fff9f9; }
    .acts { display: flex; gap: 5px; }
    .acts form { display: inline; }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 12px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Messages', 'What people write from the contact form on the website', 'fa-envelope',
        ['../index.php#contact' => '<i class="fas fa-external-link-alt"></i> The form on the site']); ?>
    <?php exam_tabs('contact_queries.php', WEB_PAGES); exam_flash(); ?>

    <div class="sb">
        <a href="contact_queries.php" class="<?php echo $status === '' ? 'on' : ''; ?>"><b><?php echo (int)($counts['total'] ?? 0); ?></b><span>All messages</span></a>
        <a href="<?php echo h('contact_queries.php?status=New'); ?>" class="<?php echo $status === 'New' ? 'on' : ''; ?>"><b><?php echo (int)($counts['new_count'] ?? 0); ?></b><span>Unread</span></a>
        <a href="<?php echo h('contact_queries.php?status=Read'); ?>" class="<?php echo $status === 'Read' ? 'on' : ''; ?>"><b><?php echo (int)($counts['read_count'] ?? 0); ?></b><span>Read</span></a>
        <a href="<?php echo h('contact_queries.php?status=Replied'); ?>" class="<?php echo $status === 'Replied' ? 'on' : ''; ?>"><b><?php echo (int)($counts['replied'] ?? 0); ?></b><span>Answered</span></a>
    </div>

    <?php if ($view): [$lbl, $chip] = QUERY_STATES[$view['status']] ?? ['', 'off']; ?>
    <div class="card">
        <h2><i class="fas fa-envelope-open-text"></i> <?php echo h($view['subject'] ?: '(no subject)'); ?> <span class="chip <?php echo h($chip); ?>"><?php echo h($lbl); ?></span></h2>
        <div class="meta">
            <div><b>From</b> <?php echo h($view['name']); ?></div>
            <div><b>Email</b> <a href="mailto:<?php echo h($view['email']); ?>"><?php echo h($view['email']); ?></a></div>
            <div><b>Came in</b> <?php echo h(date('d M Y, g:i a', strtotime($view['created_at']))); ?></div>
            <div><b>From the address</b> <?php echo h($view['ip_address'] ?: '—'); ?></div>
        </div>
        <div class="msg"><?php echo h($view['message']); ?></div>
        <div class="acts" style="margin-top:14px">
            <a href="<?php echo h('mailto:' . $view['email'] . '?subject=' . rawurlencode('Re: ' . ($view['subject'] ?: 'your message'))); ?>" class="btn btn-success"><i class="fas fa-reply"></i> Answer by email</a>
            <form method="post">
                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$view['id']; ?>">
                <?php if ($view['status'] !== 'Replied'): ?>
                    <button type="submit" name="mark_replied" class="btn btn-primary"><i class="fas fa-check"></i> Mark it answered</button>
                <?php else: ?>
                    <button type="submit" name="mark_new" class="btn btn-secondary"><i class="fas fa-rotate-left"></i> Put it back as unread</button>
                <?php endif; ?>
            </form>
            <form method="post" action="delete_contact_query.php" onsubmit="return confirm('Delete this message? It cannot be brought back.')">
                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$view['id']; ?>">
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button>
            </form>
            <a href="<?php echo h($self(['view' => null])); ?>" class="btn btn-secondary">Close</a>
        </div>
    </div>
    <?php endif; ?>

    <form method="get" class="card pick">
        <input type="hidden" name="status" value="<?php echo h($status); ?>">
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, email, subject or text" style="min-width:250px"></div>
        <div><label>Per page</label><select name="per"><?php echo exam_options([25 => 25, 50 => 50, 100 => 100], $per); ?></select></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
        <div><a href="contact_queries.php" class="btn btn-secondary">Reset</a></div>
    </form>

    <div class="card">
        <h2><i class="fas fa-inbox"></i> <?php echo $status !== '' ? h(QUERY_STATES[$status][0]) : 'Every message'; ?> <small><?php echo number_format($total); ?><?php echo $pages > 1 ? ' · page ' . $page . ' of ' . $pages : ''; ?></small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-inbox"></i><?php echo ($counts['total'] ?? 0) ? 'No message matches what you asked for.' : 'Nobody has written yet.'; ?></div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th style="width:44px">#</th><th>From</th><th>Subject and message</th><th>Came in</th><th>Where it stands</th><th></th></tr></thead>
            <tbody>
            <?php $i = ($page - 1) * $per; foreach ($rows as $r): [$lbl, $chip] = QUERY_STATES[$r['status']] ?? ['', 'off']; ?>
                <tr class="<?php echo $r['status'] === 'New' ? 'unread' : ''; ?>">
                    <td class="num"><?php echo ++$i; ?></td>
                    <td><b><?php echo h($r['name']); ?></b><div class="cut"><?php echo h($r['email']); ?></div></td>
                    <td><?php echo h($r['subject'] ?: '(no subject)'); ?><div class="cut"><?php echo h($r['message']); ?></div></td>
                    <td><?php echo h(date('d M Y', strtotime($r['created_at']))); ?><div class="cut"><?php echo h(date('g:i a', strtotime($r['created_at']))); ?></div></td>
                    <td><span class="chip <?php echo h($chip); ?>"><?php echo h($lbl); ?></span></td>
                    <td>
                        <div class="acts">
                            <a href="<?php echo h($self(['view' => (int)$r['id']])); ?>" class="btn btn-info btn-sm" title="Read it"><i class="fas fa-eye"></i></a>
                            <form method="post" action="delete_contact_query.php" onsubmit="return confirm('Delete this message? It cannot be brought back.')">
                                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php if ($pages > 1): ?>
        <div class="pager">
            <span>Page <?php echo $page; ?> of <?php echo $pages; ?></span>
            <?php if ($page > 1): ?><a href="<?php echo h($self(['page' => $page - 1])); ?>"><i class="fas fa-angle-left"></i> Back</a><?php endif; ?>
            <?php for ($p = max(1, $page - 3); $p <= min($pages, $page + 3); $p++): ?>
                <a href="<?php echo h($self(['page' => $p])); ?>" class="<?php echo $p === $page ? 'on' : ''; ?>"><?php echo $p; ?></a>
            <?php endfor; ?>
            <?php if ($page < $pages): ?><a href="<?php echo h($self(['page' => $page + 1])); ?>">Next <i class="fas fa-angle-right"></i></a><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <p class="note">Opening a message marks it read. Answering happens in your own email — "Mark it answered" only records that you did.</p>
    </div>
</div>
</body>
</html>

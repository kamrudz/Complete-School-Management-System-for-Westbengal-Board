<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$session_ids = array_map('intval', array_column($sessions, 'id'));

if (isset($_POST['do_copy'])) {
    verify_csrf_or_die();
    $from = (int)($_POST['from_session_id'] ?? 0);
    $to = (int)($_POST['to_session_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);   // 0 = every class
    if (!in_array($from, $session_ids, true) || !in_array($to, $session_ids, true)) {
        $_SESSION['error'] = 'From Session এবং To Session দুটোই সিলেক্ট করুন।';
    } elseif ($from === $to) {
        $_SESSION['error'] = 'From Session এবং To Session একই হতে পারবে না।';
    } else {
        $where = 'session_id = ?' . ($class_id ? ' AND class_id = ?' : '');
        $args = $class_id ? [$from, $class_id] : [$from];
        $total = (int)db_get_row("SELECT COUNT(*) AS n FROM sections WHERE $where", str_repeat('i', count($args)), ...$args)['n'];
        // the unique (session, class, name) skips the sections the target already has
        $copied = $total ? (int)db_execute("INSERT IGNORE INTO sections (session_id, class_id, section_name) SELECT ?, class_id, section_name FROM sections WHERE $where", str_repeat('i', count($args) + 1), $to, ...$args) : 0;
        if (!$total) {
            $_SESSION['error'] = 'Nothing to copy — the source session has no sections' . ($class_id ? ' for that class' : '') . '.';
        } elseif ($copied) {
            log_action((int)($_SESSION['admin_id'] ?? 0), 'SECTIONS_COPIED', 'sections', null, null, ['from_session_id' => $from, 'to_session_id' => $to, 'class_id' => $class_id, 'copied' => $copied]);
            $_SESSION['success'] = "$copied টা section কপি হয়েছে।" . ($total > $copied ? ' (' . ($total - $copied) . ' টা আগে থেকেই ছিল, তাই বাদ দেওয়া হয়েছে।)' : '');
            header("Location: sections.php?session_id=$to"); exit;
        } else {
            $_SESSION['error'] = "কিছু কপি হয়নি — $total টা section-ই target session-এ আগে থেকে আছে।";
        }
    }
    header('Location: copy_sections.php'); exit;
}
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Copy Sections</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:640px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-copy"></i> Copy Sections</div>
        <a href="sections.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Sections</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card" onsubmit="return confirm('Section গুলো কপি করতে চান?')">
        <div class="form-note"><i class="fas fa-info-circle"></i> যেই session-এ section আগে থেকেই আছে (same Class + same Section name), সেটা আবার কপি হবে না — শুধু নতুনগুলোই যোগ হবে। তাই এই পেজ নিরাপদে একাধিকবার চালানো যায়।</div>
        <?php echo csrf_field(); ?>
        <?php foreach (['from_session_id' => ['fa-calendar-alt', 'From Session (যেখান থেকে কপি হবে)'], 'to_session_id' => ['fa-calendar-plus', 'To Session (যেখানে কপি হবে)']] as $field => [$icon, $label]): ?>
        <div class="form-group"><label><i class="fas <?php echo $icon; ?>"></i> <?php echo $label; ?></label>
            <select name="<?php echo $field; ?>" required>
                <option value="">— select —</option>
                <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"><?php echo $h($s['session_name']) . ($s['status'] === 'Active' ? ' (Active)' : ''); ?></option><?php endforeach; ?>
            </select></div>
        <?php endforeach; ?>
        <div class="form-group"><label><i class="fas fa-chalkboard"></i> Class (ঐচ্ছিক)</label>
            <select name="class_id">
                <option value="0">All classes</option>
                <?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo $h($c['class_name']); ?></option><?php endforeach; ?>
            </select></div>
        <button type="submit" name="do_copy" class="btn btn-success"><i class="fas fa-copy"></i> Copy Sections</button>
    </form>
</div>
</body>
</html>

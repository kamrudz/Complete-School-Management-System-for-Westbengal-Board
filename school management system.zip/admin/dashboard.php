<?php
// ===== COMPLETE DASHBOARD WITH ALL PAGES =====
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

// A module whose own page already links everything it has opens that page directly (old links still work).
$direct = ['students' => 'students.php', 'staff' => 'staff.php', 'promotion' => 'promotion.php', 'promotion_history' => 'promotion_history.php',
           'pass_out' => 'pass_out_students.php', 'merit_ranks' => 'student_merit_ranks.php', 'backup' => 'backup_now.php', 'logs' => 'view_logs.php',
           'website_settings' => 'website_settings.php'];
if (isset($direct[$_GET['page'] ?? ''])) { header('Location: ' . $direct[$_GET['page']]); exit(); }

include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/promotion_helper.php");
require_once("../includes/fee_helper.php");

// ===== SCHOOL INFO =====
$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings LIMIT 1"));

// ===== CSRF TOKEN =====
if(!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ============================================================
// 1. BASIC COUNTS
// ============================================================
$count_student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM students WHERE student_status='Active'"));
$count_staff = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM staff"));
$count_subject = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM subjects WHERE is_active=1"));
$count_class = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM classes"));
$count_exam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM exams"));
$count_section = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM sections"));
$count_notice = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM notices"));
$count_class_subjects = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM class_subjects"));
$count_hs_exams = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM hs_exam"));

// ===== ADMISSION COUNTS =====
$adm_pending_res = mysqli_query($conn, "SELECT id FROM admission_applications WHERE application_status='Pending'");
$count_admission_pending = $adm_pending_res ? mysqli_num_rows($adm_pending_res) : 0;
$adm_total_res = mysqli_query($conn, "SELECT id FROM admission_applications");
$count_admission_total = $adm_total_res ? mysqli_num_rows($adm_total_res) : 0;

// ===== NEW CONTACT MESSAGES (badge on Website & Content) =====
$cq_res = @mysqli_query($conn, "SELECT id FROM contact_queries WHERE status='New'");
$count_new_queries = $cq_res ? mysqli_num_rows($cq_res) : 0;

// ===== LIBRARY (badge on sidebar + stat cards on the Library hub) =====
$lib_stock = mysqli_fetch_assoc(@mysqli_query($conn, "
    SELECT
        (SELECT COUNT(*) FROM library_books WHERE status='Active') AS total_titles,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Available') AS available_copies,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Issued') AS issued_copies
")) ?: [];
$lib_overdue_res = @mysqli_query($conn, "SELECT id FROM library_issues WHERE status='Issued' AND due_date < CURDATE()");
$lib_overdue_count = $lib_overdue_res ? mysqli_num_rows($lib_overdue_res) : 0;

// ============================================================
// 2. ACTIVE SESSION (moved up — must run before anything that
//    filters by the active session id, e.g. merit/fee stats below)
// ============================================================
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));

// ============================================================
// 3. YEAR END OF THE ACTIVE SESSION (the classes that go up by promotion)
// ============================================================
$active_session_id = (int)($active_session['id'] ?? 0);
$next_session_id = $active_session_id ? (int)promotion_next_session($active_session_id) : 0;
$year_end = ['next' => $next_session_id ? promotion_get_session_name($conn, $next_session_id) : '', 'classes' => 0, 'merit' => 0, 'promoted' => 0];
if ($active_session_id) {
    foreach (promotion_year_status($active_session_id, $next_session_id)['classes'] as $y) {
        if ($y['next'] === null || (!$y['now'] && !$y['batch'])) continue;
        $year_end['classes']++;
        if ($y['merit']) $year_end['merit']++;
        if ($y['batch']) $year_end['promoted']++;
    }
}

// ============================================================
// 4. TODAY'S STATS
// ============================================================
$today = date('Y-m-d');
$today_provisional = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM provisional_routine WHERE provisional_date='$today' AND status='assigned'"));

$attendance_stats = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total, SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) as present FROM student_attendance WHERE attendance_date='$today'"));
$total_att = $attendance_stats['total'] ?? 0;
$present_att = $attendance_stats['present'] ?? 0;
$attendance_percent = $total_att > 0 ? round(($present_att / $total_att) * 100) : 0;

// ============================================================
// 5. FEE STATS
// ============================================================
$fee_session_id = (int)($active_session['id'] ?? 0);
$today_collected = (float)(db_get_row("SELECT COALESCE(SUM(amount), 0) AS t FROM fee_receipts WHERE status = 'valid' AND receipt_date = ?", 's', $today)['t'] ?? 0);
$acc_open = db_get_row('SELECT COUNT(*) AS n, COALESCE(SUM(opening_cash), 0) AS c, COALESCE(SUM(opening_bank), 0) AS b FROM acc_accounts');
$acc_move = db_get_row("SELECT COALESCE(SUM(IF(mode = 'cash', IF(direction = 'in', amount, -amount), 0)), 0) AS c, COALESCE(SUM(IF(mode = 'bank', IF(direction = 'in', amount, -amount), 0)), 0) AS b FROM acc_entries WHERE status = 'valid'");
$acc_cash = (float)$acc_open['c'] + (float)$acc_move['c'];
$acc_bank = (float)$acc_open['b'] + (float)$acc_move['b'];
$pending_amount = $fee_session_id ? fee_session_owing($fee_session_id) / 100 : 0;

// ============================================================
// 6. RECENT STUDENTS (with Photo)
// ============================================================
$recent_students = mysqli_query($conn, "
    SELECT s.*, c.class_name, sec.section_name 
    FROM students s
    LEFT JOIN student_academic_history sah ON s.id = sah.student_id
    LEFT JOIN classes c ON sah.class_id = c.id
    LEFT JOIN sections sec ON sah.section_id = sec.id
    WHERE s.student_status='Active'
    ORDER BY s.id DESC LIMIT 6
");

// ============================================================
// 7. BIRTHDAYS (Student + Staff)
// ============================================================
$birthdays = mysqli_query($conn, "
    SELECT student_name, dob, photo FROM students 
    WHERE DATE_FORMAT(dob, '%m-%d') = DATE_FORMAT('$today', '%m-%d')
    AND student_status='Active'
    LIMIT 5
");

$staff_birthdays = mysqli_query($conn, "
    SELECT staff_name, date_of_birth, photo FROM staff 
    WHERE DATE_FORMAT(date_of_birth, '%m-%d') = DATE_FORMAT('$today', '%m-%d')
    AND service_status='Active'
    LIMIT 5
");

// ============================================================
// 8. RECENT NOTICES
// ============================================================
$recent_notices = mysqli_query($conn, "SELECT * FROM notices ORDER BY id DESC LIMIT 4");

// ============================================================
// 9. V-X AND XI-XII COUNTS
// ============================================================
$count_student_hs = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(DISTINCT s.id) as total 
    FROM students s
    JOIN student_academic_history sah ON s.id = sah.student_id
    JOIN classes c ON sah.class_id = c.id
    WHERE s.student_status='Active' AND c.class_name IN ('XI','XII')
"));


// ============================================================
// 10. CURRENT PAGE
// ============================================================
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Students of each section of the school, from the stage stored on the class.
$count_student_pup = $count_student_sec = 0;
foreach (db_get_all("SELECT c.stage, COUNT(*) n FROM student_academic_history sah JOIN classes c ON c.id = sah.class_id JOIN students s ON s.id = sah.student_id AND s.student_status = 'Active' WHERE sah.academic_status = 'Current' GROUP BY c.stage") as $r) {
    if (in_array($r['stage'], ['primary', 'upper_primary'], true)) $count_student_pup += (int)$r['n'];
    elseif ($r['stage'] === 'secondary') $count_student_sec += (int)$r['n'];
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $school['school_name'] ?? 'SchoolMS'; ?> - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        /* ============================================
           RESET & BASE
           ============================================ */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        html, body {
            height: 100%;
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f0f4f9;
            display: flex;
            overflow: hidden; /* the page itself never scrolls — each pane below scrolls on its own, so this layout can't break no matter what global overflow rules exist elsewhere on the site */
        }

        /* ============================================
           SIDEBAR
           ============================================ */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #0a1628 0%, #162a4a 100%);
            padding: 0 0 20px 0;
            flex-shrink: 0;
            height: 100vh;
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            box-shadow: 3px 0 25px rgba(0, 0, 0, 0.15);
            transition: all 0.3s ease;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }
        .sidebar::-webkit-scrollbar { width: 4px; }
        .sidebar::-webkit-scrollbar-track { background: rgba(255, 255, 255, 0.03); }
        .sidebar::-webkit-scrollbar-thumb { background: #1f5b8a; border-radius: 10px; }

        .sidebar-logo {
            padding: 18px 18px 14px 18px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            flex-shrink: 0;
        }
        .sidebar-logo .logo-text {
            color: #fff;
            font-size: 20px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .sidebar-logo .logo-text i { color: #6ea8fe; font-size: 24px; }
        .sidebar-logo .logo-sub {
            color: #7a9bbd;
            font-size: 11px;
            font-weight: 400;
            margin-top: 2px;
            padding-left: 34px;
        }

        .sidebar-user {
            padding: 12px 16px 14px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            flex-shrink: 0;
        }
        .sidebar-user .user-name {
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .sidebar-user .user-name i { color: #6ea8fe; font-size: 18px; }
        .sidebar-user .user-role {
            color: #7a9bbd;
            font-size: 12px;
            font-weight: 500;
            margin-top: 2px;
            padding-left: 26px;
        }

        .sidebar-menu-wrap { flex: 1; overflow-y: auto; padding: 6px 0 8px 0; }
        .sidebar-label {
            padding: 10px 16px 4px 16px;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            color: #4a6a85;
        }
        .sidebar-menu { list-style: none; padding: 0 10px; }
        .sidebar-menu li { margin-bottom: 1px; }
        .sidebar-menu li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 8px 12px;
            color: #b0c8e0;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            border-radius: 8px;
            transition: all 0.25s ease;
            position: relative;
        }
        .sidebar-menu li a i {
            width: 18px;
            font-size: 15px;
            color: #5a7fa0;
            text-align: center;
            flex-shrink: 0;
        }
        .sidebar-menu li a:hover { background: rgba(255, 255, 255, 0.07); color: #fff; }
        .sidebar-menu li a:hover i { color: #6ea8fe; }
        .sidebar-menu li a.active {
            background: rgba(31, 91, 138, 0.30);
            color: #fff;
            box-shadow: inset 0 0 0 1px rgba(110, 168, 254, 0.25);
        }
        .sidebar-menu li a.active i { color: #6ea8fe; }
        .sidebar-menu li a.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 6px;
            bottom: 6px;
            width: 3px;
            background: #6ea8fe;
            border-radius: 0 3px 3px 0;
        }

        .sidebar-badge {
            background: #dc3545;
            color: #fff;
            font-size: 8px;
            font-weight: 700;
            padding: 1px 8px;
            border-radius: 20px;
            margin-left: auto;
        }
        .sidebar-badge.green { background: #28a745; }
        .sidebar-badge.orange { background: #f59e0b; }
        .sidebar-badge.hs { background: #dc3545; }

        .sidebar-footer {
            padding: 10px 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            flex-shrink: 0;
        }
        .sidebar-footer a {
            color: #6a8aaa;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 10px;
            border-radius: 8px;
            transition: all 0.25s ease;
        }
        .sidebar-footer a:hover { background: rgba(255, 255, 255, 0.07); color: #fff; }
        .sidebar-footer a i {
            font-size: 15px;
            color: #6a8aaa;
            width: 18px;
            text-align: center;
        }

        /* ============================================
           SIDEBAR TOGGLE (Mobile)
           ============================================ */
        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 98;
        }
        .sidebar-overlay.active { display: block; }

        .sidebar-toggle {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 99;
            background: #003366;
            color: #fff;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 22px;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 51, 102, 0.4);
            transition: all 0.3s ease;
            align-items: center;
            justify-content: center;
        }
        .sidebar-toggle:hover { transform: scale(1.05); }

        /* ============================================
           MAIN CONTENT
           ============================================ */
        .main-content {
            flex: 1;
            height: 100vh;
            overflow-y: auto;
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
            scroll-behavior: smooth;
            padding: 16px 20px 20px 20px;
            background: #f0f4f9;
            min-width: 0;
        }
        .main-content::-webkit-scrollbar { width: 8px; }
        .main-content::-webkit-scrollbar-track { background: transparent; }
        .main-content::-webkit-scrollbar-thumb { background: #d0dbe8; border-radius: 10px; }
        .main-content::-webkit-scrollbar-thumb:hover { background: #aebfd4; }

        /* Search + greeting bar stays pinned to the top of the content
           pane while the rest scrolls underneath it */
        .dash-topbar-sticky {
            position: sticky;
            top: -16px;
            margin: -16px -20px 0;
            padding: 16px 20px 10px;
            background: #f0f4f9;
            z-index: 40;
            transition: box-shadow 0.25s ease;
        }
        .dash-topbar-sticky.scrolled {
            box-shadow: 0 8px 16px -12px rgba(15, 26, 46, 0.18);
        }

        /* ============================================
           TOP HEADER
           ============================================ */
        .top-header {
            background: #fff;
            border-radius: 12px;
            padding: 14px 20px;
            margin-bottom: 16px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.04);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .top-header .greeting h2 {
            font-size: 20px;
            color: #0f1a2e;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .top-header .greeting h2 i { color: #f59e0b; }
        .top-header .greeting p {
            color: #6c7a8a;
            font-size: 13px;
            margin-top: 2px;
        }
        .top-header .date-time {
            text-align: right;
            background: #f8f9fa;
            padding: 6px 16px;
            border-radius: 30px;
        }
        .top-header .date-time .date {
            font-size: 12px;
            font-weight: 600;
            color: #0f1a2e;
        }
        .top-header .date-time .time {
            font-size: 18px;
            font-weight: 800;
            color: #003366;
        }

        /* ============================================
           GLOBAL SEARCH (TOP OF DASHBOARD)
           ============================================ */
        .dash-search-wrap {
            position: relative;
            margin-bottom: 16px;
        }
        .dash-search-box {
            position: relative;
            display: flex;
            align-items: center;
            background: #fff;
            border-radius: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
            border: 1px solid #e4edf6;
            padding: 4px 4px 4px 0;
        }
        .dash-search-box > i.fa-search {
            position: absolute;
            left: 22px;
            color: #6c7a8a;
            font-size: 15px;
            pointer-events: none;
        }
        .dash-search-box input {
            flex: 1;
            border: none;
            outline: none;
            background: transparent;
            padding: 13px 16px 13px 48px;
            font-size: 14px;
            color: #0f1a2e;
            border-radius: 30px;
        }
        .dash-search-box input::placeholder { color: #9aa7b5; }
        .dash-search-box .dash-search-kbd {
            display: flex;
            align-items: center;
            gap: 4px;
            background: #f8f9fa;
            border: 1px solid #e4edf6;
            border-radius: 8px;
            padding: 4px 8px;
            font-size: 11px;
            color: #8a97a5;
            margin-right: 10px;
            white-space: nowrap;
        }
        .dash-search-dropdown {
            display: none;
            position: absolute;
            top: calc(100% + 8px);
            left: 0;
            right: 0;
            max-height: 440px;
            overflow-y: auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.16);
            z-index: 500;
            padding: 8px 0;
        }
        .dgs-group-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            color: #003366;
            padding: 8px 18px 4px 18px;
            letter-spacing: 0.5px;
        }
        .dgs-item { display: block; padding: 9px 18px; text-decoration: none; border-bottom: 1px solid #f2f2f2; }
        .dgs-item:hover { background: #f5f8fb; }
        .dgs-item-title { font-size: 13.5px; font-weight: 600; color: #1a3b55; }
        .dgs-item-sub { font-size: 11.5px; color: #8a97a5; margin-top: 1px; }
        .dgs-empty { padding: 20px; text-align: center; font-size: 13px; color: #8a97a5; }
        @media (max-width: 600px) {
            .dash-search-kbd { display: none; }
        }

        /* ============================================
           SESSION BANNER
           ============================================ */
        .session-banner {
            background: linear-gradient(135deg, #003366, #1f5b8a);
            color: #fff;
            padding: 10px 18px;
            border-radius: 10px;
            margin-bottom: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
        }
        .session-banner .session-info {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
        }
        .session-banner .session-info .label { font-size: 10px; opacity: 0.7; }
        .session-banner .session-info .value { font-size: 15px; font-weight: 700; }
        .session-banner .session-info .badge {
            background: rgba(255, 255, 255, 0.18);
            padding: 2px 12px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 600;
        }
        .session-banner .session-actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        .session-banner .session-actions a {
            color: #fff;
            background: rgba(255, 255, 255, 0.12);
            padding: 4px 14px;
            border-radius: 30px;
            text-decoration: none;
            font-size: 11px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .session-banner .session-actions a:hover {
            background: rgba(255, 255, 255, 0.22);
            transform: translateY(-2px);
        }

        /* ============================================
           STATS GRID
           ============================================ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(155px, 1fr));
            gap: 12px;
            margin-bottom: 18px;
        }
        .stat-card {
            background: #fff;
            padding: 14px 16px;
            border-radius: 10px;
            border: 1px solid #e4edf6;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .stat-card::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08); }
        .stat-card .stat-icon {
            font-size: 24px;
            margin-bottom: 4px;
            display: inline-block;
            padding: 6px;
            border-radius: 8px;
            background: rgba(31, 91, 138, 0.08);
        }
        .stat-card .stat-number {
            font-size: 26px;
            font-weight: 800;
            color: #0f1a2e;
            line-height: 1.2;
        }
        .stat-card .stat-label {
            font-size: 12px;
            color: #6c7a8a;
            margin-top: 2px;
            font-weight: 500;
        }
        .stat-card .stat-link {
            font-size: 11px;
            color: #1f5b8a;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin-top: 4px;
            font-weight: 600;
        }
        .stat-card .stat-link:hover { color: #003366; gap: 6px; }

        .stat-card.blue::after { background: #1f5b8a; }
        .stat-card.green::after { background: #28a745; }
        .stat-card.orange::after { background: #f59e0b; }
        .stat-card.red::after { background: #dc3545; }
        .stat-card.purple::after { background: #6f42c1; }
        .stat-card.cyan::after { background: #17a2b8; }
        .stat-card.pink::after { background: #e83e8c; }
        .stat-card.teal::after { background: #20c997; }
        .stat-card.gold::after { background: #f1c40f; }
        .stat-card.indigo::after { background: #4f46e5; }

        /* ============================================
           SECTION TITLE
           ============================================ */
        .section-title {
            font-size: 16px;
            font-weight: 700;
            color: #0f1a2e;
            margin: 20px 0 12px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .section-title i { color: #1f5b8a; font-size: 18px; }
        .section-title .sub {
            font-size: 12px;
            font-weight: 400;
            color: #6c7a8a;
        }

        /* ============================================
           CATEGORY CARDS
           ============================================ */
        .category-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 14px;
            margin-top: 10px;
        }
        .category-card {
            background: #fff;
            padding: 20px 16px;
            border-radius: 12px;
            border: 1px solid #e4edf6;
            text-align: center;
            text-decoration: none;
            color: #0f1a2e;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
        }
        .category-card:hover {
            transform: translateY(-4px);
            border-color: #1f5b8a;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            background: #f8faff;
        }
        .category-card .card-icon {
            font-size: 32px;
            color: #1f5b8a;
            background: rgba(31, 91, 138, 0.08);
            padding: 12px;
            border-radius: 12px;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .category-card h4 {
            font-size: 15px;
            font-weight: 700;
            color: #0f1a2e;
            margin-top: 4px;
        }
        .category-card p {
            font-size: 12px;
            color: #6c7a8a;
            margin: 0;
        }
        .category-card .card-count {
            font-size: 11px;
            color: #1f5b8a;
            font-weight: 600;
            background: #e8f4ff;
            padding: 2px 12px;
            border-radius: 20px;
            margin-top: 4px;
        }

        /* ============================================
           RESULT GRID
           ============================================ */
        .result-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-bottom: 18px;
        }
        .result-card {
            background: #fff;
            border-radius: 10px;
            border: 1px solid #e4edf6;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
        }
        .result-card:hover {
            box-shadow: 0 4px 18px rgba(0, 0, 0, 0.08);
            transform: translateY(-3px);
        }
        .result-card .result-header {
            padding: 10px 14px;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
            font-weight: 700;
            color: #fff;
        }
        .result-card .result-header.vx { background: linear-gradient(135deg, #003366, #1f5b8a); }
        .result-card .result-header.hs { background: linear-gradient(135deg, #6b1a1a, #a83232); }
        .result-card .result-header i { font-size: 20px; }
        .result-card .result-body {
            padding: 10px 14px;
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 8px;
        }
        .result-card .result-body .r-item {
            text-align: center;
            padding: 4px;
            background: #f8f9fa;
            border-radius: 6px;
        }
        .result-card .result-body .r-item .r-num {
            font-size: 22px;
            font-weight: 800;
            color: #003366;
        }
        .result-card .result-body .r-item .r-label {
            font-size: 10px;
            color: #6c7a8a;
            font-weight: 500;
        }
        .result-card .result-body .r-item .r-link {
            font-size: 10px;
            color: #1f5b8a;
            text-decoration: none;
            font-weight: 600;
            display: block;
            margin-top: 2px;
        }

        /* ============================================
           QUICK ACTIONS
           ============================================ */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 8px;
            margin-bottom: 20px;
        }
        .quick-action {
            background: #fff;
            padding: 12px 10px;
            border-radius: 8px;
            border: 1px solid #e4edf6;
            text-align: center;
            text-decoration: none;
            color: #0f1a2e;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
        }
        .quick-action:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            border-color: #1f5b8a;
            background: #f8faff;
        }
        .quick-action .icon { font-size: 24px; }
        .quick-action .label { font-size: 11px; font-weight: 600; }

        /* ============================================
           TWO COLUMN WIDGETS
           ============================================ */
        .two-column {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 18px;
            margin-bottom: 20px;
        }
        @media (max-width: 1024px) { .two-column { grid-template-columns: 1fr; } }

        .widget {
            background: #fff;
            border-radius: 10px;
            border: 1px solid #e4edf6;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }
        .widget-header {
            padding: 10px 16px;
            border-bottom: 1px solid #e4edf6;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fafbfc;
        }
        .widget-header h4 {
            font-size: 14px;
            font-weight: 700;
            color: #0f1a2e;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .widget-header h4 i { color: #1f5b8a; font-size: 15px; }
        .widget-header a {
            font-size: 11px;
            color: #1f5b8a;
            text-decoration: none;
            font-weight: 600;
        }
        .widget-body { padding: 10px 14px; }

        .student-list .student-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 6px 0;
            border-bottom: 1px solid #f0f2f5;
        }
        .student-list .student-item:last-child { border-bottom: none; }
        .student-list .student-item .avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #e4edf6;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            color: #003366;
            font-size: 13px;
            flex-shrink: 0;
        }
        .student-list .student-item .avatar img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
        }
        .student-list .student-item .info { flex: 1; }
        .student-list .student-item .info .name {
            font-size: 14px;
            font-weight: 600;
            color: #0f1a2e;
        }
        .student-list .student-item .info .class {
            font-size: 11px;
            color: #6c7a8a;
        }
        .student-list .student-item .badge {
            font-size: 9px;
            background: #e8f4ff;
            color: #1f5b8a;
            padding: 1px 8px;
            border-radius: 20px;
            font-weight: 600;
        }

        .birthday-list .birthday-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 5px 0;
            border-bottom: 1px solid #f0f2f5;
        }
        .birthday-list .birthday-item:last-child { border-bottom: none; }
        .birthday-list .birthday-item .cake { font-size: 20px; }
        .birthday-list .birthday-item .info .name {
            font-size: 14px;
            font-weight: 600;
            color: #0f1a2e;
        }
        .birthday-list .birthday-item .info .age {
            font-size: 11px;
            color: #6c7a8a;
        }
        .birthday-list .birthday-item .today {
            font-size: 9px;
            background: #28a745;
            color: #fff;
            padding: 1px 8px;
            border-radius: 20px;
            font-weight: 600;
        }

        .notice-list .notice-item {
            padding: 6px 10px;
            border-bottom: 1px solid #f0f2f5;
            cursor: pointer;
            transition: all 0.2s ease;
            border-radius: 4px;
        }
        .notice-list .notice-item:last-child { border-bottom: none; }
        .notice-list .notice-item:hover {
            background: #e8f4ff;
            transform: translateX(4px);
        }
        .notice-list .notice-item .title {
            font-size: 13px;
            font-weight: 600;
            color: #0f1a2e;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .notice-list .notice-item .title i {
            color: #1f5b8a;
            font-size: 12px;
            opacity: 0.6;
        }
        .notice-list .notice-item .meta {
            font-size: 11px;
            color: #6c7a8a;
            display: flex;
            gap: 12px;
            margin-top: 2px;
            align-items: center;
        }

        /* ============================================
           DASHBOARD FOOTER
           ============================================ */
        .dashboard-footer {
            margin-top: 20px;
            text-align: center;
            color: #6c7a8a;
            font-size: 11px;
            padding: 14px;
            border-top: 1px solid #e4edf6;
        }
        .dashboard-footer i { color: #1f5b8a; }

        /* ============================================
           CHANGE PASSWORD PAGE
           ============================================ */
        .password-card {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            border: 1px solid #e4edf6;
            max-width: 450px;
            margin: 0 auto;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .password-card .card-icon {
            font-size: 48px;
            color: #1f5b8a;
            text-align: center;
            margin-bottom: 15px;
        }
        .password-card h4 {
            text-align: center;
            font-size: 20px;
            color: #003366;
            margin-bottom: 5px;
        }
        .password-card p {
            text-align: center;
            color: #6c7a8a;
            font-size: 14px;
            margin-bottom: 20px;
        }
        .password-card .form-group {
            margin-bottom: 15px;
        }
        .password-card .form-group label {
            display: block;
            font-weight: 600;
            font-size: 13px;
            color: #1a3b55;
            margin-bottom: 5px;
        }
        .password-card .form-group input {
            width: 100%;
            padding: 10px 14px;
            border: 2px solid #e4edf6;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .password-card .form-group input:focus {
            outline: none;
            border-color: #1f5b8a;
            box-shadow: 0 0 0 3px rgba(31,91,138,0.1);
        }
        .password-card .btn-update {
            width: 100%;
            padding: 12px;
            background: #4f46e5;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .password-card .btn-update:hover {
            background: #4338ca;
            transform: translateY(-2px);
        }

        /* ============================================
           PROMOTION FLOW - NEW CARDS
           ============================================ */
        .promotion-flow {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 16px;
            margin-bottom: 20px;
        }
        .promotion-step {
            background: #fff;
            border-radius: 12px;
            border: 1px solid #e4edf6;
            padding: 18px 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .promotion-step:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        }
        .promotion-step .step-icon {
            font-size: 28px;
            color: #1f5b8a;
            margin-bottom: 8px;
        }
        .promotion-step h4 {
            font-size: 16px;
            font-weight: 700;
            color: #003366;
            margin-bottom: 4px;
        }
        .promotion-step p {
            font-size: 13px;
            color: #6c7a8a;
            margin-bottom: 10px;
        }
        .promotion-step .btn-step {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 16px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 12px;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        .promotion-step .btn-step:hover {
            transform: translateY(-2px);
        }
        .btn-promote { background: #28a745; color: #fff; }
        .btn-promote:hover { background: #218838; color: #fff; }

        /* ============================================
           RESPONSIVE
           ============================================ */
        @media (max-width: 1024px) {
            .sidebar {
                position: fixed;
                left: -270px;
                top: 0;
                height: 100vh;
                width: 260px;
                border-radius: 0;
                z-index: 999;
                transition: left 0.3s ease;
                padding-top: 0;
                margin-top: 0;
                box-shadow: none;
            }
            .sidebar.open { left: 0; box-shadow: 4px 0 30px rgba(0, 0, 0, 0.3); }
            .sidebar-overlay.active { display: block; }
            .sidebar-toggle { display: flex; }
            .main-content { padding: 10px 12px 16px 12px; }
            .top-header .greeting h2 { font-size: 18px; }
            .stats-grid { grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); }
            .stat-card .stat-number { font-size: 22px; }
            .category-cards { grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); }
            .result-grid { grid-template-columns: 1fr; }
        }

        @media (max-width: 768px) {
            .top-header { flex-direction: column; text-align: center; padding: 10px 12px; }
            .top-header .date-time { text-align: center; width: 100%; }
            .session-banner { flex-direction: column; text-align: center; }
            .session-banner .session-actions { justify-content: center; }
            .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
            .stat-card { padding: 10px 12px; }
            .stat-card .stat-number { font-size: 18px; }
            .stat-card .stat-label { font-size: 11px; }
            .quick-actions { grid-template-columns: repeat(3, 1fr); }
            .result-card .result-body { grid-template-columns: 1fr 1fr; }
            .category-cards { grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); }
            .two-column { grid-template-columns: 1fr; }
            .promotion-flow { grid-template-columns: 1fr 1fr; }
        }

        @media (max-width: 480px) {
            .stats-grid { grid-template-columns: 1fr 1fr; }
            .quick-actions { grid-template-columns: repeat(2, 1fr); }
            .stat-card .stat-number { font-size: 16px; }
            .result-card .result-body { grid-template-columns: 1fr; }
            .result-card .result-body .r-item .r-num { font-size: 18px; }
            .top-header .greeting h2 { font-size: 15px; }
            .top-header .date-time .time { font-size: 15px; }
            .category-cards { grid-template-columns: 1fr 1fr; }
            .category-card { padding: 14px 10px; }
            .category-card .card-icon { font-size: 24px; width: 48px; height: 48px; }
            .category-card h4 { font-size: 13px; }
            .promotion-flow { grid-template-columns: 1fr; }
        }

        /* ============================================
           PRINT STYLES
           ============================================ */
        @media print {
            .sidebar, .sidebar-toggle, .sidebar-overlay,
            .top-header .date-time, .session-banner .session-actions,
            .quick-actions, .category-cards, .result-grid,
            .dashboard-footer, .no-print { display: none !important; }
            .main-content { padding: 0; }
            .top-header { box-shadow: none; border: 1px solid #ddd; }
            .stats-grid { grid-template-columns: repeat(4, 1fr); }
            .stat-card { border: 1px solid #ddd; }
            .widget { border: 1px solid #ddd; break-inside: avoid; }
        }

        /* ============================================
           ALERT MESSAGES
           ============================================ */
        .alert {
            padding: 12px 18px;
            border-radius: 10px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 600;
            animation: slideDown 0.4s ease;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            background: #f8f9fa;
            border-radius: 12px;
            border: 2px dashed #d0dbe8;
        }
        .empty-state i { font-size: 40px; color: #003366; opacity: 0.2; }
        .empty-state h3 { color: #003366; margin-top: 12px; font-size: 18px; }
        .empty-state p { color: #6c7a8a; font-size: 13px; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<!-- ===== SIDEBAR OVERLAY ===== -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- ===== SIDEBAR TOGGLE ===== -->
<button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</button>

<!-- ===== SIDEBAR ===== -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-text">
            <i class="fas fa-school"></i> SchoolMS
        </div>
        <div class="logo-sub">School Management System</div>
    </div>

    <div class="sidebar-user">
        <div class="user-name">
            <i class="fas fa-user-circle"></i>
            <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
        </div>
        <div class="user-role">
            <i class="fas fa-shield-alt"></i> Administrator
        </div>
    </div>

    <div class="sidebar-menu-wrap">
        <!-- ===== MAIN ===== -->
        <div class="sidebar-label"><i class="fas fa-th-large"></i> Main</div>
        <ul class="sidebar-menu">
            <li><a href="?page=dashboard" class="<?php echo $page == 'dashboard' ? 'active' : ''; ?>"><i class="fas fa-th-large"></i> Dashboard</a></li>
        </ul>

        <!-- One entry per module. A module whose own page already links all its parts opens that page directly;
             the others open a short card list of their separate pages. -->
        <div class="sidebar-label"><i class="fas fa-cogs"></i> Settings</div>
        <ul class="sidebar-menu">
            <li><a href="?page=settings" class="<?php echo $page == 'settings' ? 'active' : ''; ?>"><i class="fas fa-cogs"></i> School &amp; Other Settings</a></li>
        </ul>

        <div class="sidebar-label"><i class="fas fa-school"></i> Academic</div>
        <ul class="sidebar-menu">
            <li><a href="?page=academic" class="<?php echo $page == 'academic' ? 'active' : ''; ?>"><i class="fas fa-school"></i> Academic Setup</a></li>
        </ul>

        <!-- ===== STUDENTS ===== -->
        <div class="sidebar-label"><i class="fas fa-users"></i> Students</div>
        <ul class="sidebar-menu">
            <li><a href="students.php"><i class="fas fa-user-graduate"></i> All Students</a></li>
            <li><a href="houses.php"><i class="fas fa-shield-halved"></i> Houses</a></li>
        </ul>

        <!-- ===== ADMISSION ===== -->
        <div class="sidebar-label"><i class="fas fa-file-signature"></i> Admission</div>
        <ul class="sidebar-menu">
            <li><a href="?page=admission" class="<?php echo $page == 'admission' ? 'active' : ''; ?>">
                <i class="fas fa-file-signature"></i> Online Admission
                <?php if($count_admission_pending > 0): ?>
                <span class="sidebar-badge orange"><?php echo $count_admission_pending; ?></span>
                <?php endif; ?>
            </a></li>
        </ul>

        <!-- ===== STAFF ===== -->
        <div class="sidebar-label"><i class="fas fa-user-tie"></i> Staff</div>
        <ul class="sidebar-menu">
            <li><a href="staff.php"><i class="fas fa-user-tie"></i> All Staff</a></li>
        </ul>

        <!-- ===== ATTENDANCE ===== -->
        <div class="sidebar-label"><i class="fas fa-user-check"></i> Attendance</div>
        <ul class="sidebar-menu">
            <li><a href="?page=attendance" class="<?php echo $page == 'attendance' ? 'active' : ''; ?>"><i class="fas fa-user-check"></i> Attendance</a></li>
        </ul>

        <!-- ===== ROUTINE ===== -->
        <div class="sidebar-label"><i class="fas fa-clock"></i> Routine</div>
        <ul class="sidebar-menu">
            <li><a href="?page=routine" class="<?php echo $page == 'routine' ? 'active' : ''; ?>"><i class="fas fa-clock"></i> Routine</a></li>
        </ul>

        <!-- ===== EXAMS V-X ===== -->
        <div class="sidebar-label"><i class="fas fa-pencil-alt"></i> Exams (V-X)</div>
        <ul class="sidebar-menu">
            <li><a href="?page=pup" class="<?php echo $page == 'pup' ? 'active' : ''; ?>"><i class="fas fa-child"></i> Primary &amp; Upper Primary</a></li>
            <li><a href="?page=sec" class="<?php echo $page == 'sec' ? 'active' : ''; ?>"><i class="fas fa-file-signature"></i> Secondary (IX-X)</a></li>
        </ul>

        <!-- ===== HS (XI-XII) ===== -->
        <div class="sidebar-label"><i class="fas fa-university"></i> HS (XI-XII)</div>
        <ul class="sidebar-menu">
            <li><a href="?page=hs" class="<?php echo $page == 'hs' ? 'active' : ''; ?>"><i class="fas fa-university"></i> HS Exams</a></li>
        </ul>

        <!-- ===== EXAM CONDUCT ===== -->
        <div class="sidebar-label"><i class="fas fa-clipboard-check"></i> Exam Conduct</div>
        <ul class="sidebar-menu">
            <li><a href="?page=exam_conduct" class="<?php echo $page == 'exam_conduct' ? 'active' : ''; ?>"><i class="fas fa-chair"></i> Seating &amp; Duty</a></li>
        </ul>

        <!-- ===== HPRC ===== -->
        <div class="sidebar-label"><i class="fas fa-brain"></i> HPRC</div>
        <ul class="sidebar-menu">
            <li><a href="?page=hprc" class="<?php echo $page == 'hprc' ? 'active' : ''; ?>"><i class="fas fa-brain"></i> HPRC Entry</a></li>
        </ul>

        <!-- ===== FEES ===== -->
        <div class="sidebar-label"><i class="fas fa-money-bill-wave"></i> Fees</div>
        <ul class="sidebar-menu">
            <li><a href="?page=fees" class="<?php echo $page == 'fees' ? 'active' : ''; ?>"><i class="fas fa-money-bill-wave"></i> Fee Management</a></li>
        </ul>

        <!-- ===== ACCOUNTS ===== -->
        <div class="sidebar-label"><i class="fas fa-university"></i> Accounts</div>
        <ul class="sidebar-menu">
            <li><a href="?page=accounts" class="<?php echo $page == 'accounts' ? 'active' : ''; ?>"><i class="fas fa-university"></i> Accounts</a></li>
        </ul>

        <!-- ===== LIBRARY ===== -->
        <div class="sidebar-label"><i class="fas fa-book-reader"></i> Library</div>
        <ul class="sidebar-menu">
            <li><a href="?page=library" class="<?php echo $page == 'library' ? 'active' : ''; ?>">
                <i class="fas fa-book"></i> Library Management
                <?php if($lib_overdue_count > 0): ?>
                <span class="sidebar-badge"><?php echo $lib_overdue_count; ?></span>
                <?php endif; ?>
            </a></li>
        </ul>

        <!-- ===== CERTIFICATES & CARDS ===== -->
        <div class="sidebar-label"><i class="fas fa-id-card"></i> Certificates &amp; Cards</div>
        <ul class="sidebar-menu">
            <li><a href="?page=cards" class="<?php echo $page == 'cards' ? 'active' : ''; ?>"><i class="fas fa-id-card"></i> ID / Admit / Certificate</a></li>
        </ul>

        <!-- year-end work: the merit list sits with each exam section, and Promotion links its history -->
        <div class="sidebar-label"><i class="fas fa-trophy"></i> Year End</div>
        <ul class="sidebar-menu">
            <li><a href="promotion.php"><i class="fas fa-level-up-alt"></i> Promotion</a></li>
            <li><a href="pass_out_students.php"><i class="fas fa-graduation-cap"></i> Pass Out</a></li>
        </ul>

        <!-- ===== REPORTS ===== -->
        <div class="sidebar-label"><i class="fas fa-chart-bar"></i> Reports</div>
        <ul class="sidebar-menu">
            <li><a href="?page=reports" class="<?php echo $page == 'reports' ? 'active' : ''; ?>"><i class="fas fa-chart-pie"></i> Reports &amp; Analytics</a></li>
        </ul>

        <!-- ===== WEBSITE & CONTENT ===== -->
        <div class="sidebar-label"><i class="fas fa-bullhorn"></i> Website &amp; Content</div>
        <ul class="sidebar-menu">
            <li><a href="?page=content" class="<?php echo $page == 'content' ? 'active' : ''; ?>">
                <i class="fas fa-bullhorn"></i> Notices, Gallery &amp; More
                <?php if(($count_new_queries ?? 0) > 0): ?>
                <span class="sidebar-badge orange"><?php echo $count_new_queries; ?></span>
                <?php endif; ?>
            </a></li>
        </ul>

        <div class="sidebar-label"><i class="fas fa-cogs"></i> System</div>
        <ul class="sidebar-menu">
            <li><a href="backup_now.php"><i class="fas fa-database"></i> Backup</a></li>
            <li><a href="view_logs.php"><i class="fas fa-history"></i> Activity Logs</a></li>
            <li><a href="../index.php" target="_blank"><i class="fas fa-globe"></i> Website</a></li>
        </ul>

    </div>

    <div class="sidebar-footer">
        <a href="?page=change_password"><i class="fas fa-key"></i> Change Password</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</aside>

<!-- ===== MAIN CONTENT ===== -->
<main class="main-content">

    <div class="dash-topbar-sticky">
    <!-- ===== GLOBAL SEARCH (TOP OF DASHBOARD) ===== -->
    <div class="dash-search-wrap">
        <div class="dash-search-box">
            <i class="fas fa-search"></i>
            <input type="text" id="dashSearchInput" placeholder="Search Student, Staff, Subject, Exam, Notice..." autocomplete="off">
            <span class="dash-search-kbd"><i class="fas fa-bolt"></i> Quick Search</span>
            <div id="dashSearchResults" class="dash-search-dropdown"></div>
        </div>
    </div>

    <!-- ===== TOP HEADER ===== -->
    <div class="top-header">
        <div class="greeting">
            <h2><i class="fas fa-wave-square"></i> Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>!</h2>
            <p><i class="fas fa-shield-alt" style="color:#1f5b8a;"></i> Manage your school from one dashboard</p>
        </div>
        <div class="date-time">
            <div class="date"><i class="far fa-calendar-alt"></i> <?php echo date('d M Y'); ?></div>
            <div class="time" id="currentTime"><?php echo date('h:i A'); ?></div>
        </div>
    </div>
    </div>

    <!-- ============================================================ -->
    <!-- DASHBOARD CONTENT                                             -->
    <!-- ============================================================ -->
    <?php if($page == 'dashboard'): ?>

    <!-- Session Banner -->
    <div class="session-banner">
        <div class="session-info">
            <span>
                <span class="label"><i class="fas fa-calendar-check"></i> Active Session</span><br>
                <span class="value"><?php echo $active_session['session_name'] ?? 'Not Set'; ?></span>
            </span>
            <span class="badge"><?php echo $active_session ? '🟢 Running' : '🔴 Not Set'; ?></span>
        </div>
        <div class="session-actions">
            <a href="sessions.php"><i class="fas fa-calendar-alt"></i> Manage Sessions</a>
            <a href="backup_now.php"><i class="fas fa-database"></i> Backup All Data</a>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="stats-grid">
        <div class="stat-card blue">
            <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
            <div class="stat-number"><?php echo $count_student['total']; ?></div>
            <div class="stat-label">Total Students</div>
            <a href="students.php" class="stat-link">View All →</a>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><i class="fas fa-user-tie"></i></div>
            <div class="stat-number"><?php echo $count_staff['total']; ?></div>
            <div class="stat-label">Total Staff</div>
            <a href="staff.php" class="stat-link">View All →</a>
        </div>
        <div class="stat-card orange">
            <div class="stat-icon"><i class="fas fa-book"></i></div>
            <div class="stat-number"><?php echo $count_subject['total']; ?></div>
            <div class="stat-label">Total Subjects</div>
            <a href="?page=academic" class="stat-link">View All →</a>
        </div>
        <div class="stat-card purple">
            <div class="stat-icon"><i class="fas fa-chalkboard"></i></div>
            <div class="stat-number"><?php echo $count_class['total']; ?></div>
            <div class="stat-label">Total Classes</div>
            <a href="?page=academic" class="stat-link">View All →</a>
        </div>
        <div class="stat-card cyan">
            <div class="stat-icon"><i class="fas fa-layer-group"></i></div>
            <div class="stat-number"><?php echo $count_section['total']; ?></div>
            <div class="stat-label">Total Sections</div>
            <a href="?page=academic" class="stat-link">View All →</a>
        </div>
        <div class="stat-card pink">
            <div class="stat-icon"><i class="fas fa-file-signature"></i></div>
            <div class="stat-number"><?php echo $count_exam['total']; ?></div>
            <div class="stat-label">Total Exams (V-X)</div>
            <a href="?page=pup" class="stat-link">View All →</a>
        </div>
        <div class="stat-card red">
            <div class="stat-icon"><i class="fas fa-university"></i></div>
            <div class="stat-number"><?php echo $count_hs_exams; ?></div>
            <div class="stat-label">Total HS Exams</div>
            <a href="?page=hs" class="stat-link">View All →</a>
        </div>
        <div class="stat-card teal">
            <div class="stat-icon"><i class="fas fa-exchange-alt"></i></div>
            <div class="stat-number"><?php echo $today_provisional; ?></div>
            <div class="stat-label">Provisional Today</div>
            <a href="provisional_routine.php" class="stat-link">View →</a>
        </div>
        <div class="stat-card indigo">
            <div class="stat-icon"><i class="fas fa-link"></i></div>
            <div class="stat-number"><?php echo $count_class_subjects['total'] ?? 0; ?></div>
            <div class="stat-label">Class Subjects</div>
            <a href="?page=academic" class="stat-link">View →</a>
        </div>
        <div class="stat-card gold">
            <div class="stat-icon"><i class="fas fa-user-check"></i></div>
            <div class="stat-number"><?php echo $present_att; ?>/<?php echo $total_att; ?></div>
            <div class="stat-label">Today's Attendance (<?php echo $attendance_percent; ?>%)</div>
            <a href="student_attendance.php" class="stat-link">Mark Today →</a>
        </div>
        <div class="stat-card gold" style="border-left:4px solid #2ecc71;">
            <div class="stat-icon"><i class="fas fa-hand-holding-usd"></i></div>
            <div class="stat-number">₹<?php echo number_format($today_collected, 2); ?></div>
            <div class="stat-label">Collected Today</div>
            <a href="collect_fee.php" class="stat-link">Collect Fee →</a>
        </div>
        <div class="stat-card gold" style="border-left:4px solid #e74c3c;">
            <div class="stat-icon"><i class="fas fa-clock"></i></div>
            <div class="stat-number">₹<?php echo number_format($pending_amount, 2); ?></div>
            <div class="stat-label">Not Paid Yet</div>
            <a href="fee_report.php?type=dues" class="stat-link">Who has not paid →</a>
        </div>
        <?php if ((int)$acc_open['n'] > 0): ?>
        <div class="stat-card gold" style="border-left:4px solid #2f62d6;">
            <div class="stat-icon"><i class="fas fa-university"></i></div>
            <div class="stat-number">₹<?php echo number_format($acc_cash + $acc_bank, 2); ?></div>
            <div class="stat-label">In the accounts — cash ₹<?php echo number_format($acc_cash, 2); ?> · bank ₹<?php echo number_format($acc_bank, 2); ?></div>
            <a href="acc_report.php?type=balances" class="stat-link">Balances →</a>
        </div>
        <?php endif; ?>
        <div class="stat-card gold" style="border-left:4px solid #e67e22;">
            <div class="stat-icon"><i class="fas fa-file-signature"></i></div>
            <div class="stat-number"><?php echo $count_admission_pending; ?></div>
            <div class="stat-label">Pending Admissions (<?php echo $count_admission_total; ?> Total)</div>
            <a href="admission_applications.php" class="stat-link">Review →</a>
        </div>
    </div>

    <!-- ===== YEAR END ===== -->
    <div class="section-title">
        <i class="fas fa-level-up-alt"></i> Year End
        <span class="sub">— merit lists, promotion and pass out, class by class</span>
    </div>

    <div class="promotion-flow">
        <div class="promotion-step">
            <div class="step-icon"><i class="fas fa-tasks"></i></div>
            <h4><?php echo htmlspecialchars($active_session['session_name'] ?? 'No active session'); ?> → <?php echo htmlspecialchars($year_end['next'] ?: 'next session'); ?></h4>
            <p>Merit lists: <b><?php echo $year_end['merit']; ?></b> of <?php echo $year_end['classes']; ?> classes · Promoted: <b><?php echo $year_end['promoted']; ?></b> of <?php echo $year_end['classes']; ?><?php echo $year_end['next'] ? '' : ' · the next session is not created yet'; ?></p>
            <a href="promotion.php" class="btn-step btn-promote"><i class="fas fa-level-up-alt"></i> Promote Students</a>
        </div>
    </div>

    <!-- Result Section -->
    <div class="section-title">
        <i class="fas fa-graduation-cap"></i> Results & Exams
        <span class="sub">— Quick access to examination modules</span>
    </div>
    <div class="result-grid">
        <div class="result-card">
            <div class="result-header vx">
                <i class="fas fa-child"></i>
                <span>Primary &amp; Upper Primary (I-VIII)</span>
                <span style="font-size:11px; font-weight:400; opacity:0.8; margin-left:auto;">
                    <i class="fas fa-user-graduate"></i> <?php echo $count_student_pup; ?> Students
                </span>
            </div>
            <div class="result-body">
                <div class="r-item"><div class="r-num"><?php echo $count_exam['total']; ?></div><div class="r-label">Exams</div><a href="?page=pup" class="r-link">Manage →</a></div>
                <div class="r-item"><div class="r-num">📝</div><div class="r-label">Marks Entry</div><a href="marks_entry.php?section=pup" class="r-link">Enter →</a></div>
                <div class="r-item"><div class="r-num">📊</div><div class="r-label">Tabulation</div><a href="tabulation_sheet.php?section=pup" class="r-link">View →</a></div>
            </div>
        </div>
        <div class="result-card">
            <div class="result-header vx">
                <i class="fas fa-file-signature"></i>
                <span>Secondary (IX-X)</span>
                <span style="font-size:11px; font-weight:400; opacity:0.8; margin-left:auto;">
                    <i class="fas fa-user-graduate"></i> <?php echo $count_student_sec; ?> Students
                </span>
            </div>
            <div class="result-body">
                <div class="r-item"><div class="r-num"><?php echo $count_exam['total']; ?></div><div class="r-label">Exams</div><a href="?page=sec" class="r-link">Manage →</a></div>
                <div class="r-item"><div class="r-num">📝</div><div class="r-label">Marks Entry</div><a href="marks_entry.php?section=sec" class="r-link">Enter →</a></div>
                <div class="r-item"><div class="r-num">🎓</div><div class="r-label">Madhyamik Regd.</div><a href="secondary_registration.php" class="r-link">Open →</a></div>
            </div>
        </div>
        <div class="result-card">
            <div class="result-header hs">
                <i class="fas fa-university"></i>
                <span>Class XI - XII (HS)</span>
                <span style="font-size:11px; font-weight:400; opacity:0.8; margin-left:auto;">
                    <i class="fas fa-user-graduate"></i> <?php echo $count_student_hs['total'] ?? 0; ?> Students
                </span>
            </div>
            <div class="result-body">
                <div class="r-item"><div class="r-num"><?php echo $count_hs_exams; ?></div><div class="r-label">HS Exams</div><a href="?page=hs" class="r-link">Manage →</a></div>
                <div class="r-item"><div class="r-num">📝</div><div class="r-label">HS Marks Entry</div><a href="hs_marks_entry.php" class="r-link">Enter →</a></div>
                <div class="r-item"><div class="r-num">📊</div><div class="r-label">HS Tabulation</div><a href="hs_tabulation.php" class="r-link">View →</a></div>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="section-title">
        <i class="fas fa-bolt"></i> Quick Actions
        <span class="sub">— Frequently used features</span>
    </div>
    <div class="quick-actions">
        <a href="add_student.php" class="quick-action"><span class="icon">👨‍🎓</span><span class="label">Add Student</span></a>
        <a href="add_staff.php" class="quick-action"><span class="icon">👨‍🏫</span><span class="label">Add Staff</span></a>
        <a href="routine_entry.php" class="quick-action"><span class="icon">📅</span><span class="label">Routine Entry</span></a>
        <a href="bulk_grace_marks.php" class="quick-action"><span class="icon">❤️</span><span class="label">Grace Marks</span></a>
        <a href="annual_result.php" class="quick-action"><span class="icon">📊</span><span class="label">Annual Result</span></a>
        <a href="add_notice.php" class="quick-action"><span class="icon">📢</span><span class="label">Add Notice</span></a>
    </div>

    <!-- Two Column Widgets -->
    <div class="section-title">
        <i class="fas fa-info-circle"></i> Recent Activity
        <span class="sub">— Latest updates</span>
    </div>
    <div class="two-column">
        <div class="widget">
            <div class="widget-header">
                <h4><i class="fas fa-user-graduate"></i> Recently Added Students</h4>
                <a href="students.php">View All →</a>
            </div>
            <div class="widget-body student-list">
                <?php if(mysqli_num_rows($recent_students) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($recent_students)): ?>
                    <div class="student-item">
                        <div class="avatar">
                            <?php if(!empty($row['photo'])): ?>
                            <img src="../uploads/students/<?php echo htmlspecialchars($row['photo'], ENT_QUOTES, 'UTF-8'); ?>" alt="Photo">
                            <?php else: ?>
                            <?php echo htmlspecialchars(substr($row['student_name'], 0, 1)); ?>
                            <?php endif; ?>
                        </div>
                        <div class="info">
                            <div class="name"><?php echo htmlspecialchars($row['student_name']); ?></div>
                            <div class="class"><?php echo htmlspecialchars($row['class_name'] ?? 'N/A'); ?> - <?php echo htmlspecialchars($row['section_name'] ?? ''); ?></div>
                        </div>
                        <span class="badge"><?php echo date('d M', strtotime($row['created_at'])); ?></span>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div style="text-align:center; padding:14px; color:#6c7a8a;">No students added yet</div>
                <?php endif; ?>
            </div>
        </div>

        <div>
            <div class="widget" style="margin-bottom:14px;">
                <div class="widget-header">
                    <h4><i class="fas fa-birthday-cake" style="color:#f59e0b;"></i> Today's Student Birthdays</h4>
                    <span style="font-size:11px; color:#6c7a8a;"><?php echo date('d M'); ?></span>
                </div>
                <div class="widget-body birthday-list">
                    <?php if(mysqli_num_rows($birthdays) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($birthdays)): ?>
                        <div class="birthday-item">
                            <span class="cake">🎂</span>
                            <div class="info">
                                <div class="name"><?php echo htmlspecialchars($row['student_name']); ?></div>
                                <div class="age"><?php echo date('Y') - date('Y', strtotime($row['dob'])); ?> years</div>
                            </div>
                            <span class="today">Today</span>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="text-align:center; padding:14px; color:#6c7a8a;">No student birthdays today</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="widget" style="margin-bottom:14px;">
                <div class="widget-header">
                    <h4><i class="fas fa-birthday-cake" style="color:#8b5cf6;"></i> Today's Staff Birthdays</h4>
                    <span style="font-size:11px; color:#6c7a8a;"><?php echo date('d M'); ?></span>
                </div>
                <div class="widget-body birthday-list">
                    <?php if(mysqli_num_rows($staff_birthdays) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($staff_birthdays)): ?>
                        <div class="birthday-item">
                            <span class="cake">🎂</span>
                            <div class="info">
                                <div class="name"><?php echo htmlspecialchars($row['staff_name']); ?></div>
                                <div class="age"><?php echo date('Y') - date('Y', strtotime($row['date_of_birth'])); ?> years</div>
                            </div>
                            <span class="today">Today</span>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="text-align:center; padding:14px; color:#6c7a8a;">No staff birthdays today</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="widget">
                <div class="widget-header">
                    <h4><i class="fas fa-bullhorn" style="color:#dc3545;"></i> Recent Notices</h4>
                    <a href="notices.php">View All →</a>
                </div>
                <div class="widget-body notice-list">
                    <?php if(mysqli_num_rows($recent_notices) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($recent_notices)): ?>
                        <div class="notice-item" onclick="window.location.href='notices.php'">
                            <div class="title">
                                <i class="fas fa-file-alt"></i>
                                <?php echo htmlspecialchars($row['notice_title']); ?>
                            </div>
                            <div class="meta">
                                <span><i class="far fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($row['publish_date'])); ?></span>
                                <span><i class="far fa-clock"></i> <?php echo date('h:i A', strtotime($row['created_at'])); ?></span>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="text-align:center; padding:14px; color:#6c7a8a;">No notices available</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'academic'): ?>
    <!-- ACADEMIC PAGE -->
    <div class="section-title">
        <i class="fas fa-school"></i> Academic Setup
        <span class="sub">— Manage academic structure</span>
    </div>
    <div class="category-cards">
        <a href="sessions.php" class="category-card"><div class="card-icon"><i class="fas fa-calendar-alt"></i></div><h4>Sessions</h4><p>Manage academic sessions</p></a>
        <a href="classes.php" class="category-card"><div class="card-icon"><i class="fas fa-chalkboard"></i></div><h4>Classes</h4><p>Manage classes</p></a>
        <a href="sections.php" class="category-card"><div class="card-icon"><i class="fas fa-layer-group"></i></div><h4>Sections</h4><p>Manage sections</p></a>
        <a href="subjects.php" class="category-card"><div class="card-icon"><i class="fas fa-book"></i></div><h4>Subjects</h4><p>Manage subjects</p></a>
        <a href="class_subjects.php" class="category-card"><div class="card-icon"><i class="fas fa-link"></i></div><h4>Class Subjects</h4><p>Assign subjects to class</p></a>
        <a href="assign_third_language.php" class="category-card"><div class="card-icon"><i class="fas fa-user-check"></i></div><h4>3rd Language Assign</h4><p>Class-wise Arabic/Sanskrit choice</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'library'): ?>
    <!-- LIBRARY PAGE -->
    <div class="section-title">
        <i class="fas fa-boxes"></i> Stock at a Glance
    </div>
    <div class="stats-grid" style="margin-bottom:10px;">
        <div class="stat-card blue">
            <div class="stat-icon"><i class="fas fa-book"></i></div>
            <div class="stat-number"><?php echo (int)($lib_stock['total_titles'] ?? 0); ?></div>
            <div class="stat-label">Book Titles</div>
            <a href="books.php" class="stat-link">View All →</a>
        </div>
        <div class="stat-card green">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="stat-number"><?php echo (int)($lib_stock['available_copies'] ?? 0); ?></div>
            <div class="stat-label">Copies Available</div>
            <a href="books.php" class="stat-link">View All →</a>
        </div>
        <div class="stat-card orange">
            <div class="stat-icon"><i class="fas fa-people-carry"></i></div>
            <div class="stat-number"><?php echo (int)($lib_stock['issued_copies'] ?? 0); ?></div>
            <div class="stat-label">Currently Issued</div>
            <a href="library_return.php" class="stat-link">View →</a>
        </div>
        <div class="stat-card red">
            <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-number"><?php echo (int)$lib_overdue_count; ?></div>
            <div class="stat-label">Overdue</div>
            <a href="library_return.php?overdue_only=1" class="stat-link">Resolve →</a>
        </div>
    </div>

    <div class="section-title">
        <i class="fas fa-book-reader"></i> Library Management
        <span class="sub">— Books, issues &amp; returns (students &amp; staff both supported)</span>
    </div>
    <div class="category-cards">
        <a href="library_dashboard.php" class="category-card"><div class="card-icon"><i class="fas fa-th-large"></i></div><h4>Library Dashboard</h4><p>Stock, overdue &amp; usage reports</p></a>
        <a href="library_staff_access.php" class="category-card"><div class="card-icon"><i class="fas fa-user-shield"></i></div><h4>Staff Access</h4><p>Who can scan in Teacher Portal</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'exam_conduct'): ?>
    <!-- EXAM CONDUCT PAGE -->
    <div class="section-title">
        <i class="fas fa-clipboard-check"></i> Exam Conduct
        <span class="sub">— Seating plan, rooms & invigilation duty</span>
    </div>
    <div class="category-cards">
        <a href="exam_conduct_dashboard.php" class="category-card"><div class="card-icon"><i class="fas fa-tachometer-alt"></i></div><h4>Overview</h4><p>Exam conduct dashboard</p></a>
        <a href="exam_room_config.php" class="category-card"><div class="card-icon"><i class="fas fa-th"></i></div><h4>Room Config</h4><p>Seat capacity setup</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'content'): ?>
    <!-- WEBSITE & CONTENT PAGE -->
    <div class="section-title">
        <i class="fas fa-bullhorn"></i> Website & Content
        <span class="sub">— Notices, gallery, holidays & messages</span>
    </div>
    <div class="category-cards">
        <a href="notices.php" class="category-card"><div class="card-icon"><i class="fas fa-bullhorn"></i></div><h4>Notices</h4><p>Drafts, and what is on the website now</p><span class="card-count"><?php echo $count_notice['total'] ?? 0; ?></span></a>
        <a href="gallery.php" class="category-card"><div class="card-icon"><i class="fas fa-images"></i></div><h4>Gallery</h4><p>The school's photographs</p></a>
        <a href="holidays.php" class="category-card"><div class="card-icon"><i class="fas fa-umbrella-beach"></i></div><h4>Holidays</h4><p>Year by year — attendance follows this list</p></a>
        <a href="website_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-globe"></i></div><h4>Website</h4><p>Banner, about, contact and links</p></a>
        <a href="contact_queries.php" class="category-card"><div class="card-icon"><i class="fas fa-envelope"></i></div><h4>Messages</h4><p>What people write from the site</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'reports'): ?>
    <!-- REPORTS PAGE -->
    <div class="section-title">
        <i class="fas fa-chart-bar"></i> Reports
        <span class="sub">— Analytics & printable reports</span>
    </div>
    <div class="category-cards">
        <a href="student_statistics.php" class="category-card"><div class="card-icon"><i class="fas fa-chart-pie"></i></div><h4>Student Statistics</h4><p>Class, category, age, places, what is missing</p></a>
        <a href="sibling_report.php" class="category-card"><div class="card-icon"><i class="fas fa-people-roof"></i></div><h4>Brothers &amp; Sisters</h4><p>Families, and the records still to be joined</p></a>
        <a href="student_year_comparison.php" class="category-card"><div class="card-icon"><i class="fas fa-arrows-left-right"></i></div><h4>Year by Year</h4><p>Where each student was, and is now</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'cards'): ?>
    <!-- CERTIFICATES & CARDS PAGE -->
    <div class="section-title">
        <i class="fas fa-id-card"></i> Certificates &amp; Cards
        <span class="sub">— ID cards, admit cards &amp; certificates</span>
    </div>
    <div class="category-cards">
        <a href="idcard_home.php" class="category-card"><div class="card-icon"><i class="fas fa-id-card"></i></div><h4>ID Card Home</h4><p>Overview</p></a>
        <a href="admit_card_home.php" class="category-card"><div class="card-icon"><i class="fas fa-address-card"></i></div><h4>Admit Card Home</h4><p>Overview</p></a>
        <a href="certificate_list.php" class="category-card"><div class="card-icon"><i class="fas fa-list"></i></div><h4>Certificates</h4><p>All issued certificates</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'admission'): ?>
    <!-- ADMISSION PAGE -->
    <div class="section-title">
        <i class="fas fa-file-signature"></i> Online Admission
        <span class="sub">— Manage admission settings & applications</span>
    </div>
    <div class="category-cards">
        <a href="admission_applications.php" class="category-card"><div class="card-icon"><i class="fas fa-list"></i></div><h4>Applications</h4><p>Check, select, waitlist or reject</p><span class="card-count"><?php echo $count_admission_pending; ?> Pending</span></a>
        <a href="admission_merit.php" class="category-card"><div class="card-icon"><i class="fas fa-ranking-star"></i></div><h4>Merit List</h4><p>Class XI by Madhyamik %</p></a>
        <a href="admission_centres.php" class="category-card"><div class="card-icon"><i class="fas fa-store"></i></div><h4>Application Centres</h4><p>Cyber cafés that apply for parents</p></a>
        <a href="admission_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-sliders-h"></i></div><h4>Admission Settings</h4><p>Window, classes, seats, what to give</p></a>
        <a href="../admission.php" target="_blank" class="category-card"><div class="card-icon"><i class="fas fa-globe"></i></div><h4>Public Form</h4><p>View live application form</p></a>
        <a href="../admission_status.php" target="_blank" class="category-card"><div class="card-icon"><i class="fas fa-search"></i></div><h4>Status Check Page</h4><p>Public status lookup page</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'routine'): ?>
    <!-- ROUTINE PAGE -->
    <div class="section-title">
        <i class="fas fa-clock"></i> Routine Management
        <span class="sub">— Manage class routines</span>
    </div>
    <div class="category-cards">
        <a href="routine_builder.php" class="category-card"><div class="card-icon"><i class="fas fa-magic"></i></div><h4>Routine Builder</h4><p>Manual · semi-automatic · automatic</p></a>
        <a href="class_routine.php" class="category-card"><div class="card-icon"><i class="fas fa-table"></i></div><h4>Class Routine</h4><p>View / print, booklet</p></a>
        <a href="daywise_class_routine.php" class="category-card"><div class="card-icon"><i class="fas fa-calendar-day"></i></div><h4>Day-wise Class</h4><p>All sections, one day</p></a>
        <a href="provisional_routine.php" class="category-card"><div class="card-icon"><i class="fas fa-exchange-alt"></i></div><h4>Substitution</h4><p>Cover absent teachers</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'pup'): ?>
    <!-- PRIMARY & UPPER PRIMARY -->
    <div class="section-title">
        <i class="fas fa-child"></i> Primary &amp; Upper Primary
        <span class="sub">— Classes I–VIII</span>
    </div>
    <div class="category-cards">
        <a href="exams.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-clipboard-list"></i></div><h4>Exams</h4><p>Add / edit / publish exams</p><span class="card-count"><?php echo $count_exam['total']; ?></span></a>
        <a href="pass_fail_settings.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-cog"></i></div><h4>Rules &amp; Grades</h4><p>Pass/fail rules, grade bands</p></a>
        <a href="marks_entry.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-edit"></i></div><h4>Marks Entry</h4><p>Subject-wise entry</p></a>
        <a href="bulk_marks_upload.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-file-excel"></i></div><h4>Bulk Upload</h4><p>Excel template upload</p></a>
        <a href="bulk_grace_marks.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-hand-holding-heart"></i></div><h4>Grace Marks</h4><p>Students short of pass marks</p></a>
        <a href="tabulation_sheet.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-table"></i></div><h4>Tabulation</h4><p>One exam · print / Excel</p></a>
        <a href="annual_result.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-award"></i></div><h4>Annual Result</h4><p>All counting exams added up</p></a>
        <a href="report_card.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-id-card"></i></div><h4>Report Card</h4><p>One page per student</p></a>
        <a href="student_merit_ranks.php?section=pup" class="category-card"><div class="card-icon"><i class="fas fa-trophy"></i></div><h4>Merit List</h4><p>Rank of the class for promotion</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'sec'): ?>
    <!-- SECONDARY -->
    <div class="section-title">
        <i class="fas fa-file-signature"></i> Secondary
        <span class="sub">— Classes IX–X</span>
    </div>
    <div class="category-cards">
        <a href="exams.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-clipboard-list"></i></div><h4>Exams</h4><p>Add / edit / publish exams</p><span class="card-count"><?php echo $count_exam['total']; ?></span></a>
        <a href="pass_fail_settings.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-cog"></i></div><h4>Rules &amp; Grades</h4><p>Pass/fail rules, grade bands</p></a>
        <a href="marks_entry.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-edit"></i></div><h4>Marks Entry</h4><p>Subject-wise entry</p></a>
        <a href="bulk_marks_upload.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-file-excel"></i></div><h4>Bulk Upload</h4><p>Excel template upload</p></a>
        <a href="bulk_grace_marks.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-hand-holding-heart"></i></div><h4>Grace Marks</h4><p>Students short of pass marks</p></a>
        <a href="tabulation_sheet.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-table"></i></div><h4>Tabulation</h4><p>One exam · print / Excel</p></a>
        <a href="annual_result.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-award"></i></div><h4>Annual Result</h4><p>All counting exams added up</p></a>
        <a href="report_card.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-id-card"></i></div><h4>Report Card</h4><p>One page per student</p></a>
        <a href="student_merit_ranks.php?section=sec" class="category-card"><div class="card-icon"><i class="fas fa-trophy"></i></div><h4>Merit List</h4><p>Rank of the class for promotion</p></a>
        <a href="secondary_registration.php" class="category-card"><div class="card-icon"><i class="fas fa-id-badge"></i></div><h4>Madhyamik Registration</h4><p>IX-X board registration</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'hs'): ?>
    <!-- HS PAGE -->
    <div class="section-title">
        <i class="fas fa-university"></i> Higher Secondary (XI-XII)
        <span class="sub">— HS Module</span>
    </div>
    <div class="category-cards">
        <a href="hs_exams.php" class="category-card"><div class="card-icon"><i class="fas fa-list"></i></div><h4>Semester Exams</h4><p>Class XI Semester 1 &amp; 2</p><span class="card-count"><?php echo $count_hs_exams; ?></span></a>
        <a href="hs_subjects.php" class="category-card"><div class="card-icon"><i class="fas fa-book-open"></i></div><h4>HS Subject Combination</h4><p>Five or six subjects per student</p></a>
        <a href="hs_marks_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-pencil-alt"></i></div><h4>HS Marks Entry</h4><p>One exam, one subject at a time</p></a>
        <a href="hs_bulk_marks_upload.php" class="category-card"><div class="card-icon"><i class="fas fa-file-excel"></i></div><h4>HS Bulk Upload</h4><p>Excel — one tab per subject</p></a>
        <a href="hs_tabulation.php" class="category-card"><div class="card-icon"><i class="fas fa-table"></i></div><h4>HS Tabulation</h4><p>Semester-wise, best of five</p></a>
        <a href="hs_report_card.php" class="category-card"><div class="card-icon"><i class="fas fa-id-card"></i></div><h4>HS Mark Sheet</h4><p>Class XI mark sheet, A4 landscape</p></a>
        <a href="hs_registration.php" class="category-card"><div class="card-icon"><i class="fas fa-id-card"></i></div><h4>WBCHSE Registration</h4><p>Registration number and year</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'hprc'): ?>
    <!-- HPRC PAGE -->
    <div class="section-title">
        <i class="fas fa-brain"></i> HPRC System
        <span class="sub">— Holistic Progress Report Card</span>
    </div>
    <div class="category-cards">
        <a href="formative_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-cog"></i></div><h4>Formative Full Marks Settings</h4><p>Full marks of each formative part</p></a>
        <a href="hprc_formative_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-tasks"></i></div><h4>Formative</h4><p>Formative entry</p></a>
        <a href="hprc_formative_report.php" class="category-card"><div class="card-icon"><i class="fas fa-file-alt"></i></div><h4>Formative Report</h4><p>View report</p></a>
        <a href="hprc_learning_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-brain"></i></div><h4>Learning</h4><p>Learning entry</p></a>
        <a href="hprc_behavior_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-heart"></i></div><h4>Behavior</h4><p>Behavior entry</p></a>
        <a href="hprc_personality_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-star"></i></div><h4>Personality</h4><p>Personality entry</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'fees'): ?>
    <!-- FEES PAGE -->
    <div class="section-title">
        <i class="fas fa-money-bill-wave"></i> Fee Management
        <span class="sub">— Manage all fees</span>
    </div>
    <div class="category-cards">
        <a href="collect_fee.php" class="category-card"><div class="card-icon"><i class="fas fa-cash-register"></i></div><h4>Collect</h4><p>One student or a whole class</p></a>
        <a href="fee_receipts.php" class="category-card"><div class="card-icon"><i class="fas fa-receipt"></i></div><h4>Receipts</h4><p>Find, give slips, cancel</p></a>
        <a href="fee_report.php" class="category-card"><div class="card-icon"><i class="fas fa-chart-bar"></i></div><h4>Reports</h4><p>Collection, not paid, fee-wise</p></a>
        <a href="fee_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-sliders-h"></i></div><h4>Fee Settings</h4><p>Fees, amounts and the slip</p></a>
        <a href="student_discounts.php" class="category-card"><div class="card-icon"><i class="fas fa-percent"></i></div><h4>Discounts</h4><p>Concessions per student</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'accounts'): ?>
    <!-- ACCOUNTS PAGE -->
    <div class="section-title">
        <i class="fas fa-university"></i> Accounts
        <span class="sub">— Where the money is, what came in and what went out</span>
    </div>
    <div class="category-cards">
        <a href="acc_entry.php" class="category-card"><div class="card-icon"><i class="fas fa-pen"></i></div><h4>New Entry</h4><p>Expense, income, deposit, transfer</p></a>
        <a href="acc_vouchers.php" class="category-card"><div class="card-icon"><i class="fas fa-file-invoice-dollar"></i></div><h4>Vouchers</h4><p>Find, print, cancel</p></a>
        <a href="acc_cashbook.php" class="category-card"><div class="card-icon"><i class="fas fa-book"></i></div><h4>Cash Book</h4><p>Day by day, cash and bank</p></a>
        <a href="acc_report.php" class="category-card"><div class="card-icon"><i class="fas fa-chart-line"></i></div><h4>Reports</h4><p>Balances, statements</p></a>
        <a href="acc_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-sliders-h"></i></div><h4>Account Settings</h4><p>Accounts, heads, options</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'attendance'): ?>
    <!-- ATTENDANCE PAGE -->
    <div class="section-title">
        <i class="fas fa-calendar-check"></i> Attendance System
        <span class="sub">— Manage attendance</span>
    </div>
    <div class="category-cards">
        <a href="student_attendance.php" class="category-card"><div class="card-icon"><i class="fas fa-users"></i></div><h4>Student Attendance</h4><p>Mark student attendance</p></a>
        <a href="teacher_attendance.php" class="category-card"><div class="card-icon"><i class="fas fa-user-tie"></i></div><h4>Teacher Attendance</h4><p>Mark teacher attendance</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'settings'): ?>
    <!-- SCHOOL & OTHER SETTINGS PAGE -->
    <div class="section-title">
        <i class="fas fa-cogs"></i> School &amp; Other Settings
        <span class="sub">— School info, academic &amp; system settings</span>
    </div>
    <div class="category-cards">
        <a href="school_settings.php" class="category-card"><div class="card-icon"><i class="fas fa-school"></i></div><h4>School Settings</h4><p>School info, logo</p></a>
        <a href="user_access.php" class="category-card"><div class="card-icon"><i class="fas fa-user-shield"></i></div><h4>User Access</h4><p>Admin permissions</p></a>
        <a href="whatsapp_send.php" class="category-card"><div class="card-icon"><i class="fab fa-whatsapp"></i></div><h4>WhatsApp Send</h4><p>Bulk message parents</p></a>
    </div>

    <!-- ============================================================ -->
    <?php elseif($page == 'change_password'): ?>
    <!-- CHANGE PASSWORD -->
    <div class="section-title">
        <i class="fas fa-key"></i> Change Password
        <span class="sub">— Update your password</span>
    </div>
    <div class="password-card">
        <div class="card-icon"><i class="fas fa-key"></i></div>
        <h4>Change Password</h4>
        <p>Update your admin password</p>

        <?php if(isset($_SESSION['error'])): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($_SESSION['error'] ?? '', ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?>
        </div>
        <?php endif; ?>

        <?php if(isset($_SESSION['success'])): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($_SESSION['success'] ?? '', ENT_QUOTES, 'UTF-8'); unset($_SESSION['success']); ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="change_password.php">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="current_password" required>
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" required minlength="8">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button type="submit" name="change_pass" class="btn-update">
                <i class="fas fa-save"></i> Update Password
            </button>
        </form>
    </div>

    <!-- ============================================================ -->
    <?php else: ?>
    <!-- DEFAULT - CATEGORY NOT FOUND -->
    <div class="category-card" style="grid-column:1/-1; text-align:center; padding:40px; max-width:500px; margin:40px auto;">
        <div class="card-icon"><i class="fas fa-folder-open"></i></div>
        <h4>Category Not Found</h4>
        <p>Please select a category from the sidebar.</p>
        <br>
        <a href="?page=dashboard" class="btn btn-primary" style="padding:10px 24px; background:#003366; color:#fff; border-radius:8px; text-decoration:none; display:inline-block;">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    <?php endif; ?>

    <!-- Footer -->
    <div class="dashboard-footer">
        <i class="fas fa-code"></i> <?php echo $school['school_name'] ?? 'SchoolMS'; ?> - School Management System
        <span style="margin:0 10px;">|</span>
        <i class="fas fa-clock"></i> <?php echo date('d M Y h:i A'); ?>
        <span style="margin:0 10px;">|</span>
        <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'Admin'); ?>
    </div>

</main>

<script>
    // ============================================
    // STICKY TOPBAR SHADOW ON SCROLL
    // (main-content is now its own scroll pane — see CSS notes above)
    // ============================================
    (function(){
        const pane = document.querySelector('.main-content');
        const bar = document.querySelector('.dash-topbar-sticky');
        if(!pane || !bar) return;
        pane.addEventListener('scroll', function(){
            bar.classList.toggle('scrolled', pane.scrollTop > 4);
        });
    })();

    // ============================================
    // UPDATE CLOCK
    // ============================================
    function updateClock() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        let ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        document.getElementById('currentTime').textContent = hours + ':' + minutes + ' ' + ampm;
    }
    updateClock();
    setInterval(updateClock, 1000);

    // ============================================
    // TOGGLE SIDEBAR
    // ============================================
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('open');
        document.getElementById('sidebarOverlay').classList.toggle('active');
    }

    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) {
            document.getElementById('sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            document.getElementById('sidebar').classList.remove('open');
            document.getElementById('sidebarOverlay').classList.remove('active');
        }
    });

    // ============================================
    // AUTO CLOSE SIDEBAR ON LINK CLICK (Mobile)
    // ============================================
    document.querySelectorAll('.sidebar-menu a, .sidebar-footer a').forEach(function(link) {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 1024) {
                document.getElementById('sidebar').classList.remove('open');
                document.getElementById('sidebarOverlay').classList.remove('active');
            }
        });
    });
</script>

<script>
    // ============================================
    // GLOBAL SEARCH (TOP OF DASHBOARD)
    // ============================================
    (function(){
        const input = document.getElementById('dashSearchInput');
        const dropdown = document.getElementById('dashSearchResults');
        if(!input || !dropdown) return;
        let debounceTimer = null;
        let activeController = null;

        function escapeHtml(str) {
            const div = document.createElement('div');
            div.textContent = str ?? '';
            return div.innerHTML;
        }

        function renderResults(groups) {
            if(!groups || groups.length === 0) {
                dropdown.innerHTML = '<div class="dgs-empty"><i class="fas fa-search"></i> কোনো ফলাফল পাওয়া যায়নি</div>';
                dropdown.style.display = 'block';
                return;
            }
            let html = '';
            groups.forEach(group => {
                html += `<div class="dgs-group-label"><i class="fas ${group.icon}"></i> ${group.category}</div>`;
                group.items.forEach(item => {
                    html += `<a href="${item.url}" class="dgs-item">
                        <div class="dgs-item-title">${escapeHtml(item.title)}</div>
                        <div class="dgs-item-sub">${escapeHtml(item.subtitle)}</div>
                    </a>`;
                });
            });
            dropdown.innerHTML = html;
            dropdown.style.display = 'block';
        }

        input.addEventListener('input', function(){
            const q = this.value.trim();
            clearTimeout(debounceTimer);
            if(q.length < 2) {
                dropdown.style.display = 'none';
                dropdown.innerHTML = '';
                return;
            }
            debounceTimer = setTimeout(() => {
                if(activeController) activeController.abort();
                activeController = new AbortController();
                fetch('global_search.php?q=' + encodeURIComponent(q), { signal: activeController.signal })
                    .then(res => res.json())
                    .then(data => renderResults(data.results))
                    .catch(err => { if(err.name !== 'AbortError') console.error(err); });
            }, 250);
        });

        input.addEventListener('focus', function(){
            if(dropdown.innerHTML.trim() !== '') dropdown.style.display = 'block';
        });

        document.addEventListener('click', function(e){
            if(!e.target.closest('.dash-search-wrap')) {
                dropdown.style.display = 'none';
            }
        });

        document.addEventListener('keydown', function(e){
            if(e.key === 'Escape') {
                dropdown.style.display = 'none';
                input.blur();
            }
        });
    })();
</script>

</body>
</html>

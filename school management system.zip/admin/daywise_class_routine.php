<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/routine_helper.php';
require_once '../includes/lifecycle_ui.php';

/** Day-wise class routine — every section (unit) of the school for one weekday, one sheet. */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$session_id = (int)($_GET['session_id'] ?? ($active['id'] ?? 0));
$session = null; foreach ($sessions as $ss) if ((int)$ss['id'] === $session_id) $session = $ss;
$today = date('l') === 'Sunday' ? 'Monday' : date('l');
$day = schoolms_valid_weekday($_GET['day_name'] ?? '') ? $_GET['day_name'] : $today;
$periods = routine_periods($day);
$units = []; $unit_of = [];
foreach (db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order') as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $units[$k] = ['class' => $c['class_name'], 'class_id' => (int)$c['id'], 'label' => $u['label'], 'first' => $u['section_ids'][0]]; foreach ($u['section_ids'] as $sid) $unit_of[$sid] = $k; }
$rows = db_get_all('SELECT r.section_id, r.period_id, r.group_id, sub.subject_name, st.short_code, st.staff_name FROM routine r LEFT JOIN subjects sub ON sub.id = r.subject_id LEFT JOIN staff st ON st.id = r.teacher_id WHERE r.session_id = ? AND r.day_name = ? ORDER BY ABS(r.group_id)', 'is', $session_id, $day);
$cells = []; // unit => pid => rows (from the unit's first section only)
foreach ($rows as $r) { $k = $unit_of[(int)$r['section_id']] ?? null; if ($k && (int)$r['section_id'] === $units[$k]['first']) $cells[$k][(int)$r['period_id']][] = $r; }
$show = array_filter($units, fn($u, $k) => isset($cells[$k]), ARRAY_FILTER_USE_BOTH);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Day-wise Class Routine</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); echo routine_view_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #0b3d5c; }
    .days { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; } .days a { padding: 7px 14px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #0b3d5c; text-decoration: none; font-weight: 700; font-size: 13px; } .days a.on { background: #0b3d5c; color: #fff; border-color: #0b3d5c; }
    .wrap { overflow: auto; background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px; }
    table.rv { table-layout: auto; } .rv td.u, .rv th.u { text-align: left; min-width: 120px; background: #f5f9fc; font-weight: 800; color: #0b3d5c; } .rv th.u { background: #0b3d5c; color: #fff; } .rv td.u small { display: block; font-weight: 400; color: #6b7d90; font-size: 10.5px; }
    .rv td { height: 40px; }
    .print-head { display: none; }
    @media print { @page { size: A4 landscape; margin: 8mm; } html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; } .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; } .rt-banner, .lc-filter, .days, .lc-empty { display: none !important; } .wrap { border: 0; padding: 0; overflow: visible; } .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #0b3d5c; padding-bottom: 5px; margin-bottom: 8px; } .print-head img { width: 42px; height: 42px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #0b3d5c; } .print-head small { color: #444; font-size: 10.5px; } .rv td { height: 32px; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-calendar-day"></i></div>
        <div><h1>Day-wise Class Routine</h1><p>Every section for one weekday on one sheet — session <?php echo h($session['session_name'] ?? ''); ?>.</p></div>
        <div class="links"><a href="daywise_teacher_routine.php?session_id=<?php echo $session_id; ?>&day_name=<?php echo h($day); ?>"><i class="fas fa-chalkboard-teacher"></i> Teachers this day</a><a href="class_routine.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-table"></i> Weekly</a><a href="#" class="solid" onclick="window.print();return false;"><i class="fas fa-print"></i> Print</a></div>
    </div>
    <form method="get" class="lc-filter"><div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div><input type="hidden" name="day_name" value="<?php echo h($day); ?>"></form>
    <div class="days"><?php foreach (routine_days() as $d): ?><a href="?session_id=<?php echo $session_id; ?>&day_name=<?php echo $d; ?>" class="<?php echo $d === $day ? 'on' : ''; ?>"><?php echo $d; ?></a><?php endforeach; ?></div>
    <div class="wrap">
        <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — <?php echo h($day); ?> routine</h2><small>session <?php echo h($session['session_name'] ?? ''); ?> · printed <?php echo date('d-m-Y'); ?></small></div></div>
        <?php if (!$show): ?><div class="lc-empty"><i class="fas fa-calendar-times"></i>No routine entered for <?php echo h($day); ?> yet.</div>
        <?php else: ?>
        <table class="rv"><thead><tr><th class="u">Class · Section</th><?php foreach ($periods as $p): ?><th><?php echo h($p['period_name']); ?><?php if ($p['start_time']): ?><small><?php echo h(routine_time($p['start_time']) . '–' . routine_time($p['end_time'])); ?></small><?php endif; ?></th><?php endforeach; ?></tr></thead><tbody>
        <?php foreach ($show as $k => $u): ?><tr><td class="u"><?php echo h($u['class']); ?> — <?php echo h($u['label']); ?></td>
            <?php foreach ($periods as $p): $rows = $cells[$k][(int)$p['id']] ?? []; if (!$rows) { echo '<td class="e"></td>'; continue; } $parts = []; foreach ($rows as $r) $parts[] = '<b>' . h($r['subject_name'] ?? '—') . '</b><span>' . h($r['short_code'] ?: (string)$r['staff_name']) . '</span>'; ?><td class="<?php echo (int)$rows[0]['group_id'] < 0 ? 'c' : ''; ?><?php echo count($rows) > 1 ? ' s' : ''; ?>"><?php echo implode('<i class="sep">/</i>', $parts); ?></td><?php endforeach; ?></tr><?php endforeach; ?>
        </tbody></table>
        <div class="rv-legend"><span><b>Blue</b> = taught together with another section</span><span><b>/</b> = two groups in one period</span></div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

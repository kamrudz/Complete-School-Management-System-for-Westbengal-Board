<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Deactivated students: temporarily out of school (long absence, unpaid dues, …). Deactivate one found by
 * search, or several picked from a section; restore through restore_student.php. Until restored they are off
 * every class list, the portal, certificates and cards, and their roll stays reserved.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$reasons  = ['Long absence', 'Unpaid dues', 'Medical / health', 'Family moved temporarily', 'Discipline', 'Other'];

// ---- AJAX: search Active students to deactivate ----
if (isset($_GET['ajax']) && $_GET['ajax'] === 'search') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? ''));
    if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $rows = db_get_all("
        SELECT s.id, s.student_name, s.photo, c.class_name, sec.section_name, h.roll_no, g.father_name,
               (SELECT COUNT(*) FROM library_issues li WHERE li.borrower_type = 'Student' AND li.borrower_id = s.id AND li.status = 'Issued') AS books
        FROM students s
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status = 'Current'
        LEFT JOIN classes c ON c.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE s.student_status = 'Active' AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ?)
        ORDER BY s.student_name LIMIT 12", 'ssss', $like, $like, $like, $like);
    echo json_encode(['results' => array_map(fn($r) => [
        'id' => $r['id'], 'name' => $r['student_name'], 'father' => $r['father_name'] ?? '',
        'photo' => $r['photo'] ? '../uploads/students/' . rawurlencode($r['photo']) : '',
        'where' => trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · Roll ' . $r['roll_no'] : '')) ?: 'not enrolled this session',
        'books' => (int)$r['books'],
    ], $rows)]);
    exit();
}

// ---- AJAX: Active students of a section in the running session, for the bulk picker ----
if (isset($_GET['ajax']) && $_GET['ajax'] === 'section') {
    header('Content-Type: application/json; charset=utf-8');
    $class_id = (int)($_GET['class_id'] ?? 0); $section_id = (int)($_GET['section_id'] ?? 0);
    $sess = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
    $rows = $class_id && $section_id ? db_get_all("
        SELECT s.id, s.student_name, s.photo, h.roll_no, g.father_name,
               (SELECT COUNT(*) FROM library_issues li WHERE li.borrower_type = 'Student' AND li.borrower_id = s.id AND li.status = 'Issued') AS books
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.academic_status = 'Current'
        ORDER BY CAST(h.roll_no AS UNSIGNED), s.student_name", 'iii', $sess, $class_id, $section_id) : [];
    echo json_encode(['students' => array_map(fn($r) => [
        'id' => $r['id'], 'name' => $r['student_name'], 'roll' => (string)$r['roll_no'], 'father' => $r['father_name'] ?? '',
        'photo' => $r['photo'] ? '../uploads/students/' . rawurlencode($r['photo']) : '', 'books' => (int)$r['books'],
    ], $rows)]);
    exit();
}

// ---- deactivate one / many ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['deactivate']) || isset($_POST['bulk_deactivate']))) {
    verify_csrf_or_die();
    $ids = isset($_POST['deactivate']) ? [$_POST['deactivate']] : (array)($_POST['ids'] ?? []);
    $reason = trim((string)($_POST['reason'] ?? ''));
    $detail = trim((string)($_POST['reason_text'] ?? ''));
    if ($reason === 'Other' || $reason === '') $reason = $detail; elseif ($detail !== '') $reason .= ' — ' . $detail;
    $reason = mb_substr($reason, 0, 200);
    $done = 0; $errors = [];
    foreach ($ids as $raw) {
        $r = student_set_status($conn, (string)$raw, 'Deactivated', ['reason' => $reason], $admin_id);
        if ($r['ok']) $done++; else $errors[] = $r['message'];
    }
    if ($done) $_SESSION['success'] = "$done student(s) deactivated." . ($errors ? ' ' . implode(' ', $errors) : '');
    else $_SESSION['error'] = $errors ? implode(' ', $errors) : 'No student selected.';
    header('Location: deactivated_students.php');
    exit();
}

// ---- list ----
$search    = trim((string)($_GET['search'] ?? ''));
$f_class   = (int)($_GET['class_id'] ?? 0);
$f_place   = !empty($_GET['needs']);
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$params = []; $types = '';
$where = "s.student_status = 'Deactivated'";
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where .= " AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ?)";
    $params = [$like, $like, $like, $like]; $types = 'ssss';
}
if ($f_class) { $where .= ' AND h.class_id = ?'; $params[] = $f_class; $types .= 'i'; }
if ($f_place) { $where .= ' AND (h.session_id IS NULL OR h.session_id <> ?)'; $params[] = $active_session; $types .= 'i'; }
$rows = db_get_all("
    SELECT s.id, s.student_name, s.photo, s.banglarshiksha_id, s.mobile, g.father_name, g.guardian_contact,
           h.session_id AS last_session_id, h.class_id AS last_class_id, h.section_id AS last_section_id, h.roll_no AS last_roll,
           c.class_name, sec.section_name, a.session_name,
           l.created_at AS since, l.details AS note
    FROM students s
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    LEFT JOIN academic_sessions a ON a.id = h.session_id
    LEFT JOIN admin_logs l ON l.id = (SELECT MAX(l2.id) FROM admin_logs l2 WHERE l2.record_id = s.id AND l2.action = 'STUDENT_STATUS_DEACTIVATED')
    WHERE $where
    ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name", $types, ...$params);
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');

// headline numbers (whole list, not the filtered one)
$stat = db_get_row("
    SELECT COUNT(*) AS total,
           SUM(h.session_id = ?) AS in_session,
           SUM(h.session_id IS NULL OR h.session_id <> ?) AS needs,
           SUM(l.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) AS recent
    FROM students s
    LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
    LEFT JOIN admin_logs l ON l.id = (SELECT MAX(l2.id) FROM admin_logs l2 WHERE l2.record_id = s.id AND l2.action = 'STUDENT_STATUS_DEACTIVATED')
    WHERE s.student_status = 'Deactivated'", 'ii', $active_session, $active_session) ?: [];

$filtered = $search !== '' || $f_class || $f_place;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deactivated Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .dx-banner { background: linear-gradient(135deg, #1f4e79 0%, #2b78b6 100%); color: #fff; border-radius: 14px; padding: 18px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(31,78,121,.25); }
    .dx-banner .ico { width: 52px; height: 52px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 24px; }
    .dx-banner h1 { margin: 0; font-size: 21px; display: flex; align-items: center; gap: 10px; }
    .dx-banner h1 .count { background: #fff; color: #1f4e79; font-size: 13px; padding: 2px 11px; border-radius: 999px; }
    .dx-banner p { margin: 4px 0 0; font-size: 13px; color: #d6e6f5; }
    .dx-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .dx-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; }
    .dx-banner .links a:hover { background: rgba(255,255,255,.26); }
    .dx-banner .links a.solid { background: #fff; color: #1f4e79; }
    .dx-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .dx-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
    .dx-stat i { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex: 0 0 38px; }
    .dx-stat b { font-size: 22px; display: block; line-height: 1.1; color: #10253a; }
    .dx-stat small { color: #6b7d90; font-size: 12px; }
    .dx-stat.t1 i { background: #eaf2fb; color: #1f4e79; } .dx-stat.t2 i { background: #ecf9f0; color: #1b7a3d; } .dx-stat.t3 i { background: #fff6e5; color: #9a5a00; } .dx-stat.t4 i { background: #f3f0fb; color: #5b3fa0; }
    .dx-card { background: #fff; border: 1px solid #dfe7ef; border-radius: 14px; margin-bottom: 14px; overflow: hidden; }
    .dx-card > h3 { margin: 0; padding: 11px 16px; background: linear-gradient(135deg, #b0454f, #d2606a); color: #fff; font-size: 14px; display: flex; align-items: center; gap: 8px; }
    .dx-card > h3 small { font-weight: 400; color: #fde8ea; margin-left: auto; }
    .dx-card .in { padding: 14px 16px; }
    .dx-wrap { position: relative; }
    .dx-wrap input { width: 100%; height: 44px; padding: 8px 14px 8px 40px; border: 1px solid #c9d6e2; border-radius: 10px; font-size: 14.5px; box-sizing: border-box; }
    .dx-wrap input:focus { outline: none; border-color: #2b78b6; box-shadow: 0 0 0 3px rgba(43,120,182,.15); }
    .dx-wrap > i { position: absolute; left: 14px; top: 15px; color: #8a9aab; }
    .dx-res { margin-top: 10px; border: 1px solid #dfe7ef; border-radius: 10px; overflow: hidden; display: none; }
    .dx-res.open { display: block; }
    .dx-item { display: flex; align-items: center; gap: 12px; padding: 9px 12px; border-bottom: 1px solid #eef2f6; }
    .dx-item:last-child { border-bottom: 0; }
    .dx-item img, .dx-item .noimg { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; background: #edf2f7; flex: 0 0 40px; border: 1px solid #d5dee7; }
    .dx-item .who { flex: 1; font-size: 13.5px; min-width: 0; }
    .dx-item .who small { color: #6b7d90; display: block; }
    .dx-item .books { color: #9a5a00; font-size: 12px; white-space: nowrap; }
    .dx-item .none { color: #7a8a9a; padding: 4px 0; }
    .dx-hint { color: #6b7d90; font-size: 12.5px; margin-top: 8px; }
    .dx-hint i { color: #2b78b6; }
    .dx-list-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; }
    .dx-list-head h3 { margin: 0; font-size: 15px; color: #1f4e79; }
    .dx-list-head .n { color: #6b7d90; font-size: 13px; }
    .lc-table td.reason { max-width: 240px; }
    .lc-table td.reason small { color: #6b7d90; display: block; white-space: normal; }
    .lc-actions .btn { display: inline-flex; align-items: center; gap: 5px; }
    .lc-filter .chk { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 13px; color: #3b5168; text-transform: none; letter-spacing: 0; margin: 0; font-weight: 600; }
    .lc-filter .chk input { width: 17px; height: 17px; min-width: 0; margin: 0; accent-color: #1f4e79; }
    /* confirm dialog */
    .dx-dlg .stu { display: flex; align-items: center; gap: 12px; background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 10px 12px; }
    .dx-dlg .stu img, .dx-dlg .stu .noimg { width: 48px; height: 48px; border-radius: 50%; object-fit: cover; background: #edf2f7; border: 1px solid #d5dee7; display: inline-block; }
    .dx-dlg .stu small { color: #6b7d90; display: block; }
    .dx-dlg .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 12px; }
    .dx-dlg .warn { display: none; margin-top: 10px; background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 8px; padding: 8px 12px; font-size: 13px; }
    .dx-dlg .warn.on { display: block; }
    .dx-dlg h3 { background: linear-gradient(135deg, #b0454f, #d2606a) !important; }
    .dx-dlg ul { margin: 6px 0 0 18px; padding: 0; }
    .bk-empty { color: #7a8a9a; text-align: center; padding: 18px; border: 1px dashed #cfdbe6; border-radius: 10px; font-size: 13px; }
    .bk-empty i { color: #2b78b6; margin-right: 6px; }
    .bk-bar { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; padding: 8px 12px; background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px 10px 0 0; }
    .bk-bar .spacer { flex: 1; }
    .bk-bar .chk { display: flex; align-items: center; gap: 7px; font-size: 13px; font-weight: 700; color: #1f4e79; }
    .bk-bar .chk input { width: 17px; height: 17px; accent-color: #1f4e79; }
    .bk-bar .chk span { color: #6b7d90; font-weight: 400; }
    .bk-picked { background: #fff6e5; color: #9a5a00; border: 1px solid #f0c987; padding: 3px 11px; border-radius: 999px; font-size: 12.5px; font-weight: 700; }
    .bk-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 6px; padding: 8px; border: 1px solid #e1eaf2; border-top: 0; border-radius: 0 0 10px 10px; max-height: 420px; overflow: auto; }
    .bk-stu { display: flex; align-items: center; gap: 9px; padding: 6px 9px; border: 1px solid #e6edf3; border-radius: 9px; cursor: pointer; background: #fff; user-select: none; }
    .bk-stu:hover { border-color: #b9cbdc; background: #f7fafd; }
    .bk-stu.on { background: #fdeeef; border-color: #e0a3a7; }
    .bk-stu input { width: 16px; height: 16px; accent-color: #b0454f; margin: 0; flex: 0 0 16px; }
    .bk-stu .roll { width: 30px; height: 30px; border-radius: 8px; background: #1f4e79; color: #fff; font-weight: 700; font-size: 12.5px; display: flex; align-items: center; justify-content: center; flex: 0 0 30px; }
    .bk-stu .nm { font-size: 13px; min-width: 0; flex: 1; }
    .bk-stu .nm b { display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .bk-stu .nm small { color: #6b7d90; display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .bk-stu .bk { color: #9a5a00; font-size: 11px; white-space: nowrap; }
    .bk-stu[hidden] { display: none; }
    .dx-dlg .names { max-height: 200px; overflow: auto; border: 1px solid #e1eaf2; border-radius: 8px; padding: 6px 10px; margin-top: 10px; font-size: 13px; display: grid; grid-template-columns: 1fr 1fr; gap: 0 12px; }
    .dx-dlg .names div { break-inside: avoid; padding: 2px 0; }
    .dx-dlg .names .roll { display: inline-block; min-width: 26px; color: #1f4e79; font-weight: 700; }
    @media (max-width: 900px) { .dx-stats { grid-template-columns: 1fr 1fr; } .dx-dlg .row2 { grid-template-columns: 1fr; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="dx-banner">
        <div class="ico"><i class="fas fa-user-slash"></i></div>
        <div>
            <h1>Deactivated Students <span class="count"><?php echo (int)($stat['total'] ?? 0); ?></span></h1>
            <p>Temporarily out of school. They vanish from class lists, the portal, certificates and cards; their roll stays reserved in that session until you restore them.</p>
        </div>
        <div class="links">
            <a href="export_students.php?status=Deactivated&amp;session_id=0"><i class="fas fa-file-excel"></i> Export</a>
            <a href="tc_students.php"><i class="fas fa-file-export"></i> TC</a>
            <a href="deleted_students.php"><i class="fas fa-trash-alt"></i> Deleted</a>
            <a href="students.php" class="solid"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <div class="dx-stats">
        <div class="dx-stat t1"><i class="fas fa-user-slash"></i><div><b><?php echo (int)($stat['total'] ?? 0); ?></b><small>Deactivated in total</small></div></div>
        <div class="dx-stat t2"><i class="fas fa-bookmark"></i><div><b><?php echo (int)($stat['in_session'] ?? 0); ?></b><small>Roll reserved in the running session</small></div></div>
        <div class="dx-stat t3"><i class="fas fa-map-marker-alt"></i><div><b><?php echo (int)($stat['needs'] ?? 0); ?></b><small>From an earlier session — need placement to restore</small></div></div>
        <div class="dx-stat t4"><i class="fas fa-calendar-day"></i><div><b><?php echo (int)($stat['recent'] ?? 0); ?></b><small>Deactivated in the last 30 days</small></div></div>
    </div>

    <div class="dx-card">
        <h3><i class="fas fa-user-minus"></i> Deactivate a student <small>searches Active students only</small></h3>
        <div class="in">
            <div class="dx-wrap"><i class="fas fa-search"></i><input type="text" id="dxSearch" placeholder="Type a name, School UID, Banglar Shiksha ID or father's name…" autocomplete="off"></div>
            <div class="dx-res" id="dxRes"></div>
            <div class="dx-hint"><i class="fas fa-info-circle"></i> Deactivating is reversible — use <b>Restore</b> below to bring the student back. For a student who has left for good, issue a <a href="tc_students.php">TC</a> instead.</div>
        </div>
    </div>

    <div class="dx-card">
        <h3><i class="fas fa-users-slash"></i> Deactivate many <small>pick a section, tick the students</small></h3>
        <div class="in">
            <div class="lc-filter" style="margin-bottom:10px">
                <div><label>Class</label><select id="bkClass"><option value="">Select class</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo htmlspecialchars($c['class_name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Section</label><select id="bkSection"><option value="">Select class first</option></select></div>
                <div style="flex:1"><label>Find in list</label><input type="text" id="bkFind" placeholder="Roll or name" disabled></div>
            </div>
            <div id="bkEmpty" class="bk-empty"><i class="fas fa-hand-pointer"></i> Choose a class and section — its Active students appear here with a tick box each.</div>
            <div id="bkWrap" hidden>
                <div class="bk-bar">
                    <label class="chk"><input type="checkbox" id="bkAll"> Select all <span id="bkTotal"></span></label>
                    <span class="bk-picked" id="bkPicked">0 selected</span>
                    <span class="spacer"></span>
                    <button type="button" class="btn btn-danger" id="bkGo" disabled onclick="bkConfirm()"><i class="fas fa-users-slash"></i> Deactivate selected</button>
                </div>
                <div class="bk-grid" id="bkGrid"></div>
            </div>
        </div>
    </div>

    <div class="dx-list-head">
        <h3><i class="fas fa-list"></i> Deactivated list</h3>
        <span class="n"><?php echo count($rows); ?> shown<?php echo $filtered ? ' (filtered)' : ''; ?></span>
    </div>
    <form method="get" class="lc-filter">
        <div><label>Search</label><input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name, UID, Banglar Shiksha ID, father" style="min-width:260px"></div>
        <div><label>Last class</label><select name="class_id"><option value="0">All classes</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo $f_class === (int)$c['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <label class="chk"><input type="checkbox" name="needs" value="1" <?php echo $f_place ? 'checked' : ''; ?>> Needs placement only</label>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <?php if ($filtered): ?><a href="deactivated_students.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-check-circle"></i>No deactivated students<?php echo $filtered ? ' match this filter' : ''; ?>.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>#</th><th>Student</th><th>Father / contact</th><th>Banglar Shiksha ID</th><th>Last class</th><th>Since / reason</th><th>Actions</th></tr></thead>
        <tbody>
        <?php $sl = 1; foreach ($rows as $r): $needs = (int)$r['last_session_id'] !== $active_session; $why = lifecycle_reason($r['note']); ?>
        <tr>
            <td><?php echo $sl++; ?></td>
            <td><?php echo lifecycle_student_cell($r); ?></td>
            <td><?php echo htmlspecialchars($r['father_name'] ?? ''); ?><?php if ($r['guardian_contact'] ?: $r['mobile']): ?><br><small><i class="fas fa-phone" style="color:#8a9aab"></i> <?php echo htmlspecialchars($r['guardian_contact'] ?: $r['mobile']); ?></small><?php endif; ?></td>
            <td><?php echo htmlspecialchars($r['banglarshiksha_id'] ?? '—'); ?></td>
            <td><?php if ($r['class_name']): ?><span class="lc-tag <?php echo $needs ? 'muted' : 'ok'; ?>"><?php echo htmlspecialchars($r['class_name'] . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['last_roll'] ? ' · Roll ' . $r['last_roll'] : '')); ?></span> <small style="color:#6b7d90"><?php echo htmlspecialchars($r['session_name']); ?></small><?php else: ?><span class="lc-tag muted">never enrolled</span><?php endif; ?>
                <?php if ($needs): ?><br><span class="lc-tag warn" title="Their last enrolment is not in the running session — Restore asks for class, section and roll">needs placement</span><?php endif; ?></td>
            <td class="reason"><?php echo $r['since'] ? date('d-m-Y', strtotime($r['since'])) : '—'; ?><?php if ($why): ?><small><?php echo htmlspecialchars($why); ?></small><?php endif; ?></td>
            <td class="lc-actions">
                <a href="<?php echo htmlspecialchars(student_page_url('view_student.php', $r['id'])); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> View</a>
                <button type="button" class="btn btn-success btn-sm"
                    onclick="lcRestore(<?php echo htmlspecialchars(json_encode($r['id']), ENT_QUOTES, "UTF-8"); ?>, <?php echo htmlspecialchars(json_encode($r['student_name']), ENT_QUOTES, "UTF-8"); ?>, <?php echo $needs ? 'true' : 'false'; ?>, <?php echo (int)$r['last_class_id']; ?>, <?php echo (int)$r['last_section_id']; ?>, <?php echo htmlspecialchars(json_encode((string)$r['last_roll']), ENT_QUOTES, "UTF-8"); ?>)"><i class="fas fa-undo"></i> Restore</button>
                <form method="post" action="delete_student.php" onsubmit="var r = prompt('Move <?php echo htmlspecialchars(addslashes($r['student_name'])); ?> to the Deleted list?
Reason (optional):'); if (r === null) return false; this.reason.value = r; return true;"><input type="hidden" name="reason" value="">
                    <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo htmlspecialchars($r['id']); ?>"><input type="hidden" name="back" value="deactivated">
                    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<?php lifecycle_restore_modal($classes, 'deactivated'); ?>

<!-- confirm dialog for bulk deactivating -->
<div class="lc-modal" id="bkModal">
    <form class="lc-dialog dx-dlg" method="post" action="deactivated_students.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="bulk_deactivate" value="1">
        <div id="bkIds"></div>
        <h3><i class="fas fa-users-slash"></i> Deactivate <span id="bkN"></span> students</h3>
        <div class="body">
            <div><b id="bkWhere"></b></div>
            <div class="names" id="bkNames"></div>
            <div class="row2">
                <div><label>Reason (same for all)</label><select name="reason"><?php foreach ($reasons as $x): ?><option value="<?php echo htmlspecialchars($x); ?>"><?php echo htmlspecialchars($x); ?></option><?php endforeach; ?></select></div>
                <div><label>Note (optional)</label><input type="text" name="reason_text" maxlength="150" placeholder="e.g. absent since July"></div>
            </div>
            <div class="warn" id="bkBooks"></div>
            <div class="note">Each student is removed from class lists, the portal, certificates and cards; their roll stays reserved. Every one of them can be restored from this page.</div>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('bkModal').classList.remove('open')">Cancel</button>
            <button type="submit" class="btn btn-danger"><i class="fas fa-users-slash"></i> Deactivate all selected</button>
        </div>
    </form>
</div>
<script>
(function () {
    var cls = document.getElementById('bkClass'), sec = document.getElementById('bkSection'), find = document.getElementById('bkFind'),
        grid = document.getElementById('bkGrid'), wrap = document.getElementById('bkWrap'), empty = document.getElementById('bkEmpty'),
        all = document.getElementById('bkAll'), picked = document.getElementById('bkPicked'), go = document.getElementById('bkGo'), list = [];
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function h(x) { return esc(x); }
    cls.addEventListener('change', function () {
        sec.innerHTML = '<option value="">Loading…</option>'; reset();
        if (!this.value) { sec.innerHTML = '<option value="">Select class first</option>'; return; }
        fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + lcActiveSession).then(function (r) { return r.text(); }).then(function (html) { sec.innerHTML = html; });
    });
    sec.addEventListener('change', function () {
        reset(); if (!this.value) return;
        fetch('deactivated_students.php?ajax=section&class_id=' + encodeURIComponent(cls.value) + '&section_id=' + encodeURIComponent(this.value)).then(function (r) { return r.json(); }).then(function (d) {
            list = d.students;
            if (!list.length) { empty.innerHTML = '<i class="fas fa-info-circle"></i> No Active students in this section.'; return; }
            grid.innerHTML = list.map(function (s, i) {
                return '<label class="bk-stu" data-i="' + i + '"><input type="checkbox" value="' + h(s.id) + '"><span class="roll">' + h(s.roll || '–') + '</span><span class="nm"><b>' + h(s.name) + '</b><small>' + h(s.id) + (s.father ? ' · ' + h(s.father) : '') + '</small></span>' + (s.books ? '<span class="bk" title="library books not returned"><i class="fas fa-book"></i> ' + s.books + '</span>' : '') + '</label>';
            }).join('');
            empty.hidden = true; wrap.hidden = false; find.disabled = false; count();
        });
    });
    function reset() { list = []; grid.innerHTML = ''; wrap.hidden = true; empty.hidden = false; empty.innerHTML = '<i class="fas fa-hand-pointer"></i> Choose a class and section — its Active students appear here with a tick box each.'; find.value = ''; find.disabled = true; all.checked = false; count(); }
    function boxes() { return [].slice.call(grid.querySelectorAll('input[type=checkbox]')); }
    function count() {
        var b = boxes(), n = b.filter(function (x) { return x.checked; }).length;
        b.forEach(function (x) { x.closest('.bk-stu').classList.toggle('on', x.checked); });
        picked.textContent = n + ' selected'; go.disabled = !n; go.innerHTML = '<i class="fas fa-users-slash"></i> Deactivate ' + (n ? n + ' selected' : 'selected');
        document.getElementById('bkTotal').textContent = b.length ? '(' + b.length + ' students)' : '';
        all.checked = b.length > 0 && n === b.length;
    }
    grid.addEventListener('change', count);
    all.addEventListener('change', function () { var on = this.checked; boxes().forEach(function (x) { if (!x.closest('.bk-stu').hidden) x.checked = on; }); count(); });
    find.addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        grid.querySelectorAll('.bk-stu').forEach(function (el) { var s = list[+el.dataset.i]; el.hidden = q !== '' && s.name.toLowerCase().indexOf(q) < 0 && String(s.roll) !== q && s.id.toLowerCase().indexOf(q) < 0; });
    });
    window.bkConfirm = function () {
        var sel = boxes().filter(function (x) { return x.checked; }).map(function (x) { return list.find(function (s) { return s.id === x.value; }); });
        if (!sel.length) return;
        document.getElementById('bkN').textContent = sel.length;
        document.getElementById('bkWhere').textContent = cls.options[cls.selectedIndex].text + '-' + sec.options[sec.selectedIndex].text;
        document.getElementById('bkIds').innerHTML = sel.map(function (s) { return '<input type="hidden" name="ids[]" value="' + h(s.id) + '">'; }).join('');
        document.getElementById('bkNames').innerHTML = sel.map(function (s) { return '<div><span class="roll">' + h(s.roll || '–') + '</span> ' + h(s.name) + '</div>'; }).join('');
        var books = sel.reduce(function (a, s) { return a + s.books; }, 0), w = document.getElementById('bkBooks');
        w.innerHTML = books ? '<i class="fas fa-book"></i> <b>' + books + ' library book' + (books > 1 ? 's are' : ' is') + ' still out</b> with the selected students — deactivating does not close the loans.' : '';
        w.classList.toggle('on', !!books);
        document.getElementById('bkModal').classList.add('open');
    };
    document.getElementById('bkModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
})();
</script>

<!-- confirm dialog for deactivating -->
<div class="lc-modal" id="dxModal">
    <form class="lc-dialog dx-dlg" method="post" action="deactivated_students.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="deactivate" id="dxId">
        <h3><i class="fas fa-user-slash"></i> Deactivate student</h3>
        <div class="body">
            <div class="stu"><span id="dxPhoto"></span><div><b id="dxName"></b> <span class="lc-uid" id="dxUid"></span><small id="dxWhere"></small></div></div>
            <div class="row2">
                <div><label>Reason</label><select name="reason" id="dxReason"><?php foreach ($reasons as $x): ?><option value="<?php echo htmlspecialchars($x); ?>"><?php echo htmlspecialchars($x); ?></option><?php endforeach; ?></select></div>
                <div><label>Note (optional)</label><input type="text" name="reason_text" id="dxText" maxlength="150" placeholder="e.g. absent since July"></div>
            </div>
            <div class="warn" id="dxBooks"></div>
            <div class="note">What happens:<ul><li>Removed from class lists, attendance, marks entry, certificates, ID / admit cards and the student portal.</li><li>Roll stays reserved in the running session; nothing is deleted.</li><li><b>Restore</b> from this page puts them back exactly where they were.</li></ul></div>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="dxClose()">Cancel</button>
            <button type="submit" class="btn btn-danger"><i class="fas fa-user-slash"></i> Deactivate</button>
        </div>
    </form>
</div>
<script>
(function () {
    var input = document.getElementById('dxSearch'), res = document.getElementById('dxRes'), timer = null, ctrl = null;
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    window.dxFound = {};
    input.addEventListener('input', function () {
        clearTimeout(timer); var q = this.value.trim();
        if (q.length < 2) { res.classList.remove('open'); return; }
        timer = setTimeout(function () {
            if (ctrl) ctrl.abort(); ctrl = new AbortController();
            fetch('deactivated_students.php?ajax=search&q=' + encodeURIComponent(q), { signal: ctrl.signal }).then(function (r) { return r.json(); }).then(function (d) {
                window.dxFound = {};
                if (!d.results.length) { res.innerHTML = '<div class="dx-item"><span class="none"><i class="fas fa-search"></i> No Active student matches "' + esc(q) + '".</span></div>'; res.classList.add('open'); return; }
                res.innerHTML = d.results.map(function (s) {
                    window.dxFound[s.id] = s;
                    return '<div class="dx-item">' + (s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="noimg"></span>') +
                        '<div class="who"><b>' + esc(s.name) + '</b> <span class="lc-uid">' + esc(s.id) + '</span><small>' + esc(s.where) + (s.father ? ' · Father: ' + esc(s.father) : '') + '</small></div>' +
                        (s.books ? '<span class="books"><i class="fas fa-book"></i> ' + s.books + ' book' + (s.books > 1 ? 's' : '') + ' not returned</span>' : '') +
                        '<button type="button" class="btn btn-danger btn-sm" onclick="dxOpen(' + JSON.stringify(s.id) + ')"><i class="fas fa-user-slash"></i> Deactivate</button></div>';
                }).join(''); res.classList.add('open');
            }).catch(function () {});
        }, 250);
    });
    window.dxOpen = function (id) {
        var s = window.dxFound[id]; if (!s) return;
        document.getElementById('dxId').value = s.id;
        document.getElementById('dxName').textContent = s.name;
        document.getElementById('dxUid').textContent = s.id;
        document.getElementById('dxWhere').textContent = s.where + (s.father ? ' · Father: ' + s.father : '');
        document.getElementById('dxPhoto').innerHTML = s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="noimg"></span>';
        var w = document.getElementById('dxBooks');
        w.innerHTML = s.books ? '<i class="fas fa-book"></i> <b>' + s.books + ' library book' + (s.books > 1 ? 's are' : ' is') + ' still with this student.</b> Collect them first if you can — deactivating does not close the loan.' : '';
        w.classList.toggle('on', !!s.books);
        document.getElementById('dxReason').selectedIndex = 0; document.getElementById('dxText').value = '';
        document.getElementById('dxModal').classList.add('open');
    };
    window.dxClose = function () { document.getElementById('dxModal').classList.remove('open'); };
    document.getElementById('dxModal').addEventListener('click', function (e) { if (e.target === this) dxClose(); });
})();
</script>
</body>
</html>

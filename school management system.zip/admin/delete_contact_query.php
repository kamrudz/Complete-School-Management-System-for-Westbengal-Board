<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/security.php';

// ===== ONLY ALLOW POST REQUESTS =====
if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: contact_queries.php");
    exit();
}

// ===== CSRF PROTECTION =====
verify_csrf_or_die();

// ===== VALIDATE INPUT =====
if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    $_SESSION['error'] = "Invalid message ID!";
    header("Location: contact_queries.php");
    exit();
}

$id = (int)$_POST['id'];

$stmt = mysqli_prepare($conn, "DELETE FROM contact_queries WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);

if(mysqli_stmt_execute($stmt)) {
    $_SESSION['success'] = "Message deleted successfully!";
} else {
    $_SESSION['error'] = "Failed to delete message!";
}

mysqli_stmt_close($stmt);
header("Location: contact_queries.php");
exit();
?>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }


require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

verify_csrf_or_die();

$id = (int)($_POST['id'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT photo FROM gallery WHERE id=?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$query = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($query);

$delete = mysqli_prepare($conn, "DELETE FROM gallery WHERE id=?");
mysqli_stmt_bind_param($delete, "i", $id);
$deleted = mysqli_stmt_execute($delete);
if ($deleted && $row && !empty($row['photo'])) {
    app_unlink_upload('../uploads/gallery/', $row['photo']);
}

header("Location: gallery.php");

exit();

?>

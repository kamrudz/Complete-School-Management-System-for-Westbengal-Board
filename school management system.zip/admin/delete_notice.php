<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';

// ===== ONLY ALLOW POST REQUESTS =====
if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: notices.php");
    exit();
}

// ===== CSRF PROTECTION =====
verify_csrf_or_die();

// ===== VALIDATE INPUT =====
if(!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    $_SESSION['error'] = "Invalid notice ID!";
    header("Location: notices.php");
    exit();
}

$id = (int)$_POST['id'];

// ===== GET ATTACHMENT INFO =====
$row = db_get_row('SELECT attachment FROM notices WHERE id=? LIMIT 1', 'i', $id);

// ===== DELETE NOTICE =====
$deleted = db_execute('DELETE FROM notices WHERE id=?', 'i', $id);
if($deleted !== false) {
    if ($row && !empty($row['attachment'])) app_unlink_upload('../uploads/notices/', $row['attachment']);
    $_SESSION['success'] = "Notice Deleted Successfully!";
} else {
    $_SESSION['error'] = "Failed to delete notice!";
}

header("Location: notices.php");
exit();
?>
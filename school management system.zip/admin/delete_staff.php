<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/misc_helper.php';

/**
 * Staff service-status change (the old hard delete is gone: routine, attendance and exam
 * duty rows point at the staff row and must outlive the person's service).
 *   POST id, status = Transferred | Retired | Deceased (+ status_date, note)   -> leaves; portal login off
 *   POST id, status = Active                                                    -> back to Active
 *   POST id, permanent = 1, confirm_id = <employee id>                          -> removes the row, only when
 *        nothing else references it (no routine / attendance / exam duty / library rows) — for wrong entries
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: staff.php'); exit(); }
verify_csrf_or_die();

$id = (int)($_POST['id'] ?? 0);
$staff = $id > 0 ? staff_get_by_id($id) : null;
if (!$staff) { $_SESSION['error'] = 'Staff member not found.'; header('Location: staff.php'); exit(); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);

if (!empty($_POST['permanent'])) {
    if (strtoupper(trim((string)($_POST['confirm_id'] ?? ''))) !== $staff['employee_id']) { $_SESSION['error'] = "Type the Employee ID {$staff['employee_id']} exactly to confirm. Nothing was deleted."; header('Location: view_staff.php?id=' . $id); exit(); }
    $deps = staff_dependency_counts($id);
    if ($deps) { $_SESSION['error'] = 'Cannot delete: this record is referenced by ' . implode(', ', array_map(fn($k, $n) => "$n $k", array_keys($deps), $deps)) . '. Mark them Transferred / Retired instead.'; header('Location: view_staff.php?id=' . $id); exit(); }
    db_execute('DELETE FROM staff WHERE id = ?', 'i', $id);
    if ($staff['photo']) app_unlink_upload('../uploads/staff/', $staff['photo']);
    log_action($admin_id, 'STAFF_PERMANENT_DELETE', 'staff', (string)$id, null, "{$staff['staff_name']} ({$staff['employee_id']}) removed permanently");
    $_SESSION['success'] = "{$staff['staff_name']} ({$staff['employee_id']}) permanently removed.";
    header('Location: staff.php'); exit();
}

$status = in_array($_POST['status'] ?? '', staff_service_statuses(), true) ? $_POST['status'] : '';
if ($status === '') { $_SESSION['error'] = 'Choose a status.'; header('Location: staff.php'); exit(); }
$date = trim((string)($_POST['status_date'] ?? ''));
$note = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 200);
if ($status !== 'Active') {
    $dt = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dt || $dt->format('Y-m-d') !== $date) { $_SESSION['error'] = 'Give a valid date.'; header('Location: staff.php'); exit(); }
}
$data = ['service_status' => $status, 'status_date' => $status === 'Active' ? null : $date];
if ($status !== 'Active') $data['can_login'] = 0;
else $data['can_login'] = staff_designations()[$staff['designation']][1] ?? 0;
db_update('staff', $data, ['id' => $id], 'i');
log_action($admin_id, 'STAFF_STATUS_' . strtoupper($status), 'staff', (string)$id, ['service_status' => $staff['service_status'], 'status_date' => $staff['status_date']], ['service_status' => $status, 'status_date' => $data['status_date'], 'note' => $note]);
$_SESSION['success'] = "{$staff['staff_name']} ({$staff['employee_id']}) is now $status" . ($status !== 'Active' ? ' from ' . date('d-m-Y', strtotime($date)) . '. Portal login switched off.' : '.');
header('Location: ' . ($status === 'Active' ? 'staff.php?status=all' : 'staff.php'));
exit();

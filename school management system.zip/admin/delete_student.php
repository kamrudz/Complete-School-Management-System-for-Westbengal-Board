<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/logger.php';
require_once '../includes/security.php';

/**
 * Delete one student: they move to the Deleted list (restorable from there) and their running-session
 * enrolment is closed, so they drop off class lists, certificates and ID cards.
 * POST: id, reason, reason_text (optional), back = students | deactivated
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: students.php'); exit(); }
verify_csrf_or_die();

$back = ['deactivated' => 'deactivated_students.php', 'students' => 'students.php'][$_POST['back'] ?? ''] ?? 'students.php';
$reason = trim((string)($_POST['reason'] ?? ''));
$detail = trim((string)($_POST['reason_text'] ?? ''));
if ($reason === 'Other' || $reason === '') $reason = $detail; elseif ($detail !== '') $reason .= ' — ' . $detail;

$id = student_uid_clean($_POST['id'] ?? '');
$r = $id === '' ? ['ok' => false, 'message' => 'No student selected.']
    : student_set_status($conn, $id, 'Deleted', ['reason' => mb_substr($reason, 0, 200)], (int)($_SESSION['admin_id'] ?? 0));
$_SESSION[$r['ok'] ? 'success' : 'error'] = $r['ok'] ? $r['message'] . ' Restorable from the Deleted list.' : $r['message'];
header("Location: $back");
exit();

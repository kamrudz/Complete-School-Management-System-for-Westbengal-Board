<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Deleted students — soft-deleted records waiting to be restored or removed for good.
 * A student lands here from the Students list or the Deactivated list (delete_student.php,
 * with an optional reason). Restore goes through restore_student.php; permanent delete
 * through permanent_delete_student.php, after the admin types the School UID. Until then
 * nothing is lost: the record, history, marks and files all stay.
 */

// AJAX: what a permanent delete would take with it (rows per table + files)
if (isset($_GET['deps'])) {
    $uid = student_uid_clean($_GET['deps']);
    $st = $uid !== '' ? db_get_row('SELECT * FROM students WHERE id = ? AND student_status = \'Deleted\'', 's', $uid) : null;
    if (!$st) { echo 'Student not found.'; exit(); }
    $deps = student_dependency_counts($uid); $files = student_files($st);
    if (!empty($deps['fee_receipts'])) { echo '<b>Cannot be deleted for good:</b> the student has ' . (int)$deps['fee_receipts'] . ' fee receipt(s), and money records are kept for the school\'s accounts.'; exit(); }
    $labels = ['student_academic_history' => 'academic history', 'marks' => 'marks', 'hs_marks' => 'HS marks', 'student_attendance' => 'attendance', 'fee_invoices' => 'fee invoices',
        'fee_transactions' => 'fee payment lines', 'student_discounts' => 'fee discounts', 'hprc_formative' => 'HPRC formative', 'hprc_behavior' => 'HPRC behaviour', 'hprc_learning' => 'HPRC learning',
        'hprc_personality_lifeskills' => 'HPRC personality', 'student_merit_ranks' => 'merit ranks', 'promotion_details' => 'promotion records', 'student_third_language' => 'third language choice',
        'certificates' => 'certificates', 'student_id_cards' => 'ID cards', 'student_admit_cards' => 'admit cards', 'tc_students' => 'TC records', 'hs_registration' => 'HS registration',
        'secondary_registration' => 'Madhyamik registration', 'hs_student_mp_marks' => 'Madhyamik marks', 'hs_student_subjects' => 'HS subjects', 'student_activity_logs' => 'portal activity', 'exam_seating_plan' => 'exam seating', 'library_issues' => 'library loans',
        'admission_applications' => 'the link from their online admission form (the form itself stays)'];
    $parts = [];
    foreach ($deps as $t => $n) $parts[] = htmlspecialchars(($labels[$t] ?? $t) . " $n");
    echo '<b>This removes for good:</b> the student record' . ($parts ? ', ' . implode(', ', $parts) : ' (no dependent rows)') . ($files ? ', and ' . count($files) . ' uploaded file(s)' : '') . '. The family (guardian) row stays if a sibling still uses it. <b>There is no undo.</b>';
    exit();
}

$search  = trim((string)($_GET['search'] ?? ''));
$f_class = (int)($_GET['class_id'] ?? 0);
$f_place = !empty($_GET['needs']);
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$params = []; $types = '';
$where = "s.student_status = 'Deleted'";
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where .= " AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ?)";
    $params = [$like, $like, $like, $like]; $types = 'ssss';
}
if ($f_class) { $where .= ' AND h.class_id = ?'; $params[] = $f_class; $types .= 'i'; }
if ($f_place) { $where .= ' AND (h.session_id IS NULL OR h.session_id <> ?)'; $params[] = $active_session; $types .= 'i'; }
$rows = db_get_all("
    SELECT s.id, s.student_name, s.photo, s.banglarshiksha_id, s.mobile, g.father_name, g.guardian_contact,
           h.session_id AS last_session_id, h.class_id AS last_class_id, h.section_id AS last_section_id, h.roll_no AS last_roll,
           c.class_name, sec.section_name, a.session_name,
           l.created_at AS deleted_at, l.details AS note
    FROM students s
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    LEFT JOIN academic_sessions a ON a.id = h.session_id
    LEFT JOIN admin_logs l ON l.id = (SELECT MAX(l2.id) FROM admin_logs l2 WHERE l2.record_id = s.id AND l2.action IN ('STUDENT_STATUS_DELETED','STUDENT_DELETED'))
    WHERE $where
    ORDER BY deleted_at DESC, s.student_name", $types, ...$params);
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');

// headline numbers (whole list, not the filtered one)
$stat = db_get_row("
    SELECT COUNT(*) AS total,
           SUM(h.session_id = ?) AS in_session,
           SUM(h.session_id IS NULL OR h.session_id <> ?) AS needs,
           SUM(l.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)) AS recent
    FROM students s
    LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
    LEFT JOIN admin_logs l ON l.id = (SELECT MAX(l2.id) FROM admin_logs l2 WHERE l2.record_id = s.id AND l2.action IN ('STUDENT_STATUS_DELETED','STUDENT_DELETED'))
    WHERE s.student_status = 'Deleted'", 'ii', $active_session, $active_session) ?: [];

$filtered = $search !== '' || $f_class || $f_place;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deleted Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .dl-banner { background: linear-gradient(135deg, #7a2a33 0%, #b0454f 100%); color: #fff; border-radius: 14px; padding: 18px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(122,42,51,.25); }
    .dl-banner .ico { width: 52px; height: 52px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 24px; }
    .dl-banner h1 { margin: 0; font-size: 21px; display: flex; align-items: center; gap: 10px; }
    .dl-banner h1 .count { background: #fff; color: #7a2a33; font-size: 13px; padding: 2px 11px; border-radius: 999px; }
    .dl-banner p { margin: 4px 0 0; font-size: 13px; color: #f6dfe1; }
    .dl-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .dl-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; }
    .dl-banner .links a:hover { background: rgba(255,255,255,.26); }
    .dl-banner .links a.solid { background: #fff; color: #7a2a33; }
    .dl-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .dl-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
    .dl-stat i { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex: 0 0 38px; }
    .dl-stat b { font-size: 22px; display: block; line-height: 1.1; color: #10253a; }
    .dl-stat small { color: #6b7d90; font-size: 12px; }
    .dl-stat.t1 i { background: #fdeeef; color: #9d2630; } .dl-stat.t2 i { background: #ecf9f0; color: #1b7a3d; } .dl-stat.t3 i { background: #fff6e5; color: #9a5a00; } .dl-stat.t4 i { background: #f3f0fb; color: #5b3fa0; }
    .dl-how { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-bottom: 14px; }
    .dl-how div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 11px 14px; font-size: 12.5px; color: #3b5168; display: flex; gap: 10px; align-items: flex-start; }
    .dl-how i { margin-top: 2px; font-size: 15px; }
    .dl-how b { display: block; color: #10253a; font-size: 13px; margin-bottom: 2px; }
    .dl-list-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; }
    .dl-list-head h3 { margin: 0; font-size: 15px; color: #7a2a33; }
    .dl-list-head .n { color: #6b7d90; font-size: 13px; }
    .lc-table td.reason { max-width: 240px; }
    .lc-table td.reason small { color: #6b7d90; display: block; white-space: normal; }
    .lc-actions .btn { display: inline-flex; align-items: center; gap: 5px; }
    .lc-filter .chk { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 13px; color: #3b5168; text-transform: none; letter-spacing: 0; margin: 0; font-weight: 600; }
    .lc-filter .chk input { width: 17px; height: 17px; min-width: 0; margin: 0; accent-color: #7a2a33; }
    @media (max-width: 900px) { .dl-stats, .dl-how { grid-template-columns: 1fr 1fr; } }
    @media (max-width: 600px) { .dl-how { grid-template-columns: 1fr; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="dl-banner">
        <div class="ico"><i class="fas fa-trash-alt"></i></div>
        <div>
            <h1>Deleted Students <span class="count"><?php echo (int)($stat['total'] ?? 0); ?></span></h1>
            <p>Records taken out of the school, kept here in full. Restore brings one back; Delete forever removes it with everything linked to it.</p>
        </div>
        <div class="links">
            <a href="deactivated_students.php"><i class="fas fa-user-slash"></i> Deactivated</a>
            <a href="tc_students.php"><i class="fas fa-file-export"></i> TC</a>
            <a href="students.php" class="solid"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <div class="dl-stats">
        <div class="dl-stat t1"><i class="fas fa-trash-alt"></i><div><b><?php echo (int)($stat['total'] ?? 0); ?></b><small>On the Deleted list</small></div></div>
        <div class="dl-stat t2"><i class="fas fa-bookmark"></i><div><b><?php echo (int)($stat['in_session'] ?? 0); ?></b><small>Roll still reserved in the running session</small></div></div>
        <div class="dl-stat t3"><i class="fas fa-map-marker-alt"></i><div><b><?php echo (int)($stat['needs'] ?? 0); ?></b><small>From an earlier session — need placement to restore</small></div></div>
        <div class="dl-stat t4"><i class="fas fa-calendar-day"></i><div><b><?php echo (int)($stat['recent'] ?? 0); ?></b><small>Deleted in the last 30 days</small></div></div>
    </div>

    <div class="dl-how">
        <div><i class="fas fa-trash" style="color:#b0454f"></i><div><b>How a student gets here</b>The Delete button on the Students list or the Deactivated list (with an optional reason). Nothing is removed: history, marks, fees and files stay.</div></div>
        <div><i class="fas fa-undo" style="color:#1b7a3d"></i><div><b>Restore</b>Puts the student back as Active. If their last enrolment was in an earlier session you choose the class, section and roll for the running session.</div></div>
        <div><i class="fas fa-exclamation-triangle" style="color:#9a5a00"></i><div><b>Delete forever</b>Removes the record and every linked row (history, marks, attendance, fees, cards, certificates, TC…) and the uploaded files. You must type the School UID. No undo.</div></div>
    </div>

    <div class="dl-list-head">
        <h3><i class="fas fa-list"></i> Deleted list</h3>
        <span class="n"><?php echo count($rows); ?> shown<?php echo $filtered ? ' (filtered)' : ''; ?></span>
    </div>
    <form method="get" class="lc-filter">
        <div><label>Search</label><input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name, UID, Banglar Shiksha ID, father" style="min-width:260px"></div>
        <div><label>Last class</label><select name="class_id"><option value="0">All classes</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo $f_class === (int)$c['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <label class="chk"><input type="checkbox" name="needs" value="1" <?php echo $f_place ? 'checked' : ''; ?>> Needs placement only</label>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <?php if ($filtered): ?><a href="deleted_students.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-check-circle"></i>No deleted students<?php echo $filtered ? ' match this filter' : ''; ?>.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>#</th><th>Student</th><th>Father / contact</th><th>Banglar Shiksha ID</th><th>Last class</th><th>Deleted on / reason</th><th>Actions</th></tr></thead>
        <tbody>
        <?php $sl = 1; foreach ($rows as $r): $needs = (int)$r['last_session_id'] !== $active_session; $why = lifecycle_reason($r['note']); ?>
        <tr>
            <td><?php echo $sl++; ?></td>
            <td><?php echo lifecycle_student_cell($r); ?></td>
            <td><?php echo htmlspecialchars($r['father_name'] ?? ''); ?><?php if ($r['guardian_contact'] ?: $r['mobile']): ?><br><small><i class="fas fa-phone" style="color:#8a9aab"></i> <?php echo htmlspecialchars($r['guardian_contact'] ?: $r['mobile']); ?></small><?php endif; ?></td>
            <td><?php echo htmlspecialchars($r['banglarshiksha_id'] ?? '—'); ?></td>
            <td><?php if ($r['class_name']): ?><span class="lc-tag <?php echo $needs ? 'muted' : 'ok'; ?>"><?php echo htmlspecialchars($r['class_name'] . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['last_roll'] ? ' · Roll ' . $r['last_roll'] : '')); ?></span> <small style="color:#6b7d90"><?php echo htmlspecialchars($r['session_name']); ?></small><?php else: ?><span class="lc-tag muted">never enrolled</span><?php endif; ?>
                <?php if ($needs): ?><br><span class="lc-tag warn" title="Their last enrolment is not in the running session — Restore asks for class, section and roll">needs placement</span><?php endif; ?></td>
            <td class="reason"><?php echo $r['deleted_at'] ? date('d-m-Y', strtotime($r['deleted_at'])) : '—'; ?><?php if ($why): ?><small><?php echo htmlspecialchars($why); ?></small><?php endif; ?></td>
            <td class="lc-actions">
                <a href="<?php echo htmlspecialchars(student_page_url('view_student.php', $r['id'])); ?>" class="btn btn-info btn-sm"><i class="fas fa-eye"></i> View</a>
                <button type="button" class="btn btn-success btn-sm"
                    onclick="lcRestore(<?php echo htmlspecialchars(json_encode($r['id']), ENT_QUOTES, "UTF-8"); ?>, <?php echo htmlspecialchars(json_encode($r['student_name']), ENT_QUOTES, "UTF-8"); ?>, <?php echo $needs ? 'true' : 'false'; ?>, <?php echo (int)$r['last_class_id']; ?>, <?php echo (int)$r['last_section_id']; ?>, <?php echo htmlspecialchars(json_encode((string)$r['last_roll']), ENT_QUOTES, "UTF-8"); ?>)"><i class="fas fa-undo"></i> Restore</button>
                <button type="button" class="btn btn-danger btn-sm" onclick="lcPermanent(<?php echo htmlspecialchars(json_encode($r['id']), ENT_QUOTES, "UTF-8"); ?>, <?php echo htmlspecialchars(json_encode($r['student_name']), ENT_QUOTES, "UTF-8"); ?>)"><i class="fas fa-times"></i> Delete forever</button>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<?php lifecycle_restore_modal($classes, 'deleted'); ?>

<!-- permanent delete: type the UID -->
<div class="lc-modal" id="lcPermModal">
    <form class="lc-dialog" method="post" action="permanent_delete_student.php" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" id="lpUid">
        <h3 style="background:linear-gradient(135deg,#b0454f,#d3646e)"><i class="fas fa-exclamation-triangle"></i> Delete permanently</h3>
        <div class="body">
            <div><b id="lpName"></b> <span class="lc-uid" id="lpUidBadge"></span></div>
            <div class="note" id="lpDeps">Loading what will be removed…</div>
            <div style="margin-top:12px"><label>Type the School UID <span class="danger-word" id="lpUidWord"></span> to confirm</label><input type="text" name="confirm_uid" id="lpConfirm" required placeholder="ULPHS-YYYY-NNNN" style="text-transform:uppercase"></div>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('lcPermModal').classList.remove('open')">Cancel</button>
            <button type="submit" class="btn btn-danger" id="lpSubmit" disabled><i class="fas fa-trash"></i> Delete forever</button>
        </div>
    </form>
</div>
<script>
function lcPermanent(uid, name) {
    document.getElementById('lpUid').value = uid; document.getElementById('lpName').textContent = name;
    document.getElementById('lpUidBadge').textContent = uid; document.getElementById('lpUidWord').textContent = uid;
    var c = document.getElementById('lpConfirm'); c.value = ''; document.getElementById('lpSubmit').disabled = true;
    var d = document.getElementById('lpDeps'); d.textContent = 'Loading what will be removed…';
    var x = new XMLHttpRequest();
    x.open('GET', 'deleted_students.php?deps=' + encodeURIComponent(uid), true);
    x.onload = function () { d.innerHTML = x.status === 200 ? x.responseText : 'Could not load the dependency list.'; };
    x.send();
    document.getElementById('lcPermModal').classList.add('open');
    c.focus();
}
document.getElementById('lpConfirm').addEventListener('input', function () {
    document.getElementById('lpSubmit').disabled = this.value.trim().toUpperCase() !== document.getElementById('lpUid').value;
});
document.getElementById('lcPermModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

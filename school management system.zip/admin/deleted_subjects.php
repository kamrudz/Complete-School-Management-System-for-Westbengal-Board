<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $admin_id = (int)($_SESSION['admin_id'] ?? 0);
    $id = (int)($_POST['restore_id'] ?? $_POST['purge_id'] ?? 0);
    $subject = db_get_row('SELECT subject_name FROM subjects WHERE id = ? AND is_active = 0', 'i', $id);
    if (!$subject) {
        $_SESSION['error'] = 'Subject not found among the deleted ones.';
    } elseif (isset($_POST['restore_id'])) {
        db_execute('UPDATE subjects SET is_active = 1 WHERE id = ?', 'i', $id);
        log_action($admin_id, 'SUBJECT_RESTORED', 'subjects', $id, null, $subject);
        $_SESSION['success'] = $subject['subject_name'] . ' restored.';
    } elseif ($deps = db_dependents('subjects', $id)) {   // marks, routine, results would go with it
        $_SESSION['error'] = $subject['subject_name'] . ' cannot be deleted for ever — it is still used by ' . db_dependents_text($deps) . '.';
    } else {
        db_execute('DELETE FROM subjects WHERE id = ?', 'i', $id);
        log_action($admin_id, 'SUBJECT_PURGED', 'subjects', $id, $subject);
        $_SESSION['success'] = $subject['subject_name'] . ' deleted for ever.';
    }
    header('Location: deleted_subjects.php'); exit;
}

$subjects = db_get_all('SELECT id, subject_name, subject_code FROM subjects WHERE is_active = 0 ORDER BY subject_name');
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deleted Subjects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-trash-alt"></i> Deleted Subjects <small>(<?php echo count($subjects); ?>)</small></div>
        <a href="subjects.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Subjects</a>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <?php if (!$subjects): ?>
    <div class="empty-state"><i class="fas fa-trash-alt"></i><h3>No deleted subjects</h3><p>Every subject is in use.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>#</th><th>Subject</th><th>Code</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($subjects as $i => $s): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><strong><?php echo $h($s['subject_name']); ?></strong></td>
                    <td><?php echo $s['subject_code'] !== null && $s['subject_code'] !== '' ? $h($s['subject_code']) : '—'; ?></td>
                    <td><div class="row-actions">
                        <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="restore_id" value="<?php echo (int)$s['id']; ?>">
                            <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-undo"></i> Restore</button></form>
                        <form method="post" onsubmit="return confirm('Delete <?php echo $h(addslashes($s['subject_name'])); ?> for ever? This cannot be undone.')"><?php echo csrf_field(); ?><input type="hidden" name="purge_id" value="<?php echo (int)$s['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete for ever</button></form>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

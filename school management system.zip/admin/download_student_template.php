<?php
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/student_import.php';

student_import_template();   // built from the importer's own column list, so the two always agree

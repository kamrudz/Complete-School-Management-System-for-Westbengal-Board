<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

$book_id = (int)($_GET['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();

    if (isset($_POST['update_book'])) {
        $title = trim($_POST['title'] ?? '');
        $author = trim($_POST['author'] ?? '');
        $publisher = trim($_POST['publisher'] ?? '');
        $isbn = trim($_POST['isbn'] ?? '');
        $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
        $edition = trim($_POST['edition'] ?? '');
        $price = (float)($_POST['price'] ?? 0);
        $shelf_location = trim($_POST['shelf_location'] ?? '');
        $bid = (int)$_POST['book_id'];

        $stmt = mysqli_prepare($conn, "UPDATE library_books SET title=?, author=?, publisher=?, isbn=?, category_id=?, edition=?, price=?, shelf_location=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "ssssisdsi", $title, $author, $publisher, $isbn, $category_id, $edition, $price, $shelf_location, $bid);
        mysqli_stmt_execute($stmt);
        $_SESSION['success'] = "Book details updated!";
    } elseif (isset($_POST['add_more_copies'])) {
        $bid = (int)$_POST['book_id'];
        $more = max(1, (int)$_POST['more_copies']);
        $copy_stmt = mysqli_prepare($conn, "INSERT INTO library_book_copies (book_id, accession_no, status, added_date) VALUES (?,?,'Available', CURDATE())");
        $generated = [];
        for ($i = 0; $i < $more; $i++) {
            $acc_no = next_accession_no($conn);
            mysqli_stmt_bind_param($copy_stmt, "is", $bid, $acc_no);
            mysqli_stmt_execute($copy_stmt);
            $generated[] = $acc_no;
        }
        $_SESSION['success'] = "$more new copies added: " . implode(', ', $generated);
    } elseif (isset($_POST['update_copy_status'])) {
        $copy_id = (int)$_POST['copy_id'];
        $new_status = $_POST['new_status'];
        if (in_array($new_status, ['Available','Damaged','Lost','Withdrawn'], true)) {
            // A copy that's Issued can't be changed directly — must be handled via return/library_return.php first
            $cur = db_get_row("SELECT status FROM library_book_copies WHERE id=? LIMIT 1", 'i', $copy_id);
            if ($cur && $cur['status'] === 'Issued') {
                $_SESSION['error'] = "This copy is currently issued to someone — close that transaction as Return/Lost first.";
            } else {
                $stmt = mysqli_prepare($conn, "UPDATE library_book_copies SET status=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, "si", $new_status, $copy_id);
                mysqli_stmt_execute($stmt);
                $_SESSION['success'] = "Copy status updated!";
            }
        }
    }
    header("Location: edit_book.php?id=$book_id");
    exit();
}

$book = db_get_row("SELECT * FROM library_books WHERE id=? LIMIT 1", 'i', $book_id);
if (!$book) { header("Location: books.php"); exit(); }

$categories = mysqli_query($conn, "SELECT * FROM library_categories ORDER BY category_name ASC");
$copies = db_query("SELECT * FROM library_book_copies WHERE book_id=? ORDER BY accession_no ASC", 'i', $book_id);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 22px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
.form-row { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 16px; }
.form-group { flex: 1; min-width: 200px; }
.form-group label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-group input, .form-group select { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
table th, table td { padding: 9px 12px; border-bottom: 1px solid #e4edf6; text-align: left; }
table th { background: #003366; color: #fff; }
.badge { padding: 3px 10px; border-radius: 10px; font-size: 11px; font-weight: 700; }
.badge-Available { background: #d4edda; color: #155724; }
.badge-Issued { background: #fff3cd; color: #856404; }
.badge-Damaged { background: #ffe5d0; color: #a45c00; }
.badge-Lost { background: #f8d7da; color: #842029; }
.badge-Withdrawn { background: #e2e3e5; color: #41464b; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-success { background: #d4edda; color: #155724; }
.alert-error { background: #f8d7da; color: #842029; }
.copy-status-form { display: flex; gap: 6px; align-items: center; }
.copy-status-form select { padding: 5px 8px; font-size: 12px; border-radius: 6px; border: 1.5px solid #d0dbe8; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-book-open"></i> <?php echo htmlspecialchars($book['title']); ?></div>
        <a href="books.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Book List</a>
    </div>

    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <div class="form-card">
        <h4 style="color:#003366;margin-bottom:14px;"><i class="fas fa-edit"></i> Book Details</h4>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
            <div class="form-row">
                <div class="form-group" style="flex-basis:100%;"><label>Book Title *</label><input type="text" name="title" value="<?php echo htmlspecialchars($book['title']); ?>" required></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Author</label><input type="text" name="author" value="<?php echo htmlspecialchars($book['author'] ?? ''); ?>"></div>
                <div class="form-group"><label>Publisher</label><input type="text" name="publisher" value="<?php echo htmlspecialchars($book['publisher'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>ISBN</label><input type="text" name="isbn" value="<?php echo htmlspecialchars($book['isbn'] ?? ''); ?>"></div>
                <div class="form-group"><label>Edition</label><input type="text" name="edition" value="<?php echo htmlspecialchars($book['edition'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Category</label>
                    <select name="category_id">
                        <option value="">-- Select --</option>
                        <?php mysqli_data_seek($categories, 0); while ($c = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $book['category_id']==$c['id']?'selected':''; ?>><?php echo htmlspecialchars($c['category_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group"><label>Shelf Location</label><input type="text" name="shelf_location" value="<?php echo htmlspecialchars($book['shelf_location'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Price (₹)</label><input type="number" step="0.01" min="0" name="price" value="<?php echo $book['price']; ?>" required></div>
            </div>
            <button type="submit" name="update_book" class="btn btn-success"><i class="fas fa-save"></i> Update</button>
        </form>
    </div>

    <div class="form-card">
        <h4 style="color:#003366;margin-bottom:14px;"><i class="fas fa-plus-circle"></i> Add More Copies</h4>
        <form method="POST" style="display:flex; gap:10px; align-items:center;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
            <input type="number" name="more_copies" min="1" value="1" style="width:100px; padding:9px 12px; border:2px solid #e4edf6; border-radius:8px;">
            <button type="submit" name="add_more_copies" class="btn btn-primary"><i class="fas fa-plus"></i> Add Copies</button>
        </form>
    </div>

    <div class="form-card">
        <h4 style="color:#003366;margin-bottom:14px;"><i class="fas fa-list"></i> All Copies (Accession Numbers)</h4>
        <div style="overflow-x:auto;">
        <table>
            <tr><th>Accession No</th><th>Status</th><th>Added On</th><th>QR</th><th>Change</th></tr>
            <?php while ($c = mysqli_fetch_assoc($copies)): ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($c['accession_no']); ?></strong></td>
                <td><span class="badge badge-<?php echo $c['status']; ?>"><?php echo $c['status']; ?></span></td>
                <td><?php echo date('d M Y', strtotime($c['added_date'])); ?></td>
                <td><a href="library_book_qr_print.php?copy_id=<?php echo $c['id']; ?>" target="_blank" class="btn btn-primary btn-sm"><i class="fas fa-qrcode"></i> Print</a></td>
                <td>
                    <?php if ($c['status'] === 'Issued'): ?>
                        <small style="color:#6c7a8a;">Must be changed via Library Return</small>
                    <?php else: ?>
                    <form method="POST" class="copy-status-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="copy_id" value="<?php echo $c['id']; ?>">
                        <select name="new_status">
                            <?php foreach (['Available','Damaged','Lost','Withdrawn'] as $st): ?>
                            <option value="<?php echo $st; ?>" <?php echo $c['status']===$st?'selected':''; ?>><?php echo $st; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" name="update_copy_status" class="btn btn-primary btn-sm">Save</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
    </div>
</div>
</body>
</html>

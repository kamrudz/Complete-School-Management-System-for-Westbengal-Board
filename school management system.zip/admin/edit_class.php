<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/class_helper.php';
require_once '../includes/logger.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$row = $id > 0 ? db_get_row('SELECT id, class_name, stage, board_exam FROM classes WHERE id = ?', 'i', $id) : null;
if (!$row) {
    $_SESSION['error'] = 'Class not found.';
    header('Location: classes.php'); exit;
}

if (isset($_POST['update_class'])) {
    verify_csrf_or_die();
    $name = class_name_normalise($_POST['class_name'] ?? '');
    $stage = (string)($_POST['stage'] ?? '');
    $board = !empty($_POST['board_exam']) ? 1 : 0;
    if ($name === $row['class_name'] && $stage === (string)$row['stage'] && $board === (int)$row['board_exam']) { header('Location: classes.php'); exit; }
    $error = class_name_error($name) ?? (class_stage_valid($stage) ? null : 'Choose the stage this class belongs to.');
    if ($error === null) {
        try {
            db_execute('UPDATE classes SET class_name = ?, sort_order = ?, stage = ?, board_exam = ? WHERE id = ?', 'sisii', $name, class_sort_order($name), $stage, $board, $id);
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1062) throw $e;
            $error = "Class $name already exists.";
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header("Location: edit_class.php?id=$id"); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'CLASS_EDITED', 'classes', $id,
        ['class_name' => $row['class_name'], 'stage' => $row['stage'], 'board_exam' => (int)$row['board_exam']], ['class_name' => $name, 'stage' => $stage, 'board_exam' => $board]);
    $_SESSION['success'] = "Class $name saved — " . class_stage_label($stage) . ($board ? ', board-conducted' : '') . '.';
    header('Location: classes.php'); exit;
}

// this class's own numeral plus the ones no other class uses
$names = class_roman_available();
if (!in_array($row['class_name'], $names, true)) $names[] = $row['class_name'];
usort($names, fn($a, $b) => class_sort_order($a) <=> class_sort_order($b));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Class</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:760px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-edit"></i> Edit Class <small>(<?php echo htmlspecialchars($row['class_name'], ENT_QUOTES, 'UTF-8'); ?>)</small></div>
        <a href="classes.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Classes</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
        <div class="form-group">
            <label><i class="fas fa-chalkboard"></i> Class <span class="required">*</span></label>
            <select name="class_name" required>
                <?php foreach ($names as $r): ?><option value="<?php echo $r; ?>" <?php echo $r === $row['class_name'] ? 'selected' : ''; ?>><?php echo $r; ?></option><?php endforeach; ?>
            </select>
            <div class="form-hint">শুধু Roman সংখ্যা (I–XII)। অন্য ক্লাসে ব্যবহৃত নামগুলো তালিকায় নেই। সিরিয়াল নিজে থেকে ঠিক হবে।</div>
        </div>
        <div class="form-group">
            <label><i class="fas fa-layer-group"></i> Stage <span class="required">*</span></label>
            <select name="stage" required>
                <?php foreach (class_stages() as $k => $s): ?><option value="<?php echo $k; ?>" <?php echo $k === (string)$row['stage'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['label'] . ' (' . $s['classes'] . ')', ENT_QUOTES, 'UTF-8'); ?></option><?php endforeach; ?>
            </select>
            <div class="form-hint">grade band, project/formative কলাম আর কোন module-এ class-টা পড়বে — সবই এটা দেখে ঠিক হয়। বদলালে ঐ class-এর ফল ও মেনু সাথে সাথেই বদলাবে।</div>
        </div>
        <div class="form-group">
            <label style="display:flex;align-items:center;gap:8px;font-weight:400"><input type="checkbox" name="board_exam" value="1" <?php echo (int)$row['board_exam'] ? 'checked' : ''; ?> style="width:auto"> এই class-এর পরীক্ষা <b>board</b> নেয়, স্কুল নয়</label>
            <div class="form-hint">টিক থাকলে স্কুলের পরীক্ষা ও marks entry ঐ class-এ থাকবে না।</div>
        </div>
        <div class="btn-group">
            <button type="submit" name="update_class" class="btn btn-success"><i class="fas fa-save"></i> Update Class</button>
            <a href="classes.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
</body>
</html>

<?php
/** One form adds and changes a holiday. Old links land here, so send them on. */
require_once '../includes/auth.php';
require_admin_login();

$id = (int)($_GET['id'] ?? 0);
header('Location: add_holiday.php' . ($id ? '?id=' . $id : ''));
exit();

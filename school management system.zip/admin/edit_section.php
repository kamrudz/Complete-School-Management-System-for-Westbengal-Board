<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/section_helper.php';
require_once '../includes/logger.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$row = $id > 0 ? db_get_row('SELECT id, session_id, class_id, section_name FROM sections WHERE id = ?', 'i', $id) : null;
if (!$row) {
    $_SESSION['error'] = 'Section not found.';
    header('Location: sections.php'); exit;
}
// once anything hangs off the section, moving or renaming it would leave those rows pointing at the wrong class
$deps = db_dependents('sections', $id);
$locked = (bool)$deps;

if (isset($_POST['update_section'])) {
    verify_csrf_or_die();
    $session_id = (int)($_POST['session_id'] ?? 0);
    $class_id = (int)($_POST['class_id'] ?? 0);
    $name = section_name_normalise($_POST['section_name'] ?? '');
    $error = null;
    if ($locked) {
        $error = 'This section cannot be changed — it is in use by ' . db_dependents_text($deps) . '.';
    } elseif (($error = section_name_error($name)) === null) {
        if (!db_get_row('SELECT id FROM academic_sessions WHERE id = ?', 'i', $session_id) || !db_get_row('SELECT id FROM classes WHERE id = ?', 'i', $class_id)) {
            $error = 'Choose a valid session and class.';
        } else {
            try {
                db_execute('UPDATE sections SET session_id = ?, class_id = ?, section_name = ? WHERE id = ?', 'iisi', $session_id, $class_id, $name, $id);
            } catch (mysqli_sql_exception $e) {
                if ((int)$e->getCode() !== 1062) throw $e;
                $error = "Section $name already exists in that class and session.";
            }
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header("Location: edit_section.php?id=$id"); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'SECTION_EDITED', 'sections', $id, $row, ['session_id' => $session_id, 'class_id' => $class_id, 'section_name' => $name]);
    $_SESSION['success'] = 'Section updated.';
    header('Location: sections.php'); exit;
}

$sessions = db_get_all('SELECT id, session_name FROM academic_sessions ORDER BY session_name DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$off = $locked ? ' disabled' : '';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Section</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:820px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-edit"></i> Edit Section <small>(<?php echo $h($row['section_name']); ?>)</small></div>
        <a href="sections.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Sections</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card">
        <?php if ($locked): ?>
        <div class="form-note"><i class="fas fa-lock"></i> <strong>This section is locked.</strong> It is in use by <?php echo $h(db_dependents_text($deps)); ?>. A section with students, marks or a routine attached cannot be renamed, moved or deleted.</div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
        <div class="form-row">
            <div class="form-group"><label><i class="fas fa-calendar-alt"></i> Session <span class="required">*</span></label>
                <select name="session_id" required<?php echo $off; ?>>
                    <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === (int)$row['session_id'] ? 'selected' : ''; ?>><?php echo $h($s['session_name']); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label><i class="fas fa-chalkboard"></i> Class <span class="required">*</span></label>
                <select name="class_id" required<?php echo $off; ?>>
                    <?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === (int)$row['class_id'] ? 'selected' : ''; ?>><?php echo $h($c['class_name']); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label><i class="fas fa-tag"></i> Section Name <span class="required">*</span></label>
                <input type="text" name="section_name" value="<?php echo $h($row['section_name']); ?>" required maxlength="3" pattern="[A-Za-z0-9]{1,3}" title="1–3 letters or digits" style="text-transform:uppercase"<?php echo $off; ?>></div>
        </div>
        <div class="btn-group">
            <?php if (!$locked): ?><button type="submit" name="update_section" class="btn btn-success"><i class="fas fa-save"></i> Update Section</button><?php endif; ?>
            <a href="sections.php" class="btn btn-secondary"><i class="fas fa-times"></i> <?php echo $locked ? 'Back' : 'Cancel'; ?></a>
        </div>
    </form>
</div>
</body>
</html>

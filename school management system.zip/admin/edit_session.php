<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/session_helper.php';
require_once '../includes/logger.php';

// A session can only be renamed: every class, section, enrolment, mark and routine of the year hangs off it.
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$session = $id > 0 ? db_get_row('SELECT id, session_name, status FROM academic_sessions WHERE id = ?', 'i', $id) : null;
if (!$session) {
    $_SESSION['error'] = 'Academic Session not found.';
    header('Location: sessions.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $name = trim((string)($_POST['session_name'] ?? ''));
    if ($name === $session['session_name']) { header('Location: sessions.php'); exit; }
    $error = session_name_error($name);
    if ($error === null) {
        try {
            db_execute('UPDATE academic_sessions SET session_name = ? WHERE id = ?', 'si', $name, $id);
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1062) throw $e;
            $error = "Session '$name' already exists.";
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header("Location: edit_session.php?id=$id"); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'SESSION_RENAMED', 'academic_sessions', $id, ['session_name' => $session['session_name']], ['session_name' => $name]);
    $_SESSION['success'] = "Session renamed to '$name'.";
    header('Location: sessions.php'); exit;
}
$is_active = $session['status'] === 'Active';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rename Academic Session</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:640px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-edit"></i> Rename Academic Session</div>
        <a href="sessions.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Sessions</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card">
        <div class="form-note"><i class="fas fa-info-circle"></i> Only the name can be changed. Sessions are never deleted — the whole year's classes, enrolments, marks and routine belong to one.</div>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo (int)$session['id']; ?>">
        <div class="form-group">
            <label><i class="fas fa-tag"></i> Session Name</label>
            <input type="text" name="session_name" required maxlength="9" pattern="\d{4}(-\d{4})?" title="2026 or 2026-2027" value="<?php echo htmlspecialchars($session['session_name'], ENT_QUOTES, 'UTF-8'); ?>" autofocus>
            <div class="form-hint">Status: <span class="badge badge-<?php echo $is_active ? 'success' : 'danger'; ?>"><?php echo $is_active ? 'ACTIVE' : 'INACTIVE'; ?></span> — a session is made active from the sessions list.</div>
        </div>
        <div class="btn-group">
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button>
            <a href="sessions.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
</body>
</html>

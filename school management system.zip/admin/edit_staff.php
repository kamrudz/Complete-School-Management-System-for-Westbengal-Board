<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/staff_form.php';
require_once '../includes/photo_helper.php';
require_once '../includes/misc_helper.php';

/**
 * Edit Staff — the twin of Add Staff. The Employee ID is locked; service status can be
 * changed here (Transferred / Retired / Deceased need a date); a new photo replaces the old
 * one only after the row is saved. Changed fields are written to the audit log as a diff.
 */
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$staff = $id > 0 ? staff_get_by_id($id) : null;
if (!$staff) { $_SESSION['error'] = 'Staff member not found.'; header('Location: staff.php'); exit(); }

$errors = []; $old = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_staff'])) {
    verify_csrf_or_die();
    $old = $_POST;
    $old['employee_id'] = $staff['employee_id'];               // never changes
    [$data, $errors] = staff_validate($old, $id);
    $data['employee_id'] = $staff['employee_id'];

    $photo = process_student_photo($_FILES['photo'] ?? [], '../uploads/staff/', 10240, 320, 'staff_');
    if (!$photo['ok']) $errors[] = 'Photo: ' . $photo['error'];

    if (!$errors) {
        if ($photo['filename']) $data['photo'] = $photo['filename'];
        if ($data['service_status'] === 'Active') $data['status_date'] = null;
        if ($data['service_status'] !== 'Active') $data['can_login'] = 0;     // a transferred / retired member cannot log in
        try {
            $ok = db_update('staff', $data, ['id' => $id], 'i');
            if ($ok === false) throw new RuntimeException('update failed');
        } catch (mysqli_sql_exception $e) {
            if ($photo['filename']) app_unlink_upload('../uploads/staff/', $photo['filename']);
            $errors[] = (int)$e->getCode() === 1062 ? 'Email / Aadhaar / PAN / government ID already exists for another staff member.' : 'Could not save: ' . $e->getMessage();
        }
        if (!$errors) {
            if ($photo['filename'] && $staff['photo']) app_unlink_upload('../uploads/staff/', $staff['photo']);
            $pw = ($data['can_login'] && empty($staff['login_password'])) ? staff_set_default_password($id, $data['date_of_birth']) : null;
            $diff_old = []; $diff_new = [];
            foreach ($data as $k => $v) { if ((string)($staff[$k] ?? '') !== (string)($v ?? '')) { $diff_old[$k] = $staff[$k]; $diff_new[$k] = $v; } }
            if ($diff_new) log_staff_edit((int)($_SESSION['admin_id'] ?? 0), (string)$id, $diff_old, $diff_new);
            $_SESSION['success'] = "{$data['staff_name']} updated" . ($diff_new ? ' (' . count($diff_new) . ' field' . (count($diff_new) > 1 ? 's' : '') . ' changed).' : ' — nothing had changed.') . ($pw ? " Teacher portal: username {$data['state_govt_id']}, password {$pw} (must be changed at first login)." : '');
            header('Location: view_staff.php?id=' . $id); exit();
        }
    }
}
$v = $old ?: $staff;
if ($old) $v['photo'] = $staff['photo'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Staff — <?php echo sf_h($staff['staff_name']); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php staff_form_styles(); ?>
<style>
    .sf-banner { background: linear-gradient(135deg, #7a4a00 0%, #c77b18 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 6px; box-shadow: 0 8px 24px rgba(122,74,0,.25); }
    .sf-banner img, .sf-banner .ico { width: 54px; height: 54px; border-radius: 14px; object-fit: cover; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; border: 2px solid rgba(255,255,255,.5); }
    .sf-banner h1 { margin: 0; font-size: 21px; display: flex; align-items: center; gap: 10px; }
    .sf-banner h1 .id { background: #fff; color: #7a4a00; font-size: 12px; padding: 2px 10px; border-radius: 999px; letter-spacing: .4px; }
    .sf-banner p { margin: 3px 0 0; font-size: 12.5px; color: #fbe9cf; }
    .sf-banner .links { margin-left: auto; display: flex; gap: 8px; }
    .sf-banner .links a { background: #fff; color: #7a4a00; padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; }
    .sf-banner .links a.ghost { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="sf-banner">
        <?php if ($staff['photo']): ?><img src="<?php echo sf_h(staff_photo_url($staff['photo'])); ?>" alt=""><?php else: ?><div class="ico"><i class="fas fa-user-edit"></i></div><?php endif; ?>
        <div><h1>Edit Staff <span class="id"><?php echo sf_h($staff['employee_id']); ?></span></h1><p><?php echo sf_h($staff['staff_name']); ?> · <?php echo sf_h($staff['designation']); ?> · <?php echo sf_h($staff['service_status']); ?></p></div>
        <div class="links"><a href="view_staff.php?id=<?php echo $id; ?>" class="ghost"><i class="fas fa-eye"></i> Profile</a><a href="staff.php"><i class="fas fa-arrow-left"></i> Staff list</a></div>
    </div>
    <?php if ($errors): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i><ul><?php foreach ($errors as $e): ?><li><?php echo sf_h($e); ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo $id; ?>">
        <?php staff_form_render($v, 'edit'); ?>
        <div class="sf-actions">
            <a href="view_staff.php?id=<?php echo $id; ?>" class="btn btn-secondary">Cancel</a>
            <button type="submit" name="save_staff" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save changes</button>
        </div>
    </form>
</div>
</body>
</html>

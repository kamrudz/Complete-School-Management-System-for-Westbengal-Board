<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/misc_helper.php';
require_once '../includes/sibling_helper.php';
require_once '../includes/security.php';
require_once '../includes/photo_helper.php';
require_once '../includes/document_helper.php';
require_once '../includes/logger.php';

/**
 * The twin of Add Student, with three differences: the session is fixed (moving a year is Promotion's
 * job) and only the current enrolment's class, section and roll can be corrected; the family's own
 * guardian row is updated in place, never swapped for another family's; and a replaced photo or document
 * is deleted only after the save has committed.
 */

$id = student_id_from_request();
if ($id === '') { $_SESSION['error'] = 'No student selected.'; header('Location: students.php'); exit(); }

function back_with_errors(array $errors) {
    global $id;
    $_SESSION['errors_edit_' . $id] = $errors;
    $_SESSION['old_edit_' . $id] = $_POST;
    header('Location: ' . student_page_url('edit_student.php', $id));
    exit();
}

// ---------- Load the student, guardian, current academic row, Madhyamik ----------
$student = db_get_row('SELECT * FROM students WHERE id = ?', 's', $id);
if (!$student) {
    $_SESSION['error'] = 'Student not found.';
    header('Location: students.php');
    exit();
}
$guardian = $student['guardian_id'] ? db_get_row('SELECT * FROM guardians WHERE guardian_id = ?', 'i', $student['guardian_id']) : null;
// the row for the running session; a TC / passed-out student has none, then the latest is shown read-only
$academic = db_get_row("SELECT * FROM student_academic_history WHERE student_id = ? ORDER BY (academic_status = 'Current') DESC, id DESC LIMIT 1", 's', $id);
$academic_editable   = $academic && $academic['academic_status'] === 'Current';
$academic_session_id = (int)($academic['session_id'] ?? 0);
$mp_marks = db_get_row('SELECT * FROM hs_student_mp_marks WHERE student_id = ? LIMIT 1', 's', $id);
$mp_subjects_existing = $mp_marks ? db_get_all('SELECT subject_name, full_marks, marks_obtained FROM hs_student_mp_subject_marks WHERE mp_marks_id = ? ORDER BY id', 'i', $mp_marks['id']) : [];

if (isset($_POST['update_student'])) {
    verify_csrf_or_die();

    $p = fn($k) => app_caps_value_if($k, (string)($_POST[$k] ?? ''));

    // ---------- Student ----------
    $s = [
        'banglarshiksha_id'         => $p('banglarshiksha_id'),
        'pen_id'                    => $p('pen_id'),
        'apaar_id'                  => $p('apaar_id'),
        'student_name'              => $p('student_name'),
        'name_as_per_aadhaar'       => $p('name_as_per_aadhaar'),
        'dob'                       => $p('dob'),
        'gender'                    => $p('gender'),
        'blood_group'               => $p('blood_group'),
        'religion'                  => $p('religion'),
        'caste'                     => $p('caste'),
        'sub_caste'                 => $p('sub_caste'),
        'disability'                => $p('disability'),
        'disability_type'           => $p('disability') === 'Yes' ? $p('disability_type') : '',
        'disability_percentage'     => $p('disability') === 'Yes' ? $p('disability_percentage') : '',
        'birth_registration_number' => $p('birth_registration_number'),
        'student_aadhaar'           => $p('student_aadhaar'),
        'village'                   => $p('village'),
        'post_office'               => $p('post_office'),
        'police_station'            => $p('police_station'),
        'district'                  => $p('district'),
        'state'                     => $p('state'),
        'pin_code'                  => $p('pin_code'),
        'nationality'               => $p('nationality') ?: 'Indian',
        'mother_tongue'             => $p('mother_tongue'),
        'mobile'                    => $p('mobile'),
        'email'                     => $p('email'),
        'bank_name'                 => $p('bank_name'),
        'branch_name'               => $p('branch_name'),
        'account_number'            => $p('account_number'),
        'ifsc_code'                 => strtoupper($p('ifsc_code')),
        'remarks'                   => $p('remarks'),
        'admission_no'              => $p('admission_no'),
        'admission_date'            => $p('admission_date'),
    ];
    $admission_year = $p('admission_year');

    // ---------- Academic (session comes from the DB row, not the form) ----------
    $session_id      = $academic_session_id;
    $class_id        = (int)$p('class_id');
    $section_id      = (int)$p('section_id');
    $roll_no         = $p('roll_no');
    $previous_school = $p('previous_school');

    // ---------- Guardian ----------
    $g = [
        'father_name'          => $p('father_name'),
        'father_aadhaar'       => $p('father_aadhaar'),
        'father_voter_id'      => strtoupper($p('father_voter_id')),
        'father_mobile'        => $p('father_mobile'),
        'father_occupation'    => $p('father_occupation'),
        'father_qualification' => $p('father_qualification'),
        'mother_name'          => $p('mother_name'),
        'mother_aadhaar'       => $p('mother_aadhaar'),
        'mother_voter_id'      => strtoupper($p('mother_voter_id')),
        'mother_occupation'    => $p('mother_occupation'),
        'guardian_name'        => $p('guardian_name'),
        'guardian_relation'    => $p('guardian_relation'),
        'guardian_contact'     => $p('guardian_contact'),
        'guardian_email'       => $p('guardian_email'),
    ];
    $annual_income = $p('annual_income') !== '' ? (float)$p('annual_income') : null;

    // ---------- Validation (same rules as add_student.php) ----------
    $errors = [];
    $all = $s + $g + ['session_id' => $session_id ?: '', 'class_id' => $class_id ?: '', 'section_id' => $section_id ?: '', 'roll_no' => $roll_no];
    foreach (STUDENT_REQUIRED_FIELDS as $key => $label) {
        if (!$academic_editable && in_array($key, ['session_id', 'class_id', 'section_id', 'roll_no'], true)) continue;
        if ((string)$all[$key] === '') $errors[] = "$label is required.";
    }
    $errors = array_merge($errors, array_values(student_validate($s)));
    foreach (['father_aadhaar' => 'Father Aadhaar', 'mother_aadhaar' => 'Mother Aadhaar'] as $k => $label) {
        if (($m = student_v_aadhaar($g[$k])) !== null) $errors[] = "$label: $m";
    }
    foreach (['father_mobile' => 'Father Mobile', 'guardian_contact' => 'Guardian Contact'] as $k => $label) {
        if (($m = student_v_mobile($g[$k])) !== null) $errors[] = "$label: $m";
    }
    foreach (['father_name' => 'Father Name', 'mother_name' => 'Mother Name', 'guardian_name' => 'Guardian Name'] as $k => $label) {
        if (($m = student_v_name($g[$k], $label)) !== null) $errors[] = $m;
    }
    if (($m = student_v_email($g['guardian_email'])) !== null) $errors[] = "Guardian Email: $m";
    if ($s['religion'] !== '' && !in_array($s['religion'], student_religions(), true)) $errors[] = 'Religion is not a valid choice.';
    if ($s['caste'] !== '' && !in_array($s['caste'], student_castes(), true)) $errors[] = 'Caste is not a valid choice.';
    if (($m = student_v_disability_pct($s['disability_percentage'])) !== null) $errors[] = $m;
    if ($s['disability_type'] !== '' && !in_array($s['disability_type'], student_disability_types(), true)) $errors[] = 'Type of Disability is not a valid choice.';
    if ($g['guardian_relation'] !== '' && !in_array($g['guardian_relation'], student_guardian_relations(), true)) $errors[] = 'Guardian Relation is not a valid choice.';
    if ($s['admission_date'] !== '') {
        $d = DateTime::createFromFormat('!Y-m-d', $s['admission_date']);
        if (!$d || $d->format('Y-m-d') !== $s['admission_date']) $errors[] = 'Admission Date must be a valid date.';
        elseif ($d > new DateTime('today')) $errors[] = 'Admission Date cannot be in the future.';
        elseif ($admission_year === '') $admission_year = $d->format('Y');
    }
    if ($admission_year !== '' && (!preg_match('/^\d{4}$/', $admission_year) || (int)$admission_year < 1990 || (int)$admission_year > (int)date('Y') + 1)) {
        $errors[] = 'Admission Year must be a 4-digit year.';
    }
    if ($roll_no !== '' && !preg_match('/^\d{1,4}$/', $roll_no)) $errors[] = 'Roll Number must be digits only (up to 4).';
    if ($annual_income !== null && $annual_income < 0) $errors[] = 'Annual Income cannot be negative.';

    // duplicates — excluding this student
    $errors = array_merge($errors, array_values(student_duplicates($s, $id)));

    if ($academic_editable) {
        if ($class_id && $section_id && !db_get_row('SELECT id FROM sections WHERE id = ? AND class_id = ? AND session_id = ?', 'iii', $section_id, $class_id, $session_id)) {
            $errors[] = 'The selected Section does not belong to that Class and Session.';
        }
        if ($class_id && $section_id && $roll_no !== '') {
            $dup = db_get_row(
                "SELECT s.student_name, s.id FROM student_academic_history h
                 JOIN students s ON s.id = h.student_id
                 WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.roll_no = ? AND h.student_id <> ? LIMIT 1",
                'iiiss', $session_id, $class_id, $section_id, $roll_no, $id);
            if ($dup) $errors[] = "Roll No $roll_no is already allotted to {$dup['student_name']} ({$dup['id']}) in this Session / Class / Section.";
        }
    }

    [$mp, $mp_errors] = student_mp_from_post();
    $errors = array_merge($errors, $mp_errors);

    if ($errors) back_with_errors(array_values(array_unique($errors)));

    // ---------- Uploads: a new file is stored first; the old one is removed only after commit ----------
    $uploaded = []; $to_remove = [];
    $photo_name = $student['photo'];
    $r = process_student_photo($_FILES['photo'] ?? [], "../uploads/students/");
    if (!$r['ok']) back_with_errors([$r['error']]);
    if ($r['filename'] !== null) { $uploaded[] = ["../uploads/students/", $r['filename']]; if ($photo_name) $to_remove[] = ["../uploads/students/", $photo_name]; $photo_name = $r['filename']; }

    $signature_name = $student['signature'];
    $r = process_student_document($_FILES['signature'] ?? [], "../uploads/students/signatures/", 10, 'sig');
    if (!$r['ok']) { foreach ($uploaded as [$d, $f]) app_unlink_upload($d, $f); back_with_errors([$r['error']]); }
    if ($r['filename'] !== null) { $uploaded[] = ["../uploads/students/signatures/", $r['filename']]; if ($signature_name) $to_remove[] = ["../uploads/students/signatures/", $signature_name]; $signature_name = $r['filename']; }

    // birth certificate and Aadhaar card live in the locked folder (uploads/students/docs/, served only via student_doc.php)
    $birth_certificate_name = $student['birth_certificate'];
    $r = student_doc_store_upload($_FILES['birth_certificate'] ?? [], 'birth');
    if (!$r['ok']) { foreach ($uploaded as [$d, $f]) app_unlink_upload($d, $f); back_with_errors([$r['error']]); }
    if ($r['filename'] !== null) { $uploaded[] = [student_docs_dir(), $r['filename']]; if ($birth_certificate_name) $to_remove[] = [student_docs_dir(), $birth_certificate_name]; $birth_certificate_name = $r['filename']; }

    $aadhaar_image_name = $student['student_aadhaar_image'];
    $r = student_doc_store_upload($_FILES['student_aadhaar_image'] ?? [], 'aadhaar');
    if (!$r['ok']) { foreach ($uploaded as [$d, $f]) app_unlink_upload($d, $f); back_with_errors([$r['error']]); }
    if ($r['filename'] !== null) { $uploaded[] = [student_docs_dir(), $r['filename']]; if ($aadhaar_image_name) $to_remove[] = [student_docs_dir(), $aadhaar_image_name]; $aadhaar_image_name = $r['filename']; }

    // ---------- Save: guardians → students → history → Madhyamik, all or nothing ----------
    $s = student_blank_ids_to_null($s);
    if ($s['disability_percentage'] === '') $s['disability_percentage'] = null;
    $adm_year = $admission_year !== '' ? (int)$admission_year : null;
    try {
        db_begin_transaction();

        $guardian_row = $g + [
            'father_aadhaar_not_available' => $g['father_aadhaar'] === '' ? 1 : 0,
            'mother_aadhaar_not_available' => $g['mother_aadhaar'] === '' ? 1 : 0,
            'annual_income' => $annual_income,
        ];
        $guardian_id = (int)($student['guardian_id'] ?? 0);
        if ($guardian_id > 0 && $guardian) {
            // the family's own row: siblings sharing it see the correction too
            db_update('guardians', $guardian_row, ['guardian_id' => $guardian_id], 'i');
        } else {
            // no guardian yet (an old import): share a sibling's row when the details match, else start one
            $guardian_id = find_matching_guardian_id_by_score($conn, $g, 3) ?? (int)db_insert('guardians', $guardian_row);
        }

        db_update('students', $s + [
            'guardian_id' => $guardian_id, 'admission_year' => $adm_year,
            'photo' => $photo_name, 'signature' => $signature_name,
            'birth_certificate' => $birth_certificate_name, 'student_aadhaar_image' => $aadhaar_image_name,
        ], ['id' => $id]);

        if ($academic_editable) {
            db_update('student_academic_history', ['class_id' => $class_id, 'section_id' => $section_id, 'roll_no' => $roll_no, 'previous_school' => $previous_school],
                ['id' => $academic['id']], 'i');
        }
        student_mp_save($id, $mp);

        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        foreach ($uploaded as [$d, $f]) app_unlink_upload($d, $f);
        error_log('edit_student failed: ' . $e->getMessage());
        $msg = ((int)$e->getCode() === 1062)
            ? 'Another student already holds one of these IDs (Banglar Shiksha / PEN / APAAR). Nothing was changed.'
            : 'Could not save the changes — nothing was changed. (' . $e->getMessage() . ')';
        back_with_errors([$msg]);
    }

    // committed — now the replaced files can go
    foreach ($to_remove as [$d, $f]) app_unlink_upload($d, $f);

    // what changed, for the audit log
    $changed = [];
    $same = fn($a, $b) => (is_numeric($a) && is_numeric($b)) ? (float)$a === (float)$b : (string)($a ?? '') === (string)($b ?? '');   // 40.00 vs 40
    foreach ($s as $k => $v) if (!$same($student[$k] ?? null, $v)) $changed[$k] = ['from' => $student[$k] ?? null, 'to' => $v];
    if ($academic_editable) {
        foreach (['class_id' => $class_id, 'section_id' => $section_id, 'roll_no' => $roll_no] as $k => $v) {
            if ((string)($academic[$k] ?? '') !== (string)$v) $changed[$k] = ['from' => $academic[$k], 'to' => $v];
        }
    }
    log_student_edit($_SESSION['admin_id'], $id, null, $changed ? json_encode($changed, JSON_UNESCAPED_UNICODE) : null);

    $_SESSION['success'] = "Changes to {$s['student_name']} saved." . ($changed ? ' ' . count($changed) . ' field(s) updated.' : ' Nothing was different.');
    header('Location: ' . student_page_url('view_student.php', $id));
    exit();
}

// ---------- Form ----------
// Same helpers as add_student.php: $old is the POST after a validation error,
// otherwise the stored record, so every field uses old_val()/old_sel() alike.
$errors = $_SESSION['errors_edit_' . $id] ?? [];
$old    = $_SESSION['old_edit_' . $id] ?? null;
unset($_SESSION['old_edit_' . $id], $_SESSION['errors_edit_' . $id]);
if ($old === null) {
    $old = $student;
    foreach ($guardian ?: [] as $k => $v) if (!array_key_exists($k, $old)) $old[$k] = $v;
    foreach (['class_id', 'section_id', 'roll_no', 'previous_school'] as $k) $old[$k] = $academic[$k] ?? '';
    foreach (['mp_board', 'mp_year', 'mp_roll_no'] as $k) $old[$k] = $mp_marks[$k] ?? '';
    $old['disability_percentage'] = $student['disability_percentage'] !== null ? rtrim(rtrim((string)$student['disability_percentage'], '0'), '.') : '';
    $old['annual_income'] = $guardian && $guardian['annual_income'] !== null ? rtrim(rtrim((string)$guardian['annual_income'], '0'), '.') : '';
    foreach ($old as $k => $v) if ($v === null) $old[$k] = '';
}

function old_val($key, $old, $default = '') {
    return htmlspecialchars((string)($old ? ($old[$key] ?? '') : $default), ENT_QUOTES, 'UTF-8');
}
function old_sel($key, $value, $old) {
    return strcasecmp((string)($old[$key] ?? ''), (string)$value) === 0 ? 'selected' : '';
}
function lbl($key, $text) {
    $star = isset(STUDENT_REQUIRED_FIELDS[$key]) ? ' <span class="req">*</span>' : '';
    return '<label for="f_' . $key . '">' . $text . $star . '</label>';
}
function req($key) { return isset(STUDENT_REQUIRED_FIELDS[$key]) ? ' required' : ''; }

$sections_now = ((int)($old['class_id'] ?? 0) && $academic_session_id)
    ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', (int)$old['class_id'], $academic_session_id) : [];
$sessions = db_get_all("SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC");
// Madhyamik rows: what the admin typed when a save failed, otherwise what is stored
$mp_rows = isset($old['mp_subjects_json'])
    ? array_values(array_filter((array)(json_decode($old['mp_subjects_json'], true) ?: []), 'is_array'))
    : array_map(fn($r) => ['subject' => $r['subject_name'], 'full_marks' => (float)$r['full_marks'], 'marks_obtained' => (float)$r['marks_obtained']], $mp_subjects_existing);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/student_form.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-header">
        <div class="page-title">
            <i class="fas fa-user-edit"></i> Edit Student
            <span class="uid-badge" title="School UID — auto-generated, never changes"><?php echo htmlspecialchars($id, ENT_QUOTES, 'UTF-8'); ?></span>
        </div>
        <div>
            <a href="<?php echo htmlspecialchars(student_page_url('view_student.php', $id)); ?>" class="btn btn-primary"><i class="fas fa-eye"></i> View</a>
            <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back to Students</a>
        </div>
    </div>

    <?php if (!empty($_SESSION['success'])): /* e.g. from Admission finalize, which opens this page */ ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8'); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i>
        <ul><?php foreach ($errors as $e) echo '<li>' . htmlspecialchars($e, ENT_QUOTES, 'UTF-8') . '</li>'; ?></ul>
    </div>
    <?php endif; ?>
    <form method="post" enctype="multipart/form-data" id="addStudentForm" autocomplete="off">
<?php echo csrf_field(); ?>

        <!-- STUDENT -->
        <div class="card card-student">
            <div class="card-head"><i class="fas fa-user-graduate"></i> Student Information</div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c3"><?php echo lbl('banglarshiksha_id', 'Banglar Shiksha ID'); ?>
                        <input type="text" id="f_banglarshiksha_id" name="banglarshiksha_id" inputmode="numeric" pattern="\d{13,14}" maxlength="14" placeholder="14 digits"<?php echo req('banglarshiksha_id'); ?> value="<?php echo old_val('banglarshiksha_id', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('pen_id', 'PEN'); ?>
                        <input type="text" id="f_pen_id" name="pen_id" inputmode="numeric" pattern="\d{11}" maxlength="11" placeholder="11 digits" value="<?php echo old_val('pen_id', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('apaar_id', 'APAAR ID'); ?>
                        <input type="text" id="f_apaar_id" name="apaar_id" inputmode="numeric" pattern="\d{12}" maxlength="12" placeholder="12 digits" value="<?php echo old_val('apaar_id', $old); ?>"></div>
                </div>
                <div class="grid">
                    <div class="f c4"><?php echo lbl('student_name', 'Student Name'); ?>
                        <input type="text" id="f_student_name" name="student_name" maxlength="100"<?php echo req('student_name'); ?> value="<?php echo old_val('student_name', $old); ?>"></div>
                    <div class="f c4"><?php echo lbl('name_as_per_aadhaar', 'Name as per Aadhaar'); ?>
                        <input type="text" id="f_name_as_per_aadhaar" name="name_as_per_aadhaar" maxlength="150" value="<?php echo old_val('name_as_per_aadhaar', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('dob', 'Date of Birth'); ?>
                        <input type="date" id="f_dob" name="dob" max="<?php echo date('Y-m-d'); ?>"<?php echo req('dob'); ?> value="<?php echo old_val('dob', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('gender', 'Gender'); ?>
                        <select id="f_gender" name="gender"<?php echo req('gender'); ?>>
                            <option value="">Select</option>
                            <?php foreach (['Male', 'Female', 'Other'] as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('gender', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                </div>
                <div class="grid">
                    <div class="f c2"><?php echo lbl('religion', 'Religion'); ?>
                        <select id="f_religion" name="religion"<?php echo req('religion'); ?>>
                            <option value="">Select</option>
                            <?php foreach (student_religions() as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('religion', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('caste', 'Caste'); ?>
                        <select id="f_caste" name="caste"<?php echo req('caste'); ?>>
                            <option value="">Select</option>
                            <?php foreach (student_castes() as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('caste', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('sub_caste', 'Sub Caste'); ?>
                        <input type="text" id="f_sub_caste" name="sub_caste" maxlength="50" value="<?php echo old_val('sub_caste', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('blood_group', 'Blood Group'); ?>
                        <select id="f_blood_group" name="blood_group">
                            <option value="">Select</option>
                            <?php foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('blood_group', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('student_aadhaar', 'Student Aadhaar'); ?>
                        <input type="text" id="f_student_aadhaar" name="student_aadhaar" inputmode="numeric" pattern="[2-9]\d{11}" maxlength="12" placeholder="12 digits" value="<?php echo old_val('student_aadhaar', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('mobile', 'Student Mobile'); ?>
                        <input type="tel" id="f_mobile" name="mobile" inputmode="numeric" pattern="[6-9]\d{9}" maxlength="10" placeholder="10 digits" value="<?php echo old_val('mobile', $old); ?>"></div>
                </div>
                <div class="grid">
                    <div class="f c2"><?php echo lbl('disability', 'Disability'); ?>
                        <select id="f_disability" name="disability" onchange="toggleDisabilityType()">
                            <option value="">Select</option>
                            <option value="No" <?php echo old_sel('disability', 'No', $old); ?>>No</option>
                            <option value="Yes" <?php echo old_sel('disability', 'Yes', $old); ?>>Yes</option>
                        </select></div>
                    <div class="f c3 dis-only" hidden><?php echo lbl('disability_type', 'Type of Disability'); ?>
                        <select id="f_disability_type" name="disability_type">
                            <option value="">Select</option>
                            <?php foreach (student_disability_types() as $o): ?><option value="<?php echo htmlspecialchars($o); ?>" <?php echo old_sel('disability_type', $o, $old); ?>><?php echo htmlspecialchars($o); ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c2 dis-only" hidden><?php echo lbl('disability_percentage', 'Disability %'); ?>
                        <input type="number" id="f_disability_percentage" name="disability_percentage" min="0" max="100" step="0.5" placeholder="as per certificate" value="<?php echo old_val('disability_percentage', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('birth_registration_number', 'Birth Registration No.'); ?>
                        <input type="text" id="f_birth_registration_number" name="birth_registration_number" maxlength="50" value="<?php echo old_val('birth_registration_number', $old); ?>"></div>
                    <div class="f c4"><?php echo lbl('email', 'Email'); ?>
                        <input type="email" id="f_email" name="email" maxlength="100" value="<?php echo old_val('email', $old); ?>"></div>
                </div>
            </div>
        </div>
        <!-- GUARDIAN -->
        <div class="card card-guardian">
            <div class="card-head"><i class="fas fa-users"></i> Guardian Information
                <span class="hint">Same guardian details as a sibling already in school → linked automatically</span></div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c4"><?php echo lbl('father_name', 'Father Name'); ?>
                        <input type="text" id="f_father_name" name="father_name" maxlength="150"<?php echo req('father_name'); ?> value="<?php echo old_val('father_name', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('father_aadhaar', 'Father Aadhaar'); ?>
                        <input type="text" id="f_father_aadhaar" name="father_aadhaar" inputmode="numeric" pattern="[2-9]\d{11}" maxlength="12" placeholder="12 digits" value="<?php echo old_val('father_aadhaar', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('father_mobile', 'Father Mobile'); ?>
                        <input type="tel" id="f_father_mobile" name="father_mobile" inputmode="numeric" pattern="[6-9]\d{9}" maxlength="10" placeholder="10 digits" value="<?php echo old_val('father_mobile', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('father_voter_id', 'Father Voter ID'); ?>
                        <input type="text" id="f_father_voter_id" name="father_voter_id" maxlength="20" style="text-transform:uppercase" value="<?php echo old_val('father_voter_id', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('father_occupation', 'Father Occupation'); ?>
                        <input type="text" id="f_father_occupation" name="father_occupation" maxlength="100" value="<?php echo old_val('father_occupation', $old); ?>"></div>
                </div>
                <div class="grid">
                    <div class="f c3"><?php echo lbl('father_qualification', 'Father Qualification'); ?>
                        <input type="text" id="f_father_qualification" name="father_qualification" maxlength="100" placeholder="Madhyamik / H.S / Graduate" value="<?php echo old_val('father_qualification', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('annual_income', 'Annual Income (₹)'); ?>
                        <input type="number" id="f_annual_income" name="annual_income" step="1" min="0" placeholder="Family annual income" value="<?php echo old_val('annual_income', $old); ?>"></div>
                    <div class="f c4"><?php echo lbl('mother_name', 'Mother Name'); ?>
                        <input type="text" id="f_mother_name" name="mother_name" maxlength="150"<?php echo req('mother_name'); ?> value="<?php echo old_val('mother_name', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('mother_aadhaar', 'Mother Aadhaar'); ?>
                        <input type="text" id="f_mother_aadhaar" name="mother_aadhaar" inputmode="numeric" pattern="[2-9]\d{11}" maxlength="12" placeholder="12 digits" value="<?php echo old_val('mother_aadhaar', $old); ?>"></div>
                </div>
                <div class="grid">
                    <div class="f c2"><?php echo lbl('mother_voter_id', 'Mother Voter ID'); ?>
                        <input type="text" id="f_mother_voter_id" name="mother_voter_id" maxlength="20" style="text-transform:uppercase" value="<?php echo old_val('mother_voter_id', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('mother_occupation', 'Mother Occupation'); ?>
                        <input type="text" id="f_mother_occupation" name="mother_occupation" maxlength="100" value="<?php echo old_val('mother_occupation', $old); ?>"></div>
                    <div class="f c4"><?php echo lbl('guardian_name', 'Guardian Name'); ?>
                        <input type="text" id="f_guardian_name" name="guardian_name" maxlength="150" placeholder="Father / Mother / someone else" value="<?php echo old_val('guardian_name', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('guardian_relation', 'Guardian Relation'); ?>
                        <select id="f_guardian_relation" name="guardian_relation">
                            <option value="">Select</option>
                            <?php foreach (student_guardian_relations() as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('guardian_relation', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                </div>
                <div class="grid">
                    <div class="f c4"><?php echo lbl('guardian_contact', 'Guardian Contact'); ?>
                        <input type="tel" id="f_guardian_contact" name="guardian_contact" inputmode="numeric" pattern="[6-9]\d{9}" maxlength="10" placeholder="10-digit mobile"<?php echo req('guardian_contact'); ?> value="<?php echo old_val('guardian_contact', $old); ?>"></div>
                    <div class="f c8"><?php echo lbl('guardian_email', 'Guardian Email'); ?>
                        <input type="email" id="f_guardian_email" name="guardian_email" maxlength="100" value="<?php echo old_val('guardian_email', $old); ?>"></div>
                </div>
            </div>
        </div>

        <!-- ADDRESS -->
        <div class="card card-address">
            <div class="card-head"><i class="fas fa-map-marker-alt"></i> Address</div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c3"><?php echo lbl('village', 'Village / Town'); ?>
                        <input type="text" id="f_village" name="village" maxlength="100" value="<?php echo old_val('village', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('post_office', 'Post Office'); ?>
                        <input type="text" id="f_post_office" name="post_office" maxlength="100" value="<?php echo old_val('post_office', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('police_station', 'Police Station'); ?>
                        <input type="text" id="f_police_station" name="police_station" maxlength="100" value="<?php echo old_val('police_station', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('district', 'District'); ?>
                        <input type="text" id="f_district" name="district" maxlength="100" value="<?php echo old_val('district', $old); ?>"></div>
                </div>
                <div class="grid">
                    <div class="f c3"><?php echo lbl('state', 'State'); ?>
                        <input type="text" id="f_state" name="state" maxlength="100" value="<?php echo old_val('state', $old, 'West Bengal'); ?>"></div>
                    <div class="f c2"><?php echo lbl('pin_code', 'PIN Code'); ?>
                        <input type="text" id="f_pin_code" name="pin_code" inputmode="numeric" pattern="[1-9]\d{5}" maxlength="6" placeholder="6 digits" value="<?php echo old_val('pin_code', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('nationality', 'Nationality'); ?>
                        <input type="text" id="f_nationality" name="nationality" maxlength="50" value="<?php echo old_val('nationality', $old, 'Indian'); ?>"></div>
                    <div class="f c4"><?php echo lbl('mother_tongue', 'Mother Tongue'); ?>
                        <input type="text" id="f_mother_tongue" name="mother_tongue" maxlength="50" placeholder="Bengali" value="<?php echo old_val('mother_tongue', $old); ?>"></div>
                </div>
            </div>
        </div>

        <!-- ACADEMIC -->
        <div class="card card-academic">
            <div class="card-head"><i class="fas fa-book-open"></i> Academic Information
                <span class="hint"><?php echo $academic_editable ? 'Session is fixed — class / section / roll of the running session can be corrected here' : 'No running session (TC / passed out) — shown for reference only'; ?></span></div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c2"><?php echo lbl('session_id', 'Academic Session <i class="fas fa-lock" style="color:#8a9aab;font-size:11px"></i>'); ?>
                        <input type="hidden" name="session_id" value="<?php echo (int)$academic_session_id; ?>">
                        <select id="f_session_id" disabled title="The session cannot be changed here — that is what Promotion is for">
                            <option value="">Select</option>
                            <?php foreach ($sessions as $ss): ?>
                            <option value="<?php echo (int)$ss['id']; ?>" <?php echo ((int)$ss['id'] === (int)$academic_session_id) ? 'selected' : ''; ?>><?php echo htmlspecialchars($ss['session_name']); ?></option>
                            <?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('class_id', 'Class'); ?>
                        <select id="f_class_id" name="class_id"<?php echo req('class_id'), $academic_editable ? '' : ' disabled'; ?>>
                            <option value="">Select</option>
                            <?php foreach (class_rows() as $c): ?>
                            <option value="<?php echo $c['id']; ?>" data-stage="<?php echo $c['stage']; ?>" <?php echo old_sel('class_id', $c['id'], $old); ?>><?php echo htmlspecialchars($c['name']); ?></option>
                            <?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('section_id', 'Section'); ?>
                        <select id="f_section_id" name="section_id"<?php echo req('section_id'), $academic_editable ? '' : ' disabled'; ?>>
                            <option value="">Select Section</option>
                            <?php foreach ($sections_now as $sec): ?><option value="<?php echo (int)$sec['id']; ?>" <?php echo old_sel('section_id', $sec['id'], $old); ?>><?php echo htmlspecialchars($sec['section_name']); ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c2"><?php echo lbl('roll_no', 'Roll Number'); ?>
                        <input type="text" id="f_roll_no" name="roll_no" inputmode="numeric" pattern="\d{1,4}" maxlength="4"<?php echo req('roll_no'), $academic_editable ? '' : ' disabled'; ?> value="<?php echo old_val('roll_no', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('admission_date', 'Admission Date'); ?>
                        <input type="date" id="f_admission_date" name="admission_date" max="<?php echo date('Y-m-d'); ?>"<?php echo req('admission_date'); ?> value="<?php echo old_val('admission_date', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('admission_year', 'Admission Year'); ?>
                        <input type="text" id="f_admission_year" name="admission_year" inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="from date" value="<?php echo old_val('admission_year', $old); ?>">
                        <small>Blank = year of Admission Date.</small></div>
                </div>
                <div class="grid">
                    <div class="f c4"><?php echo lbl('admission_no', 'Admission Register No.'); ?>
                        <input type="text" id="f_admission_no" name="admission_no" maxlength="30" value="<?php echo old_val('admission_no', $old); ?>"></div>
                    <div class="f c8"><?php echo lbl('previous_school', 'Previous School'); ?>
                        <input type="text" id="f_previous_school" name="previous_school" maxlength="200" value="<?php echo old_val('previous_school', $old); ?>"></div>
                </div>
            </div>
        </div>

        <!-- MADHYAMIK (collapsed unless Class XI) -->
        <details class="card card-madhyamik" id="mpCard"<?php echo ($old['mp_board'] ?? '') !== '' || ($old['mp_roll_no'] ?? '') !== '' || $mp_rows ? ' open' : ''; ?>>
            <summary class="card-head"><i class="fas fa-book"></i> Madhyamik (Class X Board) Result
                <span class="hint">Optional — mainly for Class XI admission</span><i class="fas fa-chevron-down chev"></i></summary>
            <div class="card-body">
                <div class="grid">
                    <div class="f c3"><?php echo lbl('mp_board', 'Board'); ?>
                        <select id="f_mp_board" name="mp_board">
                            <option value="">Select</option>
                            <?php foreach (student_mp_boards() as $o): ?><option value="<?php echo $o; ?>" <?php echo old_sel('mp_board', $o, $old); ?>><?php echo $o; ?></option><?php endforeach; ?>
                        </select></div>
                    <div class="f c3"><?php echo lbl('mp_year', 'Year of Passing'); ?>
                        <input type="text" id="f_mp_year" name="mp_year" inputmode="numeric" pattern="\d{4}" maxlength="4" placeholder="<?php echo date('Y'); ?>" value="<?php echo old_val('mp_year', $old); ?>"></div>
                    <div class="f c4"><?php echo lbl('mp_roll_no', 'Madhyamik Roll No.'); ?>
                        <input type="text" id="f_mp_roll_no" name="mp_roll_no" maxlength="30" value="<?php echo old_val('mp_roll_no', $old); ?>"></div>
                </div>
                <table class="mp-subject-table" id="mpSubjectTable">
                    <thead><tr><th>Subject</th><th>Full Marks</th><th>Marks Obtained</th><th></th></tr></thead>
                    <tbody id="mpSubjectBody"></tbody>
                </table>
                <button type="button" class="btn-add-subject" onclick="addMpSubjectRow('', 100, '')"><i class="fas fa-plus"></i> Add Subject</button>
                <div class="mp-total-bar" id="mpTotalBar">Total: 0 / 0 &nbsp; | &nbsp; Percentage: 0%</div>
                <input type="hidden" name="mp_subjects_json" id="mp_subjects_json">
            </div>
        </details>

        <!-- BANK -->
        <div class="card card-bank">
            <div class="card-head"><i class="fas fa-university"></i> Bank Details <span class="hint">For scholarships / DBT</span></div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c4"><?php echo lbl('bank_name', 'Bank Name'); ?>
                        <input type="text" id="f_bank_name" name="bank_name" maxlength="100" value="<?php echo old_val('bank_name', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('branch_name', 'Branch'); ?>
                        <input type="text" id="f_branch_name" name="branch_name" maxlength="100" value="<?php echo old_val('branch_name', $old); ?>"></div>
                    <div class="f c3"><?php echo lbl('account_number', 'Account Number'); ?>
                        <input type="text" id="f_account_number" name="account_number" inputmode="numeric" maxlength="30" value="<?php echo old_val('account_number', $old); ?>"></div>
                    <div class="f c2"><?php echo lbl('ifsc_code', 'IFSC'); ?>
                        <input type="text" id="f_ifsc_code" name="ifsc_code" maxlength="11" pattern="[A-Za-z]{4}0[A-Za-z0-9]{6}" placeholder="SBIN0001234" style="text-transform:uppercase" value="<?php echo old_val('ifsc_code', $old); ?>"></div>
                </div>
            </div>
        </div>

        <!-- DOCUMENTS & REMARKS -->
        <div class="card card-other">
            <div class="card-head"><i class="fas fa-camera"></i> Photo, Signature &amp; Documents</div>
            <div class="card-body">
                <div class="grid">
                    <div class="f c3"><?php echo lbl('photo', 'Student Photo'); ?>
                        <?php if (!empty($student['photo'])): ?><div class="cur"><img src="../uploads/students/<?php echo rawurlencode($student['photo']); ?>" alt="current photo"><span class="lock">current</span></div><?php else: ?><div class="cur"><span class="none">No photo yet</span></div><?php endif; ?>
                        <div class="upl"><input type="file" id="f_photo" name="photo" accept="image/*" data-preview="pv_photo"><img id="pv_photo" class="pv" alt="" hidden></div>
                        <small>Choose a file only to replace the current one. Auto-compressed to ~20 KB.</small></div>
                    <div class="f c3"><?php echo lbl('signature', 'Student Signature'); ?>
                        <?php if (!empty($student['signature'])): ?><div class="cur"><img class="wide" src="../uploads/students/signatures/<?php echo rawurlencode($student['signature']); ?>" alt="current signature"><span class="lock">current</span></div><?php else: ?><div class="cur"><span class="none">No signature yet</span></div><?php endif; ?>
                        <div class="upl"><input type="file" id="f_signature" name="signature" accept="image/*" data-preview="pv_signature"><img id="pv_signature" class="pv pv-wide" alt="" hidden></div>
                        <small>Auto-compressed to ~10 KB.</small></div>
                    <div class="f c3"><?php echo lbl('birth_certificate', 'Birth Certificate'); ?>
                        <?php if (!empty($student['birth_certificate'])): ?><div class="cur"><a href="<?php echo htmlspecialchars(student_doc_url($id, 'birth')); ?>" target="_blank"><img src="<?php echo htmlspecialchars(student_doc_url($id, 'birth')); ?>" alt="current birth certificate"></a><span class="lock">current — click to open</span></div><?php else: ?><div class="cur"><span class="none">Not uploaded yet</span></div><?php endif; ?>
                        <div class="upl"><input type="file" id="f_birth_certificate" name="birth_certificate" accept="image/*" data-preview="pv_birth_certificate"><img id="pv_birth_certificate" class="pv" alt="" hidden></div>
                        <small><i class="fas fa-lock"></i> Locked folder, admin-only. ~80 KB.</small></div>
                    <div class="f c3"><?php echo lbl('student_aadhaar_image', 'Aadhaar Card (image)'); ?>
                        <?php if (!empty($student['student_aadhaar_image'])): ?><div class="cur"><a href="<?php echo htmlspecialchars(student_doc_url($id, 'aadhaar')); ?>" target="_blank"><img src="<?php echo htmlspecialchars(student_doc_url($id, 'aadhaar')); ?>" alt="current Aadhaar card"></a><span class="lock">current — click to open</span></div><?php else: ?><div class="cur"><span class="none">Not uploaded yet</span></div><?php endif; ?>
                        <div class="upl"><input type="file" id="f_student_aadhaar_image" name="student_aadhaar_image" accept="image/*" data-preview="pv_student_aadhaar_image"><img id="pv_student_aadhaar_image" class="pv" alt="" hidden></div>
                        <small><i class="fas fa-lock"></i> Locked folder, admin-only. ~80 KB.</small></div>
                </div>
                <div class="grid">
                    <div class="f c12"><?php echo lbl('remarks', 'Remarks'); ?>
                        <textarea id="f_remarks" name="remarks" rows="2"><?php echo old_val('remarks', $old); ?></textarea></div>
                </div>
            </div>
        </div>

        <div class="actions">
            <span class="legend"><span class="req">*</span> compulsory</span>
            <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back</a>
            <button type="reset" class="btn btn-danger"><i class="fas fa-undo"></i> Undo changes</button>
            <button type="submit" name="update_student" value="1" class="btn btn-success"><i class="fas fa-save"></i> Update Student</button>
        </div>
    </form>
</div>

<script>
function toggleDisabilityType() {
    var show = document.getElementById('f_disability').value === 'Yes';
    document.querySelectorAll('.dis-only').forEach(function (el) { el.hidden = !show; });
}

// ---- Section list follows Session + Class ----
var oldSectionId = "<?php echo old_val('section_id', $old); ?>";
var sessionSel = document.getElementById('f_session_id');
var classSel   = document.getElementById('f_class_id');
var sectionSel = document.getElementById('f_section_id');

function loadSections() {
    var class_id = classSel.value, session_id = sessionSel.value;
    if (class_id === '') { sectionSel.innerHTML = '<option value="">Select Section</option>'; return; }
    if (session_id === '') { sectionSel.innerHTML = '<option value="">Select session first</option>'; return; }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'get_sections.php?class_id=' + encodeURIComponent(class_id) + '&session_id=' + encodeURIComponent(session_id), true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            sectionSel.innerHTML = xhr.responseText;
            if (oldSectionId) { sectionSel.value = oldSectionId; oldSectionId = ''; }
        }
    };
    xhr.send();
}
function toggleMadhyamik() {
    var opt = classSel.options[classSel.selectedIndex];
    if (opt && opt.dataset.stage === 'higher_secondary') document.getElementById('mpCard').open = true;
}
classSel.addEventListener('change', function () { loadSections(); toggleMadhyamik(); });
sessionSel.addEventListener('change', loadSections);

// Admission Year follows Admission Date until the admin types their own
var admDate = document.getElementById('f_admission_date'), admYear = document.getElementById('f_admission_year');
admDate.addEventListener('change', function () {
    if (admYear.value === '' || admYear.dataset.auto === '1') { admYear.value = this.value ? this.value.slice(0, 4) : ''; admYear.dataset.auto = '1'; }
});
admYear.addEventListener('input', function () { this.dataset.auto = '0'; });

window.addEventListener('DOMContentLoaded', function () {
    toggleDisabilityType();
    toggleMadhyamik();   // sections for the saved class were rendered by PHP
});

// ---- Upload previews: show the chosen image so the admin can confirm it is the right file ----
document.querySelectorAll('input[type=file][data-preview]').forEach(function (inp) {
    inp.addEventListener('change', function () {
        var img = document.getElementById(this.dataset.preview);
        var file = this.files && this.files[0];
        if (img.dataset.url) { URL.revokeObjectURL(img.dataset.url); img.dataset.url = ''; }
        if (!file || !file.type.match(/^image\//)) { img.hidden = true; img.removeAttribute('src'); return; }
        var url = URL.createObjectURL(file);
        img.src = url; img.dataset.url = url; img.hidden = false; img.title = file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
    });
});

// ---- Madhyamik subject rows ----
function addMpSubjectRow(name, fullMarks, obtained) {
    var tbody = document.getElementById('mpSubjectBody');
    var tr = document.createElement('tr');
    tr.innerHTML =
        '<td><input type="text" class="mp-subject-name" placeholder="Subject name" value="' + (name || '').replace(/"/g, '&quot;') + '"></td>' +
        '<td><input type="number" class="mp-marks-full" min="1" value="' + (fullMarks || 100) + '"></td>' +
        '<td><input type="number" class="mp-marks-obtained" min="0" value="' + (obtained || '') + '" placeholder="0"></td>' +
        '<td><button type="button" class="mp-remove-row" onclick="this.closest(\'tr\').remove(); recalcMpTotals();"><i class="fas fa-times"></i></button></td>';
    tbody.appendChild(tr);
    tr.querySelectorAll('input').forEach(function (inp) { inp.addEventListener('input', recalcMpTotals); });
    recalcMpTotals();
}
function recalcMpTotals() {
    var totalObtained = 0, totalFull = 0;
    document.querySelectorAll('#mpSubjectBody tr').forEach(function (row) {
        totalFull     += parseFloat(row.querySelector('.mp-marks-full').value) || 0;
        totalObtained += parseFloat(row.querySelector('.mp-marks-obtained').value) || 0;
    });
    var pct = totalFull > 0 ? (totalObtained / totalFull * 100) : 0;
    document.getElementById('mpTotalBar').innerHTML = 'Total: ' + totalObtained + ' / ' + totalFull + ' &nbsp; | &nbsp; Percentage: ' + pct.toFixed(2) + '%';
}
document.getElementById('addStudentForm').addEventListener('submit', function () {
    var subjects = [];
    document.querySelectorAll('#mpSubjectBody tr').forEach(function (row) {
        var name = row.querySelector('.mp-subject-name').value.trim();
        if (name !== '') subjects.push({ subject: name, full_marks: parseFloat(row.querySelector('.mp-marks-full').value) || 0, marks_obtained: parseFloat(row.querySelector('.mp-marks-obtained').value) || 0 });
    });
    document.getElementById('mp_subjects_json').value = JSON.stringify(subjects);
});

<?php echo json_encode($mp_rows, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>.forEach(function (s) {
    addMpSubjectRow(s.subject, s.full_marks, s.marks_obtained);
});
</script>
</body>
</html>

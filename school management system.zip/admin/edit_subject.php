<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/subject_helper.php';
require_once '../includes/logger.php';

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$subject = $id > 0 ? db_get_row('SELECT id, subject_name, subject_code FROM subjects WHERE id = ? AND is_active = 1', 'i', $id) : null;
if (!$subject) {
    $_SESSION['error'] = 'Subject not found.';
    header('Location: subjects.php'); exit;
}

if (isset($_POST['update_subject'])) {
    verify_csrf_or_die();
    $name = subject_name_normalise($_POST['subject_name'] ?? '');
    $code = subject_code_normalise($_POST['subject_code'] ?? '');
    $error = subject_name_error($name) ?? subject_code_error($code);
    if ($error === null) {
        try {
            db_execute('UPDATE subjects SET subject_name = ?, subject_code = ? WHERE id = ?', 'ssi', $name, $code, $id);
        } catch (mysqli_sql_exception $e) {
            if ((int)$e->getCode() !== 1062) throw $e;   // the unique name catches a rename onto another subject
            $error = "Another subject is already named '$name'.";
        }
    }
    if ($error !== null) {
        $_SESSION['error'] = $error;
        header("Location: edit_subject.php?id=$id"); exit;
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'SUBJECT_EDITED', 'subjects', $id, $subject, ['subject_name' => $name, 'subject_code' => $code]);
    $_SESSION['success'] = "$name saved.";
    header('Location: subjects.php'); exit;
}
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Subject</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box" style="max-width:640px">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-edit"></i> Edit Subject <small>(<?php echo $h($subject['subject_name']); ?>)</small></div>
        <a href="subjects.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Subjects</a>
    </div>
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <form method="post" class="form-card">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo (int)$subject['id']; ?>">
        <div class="form-group"><label><i class="fas fa-book"></i> Subject Name <span class="required">*</span></label>
            <input type="text" name="subject_name" value="<?php echo $h($subject['subject_name']); ?>" required maxlength="60"></div>
        <div class="form-group"><label><i class="fas fa-tag"></i> Subject Code</label>
            <input type="text" name="subject_code" value="<?php echo $h($subject['subject_code']); ?>" maxlength="20" style="text-transform:uppercase"></div>
        <div class="btn-group">
            <button type="submit" name="update_subject" class="btn btn-success"><i class="fas fa-save"></i> Update Subject</button>
            <a href="subjects.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
        </div>
    </form>
</div>
</body>
</html>

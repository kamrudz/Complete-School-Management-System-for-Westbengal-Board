<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== SAVE MAPPING =====
if (isset($_POST['save_mapping'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    if ($exam_id <= 0) { header("Location: exam_class_shift.php"); exit(); }

    $class_shift = $_POST['class_shift'] ?? []; // [class_id => shift_id]

    $up = mysqli_prepare($conn, "INSERT INTO exam_class_shift (exam_source, exam_id, class_id, shift_id) VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE shift_id = VALUES(shift_id)");
    // Keep already-saved routine rows in sync if the mapping changes later
    $syncRoutine = mysqli_prepare($conn, "UPDATE exam_routine SET shift_id=? WHERE exam_source=? AND exam_id=? AND class_id=?");

    $saved = 0;
    foreach ($class_shift as $class_id => $shift_id) {
        $class_id = (int)$class_id;
        $shift_id = (int)$shift_id;
        if ($class_id <= 0 || $shift_id <= 0) continue;

        mysqli_stmt_bind_param($up, 'siii', $exam_source, $exam_id, $class_id, $shift_id);
        mysqli_stmt_execute($up);
        $saved++;

        mysqli_stmt_bind_param($syncRoutine, 'isii', $shift_id, $exam_source, $exam_id, $class_id);
        mysqli_stmt_execute($syncRoutine);
    }
    mysqli_stmt_close($up);
    mysqli_stmt_close($syncRoutine);

    $_SESSION['success'] = "$saved টা ক্লাসের shift mapping সেভ হয়েছে। আগে থেকে সেভ করা routine-ও sync হয়ে গেছে।";
    header("Location: exam_class_shift.php?exam_key=" . urlencode($exam_source . ':' . $exam_id));
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')'];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')'];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

$shifts = [];
$mapping = [];
$classes = [];
if ($current_exam) {
    $q = mysqli_query($conn, "SELECT * FROM exam_shifts WHERE exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND exam_id=$exam_id ORDER BY shift_order ASC");
    while ($row = mysqli_fetch_assoc($q)) { $shifts[] = $row; }

    $mq = mysqli_query($conn, "SELECT class_id, shift_id FROM exam_class_shift WHERE exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND exam_id=$exam_id");
    while ($row = mysqli_fetch_assoc($mq)) { $mapping[$row['class_id']] = $row['shift_id']; }

    // Only classes that actually have subjects configured for this exam
    if ($exam_source === 'v-x') {
        $einfo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT session_id FROM exams WHERE id=$exam_id"));
        $sess = (int)($einfo['session_id'] ?? 0);
        $cq = mysqli_query($conn, "
            SELECT DISTINCT c.id, c.class_name, c.sort_order
            FROM exam_class_subjects ecs
            JOIN classes c ON c.id = ecs.class_id
            WHERE ecs.session_id=$sess
            ORDER BY c.sort_order ASC
        ");
    } else {
        $cq = mysqli_query($conn, "
            SELECT DISTINCT c.id, c.class_name, c.sort_order
            FROM hs_exam_subject_marks hesm
            JOIN classes c ON c.id = hesm.class_id
            WHERE hesm.hs_exam_id=$exam_id
            ORDER BY c.sort_order ASC
        ");
    }
    while ($row = mysqli_fetch_assoc($cq)) { $classes[] = $row; }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Class → Shift Mapping</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 900px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 320px; background: #fff; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table select { padding: 6px 8px; border: 1.5px solid #d0dbe8; border-radius: 6px; font-size: 12px; min-width: 220px; }
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }
    .next-step { margin-top: 22px; padding: 14px 18px; background: #f0f7ff; border: 1px solid #cfe3fa; border-radius: 12px; }
    .next-step a { color: #003366; font-weight: 700; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-users-cog"></i> Class → Shift Mapping
        <small>Exam Conduct — ধাপ ২: কোন ক্লাস কোন shift-এ পরীক্ষা দেবে</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Exam</label>
        <select name="exam_key" onchange="this.form.submit()">
            <option value="">-- Select Exam --</option>
            <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
            <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if($current_exam && empty($shifts)): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i>
            এই exam-এর জন্য এখনো কোনো shift সেট করা নেই। আগে
            <a href="exam_shift_settings.php?exam_key=<?php echo urlencode($exam_key); ?>" style="color:#842029;font-weight:700;">Exam Shift Settings</a>-এ গিয়ে shift বসান।
        </div>
    <?php elseif($current_exam): ?>

    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <table>
            <thead><tr><th>Class</th><th>Shift</th></tr></thead>
            <tbody>
            <?php foreach($classes as $c): $sel = $mapping[$c['id']] ?? 0; ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($c['class_name']); ?></strong></td>
                    <td>
                        <select name="class_shift[<?php echo $c['id']; ?>]">
                            <option value="0">-- বাছুন --</option>
                            <?php foreach($shifts as $sh): ?>
                            <option value="<?php echo $sh['id']; ?>" <?php echo ($sel == $sh['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($sh['shift_name']); ?>
                                <?php if($sh['default_start_time']): ?> (<?php echo date('h:i A', strtotime($sh['default_start_time'])); ?>–<?php echo date('h:i A', strtotime($sh['default_end_time'])); ?>)<?php endif; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if(empty($classes)): ?>
                <tr><td colspan="2" style="text-align:center;color:#6c7a8a;padding:20px;">এই exam-এ কোনো ক্লাসের subject config করা নেই।</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        <div style="margin-top:15px;">
            <button type="submit" name="save_mapping" class="btn btn-success"><i class="fas fa-save"></i> Save Mapping</button>
        </div>
    </form>

    <?php if(!empty($mapping)): ?>
    <div class="next-step">
        <i class="fas fa-arrow-right"></i> Mapping সেভ হয়ে গেলে এখন
        <a href="exam_routine.php?exam_key=<?php echo urlencode($exam_key); ?>">Exam Routine</a> পাতায় গিয়ে প্রতিটা ক্লাসের subject-wise date/time বসান —
        shift এখন থেকে এই mapping অনুযায়ী auto বসবে।
    </div>
    <?php endif; ?>

    <?php endif; ?>
</div>
</body>
</html>

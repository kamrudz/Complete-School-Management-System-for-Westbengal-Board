<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== ACTIVE SESSION =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);
$filter_session_id = isset($_GET['filter_session_id']) ? (int)$_GET['filter_session_id'] : $active_session_id;

// ===== TOP STATS =====
$total_rooms = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM exam_rooms WHERE status='Active'"))['c'] ?? 0;
$total_council = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM staff WHERE exclude_from_exam_duty=1 AND service_status='Active'"))['c'] ?? 0;
$total_rules = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM invigilator_rules"))['c'] ?? 0;

// ===== BUILD COMBINED EXAM LIST (V-X + HS) WITH PROGRESS =====
$exam_list = [];

$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$filter_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_list[] = ['source'=>'v-x', 'id'=>$r['id'], 'label'=>$r['exam_name'], 'sub'=>$r['session_name'] ?? ''];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$filter_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_list[] = ['source'=>'hs', 'id'=>$r['id'], 'label'=>$r['exam_name'], 'sub'=>($r['class_name'] ?? '').' • '.$r['academic_year']];
}

foreach ($exam_list as &$ex) {
    $src = mysqli_real_escape_string($conn, $ex['source']);
    $id = (int)$ex['id'];

    // Routine: how many date+shift slots scheduled
    $r1 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c, COUNT(DISTINCT CONCAT(exam_date,'-',shift_id)) slots, COUNT(DISTINCT class_id) classes FROM exam_routine WHERE exam_source='$src' AND exam_id=$id"));
    $ex['routine_rows'] = (int)($r1['c'] ?? 0);
    $ex['routine_slots'] = (int)($r1['slots'] ?? 0);
    $ex['routine_classes'] = (int)($r1['classes'] ?? 0);

    // Rooms/seats planned
    $r2 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) rooms, COALESCE(SUM(benches_used),0) benches FROM exam_room_usage WHERE exam_source='$src' AND exam_id=$id"));
    $ex['rooms_used'] = (int)($r2['rooms'] ?? 0);
    $ex['seats_planned'] = (int)($r2['benches'] ?? 0); // now counts benches, not raw seats

    // Seating generated
    $r3 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM exam_seating_plan WHERE exam_source='$src' AND exam_id=$id"));
    $ex['seated_students'] = (int)($r3['c'] ?? 0);

    // Students actually needed (from participating classes)
    $r4 = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT COUNT(*) c FROM students s
        JOIN student_academic_history sah ON sah.student_id=s.id AND sah.academic_status='Current' AND sah.student_status='Active' AND sah.session_id=$filter_session_id
        WHERE sah.class_id IN (SELECT DISTINCT class_id FROM exam_routine WHERE exam_source='$src' AND exam_id=$id)
    "));
    $ex['students_needed'] = (int)($r4['c'] ?? 0);

    // Duty: how many date+shift slots have at least one duty row, vs total slots
    $r5 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(DISTINCT CONCAT(exam_date,shift)) c FROM exam_duty_roster WHERE exam_source='$src' AND exam_id=$id"));
    $ex['duty_slots_done'] = (int)($r5['c'] ?? 0);

    // Status computation
    if ($ex['routine_slots'] == 0) {
        $ex['stage'] = 'routine';
    } elseif ($ex['seated_students'] == 0) {
        $ex['stage'] = 'seating';
    } elseif ($ex['duty_slots_done'] < $ex['routine_slots']) {
        $ex['stage'] = 'duty';
    } else {
        $ex['stage'] = 'done';
    }
}
unset($ex);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Conduct Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1200px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }

    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 25px; }
    .stat-card { background: #f8f9fa; padding: 14px 18px; border-radius: 12px; border: 1px solid #e4edf6; text-align: center; }
    .stat-card .number { font-size: 24px; font-weight: 700; color: #003366; }
    .stat-card .label { font-size: 11px; color: #6c7a8a; text-transform: uppercase; }
    .stat-card a { text-decoration: none; color: inherit; display: block; }
    .stat-card:hover { border-color: #003366; }

    .quick-links { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 28px; }
    .quick-links a { display: inline-flex; align-items: center; gap: 8px; padding: 9px 16px; background: #003366; color: #fff; border-radius: 8px; text-decoration: none; font-size: 13px; font-weight: 600; }
    .quick-links a:hover { background: #00509e; }
    .quick-links a.secondary { background: #f8f9fa; color: #003366; border: 1.5px solid #e4edf6; }

    .exam-card { border: 1px solid #e4edf6; border-radius: 14px; margin-bottom: 16px; overflow: hidden; }
    .exam-card .head { padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; background: #f8f9fa; }
    .exam-card .head h4 { color: #003366; font-size: 16px; }
    .exam-card .head .sub { font-size: 12px; color: #6c7a8a; margin-top: 2px; }
    .exam-card .body { padding: 16px 20px; }

    .src-tag { font-size: 10px; padding: 2px 9px; border-radius: 10px; font-weight: 700; margin-right: 8px; }
    .src-vx { background:#e2e3ff; color:#3b3fa0; }
    .src-hs { background:#ffe3ec; color:#a03b6f; }

    .progress-steps { display: flex; gap: 6px; margin-bottom: 12px; }
    .pstep { flex: 1; padding: 10px 12px; border-radius: 10px; font-size: 12px; text-align: center; border: 2px solid #e4edf6; }
    .pstep.done { background: #f4fbf6; border-color: #28a745; color: #155724; }
    .pstep.active { background: #fff8e6; border-color: #ffc107; color: #856404; }
    .pstep.pending { background: #f8f9fa; color: #9aa5b1; }
    .pstep i { display: block; margin-bottom: 4px; font-size: 16px; }

    .stage-badge { padding: 3px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; }
    .stage-routine { background: #f8d7da; color: #842029; }
    .stage-seating { background: #fff3cd; color: #856404; }
    .stage-duty { background: #d1ecf1; color: #0c5460; }
    .stage-done { background: #d4edda; color: #155724; }

    .action-links { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .action-links a { font-size: 12px; padding: 6px 12px; border-radius: 6px; text-decoration: none; background: #003366; color: #fff; }
    .action-links a:hover { background: #00509e; }

    .empty-state { text-align: center; padding: 40px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; color: #6c7a8a; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-clipboard-check"></i> Exam Conduct Dashboard
        <small>Routine → Rooms → Seating → Duty — সব exam-এর progress এক নজরে</small>
    </div>

    <div class="stats-row">
        <div class="stat-card"><a href="exam_rooms.php"><div class="number"><?php echo $total_rooms; ?></div><div class="label"><i class="fas fa-door-open"></i> Active Rooms</div></a></div>
        <div class="stat-card"><a href="exam_duty_settings.php"><div class="number"><?php echo $total_council; ?></div><div class="label"><i class="fas fa-user-shield"></i> Academic Council</div></a></div>
        <div class="stat-card"><a href="invigilator_rules.php"><div class="number"><?php echo $total_rules; ?></div><div class="label"><i class="fas fa-sliders-h"></i> Invigilator Rules</div></a></div>
        <div class="stat-card"><a href="exam_routine.php"><div class="number"><?php echo count($exam_list); ?></div><div class="label"><i class="fas fa-file-signature"></i> Total Exams (V-X+HS)</div></a></div>
    </div>

    <div class="quick-links">
        <a href="exam_shift_settings.php"><i class="fas fa-clock"></i> Shift Settings</a>
        <a href="exam_class_shift.php"><i class="fas fa-users-cog"></i> Class → Shift Mapping</a>
        <a href="exam_routine.php"><i class="fas fa-calendar-alt"></i> Exam Routine</a>
        <a href="exam_rooms.php" class="secondary"><i class="fas fa-door-open"></i> Manage Rooms</a>
        <a href="exam_seating_settings.php" class="secondary"><i class="fas fa-cog"></i> Seating Settings</a>
        <a href="invigilator_rules.php" class="secondary"><i class="fas fa-sliders-h"></i> Invigilator Rules</a>
        <a href="exam_duty_settings.php" class="secondary"><i class="fas fa-user-shield"></i> Academic Council</a>
    </div>

    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:18px; flex-wrap:wrap; gap:10px;">
        <h4 style="color:#003366; margin:0;"><i class="fas fa-list"></i> Exam-wise Progress</h4>
        <form method="GET" style="display:flex; align-items:center; gap:8px;">
            <label style="font-size:13px; font-weight:600; color:#003366;"><i class="fas fa-calendar-alt"></i> Session:</label>
            <select name="filter_session_id" onchange="this.form.submit()" style="padding:6px 12px; border:1px solid #d0dbe8; border-radius:6px; font-size:13px;">
                <?php
                $sess_list = mysqli_query($conn, "SELECT * FROM academic_sessions ORDER BY id DESC");
                while($sl = mysqli_fetch_assoc($sess_list)):
                ?>
                <option value="<?php echo (int)$sl['id']; ?>" <?php echo ($filter_session_id == $sl['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($sl['session_name']); ?><?php if($sl['status']==='Active'): ?> (Active)<?php endif; ?>
                </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <?php if(empty($exam_list)): ?>
    <div class="empty-state">
        <i class="fas fa-calendar-times" style="font-size:36px;opacity:.3;"></i>
        <p style="margin-top:10px;">এখনো কোনো Exam (V-X বা HS) বানানো হয়নি।</p>
    </div>
    <?php else: foreach($exam_list as $ex):
        $key = $ex['source'] . ':' . $ex['id'];
        $stage_label = ['routine'=>'Routine বাকি', 'seating'=>'Seating বাকি', 'duty'=>'Duty বাকি', 'done'=>'সব সম্পন্ন'];
    ?>
    <div class="exam-card">
        <div class="head">
            <div>
                <h4><span class="src-tag <?php echo $ex['source']==='hs'?'src-hs':'src-vx'; ?>"><?php echo strtoupper($ex['source']); ?></span><?php echo htmlspecialchars($ex['label']); ?></h4>
                <div class="sub"><?php echo htmlspecialchars($ex['sub']); ?></div>
            </div>
            <span class="stage-badge stage-<?php echo $ex['stage']; ?>"><?php echo $stage_label[$ex['stage']]; ?></span>
        </div>
        <div class="body">
            <div class="progress-steps">
                <div class="pstep <?php echo $ex['routine_slots']>0 ? 'done' : 'active'; ?>">
                    <i class="fas fa-calendar-alt"></i>
                    Routine<br><?php echo $ex['routine_classes']; ?> ক্লাস, <?php echo $ex['routine_slots']; ?> slot
                </div>
                <div class="pstep <?php echo $ex['rooms_used']>0 ? 'done' : ($ex['routine_slots']>0 ? 'active' : 'pending'); ?>">
                    <i class="fas fa-door-open"></i>
                    Rooms<br><?php echo $ex['rooms_used']; ?> রুম, <?php echo $ex['seats_planned']; ?> বেঞ্চ
                </div>
                <div class="pstep <?php echo $ex['seated_students']>0 ? 'done' : ($ex['rooms_used']>0 ? 'active' : 'pending'); ?>">
                    <i class="fas fa-chair"></i>
                    Seating<br><?php echo $ex['seated_students']; ?>/<?php echo $ex['students_needed']; ?> বসানো
                </div>
                <div class="pstep <?php echo ($ex['routine_slots']>0 && $ex['duty_slots_done']>=$ex['routine_slots']) ? 'done' : ($ex['seated_students']>0 ? 'active' : 'pending'); ?>">
                    <i class="fas fa-user-clock"></i>
                    Duty<br><?php echo $ex['duty_slots_done']; ?>/<?php echo $ex['routine_slots']; ?> slot
                </div>
            </div>
            <div class="action-links">
                <a href="exam_shift_settings.php?exam_key=<?php echo urlencode($key); ?>"><i class="fas fa-clock"></i> Shift Settings</a>
                <a href="exam_class_shift.php?exam_key=<?php echo urlencode($key); ?>"><i class="fas fa-users-cog"></i> Mapping</a>
                <a href="exam_routine.php?exam_key=<?php echo urlencode($key); ?>"><i class="fas fa-calendar-alt"></i> Routine</a>
                <a href="exam_routine_print.php?exam_key=<?php echo urlencode($key); ?>" target="_blank"><i class="fas fa-print"></i> Print</a>
                <a href="exam_seating.php?exam_key=<?php echo urlencode($key); ?>"><i class="fas fa-chair"></i> Seating</a>
                <a href="exam_room_display.php?exam_key=<?php echo urlencode($key); ?>" target="_blank"><i class="fas fa-thumbtack"></i> Room Notice</a>
                <a href="exam_duty_roster.php?exam_key=<?php echo urlencode($key); ?>"><i class="fas fa-user-clock"></i> Duty Roster</a>
            </div>
        </div>
    </div>
    <?php endforeach; endif; ?>

</div>
</body>
</html>

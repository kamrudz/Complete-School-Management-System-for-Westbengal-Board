<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

function invig_count_for($conn, $student_count) {
    if ($student_count <= 0) return 0;
    $stmt = mysqli_prepare($conn, "SELECT invigilator_count FROM invigilator_rules WHERE ? BETWEEN min_students AND max_students ORDER BY min_students DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $student_count);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);
    return $row ? (int)$row['invigilator_count'] : 1;
}

// ===== MANUAL DELETE ONE DUTY ROW =====
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_duty_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_duty_id'];
    $exam_source = $_POST['exam_source'];
    $exam_id = (int)$_POST['exam_id'];
    $exam_date = $_POST['exam_date'];
    $shift = $_POST['shift'];
    $stmt = mysqli_prepare($conn, "DELETE FROM exam_duty_roster WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    $_SESSION['success'] = "Duty entry সরানো হয়েছে।";
    header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($shift));
    exit();
}

// ===== MANUAL ADD ONE DUTY ROW =====
if(isset($_POST['manual_add'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    $exam_date = $_POST['exam_date'];
    $shift = $_POST['shift'];
    $room_id = (int)$_POST['room_id'];
    $staff_id = (int)$_POST['staff_id'];

    if ($room_id > 0 && $staff_id > 0) {
        $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO exam_duty_roster (exam_source, exam_id, exam_date, shift, room_id, staff_id, duty_type) VALUES (?,?,?,?,?,?,'Invigilator')");
        mysqli_stmt_bind_param($stmt, 'sissii', $exam_source, $exam_id, $exam_date, $shift, $room_id, $staff_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $_SESSION['success'] = "Manually add করা হয়েছে।";
    }
    header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($shift));
    exit();
}

// ===== COPY DUTY FROM ANOTHER SHIFT (same date, same room) =====
// First Half আর Second Half একই দিনে একই room-এ হলে, এক shift-এর invigilator
// assignment আরেক shift-এ কপি করে দেয়। শুধু যেসব রুমে target shift-এ আসলেই ছাত্র
// বসছে, সেই রুমেই কপি হয় — এরপরও নিচের room-card থেকে ম্যানুয়ালি add/remove করা যায়।
if (isset($_POST['copy_duty'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    $exam_date = $_POST['exam_date'];
    $target_shift = $_POST['shift'];
    $source_shift = $_POST['source_shift'] ?? '';
    $exam_date_sql = mysqli_real_escape_string($conn, $exam_date);
    $target_shift_sql = mysqli_real_escape_string($conn, $target_shift);
    $source_shift_sql = mysqli_real_escape_string($conn, $source_shift);
    $exam_source_sql = mysqli_real_escape_string($conn, $exam_source);

    if ($source_shift === '' || $source_shift === $target_shift) {
        $_SESSION['error'] = "কপি করার জন্য অন্য একটা shift বাছুন।";
        header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($target_shift));
        exit();
    }

    // Target shift-এ যে রুমগুলোয় আসলে ছাত্র বসছে (এইগুলোতেই duty দরকার)
    $target_room_ids = [];
    $rq = mysqli_query($conn, "
        SELECT DISTINCT sp.room_id
        FROM exam_seating_plan sp
        WHERE sp.exam_source='$exam_source_sql' AND sp.exam_id=$exam_id
          AND sp.class_id IN (
              SELECT class_id FROM exam_routine
              WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql'
                AND shift_id=(SELECT id FROM exam_shifts WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND shift_name='$target_shift_sql' LIMIT 1)
          )
    ");
    while ($r = mysqli_fetch_assoc($rq)) { $target_room_ids[] = (int)$r['room_id']; }

    // Source shift-এর duty rows
    $sq = mysqli_query($conn, "SELECT room_id, staff_id FROM exam_duty_roster WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql' AND shift='$source_shift_sql'");
    $by_room = [];
    while ($r = mysqli_fetch_assoc($sq)) { $by_room[(int)$r['room_id']][] = (int)$r['staff_id']; }

    if (empty($by_room)) {
        $_SESSION['error'] = "\"$source_shift\"-এ এখনো কোনো duty assign করা নেই — আগে সেটা করুন, তারপর কপি করুন।";
        header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($target_shift));
        exit();
    }

    $ins = mysqli_prepare($conn, "INSERT IGNORE INTO exam_duty_roster (exam_source, exam_id, exam_date, shift, room_id, staff_id, duty_type) VALUES (?,?,?,?,?,?,'Invigilator')");
    $copied_rooms = 0;
    $skipped_rooms = [];

    foreach ($by_room as $room_id => $staff_ids) {
        if (!in_array($room_id, $target_room_ids, true)) {
            $rn = mysqli_fetch_assoc(mysqli_query($conn, "SELECT room_name FROM exam_rooms WHERE id=$room_id"));
            $skipped_rooms[] = $rn['room_name'] ?? "Room #$room_id";
            continue; // এই রুমে target shift-এ কোনো ছাত্রই বসছে না, তাই duty বসানো হচ্ছে না
        }
        // এই রুমে target shift-এর আগের duty (যদি থাকে) সরিয়ে ফ্রেশ কপি বসানো হচ্ছে
        mysqli_query($conn, "DELETE FROM exam_duty_roster WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql' AND shift='$target_shift_sql' AND room_id=$room_id");
        foreach ($staff_ids as $sid) {
            mysqli_stmt_bind_param($ins, 'sissii', $exam_source, $exam_id, $exam_date, $target_shift, $room_id, $sid);
            mysqli_stmt_execute($ins);
        }
        $copied_rooms++;
    }
    mysqli_stmt_close($ins);

    $msg = "\"$source_shift\" থেকে \"$target_shift\"-এ $copied_rooms টা রুমের duty কপি হয়েছে।";
    if (!empty($skipped_rooms)) {
        $msg .= " ⚠ বাদ পড়েছে (এই shift-এ ছাত্র নেই): " . implode(', ', $skipped_rooms);
    }
    $_SESSION['success'] = $msg;
    header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($target_shift));
    exit();
}

// ===== AUTO-GENERATE DUTY FOR THIS EXAM+DATE+SHIFT =====
if(isset($_POST['generate_duty'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    $exam_date = $_POST['exam_date'];
    $shift = $_POST['shift'];
    $exam_date_sql = mysqli_real_escape_string($conn, $exam_date);
    $shift_sql = mysqli_real_escape_string($conn, $shift);
    $exam_source_sql = mysqli_real_escape_string($conn, $exam_source);

    $checked = $_POST['eligible_staff'] ?? [];
    $checked = array_map('intval', $checked);

    $eligible_pool_ids = [];
    $q = mysqli_query($conn, "SELECT id FROM staff WHERE service_status='Active' AND exclude_from_exam_duty=0 AND designation NOT LIKE '%Head%'");
    while ($r = mysqli_fetch_assoc($q)) { $eligible_pool_ids[] = (int)$r['id']; }

    mysqli_query($conn, "DELETE FROM exam_duty_temp_exclusions WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql'");
    $ins_excl = mysqli_prepare($conn, "INSERT INTO exam_duty_temp_exclusions (exam_source, exam_id, exam_date, staff_id, reason) VALUES (?,?,?,?,'Unchecked at duty generation')");
    foreach ($eligible_pool_ids as $sid) {
        if (!in_array($sid, $checked, true)) {
            mysqli_stmt_bind_param($ins_excl, 'sisi', $exam_source, $exam_id, $exam_date, $sid);
            mysqli_stmt_execute($ins_excl);
        }
    }
    mysqli_stmt_close($ins_excl);

    $available = array_values(array_intersect($eligible_pool_ids, $checked));

    $rooms = [];
    $rq = mysqli_query($conn, "
        SELECT sp.room_id, r.room_name, COUNT(*) AS student_count
        FROM exam_seating_plan sp
        JOIN exam_rooms r ON r.id = sp.room_id
        WHERE sp.exam_source='$exam_source_sql' AND sp.exam_id=$exam_id
          AND sp.class_id IN (
              SELECT class_id FROM exam_routine
              WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql'
                AND shift_id=(SELECT id FROM exam_shifts WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND shift_name='$shift_sql' LIMIT 1)
          )
        GROUP BY sp.room_id, r.room_name
        ORDER BY r.room_name ASC
    ");
    while ($r = mysqli_fetch_assoc($rq)) { $rooms[] = $r; }

    if (empty($rooms)) {
        $_SESSION['error'] = "এই তারিখ ও শিফটে কোনো রুমে ছাত্র বসানো নেই। আগে Exam Routine ও Seating ঠিক করুন।";
        header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($shift));
        exit();
    }

    $load = array_fill_keys($available, 0);
    $lq = mysqli_query($conn, "SELECT staff_id, COUNT(*) c FROM exam_duty_roster WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id GROUP BY staff_id");
    while ($r = mysqli_fetch_assoc($lq)) {
        $sid = (int)$r['staff_id'];
        if (isset($load[$sid])) { $load[$sid] = (int)$r['c']; }
    }

    mysqli_query($conn, "DELETE FROM exam_duty_roster WHERE exam_source='$exam_source_sql' AND exam_date='$exam_date_sql' AND shift='$shift_sql' AND room_id IN (SELECT room_id FROM exam_seating_plan WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id GROUP BY room_id)");

    $pool = $available;
    $ins = mysqli_prepare($conn, "INSERT IGNORE INTO exam_duty_roster (exam_source, exam_id, exam_date, shift, room_id, staff_id, duty_type) VALUES (?,?,?,?,?,?,'Invigilator')");
    $shortfall_rooms = [];

    foreach ($rooms as $room) {
        $need = invig_count_for($conn, (int)$room['student_count']);
        usort($pool, function($a, $b) use ($load) { return $load[$a] <=> $load[$b]; });

        $assigned_here = 0;
        while ($assigned_here < $need && !empty($pool)) {
            $staff_id = array_shift($pool);
            mysqli_stmt_bind_param($ins, 'sissii', $exam_source, $exam_id, $exam_date, $shift, $room['room_id'], $staff_id);
            mysqli_stmt_execute($ins);
            $load[$staff_id] = ($load[$staff_id] ?? 0) + 1;
            $assigned_here++;
        }
        if ($assigned_here < $need) {
            $shortfall_rooms[] = $room['room_name'] . " (দরকার $need, পাওয়া গেছে $assigned_here)";
        }
    }
    mysqli_stmt_close($ins);

    if (!empty($shortfall_rooms)) {
        $_SESSION['error'] = "Duty generate হয়েছে, কিন্তু এই রুমগুলোয় যথেষ্ট শিক্ষক পাওয়া যায়নি: " . implode(', ', $shortfall_rooms) . " — ম্যানুয়ালি যোগ করুন অথবা কাউকে re-check করুন।";
    } else {
        $_SESSION['success'] = "Duty roster generate হয়ে গেছে — " . count($rooms) . " টা রুমের জন্য।";
    }
    header("Location: exam_duty_roster.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&exam_date=$exam_date&shift=" . urlencode($shift));
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')'];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')'];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;
$exam_source_sql = $exam_source ? mysqli_real_escape_string($conn, $exam_source) : '';

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

$date_shifts = [];
if ($current_exam) {
    $q = mysqli_query($conn, "
        SELECT DISTINCT er.exam_date, es.shift_name AS shift
        FROM exam_routine er
        JOIN exam_shifts es ON es.id = er.shift_id
        WHERE er.exam_source='$exam_source_sql' AND er.exam_id=$exam_id
        ORDER BY er.exam_date ASC, es.shift_order ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $date_shifts[] = $r; }
}
$exam_date = $_GET['exam_date'] ?? '';
$shift = $_GET['shift'] ?? '';
$exam_date_sql = mysqli_real_escape_string($conn, $exam_date);
$shift_sql = mysqli_real_escape_string($conn, $shift);

$staff_rows = [];
$temp_excluded_ids = [];
if ($current_exam && $exam_date && $shift) {
    $q = mysqli_query($conn, "SELECT id, staff_name, designation, exclude_from_exam_duty FROM staff WHERE service_status='Active' ORDER BY staff_name ASC");
    while ($r = mysqli_fetch_assoc($q)) { $staff_rows[] = $r; }

    $eq = mysqli_query($conn, "SELECT staff_id FROM exam_duty_temp_exclusions WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql'");
    while ($r = mysqli_fetch_assoc($eq)) { $temp_excluded_ids[] = (int)$r['staff_id']; }
}

$roster_by_room = [];
if ($current_exam && $exam_date && $shift) {
    $q = mysqli_query($conn, "
        SELECT dr.*, s.staff_name, r.room_name
        FROM exam_duty_roster dr
        JOIN staff s ON s.id = dr.staff_id
        JOIN exam_rooms r ON r.id = dr.room_id
        WHERE dr.exam_source='$exam_source_sql' AND dr.exam_id=$exam_id AND dr.exam_date='$exam_date_sql' AND dr.shift='$shift_sql'
        ORDER BY r.room_name ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $roster_by_room[$r['room_id']][] = $r; }
}
$rooms_needed = [];
if ($current_exam && $exam_date && $shift) {
    $q = mysqli_query($conn, "
        SELECT sp.room_id, r.room_name, COUNT(*) AS student_count
        FROM exam_seating_plan sp
        JOIN exam_rooms r ON r.id = sp.room_id
        WHERE sp.exam_source='$exam_source_sql' AND sp.exam_id=$exam_id
          AND sp.class_id IN (
              SELECT class_id FROM exam_routine
              WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND exam_date='$exam_date_sql'
                AND shift_id=(SELECT id FROM exam_shifts WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND shift_name='$shift_sql' LIMIT 1)
          )
        GROUP BY sp.room_id, r.room_name
        ORDER BY r.room_name ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $rooms_needed[] = $r; }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Duty Roster</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1200px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }

    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }

    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display:flex; gap:12px; flex-wrap:wrap; align-items:end;}
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 220px; background: #fff; }
    .filter-box label { font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px; }

    .staff-list { border: 1px solid #e4edf6; border-radius: 12px; overflow: hidden; margin-bottom: 20px; max-height: 380px; overflow-y: auto; }
    .staff-row { display: flex; align-items: center; gap: 12px; padding: 9px 16px; border-bottom: 1px solid #e4edf6; }
    .staff-row:last-child { border-bottom: none; }
    .staff-row.disabled { background: #f8f9fa; opacity: .6; }
    .staff-row .name { font-weight: 600; color: #1a3b55; font-size: 13px; }
    .staff-row .desig { font-size: 11px; color: #6c7a8a; }
    .staff-row .tag { font-size: 10px; padding: 1px 8px; border-radius: 10px; background: #fff3cd; color: #856404; margin-left: 6px; }

    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-primary { background: #003366; color: #fff; }
    .btn-outline { background: #fff; border: 2px solid #003366; color: #003366; }
    .btn-success { background: #28a745; color: #fff; }
    .btn-danger { background: #dc3545; color: #fff; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }

    .room-card { border: 1px solid #e4edf6; border-radius: 12px; margin-bottom: 14px; overflow: hidden; }
    .room-card h5 { background: #f0f7ff; padding: 10px 16px; color: #003366; display:flex; justify-content: space-between; align-items:center; }
    .room-card .body { padding: 12px 16px; }
    .duty-chip { display:inline-flex; align-items:center; gap:8px; background:#f8f9fa; border:1px solid #e4edf6; padding:5px 10px; border-radius:8px; margin:4px 6px 4px 0; font-size:12px; }
    .add-form { display:flex; gap:8px; margin-top:8px; }
    .add-form select { padding:6px 8px; border:1.5px solid #d0dbe8; border-radius:6px; font-size:12px; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-user-clock"></i> Exam Duty Roster
        <small>Exam Conduct — Daily Invigilator Duty, Auto + Manual (V-X ও HS)</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <div>
            <label>Exam</label>
            <select name="exam_key" onchange="this.form.submit()">
                <option value="">-- Select Exam --</option>
                <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
                <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                    <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if($current_exam && !empty($date_shifts)): ?>
        <div>
            <label>Date + Shift</label>
            <select name="date_shift" onchange="var v=this.value.split('|');this.form.exam_date.value=v[0];this.form.shift.value=v[1];this.form.submit();">
                <option value="">-- Select --</option>
                <?php foreach($date_shifts as $ds):
                    $val = $ds['exam_date'] . '|' . $ds['shift'];
                    $selected = ($exam_date == $ds['exam_date'] && $shift == $ds['shift']);
                ?>
                <option value="<?php echo $val; ?>" <?php echo $selected ? 'selected' : ''; ?>><?php echo date('d M Y', strtotime($ds['exam_date'])); ?> — <?php echo $ds['shift']; ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="exam_date" value="<?php echo htmlspecialchars($exam_date); ?>">
            <input type="hidden" name="shift" value="<?php echo htmlspecialchars($shift); ?>">
        </div>
        <?php elseif($current_exam): ?>
        <div class="alert alert-info" style="margin:0;">এই exam-এর Routine এখনো বানানো হয়নি।</div>
        <?php endif; ?>
    </form>

    <?php if($current_exam && $exam_date && $shift): ?>

    <?php if(empty($rooms_needed)): ?>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> এই তারিখ+শিফটে কোনো রুমে ছাত্র বসানো নেই। আগে Exam Seating করুন।</div>
    <?php else: ?>

    <h4 style="color:#003366;margin-bottom:8px;"><i class="fas fa-users"></i> আজকের জন্য কারা Duty-তে যোগ্য (uncheck করলে বাদ)</h4>
    <p style="font-size:12px;color:#6c7a8a;margin-bottom:10px;">ধূসর/disabled যাদের — তারা Academic Council অথবা Head of Institute, স্থায়ীভাবে duty পান না।</p>

    <form method="POST" id="genForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
    <input type="hidden" name="exam_date" value="<?php echo htmlspecialchars($exam_date); ?>">
    <input type="hidden" name="shift" value="<?php echo htmlspecialchars($shift); ?>">
    <div class="staff-list">
        <?php foreach($staff_rows as $s):
            $is_head = stripos($s['designation'] ?? '', 'head') !== false;
            $is_council = !empty($s['exclude_from_exam_duty']);
            $is_permanently_excluded = $is_head || $is_council;
            $is_temp_excluded = in_array($s['id'], $temp_excluded_ids, true);
            $checked = !$is_permanently_excluded && !$is_temp_excluded;
        ?>
        <div class="staff-row <?php echo $is_permanently_excluded ? 'disabled' : ''; ?>">
            <input type="checkbox" name="eligible_staff[]" value="<?php echo $s['id']; ?>"
                <?php echo $checked ? 'checked' : ''; ?>
                <?php echo $is_permanently_excluded ? 'disabled' : ''; ?>>
            <div>
                <span class="name"><?php echo htmlspecialchars($s['staff_name']); ?></span>
                <?php if($is_council): ?><span class="tag">Academic Council</span><?php endif; ?>
                <?php if($is_head): ?><span class="tag">Head of Institute</span><?php endif; ?>
                <div class="desig"><?php echo htmlspecialchars($s['designation'] ?? ''); ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <button type="submit" name="generate_duty" class="btn btn-success"><i class="fas fa-magic"></i> Generate Duty Roster</button>
    </form>

    <hr style="margin:30px 0;border:none;border-top:1px solid #e4edf6;">
    <h4 style="color:#003366;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
        <span><i class="fas fa-clipboard-list"></i> Duty Roster — <?php echo date('d M Y', strtotime($exam_date)); ?>, <?php echo htmlspecialchars($shift); ?></span>
    </h4>

    <?php
    // একই তারিখে অন্য কোনো shift আছে কিনা (থাকলে "কপি করুন" অপশন দেখানো হবে)
    $same_date_other_shifts = [];
    foreach ($date_shifts as $ds) {
        if ($ds['exam_date'] === $exam_date && $ds['shift'] !== $shift) { $same_date_other_shifts[] = $ds['shift']; }
    }
    ?>
    <?php if (!empty($same_date_other_shifts)): ?>
    <form method="POST" style="display:flex; gap:8px; align-items:center; margin-bottom:16px; background:#f0f7ff; padding:10px 14px; border-radius:10px;">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <input type="hidden" name="exam_date" value="<?php echo htmlspecialchars($exam_date); ?>">
        <input type="hidden" name="shift" value="<?php echo htmlspecialchars($shift); ?>">
        <label style="font-size:12px; font-weight:600; color:#003366;"><i class="fas fa-clone"></i> একই room-এ অন্য shift-এর invigilator কপি করুন:</label>
        <select name="source_shift" style="padding:6px 10px; border:1.5px solid #d0dbe8; border-radius:6px; font-size:12px;">
            <option value="">-- Shift বাছুন --</option>
            <?php foreach ($same_date_other_shifts as $os): ?>
            <option value="<?php echo htmlspecialchars($os); ?>"><?php echo htmlspecialchars($os); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" name="copy_duty" class="btn btn-primary btn-sm" onclick="return confirm('এই shift-এর আগের duty (যদি থাকে) মুছে সিলেক্ট করা shift থেকে কপি হবে। এগোবেন?')"><i class="fas fa-copy"></i> Copy করুন</button>
        <span style="font-size:11px; color:#6c7a8a;">(কপির পরও নিচে ম্যানুয়ালি add/remove করা যাবে)</span>
    </form>
    <?php endif; ?>

    <?php foreach($rooms_needed as $room):
        $rid = $room['room_id'];
        $assigned = $roster_by_room[$rid] ?? [];
        $assigned_ids = array_column($assigned, 'staff_id');
    ?>
    <div class="room-card">
        <h5>
            <span><?php echo htmlspecialchars($room['room_name']); ?> — <?php echo $room['student_count']; ?> জন ছাত্র</span>
            <span><?php echo count($assigned); ?> জন invigilator</span>
        </h5>
        <div class="body">
            <?php if(empty($assigned)): ?>
            <p style="color:#dc3545;font-size:13px;"><i class="fas fa-exclamation-triangle"></i> কোনো invigilator assign করা হয়নি।</p>
            <?php else: foreach($assigned as $a): ?>
            <span class="duty-chip">
                <?php echo htmlspecialchars($a['staff_name']); ?>
                <form method="post" style="display:inline;" onsubmit="return confirm('Remove this duty?')">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="delete_duty_id" value="<?php echo $a['id']; ?>">
                    <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
                    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                    <input type="hidden" name="exam_date" value="<?php echo htmlspecialchars($exam_date); ?>">
                    <input type="hidden" name="shift" value="<?php echo htmlspecialchars($shift); ?>">
                    <button type="submit" style="border:none;background:none;color:#dc3545;cursor:pointer;">✕</button>
                </form>
            </span>
            <?php endforeach; endif; ?>

            <form method="post" class="add-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
                <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                <input type="hidden" name="exam_date" value="<?php echo htmlspecialchars($exam_date); ?>">
                <input type="hidden" name="shift" value="<?php echo htmlspecialchars($shift); ?>">
                <input type="hidden" name="room_id" value="<?php echo $rid; ?>">
                <select name="staff_id">
                    <option value="">+ Manually add teacher...</option>
                    <?php foreach($staff_rows as $s):
                        if (in_array($s['id'], $assigned_ids, true)) continue;
                    ?>
                    <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['staff_name']); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="manual_add" class="btn btn-primary btn-sm">Add</button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>
<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== SAVE (bulk update) =====
if(isset($_POST['save_council'])) {
    verify_csrf_or_die();

    // Reset everyone first, then mark only the checked ones — simplest way
    // to keep this in sync with whatever the admin submits.
    mysqli_query($conn, "UPDATE staff SET exclude_from_exam_duty=0");

    $ids = $_POST['council_staff'] ?? [];
    if (!empty($ids)) {
        $ids = array_map('intval', $ids);
        $ids = array_filter($ids, fn($v) => $v > 0);
        if (!empty($ids)) {
            $in = implode(',', $ids);
            mysqli_query($conn, "UPDATE staff SET exclude_from_exam_duty=1 WHERE id IN ($in)");
        }
    }

    $_SESSION['success'] = count($ids) . " জন staff-কে Academic Council হিসেবে চিহ্নিত করা হলো — তারা কোনো exam-এই invigilation duty পাবেন না।";
    header("Location: exam_duty_settings.php");
    exit();
}

// ===== LIST ALL ACTIVE STAFF =====
$staff_list = mysqli_query($conn, "SELECT id, staff_name, designation, exclude_from_exam_duty FROM staff WHERE service_status='Active' ORDER BY staff_name ASC");
$total_staff = mysqli_num_rows($staff_list);
$excluded_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM staff WHERE service_status='Active' AND exclude_from_exam_duty=1"));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Council Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 900px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .desc { font-size: 13px; color: #6c7a8a; margin-bottom: 20px; }

    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; display: flex; align-items: center; gap: 12px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 20px; }
    .stat-card { background: #f8f9fa; padding: 12px 18px; border-radius: 12px; border: 1px solid #e4edf6; text-align: center; }
    .stat-card .number { font-size: 22px; font-weight: 700; color: #003366; }
    .stat-card .label { font-size: 11px; color: #6c7a8a; text-transform: uppercase; }

    .staff-list { border: 1px solid #e4edf6; border-radius: 12px; overflow: hidden; margin-bottom: 20px; }
    .staff-row { display: flex; align-items: center; gap: 12px; padding: 12px 18px; border-bottom: 1px solid #e4edf6; }
    .staff-row:last-child { border-bottom: none; }
    .staff-row:hover { background: #f8f9fa; }
    .staff-row input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; flex-shrink: 0; }
    .staff-row label { display: flex; flex-direction: column; cursor: pointer; flex: 1; }
    .staff-row .name { font-weight: 600; color: #1a3b55; font-size: 14px; }
    .staff-row .desig { font-size: 12px; color: #6c7a8a; }

    .search-box { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; width: 100%; margin-bottom: 15px; font-size: 13px; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 24px; border: none; border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; text-decoration: none; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }

    .empty-state { text-align: center; padding: 40px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; color: #6c7a8a; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-user-shield"></i> Academic Council Settings
        <small>Exam Conduct — Duty Exclusion (Permanent)</small>
    </div>
    <p class="desc">যেসব staff exam পরিচালনা করেন (Academic Council-এর সদস্য), তাদের চেকবক্স টিক দিন — তারা কোনো exam-এই invigilation duty-তে auto-assign হবেন না। এটা প্রতিটা exam-এর জন্য প্রযোজ্য, একবার সেট করলেই চলবে।</p>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <div class="stats-row">
        <div class="stat-card">
            <div class="number"><?php echo $total_staff; ?></div>
            <div class="label"><i class="fas fa-users"></i> Total Active Staff</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $excluded_count; ?></div>
            <div class="label"><i class="fas fa-user-shield"></i> Academic Council</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $total_staff - $excluded_count; ?></div>
            <div class="label"><i class="fas fa-user-check"></i> Duty-Eligible</div>
        </div>
    </div>

    <?php if($total_staff === 0): ?>
    <div class="empty-state">
        <i class="fas fa-users" style="font-size:40px;opacity:.3;"></i>
        <p style="margin-top:10px;">কোনো Active staff পাওয়া যায়নি।</p>
    </div>
    <?php else: ?>

    <input type="text" class="search-box" id="staffSearch" placeholder="🔍 নাম দিয়ে খুঁজুন...">

    <form method="POST">
    <?php echo csrf_field(); ?>
        <div class="staff-list" id="staffList">
            <?php mysqli_data_seek($staff_list, 0); while($s = mysqli_fetch_assoc($staff_list)): ?>
            <div class="staff-row" data-name="<?php echo strtolower(htmlspecialchars($s['staff_name'])); ?>">
                <input type="checkbox" name="council_staff[]" id="staff_<?php echo $s['id']; ?>" value="<?php echo $s['id']; ?>" <?php echo $s['exclude_from_exam_duty'] ? 'checked' : ''; ?>>
                <label for="staff_<?php echo $s['id']; ?>">
                    <span class="name"><?php echo htmlspecialchars($s['staff_name']); ?></span>
                    <span class="desig"><?php echo htmlspecialchars($s['designation'] ?? ''); ?></span>
                </label>
            </div>
            <?php endwhile; ?>
        </div>
        <button type="submit" name="save_council" class="btn btn-success"><i class="fas fa-save"></i> Save Academic Council List</button>
    </form>

    <?php endif; ?>
</div>

<script>
document.getElementById('staffSearch')?.addEventListener('input', function() {
    var q = this.value.toLowerCase();
    document.querySelectorAll('.staff-row').forEach(function(row) {
        row.style.display = row.dataset.name.includes(q) ? 'flex' : 'none';
    });
});
</script>

</body>
</html>

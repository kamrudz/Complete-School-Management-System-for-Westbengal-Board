<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once("../includes/security.php");

$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

if (isset($_POST['add_room'])) {
    verify_csrf_or_die();
    $room_name = mysqli_real_escape_string($conn, trim($_POST['room_name']));
    $location  = mysqli_real_escape_string($conn, trim($_POST['location']));
    $gender    = in_array($_POST['default_gender'] ?? '', ['Boys','Girls','Any'], true) ? $_POST['default_gender'] : 'Any';
    $benches   = max(1, (int)($_POST['benches'] ?? 1));

    if ($room_name === '') {
        $_SESSION['error'] = "Room Name আবশ্যক।";
        header("Location: exam_room_config.php"); exit();
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO exam_rooms (room_name, location, default_gender, benches, status) VALUES (?, ?, ?, ?, 'Active')");
    mysqli_stmt_bind_param($stmt, 'sssi', $room_name, $location, $gender, $benches);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['success'] = "Room সফলভাবে যোগ হয়েছে!";
    header("Location: exam_room_config.php"); exit();
}

if (isset($_POST['update_room'])) {
    verify_csrf_or_die();
    $id       = (int)$_POST['room_id'];
    $room_name = mysqli_real_escape_string($conn, trim($_POST['room_name']));
    $location  = mysqli_real_escape_string($conn, trim($_POST['location']));
    $gender    = in_array($_POST['default_gender'] ?? '', ['Boys','Girls','Any'], true) ? $_POST['default_gender'] : 'Any';
    $benches   = max(1, (int)($_POST['benches'] ?? 1));
    $status    = ($_POST['status'] === 'Inactive') ? 'Inactive' : 'Active';

    if ($room_name === '') {
        $_SESSION['error'] = "Room Name আবশ্যক।";
        header("Location: exam_room_config.php"); exit();
    }

    $stmt = mysqli_prepare($conn, "UPDATE exam_rooms SET room_name=?, location=?, default_gender=?, benches=?, status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'sssisi', $room_name, $location, $gender, $benches, $status, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['success'] = "Room সফলভাবে আপডেট হয়েছে!";
    header("Location: exam_room_config.php"); exit();
}

if (isset($_POST['delete_room'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['room_id'];
    $in_use = false;

    $chk = @mysqli_prepare($conn, "SELECT id FROM exam_room_usage WHERE room_id=? LIMIT 1");
    if ($chk) {
        mysqli_stmt_bind_param($chk, 'i', $id);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) { $in_use = true; }
        mysqli_stmt_close($chk);
    }
    if (!$in_use) {
        $chk2 = @mysqli_prepare($conn, "SELECT id FROM exam_seating_plan WHERE room_id=? LIMIT 1");
        if ($chk2) {
            mysqli_stmt_bind_param($chk2, 'i', $id);
            mysqli_stmt_execute($chk2);
            mysqli_stmt_store_result($chk2);
            if (mysqli_stmt_num_rows($chk2) > 0) { $in_use = true; }
            mysqli_stmt_close($chk2);
        }
    }

    if ($in_use) {
        $_SESSION['error'] = "এই রুমটি আগে থেকেই কোনো Exam এ ব্যবহৃত হয়েছে, তাই ডিলিট করা যাবে না। 'Inactive' করে দিন।";
    } else {
        $stmt = mysqli_prepare($conn, 'DELETE FROM exam_rooms WHERE id=?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $_SESSION['success'] = "Room সফলভাবে ডিলিট হয়েছে!";
    }
    header("Location: exam_room_config.php"); exit();
}

if (isset($_POST['auto_assign_rooms'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];

    if ($exam_id <= 0) {
        $_SESSION['error'] = "Exam সিলেক্ট করুন।";
        header("Location: exam_room_config.php"); exit();
    }

    $settings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT seats_per_bench FROM exam_seating_settings WHERE exam_source='".mysqli_real_escape_string($conn,$exam_source)."' AND exam_id=$exam_id"));
    $spb = max(1, (int)($settings['seats_per_bench'] ?? 2));

    $shifts = mysqli_query($conn, "SELECT id, shift_name FROM exam_shifts WHERE exam_source='".mysqli_real_escape_string($conn,$exam_source)."' AND exam_id=$exam_id ORDER BY shift_order ASC");

    $active_rooms = [];
    $rq = mysqli_query($conn, "SELECT id, default_gender, benches FROM exam_rooms WHERE status='Active' ORDER BY id ASC");
    while ($rr = mysqli_fetch_assoc($rq)) { $active_rooms[] = $rr; }

    mysqli_query($conn, "DELETE FROM exam_room_usage WHERE exam_source='".mysqli_real_escape_string($conn,$exam_source)."' AND exam_id=$exam_id");

    $ins = mysqli_prepare($conn, "INSERT INTO exam_room_usage (exam_source, exam_id, shift_id, room_id, gender, benches_used) VALUES (?,?,?,?,?,?)");

    $assigned = 0;
    $warnings = [];

    while ($shift = mysqli_fetch_assoc($shifts)) {
        $sid = (int)$shift['id'];
        $sn = $shift['shift_name'];

        $need = ['Boys' => 0, 'Girls' => 0];
        $nq = mysqli_query($conn, "
            SELECT s.gender, COUNT(*) c
            FROM students s
            JOIN student_academic_history sah ON sah.student_id=s.id AND sah.academic_status='Current' AND sah.student_status='Active' AND sah.session_id=$active_session_id
            JOIN exam_routine er ON er.class_id=sah.class_id AND er.exam_source='".mysqli_real_escape_string($conn,$exam_source)."' AND er.exam_id=$exam_id
            JOIN exam_shifts esh ON esh.id=er.shift_id AND esh.id=$sid
            WHERE s.student_status='Active'
            GROUP BY s.gender
        ");
        while ($nr = mysqli_fetch_assoc($nq)) {
            if ($nr['gender'] === 'Male') $need['Boys'] = (int)$nr['c'];
            if ($nr['gender'] === 'Female') $need['Girls'] = (int)$nr['c'];
        }

        foreach (['Boys', 'Girls'] as $gen) {
            $remaining = $need[$gen];
            foreach ($active_rooms as $room) {
                if ($remaining <= 0) break;
                $rg = $room['default_gender'];
                if ($rg !== $gen && $rg !== 'Any') continue;

                $room_benches = (int)$room['benches'];
                $cap = $room_benches * $spb;
                if ($cap <= 0) continue;

                $seats_needed = min($remaining, $cap);
                $benches_use = (int)ceil($seats_needed / $spb);
                if ($benches_use > $room_benches) $benches_use = $room_benches;

                $gbind = $gen;
                mysqli_stmt_bind_param($ins, 'ssiiii', $exam_source, $exam_id, $sid, $room['id'], $gbind, $benches_use);
                mysqli_stmt_execute($ins);
                $remaining -= ($benches_use * $spb);
                if ($remaining < 0) $remaining = 0;
                $assigned++;
            }
            if ($remaining > 0) {
                $warnings[] = "$sn $gen: $remaining জন বাকি (সিট কম)।";
            }
        }
    }
    mysqli_stmt_close($ins);

    $msg = "Auto-assign সম্পন্ন: $assigned টি রুম-শিফট নির্ধারিত।";
    if (!empty($warnings)) $msg .= " " . implode(' ', $warnings);
    $_SESSION['success'] = $msg;
    header("Location: exam_room_config.php?exam_key=" . urlencode($exam_source . ':' . $exam_id));
    exit();
}

if (isset($_POST['save_room_usage'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];

    if ($exam_id <= 0) {
        $_SESSION['error'] = "Exam সিলেক্ট করুন।";
        header("Location: exam_room_config.php"); exit();
    }

    $shift_id  = (int)($_POST['shift_id'] ?? 0);
    $room_ids  = $_POST['room_id'] ?? [];
    $bench_arr = $_POST['benches_used'] ?? [];
    $genders   = $_POST['gender'] ?? [];

    mysqli_query($conn, "DELETE FROM exam_room_usage WHERE exam_source='".mysqli_real_escape_string($conn,$exam_source)."' AND exam_id=$exam_id AND shift_id=$shift_id");

    $ins = mysqli_prepare($conn, "INSERT INTO exam_room_usage (exam_source, exam_id, shift_id, room_id, gender, benches_used) VALUES (?,?,?,?,?,?)");
    $saved = 0;
    foreach ($room_ids as $rid) {
        $rid = (int)$rid;
        if (empty($_POST['use_room'][$rid])) continue;
        $bu  = max(1, (int)($bench_arr[$rid] ?? 1));
        $gen = in_array($genders[$rid] ?? '', ['Boys','Girls'], true) ? $genders[$rid] : 'Boys';
        mysqli_stmt_bind_param($ins, 'ssiiii', $exam_source, $exam_id, $shift_id, $rid, $gen, $bu);
        mysqli_stmt_execute($ins);
        $saved++;
    }
    mysqli_stmt_close($ins);

    $_SESSION['success'] = "$saved টি রুম সেভ হয়েছে।";
    header("Location: exam_room_config.php?exam_key=" . urlencode($exam_source . ':' . $exam_id));
    exit();
}

// ===== DATA QUERIES =====
$rooms_data = mysqli_query($conn, "SELECT * FROM exam_rooms ORDER BY id ASC");
$total_rooms = mysqli_num_rows($rooms_data);
$active_rooms = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM exam_rooms WHERE status='Active'"));

$gender_stats = ['Boys' => 0, 'Girls' => 0, 'Any' => 0];
$gs = mysqli_query($conn, "SELECT default_gender, COUNT(*) c FROM exam_rooms WHERE status='Active' GROUP BY default_gender");
while ($r = mysqli_fetch_assoc($gs)) { $gender_stats[$r['default_gender']] = (int)$r['c']; }

$total_benches = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(benches),0) AS c FROM exam_rooms WHERE status='Active'"))['c'];

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name FROM exams e WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name']];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.class_id, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '')];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;
$exam_source_esc = $exam_source ? mysqli_real_escape_string($conn, $exam_source) : '';

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

$settings = null;
$shifts_data = [];
$shift_room_usage = [];
$shift_needs = [];
$shift_totals = [];
$all_room_usage = [];
$all_room_usage_total = 0;

if ($current_exam) {
    $settings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT seats_per_bench, arrangement_mode FROM exam_seating_settings WHERE exam_source='$exam_source_esc' AND exam_id=$exam_id"));
    if (!$settings) {
        mysqli_query($conn, "INSERT INTO exam_seating_settings (exam_source, exam_id, seats_per_bench, arrangement_mode) VALUES ('$exam_source_esc', $exam_id, 2, 'mixed')");
        $settings = ['seats_per_bench' => 2, 'arrangement_mode' => 'mixed'];
    }

    $sq = mysqli_query($conn, "SELECT id, shift_name, shift_order, default_start_time, default_end_time FROM exam_shifts WHERE exam_source='$exam_source_esc' AND exam_id=$exam_id ORDER BY shift_order ASC");
    while ($s = mysqli_fetch_assoc($sq)) { $shifts_data[] = $s; }

    foreach ($shifts_data as $sh) {
        $sid = (int)$sh['id'];
        $need = ['Boys' => 0, 'Girls' => 0];
        $nq = mysqli_query($conn, "
            SELECT s.gender, COUNT(*) c
            FROM students s
            JOIN student_academic_history sah ON sah.student_id=s.id AND sah.academic_status='Current' AND sah.student_status='Active' AND sah.session_id=$active_session_id
            JOIN exam_routine er ON er.class_id=sah.class_id AND er.exam_source='$exam_source_esc' AND er.exam_id=$exam_id
            JOIN exam_shifts esh ON esh.id=er.shift_id AND esh.id=$sid
            WHERE s.student_status='Active'
            GROUP BY s.gender
        ");
        while ($nr = mysqli_fetch_assoc($nq)) {
            if ($nr['gender'] === 'Male') $need['Boys'] = (int)$nr['c'];
            if ($nr['gender'] === 'Female') $need['Girls'] = (int)$nr['c'];
        }
        $shift_needs[$sid] = $need;

        $shift_totals[$sid] = ['boys_seats' => 0, 'girls_seats' => 0, 'rooms' => 0];
        $ru = mysqli_query($conn, "SELECT ru.*, r.room_name, r.location, r.benches FROM exam_room_usage ru JOIN exam_rooms r ON r.id=ru.room_id WHERE ru.exam_source='$exam_source_esc' AND ru.exam_id=$exam_id AND ru.shift_id=$sid ORDER BY r.id ASC");
        $shift_room_usage[$sid] = [];
        while ($rr = mysqli_fetch_assoc($ru)) {
            $shift_room_usage[$sid][] = $rr;
            $seats = (int)$rr['benches_used'] * (int)$settings['seats_per_bench'];
            $all_room_usage[] = $rr;
            $all_room_usage_total += $seats;
            if ($rr['gender'] === 'Boys') { $shift_totals[$sid]['boys_seats'] += $seats; }
            else { $shift_totals[$sid]['girls_seats'] += $seats; }
            $shift_totals[$sid]['rooms']++;
        }
    }
}

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, school_address, established_year FROM school_settings WHERE id=1"));
$spb = $settings ? (int)$settings['seats_per_bench'] : 2;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Room Config</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1200px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; display: flex; align-items: center; gap: 12px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 20px; }
    .stat-card { background: #f8f9fa; padding: 12px 18px; border-radius: 12px; border: 1px solid #e4edf6; text-align: center; }
    .stat-card .number { font-size: 22px; font-weight: 700; color: #003366; }
    .stat-card .label { font-size: 11px; color: #6c7a8a; text-transform: uppercase; }
    .filter-box { background: #f8f9fa; padding: 15px 18px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
    .filter-box label { font-size: 13px; font-weight: 600; color: #1a3b55; }
    .filter-box select { padding: 8px 14px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 300px; background: #fff; font-size: 13px; }
    .form-card { background: #f8f9fa; padding: 20px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .form-card h4 { color: #003366; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
    .form-row { display: grid; gap: 12px; align-items: end; }
    .form-row.cols-5 { grid-template-columns: 1.4fr 1.4fr 0.7fr 0.5fr 0.5fr; }
    .form-group { display: flex; flex-direction: column; }
    .form-group label { font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 4px; }
    .form-group input, .form-group select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 13px; background: #fff; }
    .form-group input:focus, .form-group select:focus { outline: none; border-color: #1f5b8a; }
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 8px 18px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; text-decoration: none; transition: all 0.2s ease; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }
    .btn-primary { background: #003366; color: #fff; }
    .btn-danger { background: #dc3545; color: #fff; }
    .btn-warning { background: #ffc107; color: #212529; }
    .btn-info { background: #17a2b8; color: #fff; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }
    .table-responsive { overflow-x: auto; margin-top: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    table th { background: #003366; color: #fff; padding: 10px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table tr:hover { background: #f0f7ff; }
    table input[type="number"], table select { padding: 6px 8px; border: 1.5px solid #d0dbe8; border-radius: 6px; font-size: 12px; width: 80px; }
    .badge { padding: 2px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; display: inline-block; }
    .badge-active { background: #d4edda; color: #155724; }
    .badge-inactive { background: #f1f3f5; color: #6c757d; }
    .section-title { font-size: 18px; font-weight: 700; color: #003366; margin: 25px 0 12px 0; display: flex; align-items: center; gap: 10px; }
    .section-title small { font-size: 13px; font-weight: 400; color: #6c7a8a; }
    .empty-state { text-align: center; padding: 40px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; }
    .empty-state i { font-size: 48px; color: #003366; opacity: 0.3; }
    .empty-state h3 { color: #003366; margin-top: 15px; }
    .shift-card { border: 2px solid #e4edf6; border-radius: 14px; margin-bottom: 20px; overflow: hidden; }
    .shift-card .shift-header { background: linear-gradient(135deg, #003366, #1a5276); color: #fff; padding: 14px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
    .shift-card .shift-header h4 { font-size: 16px; margin: 0; }
    .shift-card .shift-header .shift-meta { font-size: 12px; opacity: 0.85; }
    .shift-card .shift-body { padding: 16px 20px; }
    .need-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 16px; }
    .need-card { padding: 14px 18px; border-radius: 12px; border: 2px solid #e4edf6; }
    .need-card.ok { border-color: #28a745; background: #f4fbf6; }
    .need-card.short { border-color: #dc3545; background: #fdf4f4; }
    .need-card b { font-size: 20px; color: #003366; }
    .need-card .lbl { font-size: 12px; color: #6c7a8a; text-transform: uppercase; margin-bottom: 4px; }
    .suggestion-box { background: #e8f4fd; border: 2px solid #b6d9f7; border-radius: 12px; padding: 14px 18px; margin-bottom: 16px; display: flex; align-items: center; gap: 12px; }
    .suggestion-box i { font-size: 22px; color: #0056b3; }
    .suggestion-box .text { font-size: 13px; color: #003366; font-weight: 600; }
    .gender-label { display: inline-flex; align-items: center; gap: 4px; font-size: 12px; font-weight: 600; }
    @media (max-width: 768px) {
        .form-row.cols-5 { grid-template-columns: 1fr; }
        .stats-row { grid-template-columns: repeat(2, 1fr); }
        .filter-box { flex-direction: column; align-items: flex-start; }
        .filter-box select { min-width: 100%; }
        .page-box { padding: 15px; }
    }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
    <style>
    @media print {
        body { background: #fff; padding: 0; }
        .no-print { display: none !important; }
        .page-box { box-shadow: none; padding: 10px; }
        #printArea { display: block !important; }
    }
    #printArea { display: none; }
    </style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title no-print">
        <i class="fas fa-door-open"></i> Exam Room Configuration
        <small>Room Master + Shift-wise Allocation — পরীক্ষার কক্ষ ব্যবস্থাপনা</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="stats-row no-print">
        <div class="stat-card">
            <div class="number"><?php echo $total_rooms; ?></div>
            <div class="label"><i class="fas fa-door-open"></i> মোট রুম</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $active_rooms; ?></div>
            <div class="label"><i class="fas fa-check-circle"></i> Active</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $total_benches; ?></div>
            <div class="label"><i class="fas fa-th"></i> মোট Benches</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $total_benches * $spb; ?></div>
            <div class="label"><i class="fas fa-chair"></i> মোট Seats (<?php echo $spb; ?>×)</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Boys']; ?></div>
            <div class="label">👦 Boys Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Girls']; ?></div>
            <div class="label">👧 Girls Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Any']; ?></div>
            <div class="label">⚪ Any Rooms</div>
        </div>
    </div>

    <!-- SECTION 1: ADD ROOM -->
    <div class="form-card no-print">
        <h4><i class="fas fa-plus-circle"></i> Add New Room</h4>
        <p style="font-size:12px;color:#6c7a8a;margin-bottom:12px;">Room-এর মোট Bench সংখ্যা দিন। Seats/Bench পরীক্ষা অনুযায়ী নির্ধারিত হবে (Exam Settings থেকে)।</p>
        <form method="POST">
        <?php echo csrf_field(); ?>
            <div class="form-row cols-5">
                <div class="form-group">
                    <label><i class="fas fa-door-open"></i> Room Name</label>
                    <input type="text" name="room_name" placeholder="e.g., Room 101 / কক্ষ ১০১" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-map-marker-alt"></i> Location</label>
                    <input type="text" name="location" placeholder="e.g., 1st Floor">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-th"></i> Benches</label>
                    <input type="number" name="benches" min="1" value="10" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-venus-mars"></i> Gender</label>
                    <select name="default_gender">
                        <option value="Any">Any</option>
                        <option value="Boys">Boys</option>
                        <option value="Girls">Girls</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button type="submit" name="add_room" class="btn btn-success"><i class="fas fa-save"></i> Add</button>
                </div>
            </div>
        </form>
    </div>

    <!-- SECTION 2: ROOM LIST -->
    <h4 class="section-title no-print"><i class="fas fa-list"></i> Room List <small>(<?php echo $total_rooms; ?> rooms)</small></h4>
    <div class="table-responsive no-print">
        <?php if($total_rooms > 0): ?>
        <?php
        mysqli_data_seek($rooms_data, 0);
        $all_rooms_arr = [];
        while ($rr = mysqli_fetch_assoc($rooms_data)) { $all_rooms_arr[] = $rr; }
        $grouped_rooms = ['Boys' => [], 'Girls' => [], 'Any' => []];
        foreach ($all_rooms_arr as $r) {
            $g = $r['default_gender'] ?? 'Any';
            if (isset($grouped_rooms[$g])) { $grouped_rooms[$g][] = $r; }
            else { $grouped_rooms['Any'][] = $r; }
        }
        ?>
        <?php foreach (['Boys', 'Girls', 'Any'] as $glabel): ?>
        <?php if (empty($grouped_rooms[$glabel])) continue; ?>
        <h5 style="color:#003366;margin:16px 0 8px;"><i class="fas fa-<?php echo $glabel==='Boys'?'male':($glabel==='Girls'?'female':'circle'); ?>"></i> <?php echo $glabel; ?> Rooms (<?php echo count($grouped_rooms[$glabel]); ?>)</h5>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Room Name</th>
                    <th>Location</th>
                    <th>Gender</th>
                    <th>Benches</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $sl = 1; foreach($grouped_rooms[$glabel] as $row): ?>
                <tr>
                    <td><?php echo $sl++; ?></td>
                    <td><strong><?php echo htmlspecialchars($row['room_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($row['location'] ?? ''); ?></td>
                    <td>
                        <?php $gicon = ['Boys'=>'👦 Boys','Girls'=>'👧 Girls','Any'=>'⚪ Any']; ?>
                        <?php echo $gicon[$row['default_gender']] ?? 'Any'; ?>
                    </td>
                    <td><strong><?php echo (int)$row['benches']; ?></strong></td>
                    <td>
                        <?php if($row['status'] === 'Active'): ?>
                        <span class="badge badge-active">Active</span>
                        <?php else: ?>
                        <span class="badge badge-inactive">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editRoom(<?php echo $row['id']; ?>, '<?php echo htmlspecialchars($row['room_name'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($row['location'] ?? '', ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$row['benches']; ?>, '<?php echo htmlspecialchars($row['default_gender'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8'); ?>')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="post" style="display:inline;" onsubmit="return confirm('এই রুমটি ডিলিট করতে চান?')">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="room_id" value="<?php echo (int)$row['id']; ?>">
                            <button type="submit" name="delete_room" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-door-open"></i>
            <h3>কোনো Room পাওয়া যায়নি</h3>
            <p>উপরের ফর্ম থেকে প্রথম Room যোগ করুন।</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- SECTION 3: EXAM ALLOCATION -->
    <hr style="margin:30px 0;border:none;border-top:1px solid #e4edf6;" class="no-print">
    <h4 class="section-title no-print"><i class="fas fa-calendar-check"></i> Exam-wise Room Allocation <small>Exam সিলেক্ট করে Shift-wise Auto-Assign বা Manual করুন</small></h4>

    <form method="GET" class="filter-box no-print">
        <label><i class="fas fa-file-alt"></i> Exam নির্বাচন করুন:</label>
        <select name="exam_key" onchange="this.form.submit()">
            <option value="">-- Select Exam --</option>
            <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
            <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if($current_exam): ?>
    <div style="margin-bottom:12px; font-size:13px; color:#003366; font-weight:600;">
        <i class="fas fa-info-circle"></i> Seats/Bench: <strong><?php echo $spb; ?></strong> | Arrangement: <strong><?php echo htmlspecialchars($settings['arrangement_mode'] ?? 'mixed'); ?></strong>
    </div>

    <!-- AUTO-ASSIGN -->
    <form method="POST" style="margin-bottom:15px;" onsubmit="return confirm('Auto-Assign করলে সব Shift-এর Room Assignment নতুন করে তৈরি হবে। এগোবেন?')">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo htmlspecialchars($exam_source); ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <button type="submit" name="auto_assign_rooms" class="btn btn-info">
            <i class="fas fa-magic"></i> Auto-Assign Rooms (All Shifts)
        </button>
    </form>

    <?php if(!empty($shifts_data)): ?>
    <?php foreach($shifts_data as $sh): ?>
    <?php $sid = (int)$sh['id']; $sn = $sh['shift_name']; $so = (int)$sh['shift_order']; ?>
    <div class="shift-card">
        <div class="shift-header">
            <div>
                <h4><i class="fas fa-clock"></i> <?php echo htmlspecialchars($sn); ?></h4>
                <div class="shift-meta">
                    Shift <?php echo $so; ?>
                    <?php if($sh['default_start_time'] && $sh['default_end_time']): ?>
                     | <?php echo date('h:i A', strtotime($sh['default_start_time'])); ?> — <?php echo date('h:i A', strtotime($sh['default_end_time'])); ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            $shift_classes = [];
            $scq = mysqli_query($conn, "SELECT DISTINCT c.class_name FROM exam_routine er JOIN classes c ON c.id=er.class_id WHERE er.shift_id=$sid AND er.exam_source='$exam_source_esc' AND er.exam_id=$exam_id");
            while ($sc = mysqli_fetch_assoc($scq)) { $shift_classes[] = $sc['class_name']; }
            ?>
            <?php if(!empty($shift_classes)): ?>
            <div class="shift-meta">Classes: <?php echo implode(', ', $shift_classes); ?></div>
            <?php endif; ?>
        </div>
        <div class="shift-body">
            <?php $sn2 = $shift_needs[$sid] ?? ['Boys'=>0,'Girls'=>0]; $st2 = $shift_totals[$sid] ?? ['boys_seats'=>0,'girls_seats'=>0,'rooms'=>0]; ?>
            <div class="need-row">
                <div class="need-card <?php echo $st2['boys_seats'] >= $sn2['Boys'] ? 'ok' : 'short'; ?>">
                    <div class="lbl"><i class="fas fa-male"></i> Boys — <?php echo $sn2['Boys']; ?> জন</div>
                    <b><?php echo $st2['boys_seats']; ?></b> সিট (<?php echo $st2['rooms']; ?> rooms)
                </div>
                <div class="need-card <?php echo $st2['girls_seats'] >= $sn2['Girls'] ? 'ok' : 'short'; ?>">
                    <div class="lbl"><i class="fas fa-female"></i> Girls — <?php echo $sn2['Girls']; ?> জন</div>
                    <b><?php echo $st2['girls_seats']; ?></b> সিট
                </div>
            </div>

            <?php $shift_rooms = $shift_room_usage[$sid] ?? []; ?>
            <?php if(!empty($shift_rooms)): ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Room</th>
                            <th>Location</th>
                            <th>Gender</th>
                            <th>Total Benches</th>
                            <th>Benches Used</th>
                            <th>Seats Allocated</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $sr_total = 0; foreach($shift_rooms as $rr):
                        $seats = (int)$rr['benches_used'] * $spb;
                        $sr_total += $seats;
                    ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($rr['room_name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($rr['location'] ?? ''); ?></td>
                            <td><span class="gender-label"><?php echo $rr['gender']==='Boys'?'👦 Boys':'👧 Girls'; ?></span></td>
                            <td><?php echo (int)$rr['benches']; ?></td>
                            <td><?php echo (int)$rr['benches_used']; ?></td>
                            <td><strong><?php echo $seats; ?></strong></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr style="background:#f0f7ff; font-weight:700;">
                        <td colspan="5" style="text-align:right;">মোট Allocated Seats:</td>
                        <td><strong><?php echo $sr_total; ?></strong></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p style="font-size:13px; color:#6c7a8a; text-align:center; padding:10px;">এই Shift-এ এখনো Room বরাদ্দ হয়নি। Auto-Assign বাটনে ক্লিক করুন।</p>
            <?php endif; ?>

            <!-- MANUAL OVERRIDE FORM (per shift) -->
            <form method="POST" style="margin-top:12px; border-top:1px solid #e4edf6; padding-top:12px;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="exam_source" value="<?php echo htmlspecialchars($exam_source); ?>">
                <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                <input type="hidden" name="shift_id" value="<?php echo $sid; ?>">
                <p style="font-size:12px; font-weight:600; color:#1a3b55; margin-bottom:8px;">📝 Manual Override — <?php echo htmlspecialchars($sn); ?></p>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>ব্যবহার?</th>
                                <th>Room</th>
                                <th>Location</th>
                                <th>Gender</th>
                                <th>Max Benches</th>
                                <th>Benches Used</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        mysqli_data_seek($rooms_data, 0);
                        while ($r = mysqli_fetch_assoc($rooms_data)):
                            if ($r['status'] !== 'Active') continue;
                            $used = null;
                            foreach ($shift_rooms as $sr) { if ((int)$sr['room_id'] === (int)$r['id']) { $used = $sr; break; } }
                            $g = $used['gender'] ?? ($r['default_gender'] === 'Girls' ? 'Girls' : 'Boys');
                            $bu = $used ? (int)$used['benches_used'] : (int)$r['benches'];
                        ?>
                        <tr>
                            <td><input type="checkbox" name="use_room[<?php echo $r['id']; ?>]" value="1" <?php echo $used ? 'checked' : ''; ?>></td>
                            <td><strong><?php echo htmlspecialchars($r['room_name']); ?></strong>
                                <input type="hidden" name="room_id[]" value="<?php echo $r['id']; ?>">
                            </td>
                            <td><?php echo htmlspecialchars($r['location'] ?? ''); ?></td>
                            <td>
                                <select name="gender[<?php echo $r['id']; ?>]">
                                    <option value="Boys" <?php echo $g==='Boys'?'selected':''; ?>>Boys</option>
                                    <option value="Girls" <?php echo $g==='Girls'?'selected':''; ?>>Girls</option>
                                </select>
                            </td>
                            <td><?php echo (int)$r['benches']; ?></td>
                            <td><input type="number" name="benches_used[<?php echo $r['id']; ?>]" min="1" max="<?php echo (int)$r['benches']; ?>" value="<?php echo $bu; ?>"></td>
                        </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <div style="margin-top:10px;">
                    <button type="submit" name="save_room_usage" class="btn btn-primary"><i class="fas fa-save"></i> Save — <?php echo htmlspecialchars($sn); ?></button>
                </div>
            </form>

        </div>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div class="empty-state">
        <i class="fas fa-clock"></i>
        <h3>এই Exam-এ কোনো Shift নেই</h3>
        <p>প্রথমে Exam Routine ও Shift সেটআপ করুন।</p>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <div class="empty-state" style="margin-top:10px;">
        <i class="fas fa-hand-pointer"></i>
        <h3>কোনো Exam সিলেক্ট করুন</h3>
        <p>উপরের dropdown থেকে একটি Exam নির্বাচন করুন।</p>
    </div>
    <?php endif; ?>
</div>

<!-- PRINT AREA -->
<?php if($current_exam && !empty($all_room_usage)): ?>
<div id="printArea">
    <div style="text-align:center; margin-bottom:15px;">
        <h2 style="color:#003366; margin:0;"><?php echo htmlspecialchars($school['school_name'] ?? 'School Name'); ?></h2>
        <p style="font-size:12px; color:#6c7a8a; margin:2px 0;"><?php echo htmlspecialchars($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
        <h3 style="color:#003366; margin-top:10px; border-bottom:2px solid #003366; display:inline-block; padding-bottom:4px;">Exam Room Chart</h3>
        <p style="font-size:13px; color:#333; margin-top:4px;">
            Exam: <strong><?php echo ($exam_source==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($current_exam['label']); ?></strong>
            | Seats/Bench: <?php echo $spb; ?>
            | Total Allocated: <?php echo $all_room_usage_total; ?> seats
        </p>
    </div>
    <?php foreach($shifts_data as $sh):
        $sid = (int)$sh['id'];
        $sr = $shift_room_usage[$sid] ?? [];
        if (empty($sr)) continue;
    ?>
    <h4 style="color:#003366; margin:12px 0 6px;"><?php echo htmlspecialchars($sh['shift_name']); ?></h4>
    <table style="width:100%; border-collapse:collapse; font-size:12px; margin-bottom:12px;">
        <thead>
            <tr style="background:#003366; color:#fff;">
                <th style="padding:6px; border:1px solid #333; text-align:left;">#</th>
                <th style="padding:6px; border:1px solid #333; text-align:left;">Room</th>
                <th style="padding:6px; border:1px solid #333; text-align:left;">Location</th>
                <th style="padding:6px; border:1px solid #333; text-align:center;">Gender</th>
                <th style="padding:6px; border:1px solid #333; text-align:center;">Benches Used</th>
                <th style="padding:6px; border:1px solid #333; text-align:center;">Seats</th>
            </tr>
        </thead>
        <tbody>
        <?php $psl = 1; $st = 0; foreach($sr as $rr):
            $seats = (int)$rr['benches_used'] * $spb;
            $st += $seats;
        ?>
            <tr>
                <td style="padding:5px 6px; border:1px solid #333;"><?php echo $psl++; ?></td>
                <td style="padding:5px 6px; border:1px solid #333;"><strong><?php echo htmlspecialchars($rr['room_name']); ?></strong></td>
                <td style="padding:5px 6px; border:1px solid #333;"><?php echo htmlspecialchars($rr['location'] ?? ''); ?></td>
                <td style="padding:5px 6px; border:1px solid #333; text-align:center;"><?php echo $rr['gender']; ?></td>
                <td style="padding:5px 6px; border:1px solid #333; text-align:center;"><?php echo (int)$rr['benches_used']; ?></td>
                <td style="padding:5px 6px; border:1px solid #333; text-align:center;"><strong><?php echo $seats; ?></strong></td>
            </tr>
        <?php endforeach; ?>
            <tr style="background:#f0f4f9; font-weight:700;">
                <td colspan="5" style="padding:5px 6px; border:1px solid #333; text-align:right;">মোট:</td>
                <td style="padding:5px 6px; border:1px solid #333; text-align:center;"><?php echo $st; ?></td>
            </tr>
        </tbody>
    </table>
    <?php endforeach; ?>
    <div style="margin-top:20px; font-size:11px; color:#6c7a8a; text-align:center;">
        Printed on <?php echo date('d/m/Y h:i A'); ?> | Exam Room Config — Auto-generated
    </div>
</div>
<?php endif; ?>

<!-- EDIT MODAL -->
<div id="editModal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
    <div style="background:#fff; padding:25px; border-radius:14px; max-width:500px; width:90%; max-height:90vh; overflow-y:auto;">
        <h4 style="color:#003366; margin-bottom:15px;"><i class="fas fa-edit"></i> Edit Room</h4>
        <form method="POST">
        <?php echo csrf_field(); ?>
            <input type="hidden" name="room_id" id="edit_id">
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-door-open"></i> Room Name</label>
                <input type="text" name="room_name" id="edit_name" required>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-map-marker-alt"></i> Location</label>
                <input type="text" name="location" id="edit_location">
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-th"></i> Benches</label>
                <input type="number" name="benches" id="edit_benches" min="1" required>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-venus-mars"></i> Default Gender</label>
                <select name="default_gender" id="edit_gender">
                    <option value="Any">Any</option>
                    <option value="Boys">Boys</option>
                    <option value="Girls">Girls</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-toggle-on"></i> Status</label>
                <select name="status" id="edit_status">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <div style="display:flex; gap:10px; margin-top:15px;">
                <button type="submit" name="update_room" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                <button type="button" class="btn btn-danger" onclick="document.getElementById('editModal').style.display='none'"><i class="fas fa-times"></i> Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editRoom(id, name, location, benches, gender, status) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_location').value = location;
    document.getElementById('edit_benches').value = benches;
    document.getElementById('edit_gender').value = gender;
    document.getElementById('edit_status').value = status;
    document.getElementById('editModal').style.display = 'flex';
}
</script>
</body>
</html>
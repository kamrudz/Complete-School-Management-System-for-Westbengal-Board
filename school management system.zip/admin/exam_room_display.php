<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

// Roll numbers within one class-section in one room may have small gaps
// (e.g. a student left mid-year) — we still show ONE row: lowest to
// highest roll, with the actual headcount alongside (not to-from+1).
function roll_span(array $nums): array {
    $nums = array_map('intval', $nums);
    if (empty($nums)) return ['from' => 0, 'to' => 0, 'count' => 0];
    return ['from' => min($nums), 'to' => max($nums), 'count' => count($nums)];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

if (!$exam_source || $exam_id <= 0) {
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Room Allocation</title></head>
<body style="font-family:'Segoe UI',Arial,sans-serif;padding:30px;">
<p>Exam সিলেক্ট করা হয়নি। <a href="exam_seating.php">Exam Seating</a> পাতা থেকে exam বেছে এই পাতায় আসুন (URL-এ exam_key ও shift_id সহ)।</p>
</body></html>
<?php
    exit();
}

$exam_source_sql = mysqli_real_escape_string($conn, $exam_source);

// Exam + session label
$exam_label = '';
$session_id = 0;
if ($exam_source === 'v-x') {
    $e = mysqli_fetch_assoc(mysqli_query($conn, "SELECT e.exam_name, e.session_id, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.id=$exam_id"));
    $exam_label = ($e['exam_name'] ?? '') . ' (' . ($e['session_name'] ?? '') . ')';
    $session_id = (int)($e['session_id'] ?? 0);
} else {
    $e = mysqli_fetch_assoc(mysqli_query($conn, "SELECT h.exam_name, h.academic_year, h.session_id, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.id=$exam_id"));
    $exam_label = ($e['exam_name'] ?? '') . ' — ' . ($e['class_name'] ?? '') . ' (' . ($e['academic_year'] ?? '') . ')';
    $session_id = (int)($e['session_id'] ?? 0);
}

$school_name = '';
$srow = mysqli_fetch_assoc(mysqli_query($conn, "SHOW TABLES LIKE 'school_settings'"));
if ($srow) {
    $sr = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings LIMIT 1"));
    $school_name = $sr['school_name'] ?? ($sr['site_name'] ?? '');
}

// Shifts for this exam
$shifts = [];
$q = mysqli_query($conn, "SELECT * FROM exam_shifts WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id ORDER BY shift_order ASC");
while ($r = mysqli_fetch_assoc($q)) { $shifts[] = $r; }
$shift_id = isset($_GET['shift_id']) ? (int)$_GET['shift_id'] : ((count($shifts) === 1) ? (int)$shifts[0]['id'] : 0);
$current_shift = null;
foreach ($shifts as $s) { if ($s['id'] == $shift_id) { $current_shift = $s; break; } }

$room_data = [];   // room_id => ['room_name'=>, 'gender'=>, 'groups'=>[ "classId-secId" => ['class_name','section_name','rolls'=>[]] ], 'total'=>n ]
$lookup_data = []; // "classId-secId" => ['class_name','section_name','rooms'=>[ room_name => rolls[] ]]

if ($current_shift) {
    $q = mysqli_query($conn, "
        SELECT sp.room_id, r.room_name, ru.gender,
               sp.class_id, c.class_name, sp.section_id, sec.section_name,
               CAST(sah.roll_no AS UNSIGNED) AS roll_no
        FROM exam_seating_plan sp
        JOIN exam_rooms r ON r.id = sp.room_id
        LEFT JOIN exam_room_usage ru ON ru.exam_source=sp.exam_source AND ru.exam_id=sp.exam_id AND ru.shift_id=sp.shift_id AND ru.room_id=sp.room_id
        LEFT JOIN classes c ON c.id = sp.class_id
        LEFT JOIN sections sec ON sec.id = sp.section_id
        LEFT JOIN student_academic_history sah ON sah.student_id=sp.student_id AND sah.session_id=$session_id AND sah.class_id=sp.class_id AND (sah.section_id=sp.section_id OR sp.section_id IS NULL)
        WHERE sp.exam_source='$exam_source_sql' AND sp.exam_id=$exam_id AND sp.shift_id=$shift_id
        ORDER BY r.room_name ASC, c.sort_order ASC, sec.section_name ASC, roll_no ASC
    ");
    while ($row = mysqli_fetch_assoc($q)) {
        $rid = $row['room_id'];
        $key = $row['class_id'] . '-' . ($row['section_id'] ?? '0');

        if (!isset($room_data[$rid])) {
            $room_data[$rid] = ['room_name' => $row['room_name'], 'gender' => $row['gender'], 'groups' => [], 'total' => 0];
        }
        if (!isset($room_data[$rid]['groups'][$key])) {
            $room_data[$rid]['groups'][$key] = ['class_name' => $row['class_name'], 'section_name' => $row['section_name'], 'rolls' => []];
        }
        $room_data[$rid]['groups'][$key]['rolls'][] = $row['roll_no'];
        $room_data[$rid]['total']++;

        if (!isset($lookup_data[$key])) {
            $lookup_data[$key] = ['class_name' => $row['class_name'], 'section_name' => $row['section_name'], 'rooms' => []];
        }
        if (!isset($lookup_data[$key]['rooms'][$row['room_name']])) {
            $lookup_data[$key]['rooms'][$row['room_name']] = [];
        }
        $lookup_data[$key]['rooms'][$row['room_name']][] = $row['roll_no'];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Room Allocation Notice</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family: 'Segoe UI', Arial, sans-serif; }
body { padding: 20px; color:#000; background:#f0f4f9; }
.no-print-bar { max-width: 1000px; margin: 0 auto 15px; display:flex; gap:10px; align-items:center; }
.no-print-bar select { padding:8px 12px; border:2px solid #ccc; border-radius:8px; }
.no-print-bar button, .no-print-bar a.btn { padding:8px 18px; background:#003366; color:#fff; border:none; border-radius:6px; cursor:pointer; font-weight:600; text-decoration:none; font-size:13px; }
.tab-toggle { display:flex; gap:8px; margin: 0 0 14px; max-width:1000px; margin-left:auto; margin-right:auto; }
.tab-toggle button { padding: 8px 18px; border-radius: 20px; border: 2px solid #ccc; background: #fff; font-weight: 700; font-size: 13px; cursor: pointer; }
.tab-toggle button.active { background: #003366; color: #fff; border-color: #003366; }
.tab-panel { display:none; }
.tab-panel.active { display:block; }

.sheet { max-width: 1000px; margin: 0 auto; background:#fff; padding: 22px 26px; border-radius: 6px; box-shadow: 0 1px 8px rgba(0,0,0,0.08); }
.header { text-align:center; margin-bottom: 16px; border-bottom: 3px solid #000; padding-bottom: 10px; }
.header .school { font-size: 30px; font-weight:800; color:#000; letter-spacing:.3px; }
.header .exam { font-size: 20px; margin-top: 5px; color:#000; font-weight:700; }
.header .shift { font-size: 16px; margin-top: 3px; color:#333; font-weight:600; }

.gender-title { font-size:22px; font-weight:800; color:#000; margin: 16px 0 6px; padding-bottom:4px; border-bottom: 2px solid #000; display:flex; align-items:center; gap:8px; }
.gender-title:first-child { margin-top:0; }

.roll-table { width:100%; border-collapse: collapse; font-size:17px; margin-bottom: 6px; }
.roll-table th { background:#003366; color:#fff; padding: 8px 10px; text-align:left; font-size:15px; text-transform:uppercase; letter-spacing:.3px; border:1px solid #003366; }
.roll-table td { padding: 6px 10px; border:1px solid #ccc; }
.roll-table td.rno { font-weight:800; text-align:center; vertical-align:middle; border-right:2px solid #000; }
.roll-table .room-total { font-size:12px; font-weight:700; color:#333; margin-top:3px; }
.roll-table tr.room-first td { border-top: 2px solid #000; }
.roll-table td.num { text-align:center; font-weight:700; }

.lookup-table { width:100%; border-collapse: collapse; font-size:18px; }
.lookup-table th { background:#003366; color:#fff; padding:9px 14px; text-align:left; font-size:15px; text-transform:uppercase; border:1px solid #003366; }
.lookup-table td { padding: 8px 14px; border:1px solid #ccc; }
.gender-page-break { page-break-before: always; }

@media print {
  @page { size: A4; margin: 10mm; }
  body { background:#fff; padding:0; }
  .no-print-bar, .tab-toggle { display:none !important; }
  .sheet { box-shadow:none; padding:0; max-width:100%; }
  .tab-panel { display:block !important; }
  .tab-panel + .tab-panel { page-break-before: always; }
  .roll-table, .lookup-table { font-size:14px; }
  .roll-table th, .lookup-table th { font-size:12px; }
  .header .school { font-size:24px; }
  .header .exam { font-size:16px; }
}
</style>
</head>
<body>

<div class="no-print-bar">
    <form method="GET" style="display:flex;gap:10px;">
        <input type="hidden" name="exam_key" value="<?php echo htmlspecialchars($exam_key); ?>">
        <select name="shift_id" onchange="this.form.submit()">
            <option value="">-- Shift --</option>
            <?php foreach($shifts as $s): ?>
            <option value="<?php echo $s['id']; ?>" <?php echo $shift_id==$s['id']?'selected':''; ?>><?php echo htmlspecialchars($s['shift_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </form>
    <button onclick="window.print()"><i class="fas fa-print"></i> Print</button>
    <a class="btn" href="exam_seating.php?exam_key=<?php echo urlencode($exam_key); ?>&shift_id=<?php echo $shift_id; ?>"><i class="fas fa-arrow-left"></i> Back to Seating</a>
</div>

<?php if(!$current_shift): ?>
<div class="sheet"><p style="text-align:center;color:#888;padding:30px;">একটা Shift বেছে নিন উপর থেকে।</p></div>
<?php elseif(empty($room_data)): ?>
<div class="sheet"><p style="text-align:center;color:#888;padding:30px;">এই shift-এর জন্য এখনো কোনো seating generate করা হয়নি।</p></div>
<?php else: ?>

<div class="tab-toggle">
    <button class="active" onclick="showTab('room', this)"><i class="fas fa-door-open"></i> Room-wise (গেটে লাগানোর জন্য)</button>
    <button onclick="showTab('lookup', this)"><i class="fas fa-search"></i> Class-wise Lookup (ছাত্ররা নিজের রুম খুঁজবে)</button>
</div>

<!-- ROOM-WISE VIEW -->
<div id="tab-room" class="tab-panel active">
<div class="sheet">
    <div class="header">
        <div class="school"><?php echo htmlspecialchars($school_name ?: 'School'); ?></div>
        <div class="exam">Room-wise Seat Allocation — <?php echo htmlspecialchars($exam_label); ?></div>
        <div class="shift"><?php echo htmlspecialchars($current_shift['shift_name']); ?>
            <?php if($current_shift['default_start_time']): ?> (<?php echo date('h:i A', strtotime($current_shift['default_start_time'])); ?>–<?php echo date('h:i A', strtotime($current_shift['default_end_time'])); ?>)<?php endif; ?>
        </div>
    </div>

    <?php
    ksort($room_data);
    foreach (['Boys','Girls'] as $gi => $gender):
        $rooms_g = array_filter($room_data, fn($r) => ($r['gender'] ?? '') === $gender);
        if (empty($rooms_g)) continue;
        $grand_total = array_sum(array_column($rooms_g, 'total'));
    ?>
    <div class="gender-title<?php echo $gi>0 ? ' gender-page-break' : ''; ?>">
        <i class="fas fa-<?php echo $gender=='Boys'?'male':'female'; ?>"></i> <?php echo $gender; ?> — মোট <?php echo $grand_total; ?> জন
    </div>
    <table class="roll-table">
        <thead><tr><th style="width:12%;">Room No</th><th>Class</th><th style="width:10%;">Sec</th><th style="width:12%;">Roll From</th><th style="width:10%;">Roll To</th><th style="width:12%;">Total</th></tr></thead>
        <tbody>
        <?php foreach($rooms_g as $rid => $room): $first_row = true; $row_count = count($room['groups']); ?>
            <?php foreach($room['groups'] as $g): $span = roll_span($g['rolls']); ?>
                <tr class="<?php echo $first_row ? 'room-first' : ''; ?>">
                    <?php if ($first_row): ?>
                    <td class="rno" rowspan="<?php echo $row_count; ?>">
                        <?php echo htmlspecialchars($room['room_name']); ?>
                        <div class="room-total">Total: <?php echo $room['total']; ?></div>
                    </td>
                    <?php endif; ?>
                    <td><?php echo htmlspecialchars($g['class_name']); ?></td>
                    <td><?php echo htmlspecialchars($g['section_name'] ?: '-'); ?></td>
                    <td class="num"><?php echo $span['from']; ?></td>
                    <td class="num"><?php echo $span['to']; ?></td>
                    <td class="num"><?php echo $span['count']; ?></td>
                </tr>
                <?php $first_row = false; ?>
            <?php endforeach; ?>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endforeach; ?>
</div>
</div>


<!-- CLASS-WISE LOOKUP VIEW -->
<div id="tab-lookup" class="tab-panel">
<div class="sheet">
    <div class="header">
        <div class="school"><?php echo htmlspecialchars($school_name ?: 'School'); ?></div>
        <div class="exam">"আমার রুম কোনটা?" — Class অনুযায়ী খুঁজুন — <?php echo htmlspecialchars($exam_label); ?></div>
        <div class="shift"><?php echo htmlspecialchars($current_shift['shift_name']); ?></div>
    </div>
    <table class="lookup-table">
        <thead><tr><th>Class</th><th>Roll From</th><th>Roll To</th><th>Room</th></tr></thead>
        <tbody>
        <?php
        ksort($lookup_data);
        foreach($lookup_data as $key => $g):
            foreach($g['rooms'] as $room_name => $rolls): $span = roll_span($rolls);
        ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($g['class_name']); ?><?php echo $g['section_name'] ? ' — '.htmlspecialchars($g['section_name']) : ''; ?></strong></td>
                <td class="num"><?php echo $span['from']; ?></td>
                <td class="num"><?php echo $span['to']; ?></td>
                <td>Room <?php echo htmlspecialchars($room_name); ?></td>
            </tr>
        <?php endforeach; endforeach; ?>
        </tbody>
    </table>
</div>
</div>

<script>
function showTab(name, btn) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-toggle button').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
}
</script>

<?php endif; ?>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once("../includes/security.php");

// ===== ADD ROOM =====
if(isset($_POST['add_room']))
{
    verify_csrf_or_die();
    $room_name = mysqli_real_escape_string($conn, trim($_POST['room_name']));
    $location  = mysqli_real_escape_string($conn, trim($_POST['location']));
    $benches  = (int)$_POST['benches'];
    $gender    = in_array($_POST['default_gender'] ?? '', ['Boys','Girls','Any'], true) ? $_POST['default_gender'] : 'Any';

    if($room_name === '' || $benches <= 0) {
        $_SESSION['error'] = "Room Name এবং সঠিক Bench সংখ্যা দিতে হবে।";
        header("Location: exam_rooms.php");
        exit();
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO exam_rooms (room_name, location, default_gender, benches, status) VALUES (?, ?, ?, ?, 'Active')");
    mysqli_stmt_bind_param($stmt, 'sssi', $room_name, $location, $gender, $benches);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['success'] = "Room Added Successfully!";
    header("Location: exam_rooms.php");
    exit();
}

// ===== UPDATE ROOM =====
if(isset($_POST['update_room']))
{
    verify_csrf_or_die();
    $id        = (int)$_POST['room_id'];
    $room_name = mysqli_real_escape_string($conn, trim($_POST['room_name']));
    $location  = mysqli_real_escape_string($conn, trim($_POST['location']));
    $benches  = (int)$_POST['benches'];
    $gender    = in_array($_POST['default_gender'] ?? '', ['Boys','Girls','Any'], true) ? $_POST['default_gender'] : 'Any';
    $status    = ($_POST['status'] === 'Inactive') ? 'Inactive' : 'Active';

    if($room_name === '' || $benches <= 0) {
        $_SESSION['error'] = "Room Name এবং সঠিক Bench সংখ্যা দিতে হবে।";
        header("Location: exam_rooms.php");
        exit();
    }

    $stmt = mysqli_prepare($conn, "UPDATE exam_rooms SET room_name=?, location=?, default_gender=?, benches=?, status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'sssisi', $room_name, $location, $gender, $benches, $status, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['success'] = "Room Updated Successfully!";
    header("Location: exam_rooms.php");
    exit();
}

// ===== DELETE ROOM =====
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id']))
{
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];

    // Guard: don't allow deleting a room that's already used in a seating plan or duty roster
    // (safe against these tables not existing yet, since seating/duty are built in later phases)
    $in_use = false;
    if ($chk = @mysqli_prepare($conn, "SELECT id FROM exam_seating_plan WHERE room_id=? LIMIT 1")) {
        mysqli_stmt_bind_param($chk, 'i', $id);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) { $in_use = true; }
        mysqli_stmt_close($chk);
    }
    if (!$in_use && ($chk = @mysqli_prepare($conn, "SELECT id FROM exam_duty_roster WHERE room_id=? LIMIT 1"))) {
        mysqli_stmt_bind_param($chk, 'i', $id);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) { $in_use = true; }
        mysqli_stmt_close($chk);
    }

    if ($in_use) {
        $_SESSION['error'] = "এই রুমটি আগে থেকেই কোনো Seating Plan বা Duty Roster-এ ব্যবহৃত হয়েছে, তাই ডিলিট করা যাবে না। এর বদলে 'Inactive' করে দিন।";
    } else {
        $stmt = mysqli_prepare($conn, 'DELETE FROM exam_rooms WHERE id=?');
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        $_SESSION['success'] = "Room Deleted Successfully!";
    }

    header("Location: exam_rooms.php");
    exit();
}

// ===== GET ALL ROOMS =====
$rooms = mysqli_query($conn, "SELECT * FROM exam_rooms ORDER BY id ASC");
$total_rooms = mysqli_num_rows($rooms);
$total_benches = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(benches),0) AS c FROM exam_rooms WHERE status='Active'"))['c'];
$active_rooms = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM exam_rooms WHERE status='Active'"));
$gender_stats = ['Boys' => 0, 'Girls' => 0, 'Any' => 0];
$gs = mysqli_query($conn, "SELECT default_gender, COUNT(*) c FROM exam_rooms WHERE status='Active' GROUP BY default_gender");
while ($r = mysqli_fetch_assoc($gs)) { $gender_stats[$r['default_gender']] = (int)$r['c']; }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Rooms</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }

    .top-nav {
        background: linear-gradient(135deg, #0f1a2e 0%, #1a2d4a 100%);
        padding: 10px 20px;
        border-radius: 12px;
        margin-bottom: 20px;
        display: flex;
        flex-wrap: nowrap;
        align-items: center;
        gap: 4px;
        overflow-x: auto;
        position: sticky;
        top: 0;
        z-index: 999;
    }

    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1100px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }

    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; display: flex; align-items: center; gap: 12px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }

    .stats-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; margin-bottom: 20px; }
    .stat-card { background: #f8f9fa; padding: 12px 18px; border-radius: 12px; border: 1px solid #e4edf6; text-align: center; }
    .stat-card .number { font-size: 22px; font-weight: 700; color: #003366; }
    .stat-card .label { font-size: 11px; color: #6c7a8a; text-transform: uppercase; }

    .form-card { background: #f8f9fa; padding: 20px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .form-card h4 { color: #003366; margin-bottom: 15px; display: flex; align-items: center; gap: 8px; }
    .form-row { display: grid; grid-template-columns: 1.2fr 1.3fr 0.7fr 0.7fr 0.5fr; gap: 12px; align-items: end; }
    .form-group { display: flex; flex-direction: column; }
    .form-group label { font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 4px; }
    .form-group input, .form-group select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 13px; background: #fff; }
    .form-group input:focus, .form-group select:focus { outline: none; border-color: #1f5b8a; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 8px 18px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; text-decoration: none; transition: all 0.2s ease; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }
    .btn-primary { background: #003366; color: #fff; }
    .btn-danger { background: #dc3545; color: #fff; }
    .btn-warning { background: #ffc107; color: #212529; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }

    .table-responsive { overflow-x: auto; margin-top: 10px; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    table th { background: #003366; color: #fff; padding: 10px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table tr:hover { background: #f0f7ff; }

    .badge { padding: 2px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; display: inline-block; }
    .badge-active { background: #d4edda; color: #155724; }
    .badge-inactive { background: #f1f3f5; color: #6c757d; }

    .empty-state { text-align: center; padding: 40px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; }
    .empty-state i { font-size: 48px; color: #003366; opacity: 0.3; }
    .empty-state h3 { color: #003366; margin-top: 15px; }

    @media (max-width: 768px) {
        .form-row { grid-template-columns: 1fr; }
        .stats-row { grid-template-columns: repeat(2, 1fr); }
        .page-box { padding: 15px; }
    }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-door-open"></i> Exam Rooms
        <small>Exam Conduct — Room Master (বেঞ্চ ভিত্তিক)</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="stats-row">
        <div class="stat-card">
            <div class="number"><?php echo $total_rooms; ?></div>
            <div class="label"><i class="fas fa-door-open"></i> Total Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $active_rooms; ?></div>
            <div class="label"><i class="fas fa-check-circle"></i> Active Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $total_benches; ?></div>
            <div class="label"><i class="fas fa-chair"></i> Total Benches</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Boys']; ?></div>
            <div class="label">👦 Boys Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Girls']; ?></div>
            <div class="label">👧 Girls Rooms</div>
        </div>
        <div class="stat-card">
            <div class="number"><?php echo $gender_stats['Any']; ?></div>
            <div class="label">⚪ Any Rooms</div>
        </div>
    </div>

    <div class="form-card">
        <h4><i class="fas fa-plus-circle"></i> Add New Room</h4>
        <p style="font-size:12px;color:#6c7a8a;margin-bottom:12px;">এটা রুমে মোট কতগুলো বেঞ্চ আছে তা। বেঞ্চে কতজন বসবে (seats/bench) সেটা প্রতিটা exam-এর জন্য আলাদাভাবে <a href="exam_seating_settings.php" style="color:#003366;font-weight:700;">Seating Settings</a>-এ ঠিক করবেন — তাই একই রুম বিভিন্ন exam-এ বিভিন্ন সংখ্যক ছাত্র ধরতে পারবে।</p>
        <form method="POST">
<?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-door-open"></i> Room Name</label>
                    <input type="text" name="room_name" placeholder="e.g., Room 101" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-map-marker-alt"></i> Location</label>
                    <input type="text" name="location" placeholder="e.g., 1st Floor, Main Building">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-chair"></i> Benches</label>
                    <input type="number" name="benches" min="1" placeholder="20" required>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-venus-mars"></i> Default Gender</label>
                    <select name="default_gender">
                        <option value="Any">Any</option>
                        <option value="Boys">Boys</option>
                        <option value="Girls">Girls</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>&nbsp;</label>
                    <button type="submit" name="add_room" class="btn btn-success">
                        <i class="fas fa-save"></i> Add
                    </button>
                </div>
            </div>
        </form>
    </div>

    <h4 style="color:#003366; margin-bottom:10px;"><i class="fas fa-list"></i> Room List</h4>
    <div class="table-responsive">
        <?php if($total_rooms > 0): ?>
        <?php
        mysqli_data_seek($rooms, 0);
        $all_rooms = [];
        while ($rr = mysqli_fetch_assoc($rooms)) { $all_rooms[] = $rr; }
        $grouped = ['Boys' => [], 'Girls' => [], 'Any' => []];
        foreach ($all_rooms as $r) {
            $g = $r['default_gender'] ?? 'Any';
            if (isset($grouped[$g])) { $grouped[$g][] = $r; }
            else { $grouped['Any'][] = $r; }
        }
        ?>
        <?php foreach (['Boys', 'Girls', 'Any'] as $glabel): ?>
        <?php if (empty($grouped[$glabel])) continue; ?>
        <h5 style="color:#003366;margin:16px 0 8px;"><i class="fas fa-<?php echo $glabel==='Boys'?'male':($glabel==='Girls'?'female':'circle'); ?>"></i> <?php echo $glabel; ?> Rooms (<?php echo count($grouped[$glabel]); ?>)</h5>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Room Name</th>
                    <th>Location</th>
                    <th>Benches</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $sl = 1; foreach($grouped[$glabel] as $row): ?>
                <tr>
                    <td><?php echo $sl++; ?></td>
                    <td><strong><?php echo htmlspecialchars($row['room_name']); ?></strong></td>
                    <td><?php echo htmlspecialchars($row['location'] ?? ''); ?></td>
                    <td><?php echo (int)$row['benches']; ?></td>
                    <td>
                        <?php if($row['status'] === 'Active'): ?>
                        <span class="badge badge-active">Active</span>
                        <?php else: ?>
                        <span class="badge badge-inactive">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editRoom(<?php echo (int)$row['id']; ?>, '<?php echo htmlspecialchars($row['room_name'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($row['location'] ?? '', ENT_QUOTES, 'UTF-8'); ?>', <?php echo (int)$row['benches']; ?>, '<?php echo htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($row['default_gender'], ENT_QUOTES, 'UTF-8'); ?>')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form method="post" style="display:inline;" onsubmit="return confirm('Delete this room?')">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="delete_id" value="<?php echo (int)$row['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endforeach; ?>
        <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-door-open"></i>
            <h3>No Rooms Found</h3>
            <p>Add your first exam room using the form above.</p>
        </div>
        <?php endif; ?>
    </div>

</div>

<!-- ===== EDIT MODAL ===== -->
<div id="editModal" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
    <div style="background:#fff; padding:25px; border-radius:14px; max-width:500px; width:90%;">
        <h4 style="color:#003366; margin-bottom:15px;"><i class="fas fa-edit"></i> Edit Room</h4>
        <form method="POST">
<?php echo csrf_field(); ?>
            <input type="hidden" name="room_id" id="edit_id">
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-door-open"></i> Room Name</label>
                <input type="text" name="room_name" id="edit_name" required>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-map-marker-alt"></i> Location</label>
                <input type="text" name="location" id="edit_location">
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-chair"></i> Benches</label>
                <input type="number" name="benches" id="edit_benches" min="1" required>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-venus-mars"></i> Default Gender</label>
                <select name="default_gender" id="edit_gender">
                    <option value="Any">Any</option>
                    <option value="Boys">Boys</option>
                    <option value="Girls">Girls</option>
                </select>
            </div>
            <div class="form-group" style="margin-bottom:12px;">
                <label><i class="fas fa-toggle-on"></i> Status</label>
                <select name="status" id="edit_status">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>
            <div style="display:flex; gap:10px; margin-top:15px;">
                <button type="submit" name="update_room" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                <button type="button" class="btn btn-danger" onclick="document.getElementById('editModal').style.display='none'"><i class="fas fa-times"></i> Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editRoom(id, name, location, benches, status, gender) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_location').value = location;
    document.getElementById('edit_benches').value = benches;
    document.getElementById('edit_status').value = status;
    document.getElementById('edit_gender').value = gender;
    document.getElementById('editModal').style.display = 'flex';
}
</script>

</body>
</html>

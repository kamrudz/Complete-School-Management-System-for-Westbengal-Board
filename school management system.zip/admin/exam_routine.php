<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== SAVE ROUTINE (bulk save for one exam + class) =====
if(isset($_POST['save_routine'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id  = (int)$_POST['exam_id'];
    $class_id = (int)$_POST['class_id'];

    if($exam_id <= 0 || $class_id <= 0) {
        $_SESSION['error'] = "Exam ও Class ঠিক নেই।";
        header("Location: exam_routine.php");
        exit();
    }

    // Shift is NOT taken from the form — it's locked to whatever this class
    // is mapped to in exam_class_shift, so it can never be entered wrong.
    $shiftRow = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT es.id AS shift_id, es.shift_name
        FROM exam_class_shift ecs
        JOIN exam_shifts es ON es.id = ecs.shift_id
        WHERE ecs.exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND ecs.exam_id=$exam_id AND ecs.class_id=$class_id
        LIMIT 1
    "));
    if (!$shiftRow) {
        $_SESSION['error'] = "এই ক্লাসের জন্য কোনো shift mapping সেট করা নেই। আগে Class → Shift Mapping পাতায় গিয়ে shift বসান।";
        header("Location: exam_routine.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&class_id=$class_id");
        exit();
    }
    $shift_id = (int)$shiftRow['shift_id'];
    $shift_name = $shiftRow['shift_name'];

    $subject_ids = $_POST['subject_id'] ?? [];
    $dates       = $_POST['exam_date'] ?? [];
    $starts      = $_POST['start_time'] ?? [];
    $ends        = $_POST['end_time'] ?? [];

    $stmt = mysqli_prepare($conn, "DELETE FROM exam_routine WHERE exam_source=? AND exam_id=? AND class_id=?");
    mysqli_stmt_bind_param($stmt, 'sii', $exam_source, $exam_id, $class_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $saved = 0;
    $ins = mysqli_prepare($conn, "INSERT INTO exam_routine (exam_source, exam_id, class_id, subject_id, exam_date, shift_id, start_time, end_time) VALUES (?,?,?,?,?,?,?,?)");
    foreach ($subject_ids as $i => $sid) {
        $sid = (int)$sid;
        $date  = trim($dates[$i] ?? '');
        $start = trim($starts[$i] ?? '');
        $end   = trim($ends[$i] ?? '');
        if ($sid <= 0 || $date === '' || $start === '' || $end === '') continue;

        mysqli_stmt_bind_param($ins, 'siiisiss', $exam_source, $exam_id, $class_id, $sid, $date, $shift_id, $start, $end);
        mysqli_stmt_execute($ins);
        $saved++;
    }
    mysqli_stmt_close($ins);

    $_SESSION['success'] = "$saved টা subject-এর routine সেভ হয়েছে! (Shift: $shift_name)";
    header("Location: exam_routine.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&class_id=$class_id");
    exit();
}

// ===== DELETE SINGLE ROUTINE ROW =====
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $exam_source = $_POST['exam_source'];
    $exam_id = (int)$_POST['exam_id'];
    $class_id = (int)$_POST['class_id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM exam_routine WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    $_SESSION['success'] = "Routine entry removed.";
    header("Location: exam_routine.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&class_id=$class_id");
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')','fixed_class_id'=>null];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, h.class_id, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')','fixed_class_id'=>$r['class_id']];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

$classes = mysqli_query($conn, "SELECT * FROM classes ORDER BY sort_order");

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

// For HS, class is fixed by the exam itself — no separate class picker needed
$class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
if ($current_exam && $current_exam['source'] === 'hs') {
    $class_id = (int)$current_exam['fixed_class_id'];
}

// session_id needed for V-X's exam_class_subjects lookup
$session_id = 0;
if ($current_exam && $current_exam['source'] === 'v-x') {
    $einfo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT session_id FROM exams WHERE id=" . (int)$exam_id));
    $session_id = $einfo['session_id'] ?? 0;
}

// This class's locked shift (from exam_class_shift), if any
$class_shift = null;
if ($current_exam && $class_id > 0) {
    $class_shift = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT es.id AS shift_id, es.shift_name, es.default_start_time, es.default_end_time
        FROM exam_class_shift ecs
        JOIN exam_shifts es ON es.id = ecs.shift_id
        WHERE ecs.exam_source='" . mysqli_real_escape_string($conn, $current_exam['source']) . "' AND ecs.exam_id=$exam_id AND ecs.class_id=$class_id
        LIMIT 1
    "));
}

// Subjects for this exam+class (source-dependent) + already-saved routine rows + full marks reference
$subjects = [];
$routine_by_subject = [];
if ($current_exam && $class_id > 0) {
    if ($current_exam['source'] === 'v-x' && $session_id > 0) {
        $q = mysqli_query($conn, "
            SELECT ecs.subject_id, sub.subject_name, esm.total_full_marks AS full_marks
            FROM exam_class_subjects ecs
            LEFT JOIN subjects sub ON ecs.subject_id = sub.id
            LEFT JOIN exam_subject_marks esm ON esm.exam_id=$exam_id AND esm.class_id=$class_id AND esm.subject_id=ecs.subject_id
            WHERE ecs.session_id='$session_id' AND ecs.class_id='$class_id'
            ORDER BY sub.subject_name ASC
        ");
        while ($row = mysqli_fetch_assoc($q)) { $subjects[] = $row; }
    } elseif ($current_exam['source'] === 'hs') {
        $q = mysqli_query($conn, "
            SELECT DISTINCT hesm.subject_id, sub.subject_name,
                   (COALESCE(hesm.theory_full_marks,0) + COALESCE(hesm.practical_full_marks,0)) AS full_marks
            FROM hs_exam_subject_marks hesm
            LEFT JOIN subjects sub ON hesm.subject_id = sub.id
            WHERE hesm.hs_exam_id='$exam_id' AND hesm.class_id='$class_id'
            ORDER BY sub.subject_name ASC
        ");
        while ($row = mysqli_fetch_assoc($q)) { $subjects[] = $row; }
    }

    $rq = mysqli_query($conn, "SELECT * FROM exam_routine WHERE exam_source='" . mysqli_real_escape_string($conn, $current_exam['source']) . "' AND exam_id='$exam_id' AND class_id='$class_id'");
    while ($row = mysqli_fetch_assoc($rq)) { $routine_by_subject[$row['subject_id']] = $row; }
}

// Full routine listing (all classes) for this exam
$full_routine = [];
if ($current_exam) {
    $q = mysqli_query($conn, "
        SELECT r.*, c.class_name, sub.subject_name, es.shift_name, es.shift_order
        FROM exam_routine r
        LEFT JOIN classes c ON r.class_id = c.id
        LEFT JOIN subjects sub ON r.subject_id = sub.id
        LEFT JOIN exam_shifts es ON es.id = r.shift_id
        WHERE r.exam_source='" . mysqli_real_escape_string($conn, $current_exam['source']) . "' AND r.exam_id='$exam_id'
        ORDER BY r.exam_date ASC, es.shift_order ASC, c.sort_order ASC
    ");
    while ($row = mysqli_fetch_assoc($q)) { $full_routine[] = $row; }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Routine</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1200px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display:flex; gap:16px; flex-wrap:wrap; }
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 280px; background: #fff; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table input[type="date"], table input[type="time"], table select { padding: 6px 8px; border: 1.5px solid #d0dbe8; border-radius: 6px; font-size: 12px; width: 100%; }
    .shift-badge { padding: 2px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; background:#fff3cd; color:#856404; }
    .src-badge { padding: 1px 8px; border-radius: 10px; font-size: 10px; font-weight: 700; }
    .src-vx { background:#e2e3ff; color:#3b3fa0; }
    .src-hs { background:#ffe3ec; color:#a03b6f; }
    .full-marks { color:#6c7a8a; font-size:11px; }
    .empty-state { text-align: center; padding: 30px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; color: #6c7a8a; }
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; text-decoration:none; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }
    .btn-outline { background: #fff; color:#003366; border: 2px solid #003366; }
    .btn-danger { background:#dc3545; color:#fff; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-calendar-alt"></i> Exam Routine
        <small>Exam Conduct — ধাপ ৩: Date/Time Sheet (V-X ও HS দুটোই)</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <div>
            <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Exam</label>
            <select name="exam_key" id="examKeySelect" onchange="onExamChange()">
                <option value="">-- Select Exam --</option>
                <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
                <option value="<?php echo $key; ?>" data-fixed-class="<?php echo (int)($eo['fixed_class_id'] ?? 0); ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                    <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div id="classPickerWrap" style="<?php echo ($current_exam && $current_exam['source']==='hs') ? 'display:none;' : ''; ?>">
            <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Class</label>
            <select name="class_id" onchange="this.form.submit()">
                <option value="">-- Select Class --</option>
                <?php mysqli_data_seek($classes, 0); while($c = mysqli_fetch_assoc($classes)): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo ($class_id == $c['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['class_name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <?php if($current_exam): ?>
        <div style="align-self:flex-end;">
            <a class="btn btn-outline" href="exam_routine_print.php?exam_key=<?php echo urlencode($exam_key); ?>" target="_blank"><i class="fas fa-print"></i> Print Full Schedule</a>
        </div>
        <?php endif; ?>
    </form>
    <script>
    function onExamChange() {
        var sel = document.getElementById('examKeySelect');
        var opt = sel.options[sel.selectedIndex];
        var fixedClass = opt ? opt.getAttribute('data-fixed-class') : '0';
        if (fixedClass && fixedClass !== '0') {
            window.location = 'exam_routine.php?exam_key=' + encodeURIComponent(sel.value) + '&class_id=' + fixedClass;
        } else {
            sel.form.submit();
        }
    }
    </script>

    <?php if($current_exam && $class_id > 0): ?>

        <?php if(!$class_shift): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i>
            এই ক্লাসের জন্য shift এখনো ঠিক করা হয়নি। আগে
            <a href="exam_class_shift.php?exam_key=<?php echo urlencode($exam_key); ?>" style="color:#842029;font-weight:700;">Class → Shift Mapping</a>-এ গিয়ে এই ক্লাসের shift বসান।
        </div>
        <?php elseif(count($subjects) === 0): ?>
        <div class="alert alert-info"><i class="fas fa-info-circle"></i>
            <?php if($current_exam['source']==='v-x'): ?>
            এই ক্লাসে এই session-এ কোনো exam subject সিলেক্ট করা নেই। আগে <a href="class_subjects.php" style="color:#003366;font-weight:600;">Class Subjects</a>-এ গিয়ে সাবজেক্ট বেছে নিন।
            <?php else: ?>
            এই HS exam-এ কোনো subject/marks config করা নেই। আগে <a href="hs_exam_subject_marks.php" style="color:#003366;font-weight:600;">HS Marks Config</a>-এ গিয়ে সাবজেক্ট বসান।
            <?php endif; ?>
        </div>
        <?php else: ?>

        <div class="alert alert-info"><i class="fas fa-clock"></i> এই ক্লাসের shift: <b><?php echo htmlspecialchars($class_shift['shift_name']); ?></b>
            <?php if($class_shift['default_start_time']): ?> (default: <?php echo date('h:i A', strtotime($class_shift['default_start_time'])); ?>–<?php echo date('h:i A', strtotime($class_shift['default_end_time'])); ?>)<?php endif; ?>
            — নিচের প্রতিটা row এই shift-এই সেভ হবে।
        </div>

        <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <table>
            <thead>
                <tr><th>Subject</th><th>Full Marks</th><th>Date</th><th>Start Time</th><th>End Time</th></tr>
            </thead>
            <tbody>
                <?php foreach($subjects as $sub):
                    $existing = $routine_by_subject[$sub['subject_id']] ?? null;
                    $start_default = $existing['start_time'] ?? ($class_shift['default_start_time'] ?? '');
                    $end_default   = $existing['end_time'] ?? ($class_shift['default_end_time'] ?? '');
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($sub['subject_name']); ?></strong>
                        <input type="hidden" name="subject_id[]" value="<?php echo $sub['subject_id']; ?>">
                    </td>
                    <td class="full-marks"><?php echo isset($sub['full_marks']) && $sub['full_marks'] !== null ? (int)$sub['full_marks'] : '—'; ?></td>
                    <td><input type="date" name="exam_date[]" value="<?php echo $existing['exam_date'] ?? ''; ?>"></td>
                    <td><input type="time" name="start_time[]" value="<?php echo htmlspecialchars($start_default); ?>"></td>
                    <td><input type="time" name="end_time[]" value="<?php echo htmlspecialchars($end_default); ?>"></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div style="margin-top:18px;">
            <button type="submit" name="save_routine" class="btn btn-success"><i class="fas fa-save"></i> Save Routine</button>
        </div>
        <p style="font-size:12px;color:#6c7a8a;margin-top:8px;"><i class="fas fa-info-circle"></i> কোনো subject-এর Date খালি রাখলে সেটার routine সেভ হবে না। Full Marks কলামটা শুধু রেফারেন্সের জন্য — duration আপনি নিজেই ঠিক করবেন।</p>
        </form>

        <?php endif; ?>
    <?php endif; ?>

    <?php if($current_exam && count($full_routine) > 0): ?>
    <hr style="margin:30px 0;border:none;border-top:1px solid #e4edf6;">
    <h4 style="color:#003366;margin-bottom:12px;"><i class="fas fa-list"></i> Full Routine — <?php echo htmlspecialchars($current_exam['label']); ?></h4>
    <table>
        <thead><tr><th>Date</th><th>Shift</th><th>Class</th><th>Subject</th><th>Time</th><th>Action</th></tr></thead>
        <tbody>
            <?php foreach($full_routine as $r): ?>
            <tr>
                <td><?php echo date('d M Y', strtotime($r['exam_date'])); ?></td>
                <td><span class="shift-badge"><?php echo htmlspecialchars($r['shift_name']); ?></span></td>
                <td><?php echo htmlspecialchars($r['class_name']); ?></td>
                <td><?php echo htmlspecialchars($r['subject_name']); ?></td>
                <td><?php echo date('h:i A', strtotime($r['start_time'])) . ' – ' . date('h:i A', strtotime($r['end_time'])); ?></td>
                <td>
                    <form method="post" style="display:inline;" onsubmit="return confirm('Delete this routine entry?')">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="delete_id" value="<?php echo $r['id']; ?>">
                        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
                        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
                        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                        <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php elseif($current_exam): ?>
    <div class="empty-state" style="margin-top:20px;"><i class="fas fa-calendar-times" style="font-size:32px;opacity:.4;"></i><p style="margin-top:10px;">এই exam-এর জন্য এখনো কোনো ক্লাসের routine সেভ হয়নি।</p></div>
    <?php endif; ?>

</div>
</body>
</html>

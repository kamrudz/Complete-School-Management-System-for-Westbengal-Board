<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

if (!$exam_source || $exam_id <= 0) { die("Exam সিলেক্ট করা হয়নি।"); }

// Exam label + school name (best-effort; adjust if your school_settings table differs)
$exam_label = '';
if ($exam_source === 'v-x') {
    $e = mysqli_fetch_assoc(mysqli_query($conn, "SELECT e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.id=$exam_id"));
    $exam_label = ($e['exam_name'] ?? '') . ' (' . ($e['session_name'] ?? '') . ')';
} else {
    $e = mysqli_fetch_assoc(mysqli_query($conn, "SELECT h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.id=$exam_id"));
    $exam_label = ($e['exam_name'] ?? '') . ' — ' . ($e['class_name'] ?? '') . ' (' . ($e['academic_year'] ?? '') . ')';
}

$school_name = '';
$srow = mysqli_fetch_assoc(mysqli_query($conn, "SHOW TABLES LIKE 'school_settings'"));
if ($srow) {
    $sr = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings LIMIT 1"));
    $school_name = $sr['school_name'] ?? ($sr['site_name'] ?? '');
}

$q = mysqli_query($conn, "
    SELECT r.*, c.class_name, sub.subject_name, es.shift_name, es.shift_order
    FROM exam_routine r
    LEFT JOIN classes c ON r.class_id = c.id
    LEFT JOIN subjects sub ON r.subject_id = sub.id
    LEFT JOIN exam_shifts es ON es.id = r.shift_id
    WHERE r.exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND r.exam_id=$exam_id
    ORDER BY r.exam_date ASC, es.shift_order ASC, c.sort_order ASC
");
$rows = [];
while ($r = mysqli_fetch_assoc($q)) { $rows[] = $r; }

// Group: date -> shift -> [rows]
$grouped = [];
foreach ($rows as $r) {
    $grouped[$r['exam_date']][$r['shift_name']][] = $r;
}
ksort($grouped);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Exam Schedule Print</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; font-family: 'Segoe UI', Arial, sans-serif; }
body { padding: 25px; color:#1a1a1a; }
.header { text-align:center; margin-bottom: 18px; border-bottom: 2px solid #003366; padding-bottom: 12px; }
.header h2 { color:#003366; }
.header .school { font-size: 20px; font-weight:700; color:#003366; }
.header .exam { font-size: 15px; margin-top: 4px; color:#333; }
.date-block { margin-bottom: 18px; page-break-inside: avoid; }
.date-title { background:#003366; color:#fff; padding:6px 12px; font-weight:700; font-size:13px; border-radius:4px 4px 0 0; }
table { width:100%; border-collapse: collapse; font-size: 12.5px; }
th, td { border: 1px solid #ccd6e0; padding: 6px 10px; text-align:left; }
th { background:#eef3fa; color:#003366; }
.shift-label { font-weight:700; color:#856404; }
.print-btn { margin-bottom:15px; }
.print-btn button { padding:8px 18px; background:#003366; color:#fff; border:none; border-radius:6px; cursor:pointer; font-weight:600; }
@media print { .print-btn { display:none; } body{ padding:0 15px; } }
</style>
</head>
<body>

<div class="print-btn"><button onclick="window.print()">🖨️ Print</button></div>

<div class="header">
    <div class="school"><?php echo htmlspecialchars($school_name ?: 'School'); ?></div>
    <div class="exam">Exam Schedule — <?php echo htmlspecialchars($exam_label); ?></div>
</div>

<?php if (empty($grouped)): ?>
    <p style="text-align:center;color:#888;padding:30px;">এই exam-এর কোনো routine এখনো সেভ করা হয়নি।</p>
<?php else: ?>
    <?php foreach ($grouped as $date => $shift_rows): ?>
    <div class="date-block">
        <div class="date-title"><?php echo date('l, d F Y', strtotime($date)); ?></div>
        <table>
            <thead>
                <tr><th style="width:16%;">Shift</th><th style="width:14%;">Class</th><th>Subject</th><th style="width:22%;">Time</th></tr>
            </thead>
            <tbody>
            <?php foreach ($shift_rows as $shift_name => $items): ?>
                <?php foreach ($items as $i => $row): ?>
                <tr>
                    <?php if ($i === 0): ?>
                        <td class="shift-label" rowspan="<?php echo count($items); ?>"><?php echo htmlspecialchars($shift_name); ?></td>
                    <?php endif; ?>
                    <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td><?php echo date('h:i A', strtotime($row['start_time'])) . ' – ' . date('h:i A', strtotime($row['end_time'])); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>

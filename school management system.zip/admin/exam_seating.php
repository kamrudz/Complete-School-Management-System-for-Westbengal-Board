<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ============================================================
// Core helper: turn ordered class buckets into a flat seat sequence
// (with null = intentionally-left-empty seat) according to the
// chosen arrangement mode. This is shared by both Auto and Manual
// generation so the anti-cheating logic stays identical everywhere.
// ============================================================
function arrange_into_slots(array $buckets, int $seats_per_bench, string $mode): array {
    $flat = [];
    if ($mode === 'mixed') {
        // Seat-level round robin across all classes -> finest mixing,
        // adjacent seats are almost never the same class.
        $work = $buckets;
        while (true) {
            $any = false;
            foreach ($work as &$b) {
                if (!empty($b)) { $flat[] = array_shift($b); $any = true; }
            }
            unset($b);
            if (!$any) break;
        }
    } elseif ($mode === 'not_mixed') {
        // One class fills its own contiguous benches; when it runs out,
        // pad up to the next bench boundary so the next class always
        // starts a fresh bench (no two classes share one bench).
        foreach ($buckets as $bucket) {
            foreach ($bucket as $stu) { $flat[] = $stu; }
            $rem = count($flat) % $seats_per_bench;
            if ($rem !== 0) {
                for ($i = $rem; $i < $seats_per_bench; $i++) { $flat[] = null; }
            }
        }
    } else { // alternate
        // Whole-bench round robin: bench 1 = class A, bench 2 = class B,
        // bench 3 = class A again... each bench is still single-class.
        $work = $buckets;
        while (true) {
            $any = false;
            foreach ($work as &$b) {
                if (empty($b)) continue;
                $any = true;
                for ($i = 0; $i < $seats_per_bench; $i++) {
                    $flat[] = !empty($b) ? array_shift($b) : null;
                }
            }
            unset($b);
            if (!$any) break;
        }
    }
    // Trim trailing empty padding at the very end (no class follows it).
    while (!empty($flat) && end($flat) === null) { array_pop($flat); }
    return $flat;
}

function estimate_benches_needed(array $class_counts, int $seats_per_bench, string $mode): int {
    if ($mode === 'mixed') {
        $total = array_sum($class_counts);
        return (int)ceil($total / max(1,$seats_per_bench));
    }
    $sum = 0;
    foreach ($class_counts as $c) { $sum += (int)ceil($c / max(1,$seats_per_bench)); }
    return $sum;
}

// ===== Fetch active session BEFORE any POST handler so $active_session_id is available =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

// ===== SAVE ROOM USAGE (per exam + shift) =====
if(isset($_POST['save_rooms'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id  = (int)$_POST['exam_id'];
    $shift_id = (int)$_POST['shift_id'];
    if ($exam_id <= 0 || $shift_id <= 0) { header("Location: exam_seating.php"); exit(); }

    $room_ids = $_POST['room_id'] ?? [];
    $benches  = $_POST['bench_use'] ?? [];
    $genders  = $_POST['gender'] ?? [];

    $del = mysqli_prepare($conn, "DELETE FROM exam_room_usage WHERE exam_source=? AND exam_id=? AND shift_id=?");
    mysqli_stmt_bind_param($del, 'sii', $exam_source, $exam_id, $shift_id);
    mysqli_stmt_execute($del);
    mysqli_stmt_close($del);

    $ins = mysqli_prepare($conn, "INSERT INTO exam_room_usage (exam_source, exam_id, shift_id, room_id, gender, benches_used) VALUES (?,?,?,?,?,?)");
    $saved = 0;
    foreach ($room_ids as $i => $rid) {
        $rid = (int)$rid;
        if (empty($_POST['use_room'][$rid])) continue;
        $bu  = (int)($benches[$rid] ?? 0);
        $gen = in_array($genders[$rid] ?? '', ['Boys','Girls'], true) ? $genders[$rid] : 'Boys';
        if ($bu <= 0) continue;
        mysqli_stmt_bind_param($ins, 'siiisi', $exam_source, $exam_id, $shift_id, $rid, $gen, $bu);
        mysqli_stmt_execute($ins);
        $saved++;
    }
    mysqli_stmt_close($ins);
    $_SESSION['success'] = "$saved টা রুম এই shift-এর জন্য সেভ হয়েছে।";
    header("Location: exam_seating.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&shift_id=$shift_id");
    exit();
}

// ===== Shared: fetch students of a shift+gender, grouped into class buckets (ordered) =====
function get_shift_class_buckets($conn, $exam_source, $exam_id, $shift_id, $gender_db_value, $active_session_id) {
    $exam_source_sql = mysqli_real_escape_string($conn, $exam_source);
    $class_rows = [];
    $q = mysqli_query($conn, "
        SELECT c.id AS class_id
        FROM exam_class_shift ecs
        JOIN classes c ON c.id = ecs.class_id
        WHERE ecs.exam_source='$exam_source_sql' AND ecs.exam_id=$exam_id AND ecs.shift_id=$shift_id
        ORDER BY c.sort_order ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $class_rows[] = (int)$r['class_id']; }
    if (empty($class_rows)) return [[], []];

    $class_list = implode(',', $class_rows);
    $by_class = [];
    foreach ($class_rows as $cid) { $by_class[$cid] = []; } // preserve class order even if empty
    $sq = mysqli_query($conn, "
        SELECT s.id AS student_id, s.gender, sah.class_id, sah.section_id, sah.roll_no
        FROM students s
        JOIN student_academic_history sah ON sah.student_id = s.id AND sah.academic_status='Current' AND sah.session_id=$active_session_id
        WHERE sah.class_id IN ($class_list) AND s.student_status='Active'
        ORDER BY sah.class_id ASC, sah.section_id ASC, CAST(sah.roll_no AS UNSIGNED) ASC
    ");
    $unassignable = [];
    while ($row = mysqli_fetch_assoc($sq)) {
        if ($row['gender'] === $gender_db_value) { $by_class[$row['class_id']][] = $row; }
        elseif (!in_array($row['gender'], ['Male','Female'], true)) { $unassignable[] = $row; }
    }
    return [array_values($by_class), $unassignable, $by_class]; // buckets, unassignable, by_class (keyed)
}

// ===== GENERATE SEATING — AUTO =====
if(isset($_POST['generate_seating'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id  = (int)$_POST['exam_id'];
    $shift_id = (int)$_POST['shift_id'];
    $exam_source_sql = mysqli_real_escape_string($conn, $exam_source);

    $setting = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exam_seating_settings WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id"));
    $seats_per_bench = (int)($setting['seats_per_bench'] ?? 2);
    $mode = $setting['arrangement_mode'] ?? 'mixed';

    $delp = mysqli_prepare($conn, "DELETE FROM exam_seating_plan WHERE exam_source=? AND exam_id=? AND shift_id=?");
    mysqli_stmt_bind_param($delp, 'sii', $exam_source, $exam_id, $shift_id);
    mysqli_stmt_execute($delp);
    mysqli_stmt_close($delp);

    $ins = mysqli_prepare($conn, "INSERT INTO exam_seating_plan (exam_source, exam_id, shift_id, room_id, student_id, class_id, section_id, bench_no, seat_in_bench, seat_no) VALUES (?,?,?,?,?,?,?,?,?,?)");

    $summary = [];
    $leftover_total = 0;
    $unassignable_total = 0;
    foreach (['Boys' => 'Male', 'Girls' => 'Female'] as $gender => $gdb) {
        [$buckets, $unassignable] = get_shift_class_buckets($conn, $exam_source, $exam_id, $shift_id, $gdb, $active_session_id ?? 0);
        $unassignable_total += count($unassignable);
        $total_needed = array_sum(array_map('count', $buckets));

        $flat = arrange_into_slots($buckets, $seats_per_bench, $mode);

        $rq = mysqli_query($conn, "SELECT ru.room_id, ru.benches_used, r.room_name FROM exam_room_usage ru JOIN exam_rooms r ON r.id=ru.room_id WHERE ru.exam_source='$exam_source_sql' AND ru.exam_id=$exam_id AND ru.shift_id=$shift_id AND ru.gender='$gender' ORDER BY r.id ASC");
        $idx = 0; $placed = 0;
        while ($room = mysqli_fetch_assoc($rq)) {
            $room_id = (int)$room['room_id'];
            for ($bench_no = 1; $bench_no <= (int)$room['benches_used']; $bench_no++) {
                for ($seat_in_bench = 1; $seat_in_bench <= $seats_per_bench; $seat_in_bench++) {
                    $stu = $flat[$idx] ?? null;
                    $idx++;
                    if ($stu === null) continue;
                    $seat_no = ($bench_no - 1) * $seats_per_bench + $seat_in_bench;
                    mysqli_stmt_bind_param($ins, 'siiiiiiiii', $exam_source, $exam_id, $shift_id, $room_id, $stu['student_id'], $stu['class_id'], $stu['section_id'], $bench_no, $seat_in_bench, $seat_no);
                    mysqli_stmt_execute($ins);
                    $placed++;
                }
            }
        }
        $real_total = 0;
        foreach ($flat as $s) { if ($s !== null) $real_total++; }
        $leftover = $real_total - $placed;
        if ($leftover > 0) $leftover_total += $leftover;
        $summary[$gender] = "মোট $total_needed জন, বসানো হয়েছে $placed জন" . ($leftover > 0 ? ", বাকি $leftover জন (সিট কম পড়েছে)" : "");
    }
    mysqli_stmt_close($ins);

    $msg = "Auto Seating generated (" . strtoupper(str_replace('_',' ',$mode)) . ") — Boys: {$summary['Boys']} | Girls: {$summary['Girls']}";
    if ($unassignable_total > 0) $msg .= " | ⚠ $unassignable_total জন ছাত্রের gender ঠিকমতো সেট নেই, ম্যানুয়ালি বসাতে হবে।";
    if ($leftover_total > 0) {
        $_SESSION['error'] = $msg . " — আরও বেঞ্চ/রুম যোগ করে আবার Generate করুন।";
    } else {
        $_SESSION['success'] = $msg;
    }
    header("Location: exam_seating.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&shift_id=$shift_id");
    exit();
}

// ===== GENERATE SEATING — MANUAL (per room, per class counts) =====
if(isset($_POST['generate_manual'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id  = (int)$_POST['exam_id'];
    $shift_id = (int)$_POST['shift_id'];
    $exam_source_sql = mysqli_real_escape_string($conn, $exam_source);

    $setting = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exam_seating_settings WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id"));
    $seats_per_bench = (int)($setting['seats_per_bench'] ?? 2);
    $mode = $setting['arrangement_mode'] ?? 'mixed';

    $delp = mysqli_prepare($conn, "DELETE FROM exam_seating_plan WHERE exam_source=? AND exam_id=? AND shift_id=?");
    mysqli_stmt_bind_param($delp, 'sii', $exam_source, $exam_id, $shift_id);
    mysqli_stmt_execute($delp);
    mysqli_stmt_close($delp);

    $ins = mysqli_prepare($conn, "INSERT INTO exam_seating_plan (exam_source, exam_id, shift_id, room_id, student_id, class_id, section_id, bench_no, seat_in_bench, seat_no) VALUES (?,?,?,?,?,?,?,?,?,?)");

    $manual = $_POST['manual'] ?? []; // [gender][room_id][class_id] = count
    $summary = [];
    $shortfall_msgs = [];
    foreach (['Boys' => 'Male', 'Girls' => 'Female'] as $gender => $gdb) {
        [, , $by_class] = get_shift_class_buckets($conn, $exam_source, $exam_id, $shift_id, $gdb, $active_session_id ?? 0);
        // $by_class: class_id => queue of students (already ordered by section/roll)
        $rq = mysqli_query($conn, "SELECT ru.room_id, ru.benches_used, r.room_name FROM exam_room_usage ru JOIN exam_rooms r ON r.id=ru.room_id WHERE ru.exam_source='$exam_source_sql' AND ru.exam_id=$exam_id AND ru.shift_id=$shift_id AND ru.gender='$gender' ORDER BY r.id ASC");
        $placed_total = 0;
        while ($room = mysqli_fetch_assoc($rq)) {
            $room_id = (int)$room['room_id'];
            $room_counts = $manual[$gender][$room_id] ?? [];
            $room_buckets = [];
            foreach ($by_class as $cid => &$queue) {
                $want = (int)($room_counts[$cid] ?? 0);
                if ($want <= 0) continue;
                $take = array_splice($queue, 0, $want); // consume from the shared class queue in roll order
                if (!empty($take)) $room_buckets[] = $take;
            }
            unset($queue);
            if (empty($room_buckets)) continue;

            $flat = arrange_into_slots($room_buckets, $seats_per_bench, $mode);
            $max_seats = (int)$room['benches_used'] * $seats_per_bench;
            $idx = 0;
            for ($bench_no = 1; $bench_no <= (int)$room['benches_used']; $bench_no++) {
                for ($seat_in_bench = 1; $seat_in_bench <= $seats_per_bench; $seat_in_bench++) {
                    $stu = $flat[$idx] ?? null;
                    $idx++;
                    if ($stu === null) continue;
                    $seat_no = ($bench_no - 1) * $seats_per_bench + $seat_in_bench;
                    mysqli_stmt_bind_param($ins, 'siiiiiiiii', $exam_source, $exam_id, $shift_id, $room_id, $stu['student_id'], $stu['class_id'], $stu['section_id'], $bench_no, $seat_in_bench, $seat_no);
                    mysqli_stmt_execute($ins);
                    $placed_total++;
                }
            }
            if (count($flat) > $max_seats) {
                $shortfall_msgs[] = htmlspecialchars($room['room_name']) . "-এ বেঞ্চে জায়গা কম পড়েছে";
            }
        }
        $summary[$gender] = "$placed_total জন বসানো হয়েছে";
    }
    mysqli_stmt_close($ins);

    $msg = "Manual Seating generated — Boys: {$summary['Boys']} | Girls: {$summary['Girls']}";
    if (!empty($shortfall_msgs)) {
        $_SESSION['error'] = $msg . " | ⚠ " . implode(', ', $shortfall_msgs);
    } else {
        $_SESSION['success'] = $msg;
    }
    header("Location: exam_seating.php?exam_key=" . urlencode($exam_source . ':' . $exam_id) . "&shift_id=$shift_id");
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')'];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')'];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;
$exam_source_sql = $exam_source ? mysqli_real_escape_string($conn, $exam_source) : '';

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

// Shifts for this exam
$shifts = [];
if ($current_exam) {
    $q = mysqli_query($conn, "SELECT * FROM exam_shifts WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id ORDER BY shift_order ASC");
    while ($r = mysqli_fetch_assoc($q)) { $shifts[] = $r; }
}
$shift_id = isset($_GET['shift_id']) ? (int)$_GET['shift_id'] : 0;
if ($shift_id <= 0 && count($shifts) === 1) { $shift_id = (int)$shifts[0]['id']; }
$current_shift = null;
foreach ($shifts as $s) { if ($s['id'] == $shift_id) { $current_shift = $s; break; } }

// Seating settings for this exam
$setting = null;
if ($current_exam) {
    $setting = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exam_seating_settings WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id"));
}
$seats_per_bench = (int)($setting['seats_per_bench'] ?? 2);
$mode = $setting['arrangement_mode'] ?? 'mixed';
$mode_label = ['mixed'=>'Mixed','not_mixed'=>'Not Mixed','alternate'=>'Alternate'][$mode] ?? 'Mixed';

$all_rooms = mysqli_query($conn, "SELECT * FROM exam_rooms WHERE status='Active' ORDER BY id ASC");

$room_usage = [];
$shift_classes = [];
$need = ['Boys' => 0, 'Girls' => 0];
$class_counts = ['Boys' => [], 'Girls' => []];
if ($current_exam && $current_shift) {
    $q = mysqli_query($conn, "SELECT * FROM exam_room_usage WHERE exam_source='$exam_source_sql' AND exam_id=$exam_id AND shift_id=$shift_id");
    while ($r = mysqli_fetch_assoc($q)) { $room_usage[$r['room_id']] = $r; }

    $cq = mysqli_query($conn, "
        SELECT c.id, c.class_name
        FROM exam_class_shift ecs JOIN classes c ON c.id = ecs.class_id
        WHERE ecs.exam_source='$exam_source_sql' AND ecs.exam_id=$exam_id AND ecs.shift_id=$shift_id
        ORDER BY c.sort_order ASC
    ");
    while ($r = mysqli_fetch_assoc($cq)) { $shift_classes[] = $r; }

    if (!empty($shift_classes)) {
        $cids = implode(',', array_column($shift_classes, 'id'));
        $gq = mysqli_query($conn, "
            SELECT s.gender, sah.class_id, COUNT(*) c
            FROM students s
            JOIN student_academic_history sah ON sah.student_id=s.id AND sah.academic_status='Current' AND s.student_status='Active' AND sah.session_id=$active_session_id
            WHERE sah.class_id IN ($cids)
            GROUP BY s.gender, sah.class_id
        ");
        while ($r = mysqli_fetch_assoc($gq)) {
            $g = $r['gender'] === 'Male' ? 'Boys' : ($r['gender'] === 'Female' ? 'Girls' : null);
            if (!$g) continue;
            $need[$g] += (int)$r['c'];
            $class_counts[$g][$r['class_id']] = (int)$r['c'];
        }
    }
}
$benches_needed = [
    'Boys' => estimate_benches_needed($class_counts['Boys'], max(1,$seats_per_bench), $mode),
    'Girls' => estimate_benches_needed($class_counts['Girls'], max(1,$seats_per_bench), $mode),
];
$benches_planned = ['Boys' => 0, 'Girls' => 0];
foreach ($room_usage as $ru) { $benches_planned[$ru['gender']] += (int)$ru['benches_used']; }

$seating_by_room = [];
$seated_count = 0;
$seating_by_room = [];
if ($current_exam && $current_shift) {
    $q = mysqli_query($conn, "
        SELECT sp.*, st.student_name, st.gender AS student_gender, c.class_name, sec.section_name
        FROM exam_seating_plan sp
        JOIN students st ON st.id = sp.student_id
        LEFT JOIN classes c ON c.id = sp.class_id
        LEFT JOIN sections sec ON sec.id = sp.section_id
        WHERE sp.exam_source='$exam_source_sql' AND sp.exam_id=$exam_id AND sp.shift_id=$shift_id
          AND st.student_status='Active'
        ORDER BY sp.room_id, sp.bench_no, sp.seat_in_bench
    ");
    while ($r = mysqli_fetch_assoc($q)) {
        $seating_by_room[$r['room_id']][$r['bench_no']][] = $r;
        $seated_count++;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Seating</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 1200px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }

    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }

    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display:flex; gap:16px; flex-wrap:wrap; }
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 260px; background: #fff; }

    .settings-strip { display:flex; justify-content: space-between; align-items:center; background:#fff3cd; color:#856404; padding: 10px 16px; border-radius: 10px; margin-bottom: 18px; font-size: 13px; }
    .settings-strip a { color: #856404; font-weight:700; }

    .need-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px; }
    .need-card { padding: 14px 18px; border-radius: 12px; border: 2px solid #e4edf6; }
    .need-card.ok { border-color: #28a745; background: #f4fbf6; }
    .need-card.short { border-color: #dc3545; background: #fdf4f4; }
    .need-card b { font-size: 20px; color: #003366; }
    .need-card .lbl { font-size: 12px; color: #6c7a8a; text-transform: uppercase; }

    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table input[type="number"], table select { padding: 6px 8px; border: 1.5px solid #d0dbe8; border-radius: 6px; font-size: 12px; width: 90px; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-primary { background: #003366; color: #fff; }
    .btn-success { background: #28a745; color: #fff; }
    .btn-outline { background:#fff; border:2px solid #003366; color:#003366; }

    .tab-toggle { display:flex; gap:8px; margin: 20px 0 14px; }
    .tab-toggle button { padding: 8px 18px; border-radius: 20px; border: 2px solid #e4edf6; background: #fff; font-weight: 600; font-size: 12px; cursor: pointer; }
    .tab-toggle button.active { background: #003366; color: #fff; border-color: #003366; }
    .tab-panel { display: none; }
    .tab-panel.active { display: block; }

    .room-card { border: 1px solid #e4edf6; border-radius: 12px; margin-bottom: 16px; overflow: hidden; }
    .room-card h5 { background: #f0f7ff; padding: 10px 16px; color: #003366; display:flex; justify-content: space-between; }
    .bench-block { border-bottom: 1px dashed #e4edf6; padding: 8px 16px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .bench-block .bench-tag { font-size:11px; font-weight:700; color:#856404; background:#fff3cd; padding:2px 8px; border-radius:10px; min-width:70px; }
    .seat-chip { font-size:11px; padding:3px 9px; border-radius: 8px; background:#eef3fa; color:#003366; }
    .manual-matrix input { width: 60px; }

    .live-counter { display:flex; align-items:center; gap:8px; background:#fff3cd; color:#856404; border:2px solid #ffe69c; padding:8px 14px; border-radius:10px; font-size:13px; margin-bottom:8px; transition: all 0.2s ease; }
    .live-counter.enough { background:#d4edda; color:#155724; border-color:#a3d9b1; }
    .live-counter i { font-size:14px; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-chair"></i> Exam Seating
        <small>Exam Conduct — Shift-wise Room + Bench Distribution (V-X ও HS)</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <div>
            <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Exam</label>
            <select name="exam_key" onchange="this.form.submit()">
                <option value="">-- Select Exam --</option>
                <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
                <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                    <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php if($current_exam): ?>
        <div>
            <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Shift</label>
            <select name="shift_id" onchange="this.form.submit()">
                <option value="">-- Select Shift --</option>
                <?php foreach($shifts as $s): ?>
                <option value="<?php echo $s['id']; ?>" <?php echo ($shift_id == $s['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['shift_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="hidden" name="exam_key" value="<?php echo htmlspecialchars($exam_key); ?>">
        </div>
        <?php endif; ?>
    </form>

    <?php if($current_exam && empty($shifts)): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> এই exam-এ shift সেট করা নেই। আগে <a href="exam_shift_settings.php?exam_key=<?php echo urlencode($exam_key); ?>" style="color:#842029;font-weight:700;">Shift Settings</a>-এ যান।</div>
    <?php elseif($current_exam && $current_shift): ?>

    <div class="settings-strip">
        <span><i class="fas fa-chair"></i> এই exam-এ: <b><?php echo $seats_per_bench; ?> জন/বেঞ্চ</b>, মোড: <b><?php echo $mode_label; ?></b></span>
        <a href="exam_seating_settings.php?exam_key=<?php echo urlencode($exam_key); ?>"><i class="fas fa-cog"></i> Change</a>
    </div>

    <div class="need-row">
        <div class="need-card <?php echo $benches_planned['Boys'] >= $benches_needed['Boys'] ? 'ok' : 'short'; ?>">
            <div class="lbl"><i class="fas fa-child"></i> Boys (<?php echo htmlspecialchars($current_shift['shift_name']); ?>) — <?php echo $need['Boys']; ?> জন, দরকার <?php echo $benches_needed['Boys']; ?> বেঞ্চ</div>
            <b><?php echo $benches_planned['Boys']; ?></b> বেঞ্চ প্ল্যান করা হয়েছে
        </div>
        <div class="need-card <?php echo $benches_planned['Girls'] >= $benches_needed['Girls'] ? 'ok' : 'short'; ?>">
            <div class="lbl"><i class="fas fa-child"></i> Girls (<?php echo htmlspecialchars($current_shift['shift_name']); ?>) — <?php echo $need['Girls']; ?> জন, দরকার <?php echo $benches_needed['Girls']; ?> বেঞ্চ</div>
            <b><?php echo $benches_planned['Girls']; ?></b> বেঞ্চ প্ল্যান করা হয়েছে
        </div>
    </div>

    <h4 style="color:#003366;margin-bottom:8px;"><i class="fas fa-door-open"></i> এই Shift-এ কোন কোন রুম, কয়টা বেঞ্চ ব্যবহার হবে</h4>
    <form method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
    <input type="hidden" name="shift_id" value="<?php echo $shift_id; ?>">

    <?php
    mysqli_data_seek($all_rooms, 0);
    $all_r = [];
    while ($rr = mysqli_fetch_assoc($all_rooms)) { $all_r[] = $rr; }
    $boys_rooms = array_filter($all_r, fn($r) => $r['default_gender'] === 'Boys');
    $girls_rooms = array_filter($all_r, fn($r) => $r['default_gender'] === 'Girls');
    $any_rooms = array_filter($all_r, fn($r) => $r['default_gender'] === 'Any');
    ?>

    <?php foreach (['Boys' => $boys_rooms, 'Girls' => $girls_rooms] as $gname => $g_rooms):
        if (empty($g_rooms)) continue;
        $show_rooms = array_merge($g_rooms, $any_rooms);
    ?>
    <h5 style="color:#003366;margin:16px 0 6px;"><i class="fas fa-<?php echo $gname==='Boys'?'male':'female'; ?>"></i> <?php echo $gname; ?> Rooms</h5>
    <div class="live-counter" id="liveCounter<?php echo $gname; ?>" data-need="<?php echo $need[$gname]; ?>">
        <i class="fas fa-chair"></i> নির্বাচিত হয়েছে: <b><span class="live-seats">0</span> আসন</b> (<span class="live-benches">0</span> বেঞ্চ) — দরকার <b><?php echo $need[$gname]; ?> জন</b>
    </div>
    <table>
        <thead><tr><th style="width:50px;">ব্যবহার?</th><th>Room</th><th>Location</th><th>মোট বেঞ্চ</th><th>এই shift-এ কয়টা বেঞ্চ</th></tr></thead>
        <tbody>
        <?php foreach ($show_rooms as $r):
            $used = $room_usage[$r['id']] ?? null;
            $bu = $used ? (int)$used['benches_used'] : (int)$r['benches'];
        ?>
        <tr>
            <td><input type="checkbox" class="seat-cb" data-gender="<?php echo $gname; ?>" name="use_room[<?php echo $r['id']; ?>]" value="1" <?php echo $used ? 'checked' : ''; ?>></td>
            <td><strong><?php echo htmlspecialchars($r['room_name']); ?></strong>
                <input type="hidden" name="room_id[]" value="<?php echo $r['id']; ?>">
            </td>
            <td><?php echo htmlspecialchars($r['location'] ?? ''); ?></td>
            <td><?php echo (int)$r['benches']; ?></td>
            <td><input type="number" class="bench-input" data-gender="<?php echo $gname; ?>" name="bench_use[<?php echo $r['id']; ?>]" min="1" max="<?php echo (int)$r['benches']; ?>" value="<?php echo $bu; ?>"></td>
            <td style="display:none;"><input type="hidden" name="gender[<?php echo $r['id']; ?>]" value="<?php echo $gname; ?>"></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endforeach; ?>

    <div style="margin-top:15px;">
        <button type="submit" name="save_rooms" class="btn btn-primary"><i class="fas fa-save"></i> Save Room Selection</button>
    </div>
    </form>
    <script>
    // Room usage checkbox/bench বদলানোর সাথে সাথে লাইভ টোটাল (Boys/Girls আলাদা) দেখায় —
    // save করার আগেই বোঝা যায় কতটা লাগবে vs কতটা সিলেক্ট হলো।
    (function(){
        var seatsPerBench = <?php echo (int)$seats_per_bench; ?>;
        function recalc(gender) {
            var seats = 0, benches = 0;
            document.querySelectorAll('.seat-cb[data-gender="' + gender + '"]').forEach(function(cb){
                if (!cb.checked) return;
                var row = cb.closest('tr');
                var benchInput = row.querySelector('.bench-input');
                var bu = benchInput ? (parseInt(benchInput.value, 10) || 0) : 0;
                benches += bu;
                seats += bu * seatsPerBench;
            });
            var box = document.getElementById('liveCounter' + gender);
            if (!box) return;
            box.querySelector('.live-seats').textContent = seats;
            box.querySelector('.live-benches').textContent = benches;
            var need = parseInt(box.getAttribute('data-need'), 10) || 0;
            box.classList.toggle('enough', seats >= need);
        }
        function recalcAll(){ recalc('Boys'); recalc('Girls'); }
        document.querySelectorAll('.seat-cb, .bench-input').forEach(function(el){
            el.addEventListener('change', recalcAll);
            el.addEventListener('input', recalcAll);
        });
        recalcAll(); // পেজ লোড হওয়ার সাথে সাথে আগে থেকে checked/সেভ করা row-গুলোর টোটালও দেখাবে
    })();
    </script>

    <?php if(!empty($room_usage)): ?>
    <div class="tab-toggle">
        <button type="button" class="active" onclick="showTab('auto', this)"><i class="fas fa-random"></i> Auto Generate</button>
        <button type="button" onclick="showTab('manual', this)"><i class="fas fa-hand-pointer"></i> Manual Allocation</button>
    </div>

    <div id="tab-auto" class="tab-panel active">
        <form method="POST" onsubmit="return confirm('আগের কোনো seating থাকলে সেটা মুছে নতুন করে বসানো হবে। এগোবেন?')">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <input type="hidden" name="shift_id" value="<?php echo $shift_id; ?>">
        <p style="font-size:12px;color:#6c7a8a;margin-bottom:10px;">সিস্টেম নিজে থেকে "<?php echo $mode_label; ?>" মোড অনুযায়ী সব ক্লাসের ছাত্র বেঞ্চে বসিয়ে দেবে (class → section → roll অনুযায়ী)।</p>
        <button type="submit" name="generate_seating" class="btn btn-success"><i class="fas fa-random"></i> Auto Generate Seating</button>
        </form>
    </div>

    <div id="tab-manual" class="tab-panel">
        <p style="font-size:12px;color:#6c7a8a;margin-bottom:10px;">প্রতিটা রুমে কোন ক্লাসের কতজন যাবে লিখুন — বাকিটা (কে কে যাবে, কীভাবে বেঞ্চে মিশবে) সিস্টেম "<?php echo $mode_label; ?>" মোড অনুযায়ী ঠিক করবে, class → section → roll ক্রম মেনে।</p>
        <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <input type="hidden" name="shift_id" value="<?php echo $shift_id; ?>">

        <?php foreach (['Boys','Girls'] as $gender):
            $rooms_g = array_filter($room_usage, fn($ru) => $ru['gender'] === $gender);
            if (empty($rooms_g) || empty($shift_classes)) continue;
        ?>
        <h5 style="color:#003366;margin:16px 0 6px;"><i class="fas fa-<?php echo $gender=='Boys'?'male':'female'; ?>"></i> <?php echo $gender; ?> (মোট <?php echo $need[$gender]; ?> জন)</h5>
        <div style="overflow-x:auto;">
        <table class="manual-matrix">
            <thead><tr><th>Class</th>
                <?php foreach($rooms_g as $room_id => $ru): $rn = ''; mysqli_data_seek($all_rooms,0); while($rr=mysqli_fetch_assoc($all_rooms)){ if($rr['id']==$room_id){$rn=$rr['room_name'];break;} } ?>
                <th><?php echo htmlspecialchars($rn); ?> (<?php echo (int)$ru['benches_used']*$seats_per_bench; ?> সিট)</th>
                <?php endforeach; ?>
            </tr></thead>
            <tbody>
            <?php foreach($shift_classes as $c): $avail = $class_counts[$gender][$c['id']] ?? 0; if ($avail <= 0) continue; ?>
            <tr>
                <td><strong><?php echo htmlspecialchars($c['class_name']); ?></strong> <span style="color:#6c7a8a;font-size:11px;">(<?php echo $avail; ?> জন)</span></td>
                <?php foreach($rooms_g as $room_id => $ru): ?>
                <td><input type="number" name="manual[<?php echo $gender; ?>][<?php echo $room_id; ?>][<?php echo $c['id']; ?>]" min="0" value="0"></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endforeach; ?>

        <div style="margin-top:15px;">
            <button type="submit" name="generate_manual" class="btn btn-success"><i class="fas fa-hand-pointer"></i> Generate Manual Seating</button>
        </div>
        </form>
    </div>
    <script>
    function showTab(name, btn) {
        document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.tab-toggle button').forEach(b => b.classList.remove('active'));
        document.getElementById('tab-' + name).classList.add('active');
        btn.classList.add('active');
    }
    </script>
    <?php endif; ?>

    <?php if($seated_count > 0): ?>
    <hr style="margin:30px 0;border:none;border-top:1px solid #e4edf6;">
    <h4 style="color:#003366;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center;">
        <span><i class="fas fa-list"></i> Generated Seating — <?php echo htmlspecialchars($current_shift['shift_name']); ?> (<?php echo $seated_count; ?> জন)</span>
        <a href="exam_room_display.php?exam_key=<?php echo urlencode($exam_key); ?>&shift_id=<?php echo $shift_id; ?>" target="_blank" class="btn btn-outline" style="font-size:12px;padding:8px 16px;"><i class="fas fa-print"></i> Room Allocation Notice</a>
    </h4>

    <?php
    $gendered_rooms = ['Boys' => [], 'Girls' => []];
    foreach ($seating_by_room as $rid => $benches_arr) {
        $g = $room_usage[$rid]['gender'] ?? 'Boys';
        $gendered_rooms[$g][$rid] = $benches_arr;
    }
    foreach (['Boys', 'Girls'] as $g):
        if (empty($gendered_rooms[$g])) continue;
        $g_icon = $g === 'Boys' ? 'male' : 'female';
        $g_count = 0;
        foreach ($gendered_rooms[$g] as $benches_arr) { $g_count += array_sum(array_map('count', $benches_arr)); }
    ?>
    <h5 style="color:#003366;margin:18px 0 10px;padding:8px 14px;background:#f0f7ff;border-radius:8px;display:flex;align-items:center;gap:8px;">
        <i class="fas fa-<?php echo $g_icon; ?>"></i> <?php echo $g; ?> — <?php echo $g_count; ?> জন
    </h5>
    <?php foreach($gendered_rooms[$g] as $room_id => $benches_arr):
        $room_name = '';
        mysqli_data_seek($all_rooms, 0);
        while($rr = mysqli_fetch_assoc($all_rooms)) { if($rr['id'] == $room_id) { $room_name = $rr['room_name']; break; } }
        $total_in_room = array_sum(array_map('count', $benches_arr));
        ksort($benches_arr);
    ?>
    <div class="room-card">
        <h5><span><?php echo htmlspecialchars($room_name); ?></span><span><?php echo $total_in_room; ?> জন</span></h5>
        <?php foreach($benches_arr as $bench_no => $seats): ?>
        <div class="bench-block">
            <span class="bench-tag">Bench <?php echo $bench_no; ?></span>
            <?php foreach($seats as $seat): ?>
            <span class="seat-chip"><?php echo htmlspecialchars($seat['student_name']); ?> — <?php echo htmlspecialchars($seat['class_name']); ?><?php echo $seat['section_name'] ? '/'.htmlspecialchars($seat['section_name']) : ''; ?></span>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
    <?php endforeach; ?>
    <?php endif; ?>

    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== SAVE SETTINGS =====
if (isset($_POST['save_settings'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    $seats_per_bench = max(1, (int)$_POST['seats_per_bench']);
    $mode = in_array($_POST['arrangement_mode'] ?? '', ['mixed','not_mixed','alternate'], true) ? $_POST['arrangement_mode'] : 'mixed';

    if ($exam_id <= 0) { header("Location: exam_seating_settings.php"); exit(); }

    $stmt = mysqli_prepare($conn, "INSERT INTO exam_seating_settings (exam_source, exam_id, seats_per_bench, arrangement_mode) VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE seats_per_bench = VALUES(seats_per_bench), arrangement_mode = VALUES(arrangement_mode)");
    mysqli_stmt_bind_param($stmt, 'siis', $exam_source, $exam_id, $seats_per_bench, $mode);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    $_SESSION['success'] = "Seating settings সেভ হয়েছে — {$seats_per_bench} জন/বেঞ্চ।";
    header("Location: exam_seating_settings.php?exam_key=" . urlencode($exam_source . ':' . $exam_id));
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')'];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')'];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

$settings = ['seats_per_bench' => 2, 'arrangement_mode' => 'mixed'];
if ($current_exam) {
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exam_seating_settings WHERE exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND exam_id=$exam_id"));
    if ($row) { $settings = $row; }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seating Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 800px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 320px; background: #fff; }
    .form-group { margin-bottom: 18px; }
    .form-group label { font-weight: 600; font-size: 13px; color: #1a3b55; display: block; margin-bottom: 6px; }
    .form-group input, .form-group select { padding: 9px 12px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; width: 100%; max-width: 300px; }
    .form-group .hint { font-size: 12px; color: #6c7a8a; margin-top: 5px; }
    .mode-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 8px; }
    .mode-card { border: 2px solid #e4edf6; border-radius: 10px; padding: 14px; cursor: pointer; }
    .mode-card.active { border-color: #003366; background: #f0f7ff; }
    .mode-card h5 { color: #003366; font-size: 13px; margin-bottom: 5px; }
    .mode-card p { font-size: 11px; color: #6c7a8a; }
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn-success { background: #28a745; color: #fff; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-cog"></i> Seating Settings
        <small>প্রতিটা exam-এর নিজস্ব বেঞ্চ-সাইজ ও বসানোর ধরন</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Exam</label>
        <select name="exam_key" onchange="this.form.submit()">
            <option value="">-- Select Exam --</option>
            <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
            <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if($current_exam): ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">

        <div class="form-group">
            <label><i class="fas fa-chair"></i> একটা বেঞ্চে কতজন বসবে?</label>
            <input type="number" name="seats_per_bench" min="1" max="6" value="<?php echo (int)$settings['seats_per_bench']; ?>">
            <div class="hint">যেমন: Class V–X-এ 3 জন/বেঞ্চ, Class XI/XII (HS)-এ 2 জন/বেঞ্চ — যেটা এই exam-এর জন্য উপযুক্ত সেটা দিন।</div>
        </div>

        <div class="form-group">
            <label><i class="fas fa-random"></i> বসানোর ধরন (Arrangement Mode)</label>
            <input type="hidden" name="arrangement_mode" id="modeInput" value="<?php echo htmlspecialchars($settings['arrangement_mode']); ?>">
            <div class="mode-cards">
                <div class="mode-card <?php echo $settings['arrangement_mode']==='mixed'?'active':''; ?>" onclick="pickMode('mixed', this)">
                    <h5><i class="fas fa-shuffle"></i> Mixed</h5>
                    <p>প্রতিটা সিট পালাক্রমে ভিন্ন ভিন্ন ক্লাস — এক বেঞ্চে ভিন্ন ক্লাসও থাকতে পারে। নকল ঠেকাতে সবচেয়ে কড়া।</p>
                </div>
                <div class="mode-card <?php echo $settings['arrangement_mode']==='not_mixed'?'active':''; ?>" onclick="pickMode('not_mixed', this)">
                    <h5><i class="fas fa-layer-group"></i> Not Mixed</h5>
                    <p>প্রতিটা বেঞ্চ সবসময় এক ক্লাসেরই। ক্লাস বদলালে নতুন বেঞ্চ থেকে শুরু হবে, বেঞ্চের মাঝে ক্লাস বদলাবে না।</p>
                </div>
                <div class="mode-card <?php echo $settings['arrangement_mode']==='alternate'?'active':''; ?>" onclick="pickMode('alternate', this)">
                    <h5><i class="fas fa-grip-lines"></i> Alternate</h5>
                    <p>বেঞ্চ ধরে ধরে ক্লাস পালটাবে (বেঞ্চ ১ = ক্লাস A, বেঞ্চ ২ = ক্লাস B, বেঞ্চ ৩ = ক্লাস A...) — প্রতি বেঞ্চ একক ক্লাসের।</p>
                </div>
            </div>
        </div>

        <button type="submit" name="save_settings" class="btn btn-success"><i class="fas fa-save"></i> Save Settings</button>
    </form>

    <script>
    function pickMode(mode, el) {
        document.getElementById('modeInput').value = mode;
        document.querySelectorAll('.mode-card').forEach(c => c.classList.remove('active'));
        el.classList.add('active');
    }
    </script>
    <?php endif; ?>
</div>
</body>
</html>

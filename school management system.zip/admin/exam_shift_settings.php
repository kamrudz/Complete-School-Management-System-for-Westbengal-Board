<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== SAVE SHIFTS =====
if (isset($_POST['save_shifts'])) {
    verify_csrf_or_die();
    $exam_source = in_array($_POST['exam_source'] ?? '', ['v-x','hs'], true) ? $_POST['exam_source'] : 'v-x';
    $exam_id = (int)$_POST['exam_id'];
    if ($exam_id <= 0) { header("Location: exam_shift_settings.php"); exit(); }

    $orders = $_POST['shift_order'] ?? [];
    $names  = $_POST['shift_name'] ?? [];
    $starts = $_POST['default_start_time'] ?? [];
    $ends   = $_POST['default_end_time'] ?? [];

    $submitted_orders = [];
    $up = mysqli_prepare($conn, "SELECT id FROM exam_shifts WHERE exam_source=? AND exam_id=? AND shift_order=?");
    $insert = mysqli_prepare($conn, "INSERT INTO exam_shifts (exam_source, exam_id, shift_order, shift_name, default_start_time, default_end_time) VALUES (?,?,?,?,?,?)");
    $update = mysqli_prepare($conn, "UPDATE exam_shifts SET shift_name=?, default_start_time=?, default_end_time=? WHERE exam_source=? AND exam_id=? AND shift_order=?");

    $saved = 0;
    foreach ($orders as $i => $ord) {
        $ord  = (int)$ord;
        $name = trim($names[$i] ?? '');
        $st   = trim($starts[$i] ?? '') ?: null;
        $en   = trim($ends[$i] ?? '') ?: null;
        if ($ord <= 0 || $name === '') continue;

        $submitted_orders[] = $ord;

        mysqli_stmt_bind_param($up, 'sii', $exam_source, $exam_id, $ord);
        mysqli_stmt_execute($up);
        $exists = mysqli_stmt_get_result($up)->fetch_assoc();

        if ($exists) {
            mysqli_stmt_bind_param($update, 'ssssii', $name, $st, $en, $exam_source, $exam_id, $ord);
            mysqli_stmt_execute($update);
        } else {
            mysqli_stmt_bind_param($insert, 'siisss', $exam_source, $exam_id, $ord, $name, $st, $en);
            mysqli_stmt_execute($insert);
        }
        $saved++;
    }
    mysqli_stmt_close($up);
    mysqli_stmt_close($update);
    mysqli_stmt_close($insert);

    // Remove shifts that existed before but were not submitted this time —
    // only if they are NOT already used in class-mapping or routine (safety).
    $removed_blocked = 0;
    $existing = mysqli_query($conn, "SELECT id, shift_order FROM exam_shifts WHERE exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND exam_id=$exam_id");
    while ($row = mysqli_fetch_assoc($existing)) {
        if (in_array((int)$row['shift_order'], $submitted_orders, true)) continue;
        $sid = (int)$row['id'];
        $used1 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM exam_class_shift WHERE shift_id=$sid"))['c'];
        $used2 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM exam_routine WHERE shift_id=$sid"))['c'];
        if ($used1 > 0 || $used2 > 0) { $removed_blocked++; continue; }
        mysqli_query($conn, "DELETE FROM exam_shifts WHERE id=$sid");
    }

    $_SESSION['success'] = "$saved টা shift সেভ হয়েছে।" . ($removed_blocked > 0 ? " ($removed_blocked টা shift মোছা যায়নি কারণ সেটা class-mapping/routine-এ ব্যবহার হচ্ছে — আগে সেগুলো সরান।)" : "");
    header("Location: exam_shift_settings.php?exam_key=" . urlencode($exam_source . ':' . $exam_id));
    exit();
}

// ===== BUILD COMBINED EXAM DROPDOWN (V-X + HS) =====
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_session_id = (int)($active_session['id'] ?? 0);

$exam_options = [];
$vx = mysqli_query($conn, "SELECT e.id, e.exam_name, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.exam_type='v-x' AND e.session_id=$active_session_id ORDER BY e.id DESC");
while ($r = mysqli_fetch_assoc($vx)) {
    $exam_options[] = ['source'=>'v-x','id'=>$r['id'],'label'=>$r['exam_name'].' ('.($r['session_name'] ?? '').')'];
}
$hs = mysqli_query($conn, "SELECT h.id, h.exam_name, h.academic_year, c.class_name FROM hs_exam h LEFT JOIN classes c ON c.id=h.class_id WHERE h.session_id=$active_session_id ORDER BY h.id DESC");
while ($r = mysqli_fetch_assoc($hs)) {
    $exam_options[] = ['source'=>'hs','id'=>$r['id'],'label'=>$r['exam_name'].' — '.($r['class_name'] ?? '').' ('.$r['academic_year'].')'];
}

$exam_key = $_GET['exam_key'] ?? '';
list($exam_source, $exam_id) = array_pad(explode(':', $exam_key, 2), 2, null);
$exam_source = in_array($exam_source, ['v-x','hs'], true) ? $exam_source : null;
$exam_id = $exam_id !== null ? (int)$exam_id : 0;

$current_exam = null;
foreach ($exam_options as $eo) { if ($eo['source'] === $exam_source && $eo['id'] == $exam_id) { $current_exam = $eo; break; } }

$shifts = [];
if ($current_exam) {
    $q = mysqli_query($conn, "SELECT * FROM exam_shifts WHERE exam_source='" . mysqli_real_escape_string($conn, $exam_source) . "' AND exam_id=$exam_id ORDER BY shift_order ASC");
    while ($row = mysqli_fetch_assoc($q)) { $shifts[] = $row; }
}
// Always show at least 3 rows to fill in (max school uses per your note = 2, but allow up to 3)
$rows_to_show = max(3, count($shifts) + 1);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Shift Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 900px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }
    .alert-info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
    .filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .filter-box select { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; min-width: 320px; background: #fff; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; vertical-align: middle; }
    table input[type="text"], table input[type="time"], table input[type="number"] { padding: 6px 8px; border: 1.5px solid #d0dbe8; border-radius: 6px; font-size: 12px; width: 100%; }
    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 22px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-primary { background: #003366; color: #fff; }
    .btn-success { background: #28a745; color: #fff; }
    .next-step { margin-top: 22px; padding: 14px 18px; background: #f0f7ff; border: 1px solid #cfe3fa; border-radius: 12px; }
    .next-step a { color: #003366; font-weight: 700; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-clock"></i> Exam Shift Settings
        <small>Exam Conduct — ধাপ ১: এই exam-এ কয়টা shift/half থাকবে</small>
    </div>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="GET" class="filter-box">
        <label style="font-size:12px;font-weight:600;color:#1a3b55;display:block;margin-bottom:4px;">Exam</label>
        <select name="exam_key" onchange="this.form.submit()">
            <option value="">-- Select Exam --</option>
            <?php foreach($exam_options as $eo): $key = $eo['source'].':'.$eo['id']; ?>
            <option value="<?php echo $key; ?>" <?php echo ($exam_key === $key) ? 'selected' : ''; ?>>
                <?php echo ($eo['source']==='hs' ? '[HS] ' : '[V-X] ') . htmlspecialchars($eo['label']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if($current_exam): ?>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> যেমন: V-X Summative-এ ২টা শিফট (First Shift, Second Shift) দিতে পারেন, HS Semester-এ ১টা শিফট দিলেই হবে। Default time দিলে পরে Routine পাতায় auto বসবে (চাইলে বদলানো যাবে)।</div>

    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="exam_source" value="<?php echo $current_exam['source']; ?>">
        <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <table>
            <thead><tr><th style="width:70px;">Order</th><th>Shift Name</th><th>Default Start</th><th>Default End</th></tr></thead>
            <tbody>
            <?php for ($i = 0; $i < $rows_to_show; $i++):
                $row = $shifts[$i] ?? null;
                $order = $row['shift_order'] ?? ($i + 1);
            ?>
                <tr>
                    <td>
                        <input type="number" name="shift_order[]" value="<?php echo (int)$order; ?>" min="1" style="width:60px;">
                    </td>
                    <td><input type="text" name="shift_name[]" placeholder="যেমন: First Shift" value="<?php echo htmlspecialchars($row['shift_name'] ?? ''); ?>"></td>
                    <td><input type="time" name="default_start_time[]" value="<?php echo htmlspecialchars($row['default_start_time'] ?? ''); ?>"></td>
                    <td><input type="time" name="default_end_time[]" value="<?php echo htmlspecialchars($row['default_end_time'] ?? ''); ?>"></td>
                </tr>
            <?php endfor; ?>
            </tbody>
        </table>
        <p style="font-size:12px;color:#6c7a8a;margin-top:8px;"><i class="fas fa-info-circle"></i> Shift Name খালি রাখলে সেই row বাদ যাবে। কম shift লাগলে বাকি row-গুলো খালি রেখে দিন।</p>
        <div style="margin-top:15px;">
            <button type="submit" name="save_shifts" class="btn btn-success"><i class="fas fa-save"></i> Save Shifts</button>
        </div>
    </form>

    <?php if(!empty($shifts)): ?>
    <div class="next-step">
        <i class="fas fa-arrow-right"></i> এই exam-এ <b><?php echo count($shifts); ?> টা shift</b> সেট হয়ে গেছে। এখন
        <a href="exam_class_shift.php?exam_key=<?php echo urlencode($exam_key); ?>">Class → Shift Mapping</a> পাতায় গিয়ে
        কোন ক্লাস কোন shift-এ পরীক্ষা দেবে সেটা ঠিক করুন।
    </div>
    <?php endif; ?>

    <?php endif; ?>
</div>
</body>
</html>

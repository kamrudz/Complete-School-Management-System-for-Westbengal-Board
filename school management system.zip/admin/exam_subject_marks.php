<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/exam_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Full & pass marks per exam × class × subject (exam_subject_marks). Subjects come from Class Subjects (has_exam).
 * Pass marks are on the total (written + project, however split). IX–X have a project part.
 * A subject left blank is "not in this exam" — marks entry refuses it until full marks are set.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
if ($exam) $session_id = (int)$exam['session_id']; elseif (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = exam_list($session_id);
if (!$exam && $exams) { $exam = $exams[0]; $exam_id = (int)$exam['id']; }
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? array_key_first($classes));
if (!isset($classes[$class_id])) $class_id = (int)array_key_first($classes);
$back = "exam_subject_marks.php?exam_id=$exam_id&class_id=$class_id";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $exam) {
    verify_csrf_or_die();
    if (isset($_POST['save_config'])) {
        $r = exam_config_save($session_id, $exam_id, $class_id, (array)($_POST['s'] ?? []), $admin_id);
        if ($r['ok']) $_SESSION['success'] = 'Full & pass marks saved for Class ' . $classes[$class_id]['name'] . ' — ' . $r['saved'] . ' subject' . ($r['saved'] === 1 ? '' : 's') . '.';
        else { $names = exam_class_subject_list($session_id, $class_id); $_SESSION['error'] = implode('; ', array_map(fn($k, $m) => ($names[$k]['name'] ?? '') . ': ' . $m, array_keys($r['errors']), $r['errors'])); }
    } elseif (isset($_POST['copy_from'])) {
        // copy this class's config from another exam (any session): matched by subject
        $src = exam_get((int)$_POST['src_exam_id']);
        if (!$src) $_SESSION['error'] = 'Source exam not found.';
        else {
            $rows = [];
            foreach (db_get_all('SELECT * FROM exam_subject_marks WHERE exam_id = ? AND class_id = ?', 'ii', (int)$src['id'], $class_id) as $c) $rows[(int)$c['subject_id']] = ['written_full' => $c['written_full_marks'], 'project_full' => $c['project_full_marks'], 'pass' => $c['total_pass_marks']];
            if (!$rows) $_SESSION['error'] = $src['exam_name'] . ' (' . $src['session_name'] . ') has no full marks for Class ' . $classes[$class_id]['name'] . '.';
            else { $r = exam_config_save($session_id, $exam_id, $class_id, $rows, $admin_id); $_SESSION[$r['ok'] ? 'success' : 'error'] = $r['ok'] ? 'Copied ' . $r['saved'] . ' subjects from ' . $src['exam_name'] . ' (' . $src['session_name'] . ').' : 'Copy failed.'; }
        }
    }
    header('Location: ' . $back); exit;
}

$subjects = $exam ? exam_subjects($session_id, $exam_id, $class_id) : [];
$has_project = exam_class_has_project($class_id);
$summary = [];
if ($exam) foreach ($classes as $cid => $c) { $n = count(exam_class_subject_list($session_id, $cid)); $done = (int)(db_get_row('SELECT COUNT(*) n FROM exam_subject_marks WHERE session_id = ? AND exam_id = ? AND class_id = ?', 'iii', $session_id, $exam_id, $cid)['n'] ?? 0); $summary[$cid] = [$done, $n]; }
$other_exams = db_get_all("SELECT e.id, e.exam_name, s.session_name FROM exams e JOIN academic_sessions s ON s.id = e.session_id WHERE e.exam_type = 'v-x' AND e.id <> ? AND EXISTS (SELECT 1 FROM exam_subject_marks x WHERE x.exam_id = e.id AND x.class_id = ?) ORDER BY s.session_name DESC, e.exam_order", 'ii', $exam_id, $class_id);
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = $e['exam_name'];
$class_group = exam_class_group($class_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Full & Pass Marks</title>
<?php exam_styles(); ?>
<style>
    .ctabs { display: flex; gap: 6px; flex-wrap: wrap; margin: 4px 0 12px; } .ctabs a { padding: 7px 14px; border-radius: 9px; border: 1px solid #d5dde5; background: #fff; color: #3b5168; text-decoration: none; font-weight: 700; font-size: 13px; } .ctabs a.on { background: #3b1d5c; color: #fff; border-color: #3b1d5c; } .ctabs a small { font-weight: 400; font-size: 10.5px; display: block; opacity: .8; }
    .ex-table td.tot { font-weight: 700; color: #3b1d5c; } .ex-table .tlb { font-size: 10px; background: #fff6e5; color: #7a4a00; border: 1px solid #f0c987; border-radius: 4px; padding: 0 4px; margin-left: 4px; }
    .toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; } .toolbar .fill { display: flex; gap: 6px; align-items: center; font-size: 12.5px; color: #3b5168; } .toolbar .fill input { width: 60px; height: 30px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Full & Pass Marks', 'Which subjects an exam has for each class, and their full / pass marks. Marks entry checks against these.', 'fa-sliders-h', ['class_subjects.php' => '<i class="fas fa-book"></i> Class Subjects']); ?>
    <?php exam_tabs('exam_subject_marks.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? '' : 'No exams in this session'); ?></select></div>
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
    </form>

    <?php if (!$exam): ?><div class="card"><div class="ex-empty"><i class="fas fa-clipboard-list"></i>No exam in this session yet — <a href="exams.php?session_id=<?php echo $session_id; ?>">add one</a> first.</div></div>
    <?php else: ?>
    <div class="ctabs"><?php foreach ($classes as $cid => $c): [$d, $n] = $summary[$cid]; ?><a href="?exam_id=<?php echo $exam_id; ?>&class_id=<?php echo $cid; ?>" class="<?php echo $cid === $class_id ? 'on' : ''; ?>">Class <?php echo h($c['name']); ?><small><?php echo $n ? "$d / $n set" : 'no subjects'; ?></small></a><?php endforeach; ?></div>

    <div class="card">
        <h2><i class="fas fa-sliders-h"></i> <?php echo h($exam['exam_name']); ?> · Class <?php echo h($classes[$class_id]['name']); ?> <small><?php echo $has_project ? 'Written + Project' : 'Written'; ?></small></h2>
        <?php if (!$subjects): ?><div class="ex-empty"><i class="fas fa-book"></i>Class <?php echo h($classes[$class_id]['name']); ?> has no exam subjects for <?php echo h($exam['session_name']); ?> — assign them under <a href="class_subjects.php">Class Subjects</a> (tick "exam").</div>
        <?php else: ?>
        <form method="post" id="cfg">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
            <div class="toolbar noprint">
                <span class="fill">Fill all: written full <input type="text" id="fw" placeholder="90"><?php if ($has_project): ?> · project full <input type="text" id="fp" placeholder="10"><?php endif; ?> · pass (total) <input type="text" id="fps" placeholder="25"><button type="button" class="btn btn-secondary btn-sm" onclick="fillAll()">Apply</button></span>
                <?php if ($other_exams): ?><span class="fill" style="margin-left:auto">Copy from <select id="src" style="height:30px;border:1px solid #c9d6e2;border-radius:6px"><?php foreach ($other_exams as $o): ?><option value="<?php echo (int)$o['id']; ?>"><?php echo h($o['exam_name'] . ' (' . $o['session_name'] . ')'); ?></option><?php endforeach; ?></select><button type="button" class="btn btn-secondary btn-sm" onclick="copyFrom()">Copy</button></span><?php endif; ?>
            </div>
            <table class="ex-table"><thead><tr><th>Subject</th><th class="num">Written full</th><?php if ($has_project): ?><th class="num">Project full</th><?php endif; ?><th class="num">Total full</th><th class="num">Pass marks<br><small style="text-transform:none;font-weight:400">on the total</small></th></tr></thead><tbody>
            <?php foreach ($subjects as $sid => $s): ?>
            <tr data-sid="<?php echo $sid; ?>">
                <td><b><?php echo h($s['name']); ?></b><?php if ($s['tl']): ?><span class="tlb">3rd language</span><?php endif; ?><?php if (!$s['configured']): ?> <span class="chip off">not set</span><?php endif; ?></td>
                <td class="num"><input class="m wf" name="s[<?php echo $sid; ?>][written_full]" value="<?php echo $s['configured'] ? exam_fmt($s['written_full']) : ''; ?>" inputmode="decimal"></td>
                <?php if ($has_project): ?><td class="num"><input class="m pf" name="s[<?php echo $sid; ?>][project_full]" value="<?php echo $s['configured'] ? exam_fmt($s['project_full']) : ''; ?>" inputmode="decimal"></td><?php endif; ?>
                <td class="num tot tf"></td>
                <td class="num"><input class="m ps" name="s[<?php echo $sid; ?>][pass]" value="<?php echo $s['configured'] ? exam_fmt($s['pass']) : ''; ?>" inputmode="decimal"></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <div style="margin-top:12px;display:flex;gap:8px;align-items:center"><button type="submit" name="save_config" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save Class <?php echo h($classes[$class_id]['name']); ?></button><span class="note" style="margin:0">Pass marks are on the total — written + project together (e.g. 25 of 100), however the marks are split. Leave a subject blank to keep it out of this exam.</span></div>
            <input type="hidden" name="src_exam_id" id="srcId"><input type="hidden" name="copy_from" id="copyFlag" value="" disabled>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
function recalc(tr) {
    var g = function (c) { var i = tr.querySelector('input.' + c); return i ? (parseFloat(i.value) || 0) : 0; };
    var wf = g('wf'), pf = g('pf'), ps = g('ps');
    tr.querySelector('.tf').textContent = (wf + pf) || '';
    tr.querySelectorAll('input.m').forEach(function (i) { i.classList.remove('bad'); });
    if (ps > wf + pf) tr.querySelector('.ps').classList.add('bad');
}
document.querySelectorAll('tr[data-sid]').forEach(function (tr) { recalc(tr); tr.querySelectorAll('input.m').forEach(function (i) { i.addEventListener('input', function () { recalc(tr); }); }); });
function fillAll() {
    var v = { wf: document.getElementById('fw').value, pf: (document.getElementById('fp') || {}).value, ps: document.getElementById('fps').value };
    document.querySelectorAll('tr[data-sid]').forEach(function (tr) { Object.keys(v).forEach(function (k) { var i = tr.querySelector('input.' + k); if (i && v[k] !== undefined && v[k] !== '') i.value = v[k]; }); recalc(tr); });
}
function copyFrom() {
    var s = document.getElementById('src'); if (!s.value) return;
    if (!confirm('Replace this class\'s full & pass marks with ' + s.options[s.selectedIndex].text + '?')) return;
    document.getElementById('srcId').value = s.value; var f = document.getElementById('copyFlag'); f.disabled = false; f.value = '1'; document.getElementById('cfg').submit();
}
// Enter moves down the same column
document.querySelectorAll('input.m').forEach(function (i) { i.addEventListener('keydown', function (e) { if (e.key !== 'Enter') return; e.preventDefault(); var tr = i.closest('tr').nextElementSibling; if (tr) { var n = tr.querySelector('input.' + i.classList[1]); if (n) { n.focus(); n.select(); } } }); });
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/exam_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Exams (classes V–X) of a session: add / edit / delete / publish in one place.
 * Order decides the sequence on tabulation and the annual result; "counts in final" says whether the exam
 * is added into the annual total (a Test exam is not). Publishing shows the exam on the public result page.
 * An exam that already has marks can only be deleted after typing its name.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$back = 'exams.php?session_id=' . $session_id;

function exam_clean(array $in, int $session_id, int $exclude_id = 0): array {
    $name = trim((string)($in['exam_name'] ?? ''));
    if ($name === '' || mb_strlen($name) > 60) return ['error' => 'Exam name is required (up to 60 characters).'];
    if (!preg_match('/^[\p{L}\p{N} .\-\/()]+$/u', $name)) return ['error' => 'Exam name: letters, numbers, spaces and . - / ( ) only.'];
    $order = (int)($in['exam_order'] ?? 0); if ($order < 1 || $order > 20) return ['error' => 'Order must be between 1 and 20.'];
    $from = trim((string)($in['exam_date_from'] ?? '')); $to = trim((string)($in['exam_date_to'] ?? ''));
    foreach ([$from, $to] as $d) if ($d !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) return ['error' => 'Dates must be YYYY-MM-DD.'];
    if ($from !== '' && $to !== '' && $to < $from) return ['error' => 'The end date is before the start date.'];
    if (db_get_row("SELECT id FROM exams WHERE session_id = ? AND exam_type = 'v-x' AND exam_name = ? AND id <> ?", 'isi', $session_id, $name, $exclude_id)) return ['error' => 'An exam named "' . $name . '" already exists in this session.'];
    return ['data' => ['exam_name' => $name, 'exam_order' => $order, 'counts_in_final' => empty($in['counts_in_final']) ? 0 : 1, 'exam_date_from' => $from ?: null, 'exam_date_to' => $to ?: null]];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['add_exam'])) {
        $r = exam_clean($_POST, $session_id);
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else { $id = db_insert('exams', $r['data'] + ['session_id' => $session_id, 'exam_type' => 'v-x']); log_action($admin_id, 'EXAM_ADDED', 'exams', $id, null, $r['data']); $_SESSION['success'] = 'Exam "' . $r['data']['exam_name'] . '" added. Next: set its full & pass marks.'; }
    } elseif (isset($_POST['update_exam'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = exam_get($id);
        $r = $old && (int)$old['session_id'] === $session_id ? exam_clean($_POST, $session_id, $id) : ['error' => 'Exam not found.'];
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else { db_update('exams', $r['data'], ['id' => $id], 'i'); log_action($admin_id, 'EXAM_UPDATED', 'exams', $id, $old, $r['data']); $_SESSION['success'] = 'Exam "' . $r['data']['exam_name'] . '" updated.'; }
    } elseif (isset($_POST['toggle_publish'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = exam_get($id);
        if (!$old) $_SESSION['error'] = 'Exam not found.';
        else { $new = (int)$old['is_published'] ? 0 : 1; db_update('exams', ['is_published' => $new], ['id' => $id], 'i'); log_action($admin_id, $new ? 'EXAM_PUBLISHED' : 'EXAM_UNPUBLISHED', 'exams', $id); $_SESSION['success'] = $new ? '"' . $old['exam_name'] . '" is now visible on the public result page.' : '"' . $old['exam_name'] . '" is hidden from the public result page.'; }
    } elseif (isset($_POST['delete_exam'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = exam_get($id);
        if (!$old) $_SESSION['error'] = 'Exam not found.';
        else {
            $deps = exam_dependencies($id);
            $hasMarks = !empty($deps['Marks']);
            if ($hasMarks && trim((string)($_POST['confirm_name'] ?? '')) !== $old['exam_name']) $_SESSION['error'] = 'To delete "' . $old['exam_name'] . '" and its ' . $deps['Marks'] . ' marks rows, type the exam name exactly.';
            else {
                db_begin_transaction();
                try {
                    foreach (['exam_routine', 'exam_seating_plan', 'exam_duty_roster'] as $t) db_execute("DELETE FROM $t WHERE exam_id = ? AND exam_source = 'v-x'", 'i', $id);
                    db_execute('DELETE FROM exams WHERE id = ?', 'i', $id);   // marks / config / hprc cascade
                    db_commit();
                    log_action($admin_id, 'EXAM_DELETED', 'exams', $id, $old + ['dependencies' => $deps], null);
                    $_SESSION['success'] = 'Exam "' . $old['exam_name'] . '" deleted' . ($deps ? ' with ' . implode(', ', array_map(fn($k, $v) => "$v $k", array_keys($deps), $deps)) : '') . '.';
                } catch (Throwable $e) { db_rollback(); error_log('exam delete: ' . $e->getMessage()); $_SESSION['error'] = 'Delete failed.'; }
            }
        }
    }
    header('Location: ' . $back); exit;
}

$section = exam_section_clean($_GET['section'] ?? '');
$exams = exam_list($session_id, array_keys(exam_classes($section)));   // counts belong to the section being looked at
$edit = null;
if (isset($_GET['edit'])) { $edit = exam_get((int)$_GET['edit']); if ($edit && (int)$edit['session_id'] !== $session_id) $edit = null; }
$deps_of = []; foreach ($exams as $e) $deps_of[(int)$e['id']] = exam_dependencies((int)$e['id']);
$next_order = $exams ? max(array_map(fn($e) => (int)$e['exam_order'], $exams)) + 1 : 1;
$used_names = array_map(fn($e) => $e['exam_name'], $exams);
$suggest = array_values(array_diff(EXAM_NAME_PRESETS, $used_names));
$classes_n = count(exam_classes($section));
$fmt = fn($d) => $d ? date('d M', strtotime($d)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Exams</title>
<?php exam_styles(); ?>
<style>
    .two { display: grid; grid-template-columns: 1fr 340px; gap: 18px; align-items: start; } @media (max-width: 950px) { .two { grid-template-columns: 1fr; } }
    .ex-table tr.editing td { background: #fff9ec; } .ex-table .acts { white-space: nowrap; } .ex-table .acts form { display: inline; }
    .ex-table .name { font-weight: 700; color: #222; } .ex-table .name small { display: block; font-weight: 400; color: #6b7d90; font-size: 11px; }
    .sug { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 6px; } .sug button { background: #f3eef8; border: 1px solid #d9c9ea; color: #3b1d5c; border-radius: 999px; padding: 2px 9px; font-size: 11.5px; cursor: pointer; }
    .pub { border: 0; cursor: pointer; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Exams', 'Classes V–X · the exams of a session, in order. Marks are entered per exam; the annual result adds up the exams that count.', 'fa-clipboard-list', ['hs_exams.php' => '<i class="fas fa-graduation-cap"></i> HS Exams (XI–XII)']); ?>
    <?php exam_tabs('exams.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
    </form>

    <div class="two">
        <div class="card">
            <h2><i class="fas fa-list-ol"></i> <?php echo count($exams); ?> exam<?php echo count($exams) === 1 ? '' : 's'; ?> <small>in <?php echo h($sessions[$session_id] ?? ''); ?></small></h2>
            <?php if (!$exams): ?><div class="ex-empty"><i class="fas fa-clipboard-list"></i>No exams yet — add the first one on the right (1st Summative, 2nd Summative, 3rd Summative).</div>
            <?php else: ?>
            <table class="ex-table"><thead><tr><th class="num">#</th><th>Exam</th><th>Dates</th><th class="num">Final</th><th>Full marks set</th><th>Marks entered</th><th class="num">Public</th><th></th></tr></thead><tbody>
            <?php foreach ($exams as $e): $id = (int)$e['id']; $d = $deps_of[$id]; ?>
            <tr class="<?php echo $edit && (int)$edit['id'] === $id ? 'editing' : ''; ?>">
                <td class="num"><?php echo (int)$e['exam_order']; ?></td>
                <td class="name"><?php echo h($e['exam_name']); ?><small>added <?php echo date('d M Y', strtotime($e['created_at'])); ?></small></td>
                <td><?php echo $e['exam_date_from'] ? h($fmt($e['exam_date_from']) . ($e['exam_date_to'] && $e['exam_date_to'] !== $e['exam_date_from'] ? ' – ' . $fmt($e['exam_date_to']) : '')) : '<span style="color:#aaa">—</span>'; ?></td>
                <td class="num"><?php echo (int)$e['counts_in_final'] ? '<span class="chip ok">counts</span>' : '<span class="chip off">not counted</span>'; ?></td>
                <td><a href="exam_subject_marks.php?exam_id=<?php echo $id; ?>&section=<?php echo h($section); ?>" class="chip <?php echo (int)$e['classes_configured'] >= $classes_n ? 'ok' : ((int)$e['classes_configured'] ? 'warn' : 'bad'); ?>" style="text-decoration:none"><?php echo (int)$e['classes_configured']; ?> / <?php echo $classes_n; ?> classes</a></td>
                <td><a href="marks_entry.php?exam_id=<?php echo $id; ?>&section=<?php echo h($section); ?>" class="chip <?php echo (int)$e['subjects_with_marks'] ? 'ok' : 'off'; ?>" style="text-decoration:none"><?php echo (int)$e['subjects_with_marks']; ?> subject<?php echo (int)$e['subjects_with_marks'] === 1 ? '' : 's'; ?> · <?php echo (int)$e['marks_rows']; ?> rows</a></td>
                <td class="num"><form method="post" onsubmit="return confirm('<?php echo (int)$e['is_published'] ? 'Hide this exam from the public result page?' : 'Publish this exam on the public result page?'; ?>');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="exam_id" value="<?php echo $id; ?>"><button type="submit" name="toggle_publish" value="1" class="chip pub <?php echo (int)$e['is_published'] ? 'ok' : 'off'; ?>" title="Click to <?php echo (int)$e['is_published'] ? 'unpublish' : 'publish'; ?>"><i class="fas <?php echo (int)$e['is_published'] ? 'fa-eye' : 'fa-eye-slash'; ?>"></i> <?php echo (int)$e['is_published'] ? 'Published' : 'Hidden'; ?></button></form></td>
                <td class="acts"><a href="?session_id=<?php echo $session_id; ?>&edit=<?php echo $id; ?>#form" class="btn btn-secondary btn-sm" title="Edit"><i class="fas fa-pen"></i></a>
                    <button type="button" class="btn btn-danger btn-sm" title="Delete" onclick="exDelete(<?php echo $id; ?>, <?php echo h(json_encode($e['exam_name'])); ?>, <?php echo h(json_encode($d)); ?>)"><i class="fas fa-trash"></i></button></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <p class="note">Order = the sequence on tabulation and the annual result. "Counts" = added into the annual total (untick for a Test / Selection Test). Publish only after the tabulation is checked.</p>
            <?php endif; ?>
        </div>
        <div class="card" id="form">
            <h2><i class="fas <?php echo $edit ? 'fa-pen' : 'fa-plus'; ?>"></i> <?php echo $edit ? 'Edit ' . h($edit['exam_name']) : 'Add exam'; ?></h2>
            <form method="post" class="pf">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
                <?php if ($edit): ?><input type="hidden" name="exam_id" value="<?php echo (int)$edit['id']; ?>"><?php endif; ?>
                <label>Exam name</label><input type="text" name="exam_name" id="exName" maxlength="60" required value="<?php echo h($edit['exam_name'] ?? ''); ?>" placeholder="1st Summative">
                <?php if (!$edit && $suggest): ?><div class="sug"><?php foreach ($suggest as $s): ?><button type="button" onclick="document.getElementById('exName').value=<?php echo h(json_encode($s)); ?>"><?php echo h($s); ?></button><?php endforeach; ?></div><?php endif; ?>
                <label>Order</label><input type="number" name="exam_order" min="1" max="20" required value="<?php echo (int)($edit['exam_order'] ?? $next_order); ?>">
                <div class="row"><div><label>From</label><input type="date" name="exam_date_from" value="<?php echo h($edit['exam_date_from'] ?? ''); ?>"></div><div><label>To</label><input type="date" name="exam_date_to" value="<?php echo h($edit['exam_date_to'] ?? ''); ?>"></div></div>
                <label class="chk"><input type="checkbox" name="counts_in_final" value="1" <?php echo !$edit || (int)$edit['counts_in_final'] ? 'checked' : ''; ?>> Counts in the annual result</label>
                <div class="acts"><button type="submit" name="<?php echo $edit ? 'update_exam' : 'add_exam'; ?>" value="1" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo $edit ? 'Save' : 'Add exam'; ?></button><?php if ($edit): ?><a href="<?php echo h($back); ?>" class="btn btn-secondary">Cancel</a><?php endif; ?></div>
            </form>
            <p class="note">V–VIII: 3 Summative + Formative (HPRC, shown on the report card only) · IX–X: 3 Summative. Dates are optional (shown on the admit card and the exam routine).</p>
        </div>
    </div>
</div>

<div class="modal" id="exDel"><div class="box">
    <h3 style="margin:0 0 8px;color:#b71c1c"><i class="fas fa-exclamation-triangle"></i> Delete exam</h3>
    <p id="exDelText" style="font-size:13.5px"></p>
    <form method="post" class="pf"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="exam_id" id="exDelId">
        <div id="exDelConfirm" style="display:none"><label>Type the exam name to confirm</label><input type="text" name="confirm_name" autocomplete="off"></div>
        <div class="acts"><button type="submit" name="delete_exam" value="1" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('exDel').classList.remove('open')">Cancel</button></div>
    </form>
</div></div>
<script>
function exDelete(id, name, deps) {
    var keys = Object.keys(deps), t = 'Delete "' + name + '"?';
    if (keys.length) t += ' This also removes: ' + keys.map(function (k) { return deps[k] + ' ' + k; }).join(', ') + '.';
    document.getElementById('exDelId').value = id;
    document.getElementById('exDelText').textContent = t;
    document.getElementById('exDelConfirm').style.display = deps['Marks'] ? '' : 'none';
    document.getElementById('exDel').classList.add('open');
}
document.getElementById('exDel').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

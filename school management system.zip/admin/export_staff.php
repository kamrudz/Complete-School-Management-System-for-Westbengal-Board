<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/export_ui.php';

/**
 * Export Staff to Excel — the Students export, for staff.
 *   GET  — filters (status / type / designation / subject / search), live count, every staff
 *          field grouped, presets, preview of the first 50 rows.
 *   POST — the .xlsx (fields[] + the same filters, CSRF-checked).
 * Passwords never leave the server; Aadhaar / account numbers are full (this is an office export).
 */
$cols = [];
foreach (['sl' => 'SL No.', 'employee_id' => 'Employee ID', 'state_govt_id' => 'State Govt ID', 'national_code' => 'National code', 'staff_name' => 'Name', 'short_code' => 'Short code', 'designation' => 'Designation', 'staff_type' => 'Staff type', 'subject_name' => 'Subject', 'academic_section' => 'Academic section', 'vacancy_status' => 'Post type', 'qualification' => 'Qualification'] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Identity & post'];
foreach (['date_of_birth' => 'Date of birth', 'age' => 'Age (years)', 'gender' => 'Gender', 'blood_group' => 'Blood group', 'religion' => 'Religion', 'caste' => 'Caste', 'mother_tongue' => 'Mother tongue', 'marital_status' => 'Marital status', 'spouse_name' => "Spouse's name", 'father_name' => "Father's name", 'mother_name' => "Mother's name"] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Personal'];
foreach (['date_of_joining' => 'Date of joining', 'service_years' => 'Service (years)', 'joining_date_present_post' => 'Joining (present post)', 'retirement_date' => 'Retirement date', 'approval_number' => 'Approval number', 'date_of_approval' => 'Date of approval', 'service_status' => 'Service status', 'status_date' => 'Status date'] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Service'];
foreach (['mobile' => 'Mobile', 'email' => 'Email', 'present_address' => 'Present address', 'permanent_address' => 'Permanent address', 'aadhar_number' => 'Aadhaar', 'voter_number' => 'Voter ID', 'pan_number' => 'PAN'] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Contact & IDs'];
foreach (['bank_name' => 'Bank', 'branch_name' => 'Branch', 'account_number' => 'Account number', 'ifsc_code' => 'IFSC'] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Bank'];
foreach (['can_login' => 'Portal login', 'portal_state' => 'Portal password', 'last_login_at' => 'Last portal login', 'has_photo' => 'Photo on file', 'remarks' => 'Remarks', 'created_at' => 'Record created'] as $k => $l) $cols[$k] = ['label' => $l, 'group' => 'Other'];
$groups = ['Identity & post', 'Personal', 'Service', 'Contact & IDs', 'Bank', 'Other'];
$presets = [
    'basic'   => ['label' => 'Default',          'fields' => ['sl', 'employee_id', 'staff_name', 'designation', 'subject_name', 'mobile']],
    'govt'    => ['label' => 'Govt / iOSMS',     'fields' => ['sl', 'staff_name', 'state_govt_id', 'national_code', 'designation', 'date_of_birth', 'gender', 'date_of_joining', 'aadhar_number', 'pan_number', 'mobile']],
    'contact' => ['label' => 'Contact sheet',    'fields' => ['sl', 'staff_name', 'designation', 'subject_name', 'mobile', 'email', 'present_address']],
    'bank'    => ['label' => 'Bank / salary',    'fields' => ['sl', 'employee_id', 'staff_name', 'designation', 'bank_name', 'branch_name', 'account_number', 'ifsc_code', 'pan_number']],
    'portal'  => ['label' => 'Portal logins',    'fields' => ['sl', 'staff_name', 'designation', 'state_govt_id', 'can_login', 'portal_state', 'last_login_at']],
    'all'     => ['label' => 'All fields',       'fields' => array_keys($cols)],
];

// ---------- filters ----------
$in = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;
$status = in_array($in['status'] ?? '', array_merge(staff_service_statuses(), ['all']), true) ? $in['status'] : 'Active';
$type   = in_array($in['type'] ?? '', ['Teaching', 'Non-teaching'], true) ? $in['type'] : '';
$desig  = isset(staff_designations()[$in['designation'] ?? '']) ? $in['designation'] : '';
$subject = in_array($in['subject'] ?? '', staff_subjects(), true) ? $in['subject'] : '';
$search = trim((string)($in['search'] ?? ''));

function export_query(string $status, string $type, string $desig, string $subject, string $search, bool $count_only): array {
    $where = []; $params = []; $types = '';
    if ($status !== 'all') { $where[] = 'service_status = ?'; $params[] = $status; $types .= 's'; }
    if ($type !== '')  { $where[] = 'staff_type = ?';  $params[] = $type;  $types .= 's'; }
    if ($desig !== '') { $where[] = 'designation = ?'; $params[] = $desig; $types .= 's'; }
    if ($subject !== '') { $where[] = 'subject_name = ?'; $params[] = $subject; $types .= 's'; }
    if ($search !== '') { $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%'; $where[] = '(staff_name LIKE ? OR employee_id LIKE ? OR state_govt_id LIKE ? OR national_code LIKE ? OR mobile LIKE ? OR email LIKE ?)'; array_push($params, $like, $like, $like, $like, $like, $like); $types .= 'ssssss'; }
    $sql = ($count_only ? 'SELECT COUNT(*) AS c' : 'SELECT *, (login_password IS NOT NULL AND login_password <> \'\') AS has_pw') . ' FROM staff' . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
        . ($count_only ? '' : " ORDER BY FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher', 'Librarian', 'Clerk', 'Accountant', 'Group D'), date_of_joining, staff_name");
    return [$sql, $types, $params];
}

/** One export cell, formatted the way it appears in the sheet. */
function export_value(array $r, string $k, int $sl): string {
    static $today = null; $today = $today ?: new DateTime('today');
    switch ($k) {
        case 'sl': return (string)$sl;
        case 'age': return $r['date_of_birth'] ? (string)(new DateTime($r['date_of_birth']))->diff($today)->y : '';
        case 'service_years': return $r['date_of_joining'] ? (string)(new DateTime($r['date_of_joining']))->diff($today)->y : '';
        case 'date_of_birth': case 'date_of_joining': case 'joining_date_present_post': case 'retirement_date': case 'date_of_approval': case 'status_date': case 'created_at':
            return $r[$k] ? date('d-m-Y', strtotime($r[$k])) : '';
        case 'last_login_at': return $r[$k] ? date('d-m-Y H:i', strtotime($r[$k])) : '';
        case 'can_login': return $r['can_login'] ? 'Yes' : 'No';
        case 'portal_state': return !$r['can_login'] ? '' : (!$r['state_govt_id'] ? 'No Govt ID' : ($r['has_pw'] ? ($r['pw_must_change'] ? 'Default (must change)' : 'Own password') : 'Not set'));
        case 'has_photo': return $r['photo'] ? 'Yes' : 'No';
        default: return (string)($r[$k] ?? '');
    }
}

// ---------- POST: the file ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $fields = array_values(array_intersect(array_keys($cols), array_map('strval', (array)($_POST['fields'] ?? []))));
    if (!$fields) { $_SESSION['error'] = 'Pick at least one field to export.'; header('Location: export_staff.php?' . http_build_query(compact('status', 'type', 'desig', 'subject', 'search'))); exit(); }
    [$sql, $types, $params] = export_query($status, $type, $desig, $subject, $search, false);
    $out = [array_map(fn($k) => $cols[$k]['label'], $fields)]; $sl = 0;
    foreach (db_get_all($sql, $types, ...$params) as $r) { $sl++; $line = []; foreach ($fields as $k) $line[] = export_value($r, $k, $sl); $out[] = $line; }
    $tag = $status === 'all' ? 'all' : strtolower($status);
    SimpleXLSXWriter::download('staff_' . $tag . '_' . date('Y-m-d') . '.xlsx', $out, 'Staff', ['header_rows' => 1, 'freeze_rows' => 1]);
}

// ---------- GET: the page ----------
[$csql, $ctypes, $cparams] = export_query($status, $type, $desig, $subject, $search, true);
$count = (int)(db_get_row($csql, $ctypes, ...$cparams)['c'] ?? 0);
[$psql, $ptypes, $pparams] = export_query($status, $type, $desig, $subject, $search, false);
$preview = []; $sl = 0;
foreach (db_get_all($psql . ' LIMIT 50', $ptypes, ...$pparams) as $r) { $sl++; $line = []; foreach ($cols as $k => $c) $line[$k] = export_value($r, $k, $sl); $preview[] = $line; }
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$q = ['status' => $status, 'type' => $type, 'designation' => $desig, 'subject' => $subject, 'search' => $search];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Export Staff</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php export_styles(); ?>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-file-excel"></i> Export Staff</div>
        <a href="staff.php?<?php echo h(http_build_query(array_filter($q))); ?>" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Staff</a>
    </div>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <form method="get" class="ex-filter" id="filterForm">
        <div><label>Status</label><select name="status"><?php foreach (['Active' => 'Active', 'all' => 'All', 'Transferred' => 'Transferred', 'Retired' => 'Retired', 'Deceased' => 'Deceased'] as $v => $l): ?><option value="<?php echo $v; ?>" <?php echo $status === $v ? 'selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
        <div><label>Type</label><select name="type"><option value="">All</option><option value="Teaching" <?php echo $type === 'Teaching' ? 'selected' : ''; ?>>Teaching</option><option value="Non-teaching" <?php echo $type === 'Non-teaching' ? 'selected' : ''; ?>>Non-teaching</option></select></div>
        <div><label>Designation</label><select name="designation"><option value="">All</option><?php foreach (array_keys(staff_designations()) as $d): ?><option value="<?php echo h($d); ?>" <?php echo $desig === $d ? 'selected' : ''; ?>><?php echo h($d); ?></option><?php endforeach; ?></select></div>
        <div><label>Subject</label><select name="subject"><option value="">All</option><?php foreach (staff_subjects() as $sub): ?><option value="<?php echo h($sub); ?>" <?php echo $subject === $sub ? 'selected' : ''; ?>><?php echo h($sub); ?></option><?php endforeach; ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="name / Employee ID / Govt ID / mobile"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <span class="ex-count"><i class="fas fa-users"></i> <?php echo number_format($count); ?> staff</span>
    </form>

    <form method="post" id="exportForm">
        <?php echo csrf_field(); ?>
        <?php foreach ($q as $k => $v): ?><input type="hidden" name="<?php echo $k; ?>" value="<?php echo h($v); ?>"><?php endforeach; ?>
        <div class="ex-presets"><span style="font-weight:700;color:#3b5168">Quick pick:</span>
            <?php foreach ($presets as $pk => $p): ?><button type="button" class="p" data-preset="<?php echo h(json_encode($p['fields'])); ?>"><?php echo h($p['label']); ?></button><?php endforeach; ?>
            <button type="button" class="p" data-preset="[]">None</button>
        </div>
        <div class="ex-groups">
            <?php foreach ($groups as $grp): ?>
            <div class="ex-group" data-group="<?php echo h($grp); ?>">
                <h4><i class="fas fa-layer-group"></i> <?php echo h($grp); ?> <span class="mini" data-all="1">all</span><span class="mini" data-all="0">none</span></h4>
                <div class="body">
                    <?php foreach ($cols as $k => $c): if ($c['group'] !== $grp) continue; ?>
                    <label><input type="checkbox" name="fields[]" value="<?php echo h($k); ?>"> <?php echo h($c['label']); ?></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="ex-prev-head"><b><i class="fas fa-eye"></i> Preview</b> <span id="prevNote"></span></div>
        <div class="ex-prev"><table id="prev"><thead></thead><tbody></tbody></table></div>
        <div class="ex-bar">
            <span class="sel" id="selCount">0 fields selected</span>
            <span class="spacer"></span>
            <a href="staff.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-success" id="dl" disabled><i class="fas fa-download"></i> Download Excel (<?php echo number_format($count); ?> rows)</button>
        </div>
    </form>
</div>
<script>
(function () {
    var PREVIEW = <?php echo json_encode($preview, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>, LABELS = <?php echo json_encode(array_map(fn($c) => $c['label'], $cols), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>, TOTAL = <?php echo $count; ?>;
    function esc(v) { return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
    function preview() {
        var f = [...document.querySelectorAll('#exportForm input[name="fields[]"]:checked')].map(function (b) { return b.value; });
        document.querySelector('#prev thead').innerHTML = '<tr>' + f.map(function (k) { return '<th>' + esc(LABELS[k]) + '</th>'; }).join('') + '</tr>';
        document.querySelector('#prev tbody').innerHTML = PREVIEW.map(function (r) { return '<tr>' + f.map(function (k) { return '<td>' + esc(r[k]) + '</td>'; }).join('') + '</tr>'; }).join('');
        document.getElementById('prevNote').textContent = TOTAL ? ('first ' + Math.min(50, TOTAL) + ' of ' + TOTAL.toLocaleString() + ' rows, exactly as they will appear in the sheet') : 'no staff match the filter';
    }
    var boxes = document.querySelectorAll('#exportForm input[name="fields[]"]'), LS = 'export_staff_fields_v1';
    function count() { preview(); var n = document.querySelectorAll('#exportForm input[name="fields[]"]:checked').length; document.getElementById('selCount').textContent = n + ' field' + (n === 1 ? '' : 's') + ' selected'; document.getElementById('dl').disabled = !n; try { localStorage.setItem(LS, JSON.stringify([...document.querySelectorAll('#exportForm input[name="fields[]"]:checked')].map(function (b) { return b.value; }))); } catch (e) {} }
    boxes.forEach(function (b) { b.addEventListener('change', count); });
    document.querySelectorAll('[data-preset]').forEach(function (btn) { btn.addEventListener('click', function () { var set = JSON.parse(btn.dataset.preset); boxes.forEach(function (b) { b.checked = set.includes(b.value); }); count(); }); });
    document.querySelectorAll('.ex-group .mini').forEach(function (m) { m.addEventListener('click', function () { m.closest('.ex-group').querySelectorAll('input').forEach(function (b) { b.checked = m.dataset.all === '1'; }); count(); }); });
    var saved = null; try { saved = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) {}
    if (saved && saved.length) boxes.forEach(function (b) { b.checked = saved.includes(b.value); });
    else document.querySelector('[data-preset]').click();
    count();
})();
</script>
</body>
</html>

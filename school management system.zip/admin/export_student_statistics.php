<?php
/** The old Excel link. Every view of the report now exports itself, so this only forwards. */
require_once '../includes/auth.php';
require_admin_login();

$keep = [];
foreach (['session_id', 'class_id', 'section_id', 'gender', 'scope', 'view'] as $k) if (isset($_GET[$k])) $keep[$k] = $_GET[$k];
$keep['export'] = 1;
header('Location: student_statistics.php?' . http_build_query($keep));
exit();

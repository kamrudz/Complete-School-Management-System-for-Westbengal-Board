<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/student_fields.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/export_ui.php';

/**
 * Export Students to Excel.
 *   GET  — the page: filters (session / class / section / status / gender / search),
 *          a live count, and every student field grouped, with presets.
 *   POST — the .xlsx (fields[] + the same filters, CSRF-checked).
 * The field list is includes/student_fields.php plus the computed columns below,
 * so the export always offers exactly what the forms hold. Text stays text in
 * Excel (a Banglar Shiksha ID keeps its leading zero).
 */

// ---------- columns on offer ----------
$B = student_bulk_fields();
$cols = ['sl' => ['label' => 'SL No.', 'group' => 'Identity'], 'school_uid' => ['label' => 'School UID', 'group' => 'Identity']];
foreach (['banglarshiksha_id', 'pen_id', 'apaar_id', 'student_aadhaar', 'birth_registration_number'] as $k) $cols[$k] = ['label' => $B[$k]['label'], 'group' => 'Identity'];
foreach (['student_name', 'name_as_per_aadhaar', 'dob', 'age', 'gender', 'blood_group', 'religion', 'caste', 'sub_caste', 'nationality', 'mother_tongue', 'disability', 'disability_type', 'disability_percentage', 'mobile', 'email'] as $k)
    $cols[$k] = ['label' => $k === 'age' ? 'Age (years)' : $B[$k]['label'], 'group' => 'Personal'];
$cols['house'] = ['label' => 'House', 'group' => 'Personal'];   // the house comes from the houses table, not from a column anyone types
foreach (['session_name' => 'Session', 'class_name' => 'Class', 'section_name' => 'Section', 'roll_no' => 'Roll', 'previous_school' => 'Previous School', 'admission_no' => 'Admission Reg No', 'admission_date' => 'Admission Date', 'admission_year' => 'Admission Year', 'admission_class' => 'Admitted to Class', 'student_status' => 'Status', 'promotion_status' => 'Promotion Status'] as $k => $l)
    $cols[$k] = ['label' => $l, 'group' => 'Academic'];
foreach (['father_name', 'father_aadhaar', 'father_voter_id', 'father_mobile', 'father_occupation', 'father_qualification', 'annual_income', 'mother_name', 'mother_aadhaar', 'mother_voter_id', 'mother_occupation', 'guardian_name', 'guardian_relation', 'guardian_contact', 'guardian_email'] as $k) $cols[$k] = ['label' => $B[$k]['label'], 'group' => 'Guardian'];
foreach (['village', 'post_office', 'police_station', 'district', 'state', 'pin_code'] as $k) $cols[$k] = ['label' => $B[$k]['label'], 'group' => 'Address'];
foreach (['bank_name', 'branch_name', 'account_number', 'ifsc_code'] as $k) $cols[$k] = ['label' => $B[$k]['label'], 'group' => 'Bank'];
$cols['remarks'] = ['label' => 'Remarks', 'group' => 'Other'];
$cols['has_photo'] = ['label' => 'Photo on file', 'group' => 'Other'];
$cols['created_at'] = ['label' => 'Record created', 'group' => 'Other'];
$groups = ['Identity', 'Personal', 'Academic', 'Guardian', 'Address', 'Bank', 'Other'];
$presets = [
    'basic'    => ['label' => 'Default',           'fields' => ['student_name', 'class_name', 'section_name', 'roll_no', 'father_name']],
    'bsp'      => ['label' => 'Banglar Shiksha',   'fields' => ['sl', 'banglarshiksha_id', 'pen_id', 'apaar_id', 'student_name', 'name_as_per_aadhaar', 'dob', 'gender', 'student_aadhaar', 'religion', 'caste', 'father_name', 'mother_name', 'class_name', 'section_name', 'roll_no', 'village', 'pin_code']],
    'contact'  => ['label' => 'Contact sheet',     'fields' => ['sl', 'roll_no', 'student_name', 'father_name', 'father_mobile', 'guardian_name', 'guardian_contact', 'mobile', 'village', 'post_office']],
    'bank'     => ['label' => 'Bank / DBT',        'fields' => ['sl', 'student_name', 'school_uid', 'banglarshiksha_id', 'father_name', 'bank_name', 'branch_name', 'account_number', 'ifsc_code']],
    'all'      => ['label' => 'All fields',        'fields' => array_keys($cols)],
];

// ---------- filters (GET for the page, POST for the file) ----------
$in = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;
$active     = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = isset($in['session_id']) && $in['session_id'] !== '' ? (int)$in['session_id'] : $active;
$class_id   = (int)($in['class_id'] ?? 0);
$section_id = (int)($in['section_id'] ?? 0);
$gender     = in_array($in['gender'] ?? '', ['Male', 'Female', 'Other'], true) ? $in['gender'] : '';
$status     = in_array($in['status'] ?? '', ['Active', 'TC', 'Passed', 'Deactivated', 'all'], true) ? $in['status'] : 'Active';
$search     = trim((string)($in['search'] ?? ''));

function export_query(int $session_id, int $class_id, int $section_id, string $gender, string $status, string $search, bool $count_only): array {
    $where = []; $params = []; $types = '';
    // one history row per student: the chosen session's row when a session is chosen, else the latest row
    if ($session_id) { $join = 'LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.session_id = ?'; $params[] = $session_id; $types .= 'i'; $where[] = 'h.id IS NOT NULL'; }
    else { $join = 'LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)'; }
    $where[] = $status === 'all' ? "s.student_status <> 'Deleted'" : 's.student_status = ?';
    if ($status !== 'all') { $params[] = $status; $types .= 's'; }
    if ($class_id)   { $where[] = 'h.class_id = ?';   $params[] = $class_id;   $types .= 'i'; }
    if ($section_id) { $where[] = 'h.section_id = ?'; $params[] = $section_id; $types .= 'i'; }
    if ($gender !== '') { $where[] = 's.gender = ?'; $params[] = $gender; $types .= 's'; }
    if ($search !== '') {   // the same fields the Students list searches, so Export gives the rows on screen
        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
        $where[] = '(s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR s.pen_id LIKE ? OR g.father_name LIKE ? OR g.guardian_name LIKE ? OR s.mobile LIKE ? OR g.guardian_contact LIKE ?)';
        array_push($params, $like, $like, $like, $like, $like, $like, $like, $like); $types .= 'ssssssss';
    }
    $sql = ($count_only ? 'SELECT COUNT(*) AS c' : "SELECT s.*, h.roll_no, h.previous_school, h.promotion_status, h.academic_status, c.class_name, sec.section_name, a.session_name, ac.class_name AS admission_class,
               g.father_name, g.father_aadhaar, g.father_voter_id, g.father_mobile, g.father_occupation, g.father_qualification, g.annual_income,
               g.mother_name, g.mother_aadhaar, g.mother_voter_id, g.mother_occupation, g.guardian_name, g.guardian_relation, g.guardian_contact, g.guardian_email, hs.name AS house_name")
        . " FROM students s $join
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN classes c ON c.id = h.class_id
            LEFT JOIN sections sec ON sec.id = h.section_id
            LEFT JOIN academic_sessions a ON a.id = h.session_id
            LEFT JOIN classes ac ON ac.id = s.admission_class_id
            LEFT JOIN houses hs ON hs.id = s.house_id
            WHERE " . implode(' AND ', $where)
        . ($count_only ? '' : ' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name');
    return [$sql, $types, $params];
}

// ---------- POST: the file ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $fields = array_values(array_intersect(array_keys($cols), array_map('strval', (array)($_POST['fields'] ?? []))));
    if (!$fields) { $_SESSION['error'] = 'Pick at least one field to export.'; header('Location: export_students.php?' . http_build_query(compact('session_id', 'class_id', 'section_id', 'gender', 'status', 'search'))); exit(); }
    [$sql, $types, $params] = export_query($session_id, $class_id, $section_id, $gender, $status, $search, false);
    $out = [array_map(fn($k) => $cols[$k]['label'], $fields)];
    $sl = 0;
    foreach (db_get_all($sql, $types, ...$params) as $r) { $sl++; $out[] = array_map(fn($k) => export_value($r, $k, $sl), $fields); }
    $tag = $class_id ? (db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $class_id)['class_name'] ?? '') . ($section_id ? '-' . (db_get_row('SELECT section_name FROM sections WHERE id = ?', 'i', $section_id)['section_name'] ?? '') : '') : ($status === 'all' ? 'all' : strtolower($status));
    SimpleXLSXWriter::download('students_' . preg_replace('/[^A-Za-z0-9\-]+/', '_', $tag) . '_' . date('Y-m-d') . '.xlsx', $out, 'Students', ['header_rows' => 1, 'freeze_rows' => 1]);
}

/** One export cell, formatted the way it appears in the sheet. */
function export_value(array $r, string $k, int $sl): string {
    static $today = null; $today = $today ?: new DateTime('today');
    switch ($k) {
        case 'sl': return (string)$sl;
        case 'school_uid': return (string)$r['id'];
        case 'age': return ($r['dob'] && $r['dob'] !== '0000-00-00') ? (string)(new DateTime($r['dob']))->diff($today)->y : '';
        case 'dob': case 'admission_date': return ($r[$k] && $r[$k] !== '0000-00-00') ? date('d-m-Y', strtotime($r[$k])) : '';
        case 'created_at': return $r[$k] ? date('d-m-Y', strtotime($r[$k])) : '';
        case 'has_photo': return $r['photo'] ? 'Yes' : 'No';
        case 'house': return (string)($r['house_name'] ?? '');
        case 'annual_income': case 'disability_percentage': return ($r[$k] === null || $r[$k] === '') ? '' : rtrim(rtrim((string)$r[$k], '0'), '.');
        default: return (string)($r[$k] ?? '');
    }
}

// ---------- GET: the page ----------
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $session_id ? db_get_all('SELECT id, class_id, section_name FROM sections WHERE session_id = ? ORDER BY class_id, section_name', 'i', $session_id) : [];
[$csql, $ctypes, $cparams] = export_query($session_id, $class_id, $section_id, $gender, $status, $search, true);
$count = (int)(db_get_row($csql, $ctypes, ...$cparams)['c'] ?? 0);
[$psql, $ptypes, $pparams] = export_query($session_id, $class_id, $section_id, $gender, $status, $search, false);
$preview = []; $sl = 0;
foreach (db_get_all($psql . ' LIMIT 50', $ptypes, ...$pparams) as $r) { $sl++; $line = []; foreach ($cols as $k => $c) $line[$k] = export_value($r, $k, $sl); $preview[] = $line; }
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$q = compact('session_id', 'class_id', 'section_id', 'gender', 'status', 'search');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Export Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php export_styles(); ?>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-file-excel"></i> Export Students</div>
        <a href="students.php?<?php echo h(http_build_query(array_filter($q))); ?>" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Students</a>
    </div>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <form method="get" class="ex-filter" id="filterForm">
        <div><label>Session</label><select name="session_id"><option value="0" <?php echo $session_id === 0 ? 'selected' : ''; ?>>Any (latest enrolment)</option><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="">All classes</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="">All sections</option><?php foreach ($sections as $x): if ((int)$x['class_id'] !== $class_id) continue; ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Status</label><select name="status"><?php foreach (['Active' => 'Active', 'TC' => 'TC', 'Passed' => 'Passed out', 'Deactivated' => 'Deactivated', 'all' => 'All (except deleted)'] as $v => $l): ?><option value="<?php echo $v; ?>" <?php echo $status === $v ? 'selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
        <div><label>Gender</label><select name="gender"><option value="">All</option><?php foreach (['Male', 'Female', 'Other'] as $g): ?><option value="<?php echo $g; ?>" <?php echo $gender === $g ? 'selected' : ''; ?>><?php echo $g; ?></option><?php endforeach; ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="name / UID / BSID / father / mobile"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <span class="ex-count"><i class="fas fa-users"></i> <?php echo number_format($count); ?> students</span>
    </form>

    <form method="post" id="exportForm">
        <?php echo csrf_field(); ?>
        <?php foreach ($q as $k => $v): ?><input type="hidden" name="<?php echo $k; ?>" value="<?php echo h($v); ?>"><?php endforeach; ?>
        <div class="ex-presets"><span style="font-weight:700;color:#3b5168">Quick pick:</span>
            <?php foreach ($presets as $pk => $p): ?><button type="button" class="p" data-preset="<?php echo h(json_encode($p['fields'])); ?>"><?php echo h($p['label']); ?></button><?php endforeach; ?>
            <button type="button" class="p" data-preset="[]">None</button>
        </div>
        <div class="ex-groups">
            <?php foreach ($groups as $grp): ?>
            <div class="ex-group" data-group="<?php echo h($grp); ?>">
                <h4><i class="fas fa-layer-group"></i> <?php echo h($grp); ?> <span class="mini" data-all="1">all</span><span class="mini" data-all="0">none</span></h4>
                <div class="body">
                    <?php foreach ($cols as $k => $c): if ($c['group'] !== $grp) continue; ?>
                    <label><input type="checkbox" name="fields[]" value="<?php echo h($k); ?>"> <?php echo h($c['label']); ?></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="ex-prev-head"><b><i class="fas fa-eye"></i> Preview</b> <span id="prevNote"></span></div>
        <div class="ex-prev"><table id="prev"><thead></thead><tbody></tbody></table></div>
        <div class="ex-bar">
            <span class="sel" id="selCount">0 fields selected</span>
            <span class="spacer"></span>
            <a href="students.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-success" id="dl" disabled><i class="fas fa-download"></i> Download Excel (<?php echo number_format($count); ?> rows)</button>
        </div>
    </form>
</div>
<script>
(function () {
    var secs = <?php echo json_encode(array_map(fn($x) => ['id' => (int)$x['id'], 'class_id' => (int)$x['class_id'], 'name' => $x['section_name']], $sections)); ?>;
    var c = document.getElementById('fClass'), s = document.getElementById('fSection');
    c.addEventListener('change', function () { s.innerHTML = '<option value="">All sections</option>' + secs.filter(function (x) { return x.class_id === +c.value; }).map(function (x) { return '<option value="' + x.id + '">' + x.name.replace(/[<>&"]/g, '') + '</option>'; }).join(''); });
    var PREVIEW = <?php echo json_encode($preview, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>, LABELS = <?php echo json_encode(array_map(fn($c) => $c['label'], $cols), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?>, TOTAL = <?php echo $count; ?>;
    function esc(v) { return String(v == null ? '' : v).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
    function preview() {
        var f = [...document.querySelectorAll('#exportForm input[name="fields[]"]:checked')].map(function (b) { return b.value; });
        document.querySelector('#prev thead').innerHTML = '<tr>' + f.map(function (k) { return '<th>' + esc(LABELS[k]) + '</th>'; }).join('') + '</tr>';
        document.querySelector('#prev tbody').innerHTML = PREVIEW.map(function (r) { return '<tr>' + f.map(function (k) { return '<td>' + esc(r[k]) + '</td>'; }).join('') + '</tr>'; }).join('');
        document.getElementById('prevNote').textContent = TOTAL ? ('first ' + Math.min(50, TOTAL) + ' of ' + TOTAL.toLocaleString() + ' rows, exactly as they will appear in the sheet') : 'no students match the filter';
    }
    var boxes = document.querySelectorAll('#exportForm input[name="fields[]"]');
    var LS = 'export_fields_v2';
    function count() { preview(); var n = document.querySelectorAll('#exportForm input[name="fields[]"]:checked').length; document.getElementById('selCount').textContent = n + ' field' + (n === 1 ? '' : 's') + ' selected'; document.getElementById('dl').disabled = !n; try { localStorage.setItem(LS, JSON.stringify([...document.querySelectorAll('#exportForm input[name="fields[]"]:checked')].map(function (b) { return b.value; }))); } catch (e) {} }
    boxes.forEach(function (b) { b.addEventListener('change', count); });
    document.querySelectorAll('[data-preset]').forEach(function (btn) { btn.addEventListener('click', function () { var set = JSON.parse(btn.dataset.preset); boxes.forEach(function (b) { b.checked = set.includes(b.value); }); count(); }); });
    document.querySelectorAll('.ex-group .mini').forEach(function (m) { m.addEventListener('click', function () { m.closest('.ex-group').querySelectorAll('input').forEach(function (b) { b.checked = m.dataset.all === '1'; }); count(); }); });
    var saved = null; try { saved = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) {}
    if (saved && saved.length) boxes.forEach(function (b) { b.checked = saved.includes(b.value); });
    else document.querySelector('[data-preset]').click();
    count();
})();
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/promotion_helper.php';

/**
 * Not Promoted: everyone still in a class of the old session who has no place in the new one — failed, absent,
 * not on the merit list, or left out of the promotion. Each one is kept in the same class (Detained), moved to
 * the next class as an exception, or given a TC. Passed students show here only after their class has gone up;
 * until then Promotion places them.
 */
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$classes = class_rows();
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions');
usort($sessions, fn($a, $b) => strnatcmp($b['session_name'], $a['session_name']));   // newest first
$names = array_column($sessions, 'session_name', 'id');
$active = 0;
foreach ($sessions as $s) if ($s['status'] === 'Active') $active = (int)$s['id'];

$from_session_id = (int)($_GET['from_session_id'] ?? 0); if (!isset($names[$from_session_id])) $from_session_id = $active;
$later = array_reverse(array_values(array_filter($sessions, fn($s) => $from_session_id && promotion_session_later($from_session_id, (int)$s['id']))));
$to_session_id = (int)($_GET['to_session_id'] ?? 0);
if (!in_array($to_session_id, array_map('intval', array_column($later, 'id')), true)) $to_session_id = (int)($later[0]['id'] ?? 0);
$from_class_id = (int)($_GET['from_class_id'] ?? 0); if (!isset($classes[$from_class_id])) $from_class_id = 0;

$list = []; $batch = null; $targets = []; $taken = [];
if ($from_class_id && $to_session_id) {
    $batch = db_get_row('SELECT id FROM promotion_batches WHERE from_session_id = ? AND from_class_id = ?', 'ii', $from_session_id, $from_class_id);
    $pool = promotion_students($from_session_id, $from_class_id);
    $list = $pool['left'] + ($batch ? $pool['eligible'] : []);
    if ($list) {   // someone already placed in the new session is done
        $uids = array_keys($list);
        $in = implode(',', array_fill(0, count($uids), '?'));
        foreach (db_get_all("SELECT DISTINCT student_id FROM student_academic_history WHERE session_id = ? AND student_id IN ($in)", 'i' . str_repeat('s', count($uids)), $to_session_id, ...$uids) as $r) unset($list[$r['student_id']]);
    }
    uasort($list, fn($a, $b) => strcasecmp($a['name'], $b['name']));
    // the same class, or the next one as an exception, with their sections and used rolls in the new session
    foreach (array_filter([$from_class_id, promotion_next_class($from_class_id)]) as $cid) {
        $targets[$cid] = array_map(fn($s) => [(int)$s['id'], $s['section_name']], promotion_get_sections($conn, $cid, $to_session_id));
        foreach (promotion_taken_rolls($to_session_id, $cid) as $sec => $rolls) $taken[$sec] = array_map('strval', array_keys($rolls));
    }
}
$labels = ['FAIL' => 'FAIL', 'ABSENT' => 'ABSENT', '' => 'No result', 'PASS' => 'PASS · left out', 'PUC' => 'PUC · left out', 'COMPARTMENT' => 'COMPARTMENT · left out'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Not Promoted</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
<style>
    .pick-row { display: flex; flex-wrap: wrap; gap: 14px; }
    .pick-row .form-group { flex: 1; min-width: 180px; margin: 0; }
    .pick-row select { width: 100%; padding: 9px 10px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
    .np-table { width: 100%; border-collapse: collapse; background: #fff; font-size: 13px; }
    .np-table th, .np-table td { border: 1px solid #e4edf6; padding: 6px 9px; text-align: left; }
    .np-table th { background: #7a2626; color: #fff; font-weight: 600; }
    .np-table td.num { text-align: right; }
    .np-table select, .np-table input.roll { padding: 5px 6px; border: 2px solid #e4edf6; border-radius: 6px; font-size: 13px; }
    .np-table input.roll { width: 70px; }
    .np-table small { display: block; color: #8a98a8; font-size: 10.5px; }
    .np-table tr.off td { opacity: .45; }
    .np-table tr.bad td { background: #fff0f0; }
    .st { display: inline-block; padding: 1px 7px; border-radius: 4px; color: #fff; font-size: 11px; font-weight: 700; background: #616161; }
    .st-FAIL { background: #b71c1c; } .st-ABSENT { background: #616161; } .st-none { background: #8d6e63; } .st-left { background: #1565c0; }
    .confirm-bar { position: sticky; bottom: 0; margin-top: 14px; padding: 12px 16px; background: #fff3f3; border: 1px solid #f3c9c9; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
    #problems { color: #c62828; font-weight: 600; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title" style="color:#7a2626"><i class="fas fa-user-clock"></i> Not Promoted</div>
        <a href="promotion.php?<?php echo $h(http_build_query(['from_session_id' => $from_session_id, 'to_session_id' => $to_session_id])); ?>" class="btn btn-primary"><i class="fas fa-level-up-alt"></i> Promotion</a>
    </div>
    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $k => $icon): if (isset($_SESSION[$k])): ?>
    <div class="alert alert-<?php echo $k === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <p style="font-size:12.5px; color:#4d6178; margin:0 0 12px">Students who stay behind in a class: failed, absent, not on the merit list, or left out of the promotion. Keep each one in the same class for the new session (detained), move them to the next class as an exception, or give a TC. Passed students appear here only after their class has been promoted.</p>

    <form method="get" class="form-card" style="margin-bottom:14px">
        <div class="pick-row">
            <div class="form-group"><label>Session</label>
                <select name="from_session_id" onchange="this.form.to_session_id.value='';this.form.submit()">
                    <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"<?php echo (int)$s['id'] === $from_session_id ? ' selected' : ''; ?>><?php echo $h($s['session_name'] . ($s['status'] === 'Active' ? ' (Active)' : '')); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label>Class</label>
                <select name="from_class_id" onchange="this.form.submit()">
                    <option value="">Select class</option>
                    <?php foreach ($classes as $id => $c): ?><option value="<?php echo $id; ?>"<?php echo $id === $from_class_id ? ' selected' : ''; ?>>Class <?php echo $h($c['name']); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label>Into session</label>
                <select name="to_session_id" onchange="this.form.submit()">
                    <?php if (!$later): ?><option value="">— no later session yet —</option><?php endif; ?>
                    <?php foreach ($later as $s): ?><option value="<?php echo (int)$s['id']; ?>"<?php echo (int)$s['id'] === $to_session_id ? ' selected' : ''; ?>><?php echo $h($s['session_name']); ?></option><?php endforeach; ?>
                </select></div>
        </div>
    </form>

    <?php if ($from_class_id && !$to_session_id): ?>
    <div class="alert alert-warning"><i class="fas fa-info-circle"></i> There is no session after <?php echo $h($names[$from_session_id]); ?> yet — <a href="add_session.php">add it first</a>.</div>
    <?php elseif ($from_class_id): ?>
        <?php if (!$batch && promotion_next_class($from_class_id) !== null): ?>
        <div class="alert alert-info"><i class="fas fa-info-circle"></i> Class <?php echo $h($classes[$from_class_id]['name']); ?> has not been promoted yet, so only the students who did not pass are listed. It is best to place them after the class below has been promoted into Class <?php echo $h($classes[$from_class_id]['name']); ?>, so the promoted students take the first rolls.</div>
        <?php endif; ?>
        <?php if (!$list): ?>
        <div class="empty-state"><i class="fas fa-check-circle"></i><h3>Nobody is waiting</h3><p>Every student of Class <?php echo $h($classes[$from_class_id]['name']); ?> (<?php echo $h($names[$from_session_id]); ?>) has a place in <?php echo $h($names[$to_session_id]); ?>, or is waiting for the promotion.</p></div>
        <?php else: ?>
        <form method="post" action="fail_students_process.php" id="npForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="from_session_id" value="<?php echo $from_session_id; ?>">
            <input type="hidden" name="from_class_id" value="<?php echo $from_class_id; ?>">
            <input type="hidden" name="to_session_id" value="<?php echo $to_session_id; ?>">
            <input type="hidden" name="rows" id="rows" value="">
            <div class="table-responsive">
            <table class="np-table" id="np">
                <thead><tr><th><input type="checkbox" id="all" checked title="All"></th><th>Student</th><th>Father</th><th>Result</th><th>%</th><th>Now</th><th>New class (<?php echo $h($names[$to_session_id]); ?>)</th><th>Section</th><th>Roll</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($list as $uid => $st): $left_out = in_array($st['status'], PROMOTION_PASSED, true); ?>
                    <tr data-uid="<?php echo $h($uid); ?>">
                        <td><input type="checkbox" class="pick" checked></td>
                        <td><b><?php echo $h($st['name']); ?></b><small><?php echo $h($uid); ?></small></td>
                        <td><?php echo $h($st['father'] !== '' ? $st['father'] : '—'); ?></td>
                        <td><span class="st <?php echo $left_out ? 'st-left' : ($st['status'] === '' ? 'st-none' : 'st-' . $h($st['status'])); ?>"><?php echo $h($labels[$st['status']] ?? $st['status']); ?></span></td>
                        <td class="num"><?php echo $st['pct'] !== null ? $h(rtrim(rtrim(number_format($st['pct'], 2), '0'), '.')) : '—'; ?></td>
                        <td><?php echo $h(($st['section'] !== '' ? $st['section'] : '—') . ' / ' . ($st['roll'] ?? '—')); ?></td>
                        <td><select class="cls">
                            <?php foreach ($targets as $cid => $_): ?><option value="<?php echo $cid; ?>"<?php echo $cid === $from_class_id ? ' selected' : ''; ?>>Class <?php echo $h($classes[$cid]['name']) . ($cid === $from_class_id ? ' — same class' : ' — as an exception'); ?></option><?php endforeach; ?>
                        </select></td>
                        <td><select class="sec"></select></td>
                        <td><input type="text" class="roll" inputmode="numeric" maxlength="4" autocomplete="off"></td>
                        <td><a href="<?php echo $h(student_page_url('tc_student.php', $uid)); ?>" title="Transfer certificate">TC</a></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <div class="confirm-bar">
                <span id="problems"></span>
                <span><noscript><b style="color:#c62828">JavaScript is needed to save.</b></noscript>
                <button type="submit" class="btn btn-success" id="saveBtn" disabled><i class="fas fa-check-circle"></i> Place ticked students</button></span>
            </div>
        </form>
        <script>
        (function () {
            var sections = <?php echo json_encode((object)$targets, JSON_HEX_TAG | JSON_HEX_AMP); ?>;   // class id => [[section id, name], ...]
            var taken = <?php echo json_encode((object)$taken, JSON_HEX_TAG | JSON_HEX_AMP); ?>;      // section id => rolls already used
            var session = <?php echo json_encode($names[$to_session_id], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
            var rows = Array.prototype.slice.call(document.querySelectorAll('#np tbody tr'));
            var btn = document.getElementById('saveBtn'), problems = document.getElementById('problems');
            function cells(tr) { return { pick: tr.querySelector('.pick'), cls: tr.querySelector('.cls'), sec: tr.querySelector('.sec'), roll: tr.querySelector('.roll') }; }
            function fill(tr) {
                var c = cells(tr), list = sections[c.cls.value] || [];
                c.sec.innerHTML = '<option value="">' + (list.length ? '— choose —' : 'no sections yet') + '</option>' + list.map(function (s) {
                    var o = document.createElement('option'); o.value = s[0]; o.textContent = s[1]; return o.outerHTML;
                }).join('');
                c.roll.value = '';
            }
            function used(sec, except) {   // rolls taken in a section: before, and by the other rows here
                var out = (taken[sec] || []).slice();
                rows.forEach(function (tr) { var c = cells(tr); if (tr !== except && c.pick.checked && c.sec.value === sec && c.roll.value.trim() !== '') out.push(c.roll.value.trim()); });
                return out;
            }
            function refresh() {
                var bad = 0, ticked = 0, seen = {};
                rows.forEach(function (tr) {
                    var c = cells(tr), on = c.pick.checked;
                    tr.classList.toggle('off', !on); c.cls.disabled = c.sec.disabled = c.roll.disabled = !on;
                    tr.classList.remove('bad');
                    if (!on) return;
                    ticked++;
                    var roll = c.roll.value.trim(), key = c.sec.value + '|' + roll;
                    var wrong = !c.sec.value || (roll !== '' && (!/^[1-9]\d{0,3}$/.test(roll) || seen[key] || (taken[c.sec.value] || []).indexOf(roll) !== -1));
                    if (roll !== '' && seen[key] && !seen[key].classList.contains('bad')) { seen[key].classList.add('bad'); bad++; }   // both rows of a roll used twice
                    if (roll !== '' && !seen[key]) seen[key] = tr;
                    if (wrong) { tr.classList.add('bad'); bad++; }
                });
                problems.textContent = bad ? bad + ' row(s) to fix: no section, a wrong roll, or a roll used twice.' : (ticked ? ticked + ' student(s) will be placed in ' + session + '.' : 'Nobody is ticked.');
                btn.disabled = bad > 0 || ticked === 0;
                return ticked;
            }
            rows.forEach(function (tr) {
                var c = cells(tr);
                fill(tr);
                c.cls.addEventListener('change', function () { fill(tr); refresh(); });
                c.sec.addEventListener('change', function () {   // suggest the next free roll of that section
                    if (c.sec.value) c.roll.value = Math.max.apply(null, [0].concat(used(c.sec.value, tr).map(Number))) + 1;
                    refresh();
                });
            });
            document.getElementById('all').addEventListener('change', function () { var on = this.checked; rows.forEach(function (tr) { cells(tr).pick.checked = on; }); refresh(); });
            document.getElementById('np').addEventListener('change', refresh);
            document.getElementById('np').addEventListener('input', refresh);
            document.getElementById('npForm').addEventListener('submit', function (e) {
                var n = refresh();
                if (btn.disabled || !confirm('Place ' + n + ' student(s) in ' + session + '?')) { e.preventDefault(); return; }
                var list = [];
                rows.forEach(function (tr) { var c = cells(tr); if (c.pick.checked) list.push([tr.dataset.uid, +c.cls.value, +c.sec.value, c.roll.value.trim()]); });
                document.getElementById('rows').value = JSON.stringify(list);
            });
            refresh();
        })();
        </script>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>

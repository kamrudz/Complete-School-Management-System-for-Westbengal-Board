<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/promotion_helper.php';

/**
 * Not Promoted into the new session: each ticked student who stays behind gets a place — the same class again
 * (their old year is closed as Detained) or the next class as an exception (closed as Promoted). The rows come
 * as one JSON list ([uid, class id, section id, roll], ...). Checked first; nothing is written unless every
 * student can be placed.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: fail_students.php'); exit(); }
verify_csrf_or_die();

$from_session_id = (int)($_POST['from_session_id'] ?? 0);
$from_class_id   = (int)($_POST['from_class_id'] ?? 0);
$to_session_id   = (int)($_POST['to_session_id'] ?? 0);
$back = 'fail_students.php?' . http_build_query(['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id]);
$fail = function (string $msg) use ($back) { $_SESSION['error'] = $msg; header("Location: $back"); exit(); };
if (!isset(class_rows()[$from_class_id]) || !promotion_session_later($from_session_id, $to_session_id)) $fail('Invalid request — choose the sessions and class again.');
$allowed = array_filter([$from_class_id, promotion_next_class($from_class_id)]);   // the same class, or the next one as an exception

$rows = json_decode((string)($_POST['rows'] ?? ''), true);
if (!is_array($rows) || !$rows) $fail('Tick at least one student.');
$moves = [];   // uid => [class id, section id, roll or null]
foreach ($rows as $r) {
    $r = is_array($r) ? array_values($r) : [];
    $ok = count($r) === 4 && is_scalar($r[0]) && is_scalar($r[1]) && is_scalar($r[2]) && is_scalar($r[3]);
    $uid = $ok ? student_uid_clean($r[0]) : '';
    if ($uid === '' || isset($moves[$uid])) $fail('The list of students was not valid — open the page again.');
    $roll = trim((string)$r[3]);
    $moves[$uid] = [(int)$r[1], (int)$r[2], $roll === '' ? null : $roll];
}

$pool = promotion_students($from_session_id, $from_class_id);
$uids = array_keys($moves);
if ($gone = array_values(array_diff($uids, array_keys($pool['eligible'] + $pool['left'])))) {
    $fail(count($gone) . ' student(s) are no longer active in this class (' . implode(', ', array_slice($gone, 0, 5)) . ').');
}
if (!promotion_batch_exists($conn, $from_session_id, $from_class_id) && ($passed = array_values(array_intersect($uids, array_keys($pool['eligible']))))) {
    $fail('These students passed — they go up through Promotion first: ' . implode(', ', array_slice($passed, 0, 5)) . '.');
}
$in = implode(',', array_fill(0, count($uids), '?'));
$there = db_get_all("SELECT s.id, s.student_name FROM student_academic_history h JOIN students s ON s.id = h.student_id WHERE h.session_id = ? AND h.student_id IN ($in)",
                    'i' . str_repeat('s', count($uids)), $to_session_id, ...$uids);
if ($there) $fail('Already placed in the new session: ' . implode(', ', array_map(fn($r) => "{$r['id']} {$r['student_name']}", array_slice($there, 0, 5))) . '.');

$sections = [];   // class id => [section id => name] in the new session
$taken = [];      // "section|roll" already used there, or earlier in this list
foreach ($allowed as $cid) {
    $sections[$cid] = array_column(promotion_get_sections($conn, $cid, $to_session_id), 'section_name', 'id');
    foreach (promotion_taken_rolls($to_session_id, $cid) as $sec => $rolls) foreach ($rolls as $roll => $_) $taken["$sec|$roll"] = true;
}
foreach ($moves as $uid => [$class_id, $section_id, $roll]) {
    if (!isset($sections[$class_id])) $fail("$uid can only stay in this class or go to the next one.");
    if (!isset($sections[$class_id][$section_id])) $fail("$uid has no section of that class in the new session — choose a section for every ticked student.");
    if ($roll === null) continue;
    if (!preg_match('/^[1-9]\d{0,3}$/', $roll)) $fail("Roll '$roll' of $uid must be a number from 1 to 9999.");
    $key = "$section_id|$roll";
    if (isset($taken[$key])) $fail("Roll $roll of section {$sections[$class_id][$section_id]} is given twice, or already belongs to a student in the new session.");
    $taken[$key] = true;
}

db_begin_transaction();
try {
    foreach ($moves as $uid => [$class_id, $section_id, $roll]) {
        $old = $pool['eligible'][$uid] ?? $pool['left'][$uid];
        $closed_as = $class_id === $from_class_id ? 'Detained' : 'Promoted';
        db_execute("UPDATE student_academic_history SET promotion_status = ?, academic_status = 'History' WHERE student_id = ? AND session_id = ? AND class_id = ? AND academic_status = 'Current'",
            'ssii', $closed_as, $uid, $from_session_id, $from_class_id);
        db_insert('student_academic_history', ['student_id' => $uid, 'session_id' => $to_session_id, 'class_id' => $class_id, 'section_id' => $section_id, 'roll_no' => $roll,
            'promotion_status' => 'Studying', 'student_status' => 'Active', 'academic_status' => 'Current', 'previous_school' => $old['previous_school']]);
    }
    db_commit();
} catch (Throwable $e) {
    db_rollback();
    $fail('Nothing was changed: ' . $e->getMessage());
}
log_action((int)($_SESSION['admin_id'] ?? 0), 'NOT_PROMOTED_PLACED', 'student_academic_history', null, null,
    ['from' => [$from_session_id, $from_class_id], 'to_session' => $to_session_id, 'students' => array_map(fn($m) => $m[0] === $from_class_id ? 'same class' : 'next class', $moves)]);
$_SESSION['success'] = count($moves) . ' student(s) placed in the new session.';
header("Location: $back");
exit();

<?php
require_once '../includes/auth.php';
require_admin_login();
header('Location: collect_fee.php?' . http_build_query(['mode' => 'class'] + array_intersect_key($_GET, array_flip(['session_id', 'class_id', 'section_id', 'roll_from', 'roll_to']))));
exit();

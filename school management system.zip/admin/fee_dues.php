<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/fee_helper.php';

/** Bills: every bill of a session — made when a fee is collected — with what is still owed; one without money on it can be cancelled. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$sessions = exam_sessions();
$session_id = (int)$in('session_id', 0);
if (!isset($sessions[$session_id])) $session_id = fee_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$class_id = (int)$in('class_id', 0);
if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? array_column(db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id), 'section_name', 'id') : [];
$section_id = (int)$in('section_id', 0);
if (!isset($sections[$section_id])) $section_id = 0;
$heads = fee_heads();
$fee = (int)$in('fee', 0);
if (!isset($heads[$fee])) $fee = 0;
$state = (string)$in('state', '');
if (!in_array($state, ['due', 'overdue', 'paid', 'cancelled'], true)) $state = '';
$search = trim((string)$in('search', ''));
$q = array_filter(['session_id' => $session_id, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null, 'fee' => $fee ?: null, 'state' => $state ?: null, 'search' => $search !== '' ? $search : null]);
$self = fn(array $over = []) => 'fee_dues.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    try {
        if (($_POST['act'] ?? '') !== 'cancel_bill') throw new RuntimeException('Nothing to do.');
        $_SESSION['success'] = 'Bill cancelled: ' . fee_cancel_bill((int)($_POST['bill_id'] ?? 0), (string)($_POST['reason'] ?? ''), $admin_id) . '.';
    } catch (RuntimeException $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    header('Location: ' . $self());
    exit();
}

$where = ['i.session_id = ?']; $types = 'i'; $params = [$session_id];
if ($fee) { $where[] = 'EXISTS (SELECT 1 FROM fee_invoice_items it WHERE it.invoice_id = i.id AND it.fee_type_id = ?)'; $types .= 'i'; $params[] = $fee; }
if ($class_id) { $where[] = 'i.class_id = ?'; $types .= 'i'; $params[] = $class_id; }
if ($section_id) { $where[] = 'i.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
$where[] = match ($state) {
    'due' => "i.status IN ('pending', 'partial')",
    'overdue' => "i.status IN ('pending', 'partial') AND i.due_date < CURDATE()",
    'paid' => "i.status = 'paid'",
    'cancelled' => "i.status = 'cancelled'",
    default => "i.status <> 'cancelled'",
};
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(s.student_name LIKE ? OR s.id LIKE ? OR i.title LIKE ?)'; $types .= 'sss'; array_push($params, $like, $like, $like);
}
$from = 'FROM fee_invoices i JOIN students s ON s.id = i.student_id LEFT JOIN classes c ON c.id = i.class_id LEFT JOIN sections sec ON sec.id = i.section_id
    LEFT JOIN student_academic_history h ON h.student_id = i.student_id AND h.session_id = i.session_id WHERE ' . implode(' AND ', $where);
$sums = db_get_row("SELECT COUNT(*) AS n, COALESCE(SUM(i.total), 0) AS total, COALESCE(SUM(i.paid_amount), 0) AS paid $from", $types, ...$params);
$per = 50; $total_rows = (int)$sums['n']; $pages = max(1, (int)ceil($total_rows / $per)); $page = min(max(1, (int)$in('page', 1)), $pages);
$bills = db_get_all("SELECT i.*, s.student_name, s.photo, c.class_name, sec.section_name, h.roll_no $from
    ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name, i.id LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bills</title>
<?php exam_styles('fee'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 10px; margin: 4px 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; }
    .sum small { color: #6b7d90; font-size: 12px; }
    .sum .go b { color: #1b7a3a; }
    .stu { display: flex; align-items: center; gap: 9px; } .stu img, .stu .ph { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; background: var(--ex-soft); flex: none; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: var(--ex-dark); font-size: 13px; }
    .stu small { display: block; color: #6b7d90; font-size: 11.5px; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .pg { display: flex; gap: 4px; justify-content: center; flex-wrap: wrap; margin-top: 12px; }
    .pg a, .pg span { min-width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; text-decoration: none; color: var(--ex-dark); font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg span { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Bills', 'Every bill of the session — made when a fee is collected — and what is still owed', 'fa-file-invoice',
        ['collect_fee.php' => '<i class="fas fa-cash-register"></i> Collect', 'fee_receipts.php' => '<i class="fas fa-receipt"></i> Receipts']); ?>
    <?php fee_tabs(''); exam_flash(); ?>
    <div class="card">
        <form method="get" class="pick">
            <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Fee</label><select name="fee"><option value="0">All fees</option><?php foreach ($heads as $hid => $hd): ?><option value="<?php echo (int)$hid; ?>"<?php echo $hid === $fee ? ' selected' : ''; ?>><?php echo h($hd['type_name']); ?></option><?php endforeach; ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="0">All classes</option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo $cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
            <?php if ($class_id): ?><div><label>Section</label><select name="section_id"><option value="0">All sections</option><?php echo exam_options($sections, $section_id); ?></select></div><?php endif; ?>
            <div><label>Show</label><select name="state"><?php echo exam_options(['' => 'All but cancelled', 'due' => 'Still owing', 'overdue' => 'Overdue', 'paid' => 'Paid', 'cancelled' => 'Cancelled'], $state); ?></select></div>
            <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, UID or bill"></div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
        </form>
    </div>
    <?php if (!$bills): ?>
    <div class="ex-empty"><i class="fas fa-file-invoice"></i>No bills match. A bill is made when a fee is collected.</div>
    <?php else: ?>
    <div class="sum">
        <div><b><?php echo number_format($total_rows); ?></b><small>bill(s)</small></div>
        <div><b><?php echo h(fee_money($sums['total'])); ?></b><small>billed</small></div>
        <div class="go"><b><?php echo h(fee_money($sums['paid'])); ?></b><small>paid</small></div>
        <div><b style="color:#b71c1c"><?php echo h(fee_money_p(fee_paise($sums['total']) - fee_paise($sums['paid']))); ?></b><small>still owing</small></div>
    </div>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>#</th><th>Student</th><th>Class</th><th>Bill</th><th class="money">Total</th><th class="money">Paid</th><th class="money">Balance</th><th>Due</th><th>State</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($bills as $b): $st = fee_bill_state($b); $bal = fee_paise($b['total']) - fee_paise($b['paid_amount']); ?>
            <tr>
                <td><?php echo (int)$b['id']; ?></td>
                <td><div class="stu"><?php echo $b['photo'] ? '<img src="../uploads/students/' . h(rawurlencode($b['photo'])) . '" alt="">' : '<span class="ph">' . h(mb_substr($b['student_name'], 0, 1)) . '</span>'; ?><div><b><?php echo h($b['student_name']); ?></b><small><?php echo h($b['student_id']); ?></small></div></div></td>
                <td><?php echo h(trim(($b['class_name'] ?? '') . ($b['section_name'] ? '-' . $b['section_name'] : '') . ($b['roll_no'] ? ' · ' . $b['roll_no'] : ''))); ?></td>
                <td><?php echo h($b['title']); ?><?php if ($st === 'cancelled'): ?><small class="note" style="display:block;margin:0"><?php echo h($b['cancel_reason']); ?></small><?php endif; ?></td>
                <td class="money"><?php echo h(fee_money($b['total'])); ?></td>
                <td class="money"><?php echo h(fee_money($b['paid_amount'])); ?></td>
                <td class="money"><b><?php echo $st === 'cancelled' ? '—' : h(fee_money_p($bal)); ?></b></td>
                <td><?php echo $b['due_date'] ? h(date('d M Y', strtotime($b['due_date']))) : '—'; ?></td>
                <td><?php echo fee_state_chip($st); ?></td>
                <td style="white-space:nowrap">
                    <?php if ($st !== 'cancelled' && $bal > 0): ?><a class="btn btn-success btn-sm" href="<?php echo h('collect_fee.php?' . http_build_query(['uid' => $b['student_id'], 'session_id' => $session_id])); ?>" title="Collect"><i class="fas fa-cash-register"></i></a><?php endif; ?>
                    <?php if ($st !== 'cancelled' && fee_paise($b['paid_amount']) === 0): ?><button type="button" class="btn btn-danger btn-sm" title="Cancel bill" onclick="cancelBill(<?php echo (int)$b['id']; ?>, <?php echo h(json_encode($b['student_name'] . ' — ' . $b['title'])); ?>)"><i class="fas fa-ban"></i></button><?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1): ?>
        <div class="pg"><?php for ($i = 1; $i <= $pages; $i++): ?><?php if ($i === $page): ?><span><?php echo $i; ?></span><?php elseif ($i <= 2 || $i > $pages - 2 || abs($i - $page) <= 2): ?><a href="<?php echo h($self(['page' => $i])); ?>"><?php echo $i; ?></a><?php endif; ?><?php endfor; ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="modal" id="cancelModal">
        <form class="box pf" method="post">
            <?php echo csrf_field(); ?>
            <?php foreach ($q as $k => $v): ?><input type="hidden" name="<?php echo h($k); ?>" value="<?php echo h($v); ?>"><?php endforeach; ?>
            <input type="hidden" name="act" value="cancel_bill"><input type="hidden" name="bill_id" id="cbId">
            <h3 style="margin:0;color:var(--ex-dark)">Cancel bill</h3>
            <p class="note" id="cbWhat"></p>
            <label>Reason</label><input type="text" name="reason" maxlength="255" required placeholder="e.g. billed by mistake">
            <div class="acts"><button type="submit" class="btn btn-danger"><i class="fas fa-ban"></i> Cancel the bill</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('cancelModal').classList.remove('open')">Keep it</button></div>
        </form>
    </div>
</div>
<script>
function cancelBill(id, what) {
    document.getElementById('cbId').value = id;
    document.getElementById('cbWhat').textContent = what + ' — a cancelled bill stays in the list, marked cancelled, and the fee can be collected again.';
    document.getElementById('cancelModal').classList.add('open');
}
document.getElementById('cancelModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

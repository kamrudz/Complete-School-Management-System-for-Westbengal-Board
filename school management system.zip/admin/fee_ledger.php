<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/fee_helper.php';

/** A student's fee ledger: every bill of every session and every receipt, with what is still owing. Read-only, printable. */
$uid = student_uid_clean($_GET['uid'] ?? '');
$st = $uid !== '' ? fee_student($uid, fee_active_session_id(), true) : null;
if (!$st) { $_SESSION['error'] = 'Choose a student first.'; header('Location: collect_fee.php'); exit(); }
$bills = fee_student_bills($uid);
$receipts = fee_student_receipts($uid);
$live = array_filter($bills, fn($b) => $b['status'] !== 'cancelled');
$billed = array_sum(array_map(fn($b) => fee_paise($b['subtotal']), $live));
$discount = array_sum(array_map(fn($b) => fee_paise($b['discount_amount']), $live));
$paid = array_sum(array_map(fn($b) => fee_paise($b['paid_amount']), $live));
$owing = array_sum(array_map(fn($b) => fee_paise($b['total']) - fee_paise($b['paid_amount']), $live));
$by_session = [];
foreach ($bills as $b) $by_session[$b['session_name']][] = $b;
$pl = $st['place'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h('Fee ledger — ' . $st['student_name']); ?></title>
<?php exam_styles('fee'); ?>
<style>
    .stu-card { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; background: linear-gradient(135deg, var(--ex-soft), #fff); border: 1px solid var(--ex-border); border-radius: 14px; padding: 14px 16px; margin-bottom: 14px; }
    .stu-card img, .stu-card .ph { width: 60px; height: 60px; border-radius: 50%; object-fit: cover; background: var(--ex-soft); display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: var(--ex-dark); font-size: 22px; flex: none; }
    .stu-card h2 { margin: 0; font-size: 19px; color: var(--ex-dark); } .stu-card .meta { font-size: 13px; color: #3b5168; margin-top: 3px; }
    .sum { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tr.void td { color: #98a6b5; }
    .items { display: block; font-size: 11.5px; color: #6b7d90; }
    .print-head { display: none; }
    @media print {
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .noprint { display: none !important; }
        .print-head { display: block; }
        .card, .sum div, .stu-card { break-inside: avoid; }
    }
    @media (max-width: 760px) { .sum { grid-template-columns: 1fr 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Fee Ledger', 'Every bill and receipt of one student, across all sessions', 'fa-book',
        ['collect_fee.php?uid=' . rawurlencode($uid) => '<i class="fas fa-cash-register"></i> Take payment',
         'fee_receipts.php?uid=' . rawurlencode($uid) => '<i class="fas fa-receipt"></i> Receipts', student_page_url('view_student.php', $uid) => '<i class="fas fa-user"></i> Profile']); ?>
    <?php fee_tabs(''); ?>
    <div class="print-head"><?php exam_school_header('FEE LEDGER', 'Printed ' . date('d M Y')); ?></div>

    <div class="stu-card">
        <?php echo $st['photo'] ? '<img src="../uploads/students/' . h(rawurlencode($st['photo'])) . '" alt="">' : '<span class="ph">' . h(mb_substr($st['student_name'], 0, 1)) . '</span>'; ?>
        <div>
            <h2><?php echo h($st['student_name']); ?> <span class="chip off"><?php echo h($uid); ?></span><?php echo $st['student_status'] !== 'Active' ? ' <span class="chip warn">' . h($st['student_status']) . '</span>' : ''; ?></h2>
            <div class="meta"><?php echo $pl ? 'Class ' . h($pl['class_name'] . ($pl['section_name'] ? '-' . $pl['section_name'] : '') . ($pl['roll_no'] ? ' · Roll ' . $pl['roll_no'] : '') . ' · ' . $pl['session_name']) : ''; ?><?php echo $st['father_name'] ? ' · Father: ' . h($st['father_name']) : ''; ?><?php echo $st['phone'] ? ' · ' . h($st['phone']) : ''; ?></div>
        </div>
        <button type="button" class="btn btn-secondary noprint" style="margin-left:auto" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
    </div>

    <div class="sum">
        <div><b><?php echo h(fee_money_p($billed)); ?></b><small>billed</small></div>
        <div><b><?php echo h(fee_money_p($discount)); ?></b><small>discount</small></div>
        <div><b style="color:#1b7a3a"><?php echo h(fee_money_p($paid)); ?></b><small>paid</small></div>
        <div><b style="color:<?php echo $owing ? '#b71c1c' : '#1b7a3a'; ?>"><?php echo h(fee_money_p($owing)); ?></b><small>owing now</small></div>
    </div>

    <?php if (!$bills): ?>
    <div class="ex-empty"><i class="fas fa-file-invoice"></i>No bill yet.</div>
    <?php endif; ?>
    <?php foreach ($by_session as $session => $list): ?>
    <div class="card" style="overflow-x:auto">
        <h2>Session <?php echo h($session); ?></h2>
        <table class="ex-table">
            <thead><tr><th>Bill</th><th>Billed on</th><th>Due</th><th class="money">Total</th><th class="money">Paid</th><th class="money">Balance</th><th>State</th></tr></thead>
            <tbody>
            <?php foreach ($list as $b): $state = fee_bill_state($b); ?>
            <tr class="<?php echo $state === 'cancelled' ? 'void' : ''; ?>">
                <td><b><?php echo h($b['title']); ?></b><span class="items"><?php echo h(implode(' · ', array_map(fn($it) => $it['description'] . ' ' . fee_money($it['amount']) . (fee_paise($it['discount']) ? ' (−' . fee_money($it['discount']) . ')' : ''), $b['items']))); ?><?php echo $state === 'cancelled' ? ' — cancelled: ' . h($b['cancel_reason']) : ''; ?></span></td>
                <td><?php echo $b['invoice_date'] ? h(date('d M Y', strtotime($b['invoice_date']))) : '—'; ?></td>
                <td><?php echo $b['due_date'] ? h(date('d M Y', strtotime($b['due_date']))) : '—'; ?></td>
                <td class="money"><?php echo h(fee_money($b['total'])); ?></td>
                <td class="money"><?php echo h(fee_money($b['paid_amount'])); ?></td>
                <td class="money"><b><?php echo $state === 'cancelled' ? '—' : h(fee_money_p(fee_paise($b['total']) - fee_paise($b['paid_amount']))); ?></b></td>
                <td><?php echo fee_state_chip($state); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endforeach; ?>

    <div class="card" style="overflow-x:auto">
        <h2>Receipts</h2>
        <?php if (!$receipts): ?><p class="note">No receipt yet.</p><?php else: ?>
        <table class="ex-table">
            <thead><tr><th>Receipt</th><th>Date</th><th class="money">Amount</th><th>Paid by</th><th>Received by</th><th>Status</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($receipts as $r): $void = $r['status'] === 'cancelled'; ?>
            <tr class="<?php echo $void ? 'void' : ''; ?>">
                <td><b><?php echo h($r['receipt_no']); ?></b></td>
                <td><?php echo h(date('d M Y', strtotime($r['receipt_date']))); ?></td>
                <td class="money"><?php echo h(fee_money($r['amount'])); ?></td>
                <td><?php echo h(FEE_METHODS[$r['method']] ?? $r['method']); ?><?php echo $r['reference_no'] ? ' · ' . h($r['reference_no']) : ''; ?></td>
                <td><?php echo h($r['received_name'] ?: '—'); ?></td>
                <td><?php echo $void ? fee_state_chip('cancelled') . ' <small class="note">' . h($r['cancel_reason']) . '</small>' : '<span class="chip ok">Valid</span>'; ?></td>
                <td class="noprint"><a class="btn btn-secondary btn-sm" target="_blank" href="<?php echo h('fee_receipt.php?id=' . (int)$r['id']); ?>"><i class="fas fa-print"></i></a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/fee_helper.php';

/** Money receipt, A4: a Student copy and an Office copy (or one copy, by Fee Settings). ?ids= prints many, one to a page. Read-only. */
$ids = array_slice(array_values(array_unique(array_filter(array_map('intval', explode(',', (string)($_GET['ids'] ?? $_GET['id'] ?? '')))))), 0, 500);
$list = array_values(array_filter(array_map('fee_receipt', $ids)));
if (!$list) { http_response_code(404); exit('Receipt not found.'); }
$one = count($list) === 1 ? $list[0] : null;
$settings = fee_settings();
$show = fee_slip_fields();
$copies = (int)$settings['receipt_copies'] === 1 ? ['Money Receipt'] : ['Student Copy', 'Office Copy'];
$headers = [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($one ? 'Receipt ' . $one['receipt_no'] . ' — ' . ($one['student']['student_name'] ?? $one['student_id']) : count($list) . ' receipts'); ?></title>
<style>
    @page { size: A4 portrait; margin: 8mm 10mm; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: 'Segoe UI', Arial, sans-serif; color: #111; background: #e9edf1; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .bar { position: sticky; top: 0; z-index: 5; background: #fff; border-bottom: 1px solid #cfd8e2; padding: 10px 16px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; font-size: 13px; color: #33475b; }
    .bar .sp { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .bar a, .bar button { border: 0; border-radius: 8px; padding: 8px 14px; font-size: 13px; font-weight: 600; cursor: pointer; background: #e4e9ef; color: #1f2d3a; text-decoration: none; font-family: inherit; }
    .bar .go { background: #14532d; color: #fff; }
    .bar .warn { background: #fdecea; color: #8e1b1b; }
    .sheet { width: 210mm; margin: 14px auto; background: #fff; padding: 8mm 10mm; box-shadow: 0 2px 14px rgba(0,0,0,.14); }
    .copy { position: relative; border: 1.2px solid #444; border-radius: 6px; padding: 5mm 6mm 4mm; overflow: hidden; break-inside: avoid; page-break-inside: avoid; }
    .copy .tag { position: absolute; top: 3mm; right: 5mm; font-size: 10.5px; font-weight: 700; letter-spacing: .6px; text-transform: uppercase; border: 1px solid #444; border-radius: 4px; padding: 1px 7px; }
    .copy .school-head { margin-bottom: 6px !important; padding-bottom: 4px !important; }
    table.meta { width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 6px; }
    table.meta td { padding: 2px 4px; vertical-align: top; }
    table.meta td.l { color: #555; width: 15%; white-space: nowrap; }
    table.meta td.v { font-weight: 600; }
    table.meta .no { font-size: 14px; font-weight: 800; letter-spacing: .4px; }
    table.lines { width: 100%; border-collapse: collapse; font-size: 12px; }
    table.lines th { text-align: left; font-size: 10.5px; text-transform: uppercase; letter-spacing: .4px; border-top: 1.2px solid #333; border-bottom: 1px solid #333; padding: 3px 5px; background: #f1f3f5; }
    table.lines td { padding: 4px 5px; border-bottom: 1px solid #ddd; vertical-align: top; }
    table.lines .amt { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
    table.lines .sub { font-size: 10.5px; color: #555; margin-top: 1px; }
    table.lines tfoot td { border-top: 1.2px solid #333; border-bottom: 1.2px solid #333; font-weight: 800; font-size: 13px; }
    .words { font-size: 12px; margin: 6px 0 2px; } .words b { font-style: italic; }
    .paid { font-size: 11.5px; color: #333; }
    .foot { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 10mm; font-size: 11.5px; }
    .foot .sign { border-top: 1px solid #333; min-width: 52mm; text-align: center; padding-top: 3px; }
    .note { font-size: 10px; color: #555; margin-top: 4px; }
    .void { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; pointer-events: none; }
    .void span { transform: rotate(-18deg); font-size: 64px; font-weight: 900; color: rgba(183, 28, 28, .16); border: 6px solid rgba(183, 28, 28, .16); padding: 0 22px; border-radius: 12px; letter-spacing: 6px; }
    .voidnote { font-size: 11px; color: #8e1b1b; font-weight: 700; margin-top: 4px; }
    .cut { text-align: center; font-size: 11px; color: #777; margin: 4mm 0; border-top: 1px dashed #999; line-height: 0; }
    .cut span { background: #fff; padding: 0 8px; position: relative; top: -1px; }
    @media screen and (max-width: 840px) { .sheet { width: auto; margin: 8px; padding: 10px; } }
    @media print { body { background: #fff; } .bar { display: none; } .sheet { margin: 0; box-shadow: none; width: auto; padding: 0; } .sheet + .sheet { break-before: page; page-break-before: always; } }
</style>
</head>
<body>
<div class="bar">
<?php if ($one): $cancelled = $one['status'] === 'cancelled'; ?>
    <span><b><?php echo h($one['receipt_no']); ?></b> · <?php echo h(fee_money($one['amount'])); ?> · <?php echo h($one['student']['student_name'] ?? $one['student_id']); ?><?php echo $cancelled ? ' · <b style="color:#b71c1c">CANCELLED</b>' : ''; ?></span>
    <span>A4 portrait — untick “Headers and footers” in the print dialog.</span>
    <span class="sp">
        <a href="<?php echo h('collect_fee.php?' . http_build_query(['uid' => $one['student_id'], 'session_id' => (int)$one['session_id']])); ?>">&larr; Collect</a>
        <a href="fee_receipts.php">All receipts</a>
        <?php if (!$cancelled): ?><a class="warn" href="<?php echo h('fee_receipts.php?' . http_build_query(['cancel' => (int)$one['id'], 'uid' => $one['student_id']])); ?>">Cancel receipt…</a><?php endif; ?>
        <button type="button" class="go" onclick="window.print()">&#128424; Print</button>
    </span>
<?php else: ?>
    <span><b><?php echo count($list); ?> receipts</b> · <?php echo h(fee_money_p(array_sum(array_map(fn($r) => fee_paise($r['amount']), $list)))); ?> · <?php echo h($list[0]['receipt_no'] . ' to ' . $list[count($list) - 1]['receipt_no']); ?></span>
    <span>A4 portrait, one receipt to a page — untick “Headers and footers” in the print dialog.</span>
    <span class="sp">
        <?php if (count(array_unique(array_column($list, 'student_id'))) === 1): ?><a href="<?php echo h('collect_fee.php?' . http_build_query(['uid' => $list[0]['student_id'], 'session_id' => (int)$list[0]['session_id']])); ?>">&larr; Collect</a><?php endif; ?>
        <a href="fee_receipts.php">All receipts</a>
        <button type="button" class="go" onclick="window.print()">&#128424; Print all</button>
    </span>
<?php endif; ?>
</div>
<?php foreach ($list as $r):
    $st = $r['student'];
    $pl = $st['place'] ?? null;
    $total = fee_paise($r['amount']);
    $cancelled = $r['status'] === 'cancelled';
    if (!isset($headers[$r['session_name']])) { ob_start(); exam_school_header($settings['slip_title'] ?: 'MONEY RECEIPT', $show['session'] ? 'Session ' . $r['session_name'] : '', $show['logo'], $show['address']); $headers[$r['session_name']] = ob_get_clean(); }
    $owing = 0;
    foreach ($r['lines'] as $l) $owing += max(0, fee_paise($l['total']) - fee_paise($l['paid_upto']));
    $meta = [['Receipt No.', '<span class="no">' . h($r['receipt_no']) . '</span>'], ['Date', h(date('d M Y', strtotime($r['receipt_date'])))], ['Student', h($st['student_name'] ?? '')]];
    if ($show['uid']) $meta[] = ['School UID', h($r['student_id'])];
    if ($show['bsid'] && trim((string)($st['banglarshiksha_id'] ?? '')) !== '') $meta[] = ['Banglar Shiksha', h($st['banglarshiksha_id'])];
    if ($show['class']) $meta[] = ['Class', $pl ? h($pl['class_name'] . ($pl['section_name'] ? '-' . $pl['section_name'] : '') . ($pl['roll_no'] ? ' · Roll ' . $pl['roll_no'] : '')) : '—'];
    if ($show['father'] && trim((string)($st['father_name'] ?? '')) !== '') $meta[] = ['Father', h($st['father_name'])];
    if ($show['mobile'] && ($st['phone'] ?? '') !== '') $meta[] = ['Mobile', h($st['phone'])];
    $paid_by = [];
    if ($show['method']) $paid_by[] = 'Paid by ' . h(FEE_METHODS[$r['method']] ?? $r['method']) . ($r['reference_no'] ? ' · Ref. ' . h($r['reference_no']) : '');
    if ($show['remarks'] && $r['remarks']) $paid_by[] = h($r['remarks']);
    if ($show['balance'] && $owing) $paid_by[] = 'Still owing on these bills: ' . h(fee_money_p($owing));
?>
<div class="sheet">
<?php foreach ($copies as $n => $copy): ?>
    <?php if ($n): ?><div class="cut"><span>&#9986; cut here</span></div><?php endif; ?>
    <div class="copy">
        <div class="tag"><?php echo h($copy); ?></div>
        <?php echo $headers[$r['session_name']]; ?>
        <table class="meta">
            <?php foreach (array_chunk($meta, 2) as $pair): ?>
            <tr><?php foreach ($pair as [$label, $value]): ?><td class="l"><?php echo h($label); ?></td><td class="v"><?php echo $value; ?></td><?php endforeach; ?><?php echo count($pair) === 1 ? '<td></td><td></td>' : ''; ?></tr>
            <?php endforeach; ?>
        </table>
        <table class="lines">
            <thead><tr><th style="width:7mm">#</th><th>Particulars</th><th class="amt">Amount (₹)</th></tr></thead>
            <tbody>
            <?php foreach ($r['lines'] as $i => $l): $left = max(0, fee_paise($l['total']) - fee_paise($l['paid_upto'])); ?>
            <tr>
                <td><?php echo $i + 1; ?></td>
                <td><b><?php echo h($l['title']); ?></b>
                    <?php if ($show['items'] && (count($l['items']) > 1 || array_filter($l['items'], fn($it) => fee_paise($it['discount']) > 0))): ?>
                    <div class="sub"><?php echo h(implode(' · ', array_map(fn($it) => $it['description'] . ' ' . fee_num_p(fee_paise($it['amount'])) . (fee_paise($it['discount']) ? ' (less ' . fee_num_p(fee_paise($it['discount'])) . ')' : ''), $l['items']))); ?></div>
                    <?php endif; ?>
                    <?php if ($show['balance'] && (fee_paise($l['amount']) !== fee_paise($l['total']) || $left > 0)): ?><div class="sub">Bill <?php echo h(fee_num_p(fee_paise($l['total']))); ?> · balance after this receipt <?php echo h(fee_num_p($left)); ?></div><?php endif; ?>
                </td>
                <td class="amt"><?php echo h(fee_num_p(fee_paise($l['amount']))); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td></td><td>Total received</td><td class="amt"><?php echo h(fee_money_p($total)); ?></td></tr></tfoot>
        </table>
        <?php if ($show['words']): ?><div class="words">In words: <b><?php echo h(fee_words($total)); ?></b></div><?php endif; ?>
        <?php if ($paid_by): ?><div class="paid"><?php echo implode(' · ', $paid_by); ?></div><?php endif; ?>
        <?php if ($cancelled): ?><div class="voidnote">Cancelled on <?php echo h(date('d M Y', strtotime($r['cancelled_at']))); ?><?php echo $r['cancelled_name'] ? ' by ' . h($r['cancelled_name']) : ''; ?> — <?php echo h($r['cancel_reason']); ?></div><?php endif; ?>
        <?php if ($show['received'] || $show['signature']): ?><div class="foot"><span><?php echo $show['received'] ? 'Received by: ' . h($r['received_name'] ?: '—') : ''; ?></span><?php if ($show['signature']): ?><span class="sign">Signature of the receiver</span><?php endif; ?></div><?php endif; ?>
        <?php if ($show['note'] && trim((string)$settings['receipt_note']) !== ''): ?><div class="note"><?php echo h($settings['receipt_note']); ?></div><?php endif; ?>
        <?php if ($cancelled): ?><div class="void"><span>CANCELLED</span></div><?php endif; ?>
    </div>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php if (!empty($_GET['new']) && !array_filter($list, fn($r) => $r['status'] === 'cancelled')): ?><script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });</script><?php endif; ?>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/fee_helper.php';
require_once '../includes/simple_xlsx_writer.php';

/** Receipts: find any receipt by date, session, book, slip, method, who took it, student or number; print it again — giving the slip of one kept without; cancel it with a reason; Excel. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$date_in = fn(string $k, string $d) => fee_valid_date((string)$in($k, '')) ? (string)$in($k) : $d;
$from = $date_in('from', date('Y-m-01'));
$to = $date_in('to', date('Y-m-d'));
if ($from > $to) [$from, $to] = [$to, $from];
$sessions = exam_sessions();
$session_f = (int)$in('session_id', 0); if (!isset($sessions[$session_f])) $session_f = 0;
$method = (string)$in('method', ''); if (!isset(FEE_METHODS[$method])) $method = '';
$by = (int)$in('by', 0);
$status = (string)$in('status', ''); if (!in_array($status, ['valid', 'cancelled'], true)) $status = '';
$book = (string)$in('book', ''); if (!isset(FEE_BOOKS[$book])) $book = '';
$slip = (string)$in('slip', ''); if (!in_array($slip, ['yes', 'no'], true)) $slip = '';
$search = trim((string)$in('search', ''));
$uid = student_uid_clean($in('uid', ''));
$q = array_filter(['from' => $uid === '' ? $from : null, 'to' => $uid === '' ? $to : null, 'session_id' => $session_f ?: null, 'method' => $method ?: null, 'by' => $by ?: null, 'status' => $status ?: null, 'book' => $book ?: null, 'slip' => $slip ?: null, 'search' => $search !== '' ? $search : null, 'uid' => $uid !== '' ? $uid : null]);
$self = fn(array $over = []) => 'fee_receipts.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    try {
        $act = (string)($_POST['act'] ?? '');
        if ($act === 'give_slips') {
            $ids = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)($_POST['ids'] ?? ''))))));
            if (!$ids || count($ids) > 500) throw new RuntimeException('Tick the receipts whose slips are given (up to 500).');
            $found = db_get_all("SELECT id, receipt_no FROM fee_receipts WHERE status = 'valid' AND id IN (" . implode(',', array_fill(0, count($ids), '?')) . ')', str_repeat('i', count($ids)), ...$ids);
            if (count($found) !== count($ids)) throw new RuntimeException('Some of the ticked receipts are cancelled or gone — look again.');
            db_execute("UPDATE fee_receipts SET slip_given = 1 WHERE status = 'valid' AND id IN (" . implode(',', array_fill(0, count($ids), '?')) . ')', str_repeat('i', count($ids)), ...$ids);
            fee_log($admin_id, 'FEE_SLIPS_GIVEN', 'fee_receipts', null, null, ['receipts' => array_column($found, 'receipt_no')]);
            header('Location: fee_receipt.php?' . http_build_query(['ids' => implode(',', $ids), 'new' => 1]));
            exit();
        }
        if ($act !== 'cancel_receipt') throw new RuntimeException('Nothing to do.');
        $no = fee_cancel_receipt((int)($_POST['receipt_id'] ?? 0), (string)($_POST['reason'] ?? ''), $admin_id);
        $_SESSION['success'] = "Receipt $no cancelled — its money is off the bills it paid, which are owing again.";
    } catch (RuntimeException $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    header('Location: ' . $self(['cancel' => null]));
    exit();
}

$where = []; $types = ''; $params = [];
if ($uid !== '') { $where[] = 'r.student_id = ?'; $types .= 's'; $params[] = $uid; }
else { $where[] = 'r.receipt_date BETWEEN ? AND ?'; $types .= 'ss'; array_push($params, $from, $to); }
if ($session_f) { $where[] = 'r.session_id = ?'; $types .= 'i'; $params[] = $session_f; }
if ($method !== '') { $where[] = 'r.method = ?'; $types .= 's'; $params[] = $method; }
if ($by) { $where[] = 'r.received_by = ?'; $types .= 'i'; $params[] = $by; }
if ($status !== '') { $where[] = 'r.status = ?'; $types .= 's'; $params[] = $status; }
if ($book !== '') { $where[] = 'r.book = ?'; $types .= 's'; $params[] = $book; }
if ($slip !== '') $where[] = 'r.slip_given = ' . ($slip === 'yes' ? 1 : 0);
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(r.receipt_no LIKE ? OR s.student_name LIKE ? OR s.id LIKE ? OR r.reference_no LIKE ?)'; $types .= 'ssss'; array_push($params, $like, $like, $like, $like);
}
$from_sql = 'FROM fee_receipts r JOIN students s ON s.id = r.student_id LEFT JOIN admins a ON a.id = r.received_by
    LEFT JOIN student_academic_history h ON h.student_id = r.student_id AND h.session_id = r.session_id
    LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id WHERE ' . implode(' AND ', $where);
$cols = 'r.*, s.student_name, s.photo, a.full_name AS received_name, c.class_name, sec.section_name, h.roll_no';

if (!empty($_GET['export'])) {
    $rows = exam_xlsx_title('Fee receipts · ' . ($uid !== '' ? $uid : date('d M Y', strtotime($from)) . ' to ' . date('d M Y', strtotime($to))));
    $rows[] = ['Receipt No', 'Date', 'Student', 'School UID', 'Class', 'Amount', 'Paid by', 'Reference', 'Received by', 'Slip given', 'Status', 'Cancel reason'];
    foreach (db_get_all("SELECT $cols $from_sql ORDER BY r.receipt_date, r.id", $types, ...$params) as $r) {
        $rows[] = [$r['receipt_no'], date('d-m-Y', strtotime($r['receipt_date'])), $r['student_name'], $r['student_id'], trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '')),
                   (float)$r['amount'], FEE_METHODS[$r['method']] ?? $r['method'], (string)$r['reference_no'], (string)$r['received_name'], $r['slip_given'] ? 'Yes' : 'No', ucfirst($r['status']), (string)$r['cancel_reason']];
    }
    SimpleXLSXWriter::download('Fee_receipts_' . ($uid !== '' ? $uid : $from . '_to_' . $to) . '.xlsx', $rows, 'Receipts', exam_xlsx_opts(12, 26));
    exit();
}

$sum = db_get_row("SELECT COUNT(*) AS n, COALESCE(SUM(r.status = 'valid'), 0) AS nv, COALESCE(SUM(IF(r.status = 'valid', r.amount, 0)), 0) AS amt, COALESCE(SUM(IF(r.status = 'cancelled', r.amount, 0)), 0) AS cancelled_amt $from_sql", $types, ...$params);
$by_method = array_column(db_get_all("SELECT r.method, SUM(r.amount) AS t $from_sql AND r.status = 'valid' GROUP BY r.method", $types, ...$params), 't', 'method');
$per = 50; $total = (int)$sum['n']; $pages = max(1, (int)ceil($total / $per)); $page = min(max(1, (int)$in('page', 1)), $pages);
$rows = db_get_all("SELECT $cols $from_sql ORDER BY r.receipt_date DESC, r.id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
$collectors = array_column(db_get_all('SELECT DISTINCT a.id, a.full_name FROM fee_receipts r JOIN admins a ON a.id = r.received_by ORDER BY a.full_name'), 'full_name', 'id');
$cancel_row = (int)$in('cancel', 0) ? db_get_row("SELECT r.id, r.receipt_no, r.amount, r.status, s.student_name FROM fee_receipts r JOIN students s ON s.id = r.student_id WHERE r.id = ?", 'i', (int)$in('cancel')) : null;
$student_name = $uid !== '' ? (string)(db_get_row('SELECT student_name FROM students WHERE id = ?', 's', $uid)['student_name'] ?? '') : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Receipts</title>
<?php exam_styles('fee'); ?>
<style>
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 19px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .sum .main b { color: #1b7a3a; font-size: 22px; }
    .ex-table td.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tr.void td { color: #98a6b5; } .ex-table tr.void td.money { text-decoration: line-through; }
    .stu { display: flex; align-items: center; gap: 8px; } .stu img, .stu .ph { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; background: var(--ex-soft); flex: none; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: var(--ex-dark); font-size: 12px; }
    .stu small { display: block; color: #6b7d90; font-size: 11.5px; }
    .pg { display: flex; gap: 4px; justify-content: center; flex-wrap: wrap; margin-top: 12px; }
    .pg a, .pg span { min-width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; text-decoration: none; color: var(--ex-dark); font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg span { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
    .modal .box h3 { margin: 0; color: #8e1b1b; font-size: 16px; }
    .ex-table input.pick { width: 17px; height: 17px; accent-color: var(--ex-light); }
    .slipbar { display: none; align-items: center; gap: 10px; margin: 0 0 10px; padding: 10px 14px; border: 1px solid var(--ex-border); background: var(--ex-soft); border-radius: 12px; font-size: 13px; }
    .slipbar.on { display: flex; }
    .print-head { display: none; }
    @media print { nav.main-navbar-2tier, .ex-banner, .ex-tabs, .noprint, .modal, .alert { display: none !important; } .print-head { display: block; } .ex-table td, .ex-table th { white-space: normal !important; padding: 3px 5px !important; font-size: 11px !important; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Receipts', 'Every money receipt — find it, print it again, or cancel it with a reason', 'fa-receipt',
        ['collect_fee.php' => '<i class="fas fa-cash-register"></i> Collect', 'fee_dues.php' => '<i class="fas fa-file-invoice"></i> Bills', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print list', $self(['export' => 1, 'page' => null, 'cancel' => null]) => '<i class="fas fa-file-excel"></i> Excel']); ?>
    <?php fee_tabs('fee_receipts.php'); exam_flash(); ?>

    <div class="card noprint">
        <form method="get" class="pick">
            <?php if ($uid !== ''): ?>
            <input type="hidden" name="uid" value="<?php echo h($uid); ?>">
            <div><label>Student</label><div style="height:38px;display:flex;align-items:center;gap:8px;font-weight:700;color:var(--ex-dark)"><?php echo h($student_name . ' · ' . $uid); ?> <a href="fee_receipts.php" title="All students"><i class="fas fa-times-circle"></i></a></div></div>
            <?php else: ?>
            <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
            <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div>
            <?php endif; ?>
            <div><label>Session</label><select name="session_id"><option value="0">All sessions</option><?php echo exam_options($sessions, $session_f); ?></select></div>
            <div><label>Paid by</label><select name="method"><option value="">Any</option><?php echo exam_options(FEE_METHODS, $method); ?></select></div>
            <div><label>Received by</label><select name="by"><option value="0">Anyone</option><?php echo exam_options($collectors, $by); ?></select></div>
            <div><label>Status</label><select name="status"><?php echo exam_options(['' => 'All', 'valid' => 'Valid', 'cancelled' => 'Cancelled'], $status); ?></select></div>
            <div><label>Book</label><select name="book"><option value="">Both</option><?php foreach (FEE_BOOKS as $k => $label): ?><option value="<?php echo h($k); ?>"<?php echo $k === $book ? ' selected' : ''; ?>><?php echo h(fee_book_prefix($k) . ' — ' . $label); ?></option><?php endforeach; ?></select></div>
            <div><label>Slip</label><select name="slip"><?php echo exam_options(['' => 'Any', 'yes' => 'Given', 'no' => 'Not given'], $slip); ?></select></div>
            <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Receipt no, name, UID, reference"></div>
            <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
        </form>
    </div>

    <div class="print-head"><?php exam_school_header('FEE RECEIPTS', $uid !== '' ? $student_name . ' · ' . $uid : date('d M Y', strtotime($from)) . ' to ' . date('d M Y', strtotime($to))); ?></div>
    <div class="sum">
        <div class="main"><b><?php echo h(fee_money($sum['amt'])); ?></b><small><?php echo (int)$sum['nv']; ?> valid receipt(s)</small></div>
        <?php foreach (FEE_METHODS as $k => $label): ?><div><b><?php echo h(fee_money($by_method[$k] ?? 0)); ?></b><small><?php echo h($label); ?></small></div><?php endforeach; ?>
        <div><b style="color:#b71c1c"><?php echo h(fee_money($sum['cancelled_amt'])); ?></b><small><?php echo $total - (int)$sum['nv']; ?> cancelled</small></div>
    </div>

    <?php if (!$rows): ?>
    <div class="ex-empty"><i class="fas fa-receipt"></i>No receipt matches<?php echo $uid === '' ? ' between ' . h(date('d M Y', strtotime($from))) . ' and ' . h(date('d M Y', strtotime($to))) : ''; ?>.</div>
    <?php else: ?>
    <form method="post" class="slipbar noprint" id="slipBar">
        <?php echo csrf_field(); ?><input type="hidden" name="act" value="give_slips"><input type="hidden" name="ids" id="slipIds">
        <b id="slipCount"></b><span>ticked — print their slips and mark them given</span>
        <button type="submit" class="btn btn-success btn-sm" style="margin-left:auto"><i class="fas fa-print"></i> Give slips</button>
    </form>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th class="noprint"><input type="checkbox" class="pick" id="pickAll" title="Tick all on this page"></th><th>Receipt</th><th>Date</th><th>Student</th><th>Class</th><th class="money" style="text-align:right">Amount</th><th>Paid by</th><th>Received by</th><th>Status</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): $void = $r['status'] === 'cancelled'; ?>
            <tr class="<?php echo $void ? 'void' : ''; ?>">
                <td class="noprint"><?php if (!$void): ?><input type="checkbox" class="pick" value="<?php echo (int)$r['id']; ?>" aria-label="<?php echo h('Tick ' . $r['receipt_no']); ?>"><?php endif; ?></td>
                <td><b><?php echo h($r['receipt_no']); ?></b><?php echo $r['slip_given'] ? '' : ' <span class="chip warn">no slip</span>'; ?></td>
                <td><?php echo h(date('d M Y', strtotime($r['receipt_date']))); ?></td>
                <td><div class="stu"><?php echo $r['photo'] ? '<img src="../uploads/students/' . h(rawurlencode($r['photo'])) . '" alt="">' : '<span class="ph">' . h(mb_substr($r['student_name'], 0, 1)) . '</span>'; ?><div><a href="<?php echo h('fee_ledger.php?uid=' . rawurlencode($r['student_id'])); ?>"><?php echo h($r['student_name']); ?></a><small><?php echo h($r['student_id']); ?></small></div></div></td>
                <td><?php echo h(trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · ' . $r['roll_no'] : ''))); ?></td>
                <td class="money"><?php echo h(fee_money($r['amount'])); ?></td>
                <td><?php echo h(FEE_METHODS[$r['method']] ?? $r['method']); ?><?php echo $r['reference_no'] ? '<small class="note" style="display:block;margin:0">' . h($r['reference_no']) . '</small>' : ''; ?></td>
                <td><?php echo h($r['received_name'] ?: '—'); ?></td>
                <td><?php echo $void ? fee_state_chip('cancelled') . '<small class="note" style="display:block;margin:0">' . h($r['cancel_reason']) . '</small>' : '<span class="chip ok">Valid</span>'; ?></td>
                <td style="white-space:nowrap" class="noprint">
                    <a class="btn btn-secondary btn-sm" href="<?php echo h('fee_receipt.php?id=' . (int)$r['id']); ?>" target="_blank" title="Print"><i class="fas fa-print"></i></a>
                    <?php if (!$void): ?><button type="button" class="btn btn-danger btn-sm" title="Cancel" onclick="cancelRcpt(<?php echo (int)$r['id']; ?>, <?php echo h(json_encode($r['receipt_no'] . ' — ' . $r['student_name'] . ', ' . fee_money($r['amount']))); ?>)"><i class="fas fa-ban"></i></button><?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php if ($pages > 1): ?>
        <div class="pg noprint"><?php for ($i = 1; $i <= $pages; $i++): ?><?php if ($i === $page): ?><span><?php echo $i; ?></span><?php elseif ($i <= 2 || $i > $pages - 2 || abs($i - $page) <= 2): ?><a href="<?php echo h($self(['page' => $i])); ?>"><?php echo $i; ?></a><?php endif; ?><?php endfor; ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="modal" id="cancelModal">
        <form class="box pf" method="post">
            <?php echo csrf_field(); ?>
            <?php foreach ($q as $k => $v): ?><input type="hidden" name="<?php echo h($k); ?>" value="<?php echo h($v); ?>"><?php endforeach; ?>
            <input type="hidden" name="act" value="cancel_receipt"><input type="hidden" name="receipt_id" id="crId">
            <h3><i class="fas fa-ban"></i> Cancel receipt</h3>
            <p class="note" id="crWhat"></p>
            <label>Reason</label><input type="text" name="reason" maxlength="255" required placeholder="e.g. wrong student, cheque bounced">
            <div class="acts"><button type="submit" class="btn btn-danger"><i class="fas fa-ban"></i> Cancel the receipt</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('cancelModal').classList.remove('open')">Keep it</button></div>
        </form>
    </div>
</div>
<script>
function cancelRcpt(id, what) {
    document.getElementById('crId').value = id;
    document.getElementById('crWhat').textContent = what + '. The receipt stays, marked cancelled; its money comes off the bills it paid, so they are owing again.';
    document.getElementById('cancelModal').classList.add('open');
}
document.getElementById('cancelModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
(function () {
    var picks = Array.prototype.slice.call(document.querySelectorAll('tbody input.pick')), all = document.getElementById('pickAll'), bar = document.getElementById('slipBar');
    if (!all) return;
    function show() {
        var on = picks.filter(function (p) { return p.checked; });
        bar.classList.toggle('on', on.length > 0);
        document.getElementById('slipCount').textContent = on.length + ' receipt(s)';
        document.getElementById('slipIds').value = on.map(function (p) { return p.value; }).join(',');
        all.checked = on.length > 0 && on.length === picks.length;
    }
    picks.forEach(function (p) { p.addEventListener('change', show); });
    all.addEventListener('change', function () { picks.forEach(function (p) { p.checked = all.checked; }); show(); });
})();
<?php if ($cancel_row && $cancel_row['status'] === 'valid'): ?>cancelRcpt(<?php echo (int)$cancel_row['id']; ?>, <?php echo json_encode($cancel_row['receipt_no'] . ' — ' . $cancel_row['student_name'] . ', ' . fee_money($cancel_row['amount']), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE); ?>);<?php endif; ?>
</script>
</body>
</html>

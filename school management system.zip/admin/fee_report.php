<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/fee_helper.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Fee reports: the session in figures (by class and by fee), who has not paid what — with phone numbers — the daily
 * collection, and what each fee brought in. Each can be printed or taken to Excel.
 */
$reports = ['summary' => ['Session Summary', 'fa-chart-pie'], 'dues' => ['Not paid', 'fa-user-clock'], 'daily' => ['Daily Collection', 'fa-calendar-day'], 'heads' => ['Fee-wise', 'fa-tags']];
$type = (string)($_GET['type'] ?? 'summary');
if (!isset($reports[$type])) $type = 'summary';
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = fee_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$class_id = (int)($_GET['class_id'] ?? 0);
if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? array_column(db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id), 'section_name', 'id') : [];
$section_id = (int)($_GET['section_id'] ?? 0);
if (!isset($sections[$section_id])) $section_id = 0;
$session_heads = fee_session_heads(true);
$fee = (int)($_GET['fee'] ?? 0);
if (!isset($session_heads[$fee])) $fee = 0;
$overdue = !empty($_GET['overdue']);
$date = fn(string $k, string $d) => fee_valid_date((string)($_GET[$k] ?? '')) ? (string)$_GET[$k] : $d;
$from = $date('from', $type === 'heads' ? date('Y-m-01') : date('Y-m-d'));
$to = $date('to', date('Y-m-d'));
if ($from > $to) [$from, $to] = [$to, $from];
$method = (string)($_GET['method'] ?? '');
if (!isset(FEE_METHODS[$method])) $method = '';
$book = (string)($_GET['book'] ?? '');
if (!isset(FEE_BOOKS[$book])) $book = '';
$by = (int)($_GET['by'] ?? 0);
$q = array_filter(['type' => $type, 'session_id' => $session_id, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null, 'fee' => $fee ?: null, 'overdue' => $overdue ? 1 : null,
    'from' => in_array($type, ['daily', 'heads'], true) ? $from : null, 'to' => in_array($type, ['daily', 'heads'], true) ? $to : null, 'method' => $method ?: null, 'book' => $book ?: null, 'by' => $by ?: null]);
$link = fn(array $over = []) => 'fee_report.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));
$export = !empty($_GET['export']);
$session_name = exam_session_name($session_id);
$range = date('d M Y', strtotime($from)) . ($from !== $to ? ' to ' . date('d M Y', strtotime($to)) : '');
$xlsx = function (string $title, array $head, array $rows, string $file) {
    $out = exam_xlsx_title($title);
    $out[] = $head;
    foreach ($rows as $r) $out[] = $r;
    SimpleXLSXWriter::download($file, $out, 'Report', exam_xlsx_opts(count($head), 26));
    exit();
};
$rs = fn(int $p) => round($p / 100, 2);
$heads = fee_heads();
$who_line = fn(array $r) => trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · ' . $r['roll_no'] : ''));

$data = [];
if ($type === 'summary') {
    // each bill's payment is shared over its fees in proportion to what each was to pay
    $blank = ['billed' => 0, 'discount' => 0, 'topay' => 0, 'paid' => 0, 'later' => 0, 'bills' => 0, 'students' => []];
    $add = function (?array &$t, string $k, int $p) use ($blank) { $t ??= $blank; $t[$k] += $p; };
    $by_fee = []; $by_class = []; $bills = [];
    foreach (db_get_all("SELECT i.id, i.class_id, i.student_id, i.total, i.paid_amount, it.fee_type_id, it.amount, it.discount, it.net FROM fee_invoices i JOIN fee_invoice_items it ON it.invoice_id = i.id
        WHERE i.session_id = ? AND i.status <> 'cancelled' ORDER BY i.id, it.id", 'i', $session_id) as $r) $bills[(int)$r['id']][] = $r;
    foreach ($bills as $items) {
        $total = fee_paise($items[0]['total']); $paid = min($total, fee_paise($items[0]['paid_amount'])); $given = 0;
        $cid = (int)$items[0]['class_id'];
        $add($by_class[$cid], 'bills', 1);
        $by_class[$cid]['students'][$items[0]['student_id']] = true;
        foreach ($items as $i => $it) {
            $hid = (int)$it['fee_type_id']; $net = fee_paise($it['net']);
            $share = $i === array_key_last($items) ? $paid - $given : ($total > 0 ? intdiv($paid * $net, $total) : 0);
            $given += $share;
            $add($by_fee[$hid], 'bills', 1);
            foreach (['billed' => fee_paise($it['amount']), 'discount' => fee_paise($it['discount']), 'topay' => $net, 'paid' => $share] as $k => $p) { $add($by_fee[$hid], $k, $p); $add($by_class[$cid], $k, $p); }
        }
    }
    $everyone = array_filter(fee_session_heads(), fn($h) => $h['who_pays'] !== 'some');
    $students = fee_class_students($session_id, array_keys($classes));
    foreach (fee_standing($session_id, $students, $everyone) as $uid => $cells) foreach ($cells as $hid => $c) {
        if ($c['state'] !== 'todo') continue;
        $add($by_fee[$hid], 'later', $c['owe']);
        $add($by_class[(int)$students[$uid]['class_id']], 'later', $c['owe']);
    }
    $in_order = fn(array $rows, array $order) => array_replace(array_intersect_key(array_flip(array_keys($order)), $rows), $rows);
    $data['classes'] = $in_order($by_class, $classes);
    $data['fees'] = $in_order($by_fee, $heads);
    $data['receipts'] = array_column(db_get_all("SELECT book, COUNT(*) AS n, SUM(amount) AS amt FROM fee_receipts WHERE session_id = ? AND status = 'valid' GROUP BY book", 'i', $session_id), null, 'book');
    if ($export) $xlsx("Fees — session summary $session_name", ['Class', 'Students', 'Bills', 'Billed', 'Discount', 'To pay', 'Paid', 'Owing on bills', 'Not collected yet'],
        array_map(fn($cid, $r) => [isset($classes[$cid]) ? 'Class ' . $classes[$cid]['name'] : '—', count($r['students']), $r['bills'], $rs($r['billed']), $rs($r['discount']), $rs($r['topay']), $rs($r['paid']), $rs($r['topay'] - $r['paid']), $rs($r['later'])], array_keys($data['classes']), $data['classes']),
        "Fees_summary_$session_name.xlsx");
}
if ($type === 'dues') {
    $students = fee_class_students($session_id, $class_id ? [$class_id] : array_keys($classes), $section_id);
    $want = $fee ? [$fee => $session_heads[$fee]] : fee_session_heads();
    $standing = fee_standing($session_id, $students, $want);
    $charges = [];
    if (!$fee && $students) {
        $uids = array_map('strval', array_keys($students));
        foreach (db_get_all("SELECT student_id, title, total - paid_amount AS o, due_date FROM fee_invoices WHERE session_id = ? AND status IN ('pending', 'partial') AND demand_key IS NULL
            AND student_id IN (" . implode(',', array_fill(0, count($uids), '?')) . ') ORDER BY id', 'i' . str_repeat('s', count($uids)), $session_id, ...$uids) as $b) $charges[$b['student_id']][] = $b;
    }
    $today = date('Y-m-d');
    $data['rows'] = [];
    foreach ($students as $uid => $st) {
        $items = []; $owe = 0; $first = null;
        $take = function (string $what, int $p, ?string $due) use (&$items, &$owe, &$first, $overdue, $today) {
            if ($overdue && (!$due || $due >= $today)) return;
            $items[] = $what . ' ' . preg_replace('/\.00$/', '', fee_money_p($p));
            $owe += $p;
            if ($due && ($first === null || $due < $first)) $first = $due;
        };
        foreach ($standing[$uid] ?? [] as $hid => $c) {
            if (!in_array($c['state'], ['todo', 'due', 'part'], true) || ($c['state'] === 'todo' && !$fee && $want[$hid]['who_pays'] === 'some')) continue;
            $take($want[$hid]['type_name'], $c['owe'], $c['due'] ?? $c['bill']['due'] ?? null);
        }
        foreach ($charges[(string)$uid] ?? [] as $b) $take($b['title'], fee_paise($b['o']), $b['due_date']);
        if ($owe > 0) $data['rows'][] = $st + ['uid' => (string)$uid, 'items' => $items, 'owe' => $owe, 'first_due' => $first, 'late' => $first !== null && $first < $today];
    }
    $data['classes'] = [];
    foreach ($data['rows'] as $r) {
        $data['classes'][(int)$r['class_id']]['n'] = ($data['classes'][(int)$r['class_id']]['n'] ?? 0) + 1;
        $data['classes'][(int)$r['class_id']]['owe'] = ($data['classes'][(int)$r['class_id']]['owe'] ?? 0) + $r['owe'];
    }
    if ($export) $xlsx('Fees — not paid ' . $session_name . ($class_id ? ' · Class ' . $classes[$class_id]['name'] : '') . ($fee ? ' · ' . $session_heads[$fee]['type_name'] : ''),
        ['School UID', 'Student', 'Class', 'Section', 'Roll', 'Father', 'Phone', 'Not paid', 'Owing', 'Last date'],
        array_map(fn($r) => [$r['uid'], $r['student_name'], (string)$r['class_name'], (string)$r['section_name'], (string)$r['roll_no'], (string)$r['father_name'], $r['phone'], implode(' · ', $r['items']), $rs($r['owe']),
            $r['first_due'] ? date('d-m-Y', strtotime($r['first_due'])) : ''], $data['rows']),
        "Fees_not_paid_$session_name.xlsx");
}
if ($type === 'daily') {
    $where = ["r.status = 'valid'", 'r.receipt_date BETWEEN ? AND ?']; $types = 'ss'; $params = [$from, $to];
    if ($method !== '') { $where[] = 'r.method = ?'; $types .= 's'; $params[] = $method; }
    if ($book !== '') { $where[] = 'r.book = ?'; $types .= 's'; $params[] = $book; }
    if ($by) { $where[] = 'r.received_by = ?'; $types .= 'i'; $params[] = $by; }
    $data['rows'] = db_get_all("SELECT r.*, s.student_name, a.full_name AS received_name, c.class_name, sec.section_name, h.roll_no
        FROM fee_receipts r JOIN students s ON s.id = r.student_id LEFT JOIN admins a ON a.id = r.received_by
        LEFT JOIN student_academic_history h ON h.student_id = r.student_id AND h.session_id = r.session_id
        LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE " . implode(' AND ', $where) . ' ORDER BY r.receipt_date, r.id', $types, ...$params);
    $data['methods'] = []; $data['books'] = []; $data['people'] = [];
    foreach ($data['rows'] as $r) {
        $data['methods'][$r['method']] = ($data['methods'][$r['method']] ?? 0) + fee_paise($r['amount']);
        $data['books'][$r['book']] = ($data['books'][$r['book']] ?? 0) + fee_paise($r['amount']);
        $who = $r['received_name'] ?: '—';
        $data['people'][$who] = ($data['people'][$who] ?? 0) + fee_paise($r['amount']);
    }
    if ($export) $xlsx("Fees — collection $range", ['Date', 'Receipt No', 'Slip given', 'Student', 'School UID', 'Class', 'Amount', 'Paid by', 'Reference', 'Received by'],
        array_map(fn($r) => [date('d-m-Y', strtotime($r['receipt_date'])), $r['receipt_no'], $r['slip_given'] ? 'Yes' : 'No', $r['student_name'], $r['student_id'], $who_line($r),
            $rs(fee_paise($r['amount'])), FEE_METHODS[$r['method']] ?? $r['method'], (string)$r['reference_no'], (string)$r['received_name']], $data['rows']),
        "Fees_collection_{$from}_to_$to.xlsx");
}
if ($type === 'heads') {
    // each receipt line is shared out over the fees of the bill it paid, in proportion to what each fee owed
    $lines = db_get_all("SELECT t.invoice_id, t.amount FROM fee_transactions t JOIN fee_receipts r ON r.id = t.receipt_id WHERE r.status = 'valid' AND r.receipt_date BETWEEN ? AND ?", 'ss', $from, $to);
    $items = [];
    $ids = array_values(array_unique(array_map(fn($l) => (int)$l['invoice_id'], $lines)));
    if ($ids) foreach (db_get_all('SELECT invoice_id, fee_type_id, net FROM fee_invoice_items WHERE invoice_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id',
        str_repeat('i', count($ids)), ...$ids) as $it) $items[(int)$it['invoice_id']][] = [(int)$it['fee_type_id'], fee_paise($it['net'])];
    $got = [];
    foreach ($lines as $l) {
        $its = $items[(int)$l['invoice_id']] ?? [];
        $whole = array_sum(array_column($its, 1));
        $amt = fee_paise($l['amount']);
        if ($whole <= 0) continue;
        $given = 0;
        foreach ($its as $i => [$hid, $net]) {
            $share = $i === array_key_last($its) ? $amt - $given : intdiv($amt * $net, $whole);
            $given += $share;
            $got[$hid] = ($got[$hid] ?? 0) + $share;
        }
    }
    arsort($got);
    $data['rows'] = $got;
    $data['total'] = array_sum($got);
    if ($export) $xlsx("Fees — collection by fee $range", ['Fee', 'Slip', 'Collected'],
        array_map(fn($hid, $p) => [$heads[$hid]['type_name'] ?? "#$hid", empty($heads[$hid]['slip']) ? 'No' : 'Yes', $rs($p)], array_keys($got), $got),
        "Fees_by_fee_{$from}_to_$to.xlsx");
}
$collectors = array_column(db_get_all('SELECT DISTINCT a.id, a.full_name FROM fee_receipts r JOIN admins a ON a.id = r.received_by ORDER BY a.full_name'), 'full_name', 'id');
$pct = fn(int $part, int $whole) => $whole > 0 ? round($part * 100 / $whole, 1) . '%' : '—';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h('Fee Reports — ' . $reports[$type][0]); ?></title>
<?php exam_styles('fee'); ?>
<style>
    .seg { display: inline-flex; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 14px; }
    .seg a { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; } .seg a i { margin-right: 6px; }
    .pick .chk { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 13px; font-weight: 600; color: #3b5168; text-transform: none; }
    .pick .chk input { min-width: 0; width: 17px; height: 17px; }
    .sum { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 10px; margin: 0 0 14px; }
    .sum div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; }
    .sum b { display: block; font-size: 20px; color: var(--ex-dark); font-variant-numeric: tabular-nums; } .sum small { color: #6b7d90; font-size: 12px; }
    .ex-table td.money, .ex-table th.money { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .ex-table tfoot td { font-weight: 700; background: var(--ex-soft); }
    .ex-table tr.day td { background: var(--ex-group); font-weight: 700; color: var(--ex-dark); }
    .bar-cell { position: relative; } .bar-cell i { position: absolute; left: 0; top: 20%; bottom: 20%; background: var(--ex-group); border-radius: 4px; z-index: 0; } .bar-cell span { position: relative; z-index: 1; }
    .owing { color: #b71c1c; font-weight: 700; }
    .titles { font-size: 11.5px; color: #6b7d90; }
    .print-head { display: none; }
    @media print {
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .seg, .noprint { display: none !important; }
        .print-head { display: block; }
        .ex-table a { color: inherit; text-decoration: none; }
        .ex-table td, .ex-table th { white-space: normal !important; padding: 3px 5px !important; font-size: 11px !important; }
        .auto-table-scroll { overflow: visible !important; margin-top: 0 !important; }
        .card { border: 0; padding: 0; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Fee Reports', 'The session in figures, who has not paid, what came in each day and from which fee', 'fa-chart-bar',
        [$link(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php fee_tabs('fee_report.php'); ?>
    <div class="seg">
        <?php foreach ($reports as $k => [$label, $icon]): ?><a href="<?php echo h('fee_report.php?' . http_build_query(['type' => $k, 'session_id' => $session_id])); ?>" class="<?php echo $k === $type ? 'on' : ''; ?>"><i class="fas <?php echo h($icon); ?>"></i><?php echo h($label); ?></a><?php endforeach; ?>
    </div>
    <div class="print-head"><?php exam_school_header('FEE REPORT — ' . strtoupper($reports[$type][0]), in_array($type, ['daily', 'heads'], true) ? $range : 'Session ' . $session_name . ($type === 'dues' && $class_id ? ' · Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : '') : '') . ($type === 'dues' && $fee ? ' · ' . $session_heads[$fee]['type_name'] : '')); ?></div>

    <form method="get" class="card pick noprint">
        <input type="hidden" name="type" value="<?php echo h($type); ?>">
        <?php if (in_array($type, ['summary', 'dues'], true)): ?>
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <?php endif; ?>
        <?php if ($type === 'dues'): ?>
        <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="0">All classes</option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo $cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
        <?php if ($class_id): ?><div><label>Section</label><select name="section_id"><option value="0">All sections</option><?php echo exam_options($sections, $section_id); ?></select></div><?php endif; ?>
        <div><label>Fee</label><select name="fee"><option value="0">All fees</option><?php foreach ($session_heads as $hid => $hd): ?><option value="<?php echo (int)$hid; ?>"<?php echo $hid === $fee ? ' selected' : ''; ?>><?php echo h($hd['type_name']); ?></option><?php endforeach; ?></select></div>
        <label class="chk"><input type="checkbox" name="overdue" value="1"<?php echo $overdue ? ' checked' : ''; ?>> Past the last date only</label>
        <?php endif; ?>
        <?php if (in_array($type, ['daily', 'heads'], true)): ?>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div>
        <?php endif; ?>
        <?php if ($type === 'daily'): ?>
        <div><label>Book</label><select name="book"><option value="">Both</option><?php foreach (FEE_BOOKS as $k => $label): ?><option value="<?php echo h($k); ?>"<?php echo $k === $book ? ' selected' : ''; ?>><?php echo h(fee_book_prefix($k) . ' — ' . $label); ?></option><?php endforeach; ?></select></div>
        <div><label>Paid by</label><select name="method"><option value="">Any</option><?php echo exam_options(FEE_METHODS, $method); ?></select></div>
        <div><label>Received by</label><select name="by"><option value="0">Anyone</option><?php echo exam_options($collectors, $by); ?></select></div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>

<?php if ($type === 'summary'):
    $T = fn(string $k) => array_sum(array_column($data['classes'], $k));
    [$billed, $disc, $topay, $paid, $later] = [$T('billed'), $T('discount'), $T('topay'), $T('paid'), $T('later')];
    $rc = $data['receipts']; ?>
    <div class="sum">
        <div><b style="color:#1b7a3a"><?php echo h(fee_money_p($paid)); ?></b><small>collected in <?php echo h($session_name); ?></small></div>
        <div><b class="owing"><?php echo h(fee_money_p($topay - $paid)); ?></b><small>owing on bills</small></div>
        <div><b><?php echo h(fee_money_p($later)); ?></b><small>not collected yet — fees everyone pays</small></div>
        <div><b><?php echo h(fee_money_p($disc)); ?></b><small>discount</small></div>
        <div><b><?php echo (int)(($rc['main']['n'] ?? 0) + ($rc['cash']['n'] ?? 0)); ?></b><small>receipts · <?php echo h(fee_book_prefix('main')); ?> <?php echo h(fee_money($rc['main']['amt'] ?? 0)); ?> · <?php echo h(fee_book_prefix('cash')); ?> <?php echo h(fee_money($rc['cash']['amt'] ?? 0)); ?></small></div>
    </div>
    <?php if (!$data['classes']): ?>
    <div class="ex-empty"><i class="fas fa-chart-pie"></i>No fee is set or collected in <?php echo h($session_name); ?> yet.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <h2>By class</h2>
        <table class="ex-table">
            <thead><tr><th>Class</th><th class="num">Students</th><th class="num">Bills</th><th class="money">To pay</th><th class="money">Paid</th><th class="money">Owing on bills</th><th class="money">Not collected yet</th><th class="num">Collected</th></tr></thead>
            <tbody>
            <?php foreach ($data['classes'] as $cid => $r): $o = $r['topay'] - $r['paid']; ?>
            <tr><td><b><?php echo isset($classes[$cid]) ? 'Class ' . h($classes[$cid]['name']) : '—'; ?></b></td><td class="num"><?php echo count($r['students']); ?></td><td class="num"><?php echo (int)$r['bills']; ?></td>
                <td class="money"><?php echo h(fee_money_p($r['topay'])); ?></td><td class="money"><?php echo h(fee_money_p($r['paid'])); ?></td>
                <td class="money <?php echo $o ? 'owing' : ''; ?>"><?php echo h(fee_money_p($o)); ?></td><td class="money"><?php echo h(fee_money_p($r['later'])); ?></td><td class="num"><?php echo $pct($r['paid'], $r['topay'] + $r['later']); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><td class="num"></td><td class="num"><?php echo array_sum(array_column($data['classes'], 'bills')); ?></td><td class="money"><?php echo h(fee_money_p($topay)); ?></td><td class="money"><?php echo h(fee_money_p($paid)); ?></td><td class="money"><?php echo h(fee_money_p($topay - $paid)); ?></td><td class="money"><?php echo h(fee_money_p($later)); ?></td><td class="num"><?php echo $pct($paid, $topay + $later); ?></td></tr></tfoot>
        </table>
        <p class="note">Collected: what is paid, out of what the bills ask and the fees everyone pays that are not collected yet.</p>
    </div>
    <div class="card" style="overflow-x:auto">
        <h2>By fee</h2>
        <table class="ex-table">
            <thead><tr><th>Fee</th><th class="num">Bills</th><th class="money">Billed</th><th class="money">Discount</th><th class="money">Paid</th><th class="money">Owing on bills</th><th class="money">Not collected yet</th></tr></thead>
            <tbody>
            <?php foreach ($data['fees'] as $hid => $r): ?>
            <tr><td><b><?php echo h($heads[$hid]['type_name'] ?? "#$hid"); ?></b><?php echo empty($heads[$hid]['slip']) ? ' <span class="chip warn">no slip</span>' : ''; ?></td><td class="num"><?php echo (int)$r['bills']; ?></td>
                <td class="money"><?php echo h(fee_money_p($r['billed'])); ?></td><td class="money"><?php echo h(fee_money_p($r['discount'])); ?></td><td class="money"><?php echo h(fee_money_p($r['paid'])); ?></td>
                <td class="money"><?php echo h(fee_money_p($r['topay'] - $r['paid'])); ?></td><td class="money"><?php echo h(fee_money_p($r['later'])); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

<?php elseif ($type === 'dues'): $owing = array_sum(array_column($data['rows'], 'owe')); ?>
    <div class="sum">
        <div><b><?php echo count($data['rows']); ?></b><small>student(s) have not paid</small></div>
        <div><b class="owing"><?php echo h(fee_money_p($owing)); ?></b><small>owing in all</small></div>
        <div><b><?php echo count(array_filter($data['rows'], fn($r) => $r['late'])); ?></b><small>past a last date</small></div>
    </div>
    <?php if (!$data['rows']): ?>
    <div class="ex-empty"><i class="fas fa-check-circle" style="color:#1b7a3a"></i>Everyone here has paid.</div>
    <?php elseif (!$class_id): ?>
    <div class="card" style="overflow-x:auto">
        <h2>By class <small>choose a class to see its students — Excel has everyone</small></h2>
        <table class="ex-table">
            <thead><tr><th>Class</th><th class="num">Students who have not paid</th><th class="money">Owing</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($classes as $cid => $c): if (empty($data['classes'][$cid])) continue; $r = $data['classes'][$cid]; ?>
            <tr><td><b>Class <?php echo h($c['name']); ?></b></td><td class="num"><?php echo (int)$r['n']; ?></td><td class="money owing"><?php echo h(fee_money_p($r['owe'])); ?></td>
                <td class="noprint"><a href="<?php echo h($link(['class_id' => $cid])); ?>">See students</a></td></tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><td class="num"><?php echo count($data['rows']); ?></td><td class="money"><?php echo h(fee_money_p($owing)); ?></td><td class="noprint"></td></tr></tfoot>
        </table>
    </div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>#</th><th>Student</th><th>Class</th><th>Father · Phone</th><th>Not paid</th><th class="money">Owing</th><th>Last date</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php foreach ($data['rows'] as $i => $r): ?>
            <tr>
                <td><?php echo $i + 1; ?></td>
                <td><b><?php echo h($r['student_name']); ?></b><small class="titles" style="display:block"><?php echo h($r['uid']); ?></small></td>
                <td style="white-space:nowrap"><?php echo h($who_line($r)); ?></td>
                <td><?php echo h($r['father_name'] ?? ''); ?><?php echo $r['phone'] ? ($r['father_name'] ? '<br>' : '') . '<i class="fas fa-phone" style="font-size:11px;color:#8a9aab"></i> ' . h($r['phone']) : ''; ?></td>
                <td class="titles"><?php echo h(implode(' · ', $r['items'])); ?></td>
                <td class="money owing"><?php echo h(fee_money_p($r['owe'])); ?></td>
                <td style="white-space:nowrap"><?php echo $r['first_due'] ? h(date('d M Y', strtotime($r['first_due']))) : '—'; ?> <?php echo $r['late'] ? fee_state_chip('overdue') : ''; ?></td>
                <td class="noprint"><a class="btn btn-success btn-sm" href="<?php echo h('collect_fee.php?' . http_build_query(['uid' => $r['uid'], 'session_id' => $session_id])); ?>" title="Collect"><i class="fas fa-cash-register"></i></a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="5">Total</td><td class="money"><?php echo h(fee_money_p($owing)); ?></td><td></td><td class="noprint"></td></tr></tfoot>
        </table>
        <p class="note">A fee for some students only counts here once it is billed — or when you choose that fee above, to see who has not paid it.</p>
    </div>
    <?php endif; ?>

<?php elseif ($type === 'daily'): $total = array_sum($data['methods']); ?>
    <div class="sum">
        <div><b style="color:#1b7a3a"><?php echo h(fee_money_p($total)); ?></b><small><?php echo count($data['rows']); ?> receipt(s) · <?php echo h($range); ?></small></div>
        <?php foreach (FEE_BOOKS as $k => $label): ?><div><b><?php echo h(fee_money_p($data['books'][$k] ?? 0)); ?></b><small><?php echo h(fee_book_prefix($k) . ' — ' . $label); ?></small></div><?php endforeach; ?>
        <?php foreach (FEE_METHODS as $k => $label): ?><div><b><?php echo h(fee_money_p($data['methods'][$k] ?? 0)); ?></b><small><?php echo h($label); ?></small></div><?php endforeach; ?>
    </div>
    <?php if ($data['people']): ?><p class="note"><b>Received by:</b> <?php echo h(implode(' · ', array_map(fn($w, $p) => "$w " . fee_money_p($p), array_keys($data['people']), $data['people']))); ?></p><?php endif; ?>
    <?php if (!$data['rows']): ?>
    <div class="ex-empty"><i class="fas fa-calendar-day"></i>No money received <?php echo $from === $to ? 'on ' . h(date('d M Y', strtotime($from))) : 'from ' . h($range); ?>.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Receipt</th><th>Student</th><th>Class</th><th>Paid by</th><th>Received by</th><th class="money">Amount</th></tr></thead>
            <tbody>
            <?php $day = null;
            foreach ($data['rows'] as $r):
                if ($day !== $r['receipt_date']): $day = $r['receipt_date']; $day_sum = array_sum(array_map(fn($x) => $x['receipt_date'] === $day ? fee_paise($x['amount']) : 0, $data['rows'])); ?>
                <tr class="day"><td colspan="5"><?php echo h(date('l, d M Y', strtotime($day))); ?></td><td class="money"><?php echo h(fee_money_p($day_sum)); ?></td></tr>
                <?php endif; ?>
            <tr>
                <td><a href="<?php echo h('fee_receipt.php?id=' . (int)$r['id']); ?>" target="_blank"><b><?php echo h($r['receipt_no']); ?></b></a><?php echo $r['slip_given'] ? '' : ' <span class="chip warn">no slip</span>'; ?></td>
                <td><?php echo h($r['student_name']); ?> <small class="titles"><?php echo h($r['student_id']); ?></small></td>
                <td><?php echo h($who_line($r)); ?></td>
                <td><?php echo h(FEE_METHODS[$r['method']] ?? $r['method']); ?><?php echo $r['reference_no'] ? ' <small class="titles">' . h($r['reference_no']) . '</small>' : ''; ?></td>
                <td><?php echo h($r['received_name'] ?: '—'); ?></td>
                <td class="money"><?php echo h(fee_money($r['amount'])); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td colspan="5">Total</td><td class="money"><?php echo h(fee_money_p($total)); ?></td></tr></tfoot>
        </table>
    </div>
    <?php endif; ?>

<?php else: $max = $data['rows'] ? max($data['rows']) : 0; ?>
    <div class="sum">
        <div><b style="color:#1b7a3a"><?php echo h(fee_money_p($data['total'])); ?></b><small>collected · <?php echo h($range); ?></small></div>
        <div><b><?php echo count($data['rows']); ?></b><small>fee(s)</small></div>
    </div>
    <?php if (!$data['rows']): ?>
    <div class="ex-empty"><i class="fas fa-tags"></i>No money received in these dates.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Fee</th><th class="money">Collected</th><th style="width:40%">Share</th></tr></thead>
            <tbody>
            <?php foreach ($data['rows'] as $hid => $p): $hd = $heads[$hid] ?? null; ?>
            <tr><td><b><?php echo h($hd['type_name'] ?? "#$hid"); ?></b><?php echo $hd && !$hd['slip'] ? ' <span class="chip warn">no slip</span>' : ''; ?></td><td class="money"><?php echo h(fee_money_p($p)); ?></td>
                <td class="bar-cell"><i style="width:<?php echo $max ? round($p * 100 / $max) : 0; ?>%"></i><span><?php echo $pct($p, $data['total']); ?></span></td></tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><td class="money"><?php echo h(fee_money_p($data['total'])); ?></td><td></td></tr></tfoot>
        </table>
        <p class="note">A payment on a bill of several fees is shared out over them in proportion to what each owed.</p>
    </div>
    <?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>

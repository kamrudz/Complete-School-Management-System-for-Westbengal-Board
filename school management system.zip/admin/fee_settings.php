<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/fee_helper.php';

/** Fee Settings: what the school collects — each fee with its amount by class, who pays, slip and account — and what the slip shows. */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = fee_active_session_id() ?: (int)array_key_first($sessions);
$classes = class_rows();
$go = function (string $kind = '', string $msg = '', string $anchor = '') use ($session_id) {
    if ($kind !== '') $_SESSION[$kind] = $msg;
    header('Location: fee_settings.php?' . http_build_query(['session_id' => $session_id]) . $anchor);
    exit();
};
$year_of = fn(int $sid) => preg_match('/(\d{4})/', exam_session_name($sid), $m) ? (int)$m[1] : 0;
$prev_session = 0;
foreach (array_keys($sessions) as $sid) if ($sid !== $session_id && $year_of($sid) < $year_of($session_id) && $year_of($sid) > $year_of($prev_session)) $prev_session = $sid;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'save_fee') {
            $id = (int)($_POST['id'] ?? 0);
            $old = $id ? db_get_row('SELECT * FROM fee_types WHERE id = ?', 'i', $id) : null;
            if ($id && !$old) throw new RuntimeException('That fee is gone — reload the page.');
            $name = trim((string)($_POST['type_name'] ?? ''));
            if ($name === '' || mb_strlen($name) > 100) throw new RuntimeException('Give the fee a name (up to 100 letters).');
            $charge = (string)($_POST['charge'] ?? '');
            if (!isset(FEE_CHARGES[$charge])) throw new RuntimeException('Choose how the fee is charged.');
            if ($old && $old['charge'] !== $charge && fee_head_used($id)) throw new RuntimeException("$name already has amounts or bills, so it stays " . mb_strtolower(FEE_CHARGES[$old['charge']]) . '.');
            $who = $charge === 'session' ? (string)($_POST['who_pays'] ?? '') : 'everyone';
            if (!isset(FEE_WHO_PAYS[$who])) throw new RuntimeException('Choose who pays.');
            $acc = (int)($_POST['account_id'] ?? 0);
            if ($acc && !isset(acc_accounts()[$acc])) throw new RuntimeException('Choose an account from the list.');
            $usual = 0; $cells = []; $due = null;
            if ($charge === 'any') {
                $raw = trim((string)($_POST['usual_amount'] ?? ''));
                $usual = $raw === '' ? 0 : fee_amount_in($raw);
                if ($usual === null || $usual > 10000000) throw new RuntimeException('Usual amount: a number from 0 to 1,00,000.');
            } else {
                $raw = json_decode((string)($_POST['amounts'] ?? ''), true);
                if (!is_array($raw)) throw new RuntimeException('The class amounts did not arrive — try again.');
                foreach ($classes as $cid => $c) {
                    $v = $raw[$cid] ?? '';
                    $p = !is_scalar($v) ? null : (trim((string)$v) === '' ? 0 : fee_amount_in($v));
                    if ($p === null || $p > 10000000) throw new RuntimeException("Class {$c['name']}: give a number from 0 to 1,00,000.");
                    $cells[$cid] = $p;
                }
                $d = trim((string)($_POST['due_date'] ?? ''));
                if ($d !== '' && !fee_valid_date($d)) throw new RuntimeException('The last date is not a date.');
                $due = $d !== '' ? $d : null;
            }
            $data = ['type_name' => $name, 'charge' => $charge, 'who_pays' => $who, 'slip' => !empty($_POST['slip']) ? 1 : 0, 'account_id' => $acc ?: null,
                'default_amount' => fee_rupees($usual), 'discountable' => !empty($_POST['discountable']) ? 1 : 0, 'is_active' => !empty($_POST['is_active']) ? 1 : 0,
                'sort_order' => max(0, min(999, (int)($_POST['sort_order'] ?? 0)))];
            if (!$old || $old['charge'] !== $charge) $data['category'] = $charge === 'any' ? 'other' : 'admission';
            db_begin_transaction();
            try {
                if ($old) db_update('fee_types', $data, ['id' => $id], 'i');
                elseif (!($id = (int)db_insert('fee_types', $data))) throw new RuntimeException('The fee could not be saved.');
                foreach ($cells as $cid => $p) {
                    if ($p > 0) db_execute('INSERT INTO fee_structures (session_id, class_id, fee_type_id, amount, due_date) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE amount = VALUES(amount), due_date = VALUES(due_date)',
                        'iiiss', $session_id, $cid, $id, fee_rupees($p), $due);
                    else db_execute('DELETE FROM fee_structures WHERE session_id = ? AND class_id = ? AND fee_type_id = ?', 'iii', $session_id, $cid, $id);
                }
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                if (!($e instanceof mysqli_sql_exception) && $e instanceof RuntimeException) throw $e;
                throw new RuntimeException((int)$e->getCode() === 1062 ? "A fee called $name is already there." : 'The fee could not be saved: ' . $e->getMessage());
            }
            fee_log($admin_id, $old ? 'FEE_HEAD_UPDATED' : 'FEE_HEAD_ADDED', 'fee_types', $id, $old, $data + ($cells ? ['session' => exam_session_name($session_id), 'amounts' => array_map('fee_rupees', array_filter($cells))] : []));
            $go('success', "$name saved.");
        }
        if ($act === 'delete_fee') {
            $h = db_get_row('SELECT * FROM fee_types WHERE id = ?', 'i', (int)($_POST['id'] ?? 0));
            if (!$h) throw new RuntimeException('That fee is gone — reload the page.');
            if (fee_head_billed((int)$h['id'])) throw new RuntimeException("{$h['type_name']} is on bills already — switch it off instead.");
            db_begin_transaction();
            try {
                db_execute('DELETE FROM fee_structures WHERE fee_type_id = ?', 'i', (int)$h['id']);
                db_execute('DELETE FROM fee_types WHERE id = ?', 'i', (int)$h['id']);
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('The fee could not be deleted: ' . $e->getMessage());
            }
            fee_log($admin_id, 'FEE_HEAD_DELETED', 'fee_types', (int)$h['id'], $h, null);
            $go('success', "{$h['type_name']} deleted.");
        }
        if ($act === 'copy_amounts') {
            if (!$prev_session) throw new RuntimeException('There is no earlier session to copy from.');
            $n = db_execute('INSERT IGNORE INTO fee_structures (session_id, class_id, fee_type_id, amount, due_date)
                SELECT ?, class_id, fee_type_id, amount, IF(due_date IS NULL, NULL, DATE_ADD(due_date, INTERVAL ? YEAR)) FROM fee_structures WHERE session_id = ?',
                'iii', $session_id, $year_of($session_id) - $year_of($prev_session), $prev_session);
            fee_log($admin_id, 'FEE_AMOUNTS_COPIED', 'fee_structures', $session_id, null, ['from' => exam_session_name($prev_session), 'to' => exam_session_name($session_id), 'rows' => $n]);
            $go('success', "$n amount(s) copied from " . exam_session_name($prev_session) . ' — the ones already set were kept.');
        }
        if ($act === 'save_slip') {
            $main = strtoupper(trim((string)($_POST['receipt_prefix'] ?? '')));
            $cash = strtoupper(trim((string)($_POST['cash_prefix'] ?? '')));
            foreach (['With slip' => $main, 'No slip' => $cash] as $label => $p) if (!preg_match('/^[A-Z0-9-]{1,10}$/', $p)) throw new RuntimeException("$label book prefix: 1 to 10 capitals, digits or -.");
            if ($main === $cash) throw new RuntimeException('The two receipt books need different prefixes.');
            foreach (['main' => $cash, 'cash' => $main] as $other => $p) {
                if (db_get_row('SELECT 1 FROM fee_receipts WHERE book = ? AND receipt_no LIKE ? LIMIT 1', 'ss', $other, "$p/%")) throw new RuntimeException("$p is already on receipts of the other book — choose another prefix.");
            }
            $title = trim((string)($_POST['slip_title'] ?? ''));
            if ($title === '' || mb_strlen($title) > 60) throw new RuntimeException('Slip title: up to 60 letters.');
            $ticked = is_array($_POST['show'] ?? null) ? $_POST['show'] : [];
            $on = [];
            foreach (FEE_SLIP_FIELDS as $fields) foreach (array_keys($fields) as $k) if (!empty($ticked[$k])) $on[] = $k;
            $data = ['receipt_prefix' => $main, 'cash_prefix' => $cash, 'receipt_copies' => (int)($_POST['receipt_copies'] ?? 2) === 1 ? 1 : 2, 'slip_title' => $title,
                'slip_fields' => json_encode($on), 'receipt_note' => mb_substr(trim((string)($_POST['receipt_note'] ?? '')), 0, 255) ?: null, 'updated_by' => $admin_id ?: null];
            $old = fee_settings();
            db_update('fee_settings', $data, ['id' => 1], 'i');
            fee_log($admin_id, 'FEE_OPTIONS_SAVED', 'fee_settings', 1, $old, $data);
            $go('success', 'Slip options saved.', '#slip');
        }
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage());
    }
    $go();
}

$heads = fee_heads();
$billed = [];
foreach (db_get_all('SELECT DISTINCT fee_type_id AS id FROM fee_invoice_items') as $r) $billed[(int)$r['id']] = true;
$by_head = []; $due_of = [];
foreach (fee_class_amounts($session_id) as $cid => $hs) foreach ($hs as $hid => $a) {
    $by_head[$hid][$cid] = $a['amount'];
    if ($a['due_date']) $due_of[$hid] = $a['due_date'];
}
$accounts = acc_accounts();
$default_acc = $accounts[(int)acc_settings()['fee_account_id']] ?? null;
$settings = fee_settings();
$show = fee_slip_fields();
$prev_has = $prev_session && db_get_row('SELECT 1 FROM fee_structures WHERE session_id = ? LIMIT 1', 'i', $prev_session) && !$by_head;
$last_receipt = (int)(db_get_row("SELECT MAX(id) AS id FROM fee_receipts WHERE status = 'valid'")['id'] ?? 0);
$session_name = exam_session_name($session_id);
$edit = fn(array $h) => ['id' => (int)$h['id'], 'name' => $h['type_name'], 'charge' => $h['charge'], 'who' => $h['who_pays'], 'slip' => (int)$h['slip'], 'acc' => (int)$h['account_id'],
    'usual' => fee_paise($h['default_amount']) ? fee_rupees(fee_paise($h['default_amount'])) : '', 'disc' => (int)$h['discountable'], 'on' => (int)$h['is_active'], 'order' => (int)$h['sort_order'],
    'amounts' => array_map('fee_rupees', $by_head[(int)$h['id']] ?? []), 'due' => $due_of[(int)$h['id']] ?? '', 'used' => fee_head_used((int)$h['id'])];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fee Settings</title>
<?php exam_styles('fee'); ?>
<style>
    .card-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
    .card-head h2 { margin: 0; }
    .card-head .acts { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    .ex-table tr.off td { color: #98a6b5; }
    .ex-table td.amt { font-variant-numeric: tabular-nums; }
    .modal .box { width: min(600px, 94vw); }
    .modal .box h3 { margin: 0 0 4px; color: var(--ex-dark); font-size: 16px; }
    .radio-row { display: flex; gap: 6px 16px; flex-wrap: wrap; font-size: 13.5px; margin-top: 4px; }
    .radio-row label { display: flex; align-items: center; gap: 6px; margin: 0; text-transform: none; font-weight: 600; font-size: 13.5px; color: #1f2d3a; }
    .radio-row input { width: auto; height: auto; }
    .cls-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(92px, 1fr)); gap: 8px; margin-top: 8px; }
    .cls-grid label { margin: 0 0 3px; }
    .cls-grid input { text-align: right; }
    .pf input.bad { border-color: #d32f2f; background: #fff2f2; }
    .pf .chk { text-transform: none; font-weight: 600; color: #1f2d3a; }
    .hint { font-size: 12px; color: #6b7d90; margin: 4px 0 0 26px; }
    details.more { margin-top: 12px; border-top: 1px dashed #d5dde5; padding-top: 8px; }
    details.more summary { cursor: pointer; font-size: 12.5px; font-weight: 700; color: #3b5168; }
    .books { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; }
    .sample { display: inline-block; margin-top: 6px; background: var(--ex-soft); border: 1px dashed var(--ex-border); border-radius: 8px; padding: 3px 10px; font-weight: 700; color: var(--ex-dark); font-size: 13px; }
    .show-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 12px; margin-top: 6px; }
    .show-grid fieldset { border: 1px solid #dfe7ef; border-radius: 10px; padding: 8px 12px 10px; margin: 0; }
    .show-grid legend { font-size: 11.5px; font-weight: 700; color: var(--ex-dark); text-transform: uppercase; padding: 0 4px; }
    .show-grid .chk { margin-top: 6px; }
    @media (max-width: 640px) { .pf .row { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Fee Settings', 'What the school collects, and what the slip shows', 'fa-sliders-h',
        ['collect_fee.php' => '<i class="fas fa-cash-register"></i> Collect', 'fee_receipts.php' => '<i class="fas fa-receipt"></i> Receipts']); ?>
    <?php fee_tabs('fee_settings.php'); exam_flash(); ?>

    <div class="card">
        <div class="card-head">
            <form method="get" class="pick"><div><label>Amounts of session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div></form>
            <div class="acts">
                <?php if ($prev_has): ?>
                <form method="post" onsubmit="return confirm(<?php echo h(json_encode('Copy the amounts of ' . exam_session_name($prev_session) . ' into ' . $session_name . '?')); ?>)">
                    <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
                    <button type="submit" name="act" value="copy_amounts" class="btn btn-secondary btn-sm"><i class="fas fa-copy"></i> Copy amounts from <?php echo h(exam_session_name($prev_session)); ?></button>
                </form>
                <?php endif; ?>
                <button type="button" class="btn btn-success btn-sm" onclick="feeOpen(null)"><i class="fas fa-plus"></i> Add fee</button>
            </div>
        </div>
        <?php if (!$heads): ?>
        <div class="ex-empty"><i class="fas fa-tags"></i>No fee yet — add the first one.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Fee</th><th>Amount, <?php echo h($session_name); ?></th><th>Who pays</th><th>Slip</th><th>Money goes to</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($heads as $id => $hd): $any = $hd['charge'] === 'any'; $sum = $any ? '' : fee_amount_summary($by_head[$id] ?? [], $classes); ?>
            <tr class="<?php echo $hd['is_active'] ? '' : 'off'; ?>">
                <td><b><?php echo h($hd['type_name']); ?></b></td>
                <td class="amt"><?php echo $any ? 'Any amount' . (fee_paise($hd['default_amount']) ? ' · usually ' . h(fee_money($hd['default_amount'])) : '') : ($sum !== '' ? h($sum) : '<span class="note" style="margin:0">not set</span>'); ?></td>
                <td><?php echo $any ? 'When needed' : h(FEE_WHO_PAYS[$hd['who_pays']] ?? ''); ?></td>
                <td><?php echo $hd['slip'] ? 'Yes' : '<span class="chip warn">No</span>'; ?></td>
                <td><?php echo isset($accounts[(int)$hd['account_id']]) ? h($accounts[(int)$hd['account_id']]['name']) : ($default_acc ? h($default_acc['name']) . ' <span class="chip off">default</span>' : '—'); ?></td>
                <td><?php echo $hd['is_active'] ? '<span class="chip ok">On</span>' : '<span class="chip off">Off</span>'; ?></td>
                <td style="white-space:nowrap">
                    <button type="button" class="btn btn-warning btn-sm" title="Edit" onclick="feeOpen(<?php echo h(json_encode($edit($hd))); ?>)"><i class="fas fa-edit"></i></button>
                    <?php if (empty($billed[$id])): ?>
                    <form method="post" style="display:inline" onsubmit="return confirm(<?php echo h(json_encode('Delete ' . $hd['type_name'] . ' and its class amounts?')); ?>)"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="id" value="<?php echo (int)$id; ?>"><button type="submit" name="act" value="delete_fee" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button></form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">A fee already on bills cannot be deleted — switch it off; its old bills stay as they are. A changed amount counts from the next collection.</p>
        <?php endif; ?>
    </div>

    <form method="post" class="card pf" id="slip" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="act" value="save_slip">
        <div class="card-head">
            <h2><i class="fas fa-receipt"></i> Slip</h2>
            <div class="acts"><?php if ($last_receipt): ?><a class="btn btn-secondary btn-sm" target="_blank" href="<?php echo h('fee_receipt.php?id=' . $last_receipt); ?>"><i class="fas fa-eye"></i> See it on the last receipt</a><?php endif; ?></div>
        </div>
        <div class="books">
            <div><label>Book with slip — prefix</label><input type="text" name="receipt_prefix" class="prefix" maxlength="10" value="<?php echo h($settings['receipt_prefix']); ?>" required><span class="sample"></span></div>
            <div><label>Book without slip (cash) — prefix</label><input type="text" name="cash_prefix" class="prefix" maxlength="10" value="<?php echo h($settings['cash_prefix']); ?>" required><span class="sample"></span></div>
            <div><label>Slip title</label><input type="text" name="slip_title" maxlength="60" value="<?php echo h($settings['slip_title']); ?>" required></div>
        </div>
        <label>Copies on one A4 page</label>
        <div class="radio-row">
            <label><input type="radio" name="receipt_copies" value="2" <?php echo (int)$settings['receipt_copies'] !== 1 ? 'checked' : ''; ?>> Two — Student copy and Office copy</label>
            <label><input type="radio" name="receipt_copies" value="1" <?php echo (int)$settings['receipt_copies'] === 1 ? 'checked' : ''; ?>> One</label>
        </div>
        <label>Receipt note</label>
        <input type="text" name="receipt_note" maxlength="255" value="<?php echo h($settings['receipt_note'] ?? ''); ?>" placeholder="Fees once paid are not refunded.">
        <label>What the slip shows</label>
        <div class="show-grid">
            <?php foreach (FEE_SLIP_FIELDS as $group => $fields): ?>
            <fieldset><legend><?php echo h($group); ?></legend>
                <?php foreach ($fields as $k => [$label]): ?><label class="chk"><input type="checkbox" name="show[<?php echo h($k); ?>]" value="1" <?php echo $show[$k] ? 'checked' : ''; ?>> <?php echo h($label); ?></label><?php endforeach; ?>
            </fieldset>
            <?php endforeach; ?>
        </div>
        <p class="note">Always on the slip: the receipt number, date, the student's name, what was paid and the total — and CANCELLED across a cancelled receipt.</p>
        <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save slip options</button></div>
    </form>

    <div class="modal" id="feeModal">
        <form class="box pf" method="post" id="feeForm" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="act" value="save_fee"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="id" id="fId"><input type="hidden" name="amounts" id="fAmounts">
            <h3 id="fTitle">Add fee</h3>
            <label>Name</label><input type="text" name="type_name" id="fName" maxlength="100" required>
            <label>How it is charged</label>
            <div class="radio-row" id="fCharge"><?php foreach (FEE_CHARGES as $k => $label): ?><label><input type="radio" name="charge" value="<?php echo h($k); ?>"> <?php echo h($label); ?></label><?php endforeach; ?></div>
            <div id="fSession">
                <label>Amount, session <?php echo h($session_name); ?></label>
                <div class="radio-row"><label><input type="radio" name="amode" value="same"> Same for every class</label><label><input type="radio" name="amode" value="class"> Different by class</label></div>
                <div id="fSameBox" style="margin-top:8px"><input type="text" id="fSame" inputmode="decimal" placeholder="0.00" style="max-width:160px"></div>
                <div class="cls-grid" id="fGrid"><?php foreach ($classes as $cid => $c): ?><div><label><?php echo h($c['name']); ?></label><input type="text" inputmode="decimal" data-class="<?php echo (int)$cid; ?>" placeholder="0"></div><?php endforeach; ?></div>
                <div class="row"><div><label>Who pays</label><select name="who_pays" id="fWho"><?php echo exam_options(FEE_WHO_PAYS, 'everyone'); ?></select></div><div><label>Last date <small style="text-transform:none;font-weight:400">optional</small></label><input type="date" name="due_date" id="fDue"></div></div>
            </div>
            <div id="fAnyBox"><label>Usual amount <small style="text-transform:none;font-weight:400">optional — written in when collecting</small></label><input type="text" name="usual_amount" id="fUsual" inputmode="decimal" placeholder="0.00" style="max-width:160px"></div>
            <label>Money goes to</label>
            <select name="account_id" id="fAcc"><option value="0"><?php echo h($default_acc ? 'Default — ' . $default_acc['name'] : 'Default account'); ?></option><?php foreach ($accounts as $aid => $a): ?><option value="<?php echo (int)$aid; ?>"><?php echo h($a['name']); ?></option><?php endforeach; ?></select>
            <label class="chk"><input type="checkbox" name="slip" id="fSlip" value="1"> Give a slip when collected</label>
            <div class="hint">Without a slip the money still gets a number in the cash book (<?php echo h(fee_book_prefix('cash')); ?>/…) and goes to its account; a slip can be printed later.</div>
            <details class="more"><summary>More</summary>
                <label class="chk"><input type="checkbox" name="discountable" id="fDisc" value="1"> Student discounts apply to this fee</label>
                <div class="row"><div><label>Order</label><input type="number" name="sort_order" id="fOrder" min="0" max="999" value="0"></div><div></div></div>
                <label class="chk"><input type="checkbox" name="is_active" id="fOn" value="1"> On — offered when collecting</label>
            </details>
            <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('feeModal').classList.remove('open')">Cancel</button></div>
        </form>
    </div>
</div>
<script>
(function () {
    var session = <?php echo json_encode($session_name); ?>;
    Array.prototype.forEach.call(document.querySelectorAll('input.prefix'), function (p) {
        var s = p.nextElementSibling;
        var show = function () { var v = p.value.trim().toUpperCase(); s.textContent = (v || '?') + '/' + session + '/00001'; };
        p.addEventListener('input', show); show();
    });

    var f = function (id) { return document.getElementById(id); };
    var form = f('feeForm'), grid = Array.prototype.slice.call(f('fGrid').querySelectorAll('input'));
    var ok = function (v) { v = v.trim().replace(/,/g, ''); return v === '' || /^\d{1,7}(\.\d{1,2})?$/.test(v); };
    var pick = function (name, v) { Array.prototype.forEach.call(form.querySelectorAll('input[name=' + name + ']'), function (r) { r.checked = r.value === v; }); };
    var val = function (name) { var r = form.querySelector('input[name=' + name + ']:checked'); return r ? r.value : ''; };
    function lay() {
        var any = val('charge') === 'any', byClass = val('amode') === 'class';
        f('fSession').style.display = any ? 'none' : '';
        f('fAnyBox').style.display = any ? '' : 'none';
        f('fSameBox').style.display = byClass ? 'none' : '';
        f('fGrid').style.display = byClass ? '' : 'none';
    }
    window.feeOpen = function (h) {
        f('fTitle').textContent = h ? 'Edit ' + h.name : 'Add fee';
        f('fId').value = h ? h.id : '';
        f('fName').value = h ? h.name : '';
        pick('charge', h ? h.charge : 'session');
        Array.prototype.forEach.call(form.querySelectorAll('input[name=charge]'), function (r) { r.disabled = !!(h && h.used && r.value !== h.charge); });
        var amounts = h ? h.amounts : {}, values = grid.map(function (i) { return amounts[i.dataset.class] || ''; });
        var same = values.every(function (v) { return v === values[0]; });
        pick('amode', same ? 'same' : 'class');
        f('fSame').value = same ? values[0] : '';
        grid.forEach(function (i, n) { i.value = values[n]; i.classList.remove('bad'); });
        f('fWho').value = h ? h.who : 'everyone';
        f('fDue').value = h ? h.due : '';
        f('fUsual').value = h ? h.usual : '';
        f('fAcc').value = h && h.acc ? h.acc : '0';
        f('fSlip').checked = h ? !!h.slip : true;
        f('fDisc').checked = h ? !!h.disc : true;
        f('fOrder').value = h ? h.order : 0;
        f('fOn').checked = h ? !!h.on : true;
        lay();
        f('feeModal').classList.add('open');
        f('fName').focus();
    };
    Array.prototype.forEach.call(form.querySelectorAll('input[name=charge], input[name=amode]'), function (r) {
        r.addEventListener('change', function () {
            if (r.name === 'amode' && r.value === 'class' && f('fSame').value.trim() !== '') grid.forEach(function (i) { if (i.value.trim() === '') i.value = f('fSame').value.trim(); });
            lay();
        });
    });
    form.addEventListener('submit', function (e) {
        if (val('charge') === 'any') { if (!ok(f('fUsual').value)) { e.preventDefault(); f('fUsual').classList.add('bad'); } return; }
        var byClass = val('amode') === 'class', bad = false, out = {};
        grid.forEach(function (i) {
            var v = byClass ? i.value : f('fSame').value, good = ok(v);
            (byClass ? i : f('fSame')).classList.toggle('bad', !good);
            if (!good) bad = true;
            out[i.dataset.class] = v.trim().replace(/,/g, '');
        });
        if (bad) { e.preventDefault(); return; }
        f('fAmounts').value = JSON.stringify(out);
    });
    f('feeModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
})();
</script>
</body>
</html>

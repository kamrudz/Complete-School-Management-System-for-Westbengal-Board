<?php
require_once '../includes/auth.php';
require_admin_login();
header('Location: fee_settings.php?' . http_build_query(['tab' => 'amounts', 'session_id' => (int)($_GET['session_id'] ?? 0) ?: null]));
exit();

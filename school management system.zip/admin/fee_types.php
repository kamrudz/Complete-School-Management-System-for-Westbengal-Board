<?php
require_once '../includes/auth.php';
require_admin_login();
header('Location: fee_settings.php?tab=heads');
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hprc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Formative Full Marks Settings (HPRC): the full marks of the nine formative parts of every subject of a
 * Primary / Upper Primary class, for one session. They bound Formative Entry (which refuses a subject
 * until it has them) and are printed on the card; formative is never added to any total.
 * "Fill HPRC standard" suggests the card's values — 20 a part in I–V, 30 in VI–VIII, half for
 * Art & Work and Health & Physical Education — in the browser only, to be checked and saved.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$classes = exam_classes('pup');
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? array_key_first($classes));
if (!isset($classes[$class_id])) $class_id = (int)array_key_first($classes);
$qs = "session_id=$session_id&class_id=$class_id";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    verify_csrf_or_die();
    $r = $class_id ? hprc_save_settings($session_id, $class_id, (array)($_POST['s'] ?? []), $admin_id) : ['ok' => false, 'errors' => ['_' => 'No class chosen']];
    if ($r['ok']) {
        $_SESSION['success'] = 'Formative full marks saved for Class ' . $classes[$class_id]['name'] . ' — ' . $r['saved'] . ' subject' . ($r['saved'] === 1 ? '' : 's') . ($r['removed'] ? ', ' . $r['removed'] . ' cleared' : '') . '.';
    } else {
        $names = exam_class_subject_list($session_id, $class_id);
        $_SESSION['error'] = implode('; ', array_map(fn($k, $m) => ($names[$k]['name'] ?? '') !== '' ? $names[$k]['name'] . ': ' . $m : $m, array_keys($r['errors']), $r['errors']));
    }
    header("Location: formative_settings.php?$qs"); exit;
}

$subjects = $class_id ? exam_class_subject_list($session_id, $class_id) : [];
$settings = $class_id ? hprc_formative_settings($session_id, $class_id) : [];
$summary = [];
foreach ($classes as $cid => $c) $summary[$cid] = [count(hprc_formative_settings($session_id, $cid)), count(exam_class_subject_list($session_id, $cid))];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Formative Full Marks Settings</title>
<?php exam_styles(); ?>
<style>
    .ctabs { display: flex; gap: 6px; flex-wrap: wrap; margin: 4px 0 12px; } .ctabs a { padding: 7px 14px; border-radius: 9px; border: 1px solid #d5dde5; background: #fff; color: #3b5168; text-decoration: none; font-weight: 700; font-size: 13px; } .ctabs a.on { background: #3b1d5c; color: #fff; border-color: #3b1d5c; } .ctabs a small { font-weight: 400; font-size: 10.5px; display: block; opacity: .8; }
    .ex-table th.term { text-align: center; border-left: 2px solid var(--ex-border); } .ex-table td.t1 { border-left: 2px solid var(--ex-border); }
    .ex-table input.m { width: 52px; }
    .toolbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; font-size: 12.5px; color: #3b5168; } .toolbar input { width: 60px; height: 30px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Formative Full Marks Settings', 'Full marks of the nine formative parts (F1A–F3C) of each subject, as on the Holistic Progress Report Card — 1st Formative Phase goes with the 1st Summative, 2nd with the 2nd, 3rd with the 3rd.', 'fa-cog',
        ['exams.php?section=pup' => '<i class="fas fa-clipboard-list"></i> Exams', 'exam_subject_marks.php?section=pup' => '<i class="fas fa-sliders-h"></i> Full & Pass Marks']); ?>
    <?php exam_tabs('formative_settings.php', HPRC_PAGES, $qs); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
    </form>

    <?php if (!$classes): ?><div class="card"><div class="ex-empty"><i class="fas fa-school"></i>No Primary or Upper Primary class yet — add one under <a href="classes.php">Classes</a>.</div></div>
    <?php else: ?>
    <div class="ctabs"><?php foreach ($classes as $cid => $c): [$d, $n] = $summary[$cid]; ?><a href="?session_id=<?php echo $session_id; ?>&class_id=<?php echo $cid; ?>" class="<?php echo $cid === $class_id ? 'on' : ''; ?>">Class <?php echo h($c['name']); ?><small><?php echo $n ? "$d / $n set" : 'no subjects'; ?></small></a><?php endforeach; ?></div>

    <div class="card">
        <h2><i class="fas fa-cog"></i> Class <?php echo h($classes[$class_id]['name']); ?> · <?php echo h(exam_session_name($session_id)); ?> <small>whole numbers 0–<?php echo HPRC_PART_MAX; ?> · blank part = not used · all blank = no formative for that subject</small></h2>
        <?php if (!$subjects): ?><div class="ex-empty"><i class="fas fa-book"></i>Class <?php echo h($classes[$class_id]['name']); ?> has no exam subjects for this session — assign them under <a href="class_subjects.php">Class Subjects</a> (tick "exam").</div>
        <?php else: ?>
        <form method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
            <div class="toolbar noprint">Fill every part with <input type="text" id="fillv" inputmode="numeric" placeholder="10"> <button type="button" class="btn btn-secondary btn-sm" onclick="fillAll(false)">Blank ones only</button> <button type="button" class="btn btn-secondary btn-sm" onclick="fillAll(true)">All</button>
                <span style="margin-left:auto"><button type="button" class="btn btn-primary btn-sm" onclick="fillStandard()" title="20 a part in Classes I–V, 30 in VI–VIII; half for Art &amp; Work and Health &amp; Physical Education. Fills blank parts only — check, then Save."><i class="fas fa-magic"></i> Fill HPRC standard</button></span></div>
            <div style="overflow-x:auto">
            <table class="ex-table">
                <thead>
                    <tr><th rowspan="2">Subject</th><?php foreach (HPRC_TERMS as $t): ?><th colspan="3" class="term">F<?php echo $t; ?> <small style="text-transform:none;font-weight:400">· <?php echo ['', '1st', '2nd', '3rd'][$t]; ?> Summative</small></th><?php endforeach; ?></tr>
                    <tr><?php foreach (HPRC_TERMS as $t) foreach (HPRC_PARTS as $i => $p): ?><th class="num <?php echo $i === 0 ? 'term' : ''; ?>"><?php echo strtoupper("f$t$p"); ?></th><?php endforeach; ?></tr>
                </thead>
                <tbody>
                <?php foreach ($subjects as $sid => $s): $set = $settings[$sid] ?? null; ?>
                    <tr data-sid="<?php echo $sid; ?>" data-std="<?php echo hprc_standard_part_full($classes[$class_id]['name'], $s['name']); ?>">
                        <td><b><?php echo h($s['name']); ?></b><?php if (!$set): ?> <span class="chip off">not set</span><?php endif; ?></td>
                        <?php foreach (hprc_part_keys() as $i => $k): ?>
                            <td class="num <?php echo $i % 3 === 0 ? 't1' : ''; ?>"><input class="m" name="s[<?php echo $sid; ?>][<?php echo $k; ?>]" value="<?php echo $set ? exam_fmt($set[$k]) : ''; ?>" inputmode="numeric" maxlength="3"></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <div style="margin-top:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button type="submit" name="save_settings" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save Class <?php echo h($classes[$class_id]['name']); ?></button>
                <span class="note" style="margin:0">A part cannot be set lower than marks already entered for it. Formative is shown on the report card only — never added to a total, grade, result or merit.</span></div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
var inputs = document.querySelectorAll('input.m');
// a part takes a whole number 0–<?php echo HPRC_PART_MAX; ?>, or stays blank (not used)
function check(i) {
    var v = i.value.trim();
    i.classList.toggle('bad', v !== '' && !(/^\d{1,3}$/.test(v) && +v <= <?php echo HPRC_PART_MAX; ?>));
}
inputs.forEach(function (i) { check(i); i.addEventListener('input', function () { check(i); }); });
function fillAll(all) {
    var v = document.getElementById('fillv').value.trim(); if (v === '') return;
    inputs.forEach(function (i) { if (all || i.value.trim() === '') i.value = v; check(i); });
}
// the card's full marks, into blank parts only — nothing is saved until Save
function fillStandard() {
    inputs.forEach(function (i) { if (i.value.trim() === '') i.value = i.closest('tr').dataset.std; check(i); });
}
// Enter moves down the same column
inputs.forEach(function (i) { i.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return; e.preventDefault();
    var td = i.closest('td'), idx = Array.prototype.indexOf.call(td.parentNode.children, td), tr = td.parentNode.nextElementSibling;
    if (tr) { var n = tr.children[idx].querySelector('input'); if (n) { n.focus(); n.select(); } }
}); });
</script>
</body>
</html>

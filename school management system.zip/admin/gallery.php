<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/** The school's photographs, newest first. The title can be corrected here without uploading again. */
$per = (int)($_GET['per'] ?? 24);
if (!in_array($per, [24, 48, 96], true)) $per = 24;
$page = max(1, (int)($_GET['page'] ?? 1));
$search = trim((string)($_GET['search'] ?? ''));
$self = fn(array $extra = []) => 'gallery.php?' . http_build_query(array_merge($_GET, $extra));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rename'])) {
    verify_csrf_or_die();
    $id = (int)($_POST['id'] ?? 0);
    $title = trim((string)($_POST['title'] ?? ''));
    if ($title === '') $_SESSION['error'] = 'Give the photo a title.';
    elseif (!db_get_row('SELECT id FROM gallery WHERE id = ?', 'i', $id)) $_SESSION['error'] = 'That photo is gone — look at the list again.';
    else {
        db_execute('UPDATE gallery SET title = ? WHERE id = ?', 'si', mb_substr($title, 0, 200), $id);
        $_SESSION['success'] = 'The title is saved.';
    }
    header('Location: ' . $self());
    exit();
}

$where = '1';
$types = '';
$params = [];
if ($search !== '') {
    $where .= ' AND title LIKE ?';
    $types .= 's';
    $params[] = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
}
$total = (int)(db_get_row("SELECT COUNT(*) n FROM gallery WHERE $where", $types, ...$params)['n'] ?? 0);
$all = (int)(db_get_row('SELECT COUNT(*) n FROM gallery')['n'] ?? 0);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$rows = db_get_all("SELECT * FROM gallery WHERE $where ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gallery</title>
<?php exam_styles('web'); ?>
<style>
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 14px; }
    .ph { border: 1px solid #e3e9f0; border-radius: 12px; overflow: hidden; background: #fff; display: flex; flex-direction: column; }
    .ph img { width: 100%; height: 150px; object-fit: cover; display: block; background: #f1f5f8; }
    .ph .body { padding: 9px 11px; display: flex; flex-direction: column; gap: 7px; flex: 1; }
    .ph input[type=text] { width: 100%; height: 32px; padding: 4px 8px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 13px; }
    .ph .row { display: flex; gap: 6px; align-items: center; }
    .ph .when { font-size: 11px; color: #93a2b2; }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 14px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Gallery', 'The photographs the school shows on its website', 'fa-images',
        ['add_gallery.php' => '<i class="fas fa-plus"></i> Add photos', '../index.php#gallery' => '<i class="fas fa-external-link-alt"></i> See them on the site']); ?>
    <?php exam_tabs('gallery.php', WEB_PAGES); exam_flash(); ?>

    <form method="get" class="card pick">
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Photo title" style="min-width:230px"></div>
        <div><label>Per page</label><select name="per"><?php echo exam_options([24 => 24, 48 => 48, 96 => 96], $per); ?></select></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
        <div><a href="gallery.php" class="btn btn-secondary">Reset</a></div>
    </form>

    <div class="card">
        <h2><i class="fas fa-images"></i> Photographs <small><?php echo number_format($total); ?><?php echo $search !== '' ? ' of ' . number_format($all) : ''; ?><?php echo $pages > 1 ? ' · page ' . $page . ' of ' . $pages : ''; ?></small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-images"></i><?php echo $all ? 'No photo matches what you asked for.' : 'No photo yet. The website shows this section only when there are some.'; ?></div>
        <?php else: ?>
        <div class="grid">
            <?php foreach ($rows as $r): ?>
            <div class="ph">
                <a href="<?php echo h('../uploads/gallery/' . $r['photo']); ?>" target="_blank">
                    <img src="<?php echo h('../uploads/gallery/' . $r['photo']); ?>" alt="<?php echo h($r['title'] ?? ''); ?>" loading="lazy">
                </a>
                <div class="body">
                    <form method="post" class="row">
                        <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                        <input type="text" name="title" maxlength="200" value="<?php echo h($r['title'] ?? ''); ?>" placeholder="Title">
                        <button type="submit" name="rename" class="btn btn-success btn-sm" title="Save the title"><i class="fas fa-check"></i></button>
                    </form>
                    <div class="row" style="justify-content:space-between;margin-top:auto">
                        <span class="when"><?php echo h(date('d M Y', strtotime($r['created_at']))); ?></span>
                        <form method="post" action="delete_gallery.php" onsubmit="return confirm('Delete this photo? The file goes too.')">
                            <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php if ($pages > 1): ?>
        <div class="pager">
            <span>Page <?php echo $page; ?> of <?php echo $pages; ?></span>
            <?php if ($page > 1): ?><a href="<?php echo h($self(['page' => $page - 1])); ?>"><i class="fas fa-angle-left"></i> Back</a><?php endif; ?>
            <?php for ($p = max(1, $page - 3); $p <= min($pages, $page + 3); $p++): ?>
                <a href="<?php echo h($self(['page' => $p])); ?>" class="<?php echo $p === $page ? 'on' : ''; ?>"><?php echo $p; ?></a>
            <?php endfor; ?>
            <?php if ($page < $pages): ?><a href="<?php echo h($self(['page' => $page + 1])); ?>">Next <i class="fas fa-angle-right"></i></a><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <p class="note">The website shows the 20 newest photographs. A photograph is made smaller when it is uploaded, so the page stays quick.</p>
    </div>
</div>
</body>
</html>

<?php
require_once '../includes/auth.php';
require_admin_login();
header('Location: fee_dues.php?' . http_build_query(['session_id' => (int)($_GET['session_id'] ?? 0) ?: null, 'class_id' => (int)($_GET['class_id'] ?? 0) ?: null]));
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

// <option>s of a class's sections for the dropdowns of many pages. The session defaults to the active one.
// A leading placeholder option comes first unless ?no_placeholder=1 (its text from ?placeholder=).
$class_id = (int)($_GET['class_id'] ?? 0);
$session_id = (int)($_GET['session_id'] ?? 0) ?: (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
if (($_GET['no_placeholder'] ?? '') !== '1') {
    $placeholder = trim((string)($_GET['placeholder'] ?? '')) ?: 'Select Section';
    echo '<option value="">' . htmlspecialchars($placeholder, ENT_QUOTES, 'UTF-8') . '</option>';
}
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id) : [];
if (!$sections) echo '<option value="">No sections found</option>';
foreach ($sections as $s) echo '<option value="' . (int)$s['id'] . '">' . htmlspecialchars($s['section_name'], ENT_QUOTES, 'UTF-8') . '</option>';

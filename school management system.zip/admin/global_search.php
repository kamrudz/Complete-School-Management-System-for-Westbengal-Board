<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');


include("../includes/db.php");
require_once '../includes/student_helper.php';

$q = trim($_GET['q'] ?? '');
if(mb_strlen($q) < 2) {
    echo json_encode(['results' => []]);
    exit();
}
$limit = 6;
// Escape LIKE wildcard characters so % and _ typed by the user are treated literally
$like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
$groups = [];

/**
 * Run a prepared LIKE-search query.
 * $sql must contain one '?' placeholder per LIKE column (all bound to $like) plus a trailing ? for LIMIT.
 * $like_count = how many '?' placeholders are for the search term (before the LIMIT one).
 */
function search_query($conn, $sql, $like, $like_count, $limit) {
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log("global_search prepare error: " . mysqli_error($conn));
        return [];
    }
    $types = str_repeat('s', $like_count) . 'i';
    $params = array_fill(0, $like_count, $like);
    $params[] = $limit;
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    mysqli_stmt_close($stmt);
    return $rows;
}

// ===== Students =====
$students = [];
$rows = search_query($conn, "
    SELECT s.id, s.student_name, s.admission_no, h.roll_no, c.class_name, sec.section_name
    FROM students s
    LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    WHERE s.student_name LIKE ? ESCAPE '\\\\' OR s.id LIKE ? ESCAPE '\\\\' OR s.admission_no LIKE ? ESCAPE '\\\\'
          OR s.banglarshiksha_id LIKE ? ESCAPE '\\\\' OR s.pen_id LIKE ? ESCAPE '\\\\' OR s.mobile LIKE ? ESCAPE '\\\\'
    ORDER BY s.student_name ASC
    LIMIT ?
", $like, 6, $limit);
foreach ($rows as $r) {
    $sub = trim(($r['class_name'] ?? '').' '.($r['section_name'] ?? '')).' • Roll: '.($r['roll_no'] ?? '-').' • Adm: '.$r['admission_no'];
    $students[] = ['title' => $r['student_name'], 'subtitle' => $sub, 'url' => student_page_url('view_student.php', $r['id'])];
}
if(!empty($students)) $groups[] = ['category' => 'Student', 'icon' => 'fa-user-graduate', 'items' => $students];

// ===== Staff =====
$staff = [];
$rows = search_query($conn, "
    SELECT id, staff_name, employee_id, designation
    FROM staff
    WHERE staff_name LIKE ? ESCAPE '\\\\' OR employee_id LIKE ? ESCAPE '\\\\' OR designation LIKE ? ESCAPE '\\\\'
    ORDER BY staff_name ASC
    LIMIT ?
", $like, 3, $limit);
foreach ($rows as $r) {
    $sub = ($r['designation'] ?: 'Staff').' • ID: '.($r['employee_id'] ?: '-');
    $staff[] = ['title' => $r['staff_name'], 'subtitle' => $sub, 'url' => 'view_staff.php?id='.$r['id']];
}
if(!empty($staff)) $groups[] = ['category' => 'Staff', 'icon' => 'fa-user-tie', 'items' => $staff];

// ===== Subjects =====
$subjects = [];
$rows = search_query($conn, "
    SELECT id, subject_name, subject_code, subject_type
    FROM subjects
    WHERE subject_name LIKE ? ESCAPE '\\\\' OR subject_code LIKE ? ESCAPE '\\\\'
    ORDER BY subject_name ASC
    LIMIT ?
", $like, 2, $limit);
foreach ($rows as $r) {
    $sub = ($r['subject_code'] ? 'Code: '.$r['subject_code'].' • ' : '').ucfirst($r['subject_type'] ?? '');
    $subjects[] = ['title' => $r['subject_name'], 'subtitle' => $sub, 'url' => 'edit_subject.php?id='.$r['id']];
}
if(!empty($subjects)) $groups[] = ['category' => 'Subject', 'icon' => 'fa-book', 'items' => $subjects];

// ===== Exams (V-X and HS) =====
$exams = [];
$rows = search_query($conn, "
    SELECT e.id, e.exam_name, e.exam_type, ss.session_name
    FROM exams e
    LEFT JOIN academic_sessions ss ON ss.id = e.session_id
    WHERE e.exam_name LIKE ? ESCAPE '\\\\'
    ORDER BY e.id DESC
    LIMIT ?
", $like, 1, $limit);
foreach ($rows as $r) {
    $sub = strtoupper($r['exam_type']).' • '.($r['session_name'] ?? '-');
    $exams[] = ['title' => $r['exam_name'], 'subtitle' => $sub, 'url' => 'exams.php?session_id='.(int)$r['session_id'].'&edit='.$r['id']];
}
if(!empty($exams)) $groups[] = ['category' => 'Exam', 'icon' => 'fa-file-signature', 'items' => $exams];

// ===== Notices =====
$notices = [];
$rows = search_query($conn, "
    SELECT id, notice_title, publish_date
    FROM notices
    WHERE notice_title LIKE ? ESCAPE '\\\\'
    ORDER BY id DESC
    LIMIT ?
", $like, 1, $limit);
foreach ($rows as $r) {
    $sub = $r['publish_date'] ? date('d-m-Y', strtotime($r['publish_date'])) : '-';
    $notices[] = ['title' => $r['notice_title'], 'subtitle' => $sub, 'url' => 'edit_notice.php?id='.$r['id']];
}
if(!empty($notices)) $groups[] = ['category' => 'Notice', 'icon' => 'fa-bullhorn', 'items' => $notices];

echo json_encode(['results' => $groups]);

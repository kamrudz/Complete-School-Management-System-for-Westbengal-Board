<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * The holiday list — one calendar year at a time, because that is how the list is published and because
 * totals of several years together mean nothing. This list is also what tells attendance which days are
 * not working days, so a day entered twice is pointed out rather than left to be counted twice.
 */
$year = (int)($_GET['year'] ?? 0);
$years = holiday_years();
if (!isset($years[$year])) $year = (int)date('Y');
$self = fn(array $extra = []) => 'holidays.php?' . http_build_query(array_merge(['year' => $year], $extra));

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $row = db_get_row('SELECT holiday_name FROM holidays WHERE id = ?', 'i', $id);
    if (!$row) $_SESSION['error'] = 'That holiday is gone — look at the list again.';
    else {
        db_execute('DELETE FROM holidays WHERE id = ?', 'i', $id);
        $_SESSION['success'] = $row['holiday_name'] . ' is off the list. Attendance counts those days as working days again.';
    }
    header('Location: ' . $self());
    exit();
}

$rows = holidays_of_year($year);
[$y_from, $y_to] = holiday_year_range($year);

/** Which rows cover a day another row already covers — the same day must not be entered twice. */
$clash = [];
foreach ($rows as $a) {
    [$af, $at] = holiday_span($a);
    if (!$af || !$at) continue;
    foreach ($rows as $b) {
        if ((int)$a['id'] === (int)$b['id']) continue;
        [$bf, $bt] = holiday_span($b);
        if ($bf && $bt && $af <= $bt && $bf <= $at) { $clash[(int)$a['id']][] = $b['holiday_name']; break; }
    }
}

$days = [];
$by_type = array_fill_keys(array_keys(HOLIDAY_TYPES), 0);
$no_date = 0;
foreach ($rows as $r) {
    [$from, $to] = holiday_span($r);
    if (!$from || !$to) { $no_date++; continue; }
    for ($d = new DateTime($from); $d <= new DateTime($to); $d->modify('+1 day')) {
        $k = $d->format('Y-m-d');
        if ($k < $y_from || $k > $y_to) continue;
        if ((int)$d->format('N') === 7) continue;   // a Sunday was never a working day
        $days[$k] = true;
    }
    $by_type[$r['holiday_type']] = ($by_type[$r['holiday_type']] ?? 0) + 1;
}
$working_lost = count($days);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Holidays</title>
<?php exam_styles('web'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb div { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; }
    .sb b { display: block; font-size: 21px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .acts { display: flex; gap: 5px; }
    .acts form { display: inline; }
    .when { font-weight: 600; color: var(--ex-dark); }
    .uid { color: #93a2b2; font-size: 11.5px; }
    .print-head { display: none; }
    @media print {
        .print-head { display: block; }
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .pick, .sb, .noprint { display: none !important; }
        .card { border: 0; padding: 0; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Holidays', 'The days the school is closed — and the days attendance is never taken', 'fa-umbrella-beach',
        ['add_holiday.php' => '<i class="fas fa-plus"></i> Add a holiday', $self(['print' => 1]) => '<i class="fas fa-print"></i> Print the list']); ?>
    <?php exam_tabs('holidays.php', WEB_PAGES); exam_flash(); ?>

    <form method="get" class="card pick noprint">
        <div><label>Year</label><select name="year" onchange="this.form.submit()"><?php echo exam_options($years, $year); ?></select></div>
        <div class="note" style="margin:0 0 0 6px;align-self:center">January to December. A vacation crossing new year shows in both years.</div>
        <div style="margin-left:auto"><a href="<?php echo h('print_holidays.php?year=' . $year); ?>" target="_blank" class="btn btn-info"><i class="fas fa-print"></i> Printable list</a></div>
    </form>

    <div class="print-head"><?php exam_school_header('HOLIDAY LIST ' . $year); ?></div>

    <div class="sb">
        <div><b><?php echo count($rows); ?></b><span>Entries in <?php echo $year; ?></span></div>
        <div><b><?php echo $working_lost; ?></b><span>Working days lost</span></div>
        <?php foreach (HOLIDAY_TYPES as $k => [$label]): if (!($by_type[$k] ?? 0)) continue; ?>
            <div><b><?php echo (int)$by_type[$k]; ?></b><span><?php echo h($label); ?></span></div>
        <?php endforeach; ?>
    </div>

    <?php if ($clash): ?>
    <div class="ex-guard noprint"><i class="fas fa-triangle-exclamation big"></i><div><b><?php echo count($clash); ?> entry(ies) cover a day another one already covers</b>
        The holiday list decides which days attendance is taken on, so a day listed twice is only confusing. They are marked below — remove one of each pair.</div></div>
    <?php endif; ?>

    <div class="card">
        <h2><i class="fas fa-calendar-days"></i> Holidays of <?php echo $year; ?> <small><?php echo count($rows); ?> entry(ies)</small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-calendar-days"></i>No holiday listed for <?php echo $year; ?>. Until one is added, every day except Sunday counts as a working day.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th style="width:44px">#</th><th>Holiday</th><th>When</th><th>Day</th><th>Kind</th><th class="num">Days</th><th class="num">Working days</th><th class="noprint"></th></tr></thead>
            <tbody>
            <?php $i = 1; foreach ($rows as $r): [$from, $to] = holiday_span($r); [$label, $icon, $chip] = HOLIDAY_TYPES[$r['holiday_type']] ?? ['Holiday', 'fa-calendar', 'off']; ?>
                <tr>
                    <td class="num"><?php echo $i++; ?></td>
                    <td>
                        <b><?php echo h($r['holiday_name']); ?></b>
                        <?php if (!empty($r['is_long_vacation'])): ?><span class="chip warn">Vacation</span><?php endif; ?>
                        <?php if (isset($clash[(int)$r['id']])): ?><span class="chip bad" title="<?php echo h(implode(', ', $clash[(int)$r['id']])); ?>">same days as <?php echo h($clash[(int)$r['id']][0]); ?></span><?php endif; ?>
                        <?php if (!empty($r['description'])): ?><div class="uid"><?php echo h(mb_substr($r['description'], 0, 90)); ?></div><?php endif; ?>
                    </td>
                    <td class="when"><?php echo $from ? h(date('d M Y', strtotime($from)) . ($to !== $from ? ' – ' . date('d M Y', strtotime($to)) : '')) : '<span class="chip bad">no date</span>'; ?></td>
                    <td><?php echo $from ? h(date('l', strtotime($from))) : '—'; ?></td>
                    <td><span class="chip <?php echo h($chip); ?>"><i class="fas <?php echo h($icon); ?>"></i> <?php echo h($label); ?></span></td>
                    <td class="num"><?php echo $from && $to ? (int)((new DateTime($from))->diff(new DateTime($to))->days) + 1 : 0; ?></td>
                    <td class="num"><b><?php echo holiday_working_days($r); ?></b></td>
                    <td class="noprint">
                        <div class="acts">
                            <a href="<?php echo h('edit_holiday.php?id=' . (int)$r['id']); ?>" class="btn btn-warning btn-sm" title="Change it"><i class="fas fa-edit"></i></a>
                            <form method="post" onsubmit="return confirm('Take <?php echo h(addslashes($r['holiday_name'])); ?> off the list? Those days become working days again.')">
                                <?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" title="Remove"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
        <p class="note">"Working days" leaves out the Sundays inside a holiday, because a Sunday was never a working day — that is the number attendance actually loses.<?php echo $no_date ? ' ' . $no_date . ' entry(ies) have no date at all and count for nothing; correct them.' : ''; ?></p>
    </div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/student_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Houses: the school divides its students into houses for competitions and activities. This has nothing to do with
 * admission — a student gets a house here, keeps it year after year, and only this page gives or changes one.
 * Distribution shares the students of a class evenly, class by class, section by section, boys and girls alike,
 * and never moves anyone who already has a house.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$in = fn(string $k, $d = '') => $_POST[$k] ?? $_GET[$k] ?? $d;
$session_id = (int)$in('session_id', 0);
if (!isset($sessions[$session_id])) $session_id = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0) ?: (int)array_key_first($sessions);
$classes = class_rows();
$class_id = (int)$in('class_id', 0);
if (!isset($classes[$class_id])) $class_id = 0;
$view = $in('view') === 'list' ? 'list' : 'houses';
$house_f = (int)$in('house', 0);
$q = array_filter(['view' => $view !== 'houses' ? $view : null, 'session_id' => $session_id, 'class_id' => $class_id ?: null, 'house' => $house_f ?: null]);
$self = fn(array $over = []) => 'houses.php?' . http_build_query(array_filter(array_merge($q, $over), fn($v) => $v !== null));
$go = function (string $kind = '', string $msg = '', ?string $url = null) use ($self) {
    if ($kind !== '') $_SESSION[$kind] = $msg;
    header('Location: ' . ($url ?? $self()));
    exit();
};

function houses_all(bool $active_only = false): array {
    $out = [];
    foreach (db_get_all('SELECT h.*, s.staff_name FROM houses h LEFT JOIN staff s ON s.id = h.teacher_id' . ($active_only ? ' WHERE h.is_active = 1' : '') . ' ORDER BY h.sort_order, h.name') as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/**
 * Who would go to which house: the students of the chosen classes who have none yet, in class, section, girls-and-boys
 * and roll order, dealt round and round the houses — so every house gets about the same number from each group. The
 * count a house already holds in that class starts it off, so a second run keeps the balance. uid => house id.
 */
function houses_share(int $session_id, array $class_ids, array $houses): array {
    if (!$houses || !$class_ids) return [];
    $rows = db_get_all("SELECT s.id AS uid, s.gender, s.house_id, h.class_id, h.section_id, h.roll_no
        FROM student_academic_history h JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE h.session_id = ? AND h.academic_status = 'Current' AND h.class_id IN (" . implode(',', array_fill(0, count($class_ids), '?')) . ")
        ORDER BY h.class_id, sec.section_name, s.gender, CAST(h.roll_no AS UNSIGNED), s.id",
        'i' . str_repeat('i', count($class_ids)), $session_id, ...$class_ids);
    $ids = array_keys($houses);
    $held = [];      // class => house => how many are already there, so a later run carries on from the same place
    foreach ($rows as $r) if ($r['house_id']) $held[(int)$r['class_id']][(int)$r['house_id']] = ($held[(int)$r['class_id']][(int)$r['house_id']] ?? 0) + 1;
    $turn = [];
    $out = [];
    foreach ($rows as $r) {
        if ($r['house_id']) continue;
        $cid = (int)$r['class_id'];
        if (!isset($turn[$cid])) {
            // start with the house that holds the fewest in this class
            $counts = [];
            foreach ($ids as $hid) $counts[$hid] = $held[$cid][$hid] ?? 0;
            asort($counts);
            $turn[$cid] = ['order' => array_keys($counts), 'at' => 0];
        }
        $pick = $turn[$cid]['order'][$turn[$cid]['at'] % count($ids)];
        $turn[$cid]['at']++;
        $out[(string)$r['uid']] = $pick;
    }
    return $out;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    try {
        if ($act === 'save_house') {
            $id = (int)($_POST['id'] ?? 0);
            $old = $id ? db_get_row('SELECT * FROM houses WHERE id = ?', 'i', $id) : null;
            if ($id && !$old) throw new RuntimeException('That house is gone — reload the page.');
            $name = trim((string)($_POST['name'] ?? ''));
            if ($name === '' || mb_strlen($name) > 50) throw new RuntimeException('Give the house a name (up to 50 letters).');
            $colour = strtolower(trim((string)($_POST['colour'] ?? '')));
            if (!preg_match('/^#[0-9a-f]{6}$/', $colour)) throw new RuntimeException('Choose a colour for the house.');
            $teacher = (int)($_POST['teacher_id'] ?? 0);
            if ($teacher && !db_get_row('SELECT id FROM staff WHERE id = ?', 'i', $teacher)) throw new RuntimeException('Choose a teacher from the list.');
            $data = ['name' => $name, 'colour' => $colour, 'teacher_id' => $teacher ?: null, 'motto' => mb_substr(trim((string)($_POST['motto'] ?? '')), 0, 100) ?: null,
                'sort_order' => max(0, min(999, (int)($_POST['sort_order'] ?? 0))), 'is_active' => !empty($_POST['is_active']) ? 1 : 0];
            try {
                if ($old) db_update('houses', $data, ['id' => $id], 'i');
                elseif (!($id = (int)db_insert('houses', $data))) throw new RuntimeException('The house could not be saved.');
            } catch (mysqli_sql_exception $e) {
                throw new RuntimeException((int)$e->getCode() === 1062 ? "A house called $name is already there." : 'Could not save: ' . $e->getMessage());
            }
            log_action($admin_id, $old ? 'HOUSE_UPDATED' : 'HOUSE_ADDED', 'houses', $id, $old, $data);
            $go('success', "$name saved.");
        }
        if ($act === 'delete_house') {
            $h = db_get_row('SELECT * FROM houses WHERE id = ?', 'i', (int)($_POST['id'] ?? 0));
            if (!$h) throw new RuntimeException('That house is gone — reload the page.');
            $n = (int)db_get_row('SELECT COUNT(*) n FROM students WHERE house_id = ?', 'i', (int)$h['id'])['n'];
            if ($n > 0) throw new RuntimeException("{$h['name']} has $n student(s) — move them first, or switch the house off.");
            db_execute('DELETE FROM houses WHERE id = ?', 'i', (int)$h['id']);
            log_action($admin_id, 'HOUSE_DELETED', 'houses', (int)$h['id'], $h, null);
            $go('success', "{$h['name']} deleted.");
        }
        if ($act === 'share') {
            $houses = houses_all(true);
            if (!$houses) throw new RuntimeException('Make the houses first, then share the students out.');
            $ids = $class_id ? [$class_id] : array_keys($classes);
            $plan = houses_share($session_id, $ids, $houses);
            if (!$plan) throw new RuntimeException('Everyone here already has a house.');
            db_begin_transaction();
            try {
                foreach ($plan as $uid => $hid) db_execute('UPDATE students SET house_id = ? WHERE id = ? AND house_id IS NULL', 'is', $hid, (string)$uid);
                db_commit();
            } catch (Throwable $e) {
                db_rollback();
                throw new RuntimeException('Nothing was changed: ' . $e->getMessage());
            }
            log_action($admin_id, 'HOUSES_SHARED', 'students', null, null, ['session' => exam_session_name($session_id), 'class' => $class_id ? $classes[$class_id]['name'] : 'all', 'students' => count($plan)]);
            $go('success', count($plan) . ' student(s) were shared out into houses.');
        }
        if ($act === 'move') {
            $uid = student_uid_clean($_POST['uid'] ?? '');
            $hid = (int)($_POST['house_id'] ?? 0);
            $st = $uid !== '' ? db_get_row('SELECT id, student_name, house_id FROM students WHERE id = ?', 's', $uid) : null;
            if (!$st) throw new RuntimeException('Student not found.');
            if ($hid && !db_get_row('SELECT id FROM houses WHERE id = ?', 'i', $hid)) throw new RuntimeException('Choose a house from the list.');
            db_execute('UPDATE students SET house_id = ? WHERE id = ?', 'is', $hid ?: null, $uid);
            log_action($admin_id, 'HOUSE_CHANGED', 'students', $uid, ['house_id' => $st['house_id']], ['house_id' => $hid ?: null]);
            $go('success', $st['student_name'] . ': house ' . ($hid ? houses_all()[$hid]['name'] : 'taken away') . '.', $self(['view' => 'list']));
        }
    } catch (RuntimeException $e) {
        $go('error', $e->getMessage());
    }
    $go();
}

$houses = houses_all();
$live = array_filter($houses, fn($h) => $h['is_active']);
$teachers = array_column(db_get_all("SELECT id, staff_name FROM staff WHERE staff_name <> '' ORDER BY staff_name"), 'staff_name', 'id');

// how many of each house are in each class this session, and how many still have none
$grid = []; $none = [];
foreach (db_get_all("SELECT h.class_id, s.house_id, COUNT(*) n FROM student_academic_history h JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
    WHERE h.session_id = ? AND h.academic_status = 'Current' GROUP BY h.class_id, s.house_id", 'i', $session_id) as $r) {
    if ($r['house_id']) $grid[(int)$r['class_id']][(int)$r['house_id']] = (int)$r['n'];
    else $none[(int)$r['class_id']] = (int)$r['n'];
}
$waiting = $class_id ? (int)($none[$class_id] ?? 0) : array_sum($none);

$rows = [];
if ($view === 'list') {
    $where = ['h.session_id = ?', "h.academic_status = 'Current'", "s.student_status = 'Active'"]; $types = 'i'; $params = [$session_id];
    if ($class_id) { $where[] = 'h.class_id = ?'; $types .= 'i'; $params[] = $class_id; }
    if ($house_f > 0) { $where[] = 's.house_id = ?'; $types .= 'i'; $params[] = $house_f; }
    elseif ($house_f === -1) $where[] = 's.house_id IS NULL';
    $rows = db_get_all("SELECT s.id AS uid, s.student_name, s.gender, s.house_id, c.class_name, sec.section_name, h.roll_no
        FROM student_academic_history h JOIN students s ON s.id = h.student_id
        LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE " . implode(' AND ', $where) . ' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name', $types, ...$params);
    if (!empty($_GET['export'])) {
        $out = exam_xlsx_title('Houses · ' . exam_session_name($session_id) . ($class_id ? ' · Class ' . $classes[$class_id]['name'] : ''));
        $out[] = ['School UID', 'Student', 'Class', 'Section', 'Roll', 'Gender', 'House'];
        foreach ($rows as $r) $out[] = [$r['uid'], $r['student_name'], (string)$r['class_name'], (string)$r['section_name'], (string)$r['roll_no'], (string)$r['gender'], $houses[(int)$r['house_id']]['name'] ?? ''];
        SimpleXLSXWriter::download('Houses_' . exam_session_name($session_id) . '.xlsx', $out, 'Houses', exam_xlsx_opts(7, 24));
        exit();
    }
}
$session_name = exam_session_name($session_id);
$would = $live ? count(houses_share($session_id, $class_id ? [$class_id] : array_keys($classes), $live)) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Houses</title>
<?php exam_styles('vx'); ?>
<style>
    .seg { display: inline-flex; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 12px; }
    .seg a { padding: 7px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; } .seg a i { margin-right: 6px; }
    .card-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
    .card-head h2 { margin: 0; } .card-head .acts { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    .dot { display: inline-block; width: 13px; height: 13px; border-radius: 50%; vertical-align: -1px; margin-right: 7px; border: 1px solid rgba(0,0,0,.15); }
    .ex-table td.num, .ex-table th.num { text-align: center; font-variant-numeric: tabular-nums; }
    .ex-table tr.off td { color: #98a6b5; }
    .ex-table small { display: block; color: #6b7d90; font-size: 11.5px; }
    .hsel { height: 32px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13px; padding: 3px 8px; min-width: 140px; }
    .pf .row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
    .modal .box h3 { margin: 0 0 6px; color: var(--ex-dark); font-size: 16px; }
    .print-head { display: none; }
    @media print { nav.main-navbar-2tier, .ex-banner, .ex-tabs, .seg, .noprint { display: none !important; } .print-head { display: block; } .card { border: 0; padding: 0; }
        .ex-table td, .ex-table th { padding: 3px 5px !important; font-size: 11px !important; } }
    @media (max-width: 760px) { .pf .row3, .pf .row { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Houses', 'The school divided into houses for competitions and activities — nothing to do with admission', 'fa-shield-halved',
        ($view === 'list' ? [$self(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print'] : [])); ?>
    <?php exam_flash(); ?>
    <div class="seg noprint">
        <a href="<?php echo h($self(['view' => null])); ?>" class="<?php echo $view === 'houses' ? 'on' : ''; ?>"><i class="fas fa-shield-halved"></i>Houses</a>
        <a href="<?php echo h($self(['view' => 'list'])); ?>" class="<?php echo $view === 'list' ? 'on' : ''; ?>"><i class="fas fa-users"></i>Students</a>
    </div>

    <form method="get" class="card pick noprint">
        <?php if ($view === 'list'): ?><input type="hidden" name="view" value="list"><?php endif; ?>
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="0">All classes</option><?php foreach ($classes as $cid => $c): ?><option value="<?php echo (int)$cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
        <?php if ($view === 'list'): ?>
        <div><label>House</label><select name="house" onchange="this.form.submit()"><option value="0">All</option><option value="-1"<?php echo $house_f === -1 ? ' selected' : ''; ?>>No house yet</option>
            <?php foreach ($houses as $hid => $hh): ?><option value="<?php echo (int)$hid; ?>"<?php echo $hid === $house_f ? ' selected' : ''; ?>><?php echo h($hh['name']); ?></option><?php endforeach; ?></select></div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="print-head"><?php exam_school_header('HOUSE LIST' . ($class_id ? ' — CLASS ' . mb_strtoupper($classes[$class_id]['name']) : ''), 'Session ' . $session_name . ($house_f > 0 ? ' · ' . ($houses[$house_f]['name'] ?? '') : '')); ?></div>

<?php if ($view === 'houses'): ?>
    <div class="card">
        <div class="card-head">
            <h2>The houses <small><?php echo count($live); ?> in use</small></h2>
            <div class="acts"><button type="button" class="btn btn-success btn-sm" onclick="houseOpen(null)"><i class="fas fa-plus"></i> Add house</button></div>
        </div>
        <?php if (!$houses): ?>
        <div class="ex-empty"><i class="fas fa-shield-halved"></i>No house yet. Most schools keep four or five — add them here, then share the students out.</div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>House</th><th>In charge</th><th>Motto</th><th class="num">Students</th><th>Status</th><th class="num">Order</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($houses as $hid => $hh): $total = (int)db_get_row('SELECT COUNT(*) n FROM students s WHERE s.house_id = ? AND s.student_status = \'Active\'', 'i', $hid)['n']; ?>
            <tr class="<?php echo $hh['is_active'] ? '' : 'off'; ?>">
                <td><span class="dot" style="background:<?php echo h($hh['colour']); ?>"></span><b><?php echo h($hh['name']); ?></b></td>
                <td><?php echo h($hh['staff_name'] ?: '—'); ?></td>
                <td><?php echo h($hh['motto'] ?: '—'); ?></td>
                <td class="num"><?php echo $total; ?></td>
                <td><?php echo $hh['is_active'] ? '<span class="chip ok">On</span>' : '<span class="chip off">Off</span>'; ?></td>
                <td class="num"><?php echo (int)$hh['sort_order']; ?></td>
                <td style="white-space:nowrap">
                    <button type="button" class="btn btn-warning btn-sm" title="Edit" onclick="houseOpen(<?php echo h(json_encode($hh)); ?>)"><i class="fas fa-edit"></i></button>
                    <?php if ($total === 0): ?>
                    <form method="post" style="display:inline" onsubmit="return confirm(<?php echo h(json_encode('Delete ' . $hh['name'] . '?')); ?>)"><?php echo csrf_field(); ?><input type="hidden" name="act" value="delete_house"><input type="hidden" name="id" value="<?php echo (int)$hid; ?>"><button type="submit" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button></form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">A house with students cannot be deleted — switch it off instead. A student keeps their house from one year to the next.</p>
        <?php endif; ?>
    </div>

    <?php if ($live): ?>
    <div class="card">
        <div class="card-head"><h2>Share the students out <small><?php echo h($session_name); ?><?php echo $class_id ? ' · Class ' . h($classes[$class_id]['name']) : ' · all classes'; ?></small></h2></div>
        <?php if (!$waiting): ?>
        <p class="note" style="margin:0">Everyone here already has a house.</p>
        <?php else: ?>
        <form method="post" onsubmit="return confirm(<?php echo h(json_encode('Share ' . $would . ' student(s) out into the houses? Anyone who already has a house stays as they are.')); ?>)" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
            <?php echo csrf_field(); ?><input type="hidden" name="act" value="share"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
            <div><b><?php echo $waiting; ?> without a house</b><div class="note" style="margin:2px 0 0">They are shared evenly across the <?php echo count($live); ?> houses, class by class, section by section, girls and boys alike. Anyone who already has a house is left alone.</div></div>
            <button type="submit" class="btn btn-success" style="margin-left:auto"><i class="fas fa-random"></i> Share <?php echo $would; ?> out</button>
        </form>
        <?php endif; ?>
    </div>

    <div class="card" style="overflow-x:auto">
        <h2>House by class <small><?php echo h($session_name); ?></small></h2>
        <table class="ex-table">
            <thead><tr><th>Class</th><?php foreach ($live as $hh): ?><th class="num"><span class="dot" style="background:<?php echo h($hh['colour']); ?>"></span><?php echo h($hh['name']); ?></th><?php endforeach; ?><th class="num">No house</th><th class="num">Total</th></tr></thead>
            <tbody>
            <?php $sum = array_fill_keys(array_keys($live), 0); $sum_none = 0;
            foreach ($classes as $cid => $c):
                $row = $grid[$cid] ?? []; $n = (int)($none[$cid] ?? 0);
                if (!$row && !$n) continue;
                $sum_none += $n; ?>
            <tr>
                <td><b>Class <?php echo h($c['name']); ?></b></td>
                <?php foreach ($live as $hid => $hh): $v = (int)($row[$hid] ?? 0); $sum[$hid] += $v; ?><td class="num"><?php echo $v ?: '—'; ?></td><?php endforeach; ?>
                <td class="num"><?php echo $n ?: '—'; ?></td>
                <td class="num"><b><?php echo array_sum($row) + $n; ?></b></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><?php foreach ($live as $hid => $hh): ?><td class="num"><?php echo (int)$sum[$hid]; ?></td><?php endforeach; ?><td class="num"><?php echo $sum_none; ?></td><td class="num"><?php echo array_sum($sum) + $sum_none; ?></td></tr></tfoot>
        </table>
    </div>
    <?php endif; ?>

    <div class="modal" id="houseModal">
        <form class="box pf" method="post" autocomplete="off">
            <?php echo csrf_field(); ?><input type="hidden" name="act" value="save_house"><input type="hidden" name="id" id="hId">
            <h3 id="hTitle">Add house</h3>
            <label>Name</label><input type="text" name="name" id="hName" maxlength="50" required placeholder="e.g. Tagore House">
            <div class="row3">
                <div><label>Colour</label><input type="color" name="colour" id="hColour" value="#1f8a4c" style="height:38px;padding:3px"></div>
                <div><label>Order</label><input type="number" name="sort_order" id="hOrder" min="0" max="999" value="0"></div>
                <div><label>In charge</label><select name="teacher_id" id="hTeacher"><option value="0">—</option><?php echo exam_options($teachers, 0); ?></select></div>
            </div>
            <label>Motto <small style="text-transform:none;font-weight:400">optional</small></label><input type="text" name="motto" id="hMotto" maxlength="100">
            <label class="chk"><input type="checkbox" name="is_active" id="hActive" value="1" checked> On — students can be shared into it</label>
            <div class="acts"><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('houseModal').classList.remove('open')">Cancel</button></div>
        </form>
    </div>

<?php else: ?>
    <?php if (!$houses): ?>
    <?php exam_guard('No house yet', ' Add the houses first, then the students can be shared into them.', $self(['view' => null]), 'Houses'); ?>
    <?php elseif (!$rows): ?>
    <div class="ex-empty"><i class="fas fa-users"></i>No student matches.</div>
    <?php else: ?>
    <div class="card" style="overflow-x:auto">
        <div class="card-head"><h2><?php echo count($rows); ?> student(s) <small><?php echo h($session_name); ?><?php echo $class_id ? ' · Class ' . h($classes[$class_id]['name']) : ''; ?></small></h2></div>
        <table class="ex-table">
            <thead><tr><th>#</th><th>Student</th><th>Class · Sec · Roll</th><th>Gender</th><th>House</th><th class="noprint">Change</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $i => $r): $hh = $houses[(int)$r['house_id']] ?? null; ?>
            <tr>
                <td><?php echo $i + 1; ?></td>
                <td><b><?php echo h($r['student_name']); ?></b><small><?php echo h($r['uid']); ?></small></td>
                <td><?php echo h(trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · ' . $r['roll_no'] : ''))); ?></td>
                <td><?php echo h($r['gender'] ?: '—'); ?></td>
                <td><?php echo $hh ? '<span class="dot" style="background:' . h($hh['colour']) . '"></span>' . h($hh['name']) : '<span class="chip off">None</span>'; ?></td>
                <td class="noprint">
                    <form method="post" style="display:flex;gap:6px;align-items:center">
                        <?php echo csrf_field(); ?><?php foreach ($q as $k => $val): ?><input type="hidden" name="<?php echo h($k); ?>" value="<?php echo h($val); ?>"><?php endforeach; ?>
                        <input type="hidden" name="act" value="move"><input type="hidden" name="uid" value="<?php echo h($r['uid']); ?>">
                        <select name="house_id" class="hsel" onchange="this.form.submit()">
                            <option value="0">No house</option>
                            <?php foreach ($houses as $hid => $x): ?><option value="<?php echo (int)$hid; ?>"<?php echo (int)$r['house_id'] === $hid ? ' selected' : ''; ?>><?php echo h($x['name']); ?></option><?php endforeach; ?>
                        </select>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
<?php endif; ?>
</div>
<script>
function houseOpen(h) {
    var f = function (id) { return document.getElementById(id); };
    f('hTitle').textContent = h ? 'Edit ' + h.name : 'Add house';
    f('hId').value = h ? h.id : '';
    f('hName').value = h ? h.name : '';
    f('hColour').value = h ? h.colour : '#1f8a4c';
    f('hOrder').value = h ? h.sort_order : 0;
    f('hTeacher').value = h && h.teacher_id ? h.teacher_id : '0';
    f('hMotto').value = h && h.motto ? h.motto : '';
    f('hActive').checked = h ? !!+h.is_active : true;
    f('houseModal').classList.add('open');
    f('hName').focus();
}
document.getElementById('houseModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hprc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Formative Entry (HPRC): exam → class → section → subject → one grid of the students who take it.
 * The exam decides the formative phase (1st Summative → 1st Formative Phase, F1A–F1C; 2nd → F2; 3rd → F3);
 * the limits come from Formative Full Marks Settings. Formative is shown on the report card only — never added to a
 * total. Saving goes through hprc_save_formative(): nothing is written if any row fails.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = [];   // only the exams that carry a formative term
foreach (exam_list($session_id) as $e) if (hprc_part_of_exam($e)) $exams[(int)$e['id']] = $e;
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
if (!isset($exams[$exam_id])) $exam_id = (int)array_key_first($exams);
$exam = $exams[$exam_id] ?? null;
$term = $exam ? hprc_part_of_exam($exam) : 0;
$classes = exam_classes('pup');
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? '');
$all_sections = $section_raw === 'all';
$section_id = $all_sections ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = 0;
$subjects = $class_id ? exam_class_subject_list($session_id, $class_id) : [];
$settings = $class_id ? hprc_formative_settings($session_id, $class_id) : [];
$subject_id = (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0);
$subject = $subjects[$subject_id] ?? null;
$full = $subject ? ($settings[$subject_id] ?? null) : null;
$ready = $exam && $class_id && ($all_sections || $section_id) && $subject;
$qs = "session_id=$session_id&exam_id=$exam_id&class_id=$class_id&section_id=" . ($all_sections ? 'all' : (int)$section_id);

$errors = []; $posted = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_formative'])) {
    verify_csrf_or_die();
    // the page falls back to the first exam for viewing; a save never does — it must name a Summative of this session
    if (!isset($exams[(int)($_POST['exam_id'] ?? 0)])) { $_SESSION['error'] = 'That exam carries no formative phase in this session — nothing was saved.'; header("Location: hprc_formative_entry.php?$qs&subject_id=$subject_id"); exit; }
    if (!$ready) { $_SESSION['error'] = 'Pick exam, class, section and subject first.'; header("Location: hprc_formative_entry.php?$qs&subject_id=$subject_id"); exit; }
    $posted = (array)($_POST['m'] ?? []);
    $r = hprc_save_formative($session_id, $exam_id, $class_id, $subject_id, $posted, $admin_id);
    if ($r['ok']) {
        $_SESSION['success'] = $subject['name'] . ' · Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : '') . ' · F' . $r['term'] . ': ' . $r['saved'] . ' saved' . ($r['cleared'] ? ', ' . $r['cleared'] . ' cleared' : '') . '.';
        header("Location: hprc_formative_entry.php?$qs&subject_id=$subject_id"); exit;
    }
    $errors = $r['errors'];
}

$status = ($exam && $class_id) ? hprc_formative_status($session_id, $class_id, $term) : [];
$listed = []; $tl_missing = 0;
if ($ready) foreach (exam_students($session_id, $class_id, $section_id) as $uid => $st) { if ($subject['tl'] && !$st['tl']) $tl_missing++; if (exam_student_takes($st, $subject)) $listed[$uid] = $st; }
$rows = $ready ? hprc_formative_rows($session_id, $class_id, $subject_id) : [];
$keys = $term ? hprc_part_keys($term) : [];
$val = function (string $uid, string $p) use ($posted, $rows, $term) {   // posted value wins (failed save), else stored
    if ($posted) return (string)($posted[$uid][$p] ?? '');
    $v = $rows[$uid]["f$term$p"] ?? null;
    return $v === null ? '' : exam_fmt($v);
};
$used_keys = $full ? array_filter($keys, fn($k) => $full[$k] > 0) : [];   // the phase's parts this subject uses
$exam_opts = []; foreach ($exams as $id => $e) $exam_opts[$id] = $e['exam_name'] . ' · ' . HPRC_PHASES[hprc_part_of_exam($e)] . ' (F' . hprc_part_of_exam($e) . ')';
$sec_opts = ['all' => 'All sections'] + $sections;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Formative Entry</title>
<?php exam_styles(); ?>
<style>
    .ex-table td.err { background: #fff2f2; } .ex-table td .em { display: block; color: #b71c1c; font-size: 11px; }
    .sticky { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 2px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .kb { font-size: 11.5px; color: #6b7d90; } .kb kbd { background: #eef1f4; border: 1px solid #d5dde5; border-radius: 4px; padding: 0 5px; font-size: 11px; }
    .ex-table th.sub { background: #e9e1f2; }
    #grid th, #grid td { border: 1px solid #dde4ec; } #grid th { border-bottom: 2px solid #c9b8dd; } #grid tr:hover td { background: #f7f2fc; }
    #grid td.sep, #grid th.sep { border-left: 2px solid #b7a6cc; }
    .bulk { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; font-size: 12.5px; color: #3b5168; }
    .bulk input[type=text] { width: 70px; height: 30px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; } .bulk label { display: flex; align-items: center; gap: 4px; margin: 0; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Formative Entry', 'One subject at a time. The exam decides the phase — 1st Summative is the 1st Formative Phase (F1A–F1C), 2nd is F2, 3rd is F3. Limits come from Formative Full Marks Settings; formative is shown on the report card only.', 'fa-tasks',
        ['formative_settings.php?' . "session_id=$session_id&class_id=$class_id" => '<i class="fas fa-cog"></i> Formative Full Marks Settings', 'marks_entry.php?section=pup' => '<i class="fas fa-edit"></i> Marks Entry']); ?>
    <?php exam_tabs('hprc_formative_entry.php', HPRC_PAGES, "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>
    <?php if ($errors):
        $off_grid = array_diff_key($errors, $listed + ['_' => 1]);   // rows the grid does not show (another class, not on the roll)
        ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Nothing was saved — fix the rows marked in red<?php if (isset($errors['_'])) echo ': ' . h($errors['_']); ?>.<?php
        foreach ($off_grid as $uid => $m) echo '<br>' . h($uid) . ': ' . h($m); ?></div><?php endif; ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? '' : 'No Summative in this session'); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='';this.form.subject_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options($sec_opts, $all_sections ? 'all' : ($section_id ?: ''), 'Select section'); ?></select></div>
        <div><label>Subject</label><select name="subject_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(array_map(fn($s) => $s['name'] . (isset($settings[$s['id']]) ? '' : ' (not set)'), $subjects), $subject_id, 'Select subject'); ?></select></div>
    </form>

    <?php if ($exam && $class_id && $subjects): ?>
    <div class="strip">
        <?php foreach ($status as $sid => $st): $cls = !$st['set'] ? 'nocfg' : ($st['total'] && $st['done'] >= $st['total'] ? 'done' : ($st['done'] ? 'part' : '')); ?>
        <a href="?<?php echo $qs; ?>&subject_id=<?php echo $sid; ?>" class="<?php echo $cls . ($sid === $subject_id ? ' on' : ''); ?>" title="<?php echo $st['set'] ? $st['done'] . ' of ' . $st['total'] . ' entered for F' . $term . ' (whole class)' : 'Formative full marks not set'; ?>"><?php echo $st['set'] ? ($st['total'] && $st['done'] >= $st['total'] ? '<i class="fas fa-check"></i> ' : ($st['done'] ? '<i class="fas fa-adjust"></i> ' : '')) : '<i class="fas fa-ban"></i> '; ?><?php echo h($subjects[$sid]['name']); ?> <small><?php echo $st['set'] ? $st['done'] . '/' . $st['total'] : 'not set'; ?></small></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!$ready): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-tasks"></i><?php echo !$exams ? 'This session has no 1st, 2nd or 3rd Summative yet — <a href="exams.php?section=pup">add the exams</a> first.' : (!$class_id ? 'Select a class.' : (!$subjects ? 'Class ' . h($classes[$class_id]['name']) . ' has no exam subjects — see <a href="class_subjects.php">Class Subjects</a>.' : (!($all_sections || $section_id) ? 'Select a section (or all sections).' : 'Select a subject.'))); ?></div></div>
    <?php elseif (!$full): ?>
        <?php exam_guard('Formative full marks are not set', ' for ' . $subject['name'] . ' in Class ' . $classes[$class_id]['name'] . '.', "formative_settings.php?session_id=$session_id&class_id=$class_id", 'Formative Full Marks Settings'); ?>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-tasks"></i> <?php echo h($exam['exam_name']); ?> · <?php echo h(HPRC_PHASES[$term]); ?> (F<?php echo $term; ?>) · Class <?php echo h($classes[$class_id]['name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?> · <?php echo h($subject['name']); ?>
            <?php if ($subject['tl']): ?><small>3rd language</small><?php endif; ?></h2>
        <?php if ($tl_missing): ?><div class="alert alert-warning" style="font-size:13px"><i class="fas fa-language"></i> <?php echo $tl_missing; ?> student<?php echo $tl_missing === 1 ? ' has' : 's have'; ?> no third-language choice yet and <?php echo $tl_missing === 1 ? 'is' : 'are'; ?> not listed — <a href="assign_third_language.php?class_id=<?php echo $class_id; ?>">assign third language</a>.</div><?php endif; ?>
        <?php if (!$used_keys): ?><div class="ex-empty"><i class="fas fa-ban"></i><?php echo h($subject['name']); ?> uses no F<?php echo $term; ?> part — see <a href="formative_settings.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $class_id; ?>">Formative Full Marks Settings</a>.</div>
        <?php elseif (!$listed): ?><div class="ex-empty"><i class="fas fa-user-slash"></i>No students to list.</div>
        <?php else: ?>
        <form method="post" id="mf" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $all_sections ? 'all' : (int)$section_id; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
            <div class="bulk noprint"><b><i class="fas fa-bolt"></i> Bulk Fill</b>
                <input type="text" id="bulkv" inputmode="numeric" maxlength="3" placeholder="Value" aria-label="Bulk fill value">
                <?php foreach (HPRC_PARTS as $i => $p): $k = "f$term$p"; if (!in_array($k, $used_keys, true)) continue; ?><button type="button" class="btn btn-secondary btn-sm" data-part="<?php echo $i; ?>" data-max="<?php echo $full[$k]; ?>"><?php echo strtoupper($k); ?></button><?php endforeach; ?>
                <label><input type="checkbox" id="bulkall"> also overwrite filled cells</label>
                <span class="kb" id="bulkmsg">fills this page only — Save to keep</span></div>
            <table class="ex-table" id="grid"><thead><tr><th class="num">#</th><th class="num">Sec</th><th class="num">Roll</th><th>Student</th><th>Father</th>
                <?php foreach ($keys as $i => $k): ?><th class="num sub <?php echo $i === 0 ? 'sep' : ''; ?>"><?php echo strtoupper($k); ?> <small>/<?php echo exam_fmt($full[$k]); ?></small></th><?php endforeach; ?></tr></thead><tbody>
            <?php $n = 0; foreach ($listed as $uid => $st): $n++; $e = $errors[$uid] ?? null; ?>
            <tr data-uid="<?php echo h($uid); ?>">
                <td class="num"><?php echo $n; ?></td><td class="num"><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['roll']); ?></td>
                <td><b><?php echo h($st['name']); ?></b><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($uid); ?></small></td><td style="color:#4d6178"><?php echo h($st['father']); ?></td>
                <?php foreach (HPRC_PARTS as $i => $p): $k = "f$term$p"; $used = in_array($k, $used_keys, true); ?>
                <td class="num <?php echo $i === 0 ? 'sep' : ''; ?> <?php echo $e && $i === 0 ? 'err' : ''; ?>"><input class="m p<?php echo $i; ?>" name="m[<?php echo h($uid); ?>][<?php echo $p; ?>]" value="<?php echo h($val($uid, $p)); ?>" inputmode="numeric" maxlength="3" data-max="<?php echo $full[$k]; ?>" <?php echo $used ? '' : 'disabled title="Not used for this subject"'; ?>><?php if ($e && $i === 0): ?><span class="em"><?php echo h($e); ?></span><?php endif; ?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?></tbody></table>
            <div class="sticky">
                <button type="submit" name="save_formative" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save <?php echo count($listed); ?> students</button>
                <span class="kb"><kbd>Enter</kbd>/<kbd>↓</kbd> next student · <kbd>↑</kbd> previous · <kbd>Tab</kbd> next part · blank = not entered · whole numbers only</span>
            </div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
(function () {
    // blank, or a whole number within the part's full marks
    function check(i) {
        var v = i.value.trim();
        i.classList.toggle('bad', v !== '' && (!/^\d{1,3}$/.test(v) || +v > +i.dataset.max));
    }
    var rows = Array.prototype.slice.call(document.querySelectorAll('#grid tbody tr'));
    document.querySelectorAll('#grid input.m').forEach(function (i) {
        check(i); i.addEventListener('input', function () { check(i); });
        i.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
            e.preventDefault();
            var tr = i.closest('tr'), cls = i.classList[1], dir = e.key === 'ArrowUp' ? -1 : 1, idx = rows.indexOf(tr) + dir;
            while (idx >= 0 && idx < rows.length) { var n = rows[idx].querySelector('input.' + cls); if (n && !n.disabled) { n.focus(); n.select(); return; } idx += dir; }
        });
    });
    var f = document.getElementById('mf'); if (f) { var dirty = false; f.addEventListener('input', function () { dirty = true; }); window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } }); f.addEventListener('submit', function () { dirty = false; }); }
    // Bulk Fill: one value into a part's column — blank cells only unless "also overwrite" is ticked; nothing is saved until Save
    var bv = document.getElementById('bulkv'), msg = document.getElementById('bulkmsg');
    document.querySelectorAll('button[data-part]').forEach(function (b) {
        b.addEventListener('click', function () {
            var v = bv.value.trim(), all = document.getElementById('bulkall').checked, n = 0;
            if (!/^\d{1,3}$/.test(v)) { msg.textContent = 'Type a whole number first.'; bv.focus(); return; }
            if (+v > +b.dataset.max) { msg.textContent = b.textContent + ' full marks are ' + b.dataset.max + ' — ' + v + ' is more.'; bv.focus(); return; }
            document.querySelectorAll('#grid input.p' + b.dataset.part).forEach(function (i) { if (all || i.value.trim() === '') { i.value = v; check(i); n++; } });
            msg.textContent = n + ' cell' + (n === 1 ? '' : 's') + ' of ' + b.textContent + ' filled with ' + v + ' — Save to keep.';
            if (n) dirty = true;
        });
    });
    var first = document.querySelector('#grid input.m:not(:disabled)'); if (first && !document.querySelector('.err')) first.focus();
})();
</script>
</body>
</html>

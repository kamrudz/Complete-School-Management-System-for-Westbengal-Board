<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hprc_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Formative Report (HPRC): every subject's three parts of one Formative Phase, student by student, for a class
 * or one section, with how much has been entered. Read-only; A4 landscape print and ?xlsx=1 Excel.
 * No totals — formative is shown, never added.
 */
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = [];   // only the exams that carry a formative phase
foreach (exam_list($session_id) as $e) if (hprc_part_of_exam($e)) $exams[(int)$e['id']] = $e;
$exam_id = (int)($_GET['exam_id'] ?? 0);
if (!isset($exams[$exam_id])) $exam_id = (int)array_key_first($exams);
$exam = $exams[$exam_id] ?? null;
$term = $exam ? hprc_part_of_exam($exam) : 0;
$classes = exam_classes('pup');
$class_id = (int)($_GET['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? '');
$all_sections = $section_raw === 'all';
$section_id = $all_sections ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = 0;
$search = trim((string)($_GET['search'] ?? ''));
$ready = $exam && $class_id && ($all_sections || $section_id);
$qs = "session_id=$session_id&exam_id=$exam_id&class_id=$class_id&section_id=" . ($all_sections ? 'all' : (int)$section_id) . '&search=' . urlencode($search);

$keys = $term ? hprc_part_keys($term) : [];
$subjects = $ready ? exam_class_subject_list($session_id, $class_id) : [];
$full = $ready ? hprc_formative_settings($session_id, $class_id) : [];   // subject_id => part => full marks; a subject without them is "not set"
$listed = [];
if ($ready) foreach (exam_students($session_id, $class_id, $section_id, (int)$exam['id']) as $uid => $st) {   // the class as it was for that exam
    if ($search === '' || mb_stripos($st['name'], $search) !== false) $listed[$uid] = $st;
}
$rows = $ready ? hprc_formative_class_rows($session_id, $class_id) : [];
$entered = fn(string $uid, int $sid): bool => (bool)array_filter($keys, fn($k) => ($rows[$uid][$sid][$k] ?? null) !== null);   // any part of the phase
/** One cell: 'NA' when the student does not take the subject, '' for a part the subject does not use, null when not entered, else the mark. */
$cell = function (string $uid, array $st, int $sid, string $k) use ($subjects, $full, $rows): ?string {
    if (!exam_student_takes($st, $subjects[$sid])) return 'NA';
    if (isset($full[$sid]) && $full[$sid][$k] <= 0) return '';
    $v = $rows[$uid][$sid][$k] ?? null;
    return $v === null ? null : exam_fmt($v);
};

// progress: a student's subject counts when it has full marks and the student takes it
$progress = []; $complete = 0; $none = 0; $cells = 0; $done = 0;
foreach ($listed as $uid => $st) {
    $mine = 0; $got = 0;
    foreach ($subjects as $sid => $s) {
        if (!isset($full[$sid]) || !exam_student_takes($st, $s)) continue;
        $mine++; $progress[$sid]['of'] = ($progress[$sid]['of'] ?? 0) + 1;
        if ($entered($uid, $sid)) { $got++; $progress[$sid]['done'] = ($progress[$sid]['done'] ?? 0) + 1; }
    }
    $cells += $mine; $done += $got;
    if ($mine && $got === $mine) $complete++;
    if (!$got) $none++;
}
$title = $ready ? 'Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : ' (all sections)') . ' · ' . HPRC_PHASES[$term] : '';

if ($ready && !empty($_GET['xlsx'])) {
    $head = ['#', 'Sec', 'Roll', 'School UID', "Banglar\nShiksha ID", 'Student']; $parts = array_fill(0, count($head), '');
    $fixed = count($head); $merge = []; $band = []; $b = 0;
    foreach ($subjects as $sid => $s) {
        $from = count($head) + 1; $b = $b === 1 ? 2 : 1;   // every other subject is tinted so its three columns read together
        foreach ($keys as $i => $k) {
            $head[] = $i === 0 ? $s['name'] : '';
            $parts[] = strtoupper($k) . (isset($full[$sid]) ? "\n/" . exam_fmt($full[$sid][$k]) : '');
            $band[$from + $i] = $b;
        }
        $merge[] = SimpleXLSXWriter::columnName($from) . '4:' . SimpleXLSXWriter::columnName($from + count($keys) - 1) . '4';
    }
    for ($c = 1; $c <= $fixed; $c++) { $col = SimpleXLSXWriter::columnName($c); $merge[] = "{$col}4:{$col}5"; }
    $out = array_merge(exam_xlsx_title('Formative Report — ' . $title, 'Session ' . exam_session_name($session_id) . '  ·  ' . $exam['exam_name'] . '  ·  NA = does not take the subject'), [$head, $parts]);
    $i = 0;
    foreach ($listed as $uid => $st) {
        $r = [++$i, $st['section'], $st['roll'], $uid, $st['bsid'], $st['name']];
        foreach ($subjects as $sid => $s) foreach ($keys as $k) $r[] = (string)$cell($uid, $st, $sid, $k);
        $out[] = $r;
    }
    $opts = exam_xlsx_opts(count($head));
    SimpleXLSXWriter::download('formative_' . preg_replace('/[^A-Za-z0-9]+/', '_', $title) . '.xlsx', $out, 'Formative',
        ['header_rows' => 2, 'band_cols' => $band, 'merge_cells' => array_merge($opts['merge_cells'], $merge)] + $opts);
    exit;
}
$exam_opts = []; foreach ($exams as $id => $e) $exam_opts[$id] = $e['exam_name'] . ' · ' . HPRC_PHASES[hprc_part_of_exam($e)] . ' (F' . hprc_part_of_exam($e) . ')';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Formative Report</title>
<?php exam_styles(); ?>
<style>
    .cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 12px; }
    .cards div { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px; text-align: center; }
    .cards b { display: block; font-size: 26px; color: var(--ex-dark); } .cards span { font-size: 12px; color: #6b7d90; }
    .cards .ok b { color: #1b7a3a; } .cards .no b { color: #b71c1c; } .cards .pc b { color: #b26a00; }
    .info { display: flex; gap: 14px; flex-wrap: wrap; align-items: center; font-size: 13px; color: #3b5168; margin-bottom: 10px; } .info b { color: var(--ex-dark); }
    .wrap { overflow-x: auto; }
    #grid { font-size: 12.5px; } #grid th, #grid td { border: 1px solid #dde4ec; padding: 5px 6px; } #grid th { text-align: center; }
    #grid th.subj { background: #e9e1f2; } #grid th.subj small { display: block; font-weight: 400; text-transform: none; color: #6b7d90; }
    #grid td.m { text-align: center; font-weight: 700; color: #1b7a3a; } #grid td.m.none { color: #b0bac5; font-weight: 400; } #grid td.m.na { color: #8a98a8; font-weight: 400; font-size: 11px; }
    #grid .s0 { border-left: 2px solid #b7a6cc; }
    .print-only { display: none; }
    @media print {
        .main-navbar-2tier, .pick, .ex-banner, .ex-tabs, .cards, .noprint { display: none !important; }
        .print-only { display: block; } .card { border: 0; padding: 0; } .wrap { overflow: visible; }
        #grid { font-size: 10px; } #grid th, #grid td { padding: 2px 3px !important; white-space: normal; }   /* the phone stylesheet pads cells on paper */
        * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        @page { size: A4 landscape; margin: 8mm; }
    }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Formative Report', 'Every subject\'s formative parts for one Formative Phase, student by student. Formative is shown on the report card only — never added to a total.', 'fa-file-alt',
        ($ready ? ["hprc_formative_report.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel'] : []) + ["hprc_formative_entry.php?session_id=$session_id&exam_id=$exam_id&class_id=$class_id" => '<i class="fas fa-edit"></i> Formative Entry']); ?>
    <?php exam_tabs('hprc_formative_report.php', HPRC_PAGES, "session_id=$session_id&class_id=$class_id"); ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? '' : 'No Summative in this session'); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $all_sections ? 'all' : ($section_id ?: ''), 'Select section'); ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Student name"></div>
        <div><label>&nbsp;</label><button type="submit" class="btn btn-primary" style="height:38px"><i class="fas fa-search"></i> Load</button></div>
    </form>

    <?php if (!$ready): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-file-alt"></i><?php echo !$exams ? 'This session has no 1st, 2nd or 3rd Summative yet.' : (!$class_id ? 'Select a class.' : 'Select a section (or all sections).'); ?></div></div>
    <?php else: ?>
    <div class="cards">
        <div><b><?php echo count($listed); ?></b><span><i class="fas fa-users"></i> Total Students</span></div>
        <div class="ok"><b><?php echo $complete; ?></b><span><i class="fas fa-check-circle"></i> All Subjects Entered</span></div>
        <div class="no"><b><?php echo $none; ?></b><span><i class="fas fa-times-circle"></i> Nothing Entered</span></div>
        <div class="pc"><b><?php echo $cells ? round($done / $cells * 100, 1) : 0; ?>%</b><span><i class="fas fa-chart-line"></i> Completion Rate</span></div>
    </div>
    <div class="card">
        <div class="print-only"><?php exam_school_header('Formative Assessment Report — ' . $title, 'Session ' . exam_session_name($session_id) . ' · ' . $exam['exam_name']); ?></div>
        <div class="info">
            <span>Class: <b><?php echo h($classes[$class_id]['name']); ?></b></span>
            <span>Section: <b><?php echo $section_id ? h($sections[$section_id]) : 'All'; ?></b></span>
            <span>Exam: <b><?php echo h($exam['exam_name']); ?></b></span>
            <span class="chip ok"><?php echo h(HPRC_PHASES[$term]); ?> (<?php echo strtoupper(implode(', ', $keys)); ?>)</span>
            <span class="noprint" style="margin-left:auto;display:flex;gap:6px"><a class="btn btn-secondary btn-sm" href="hprc_formative_report.php?<?php echo h($qs); ?>&xlsx=1"><i class="fas fa-file-excel"></i> Excel</a><button type="button" class="btn btn-secondary btn-sm" onclick="window.print()"><i class="fas fa-print"></i> Print</button></span>
        </div>
        <?php if (!$listed): ?><div class="ex-empty"><i class="fas fa-user-slash"></i><?php echo $search !== '' ? 'No student matches "' . h($search) . '".' : 'No students to list.'; ?></div>
        <?php elseif (!$subjects): ?><div class="ex-empty"><i class="fas fa-book"></i>Class <?php echo h($classes[$class_id]['name']); ?> has no exam subjects — see <a href="class_subjects.php">Class Subjects</a>.</div>
        <?php else: ?>
        <div class="wrap">
        <table class="ex-table" id="grid"><thead>
            <tr><th rowspan="2">Roll</th><th rowspan="2" style="text-align:left">Student Name</th><th rowspan="2">Sec</th><th rowspan="2">BS ID</th>
                <?php foreach ($subjects as $sid => $s): ?><th colspan="<?php echo count($keys); ?>" class="subj s0"><?php echo h($s['name']); ?><small><?php echo isset($full[$sid]) ? ($progress[$sid]['done'] ?? 0) . '/' . ($progress[$sid]['of'] ?? 0) . ' entered' : 'full marks not set'; ?></small></th><?php endforeach; ?></tr>
            <tr><?php foreach ($subjects as $sid => $s) foreach ($keys as $i => $k): ?><th class="<?php echo $i === 0 ? 's0' : ''; ?>"><?php echo strtoupper($k); ?><?php if (isset($full[$sid])): ?> <small>/<?php echo exam_fmt($full[$sid][$k]); ?></small><?php endif; ?></th><?php endforeach; ?></tr>
        </thead><tbody>
        <?php foreach ($listed as $uid => $st): ?>
            <tr>
                <td class="num"><?php echo h($st['roll']); ?></td><td><b><?php echo h($st['name']); ?></b></td><td class="num"><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['bsid'] ?: '—'); ?></td>
                <?php foreach ($subjects as $sid => $s) foreach ($keys as $i => $k): $v = $cell($uid, $st, $sid, $k); ?><td class="m <?php echo ($i === 0 ? 's0 ' : '') . ($v === null ? 'none' : ($v === 'NA' || $v === '' ? 'na' : '')); ?>"><?php echo $v === null ? '—' : h($v); ?></td><?php endforeach; ?>
            </tr>
        <?php endforeach; ?></tbody></table>
        </div>
        <p class="note">— not entered · NA the student does not take the subject (third language) · a blank cell is a part the subject does not use.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

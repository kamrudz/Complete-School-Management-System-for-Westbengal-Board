<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hprc_grid_page.php';

/** HPRC Learning entry — the shared observation sheet of includes/hprc_grid_page.php. */
hprc_grid_page('learning', 'hprc_learning_entry.php');

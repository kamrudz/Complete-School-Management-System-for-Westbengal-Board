<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_reader.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Bulk marks upload for a semester exam: download one workbook with A TAB PER SUBJECT, fill it in Excel,
 * upload → preview (problems listed per row) → confirm.
 *
 * A tab carries only the students whose combination includes that subject, so there are no "not applicable"
 * cells at all: School UID (the key), Section, Roll and Student are locked, and only the Theory and
 * Practical / Project columns can be typed in. A cell is a number, AB for absent, or blank.
 * BLANK MEANS UNCHANGED — every row is merged with what is already on record before it is saved, so filling
 * in theory alone never wipes a practical or a supplementary mark. Supplementary is not in the sheet at all
 * (it is rare, and Marks Entry handles it); a sheet that would invalidate one is reported, never silently dropped.
 * Saved through hs_marks_save_rows() per subject — the same rules as the Marks Entry screen.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? hs_exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = hs_exam_list($session_id);
if (!$exam && $exams) { $exam = hs_exam_get((int)$exams[0]['id']); $exam_id = (int)$exam['id']; }
$class_id = $exam ? (int)$exam['class_id'] : (int)(array_key_first(hs_exam_classes()) ?? 0);
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw;
if ($section_id && !isset($sections[$section_id])) $section_id = null;
$all_subjects = $exam ? hs_exam_subjects($exam_id) : [];
$subjects = array_filter($all_subjects, fn($s) => $s['configured']);          // a subject without full marks cannot take marks
$subject_id = (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0);        // 0 = every subject, one tab each
if ($subject_id && !isset($subjects[$subject_id])) $subject_id = 0;
$ready = $exam && $subjects;
$qs = "exam_id=$exam_id&section_id=" . ($section_id ?: 'all') . "&subject_id=$subject_id";
$tmp_dir = sys_get_temp_dir();

/** The subjects that go into the workbook: the chosen one, or all of them. */
function hs_bulk_subjects(array $subjects, int $subject_id): array {
    return $subject_id ? [$subject_id => $subjects[$subject_id]] : $subjects;
}

/**
 * One worksheet per subject: only the students who take it, their marks pre-filled.
 * @return array<int,array<string,mixed>> sheets for SimpleXLSXWriter::downloadBook()
 */
function hs_bulk_sheets(array $exam, array $subjects, array $students, array $choice, array $marks, string $where, string $school): array {
    $sheets = [];
    foreach ($subjects as $sid => $s) {
        $code = exam_subject_code($s);
        $prac = $s['has_practical'];
        // the Theory[id] / Practical[id] prefix is what the upload reads — the tab name and its order do not matter
        $head = ['School UID', 'Sec', 'Roll', 'Student', "Theory[$sid]\n$code\nmax " . exam_fmt($s['theory_full'])];
        if ($prac) $head[] = "Practical[$sid]\n$code\nmax " . exam_fmt($s['practical_full']);
        $width = count($head);
        $marksLine = $s['name'] . ' (' . $code . ') — Theory ' . exam_fmt($s['theory_full']) . ', pass ' . exam_fmt($s['theory_pass'])
            . ($prac ? '  ·  Practical / Project ' . exam_fmt($s['practical_full']) . ', pass ' . exam_fmt($s['practical_pass']) : '')
            . '  ·  each part is passed on its own';
        $rows = [
            [$school],
            [$exam['exam_name'] . '  ·  Session ' . $exam['session_name'] . '  ·  ' . $where],
            [$marksLine],
            ['Type marks in the yellow columns only — UID, Sec, Roll and Student are locked. A number, or AB for absent; a blank cell leaves the mark as it is. Only the students who took this subject are listed.'],
            $head,
        ];
        $n = 0;
        foreach ($students as $uid => $st) {
            if (!isset($choice[$uid][$sid])) continue;
            $m = $marks[$uid][$sid] ?? null;
            $r = [$uid, $st['section'], $st['roll'], $st['name']];
            $r[] = $m ? ((int)$m['theory_absent'] ? 'AB' : exam_fmt($m['theory_marks'])) : '';
            if ($prac) $r[] = $m ? ((int)$m['practical_absent'] ? 'AB' : exam_fmt($m['practical_marks'])) : '';
            $rows[] = $r; $n++;
        }
        if (!$n) continue;   // nobody takes it here — no empty tab
        $sheets[] = ['name' => $code, 'rows' => $rows,
            'options' => ['title_rows' => 4, 'header_rows' => 1, 'protect' => true, 'unlocked_cols' => range(5, $width), 'max_col_width' => 24,
                'merge_cells' => array_map(fn($r) => 'A' . $r . ':' . SimpleXLSXWriter::columnName($width) . $r, [1, 2, 3, 4])]];
    }
    return $sheets;
}

/**
 * Read an uploaded workbook into rows for hs_marks_save_rows(), plus a message per problem.
 * Every tab is read; a tab without the Theory[..] header is ignored, so extra sheets do no harm.
 */
function hs_bulk_parse(string $path, int $exam_id, array $subjects): array {
    $exam = hs_exam_get($exam_id);
    if (!$exam) return ['error' => 'The semester exam no longer exists.'];
    $book = SimpleXLSXReader::readAllSheets($path);
    if (!$book) return ['error' => 'The workbook has no worksheets.'];
    $session_id = (int)$exam['session_id']; $class_id = (int)$exam['class_id'];
    $students = hs_students($session_id, $class_id);
    $choice = hs_student_subjects($session_id, $class_id);
    $onRecord = hs_marks($exam_id);
    $out = []; $msgs = []; $seen = [];
    $stats = ['tabs' => 0, 'rows' => 0, 'cells' => 0, 'absent' => 0, 'skipped' => 0, 'errors' => 0];

    foreach ($book as $tab => $all) {
        $cols = []; $headAt = -1;
        foreach ($all as $i => $r) {
            $c = [];
            foreach ($r as $j => $label) if (preg_match('/^(Theory|Practical)\[(\d+)\]/i', trim((string)$label), $m)) $c[$j] = [strtolower($m[1]), (int)$m[2]];
            if ($c) { $cols = $c; $headAt = $i; break; }
        }
        if (!$cols) continue;                       // not a marks tab
        $stats['tabs']++;
        $offset = $headAt + 2;                      // Excel's own row number of the first data row
        foreach (array_slice($all, $headAt + 1) as $n => $r) {
            $line = $n + $offset;
            $uid = student_uid_clean((string)($r[0] ?? ''));
            if ($uid === '') continue;
            $stats['rows']++;
            $st = $students[$uid] ?? null;
            if (!$st) { $msgs[] = "$tab row $line: $uid is not a current student of this class — row skipped."; $stats['errors']++; continue; }
            $by = [];
            foreach ($cols as $i => [$type, $sid]) $by[$sid][$type] = strtoupper(trim((string)($r[$i] ?? '')));
            foreach ($by as $sid => $v) {
                $sub = $subjects[$sid] ?? null;
                if (!$sub) { if (empty($seen["s$sid"])) { $seen["s$sid"] = 1; $msgs[] = "$tab: a column belongs to a subject that has no full marks in this exam — that tab was ignored."; $stats['errors']++; } continue; }
                if (!isset($choice[$uid][$sid])) { $msgs[] = "$tab row $line ({$st['name']}): does not take {$sub['name']} — row skipped."; $stats['errors']++; continue; }
                $th = $v['theory'] ?? ''; $pr = $v['practical'] ?? '';
                if ($th === 'NA') $th = ''; if ($pr === 'NA') $pr = '';
                if ($th === '' && $pr === '') { $stats['skipped']++; continue; }   // blank = leave the mark as it is

                // start from what is on record, so a blank cell never wipes the other part or the supplementary
                $cur = $onRecord[$uid][$sid] ?? null;
                $row = [
                    'theory' => ($cur && $cur['theory_marks'] !== null) ? exam_fmt($cur['theory_marks']) : '',
                    'supplementary' => ($cur && $cur['theory_supplementary_marks'] !== null) ? exam_fmt($cur['theory_supplementary_marks']) : '',
                    'practical' => ($cur && $cur['practical_marks'] !== null) ? exam_fmt($cur['practical_marks']) : '',
                    'theory_absent' => $cur ? (int)$cur['theory_absent'] : 0,
                    'practical_absent' => $cur ? (int)$cur['practical_absent'] : 0,
                ];
                $bad = '';
                if ($th !== '') {
                    if ($th === 'AB') { $row['theory'] = ''; $row['theory_absent'] = 1; $stats['absent']++; }
                    else { [, $e] = exam_parse_mark($th, $sub['theory_full']); if ($e) $bad = "theory $e"; else { $row['theory'] = $th; $row['theory_absent'] = 0; } }
                }
                if ($bad === '' && $pr !== '') {
                    if (!$sub['has_practical']) $bad = 'this semester has no practical / project for ' . $sub['name'];
                    elseif ($pr === 'AB') { $row['practical'] = ''; $row['practical_absent'] = 1; $stats['absent']++; }
                    else { [, $e] = exam_parse_mark($pr, $sub['practical_full']); if ($e) $bad = "practical / project $e"; else { $row['practical'] = $pr; $row['practical_absent'] = 0; } }
                }
                // supplementary is the second chance for a failed semester: a pass mark cannot keep one
                if ($bad === '' && $row['supplementary'] !== '' && !$row['theory_absent'] && $row['theory'] !== '' && (float)$row['theory'] >= $sub['theory_pass']) {
                    $bad = 'theory ' . $row['theory'] . ' is a pass but a supplementary mark of ' . $row['supplementary'] . ' is on record — clear it in Marks Entry first';
                }
                if ($bad !== '') { $msgs[] = "$tab row $line ({$st['name']}): {$sub['name']} — $bad, row skipped."; $stats['errors']++; continue; }
                $out[$sid][$uid] = $row; $stats['cells']++;
            }
        }
    }
    if (!$stats['tabs']) return ['error' => 'No marks columns found — use the downloaded workbook and keep its heading rows.'];
    return ['rows' => $out, 'msgs' => $msgs, 'stats' => $stats];
}

// ── template
if ($ready && isset($_GET['download_template'])) {
    $students = hs_students($session_id, $class_id, $section_id);
    $choice = hs_student_subjects($session_id, $class_id, $section_id);
    $marks = hs_marks($exam_id);
    $where = 'Class ' . $exam['class_name'] . ($section_id ? ' — Section ' . $sections[$section_id] : ' — all sections');
    $school = (string)(db_get_row('SELECT school_name FROM school_settings WHERE id = 1')['school_name'] ?? '');
    $sheets = hs_bulk_sheets($exam, hs_bulk_subjects($subjects, $subject_id), $students, $choice, $marks, $where, $school);
    if (!$sheets) { $_SESSION['error'] = 'Nobody here has these subjects in their combination yet.'; header("Location: hs_bulk_marks_upload.php?$qs"); exit; }
    $name = 'HS_marks_' . preg_replace('/[^A-Za-z0-9]+/', '_', $exam['exam_name'] . '_class_' . $exam['class_name']
        . ($section_id ? '_' . $sections[$section_id] : '') . ($subject_id ? '_' . exam_subject_code($subjects[$subject_id]) : '')) . '.xlsx';
    SimpleXLSXWriter::downloadBook($name, $sheets);
    exit;
}

$preview = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    verify_csrf_or_die();
    if (isset($_POST['upload'])) {
        $f = $_FILES['file'] ?? null;
        if (!$f || (int)$f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) $_SESSION['error'] = 'Choose an .xlsx file to upload.';
        elseif ($f['size'] > 2 * 1024 * 1024) $_SESSION['error'] = 'The file is larger than 2 MB.';
        elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'xlsx' || !in_array(mime_content_type($f['tmp_name']), ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'], true)) $_SESSION['error'] = 'Only .xlsx files are accepted (save as Excel Workbook).';
        else {
            try { $p = hs_bulk_parse($f['tmp_name'], $exam_id, $subjects); } catch (Throwable $e) { error_log('hs_bulk_parse: ' . $e->getMessage()); $p = ['error' => 'Could not read the file — save it again as an Excel Workbook (.xlsx).']; }
            if (isset($p['error'])) $_SESSION['error'] = $p['error'];
            else {
                $token = bin2hex(random_bytes(12));
                $dest = $tmp_dir . DIRECTORY_SEPARATOR . 'hs_marks_' . $token . '.xlsx';
                move_uploaded_file($f['tmp_name'], $dest);
                $_SESSION['hs_bulk_marks'] = ['token' => $token, 'path' => $dest, 'exam_id' => $exam_id, 'time' => time()];
                $preview = $p + ['token' => $token];
            }
        }
        if (!$preview) { header("Location: hs_bulk_marks_upload.php?$qs"); exit; }
    } elseif (isset($_POST['confirm'])) {
        $pend = $_SESSION['hs_bulk_marks'] ?? null; unset($_SESSION['hs_bulk_marks']);
        if (!$pend || !hash_equals($pend['token'], (string)($_POST['token'] ?? '')) || (int)$pend['exam_id'] !== $exam_id || !is_file($pend['path'])) $_SESSION['error'] = 'The upload expired — upload the file again.';
        else {
            try { $p = hs_bulk_parse($pend['path'], $exam_id, $subjects); } catch (Throwable $e) { error_log('hs_bulk_parse: ' . $e->getMessage()); $p = ['error' => 'Could not read the file again — upload it once more.']; }
            @unlink($pend['path']);
            if (isset($p['error'])) $_SESSION['error'] = $p['error'];
            else {
                $saved = 0; $failed = [];
                foreach ($p['rows'] ?? [] as $sid => $rows) {
                    $r = hs_marks_save_rows($exam_id, (int)$sid, $rows, $admin_id);
                    if ($r['ok']) $saved += $r['saved'];
                    else $failed[] = $subjects[$sid]['name'] . ': ' . implode('; ', array_slice($r['errors'], 0, 3));
                }
                log_action($admin_id, 'HS_MARKS_BULK_UPLOADED', 'hs_marks', $exam_id, null, ['saved' => $saved, 'subjects' => count($p['rows'] ?? [])]);
                $_SESSION[$failed ? 'error' : 'success'] = "$saved marks saved from the workbook" . ($failed ? '. Not saved — ' . implode(' | ', $failed) : '.');
            }
        }
        header("Location: hs_bulk_marks_upload.php?$qs"); exit;
    } elseif (isset($_POST['cancel'])) {
        $pend = $_SESSION['hs_bulk_marks'] ?? null; unset($_SESSION['hs_bulk_marks']);
        if ($pend && is_file($pend['path'])) @unlink($pend['path']);
        header("Location: hs_bulk_marks_upload.php?$qs"); exit;
    }
}

$status = $exam ? hs_entry_status($exam_id) : [];
$combinations = $class_id ? (int)(db_get_row('SELECT COUNT(DISTINCT student_id) n FROM hs_student_subjects WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
$roll_count = $class_id ? count(hs_students($session_id, $class_id)) : 0;
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = 'Class ' . $e['class_name'] . ' — ' . $e['exam_name'];
$subject_opts = [0 => 'All subjects — one tab each'];
foreach ($subjects as $sid => $s) $subject_opts[$sid] = $s['name'] . ' only';
// how many students each tab would carry — a subject nobody here takes gets no tab at all
$takers = [];
if ($ready) {
    $in_section = hs_students($session_id, $class_id, $section_id);
    $choice_now = hs_student_subjects($session_id, $class_id, $section_id);
    foreach (hs_bulk_subjects($subjects, $subject_id) as $sid => $s) {
        $n = 0;
        foreach ($in_section as $uid => $st) if (isset($choice_now[$uid][$sid])) $n++;
        $takers[$sid] = $n;
    }
}
$tab_count = count(array_filter($takers));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Bulk Marks Upload</title>
<?php exam_styles('hs'); ?>
<style>
    .steps2 { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; } @media (max-width: 900px) { .steps2 { grid-template-columns: 1fr; } }
    .step h3 { margin: 0 0 6px; font-size: 14px; color: var(--ex-dark); } .step h3 span { display: inline-block; width: 24px; height: 24px; border-radius: 50%; background: var(--ex-dark); color: #fff; text-align: center; line-height: 24px; font-size: 12px; margin-right: 6px; }
    .stats { display: flex; gap: 8px; flex-wrap: wrap; margin: 10px 0; } .stats span { padding: 6px 12px; border-radius: 9px; background: var(--ex-soft); border: 1px solid var(--ex-border); font-size: 13px; } .stats b { font-size: 16px; display: block; }
    .msgs { max-height: 280px; overflow: auto; font-size: 12.5px; background: #fff7f7; border: 1px solid #f5b5b0; border-radius: 9px; padding: 8px 12px; } .msgs div { padding: 2px 0; border-bottom: 1px dashed #f1d3d0; }
    .tabs-preview { display: flex; gap: 6px; flex-wrap: wrap; margin: 8px 0 2px; } .tabs-preview span { padding: 4px 10px; border-radius: 7px 7px 0 0; background: var(--ex-soft); border: 1px solid var(--ex-border); border-bottom: 0; font-size: 12px; font-weight: 700; color: var(--ex-dark); } .tabs-preview span small { font-weight: 400; opacity: .7; } .tabs-preview span.none { background: #f4f6f8; border-color: #dde3e9; color: #93a2b1; }
    input[type=file] { font-size: 13px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('HS Bulk Marks Upload', 'One workbook per semester exam with a tab for every subject — each tab lists only the students who took it.', 'fa-file-excel', ['hs_marks_entry.php' => '<i class="fas fa-edit"></i> Marks Entry']); ?>
    <?php hs_tabs('hs_bulk_marks_upload.php'); ?>
    <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_marks_entry.php', "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div style="min-width:260px"><label>Semester exam</label><select name="exam_id" onchange="this.form.section_id.value='all';this.form.subject_id.value='0';this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No semester exam in this session'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $exam ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
        <div style="min-width:220px"><label>Subjects in the file</label><select name="subject_id" onchange="this.form.submit()" <?php echo $ready ? '' : 'disabled'; ?>><?php echo exam_options($subject_opts, $subject_id); ?></select></div>
    </form>

    <?php if ($exam && $all_subjects): ?>
    <div class="strip">
        <?php foreach ($status as $sid => $st): $cls = !$st['configured'] ? 'nocfg' : ($st['total'] && $st['done'] >= $st['total'] ? 'done' : ($st['done'] ? 'part' : '')); ?>
        <span class="<?php echo $cls; ?>" title="<?php echo $st['configured'] ? $st['done'] . ' of ' . $st['total'] . ' entered' : 'Full marks not set'; ?>"><?php echo h($all_subjects[$sid]['name']); ?> <small><?php echo $st['configured'] ? $st['done'] . '/' . $st['total'] : 'no FM'; ?></small></span>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!$exam): ?>
        <div class="card"><?php exam_guard('No semester exam yet', 'Create the semester exams of Class XI first.', 'hs_exams.php', 'Semester Exams'); ?></div>
    <?php elseif (!$subjects): ?>
        <div class="card"><?php exam_guard('Full marks are not set', 'No subject of ' . $exam['exam_name'] . ' has its theory and practical marks yet, so no template can be made.', "hs_exam_subject_marks.php?exam_id=$exam_id", 'Full & Pass Marks'); ?></div>
    <?php elseif (!$combinations): ?>
        <div class="card"><?php exam_guard('No subject combination yet', 'Class ' . $exam['class_name'] . ' has ' . $roll_count . ' students and none of them has a combination, so no tab would have any student in it.', "hs_subjects.php?session_id=$session_id&class_id=$class_id", 'Subject Combination'); ?></div>
    <?php elseif ($preview): $s = $preview['stats']; ?>
    <div class="card">
        <h2><i class="fas fa-search"></i> Preview <small><?php echo h($exam['exam_name']); ?> · Class <?php echo h($exam['class_name']); ?> — nothing has been saved yet</small></h2>
        <div class="stats">
            <span><b><?php echo $s['tabs']; ?></b>subject tabs read</span>
            <span><b><?php echo $s['rows']; ?></b>student rows</span>
            <span><b><?php echo $s['cells']; ?></b>marks to save</span>
            <span><b><?php echo $s['absent']; ?></b>absent (AB)</span>
            <span><b><?php echo $s['skipped']; ?></b>blank (unchanged)</span>
            <span style="<?php echo $s['errors'] ? 'background:#fdecea;border-color:#f5b5b0' : ''; ?>"><b><?php echo $s['errors']; ?></b>problems</span>
        </div>
        <?php if ($preview['msgs']): ?>
            <div class="msgs"><?php foreach ($preview['msgs'] as $m) echo '<div>' . h($m) . '</div>'; ?></div>
            <p class="note">Rows with a problem are skipped; everything else is saved when you confirm.</p>
        <?php endif; ?>
        <form method="post" style="margin-top:12px;display:flex;gap:8px"><?php echo csrf_field(); ?>
            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id ?: 'all'; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>"><input type="hidden" name="token" value="<?php echo h($preview['token']); ?>">
            <button type="submit" name="confirm" value="1" class="btn btn-primary" <?php echo $s['cells'] ? '' : 'disabled'; ?>><i class="fas fa-check"></i> Save <?php echo $s['cells']; ?> marks</button>
            <button type="submit" name="cancel" value="1" class="btn btn-secondary">Cancel</button>
        </form>
    </div>
    <?php else: ?>
    <div class="card"><div class="steps2">
        <div class="step"><h3><span>1</span>Download the workbook</h3>
            <p class="note" style="margin:0 0 8px"><b><?php echo $tab_count; ?></b> subject tab<?php echo $tab_count === 1 ? '' : 's'; ?> for <?php echo h($exam['exam_name']); ?> · Class <?php echo h($exam['class_name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?>. Each tab lists <b>only the students who took that subject</b> and carries their marks already entered, so there is nothing to skip over. <b>UID, Sec, Roll and Student are locked</b>; type only in the yellow columns — a number, <b>AB</b> for absent, or leave the cell blank to keep the mark as it is.</p>
            <div class="tabs-preview"><?php foreach ($takers as $sid2 => $n2) {
                $s2 = $subjects[$sid2];
                echo '<span class="' . ($n2 ? '' : 'none') . '" title="' . h($s2['name']) . ($n2 ? ' — ' . $n2 . ' student' . ($n2 === 1 ? '' : 's') : ' — nobody here takes it, so there is no tab') . '">' . h(exam_subject_code($s2)) . ' <small>' . ($n2 ?: '—') . '</small></span>';
            } ?></div>
            <div style="border-top:1px solid var(--ex-border);padding-top:10px">
                <a href="?<?php echo $qs; ?>&download_template=1" class="btn btn-secondary"><i class="fas fa-download"></i> Download .xlsx</a></div>
            <p class="note">Supplementary marks are not in this sheet — enter those in <a href="hs_marks_entry.php?<?php echo $qs; ?>">Marks Entry</a>, they are few.</p></div>
        <div class="step"><h3><span>2</span>Upload the filled workbook</h3>
            <form method="post" enctype="multipart/form-data" class="pf"><?php echo csrf_field(); ?>
                <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id ?: 'all'; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
                <input type="file" name="file" accept=".xlsx" required style="height:auto;padding:8px">
                <div class="acts"><button type="submit" name="upload" value="1" class="btn btn-primary"><i class="fas fa-upload"></i> Upload &amp; preview</button></div></form>
            <p class="note">Every tab of the file is read, so a teacher may delete the tabs that are not theirs. You will see a preview with any problems before anything is saved. Max 2 MB.</p></div>
    </div></div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Full and pass marks of one semester exam, per subject.
 * Every subject carries 40 theory + 20 practical/project, or 35 theory + 30 practical/project: Semester 1 is
 * theory only, Semester 2 has the theory and the practical / project. A subject that has no laboratory
 * practical carries a project instead, so the column applies to every subject.
 * THEORY AND PRACTICAL ARE PASSED SEPARATELY, so each has its own pass marks, and theory is judged semester
 * by semester. The practical columns appear only in the semester that carries the practical.
 * The class always comes from the exam itself, never from the form.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? hs_exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$class_id = $exam ? (int)$exam['class_id'] : (int)($_GET['class_id'] ?? array_key_first(hs_classes()));
$classes = hs_classes();
if (!isset($classes[$class_id])) $class_id = (int)array_key_first($classes);
$exams = hs_exam_list($session_id);
if (!$exam && $exams) { $exam = hs_exam_get((int)$exams[0]['id']); $exam_id = (int)$exam['id']; $class_id = (int)$exam['class_id']; }
$back = "hs_exam_subject_marks.php?exam_id=$exam_id";

$has_practical_target = $exam && (int)$exam['has_practical'] === 1;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $exam) {
    verify_csrf_or_die();
    if (isset($_POST['save_config'])) {
        $r = hs_config_save($exam_id, (array)($_POST['s'] ?? []), $admin_id);
        if ($r['ok']) $_SESSION['success'] = 'Full & pass marks saved for ' . $exam['exam_name'] . ' — ' . $r['saved'] . ' subject' . ($r['saved'] === 1 ? '' : 's') . '.';
        else {
            $names = hs_class_subject_list($session_id, $class_id);
            $_SESSION['error'] = implode('; ', array_map(fn($k, $m) => ($names[$k]['name'] ?? 'Subject') . ': ' . $m, array_keys($r['errors']), $r['errors']));
        }
    } elseif (isset($_POST['copy_from'])) {
        $src = hs_exam_get((int)($_POST['src_exam_id'] ?? 0));
        if (!$src || (int)$src['class_id'] !== $class_id) $_SESSION['error'] = 'Copy from another semester of the same class only.';
        else {
            $rows = [];
            foreach (hs_exam_subjects((int)$src['id']) as $sid => $s) if ($s['configured']) $rows[$sid] = ['theory_full' => $s['theory_full'], 'theory_pass' => $s['theory_pass'], 'practical_full' => $s['practical_full'], 'practical_pass' => $s['practical_pass']];
            if (!$rows) $_SESSION['error'] = $src['exam_name'] . ' has no full marks to copy.';
            else {
                $r = hs_config_save($exam_id, $rows, $admin_id);
                // A practical semester carries a bigger total, so its pass marks do not fit a theory-only semester.
                $dropped = !$has_practical_target && count(array_filter($rows, fn($x) => $x['practical_full'] > 0));
                $_SESSION[$r['ok'] ? 'success' : 'error'] = $r['ok']
                    ? 'Copied ' . $r['saved'] . ' subjects from ' . $src['exam_name'] . '.' . ($dropped ? ' Practical marks were left out — this semester has none.' : '')
                    : 'Copy failed.';
            }
        }
    }
    header('Location: ' . $back); exit;
}

$subjects = $exam ? hs_exam_subjects($exam_id) : [];
$has_practical = $exam && (int)$exam['has_practical'] === 1;
$other_exams = $exam ? array_filter($exams, fn($e) => (int)$e['class_id'] === $class_id && (int)$e['id'] !== $exam_id && (int)$e['subjects_configured'] > 0) : [];
$exam_opts = [];
foreach ($exams as $e) $exam_opts[(int)$e['id']] = 'Class ' . $e['class_name'] . ' — ' . $e['exam_name'];
$configured = count(array_filter($subjects, fn($s) => $s['configured']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Full & Pass Marks</title>
<?php exam_styles('hs'); ?>
<style>
    .ex-table td.tot { font-weight: 700; color: var(--ex-dark); }
    .toolbar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; } .toolbar .fill { display: flex; gap: 6px; align-items: center; font-size: 12.5px; color: #3b5168; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 9px; padding: 6px 10px; } .toolbar .fill input { width: 58px; height: 30px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; }
    .ex-table input[type=checkbox] { width: 17px; height: 17px; }
    .ex-table tr.lab td { background: var(--ex-soft); }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('HS Full & Pass Marks', 'What each subject carries in one semester: theory marks, practical / project marks, and the pass marks of each part separately.', 'fa-sliders-h', ['hs_exams.php' => '<i class="fas fa-clipboard-list"></i> Semester Exams', 'class_subjects.php' => '<i class="fas fa-book"></i> Class Subjects']); ?>
    <?php hs_tabs('hs_exam_subject_marks.php'); ?>
    <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_exam_subject_marks.php', "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div style="min-width:280px"><label>Semester exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? '' : 'No semester exam in this session'); ?></select></div>
    </form>

    <?php if (!$exam): ?>
        <div class="card"><?php exam_guard('No semester exam yet', 'Create the semester exams of Classes XI and XII first.', 'hs_exams.php', 'Semester Exams'); ?></div>
    <?php elseif (!$subjects): ?>
        <div class="card"><?php exam_guard('Class ' . $exam['class_name'] . ' has no exam subjects', 'Assign the subjects this class offers, with the exam tick, before setting full marks.', 'class_subjects.php', 'Class Subjects'); ?></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-sliders-h"></i> <?php echo h($exam['exam_name']); ?> · Class <?php echo h($exam['class_name']); ?>
            <small><?php echo $has_practical ? 'Theory + practical / project' : 'Theory only'; ?> · <?php echo $configured; ?> of <?php echo count($subjects); ?> subjects set</small></h2>
        <form method="post" id="cfg">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
            <div class="toolbar noprint">
                <span class="fill">40-mark subjects: theory <input type="text" id="fT" value="40"> pass <input type="text" id="fTp" value="12"><?php if ($has_practical): ?> · project <input type="text" id="fTpf" value="20"> pass <input type="text" id="fTpp" value="6"><?php endif; ?> <button type="button" class="btn btn-secondary btn-sm" onclick="fill(false)">Apply to the rest</button></span>
                <?php if ($has_practical): ?><span class="fill">35-mark subjects: theory <input type="text" id="fP" value="35"> pass <input type="text" id="fPp2" value="11"> · practical <input type="text" id="fPp" value="30"> pass <input type="text" id="fPs" value="9"> <button type="button" class="btn btn-secondary btn-sm" onclick="fill(true)">Apply to the ticked ones</button></span><?php endif; ?>
                <?php if ($other_exams): ?><span class="fill" style="margin-left:auto">Copy from <select id="src" style="height:30px;border:1px solid #c9d6e2;border-radius:6px"><?php foreach ($other_exams as $o): ?><option value="<?php echo (int)$o['id']; ?>"><?php echo h($o['exam_name']); ?></option><?php endforeach; ?></select><button type="button" class="btn btn-secondary btn-sm" onclick="copyFrom()">Copy</button></span><?php endif; ?>
            </div>
            <table class="ex-table"><thead><tr><th>Subject</th><?php if ($has_practical): ?><th class="num">Lab practical<br><small style="text-transform:none;font-weight:400">35 + 30 subjects</small></th><?php endif; ?><th class="num">Theory full</th><th class="num">Theory pass</th><?php if ($has_practical): ?><th class="num">Practical / Project full</th><th class="num">Practical / Project pass</th><?php endif; ?><th class="num">Total full</th></tr></thead><tbody>
            <?php foreach ($subjects as $sid => $s): ?>
            <tr data-sid="<?php echo $sid; ?>" class="<?php echo $s['configured'] && $s['theory_full'] == 35 ? 'lab' : ''; ?>">
                <td><b><?php echo h($s['name']); ?></b><?php if (!$s['configured']): ?> <span class="chip warn">marks not set</span><?php endif; ?>
                    <?php if (!empty($s['is_practical_row'])): ?><br><small style="color:#7a4a00">This looks like a practical listed as its own subject — set the practical marks on the parent subject instead, and untick it in Class Subjects.</small><?php endif; ?></td>
                <?php if ($has_practical): ?><td class="num"><input type="checkbox" class="hp" title="This subject has a laboratory practical (35 theory + 30 practical)" <?php echo $s['configured'] && $s['theory_full'] == 35 ? 'checked' : ''; ?> onchange="this.closest('tr').classList.toggle('lab', this.checked)"></td><?php endif; ?>
                <td class="num"><input class="m tf" name="s[<?php echo $sid; ?>][theory_full]" value="<?php echo $s['configured'] ? exam_fmt($s['theory_full']) : ''; ?>" inputmode="decimal"></td>
                <td class="num"><input class="m tp" name="s[<?php echo $sid; ?>][theory_pass]" value="<?php echo $s['configured'] ? exam_fmt($s['theory_pass']) : ''; ?>" inputmode="decimal"></td>
                <?php if ($has_practical): ?><td class="num"><input class="m pf" name="s[<?php echo $sid; ?>][practical_full]" value="<?php echo $s['configured'] && $s['practical_full'] > 0 ? exam_fmt($s['practical_full']) : ''; ?>" inputmode="decimal"></td>
                <td class="num"><input class="m pp" name="s[<?php echo $sid; ?>][practical_pass]" value="<?php echo $s['configured'] && $s['practical_full'] > 0 ? exam_fmt($s['practical_pass']) : ''; ?>" inputmode="decimal"></td><?php endif; ?>
                <td class="num tot sum"></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <div style="margin-top:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><button type="submit" name="save_config" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save <?php echo h($exam['exam_name']); ?></button><span class="note" style="margin:0">Every subject the class offers needs its marks here. A subject without a laboratory practical carries a project instead, so the practical / project marks apply to all of them. Theory and practical / project are passed separately, so each carries its own pass marks. A subject left blank is not examined this semester and marks entry refuses it.</span></div>
            <input type="hidden" name="src_exam_id" id="srcId"><input type="hidden" name="copy_from" id="copyFlag" value="" disabled>
        </form>
    </div>
    <p class="note">Marks entry uses these limits, so a wrong figure here shows up on every mark. The practical columns appear only in the semester ticked "practical" on the <a href="hs_exams.php">Semester Exams</a> page.</p>
    <?php endif; ?>
</div>
<script>
function num(i) { return i && !i.disabled ? (parseFloat(i.value) || 0) : 0; }
function recalc(tr) {
    var tf = tr.querySelector('input.tf'), tp = tr.querySelector('input.tp'), pf = tr.querySelector('input.pf'), pp = tr.querySelector('input.pp');
    tr.querySelector('.sum').textContent = (num(tf) + num(pf)) || '';
    tr.querySelectorAll('input.m').forEach(function (i) { i.classList.remove('bad'); });
    if (num(tp) > num(tf)) tp.classList.add('bad');
    if (pp && num(pp) > num(pf)) pp.classList.add('bad');
}
document.querySelectorAll('tr[data-sid]').forEach(function (tr) { recalc(tr); tr.querySelectorAll('input.m').forEach(function (i) { i.addEventListener('input', function () { recalc(tr); }); }); });
function fill(thirtyFive) {
    var el = function (id) { var e = document.getElementById(id); return e ? e.value : ''; };
    var theory = thirtyFive ? el('fP') : el('fT');
    var theoryPass = thirtyFive ? el('fPp2') : el('fTp');
    var prac = thirtyFive ? el('fPp') : el('fTpf');
    var pracPass = thirtyFive ? el('fPs') : el('fTpp');
    document.querySelectorAll('tr[data-sid]').forEach(function (tr) {
        var cb = tr.querySelector('input.hp');
        var isPrac = cb ? cb.checked : false;
        if (cb && isPrac !== thirtyFive) return;   // the ticked rows are the ones with a laboratory practical
        tr.querySelector('input.tf').value = theory;
        tr.querySelector('input.tp').value = theoryPass;
        var pf = tr.querySelector('input.pf'), pp = tr.querySelector('input.pp');
        if (pf && prac !== '') pf.value = prac;
        if (pp && pracPass !== '') pp.value = pracPass;
        recalc(tr);
    });
}
function copyFrom() {
    var s = document.getElementById('src'); if (!s || !s.value) return;
    if (!confirm('Replace the full & pass marks of this semester with ' + s.options[s.selectedIndex].text + '?')) return;
    document.getElementById('srcId').value = s.value;
    var f = document.getElementById('copyFlag'); f.disabled = false; f.value = '1';
    document.getElementById('cfg').submit();
}
document.querySelectorAll('input.m').forEach(function (i) {
    i.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return; e.preventDefault();
        var tr = i.closest('tr').nextElementSibling; if (!tr) return;
        var n = tr.querySelector('input.' + i.classList[1]); if (n && !n.disabled) { n.focus(); n.select(); }
    });
});
</script>
</body>
</html>

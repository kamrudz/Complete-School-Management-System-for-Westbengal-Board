<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Semester exams the school conducts: Class XI only (Semester 1 and Semester 2). Class XII sits Semester 3
 * and 4 with the board, which issues those admit cards and results, so they are not kept here.
 * Semester 1 is theory only; Semester 2 carries the practical / project marks as well.
 * Add, edit, publish and delete happen on this page — publishing is what makes a result public.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$classes = hs_exam_classes();   // the school conducts Class XI only
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? array_key_first($classes));
if (!isset($classes[$class_id])) $class_id = (int)array_key_first($classes);
$back = "hs_exams.php?session_id=$session_id&class_id=$class_id";

/** Validate one exam form. Returns ['data' => …] or ['error' => message]. */
function hs_exam_clean(array $in, int $session_id, int $exclude_id = 0): array {
    $class_id = (int)($in['class_id'] ?? 0);
    $classes = hs_exam_classes();
    if (!isset($classes[$class_id])) return ['error' => 'The school conducts Class XI semester exams only — Class XII is examined by the board.'];
    $semester = (int)($in['semester'] ?? 0);
    if (!in_array($semester, hs_school_semesters($class_id), true)) return ['error' => 'Class ' . $classes[$class_id]['name'] . ' sits semesters ' . implode(' and ', hs_school_semesters($class_id)) . ' only.'];
    $name = trim((string)($in['exam_name'] ?? ''));
    if ($name === '') $name = HS_SEMESTERS[$semester] . ' Examination';
    if (mb_strlen($name) > 100) return ['error' => 'Exam name is too long (up to 100 characters).'];
    if (!preg_match('/^[\p{L}\p{N} .\-\/()]+$/u', $name)) return ['error' => 'Exam name: letters, numbers, spaces and . - / ( ) only.'];
    $year = trim((string)($in['academic_year'] ?? ''));
    if ($year !== '' && !preg_match('/^\d{4}$/', $year)) return ['error' => 'Academic year must be four digits.'];
    $from = trim((string)($in['exam_date_from'] ?? '')); $to = trim((string)($in['exam_date_to'] ?? ''));
    foreach ([$from, $to] as $d) if ($d !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) return ['error' => 'Dates must be YYYY-MM-DD.'];
    if ($from !== '' && $to !== '' && $to < $from) return ['error' => 'The end date is before the start date.'];
    if (db_get_row('SELECT id FROM hs_exam WHERE session_id = ? AND class_id = ? AND semester = ? AND id <> ?', 'iiii', $session_id, $class_id, $semester, $exclude_id)) {
        return ['error' => 'Class ' . $classes[$class_id]['name'] . ' already has a ' . HS_SEMESTERS[$semester] . ' exam in this session.'];
    }
    return ['data' => ['class_id' => $class_id, 'semester' => $semester, 'exam_name' => $name,
        'academic_year' => $year !== '' ? $year : null, 'has_practical' => empty($in['has_practical']) ? 0 : 1,
        'exam_date_from' => $from ?: null, 'exam_date_to' => $to ?: null]];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['add_exam'])) {
        $r = hs_exam_clean($_POST, $session_id);
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else {
            $id = db_insert('hs_exam', $r['data'] + ['session_id' => $session_id]);
            log_action($admin_id, 'HS_EXAM_ADDED', 'hs_exam', $id, null, $r['data']);
            $_SESSION['success'] = $r['data']['exam_name'] . ' added for Class ' . hs_class_name((int)$r['data']['class_id']) . '. Next: set its full & pass marks.';
        }
    } elseif (isset($_POST['update_exam'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = hs_exam_get($id);
        $r = ($old && (int)$old['session_id'] === $session_id) ? hs_exam_clean($_POST, $session_id, $id) : ['error' => 'Exam not found.'];
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else {
            db_update('hs_exam', $r['data'], ['id' => $id], 'i');
            log_action($admin_id, 'HS_EXAM_UPDATED', 'hs_exam', $id, $old, $r['data']);
            $_SESSION['success'] = $r['data']['exam_name'] . ' updated.';
        }
    } elseif (isset($_POST['toggle_publish'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = hs_exam_get($id);
        if (!$old) $_SESSION['error'] = 'Exam not found.';
        else {
            $new = (int)$old['is_published'] ? 0 : 1;
            db_update('hs_exam', ['is_published' => $new], ['id' => $id], 'i');
            log_action($admin_id, $new ? 'HS_EXAM_PUBLISHED' : 'HS_EXAM_UNPUBLISHED', 'hs_exam', $id);
            $_SESSION['success'] = $old['exam_name'] . ($new ? ' is now visible on the public result page.' : ' is hidden from the public result page.');
        }
    } elseif (isset($_POST['delete_exam'])) {
        $id = (int)($_POST['exam_id'] ?? 0); $old = hs_exam_get($id);
        if (!$old) $_SESSION['error'] = 'Exam not found.';
        else {
            $deps = hs_exam_dependencies($id);
            if (!empty($deps['Marks']) && trim((string)($_POST['confirm_name'] ?? '')) !== $old['exam_name']) {
                $_SESSION['error'] = 'To delete ' . $old['exam_name'] . ' and its ' . $deps['Marks'] . ' marks rows, type the exam name exactly.';
            } else {
                db_begin_transaction();
                try {
                    foreach (['exam_routine', 'exam_seating_plan', 'exam_duty_roster'] as $t) db_execute("DELETE FROM $t WHERE exam_id = ? AND exam_source = 'hs'", 'i', $id);
                    db_execute('DELETE FROM hs_exam WHERE id = ?', 'i', $id);   // marks and config cascade
                    db_commit();
                    log_action($admin_id, 'HS_EXAM_DELETED', 'hs_exam', $id, $old + ['dependencies' => $deps], null);
                    $_SESSION['success'] = $old['exam_name'] . ' deleted' . ($deps ? ' with ' . implode(', ', array_map(fn($k, $v) => "$v $k", array_keys($deps), $deps)) : '') . '.';
                } catch (Throwable $e) { db_rollback(); error_log('hs exam delete: ' . $e->getMessage()); $_SESSION['error'] = 'Delete failed.'; }
            }
        }
    }
    header('Location: ' . $back); exit;
}

$exams = hs_exam_list($session_id);
$edit = null;
if (isset($_GET['edit'])) { $edit = hs_exam_get((int)$_GET['edit']); if ($edit && (int)$edit['session_id'] !== $session_id) $edit = null; }
$deps_of = []; foreach ($exams as $e) $deps_of[(int)$e['id']] = hs_exam_dependencies((int)$e['id']);
$subject_count = count(hs_class_subject_list($session_id, $class_id));
$missing = [];   // semesters not created yet, per class
foreach ($classes as $cid => $c) foreach (hs_school_semesters($cid) as $sem) if (!hs_exam_of_semester($session_id, $cid, $sem)) $missing[$cid][] = $sem;
$fmt = fn($d) => $d ? date('d M', strtotime($d)) : '';
$year_guess = preg_replace('/\D.*$/', '', (string)($sessions[$session_id] ?? ''));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Semester Exams</title>
<?php exam_styles('hs'); ?>
<style>
    .two { display: grid; grid-template-columns: 1fr 340px; gap: 18px; align-items: start; } @media (max-width: 950px) { .two { grid-template-columns: 1fr; } }
    .ex-table tr.editing td { background: #fff9ec; } .ex-table .acts { white-space: nowrap; } .ex-table .acts form { display: inline; }
    .ex-table .name { font-weight: 700; color: #222; } .ex-table .name small { display: block; font-weight: 400; color: #6b7d90; font-size: 11px; }
    .sem { display: inline-block; min-width: 26px; text-align: center; font-weight: 800; color: var(--ex-dark); }
    .pub { border: 0; cursor: pointer; }
    .clstab { display: flex; gap: 6px; margin-bottom: 12px; } .clstab a { padding: 7px 16px; border-radius: 9px; border: 1px solid var(--ex-border); background: #fff; color: var(--ex-dark); text-decoration: none; font-weight: 700; font-size: 13px; } .clstab a.on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('HS Semester Exams', 'Class XI, WBCHSE semester system: Semester 1 (theory) and Semester 2 (theory + practical). Class XII is examined by the board, so its semesters are not kept here.', 'fa-graduation-cap', ['exams.php' => '<i class="fas fa-clipboard-list"></i> Exams (V–X)']); ?>
    <?php hs_tabs('hs_exams.php'); ?>
    <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_exams.php', "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
    </form>
    <?php if (count($classes) > 1): ?><div class="clstab"><?php foreach ($classes as $cid => $c): ?><a href="?session_id=<?php echo $session_id; ?>&class_id=<?php echo $cid; ?>" class="<?php echo $cid === $class_id ? 'on' : ''; ?>">Class <?php echo h($c['name']); ?></a><?php endforeach; ?></div><?php endif; ?>

    <?php if (!empty($missing[$class_id])): ?>
        <?php exam_guard('Class ' . $classes[$class_id]['name'] . ' is missing a semester exam',
            'Semester ' . implode(' and ', $missing[$class_id]) . ' not created yet — the year\'s result needs both semesters.'); ?>
    <?php endif; ?>
    <?php if ($subject_count === 0): ?>
        <?php exam_guard('Class ' . $classes[$class_id]['name'] . ' has no exam subjects', 'Assign the subjects this class offers before setting full marks.', 'class_subjects.php', 'Class Subjects'); ?>
    <?php endif; ?>

    <div class="two">
        <div class="card">
            <h2><i class="fas fa-list-ol"></i> <?php echo count($exams); ?> semester exam<?php echo count($exams) === 1 ? '' : 's'; ?> <small>Class XI, <?php echo h($sessions[$session_id] ?? ''); ?></small></h2>
            <?php if (!$exams): ?><div class="ex-empty"><i class="fas fa-graduation-cap"></i>No semester exam yet — add Semester 1 and Semester 2 for Class XI.</div>
            <?php else: ?>
            <table class="ex-table"><thead><tr><th>Class</th><th class="num">Sem</th><th>Exam</th><th>Dates</th><th class="num">Practical / Project</th><th>Full marks set</th><th>Marks entered</th><th class="num">Public</th><th></th></tr></thead><tbody>
            <?php foreach ($exams as $e): $id = (int)$e['id']; $d = $deps_of[$id]; $ecls = (int)$e['class_id']; ?>
            <tr class="<?php echo $edit && (int)$edit['id'] === $id ? 'editing' : ''; ?>">
                <td><b>Class <?php echo h($e['class_name']); ?></b></td>
                <td class="num"><span class="sem"><?php echo (int)$e['semester']; ?></span></td>
                <td class="name"><?php echo h($e['exam_name']); ?><small><?php echo h($e['academic_year'] ?: $e['session_name']); ?></small></td>
                <td><?php echo $e['exam_date_from'] ? h($fmt($e['exam_date_from']) . ($e['exam_date_to'] && $e['exam_date_to'] !== $e['exam_date_from'] ? ' – ' . $fmt($e['exam_date_to']) : '')) : '<span style="color:#aaa">—</span>'; ?></td>
                <td class="num"><?php echo (int)$e['has_practical'] ? '<span class="chip ok">practical / project</span>' : '<span class="chip off">theory only</span>'; ?></td>
                <td><a href="hs_exam_subject_marks.php?exam_id=<?php echo $id; ?>" class="chip <?php echo (int)$e['subjects_configured'] ? 'ok' : 'bad'; ?>" style="text-decoration:none"><?php echo (int)$e['subjects_configured']; ?> subject<?php echo (int)$e['subjects_configured'] === 1 ? '' : 's'; ?></a></td>
                <td><a href="hs_marks_entry.php?exam_id=<?php echo $id; ?>" class="chip <?php echo (int)$e['subjects_with_marks'] ? 'ok' : 'off'; ?>" style="text-decoration:none"><?php echo (int)$e['subjects_with_marks']; ?> subject<?php echo (int)$e['subjects_with_marks'] === 1 ? '' : 's'; ?> · <?php echo (int)$e['marks_rows']; ?> rows</a></td>
                <td class="num"><form method="post" onsubmit="return confirm('<?php echo (int)$e['is_published'] ? 'Hide this semester result from the public page?' : 'Publish this semester result on the public page?'; ?>');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="exam_id" value="<?php echo $id; ?>"><button type="submit" name="toggle_publish" value="1" class="chip pub <?php echo (int)$e['is_published'] ? 'ok' : 'off'; ?>" title="Click to <?php echo (int)$e['is_published'] ? 'unpublish' : 'publish'; ?>"><i class="fas <?php echo (int)$e['is_published'] ? 'fa-eye' : 'fa-eye-slash'; ?>"></i> <?php echo (int)$e['is_published'] ? 'Published' : 'Hidden'; ?></button></form></td>
                <td class="acts"><a href="?session_id=<?php echo $session_id; ?>&class_id=<?php echo $ecls; ?>&edit=<?php echo $id; ?>#form" class="btn btn-secondary btn-sm" title="Edit"><i class="fas fa-pen"></i></a>
                    <button type="button" class="btn btn-danger btn-sm" title="Delete" onclick="hsDelete(<?php echo $id; ?>, <?php echo h(json_encode($e['exam_name'])); ?>, <?php echo h(json_encode($d)); ?>)"><i class="fas fa-trash"></i></button></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <p class="note">Semester 2 is where the practical / project marks are entered. Publish only after the tabulation has been checked — Class XII results come from the board.</p>
            <?php endif; ?>
        </div>
        <div class="card" id="form">
            <h2><i class="fas <?php echo $edit ? 'fa-pen' : 'fa-plus'; ?>"></i> <?php echo $edit ? 'Edit ' . h($edit['exam_name']) : 'Add semester exam'; ?></h2>
            <form method="post" class="pf">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
                <?php if ($edit): ?><input type="hidden" name="exam_id" value="<?php echo (int)$edit['id']; ?>"><?php endif; ?>
                <label>Class</label>
                <select name="class_id" id="hsClass" onchange="hsSem()"><?php foreach ($classes as $cid => $c): ?><option value="<?php echo $cid; ?>" data-sem="<?php echo h(implode(',', $c['semesters'])); ?>" <?php echo (int)($edit['class_id'] ?? $class_id) === $cid ? 'selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select>
                <label>Semester</label><select name="semester" id="hsSem" onchange="hsName()"></select>
                <label>Exam name</label><input type="text" name="exam_name" id="hsName" maxlength="100" value="<?php echo h($edit['exam_name'] ?? ''); ?>" placeholder="Semester 1 Examination">
                <div class="row"><div><label>From</label><input type="date" name="exam_date_from" value="<?php echo h($edit['exam_date_from'] ?? ''); ?>"></div><div><label>To</label><input type="date" name="exam_date_to" value="<?php echo h($edit['exam_date_to'] ?? ''); ?>"></div></div>
                <label>Academic year</label><input type="text" name="academic_year" maxlength="4" inputmode="numeric" value="<?php echo h($edit['academic_year'] ?? $year_guess); ?>" placeholder="<?php echo h($year_guess); ?>">
                <label class="chk"><input type="checkbox" name="has_practical" id="hsPrac" value="1" <?php echo ($edit ? (int)$edit['has_practical'] : 0) ? 'checked' : ''; ?>> Practical / project marks are taken in this semester</label>
                <div class="acts"><button type="submit" name="<?php echo $edit ? 'update_exam' : 'add_exam'; ?>" value="1" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo $edit ? 'Save' : 'Add exam'; ?></button><?php if ($edit): ?><a href="<?php echo h($back); ?>" class="btn btn-secondary">Cancel</a><?php endif; ?></div>
            </form>
            <p class="note">Class XI sits Semester 1 and Semester 2. The practical tick is set for Semester 2 by default, because that is when the practical / project marks are taken.</p>
        </div>
    </div>
</div>

<div class="modal" id="hsDel"><div class="box">
    <h3 style="margin:0 0 8px;color:#b71c1c"><i class="fas fa-exclamation-triangle"></i> Delete semester exam</h3>
    <p id="hsDelText" style="font-size:13.5px"></p>
    <form method="post" class="pf"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="exam_id" id="hsDelId">
        <div id="hsDelConfirm" style="display:none"><label>Type the exam name to confirm</label><input type="text" name="confirm_name" autocomplete="off"></div>
        <div class="acts"><button type="submit" name="delete_exam" value="1" class="btn btn-danger"><i class="fas fa-trash"></i> Delete</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('hsDel').classList.remove('open')">Cancel</button></div>
    </form>
</div></div>
<script>
var hsEdit = <?php echo $edit ? json_encode(['semester' => (int)$edit['semester']]) : 'null'; ?>;
function hsSem() {
    var cls = document.getElementById('hsClass'), sel = document.getElementById('hsSem');
    var sems = (cls.options[cls.selectedIndex].dataset.sem || '').split(',').filter(Boolean);
    var keep = hsEdit ? String(hsEdit.semester) : sel.value;
    sel.innerHTML = '';
    sems.forEach(function (s) { var o = document.createElement('option'); o.value = s; o.textContent = 'Semester ' + s; if (s === keep) o.selected = true; sel.appendChild(o); });
    hsName();
}
function hsName() {
    var sel = document.getElementById('hsSem'), name = document.getElementById('hsName'), prac = document.getElementById('hsPrac');
    var suggested = 'Semester ' + sel.value + ' Examination';
    if (!name.value || /^Semester \d+ Examination$/.test(name.value)) name.value = suggested;
    if (!hsEdit) prac.checked = (parseInt(sel.value, 10) % 2 === 0);   // practical rides the even semester
}
hsSem();
function hsDelete(id, name, deps) {
    var keys = Object.keys(deps), t = 'Delete "' + name + '"?';
    if (keys.length) t += ' This also removes: ' + keys.map(function (k) { return deps[k] + ' ' + k; }).join(', ') + '.';
    document.getElementById('hsDelId').value = id;
    document.getElementById('hsDelText').textContent = t;
    document.getElementById('hsDelConfirm').style.display = deps['Marks'] ? '' : 'none';
    document.getElementById('hsDel').classList.add('open');
}
document.getElementById('hsDel').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

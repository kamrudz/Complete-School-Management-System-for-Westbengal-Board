<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Marks entry for one semester exam × subject.
 * Only the students who took that subject are listed (their combination decides it).
 * Theory is always entered; the practical / project column appears in the semester that carries it —
 * a subject without a laboratory practical carries a project instead. Supplementary is the re-examination mark — the
 * better of theory and supplementary is what counts in the result.
 * Limits come from Full & Pass Marks; nothing is written unless every row on the page is valid.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? hs_exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = hs_exam_list($session_id);
if (!$exam && $exams) { $exam = hs_exam_get((int)$exams[0]['id']); $exam_id = (int)$exam['id']; }
$class_id = $exam ? (int)$exam['class_id'] : (int)array_key_first(hs_classes());
$classes = hs_classes();
$sections = exam_sections($session_id, $class_id);
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? '');
$all_sections = $section_raw === 'all';
$section_id = $all_sections ? null : (int)$section_raw;
if ($section_id && !isset($sections[$section_id])) $section_id = 0;
$subject_id = (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0);
$subjects = $exam ? hs_exam_subjects($exam_id) : [];
$subject = $subjects[$subject_id] ?? null;
$ready = $exam && ($all_sections || $section_id) && $subject;
$qs = "exam_id=$exam_id&section_id=" . ($all_sections ? 'all' : (int)$section_id);

$errors = []; $posted = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marks'])) {
    verify_csrf_or_die();
    if (!$ready) { $_SESSION['error'] = 'Choose a semester exam, a section and a subject first.'; header("Location: hs_marks_entry.php?$qs&subject_id=$subject_id"); exit; }
    $posted = (array)($_POST['m'] ?? []);
    $r = hs_marks_save_rows($exam_id, $subject_id, $posted, $admin_id);
    if ($r['ok']) {
        $_SESSION['success'] = $subject['name'] . ' · ' . $exam['exam_name'] . ': ' . $r['saved'] . ' saved' . ($r['cleared'] ? ', ' . $r['cleared'] . ' cleared' : '') . '.';
        header("Location: hs_marks_entry.php?$qs&subject_id=$subject_id"); exit;
    }
    $errors = $r['errors'];
}

$students = $ready ? hs_students($session_id, $class_id, $section_id) : [];
$choice = $ready ? hs_student_subjects($session_id, $class_id, $section_id) : [];
$marks = $ready ? hs_marks($exam_id, $subject_id) : [];
$status = $exam ? hs_entry_status($exam_id) : [];
$listed = [];
if ($ready) foreach ($students as $uid => $st) if (isset($choice[$uid][$subject_id])) $listed[$uid] = $st;
$has_practical = $subject && $subject['has_practical'];
$last = null;
if ($ready) foreach ($marks as $uid => $bySub) { $m = $bySub[$subject_id] ?? null; if ($m && (!$last || ($m['updated_at'] ?? $m['created_at']) > ($last['updated_at'] ?? $last['created_at']))) $last = $m; }
$val = function (string $uid, string $k) use ($posted, $marks, $subject_id) {   // posted value wins after a failed save
    if ($posted) return (string)($posted[$uid][$k] ?? '');
    $m = $marks[$uid][$subject_id] ?? null; if (!$m) return '';
    if ($k === 'theory_absent') return (int)$m['theory_absent'] ? '1' : '';
    if ($k === 'practical_absent') return (int)$m['practical_absent'] ? '1' : '';
    $col = ['theory' => 'theory_marks', 'supplementary' => 'theory_supplementary_marks', 'practical' => 'practical_marks'][$k] ?? null;
    return ($col && $m[$col] !== null) ? exam_fmt($m[$col]) : '';
};
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = 'Class ' . $e['class_name'] . ' — ' . $e['exam_name'];
$subject_opts = []; foreach ($subjects as $sid => $s) $subject_opts[$sid] = $s['name'] . ($s['configured'] ? '' : ' (no full marks)');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Marks Entry</title>
<?php exam_styles('hs'); ?>
<style>
    #grid th, #grid td { border: 1px solid #dde7ec; } #grid th { border-bottom: 2px solid var(--ex-border); } #grid td.sep, #grid th.sep { border-left: 2px solid var(--ex-muted); }
    .ex-table td.err { background: #fff2f2; } .ex-table td .em { display: block; color: #b71c1c; font-size: 11px; }
    .ex-table td.st { font-size: 11px; font-weight: 700; } .ex-table td.st.p { color: #1b7a3a; } .ex-table td.st.f { color: #b71c1c; } .ex-table td.st.a { color: #616161; }
    .ex-table tr.ab input.m { background: #f2f2f2; color: #999; }
    .sticky { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 2px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .kb { font-size: 11.5px; color: #6b7d90; } .kb kbd { background: #eef1f4; border: 1px solid #d5dde5; border-radius: 4px; padding: 0 5px; font-size: 11px; }
    .meta { font-size: 12px; color: #6b7d90; margin-left: auto; }
    .supp { width: 58px !important; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('HS Marks Entry', 'One semester exam, one subject at a time. Only the students who took that subject are listed.', 'fa-edit', ['hs_bulk_marks_upload.php' => '<i class="fas fa-file-excel"></i> Bulk upload', 'hs_exam_subject_marks.php' => '<i class="fas fa-sliders-h"></i> Full & Pass Marks']); ?>
    <?php hs_tabs('hs_marks_entry.php'); ?>
    <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_marks_entry.php', "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>
    <?php if ($errors): $off_list = array_diff_key($errors, $listed, ['_' => 1]); ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Nothing was saved — fix the rows marked in red<?php if (isset($errors['_'])) echo ': ' . h($errors['_']); ?>.
        <?php foreach ($off_list as $u => $m) echo ' ' . h($u) . ': ' . h($m) . '.'; ?></div>
    <?php endif; ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div style="min-width:260px"><label>Semester exam</label><select name="exam_id" onchange="this.form.section_id.value='';this.form.subject_id.value='';this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No semester exam in this session'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $exam ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $all_sections ? 'all' : ($section_id ?: ''), 'Select section'); ?></select></div>
        <div><label>Subject</label><select name="subject_id" onchange="this.form.submit()" <?php echo $exam ? '' : 'disabled'; ?>><?php echo exam_options($subject_opts, $subject_id, 'Select subject'); ?></select></div>
    </form>

    <?php if ($exam && $subjects): ?>
    <div class="strip">
        <?php foreach ($status as $sid => $st): $cls = !$st['configured'] ? 'nocfg' : ($st['total'] && $st['done'] >= $st['total'] ? 'done' : ($st['done'] ? 'part' : '')); ?>
        <a href="?<?php echo $qs; ?>&subject_id=<?php echo $sid; ?>" class="<?php echo $cls . ($sid === $subject_id ? ' on' : ''); ?>" title="<?php echo $st['configured'] ? $st['done'] . ' of ' . $st['total'] . ' entered (whole class)' : 'Full marks not set'; ?>"><?php echo $st['configured'] ? ($st['total'] && $st['done'] >= $st['total'] ? '<i class="fas fa-check"></i> ' : ($st['done'] ? '<i class="fas fa-adjust"></i> ' : '')) : '<i class="fas fa-ban"></i> '; ?><?php echo h($subjects[$sid]['name']); ?> <small><?php echo $st['configured'] ? $st['done'] . '/' . $st['total'] : 'no FM'; ?></small></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!$exam): ?>
        <div class="card"><?php exam_guard('No semester exam yet', 'Create the semester exams of Classes XI and XII first.', 'hs_exams.php', 'Semester Exams'); ?></div>
    <?php elseif (!$subjects): ?>
        <div class="card"><?php exam_guard('Class ' . $exam['class_name'] . ' has no exam subjects', 'Assign this class its subjects first.', 'class_subjects.php', 'Class Subjects'); ?></div>
    <?php elseif (!$ready): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-edit"></i><?php echo !($all_sections || $section_id) ? 'Select a section (or all sections).' : 'Select a subject from the strip above.'; ?></div></div>
    <?php elseif (!$subject['configured']): ?>
        <div class="card"><?php exam_guard('Full marks are not set for ' . $subject['name'], 'Set the theory, practical and pass marks of this subject in ' . $exam['exam_name'] . ' before entering marks.', "hs_exam_subject_marks.php?exam_id=$exam_id", 'Full & Pass Marks'); ?></div>
    <?php elseif (!$listed): ?>
        <div class="card"><?php exam_guard('Nobody takes ' . $subject['name'] . ' here', 'No student of this section has ' . $subject['name'] . ' in their combination.', "hs_subjects.php?session_id=$session_id&class_id=$class_id", 'Subject Combination'); ?></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-edit"></i> <?php echo h($exam['exam_name']); ?> · Class <?php echo h($exam['class_name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?> · <?php echo h($subject['name']); ?>
            <small>Theory <?php echo exam_fmt($subject['theory_full']); ?> (pass <?php echo exam_fmt($subject['theory_pass']); ?>)<?php if ($has_practical): ?> + Practical / Project <?php echo exam_fmt($subject['practical_full']); ?> (pass <?php echo exam_fmt($subject['practical_pass']); ?>)<?php endif; ?> — each part is passed on its own</small></h2>
        <form method="post" id="mf" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="section_id" value="<?php echo $all_sections ? 'all' : (int)$section_id; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
            <table class="ex-table" id="grid"><thead><tr>
                <th class="num">#</th><th class="num">Class</th><th class="num">Sec</th><th class="num">Roll</th><th>Student</th><th>Father</th>
                <th class="num sep">Theory <small>/<?php echo exam_fmt($subject['theory_full']); ?></small></th>
                <th class="num">Suppl. <small>re-exam</small></th>
                <?php if ($has_practical): ?><th class="num">Practical / Project <small>/<?php echo exam_fmt($subject['practical_full']); ?></small></th><?php endif; ?>
                <th class="num">Abs T</th><?php if ($has_practical): ?><th class="num">Abs P</th><?php endif; ?>
                <th class="num sep">Total</th><th class="num">Status</th>
            </tr></thead><tbody>
            <?php $i = 0; foreach ($listed as $uid => $st): $i++; $e = $errors[$uid] ?? null; $tab = $val($uid, 'theory_absent') === '1'; $pab = $val($uid, 'practical_absent') === '1'; ?>
            <tr data-uid="<?php echo h($uid); ?>" class="<?php echo $tab ? 'ab' : ''; ?>">
                <td class="num"><?php echo $i; ?></td><td class="num"><?php echo h($exam['class_name']); ?></td><td class="num"><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['roll']); ?></td>
                <td><b><?php echo h($st['name']); ?></b><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($uid); ?><?php echo $st['reg_no'] !== '' ? ' · Reg ' . h($st['reg_no']) : ''; ?></small></td>
                <td style="color:#4d6178"><?php echo h($st['father']); ?></td>
                <td class="num sep <?php echo $e ? 'err' : ''; ?>"><input class="m th" name="m[<?php echo h($uid); ?>][theory]" value="<?php echo h($val($uid, 'theory')); ?>" inputmode="decimal" data-max="<?php echo $subject['theory_full']; ?>" <?php echo $tab ? 'disabled' : ''; ?>><?php if ($e): ?><span class="em"><?php echo h($e); ?></span><?php endif; ?></td>
                <td class="num"><input class="m supp sp" name="m[<?php echo h($uid); ?>][supplementary]" value="<?php echo h($val($uid, 'supplementary')); ?>" inputmode="decimal" data-max="<?php echo $subject['theory_full']; ?>" <?php echo $tab ? 'disabled' : ''; ?>></td>
                <?php if ($has_practical): ?><td class="num"><input class="m pr" name="m[<?php echo h($uid); ?>][practical]" value="<?php echo h($val($uid, 'practical')); ?>" inputmode="decimal" data-max="<?php echo $subject['practical_full']; ?>" <?php echo $pab ? 'disabled' : ''; ?>></td><?php endif; ?>
                <td class="num"><input type="checkbox" class="abt" name="m[<?php echo h($uid); ?>][theory_absent]" value="1" <?php echo $tab ? 'checked' : ''; ?> title="Absent in theory"></td>
                <?php if ($has_practical): ?><td class="num"><input type="checkbox" class="abp" name="m[<?php echo h($uid); ?>][practical_absent]" value="1" <?php echo $pab ? 'checked' : ''; ?> title="Absent in the practical / project"></td><?php endif; ?>
                <td class="num tot sep"></td><td class="num st"></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <div class="sticky">
                <button type="submit" name="save_marks" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save <?php echo count($listed); ?> students</button>
                <span class="kb"><kbd>Enter</kbd>/<kbd>↓</kbd> next student · blank = not entered · the supplementary box opens only when the theory mark is below the pass marks</span>
                <?php if ($last): ?><span class="meta"><i class="fas fa-history"></i> Last saved <?php echo date('d M Y, g:i a', strtotime($last['updated_at'] ?? $last['created_at'])); ?><?php echo $last['entered_by_name'] ? ' by ' . h($last['entered_by_name']) : ''; ?></span><?php endif; ?>
            </div>
        </form>
    </div>
    <?php endif; ?>
</div>
<script>
(function () {
    var pass = <?php echo json_encode($subject ? (float)$subject['pass'] : 0); ?>, hasP = <?php echo $has_practical ? 'true' : 'false'; ?>;
    var passTheory = <?php echo json_encode($subject ? (float)$subject['theory_pass'] : 0); ?>, passPrac = <?php echo json_encode($subject ? (float)$subject['practical_pass'] : 0); ?>;
    function row(tr) {
        var th = tr.querySelector('input.th'), sp = tr.querySelector('input.sp'), pr = tr.querySelector('input.pr');
        var abt = tr.querySelector('.abt').checked, abp = tr.querySelector('.abp') ? tr.querySelector('.abp').checked : false;
        var tot = tr.querySelector('.tot'), st = tr.querySelector('.st');
        th.disabled = abt; if (pr) pr.disabled = abp;
        // supplementary is the second chance: it opens only when the theory mark is below the pass marks, or the student was absent
        var theoryTyped = th.value.trim() !== '', failedTheory = theoryTyped && (parseFloat(th.value) || 0) < passTheory;
        sp.disabled = !(abt || failedTheory);
        if (sp.disabled && sp.value.trim() !== '') sp.value = '';
        sp.title = sp.disabled ? (theoryTyped ? 'Theory is a pass — no supplementary' : 'Enter the theory mark first') : 'Supplementary (re-exam) mark';
        tr.classList.toggle('ab', abt);
        [th, sp, pr].forEach(function (i) { if (!i) return; var v = i.value.trim(), mx = parseFloat(i.dataset.max); i.classList.toggle('bad', v !== '' && (!/^\d{1,3}(\.\d{1,2})?$/.test(v) || parseFloat(v) > mx)); });
        st.className = 'num st';
        var typed = (!abt && (th.value.trim() !== '' || sp.value.trim() !== '')) || (pr && !abp && pr.value.trim() !== '');
        if (abt && (!hasP || abp)) { tot.textContent = 'AB'; st.textContent = 'Absent'; st.classList.add('a'); return; }
        if (!typed && !abt && !abp) { tot.textContent = ''; st.textContent = ''; return; }
        var theory = abt ? 0 : Math.max(parseFloat(th.value) || 0, parseFloat(sp.value) || 0);
        var prac = (pr && !abp) ? (parseFloat(pr.value) || 0) : 0;
        var t = theory + prac; tot.textContent = Math.round(t * 100) / 100;
        var theoryOk = !abt && theory >= passTheory;
        var pracOk = !hasP || (!abp && prac >= passPrac);
        st.textContent = theoryOk && pracOk ? 'Pass' : (!theoryOk && !pracOk ? 'Fail T+P' : (!theoryOk ? 'Fail theory' : 'Fail pract.'));
        st.classList.add(theoryOk && pracOk ? 'p' : 'f');
    }
    var rows = Array.prototype.slice.call(document.querySelectorAll('#grid tbody tr'));
    rows.forEach(function (tr) { row(tr); tr.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', function () { row(tr); }); i.addEventListener('change', function () { row(tr); }); }); });
    document.querySelectorAll('#grid input.m').forEach(function (i) {
        i.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
            e.preventDefault();
            var tr = i.closest('tr'), cls = i.classList[1], dir = e.key === 'ArrowUp' ? -1 : 1, idx = rows.indexOf(tr) + dir;
            while (idx >= 0 && idx < rows.length) { var n = rows[idx].querySelector('input.' + cls); if (n && !n.disabled) { n.focus(); n.select(); return; } idx += dir; }
        });
    });
    var f = document.getElementById('mf');
    if (f) { var dirty = false; f.addEventListener('input', function () { dirty = true; }); window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } }); f.addEventListener('submit', function () { dirty = false; }); }
    var first = document.querySelector('#grid input.th:not(:disabled)'); if (first && !document.querySelector('.err')) first.focus();
})();
</script>
</body>
</html>

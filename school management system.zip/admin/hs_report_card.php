<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hs_result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Class XI mark sheet — one A4 LANDSCAPE page per student, in the WBCHSE layout the school itself issues:
 * school heading with the logo, the student's details with the WBCHSE registration number and year, then
 * FULL MARKS / PASS MARKS / MARKS-GRADE (Semester 1, its supplementary, Semester 2, its supplementary and the
 * practical / oral / project) per subject, grouped as COMPULSORY LANGUAGE · COMPULSORY ELECTIVE · OPTIONAL
 * ELECTIVE, and the footer with Result, Overall Grade and the Grand Total (the best five subjects).
 * The school logo sits behind the page as a watermark and the student's photograph in the top right corner.
 * Every figure comes from hs_result_helper.php — the one place the rules live.
 */
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$classes = hs_exam_classes();                       // Class XI: Class XII is examined by the board
$class_id = (int)($_GET['class_id'] ?? 0);
if (!isset($classes[$class_id])) $class_id = (int)(array_key_first($classes) ?? 0);
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw;
if ($section_id && !isset($sections[$section_id])) $section_id = null;
$only = student_uid_clean((string)($_GET['uid'] ?? ''));
$print = !empty($_GET['print']);
$qs = "session_id=$session_id&class_id=$class_id&section_id=" . ($section_id ?: 'all') . ($only !== '' ? '&uid=' . urlencode($only) : '');

$res = $class_id ? hs_result_year($session_id, $class_id, $section_id, true) : null;   // also those promoted or passed out since
$students = $res['students'] ?? [];
$names = []; foreach ($res['subjects'] ?? [] as $sid => $s) $names[$sid] = $s['name'];
if ($only !== '') $students = isset($students[$only]) ? [$only => $students[$only]] : [];
$semesters = $class_id ? hs_school_semesters($class_id) : [1, 2];
[$S1, $S2] = [$semesters[0] ?? 1, $semesters[1] ?? 2];
$exam_year = '';
foreach ($res['exams'] ?? [] as $e) { $exam_year = (string)($e['academic_year'] ?: ''); break; }
if ($exam_year === '') $exam_year = exam_session_name($session_id);

$school = db_get_row('SELECT school_name, school_address, udise_code, established_year, hs_code, logo, hoi_name, hoi_signature FROM school_settings WHERE id = 1') ?: [];
$photos = [];
if ($students) {
    $ids = array_keys($students);
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (db_get_all("SELECT id, photo FROM students WHERE id IN ($in)", str_repeat('s', count($ids)), ...$ids) as $r) $photos[$r['id']] = (string)$r['photo'];
}
$teachers = [];   // section => class teacher, for the signature line on the left
if ($class_id) {
    foreach (db_get_all('SELECT sec.id, st.staff_name FROM sections sec LEFT JOIN staff st ON st.id = sec.class_teacher_id WHERE sec.session_id = ? AND sec.class_id = ?', 'ii', $session_id, $class_id) as $r) {
        $teachers[(int)$r['id']] = (string)$r['staff_name'];
    }
}
$regs = [];
if ($students) {
    $ids = array_keys($students);
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (db_get_all("SELECT student_id, registration_no, registration_year FROM hs_registration WHERE student_id IN ($in)", str_repeat('s', count($ids)), ...$ids) as $r) $regs[$r['student_id']] = $r;
}

/** A mark with its grade the way the mark sheet prints it: "36/O", AB, NA or — when nothing was entered. */
$mg = function (?float $mark, float $full, bool $absent, bool $missing) use ($class_id): string {
    if ($missing) return '—';
    if ($absent) return 'AB';
    if ($mark === null) return 'NA';
    $g = $full > 0 ? (string)grade_for(round($mark / $full * 100, 2), $class_id)['grade'] : '';
    return exam_fmt($mark) . ($g !== '' ? '/' . $g : '');
};
/** The three groups of the mark sheet, in order, as slot => heading. */
$groups = ['compulsory' => 'COMPULSORY LANGUAGE', 'elective' => 'COMPULSORY ELECTIVE', 'additional' => 'OPTIONAL ELECTIVE'];
$student_opts = [];
foreach ($res['students'] ?? [] as $uid => $st) $student_opts[$uid] = $st['section'] . '-' . $st['roll'] . '  ' . $st['name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Mark Sheet</title>
<?php exam_styles('hs'); ?>
<style>
    :root { --ms-1: #0f4c5c; --ms-2: #1e88a8; --ms-3: #b8860b; --ms-soft: #eef7fa; --ms-line: #9fc4d0; }
    .ms { position: relative; background: #fff; border: 3px double var(--ms-1); border-radius: 10px; padding: 12px 16px 10px;
          margin: 0 auto 16px; width: 277mm; min-height: 190mm; box-sizing: border-box; color: #10262e; font-size: 11.5px;
          page-break-after: always; overflow: hidden; box-shadow: 0 6px 20px rgba(15,76,92,.12); }
    .ms::before { content: ''; position: absolute; inset: 5px; border: 1px solid var(--ms-line); border-radius: 6px; pointer-events: none; }
    .ms::after { content: ''; position: absolute; left: 0; right: 0; top: 0; height: 6px; background: linear-gradient(90deg, var(--ms-1), var(--ms-2) 45%, var(--ms-3)); }
    .ms:last-child { page-break-after: auto; }
    .ms .wm { position: absolute; left: 50%; top: 52%; transform: translate(-50%, -50%); width: 118mm; opacity: .06; pointer-events: none; }
    .ms .inner { position: relative; z-index: 1; }

    .ms .head { display: flex; align-items: center; gap: 14px; }
    .ms .head .logo { width: 62px; height: 62px; object-fit: contain; }
    .ms .head .mid { flex: 1; text-align: center; }
    .ms .head h1 { margin: 0; font-size: 27px; line-height: 1.15; letter-spacing: 1px; color: var(--ms-1); text-transform: uppercase; }
    .ms .head .addr { font-size: 11px; color: #3d5c66; margin-top: 3px; }
    .ms .head .codes { font-size: 11px; color: #3d5c66; margin-top: 2px; }
    .ms .photo { width: 26mm; height: 33mm; border: 1.5px solid var(--ms-1); border-radius: 4px; object-fit: cover;
                 background: #fff; padding: 4px; margin: 3px 6px 0 8px; box-shadow: 0 1px 4px rgba(15,76,92,.18); }
    .ms .photo.none { display: flex; align-items: center; justify-content: center; font-size: 9px; color: #9bb3bc; border-style: dashed; text-align: center; box-sizing: border-box; }

    .ms .title { margin: 8px 0 8px; text-align: center; }
    .ms .title b { display: inline-block; background: linear-gradient(135deg, var(--ms-1), var(--ms-2)); color: #fff; padding: 4px 26px;
                   border-radius: 999px; font-size: 13px; letter-spacing: 3px; }
    .ms .title span { display: block; font-size: 12px; font-weight: 700; color: var(--ms-1); margin-top: 4px; letter-spacing: .5px; }

    .ms .who { display: grid; grid-template-columns: repeat(4, 1fr); gap: 2px 14px; background: var(--ms-soft); border: 1px solid var(--ms-line);
               border-radius: 6px; padding: 7px 12px; margin-bottom: 8px; font-size: 11px; }
    .ms .who div span { color: #4a6b75; } .ms .who div b { color: #10262e; }
    .ms .who .wide { grid-column: span 2; }

    .ms table.mk { width: 100%; border-collapse: collapse; font-size: 10.5px; }
    .ms table.mk th, .ms table.mk td { border: 1px solid var(--ms-line); padding: 3px 4px; text-align: center; }
    /*
     * One gradient behind the whole head, not one per cell: on paper Chrome turns a gradient in each
     * header cell into ~17 page-sized bitmaps per sheet, so a class of 368 sheets took ~9 minutes and
     * 150 MB to print; painted on the thead it is drawn as a gradient and prints ~7× faster.
     */
    .ms table.mk thead { background: linear-gradient(180deg, var(--ms-2), var(--ms-1)); }
    .ms table.mk thead th { color: #fff; font-size: 9.5px; letter-spacing: .3px; line-height: 1.15; }
    .ms table.mk tbody td.sub { text-align: left; font-weight: 700; letter-spacing: .4px; }
    .ms table.mk tr.grp td { background: #fdf4e0; color: #7a5300; font-weight: 700; font-size: 9.5px; letter-spacing: 1.2px; text-align: left; border-color: var(--ms-3); }
    .ms table.mk tbody tr:nth-child(even of .sr) td { background: #f7fbfc; }
    .ms table.mk td.tot { font-weight: 800; background: #eef7fa; } .ms table.mk td.gr { font-weight: 800; color: var(--ms-1); }
    .ms table.mk td.f { color: #b71c1c; font-weight: 800; }
    .ms table.mk td.drop { color: #7d929b; } .ms table.mk td.drop.tot { text-decoration: line-through; }

    .ms .res { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; }
    .ms .res span { border: 1px solid var(--ms-line); border-radius: 7px; padding: 5px 13px; font-size: 11px; background: var(--ms-soft); }
    .ms .res span b { display: block; font-size: 14px; color: var(--ms-1); letter-spacing: .5px; }
    .ms .res span.pass b { color: #1b7a3a; } .ms .res span.fail b { color: #b71c1c; }
    /* the two signatures sit well below the figures: class teacher on the left, head of the institution on the right */
    .ms .signs { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 46px; }
    .ms .sign { text-align: center; font-size: 10.5px; min-width: 64mm; }
    .ms .sign img { height: 34px; display: block; margin: 0 auto 2px; }
    .ms .sign .line { border-top: 1px solid #10262e; padding-top: 3px; }
    .ms .note { font-size: 9px; color: #6b8a95; margin-top: 4px; }

    /*
     * On paper nothing but the sheets prints — not the app's menu (main-navbar-2tier), which the Print
     * button on the normal page would otherwise put above the first sheet and push half of it onto a
     * second page — and every sheet is one whole landscape page, never split.
     */
    @media print {
        html, body { margin: 0 !important; padding: 0 !important; background: #fff !important; min-height: 0 !important; }
        .navbar, .main-navbar-2tier, .ex-banner, .ex-tabs, .ex-steps, .noprint, .pick, .alert { display: none !important; }
        .page-box { margin: 0 !important; padding: 0 !important; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; max-width: none !important; background: none !important; }
        .ms { border-width: 2px; box-shadow: none; margin: 0; width: auto; min-height: 0;
              break-inside: avoid; page-break-inside: avoid; break-after: page; page-break-after: always; }
        .ms:last-child { break-after: auto; page-break-after: auto; }
        @page { size: A4 landscape; margin: 6mm; }
        * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if (!$print): ?>
        <?php exam_banner('HS Mark Sheet', 'One A4 landscape mark sheet per student of Class XI, in the WBCHSE layout — semester marks, practical, best-of-five Grand Total and grade.', 'fa-id-card',
            $students ? ["hs_report_card.php?$qs&print=1" => '<i class="fas fa-print"></i> Print view'] : []); ?>
        <?php hs_tabs('hs_report_card.php'); ?>
        <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_report_card.php', "session_id=$session_id&class_id=$class_id"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px">
            <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.uid.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id); ?></select></div>
            <div><label>Section</label><select name="section_id" onchange="this.form.uid.value='';this.form.submit()"><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
            <div style="min-width:240px"><label>Student</label><select name="uid" onchange="this.form.submit()"><?php echo exam_options($student_opts, $only, 'Everyone listed'); ?></select></div>
            <div><label>&nbsp;</label><button type="button" class="btn btn-primary" onclick="window.print()" style="height:38px"><i class="fas fa-print"></i> Print</button></div>
        </form>
        <?php if ($res && $res['warnings']): ?><div class="alert alert-warning noprint"><i class="fas fa-exclamation-circle"></i> <?php echo h(implode(' · ', $res['warnings'])); ?></div><?php endif; ?>
    <?php else: ?>
        <div class="noprint" style="margin:0 0 10px"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button> <a href="hs_report_card.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php endif; ?>

    <?php if (!$students): ?>
        <div class="card noprint"><?php exam_guard('No mark sheet to show', $res && $res['warnings'] ? implode(' ', $res['warnings']) : 'No student of this class has a subject combination and marks yet.', "hs_tabulation.php?session_id=$session_id&class_id=$class_id", 'Tabulation'); ?></div>
    <?php else: foreach ($students as $uid => $st):
        $order = hs_slot_order($st['subjects'], $names);
        $reg = $regs[$uid] ?? null;
        $photo = $photos[$uid] ?? '';
    ?>
    <div class="ms">
        <?php if (!empty($school['logo'])): ?><img class="wm" src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?>
        <div class="inner">
            <div class="head">
                <?php if (!empty($school['logo'])): ?><img class="logo" src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php else: ?><div style="width:62px"></div><?php endif; ?>
                <div class="mid">
                    <h1><?php echo h($school['school_name'] ?? ''); ?></h1>
                    <div class="addr"><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></div>
                    <div class="codes">
                        <?php if (!empty($school['hs_code'])): ?>H.S. Inst Code: <b><?php echo h($school['hs_code']); ?></b><?php endif; ?>
                        <?php if (!empty($school['udise_code'])): ?> &nbsp;·&nbsp; UDISE: <b><?php echo h($school['udise_code']); ?></b><?php endif; ?>
                    </div>
                </div>
                <?php if ($photo !== ''): ?>
                    <img class="photo" src="../uploads/students/<?php echo rawurlencode($photo); ?>" alt="">
                <?php else: ?>
                    <div class="photo none">Photograph</div>
                <?php endif; ?>
            </div>

            <div class="title">
                <b>MARK SHEET</b>
                <span>Class XI Annual Examination <?php echo h($exam_year); ?></span>
            </div>

            <div class="who">
                <div class="wide"><span>Name of the Candidate:</span> <b><?php echo h($st['name']); ?></b></div>
                <div class="wide"><span>Father's Name:</span> <b><?php echo h($st['father']); ?></b></div>
                <div><span>Registration No.:</span> <b><?php echo h($reg['registration_no'] ?? '—'); ?></b></div>
                <div><span>Registration Year:</span> <b><?php echo h($reg['registration_year'] ?? '—'); ?></b></div>
                <div><span>Class &amp; Section:</span> <b><?php echo h(hs_class_name($class_id)); ?><?php echo $st['section'] !== '' ? '-' . h($st['section']) : ''; ?></b></div>
                <div><span>Roll No.:</span> <b><?php echo h($st['roll']); ?></b></div>
                <div><span>School UID:</span> <b><?php echo h($uid); ?></b></div>
                <div><span>Banglar Shiksha ID:</span> <b><?php echo h($st['bsid'] ?: '—'); ?></b></div>
                <div><span>PEN:</span> <b><?php echo h($st['pen'] ?: '—'); ?></b></div>
                <div><span>Date of Birth:</span> <b><?php echo $st['dob'] ? h(date('d-m-Y', strtotime($st['dob']))) : '—'; ?></b></div>
            </div>

            <table class="mk">
                <thead>
                    <tr>
                        <th rowspan="2" style="width:22%">SUBJECTS</th>
                        <th colspan="3">FULL MARKS</th>
                        <th colspan="3">PASS MARKS</th>
                        <th colspan="5">MARKS / GRADE</th>
                        <th rowspan="2">TOTAL<br>IN FIGURES</th>
                        <th rowspan="2">SUBJECT<br>GRADE</th>
                    </tr>
                    <tr>
                        <th>SEM 1</th><th>SEM 2</th><th>PRACTICAL<br>/ ORAL / PROJECT</th>
                        <th>SEM 1</th><th>SEM 2</th><th>PRACTICAL<br>/ ORAL / PROJECT</th>
                        <th>SEM 1</th><th>SEM 1<br>SUPPLEMENTARY</th><th>SEM 2</th><th>SEM 2<br>SUPPLEMENTARY</th><th>PRACTICAL<br>/ ORAL / PROJECT</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($groups as $slot => $heading):
                    $ids = [];
                    if ($slot === 'compulsory') $ids = array_filter([$order['c1'], $order['c2']]);
                    elseif ($slot === 'elective') $ids = array_filter([$order['m1'], $order['m2'], $order['m3']]);
                    else $ids = array_filter([$order['a']]);
                    if (!$ids) continue; ?>
                    <tr class="grp"><td colspan="14"><?php echo h($heading); ?></td></tr>
                    <?php foreach ($ids as $sid): $row = $st['subjects'][$sid]; $a = $row['sem'][$S1] ?? null; $b = $row['sem'][$S2] ?? null;
                        $counted = in_array($sid, $st['best5'], true); ?>
                    <tr class="sr">
                        <td class="sub <?php echo $counted ? '' : 'drop'; ?>"><?php echo h(exam_subject_code(['name' => $names[$sid] ?? '', 'code' => $res['subjects'][$sid]['code'] ?? ''])); ?> &nbsp;<small style="font-weight:400"><?php echo h($names[$sid] ?? ''); ?></small></td>
                        <td><?php echo $a ? exam_fmt($a['theory_full']) : '—'; ?></td>
                        <td><?php echo $b ? exam_fmt($b['theory_full']) : '—'; ?></td>
                        <td><?php echo $b && $b['practical_full'] > 0 ? exam_fmt($b['practical_full']) : 'NA'; ?></td>
                        <td><?php echo $a ? exam_fmt($a['theory_pass']) : '—'; ?></td>
                        <td><?php echo $b ? exam_fmt($b['theory_pass']) : '—'; ?></td>
                        <td><?php echo $b && $b['practical_full'] > 0 ? exam_fmt($b['practical_pass']) : 'NA'; ?></td>
                        <td class="<?php echo $a && $a['theory_fail'] ? 'f' : ''; ?>"><?php echo $a ? h($mg($a['theory'], $a['theory_full'], $a['theory_absent'] && $a['supplementary'] === null, $a['missing'])) : '—'; ?></td>
                        <td class="<?php echo $a && $a['supplementary'] !== null && $a['theory_fail'] ? 'f' : ''; ?>"><?php echo $a && $a['supplementary'] !== null ? h($mg($a['supplementary'], $a['theory_full'], false, false)) : 'NA'; ?></td>
                        <td class="<?php echo $b && $b['theory_fail'] ? 'f' : ''; ?>"><?php echo $b ? h($mg($b['theory'], $b['theory_full'], $b['theory_absent'] && $b['supplementary'] === null, $b['missing'])) : '—'; ?></td>
                        <td class="<?php echo $b && $b['supplementary'] !== null && $b['theory_fail'] ? 'f' : ''; ?>"><?php echo $b && $b['supplementary'] !== null ? h($mg($b['supplementary'], $b['theory_full'], false, false)) : 'NA'; ?></td>
                        <td class="<?php echo $b && $b['practical_fail'] ? 'f' : ''; ?>"><?php echo $b && $b['practical_full'] > 0 ? h($mg($b['practical'], $b['practical_full'], $b['practical_absent'], $b['missing'])) : 'NA'; ?></td>
                        <td class="tot <?php echo $counted ? '' : 'drop'; ?>"><?php echo $row['missing'] ? '—' : exam_fmt($row['total']); ?><?php echo $counted ? '' : ' †'; ?></td>
                        <td class="gr <?php echo $counted ? '' : 'drop'; ?>"><?php echo h($row['grade']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div class="res">
                <span class="<?php echo $st['status'] === 'PASS' ? 'pass' : ($st['status'] === 'FAIL' ? 'fail' : ''); ?>">Result<b><?php echo $st['status'] === 'PASS' ? 'Pass' : ($st['status'] === 'FAIL' ? 'Fail' : 'Not available'); ?></b></span>
                <span>Overall Grade<b><?php echo h($st['grade']); ?></b></span>
                <span>Grand Total<b><?php echo exam_fmt($st['total']); ?> / <?php echo exam_fmt($st['full']); ?></b></span>
                <span>Percentage<b><?php echo exam_fmt($st['pct']); ?>%</b></span>
                <span>Subjects Passed<b><?php echo $st['subjects_n'] - $st['failed_n']; ?> of <?php echo $st['subjects_n']; ?></b></span>
            </div>
            <div class="signs">
                <div class="sign">
                    <div class="line">(Signature of the Class Teacher)<br><small><?php echo h($teachers[(int)$st['section_id']] ?? ''); ?></small></div>
                </div>
                <div class="sign">
                    <?php if (!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo h($school['hoi_signature']); ?>" alt=""><?php endif; ?>
                    <div class="line">(Signature of the HOI)<br><small><?php echo h($school['hoi_name'] ?? ''); ?></small></div>
                </div>
            </div>
            <div class="note">Grand Total is the best five subjects — a subject marked † is outside it. NA = not applicable · AB = absent · — = not entered. Issued on <?php echo date('d-m-Y'); ?>.</div>
        </div>
    </div>
    <?php endforeach; endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * One Higher Secondary student, both semesters, every subject of their own combination on a single form:
 * theory, supplementary, practical / project and the two absent ticks. Below the form the year is worked out
 * the way the result does it — subject totals, the best five marked, total, percentage, grade and result.
 * Each subject is saved through hs_marks_save_rows(), so the limits and the supplementary rule are the same
 * ones the Marks Entry screen applies. Linked from the tabulation sheet.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$uid = student_uid_clean((string)($_GET['uid'] ?? $_POST['uid'] ?? ''));
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();

$student = null; $class_id = 0;
if ($uid !== '') {
    $student = db_get_row('SELECT s.id, s.student_name, s.banglarshiksha_id, s.pen_id, g.father_name, sah.class_id, sah.section_id, sah.roll_no, sec.section_name, hr.registration_no
        FROM students s
        JOIN student_academic_history sah ON sah.student_id = s.id AND sah.session_id = ? AND sah.academic_status = "Current"
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = sah.section_id
        LEFT JOIN hs_registration hr ON hr.student_id = s.id
        WHERE s.id = ? AND s.student_status = "Active"', 'is', $session_id, $uid);
    if ($student) { $class_id = (int)$student['class_id']; if (!hs_is_hs_class($class_id)) $student = null; }
}
$section_id = $student ? (int)$student['section_id'] : 0;
$back = 'hs_tabulation.php?session_id=' . $session_id . '&class_id=' . $class_id . '&section_id=' . ($section_id ?: 'all');

// the semester exams the school conducts for this class, with their subject config
$exams = [];
if ($student) {
    foreach (hs_school_semesters($class_id) as $sem) {
        $e = hs_exam_of_semester($session_id, $class_id, $sem);
        if ($e) $exams[(int)$e['id']] = ['exam' => $e, 'semester' => $sem, 'subjects' => array_filter(hs_exam_subjects((int)$e['id']), fn($s) => $s['configured'])];
    }
}
$choice = $student ? hs_student_subjects_one($session_id, $uid) : [];

$errors = []; $posted = [];
if ($student && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    verify_csrf_or_die();
    $posted = (array)($_POST['m'] ?? []);
    $saved = 0; $cleared = 0;
    foreach ($posted as $eid => $bySubject) {
        $eid = (int)$eid;
        if (!isset($exams[$eid])) continue;                       // only this student's own semester exams
        foreach ((array)$bySubject as $sid => $v) {
            $sid = (int)$sid;
            if (!isset($exams[$eid]['subjects'][$sid]) || !isset($choice[$sid])) continue;
            $r = hs_marks_save_rows($eid, $sid, [$uid => (array)$v], $admin_id);
            if ($r['ok']) { $saved += $r['saved']; $cleared += $r['cleared']; }
            else $errors[$eid . ':' . $sid] = $r['errors'][$uid] ?? ($r['errors']['_'] ?? 'could not be saved');
        }
    }
    if (!$errors) {
        $_SESSION['success'] = $student['student_name'] . ': ' . $saved . ' subject' . ($saved === 1 ? '' : 's') . ' saved' . ($cleared ? ', ' . $cleared . ' cleared' : '') . '.';
        header('Location: hs_student_marks_edit.php?uid=' . urlencode($uid) . '&session_id=' . $session_id); exit;
    }
}

$marks = [];
foreach ($exams as $eid => $x) $marks[$eid] = hs_marks($eid);
$year = $student ? hs_result_year($session_id, $class_id, $section_id) : null;
$me = $year['students'][$uid] ?? null;
$names = []; foreach ($year['subjects'] ?? [] as $sid => $s) $names[$sid] = $s['name'];

/** Field value: what was posted after a failed save, otherwise what is on record. */
$val = function (int $eid, int $sid, string $k) use ($posted, $marks, $uid): string {
    if ($posted) return (string)($posted[$eid][$sid][$k] ?? '');
    $m = $marks[$eid][$uid][$sid] ?? null;
    if (!$m) return '';
    if ($k === 'theory_absent') return (int)$m['theory_absent'] ? '1' : '';
    if ($k === 'practical_absent') return (int)$m['practical_absent'] ? '1' : '';
    $col = ['theory' => 'theory_marks', 'supplementary' => 'theory_supplementary_marks', 'practical' => 'practical_marks'][$k] ?? null;
    return ($col && $m[$col] !== null) ? exam_fmt($m[$col]) : '';
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit HS Student Marks</title>
<?php exam_styles('hs'); ?>
<style>
    .who { display: flex; gap: 18px; flex-wrap: wrap; font-size: 13px; color: #3b5168; margin-bottom: 4px; } .who b { color: #16303a; }
    .ex-table td.err { background: #fff2f2; } .ex-table .em { display: block; color: #b71c1c; font-size: 11px; }
    .ex-table input.m { width: 66px; } .ex-table input.m.supp { width: 58px; }
    .ex-table td.st { font-weight: 700; font-size: 11.5px; } .ex-table td.st.p { color: #1b7a3a; } .ex-table td.st.f { color: #b71c1c; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 12px; } .sum span { padding: 6px 12px; border-radius: 9px; background: var(--ex-soft); border: 1px solid var(--ex-border); font-size: 13px; } .sum b { display: block; font-size: 15px; }
    .yr { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-top: 8px; } .yr th, .yr td { border: 1px solid #dde7ec; padding: 5px 8px; text-align: center; } .yr th { background: var(--ex-soft); color: var(--ex-dark); font-size: 11px; text-transform: uppercase; }
    .yr td.l { text-align: left; } .yr tr.out td { color: #8c9aa4; background: #f6f8f9; } .yr td.f { color: #b71c1c; font-weight: 700; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Edit HS Student Marks', 'One student, both semesters, all of their subjects on one form — the same limits as Marks Entry.', 'fa-user-edit', [$back => '<i class="fas fa-arrow-left"></i> Back to tabulation']); ?>
    <?php hs_tabs('hs_tabulation.php'); ?>
    <?php exam_flash(); ?>
    <?php if ($errors): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Not saved — see the subjects marked in red.</div><?php endif; ?>

    <?php if (!$student): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-user-slash"></i><?php echo $uid === '' ? 'No student given.' : 'Student ' . h($uid) . ' is not a current Higher Secondary student in ' . h(exam_session_name($session_id)) . '.'; ?> Open a student from the <a href="hs_tabulation.php">tabulation sheet</a>.</div></div>
    <?php elseif (!$exams): ?>
        <div class="card"><?php exam_guard('No semester exam for this class', 'Create the semester exams before entering marks.', 'hs_exams.php', 'Semester Exams'); ?></div>
    <?php elseif (!$choice): ?>
        <div class="card"><?php exam_guard('This student has no subject combination', $student['student_name'] . ' has not chosen their subjects yet, so there is nothing to enter.', "hs_subjects.php?session_id=$session_id&class_id=$class_id", 'Subject Combination'); ?></div>
    <?php else: ?>
    <div class="card">
        <div class="who">
            <span>UID <b><?php echo h($uid); ?></b></span>
            <span>Student <b><?php echo h($student['student_name']); ?></b></span>
            <span>Father <b><?php echo h($student['father_name']); ?></b></span>
            <span>Class <b><?php echo h(hs_class_name($class_id)); ?><?php echo $student['section_name'] ? '-' . h($student['section_name']) : ''; ?></b></span>
            <span>Roll <b><?php echo h($student['roll_no']); ?></b></span>
            <?php if ($student['registration_no']): ?><span>WBCHSE Reg. <b><?php echo h($student['registration_no']); ?></b></span><?php endif; ?>
            <?php if ($student['banglarshiksha_id']): ?><span>BSID <b><?php echo h($student['banglarshiksha_id']); ?></b></span><?php endif; ?>
            <?php if ($student['pen_id']): ?><span>PEN <b><?php echo h($student['pen_id']); ?></b></span><?php endif; ?>
        </div>
    </div>

    <form method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="uid" value="<?php echo h($uid); ?>"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
        <?php foreach ($exams as $eid => $x): $has_prac = (int)$x['exam']['has_practical'] === 1; ?>
        <div class="card">
            <h2><i class="fas fa-edit"></i> <?php echo h($x['exam']['exam_name']); ?> <small><?php echo $has_prac ? 'theory + practical / project' : 'theory only'; ?> — each part is passed on its own</small></h2>
            <?php $mine = array_intersect_key($x['subjects'], $choice); if (!$mine): ?>
                <div class="ex-empty"><i class="fas fa-sliders-h"></i>None of this student's subjects has its full marks set in this semester — <a href="hs_exam_subject_marks.php?exam_id=<?php echo $eid; ?>">set them first</a>.</div>
            <?php else: ?>
            <table class="ex-table">
                <thead><tr><th style="text-align:left">Subject</th><th class="num">Theory</th><th class="num">Suppl.</th><?php if ($has_prac): ?><th class="num">Practical / Project</th><?php endif; ?><th class="num">Abs T</th><?php if ($has_prac): ?><th class="num">Abs P</th><?php endif; ?><th class="num">Total</th><th class="num">Status</th></tr></thead>
                <tbody>
                <?php foreach ($mine as $sid => $s):
                    $err = $errors[$eid . ':' . $sid] ?? '';
                    $th = $val($eid, $sid, 'theory'); $sp = $val($eid, $sid, 'supplementary'); $pr = $val($eid, $sid, 'practical');
                    $tab = $val($eid, $sid, 'theory_absent') === '1'; $pab = $val($eid, $sid, 'practical_absent') === '1';
                    $counted = $tab ? null : hs_theory_counted($th === '' ? null : (float)$th, $sp === '' ? null : (float)$sp);
                    $t_fail = $tab || ($counted !== null && $counted < $s['theory_pass']);
                    $p_fail = $s['has_practical'] && ($pab || ($pr !== '' && (float)$pr < $s['practical_pass']));
                    $entered = $th !== '' || $sp !== '' || $pr !== '' || $tab || $pab;
                    $supp_open = $tab || ($th !== '' && (float)$th < $s['theory_pass']);   // supplementary is only for a failed semester
                    $total = (float)($counted ?? 0) + (float)($pab || $pr === '' ? 0 : $pr);
                ?>
                <tr data-sid="<?php echo $sid; ?>">
                    <td><b><?php echo h($s['name']); ?></b><br><small style="color:#6b7d90">theory <?php echo exam_fmt($s['theory_full']); ?> (pass <?php echo exam_fmt($s['theory_pass']); ?>)<?php if ($s['has_practical']): ?> · practical / project <?php echo exam_fmt($s['practical_full']); ?> (pass <?php echo exam_fmt($s['practical_pass']); ?>)<?php endif; ?></small>
                        <?php if ($err): ?><span class="em"><?php echo h($err); ?></span><?php endif; ?></td>
                    <td class="num <?php echo $err ? 'err' : ''; ?>"><input class="m th" name="m[<?php echo $eid; ?>][<?php echo $sid; ?>][theory]" value="<?php echo h($th); ?>" inputmode="decimal" <?php echo $tab ? 'disabled' : ''; ?>></td>
                    <td class="num"><input class="m supp" name="m[<?php echo $eid; ?>][<?php echo $sid; ?>][supplementary]" value="<?php echo h($sp); ?>" inputmode="decimal" <?php echo $supp_open ? '' : 'disabled'; ?> title="<?php echo $supp_open ? 'Supplementary mark' : 'Only for a failed or absent theory'; ?>"></td>
                    <?php if ($has_prac): ?><td class="num"><input class="m pr" name="m[<?php echo $eid; ?>][<?php echo $sid; ?>][practical]" value="<?php echo h($pr); ?>" inputmode="decimal" <?php echo $s['has_practical'] ? '' : 'disabled'; ?> <?php echo $pab ? 'disabled' : ''; ?>></td><?php endif; ?>
                    <td class="num"><input type="checkbox" class="ta" name="m[<?php echo $eid; ?>][<?php echo $sid; ?>][theory_absent]" value="1" <?php echo $tab ? 'checked' : ''; ?>></td>
                    <?php if ($has_prac): ?><td class="num"><input type="checkbox" class="pa" name="m[<?php echo $eid; ?>][<?php echo $sid; ?>][practical_absent]" value="1" <?php echo $pab ? 'checked' : ''; ?> <?php echo $s['has_practical'] ? '' : 'disabled'; ?>></td><?php endif; ?>
                    <td class="num"><b><?php echo $entered ? exam_fmt($total) : '—'; ?></b></td>
                    <td class="num st <?php echo !$entered ? '' : (($t_fail || $p_fail) ? 'f' : 'p'); ?>"><?php echo !$entered ? '—' : (($t_fail && $p_fail) ? 'Fail T+P' : ($t_fail ? 'Fail theory' : ($p_fail ? 'Fail pract.' : 'Pass'))); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <div class="card" style="display:flex;gap:8px;align-items:center">
            <button type="submit" name="save" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save all semesters</button>
            <a href="<?php echo h($back); ?>" class="btn btn-secondary">Cancel</a>
            <span class="note" style="margin:0">A blank subject with no absent tick is left out of the records. Supplementary opens only when the theory is below the pass marks or absent.</span>
        </div>
    </form>

    <?php if ($me): ?>
    <div class="card">
        <h2><i class="fas fa-award"></i> The year <small>Semester 1 + Semester 2, best of five</small></h2>
        <table class="yr">
            <thead><tr><th style="text-align:left">Subject</th><th>Slot</th><?php foreach (hs_school_semesters($class_id) as $sem): ?><th><?php echo h(HS_SEMESTERS[$sem]); ?></th><?php endforeach; ?><th>Total</th><th>Full</th><th>%</th><th>Grade</th><th>Counted</th></tr></thead>
            <tbody>
            <?php foreach ($me['subjects'] as $sid => $row): $in = in_array($sid, $me['best5'], true); ?>
            <tr class="<?php echo $in ? '' : 'out'; ?>">
                <td class="l"><?php echo h($names[$sid] ?? ''); ?></td>
                <td><?php echo h(HS_SLOTS[$row['slot']] ?? $row['slot']); ?></td>
                <?php foreach (hs_school_semesters($class_id) as $sem): $c = $row['sem'][$sem] ?? null; ?>
                    <td class="<?php echo $c && ($c['theory_fail'] || $c['practical_fail']) ? 'f' : ''; ?>"><?php
                        if (!$c || $c['missing']) echo '—';
                        else { echo $c['counted'] === null ? ($c['theory_absent'] ? 'AB' : '—') : exam_fmt($c['counted']) . (!empty($c['supp_used']) ? '*' : '');
                               if ($c['practical'] !== null || $c['practical_absent']) echo ' + ' . ($c['practical_absent'] ? 'AB' : exam_fmt($c['practical'])); }
                    ?></td>
                <?php endforeach; ?>
                <td><b><?php echo exam_fmt($row['total']); ?></b></td><td><?php echo exam_fmt($row['full']); ?></td><td><?php echo exam_fmt($row['pct']); ?></td><td><?php echo h($row['grade']); ?></td>
                <td><?php echo $in ? '<i class="fas fa-check" style="color:#1b7a3a"></i>' : '<span style="color:#8c9aa4">not in the best 5</span>'; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="sum">
            <span>Total<b><?php echo exam_fmt($me['total']); ?> / <?php echo exam_fmt($me['full']); ?></b></span>
            <span>Percentage<b><?php echo exam_fmt($me['pct']); ?>%</b></span>
            <span>Grade<b><?php echo h($me['grade']); ?></b></span>
            <span>Result<b><?php echo h($me['status']); ?></b></span>
            <span>Rank<b><?php echo $me['rank'] ?? '—'; ?></b> <small>in <?php echo h($student['section_name'] ?: 'the class'); ?></small></span>
            <span>Subjects passed<b><?php echo $me['subjects_n'] - $me['failed_n']; ?> of <?php echo $me['subjects_n']; ?></b></span>
        </div>
        <?php if ($year['warnings']): ?><p class="note"><?php echo h(implode(' · ', $year['warnings'])); ?></p><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<script>
// the absent ticks blank out their own mark box, and supplementary stays shut while the theory is a pass
document.querySelectorAll('tr[data-sid]').forEach(function (tr) {
    var th = tr.querySelector('input.th'), sp = tr.querySelector('input.supp'), pr = tr.querySelector('input.pr'),
        ta = tr.querySelector('input.ta'), pa = tr.querySelector('input.pa');
    function sync() {
        if (ta && th) { th.disabled = ta.checked; if (ta.checked) th.value = ''; }
        if (pa && pr) { pr.disabled = pa.checked; if (pa.checked) pr.value = ''; }
    }
    if (ta) ta.addEventListener('change', sync);
    if (pa) pa.addEventListener('change', sync);
});
</script>
</body>
</html>

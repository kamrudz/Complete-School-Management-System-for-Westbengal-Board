<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/hs_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Subject combination of each Higher Secondary student, chosen at admission.
 * Bengali and English are compulsory; the student then takes three main subjects and, if they wish,
 * one additional subject — five or six in all. Each slot is picked by subject code.
 * Marks entry lists a student only for the subjects chosen here, and the best-of-5 result counts the two
 * compulsory subjects plus the best three of the rest.
 * The whole page saves in one transaction — nothing is written if any row is wrong.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$classes = hs_classes();
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? array_key_first($classes));
if (!isset($classes[$class_id])) $class_id = (int)array_key_first($classes);
$sections = exam_sections($session_id, $class_id);
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? '');
$section_id = $section_raw === 'all' ? null : (int)$section_raw;
if ($section_id && !isset($sections[$section_id])) $section_id = null;
$only = ($_GET['only'] ?? '') === 'missing' ? 'missing' : (($_GET['only'] ?? '') === 'done' ? 'done' : '');
$search = trim((string)($_GET['q'] ?? ''));
$qs = "session_id=$session_id&class_id=$class_id&section_id=" . ($section_id ?: 'all') . ($only ? "&only=$only" : '') . ($search !== '' ? '&q=' . urlencode($search) : '');
$back = 'hs_subjects.php?' . $qs;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['save_rows'])) {
        $rows = []; $dups = [];
        foreach ((array)($_POST['listed'] ?? []) as $uid) {
            $uid = (string)$uid;
            $picked = array_map('intval', (array)($_POST['main'][$uid] ?? []));
            $add = (int)($_POST['additional'][$uid] ?? 0);
            if ($add) $picked[] = $add;
            $picked = array_values(array_filter($picked));
            if (count($picked) !== count(array_unique($picked))) { $dups[] = $uid; continue; }
            $rows[$uid] = $picked;
        }
        if ($dups) {
            $students = hs_students($session_id, $class_id);
            $_SESSION['error'] = 'The same subject is picked twice for: ' . implode(', ', array_map(fn($u) => $students[$u]['name'] ?? $u, $dups)) . '.';
        } else {
            $r = hs_subjects_save_many($session_id, $class_id, $rows, $admin_id);
            if ($r['ok']) $_SESSION['success'] = 'Subject combination saved — ' . $r['saved'] . ' student' . ($r['saved'] === 1 ? '' : 's') . ($r['cleared'] ? ', ' . $r['cleared'] . ' left blank' : '') . '.';
            else {
                $students = hs_students($session_id, $class_id);
                $_SESSION['error'] = implode('; ', array_map(fn($u, $m) => ($students[$u]['name'] ?? $u) . ': ' . $m, array_keys($r['errors']), $r['errors']));
            }
        }
    }
    header('Location: ' . $back); exit;
}

$catalogue = hs_class_subject_list($session_id, $class_id);
$compulsory = hs_compulsory_subjects();
/** Subjects a student may pick: everything the class offers except the two compulsory ones. */
$choices = [];
foreach ($catalogue as $sid => $s) {
    if (isset($compulsory[$sid])) continue;
    $choices[$sid] = exam_subject_code($s);   // the code alone keeps the boxes narrow; the legend below spells them out
}
$all_students = hs_students($session_id, $class_id, $section_id);
$choice = hs_student_subjects($session_id, $class_id);
$students = [];
foreach ($all_students as $uid => $st) {
    $has = !empty($choice[$uid]);
    if ($only === 'missing' && $has) continue;
    if ($only === 'done' && !$has) continue;
    if ($search !== '' && stripos($st['name'] . ' ' . $uid . ' ' . $st['roll'], $search) === false) continue;
    $students[$uid] = $st;
}
$with_combo = count(array_filter($all_students, fn($st) => !empty($choice[$st['uid']])));
$class_total = (int)(db_get_row('SELECT COUNT(*) n FROM student_academic_history WHERE session_id = ? AND class_id = ? AND academic_status = "Current"', 'ii', $session_id, $class_id)['n'] ?? 0);
/** A student's picks split into the three main slots and the additional one. */
$slots_of = function (string $uid) use ($choice, $compulsory, $catalogue): array {
    $mine = $choice[$uid] ?? [];
    $main = []; $add = 0;
    foreach ($mine as $sid => $slot) {
        if (isset($compulsory[$sid])) continue;
        if ($slot === 'additional') $add = $sid; else $main[] = $sid;
    }
    usort($main, fn($a, $b) => strcmp($catalogue[$a]['name'] ?? '', $catalogue[$b]['name'] ?? ''));
    return ['main' => array_pad(array_slice($main, 0, HS_MAIN_REQUIRED), HS_MAIN_REQUIRED, 0), 'additional' => $add];
};

if (!empty($_GET['xlsx']) && $students) {
    $head = ['#', 'Sec', 'Roll', 'School UID', 'Student', 'Father', 'Compulsory', 'Main 1', 'Main 2', 'Main 3', 'Additional', 'Count'];
    $rows = array_merge(exam_xlsx_title('HS Subject Combination — Class ' . $classes[$class_id]['name'] . ($section_id ? ' — Section ' . $sections[$section_id] : ''), 'Session ' . exam_session_name($session_id)), [$head]);
    $i = 0; $nm = fn($sid) => $sid ? ($catalogue[$sid]['name'] ?? '') : '';
    foreach ($students as $uid => $st) {
        $s = $slots_of($uid);
        $rows[] = [++$i, $st['section'], $st['roll'], $uid, $st['name'], $st['father'], implode(' + ', $compulsory),
            $nm($s['main'][0]), $nm($s['main'][1]), $nm($s['main'][2]), $nm($s['additional']), count($choice[$uid] ?? [])];
    }
    SimpleXLSXWriter::download('hs_subjects_class_' . $classes[$class_id]['name'] . '.xlsx', $rows, 'Combination', exam_xlsx_opts(count($head), 26));
    exit;
}
$opt = function (array $list, int $selected, string $placeholder): string {
    $s = '<option value="0">' . h($placeholder) . '</option>';
    foreach ($list as $sid => $label) $s .= '<option value="' . (int)$sid . '"' . ($sid === $selected ? ' selected' : '') . '>' . h($label) . '</option>';
    return $s;
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Subject Combination</title>
<?php exam_styles('hs'); ?>
<style>
    .grid { overflow: auto; max-height: 72vh; } .grid table { border-collapse: separate; border-spacing: 0; font-size: 12.5px; width: 100%; }
    .grid th, .grid td { border-right: 1px solid #e4ecf1; border-bottom: 1px solid #e4ecf1; padding: 6px 8px; background: #fff; white-space: nowrap; }
    .grid thead th { position: sticky; top: 0; z-index: 3; background: var(--ex-soft); color: var(--ex-dark); font-size: 11px; text-transform: uppercase; text-align: left; }
    .grid td.stick, .grid th.stick { position: sticky; left: 0; z-index: 2; background: #fff; } .grid thead th.stick { z-index: 4; background: var(--ex-soft); }
    .grid td.name { min-width: 200px; } .grid td.name small { display: block; color: #8a98a8; font-size: 10.5px; }
    .grid select { height: 30px; width: 96px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 12.5px; background: #fff; padding: 0 4px; font-weight: 600; color: var(--ex-dark); }
    .grid select.bad { border-color: #d32f2f; background: #fff2f2; }
    .grid td.comp { color: var(--ex-dark); font-weight: 600; }
    .grid tr.bad td { background: #fff2f2; } .grid tr:hover td { background: var(--ex-soft); }
    .cnt { font-weight: 800; text-align: center; } .cnt.ok { color: #1b7a3a; } .cnt.bad { color: #b71c1c; } .cnt.none { color: #8a98a8; }
    .bulkbar { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 9px 12px; margin-bottom: 10px; font-size: 12.5px; }
    .bulkbar select { height: 30px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 12.5px; } .bulkbar select.code { width: 104px; font-weight: 600; color: var(--ex-dark); }
    .sticky { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 2px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('HS Subject Combination', 'What each student of Classes XI–XII takes: Bengali and English, three main subjects, and an additional subject if they want one.', 'fa-book-open', $students ? ["hs_subjects.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel'] : []); ?>
    <?php hs_tabs('hs_subjects.php'); ?>
    <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_subjects.php', "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()"><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
        <div><label>Show</label><select name="only" onchange="this.form.submit()"><?php echo exam_options(['' => 'Everyone', 'missing' => 'Without a combination', 'done' => 'With a combination'], $only); ?></select></div>
        <div><label>Search</label><input type="text" name="q" value="<?php echo h($search); ?>" placeholder="name, roll or UID"></div>
        <div><label>&nbsp;</label><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
    </form>

    <?php if (!$catalogue): ?>
        <div class="card"><?php exam_guard('Class ' . $classes[$class_id]['name'] . ' has no exam subjects', 'Assign the subjects this class offers, with the exam tick, before choosing combinations.', 'class_subjects.php', 'Class Subjects'); ?></div>
    <?php elseif (count($compulsory) < 2): ?>
        <div class="card"><?php exam_guard('Bengali and English were not found', 'The two compulsory subjects are matched by name; add them under Subjects first.', 'subjects.php', 'Subjects'); ?></div>
    <?php elseif (!$students): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-user-slash"></i>No student matches this filter<?php echo $only === 'missing' ? ' — every listed student already has a combination.' : '.'; ?></div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-book-open"></i> Class <?php echo h($classes[$class_id]['name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?>
            <small><?php echo $with_combo; ?> of <?php echo $class_total; ?> students in the class have a combination · showing <?php echo count($students); ?></small></h2>

        <form method="post" id="cf" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id ?: 'all'; ?>">
            <div class="bulkbar noprint">
                <b>Fill everyone listed:</b>
                <select id="b0" class="code"><?php echo $opt($choices, 0, 'Main 1'); ?></select>
                <select id="b1" class="code"><?php echo $opt($choices, 0, 'Main 2'); ?></select>
                <select id="b2" class="code"><?php echo $opt($choices, 0, 'Main 3'); ?></select>
                <select id="b3" class="code"><?php echo $opt($choices, 0, 'Additional'); ?></select>
                <select id="bulkWho"><option value="empty">only students with no combination</option><option value="all">everyone listed (replaces their choice)</option></select>
                <button type="button" class="btn btn-secondary btn-sm" onclick="bulkApply()"><i class="fas fa-magic"></i> Apply</button>
            </div>

            <div class="grid"><table>
                <thead><tr>
                    <th class="stick">Student</th><th>Sec</th><th>Roll</th>
                    <th>Compulsory</th><th>Main 1</th><th>Main 2</th><th>Main 3</th><th>Additional</th><th>Subjects</th>
                </tr></thead>
                <tbody>
                <?php foreach ($students as $uid => $st): $s = $slots_of($uid); ?>
                <tr data-uid="<?php echo h($uid); ?>">
                    <td class="stick name"><b><?php echo h($st['name']); ?></b><small><?php echo h($uid); ?> · <?php echo h($st['father']); ?></small>
                        <input type="hidden" name="listed[]" value="<?php echo h($uid); ?>"></td>
                    <td><?php echo h($st['section']); ?></td><td><?php echo h($st['roll']); ?></td>
                    <td class="comp"><?php echo h(implode(' + ', array_map(fn($s2) => exam_subject_code(['name' => $s2, 'code' => '']), $compulsory))); ?></td>
                    <?php for ($i = 0; $i < HS_MAIN_REQUIRED; $i++): ?>
                    <td><select class="pick" name="main[<?php echo h($uid); ?>][]"><?php echo $opt($choices, (int)$s['main'][$i], '— none —'); ?></select></td>
                    <?php endfor; ?>
                    <td><select class="pick add" name="additional[<?php echo h($uid); ?>]"><?php echo $opt($choices, (int)$s['additional'], '— none —'); ?></select></td>
                    <td class="cnt"></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>

            <div class="sticky">
                <button type="submit" name="save_rows" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save <?php echo count($students); ?> students</button>
                <span class="note" style="margin:0">Bengali and English are always counted. Three main subjects are needed; the additional subject is optional, so a student takes five or six. Leave every box on "— none —" for a student whose choice is not made yet.</span>
            </div>
        </form>
    </div>
    <p class="note"><?php echo h(exam_subject_legend($catalogue)); ?></p>
    <p class="note">The best-of-5 result counts Bengali + English plus the best three of the rest, so an additional subject can replace a weaker main subject.</p>
    <?php endif; ?>
</div>
<script>
var MAIN_NEEDED = <?php echo HS_MAIN_REQUIRED; ?>;
function check(tr) {
    var picks = Array.prototype.slice.call(tr.querySelectorAll('select.pick'));
    var vals = picks.map(function (s) { return s.value; }).filter(function (v) { return v !== '0'; });
    var mains = picks.filter(function (s) { return !s.classList.contains('add'); }).map(function (s) { return s.value; }).filter(function (v) { return v !== '0'; });
    var seen = {}, dup = false;
    vals.forEach(function (v) { if (seen[v]) dup = true; seen[v] = true; });
    picks.forEach(function (s) { s.classList.toggle('bad', s.value !== '0' && vals.filter(function (v) { return v === s.value; }).length > 1); });
    var cell = tr.querySelector('.cnt');
    var total = vals.length ? vals.length + 2 : 0;          // plus Bengali and English
    var ok = vals.length === 0 || (mains.length === MAIN_NEEDED && !dup);
    cell.textContent = total ? total : '—';
    cell.className = 'cnt ' + (total === 0 ? 'none' : (ok ? 'ok' : 'bad'));
    tr.classList.toggle('bad', !ok);
    return ok;
}
document.querySelectorAll('tr[data-uid]').forEach(function (tr) {
    check(tr);
    tr.querySelectorAll('select.pick').forEach(function (s) { s.addEventListener('change', function () { check(tr); }); });
});
function bulkApply() {
    var vals = ['b0', 'b1', 'b2', 'b3'].map(function (id) { return document.getElementById(id).value; });
    if (vals.slice(0, 3).filter(function (v) { return v !== '0'; }).length !== MAIN_NEEDED) { alert('Choose all ' + MAIN_NEEDED + ' main subjects first.'); return; }
    var who = document.getElementById('bulkWho').value, n = 0;
    document.querySelectorAll('tr[data-uid]').forEach(function (tr) {
        var picks = Array.prototype.slice.call(tr.querySelectorAll('select.pick'));
        var already = picks.filter(function (s) { return s.value !== '0'; }).length;
        if (who === 'empty' && already > 0) return;
        picks.forEach(function (s, i) { s.value = vals[i]; });
        check(tr); n++;
    });
    alert(n + ' student(s) filled on screen — press Save to store.');
}
var f = document.getElementById('cf');
if (f) {
    var dirty = false;
    f.addEventListener('change', function () { dirty = true; });
    f.addEventListener('submit', function (e) {
        var bad = document.querySelectorAll('tr.bad').length;
        if (bad) { e.preventDefault(); alert(bad + ' student(s) need ' + MAIN_NEEDED + ' different main subjects (or all boxes on "— none —").'); return; }
        dirty = false;
    });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
}
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/hs_result_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * HS tabulation sheet. Because every student has their own five or six subjects, the sheet is laid out by SLOT,
 * not by subject: Compulsory 1 · Compulsory 2 · Main 1 · Main 2 · Main 3 · Additional — so every row fills the
 * same six columns and there is no "not taken" cell anywhere.
 *
 * View: Semester 1 · Semester 2 (that exam alone) · Year (both semesters added up, then BEST OF 5).
 * All the marks, the best-of-5, the grade, the result and the rank come from hs_result_helper.php — the one
 * place the WBCHSE rules are written. ?print=1 = A4 landscape, ?xlsx=1 = Excel.
 */
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$classes = hs_exam_classes();                       // the school examines Class XI; XII is the board's
$class_id = (int)($_GET['class_id'] ?? 0);
if (!isset($classes[$class_id])) $class_id = (int)(array_key_first($classes) ?? 0);
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw;
if ($section_id && !isset($sections[$section_id])) $section_id = null;
$semesters = $class_id ? hs_school_semesters($class_id) : [];
$view = (string)($_GET['view'] ?? 'year');
$semester = (preg_match('/^s(\d+)$/', $view, $m) && in_array((int)$m[1], $semesters, true)) ? (int)$m[1] : 0;
if (!$semester) $view = 'year';
$sort = ($_GET['sort'] ?? 'roll') === 'merit' ? 'merit' : 'roll';
$compact = !empty($_GET['compact']);          // the year normally shows each semester on its own, as the mark sheet does
$print = !empty($_GET['print']); $xlsx = !empty($_GET['xlsx']);
$qs = "session_id=$session_id&class_id=$class_id&section_id=" . ($section_id ?: 'all') . "&view=$view&sort=$sort" . ($compact ? '&compact=1' : '');

$exam = $semester ? hs_exam_of_semester($session_id, $class_id, $semester) : null;
$students = []; $names = []; $codes = []; $warnings = []; $res = null;
if ($class_id && $semester && $exam) {
    $res = hs_result_semester((int)$exam['id'], $section_id, true);
    $students = $res['students'];
    foreach ($res['subjects'] as $sid => $s) { $names[$sid] = $s['name']; $codes[$sid] = exam_subject_code($s); }
    if (!$res['subjects']) $warnings[] = $exam['exam_name'] . ': full marks are not set for any subject.';
} elseif ($class_id && $semester && !$exam) {
    $warnings[] = HS_SEMESTERS[$semester] . ' has not been created for this class.';
} elseif ($class_id) {
    $res = hs_result_year($session_id, $class_id, $section_id, true);   // also those promoted or passed out since
    $students = $res['students']; $warnings = $res['warnings'];
    foreach ($res['subjects'] as $sid => $s) { $names[$sid] = $s['name']; $codes[$sid] = exam_subject_code($s); }
}
$is_year = $view === 'year';
$detail = $is_year && !$compact;              // Semester 1 · Semester 2 · Practical · Total under every slot

/** Per-student figures that differ between the two views. */
$figures = function (array $st) use ($is_year): array {
    if ($is_year) {
        return ['total' => $st['total'], 'full' => $st['full'], 'grade' => $st['grade'], 'status' => $st['status'],
            'rank' => $st['rank'], 'passed' => $st['subjects_n'] - $st['failed_n'], 'n' => $st['subjects_n']];
    }
    $total = 0.0; $full = 0.0; $passed = 0; $entered = 0;
    foreach ($st['subjects'] as $c) {
        $total += $c['total']; $full += $c['full'];
        if (!$c['missing']) $entered++;
        if (!$c['missing'] && !$c['fail']) $passed++;
    }
    return ['total' => round($total, 2), 'full' => round($full, 2), 'grade' => '', 'status' => $entered ? '' : 'ABSENT',
        'rank' => null, 'passed' => $passed, 'n' => count($st['subjects'])];
};
foreach ($students as $uid => $st) $students[$uid]['fig'] = $figures($st);
if ($sort === 'merit') {
    uasort($students, fn($a, $b) => ($b['fig']['total'] <=> $a['fig']['total']) ?: strcmp($a['section'] . $a['roll'], $b['section'] . $b['roll']));
}

/** One slot cell as [code, marks text, css class]. */
$slot_cell = function (?int $sid, array $st) use ($is_year, $codes): array {
    if ($sid === null) return ['', '', 'empty'];
    $row = $st['subjects'][$sid] ?? null;
    if (!$row) return ['', '', 'empty'];
    $code = $codes[$sid] ?? '';
    $cls = [];
    if ($is_year) {
        if (!in_array($sid, $st['best5'] ?? [], true)) $cls[] = 'out';
        if ($row['fail']) $cls[] = 'f';
        if ($row['missing']) return [$code, '—', implode(' ', array_merge($cls, ['miss']))];
        $supp = false;
        foreach ($row['sem'] as $c) if ($c && !empty($c['supp_used'])) $supp = true;   // * only when it is the mark that counts
        $txt = $row['absent'] && $row['total'] <= 0 ? 'AB' : exam_fmt($row['total']) . ($supp ? '*' : '');
        return [$code, $txt, implode(' ', $cls)];
    }
    if ($row['theory_fail'] || $row['practical_fail']) $cls[] = 'f';
    if ($row['missing']) return [$code, '—', implode(' ', array_merge($cls, ['miss']))];
    if ($row['counted'] === null && $row['practical'] === null && $row['theory_absent']) return [$code, 'AB', implode(' ', $cls)];
    $t = $row['counted'] === null ? ($row['theory_absent'] ? 'AB' : '—') : exam_fmt($row['counted']) . ($row['supp_used'] ? '*' : '');
    $txt = $row['practical'] !== null || $row['practical_absent'] ? $t . ' + ' . ($row['practical_absent'] ? 'AB' : exam_fmt($row['practical'])) : $t;
    return [$code, $txt, implode(' ', $cls)];
};

/**
 * A slot broken up the way the mark sheet prints it: Semester 1 · Semester 2 · Practical / Project · Total.
 * A mark rescued by the supplementary carries a *; each part keeps its own fail flag.
 * @return array{code:string,s1:string,s2:string,pr:string,total:string,cls:string,f1:bool,f2:bool,fp:bool}
 */
$slot_parts = function (?int $sid, array $st) use ($codes, $semesters): array {
    $blank = ['code' => '', 's1' => '', 's2' => '', 'pr' => '', 'total' => '', 'cls' => 'empty', 'f1' => false, 'f2' => false, 'fp' => false];
    if ($sid === null) return $blank;
    $row = $st['subjects'][$sid] ?? null;
    if (!$row) return $blank;
    $part = function (?array $c, string $which): string {
        if (!$c || $c['missing']) return '—';
        if ($which === 'p') return $c['practical_absent'] ? 'AB' : ($c['practical'] === null ? '' : exam_fmt($c['practical']));
        if ($c['counted'] === null) return $c['theory_absent'] ? 'AB' : '—';   // absent with no supplementary
        return exam_fmt($c['counted']) . (!empty($c['supp_used']) ? '*' : '');  // * = this is the supplementary mark
    };
    [$a, $b] = [$row['sem'][$semesters[0] ?? 1] ?? null, $row['sem'][$semesters[1] ?? 2] ?? null];
    $cls = [];
    if (!in_array($sid, $st['best5'] ?? [], true)) $cls[] = 'out';
    if ($row['fail']) $cls[] = 'f';
    return ['code' => $codes[$sid] ?? '', 's1' => $part($a, 't'), 's2' => $part($b, 't'), 'pr' => $part($b, 'p'),
        'total' => $row['missing'] ? '—' : exam_fmt($row['total']), 'cls' => implode(' ', $cls),
        'f1' => (bool)($a['theory_fail'] ?? false), 'f2' => (bool)($b['theory_fail'] ?? false), 'fp' => (bool)($b['practical_fail'] ?? false)];
};

$class_name = $class_id ? $classes[$class_id]['name'] : '';
$where = 'Class ' . $class_name . ($section_id ? ' — Section ' . $sections[$section_id] : ' — all sections');
$view_label = $is_year ? 'Year — Semester 1 + Semester 2, best of 5' : ($exam['exam_name'] ?? HS_SEMESTERS[$semester] ?? '');
$title = $view_label . '  ·  ' . $where;
$slots = ['c1' => 'Compulsory 1', 'c2' => 'Compulsory 2', 'm1' => 'Main 1', 'm2' => 'Main 2', 'm3' => 'Main 3', 'a' => 'Additional'];
$summary = ['n' => count($students), 'PASS' => 0, 'FAIL' => 0, 'ABSENT' => 0];
foreach ($students as $st) if (isset($summary[$st['fig']['status']])) $summary[$st['fig']['status']]++;

if ($students && $xlsx) {
    $head = ['#', 'Class', 'Sec', 'Roll', 'Student', 'Father', 'WBCHSE Registration No.', 'Banglar Shiksha ID', 'PEN ID'];
    $band = []; $b = 0;
    foreach ($slots as $label) {
        $b = $b === 1 ? 2 : 1; $from = count($head) + 1;
        $head[] = $label;
        if ($detail) { $head[] = "Sem 1"; $head[] = "Sem 2"; $head[] = "Pract.\n/ Project"; }
        $head[] = $detail ? "Subject\ntotal" : 'Marks';
        for ($c = $from; $c <= count($head); $c++) $band[$c] = $b;
    }
    $head[] = $is_year ? "Total\nbest of 5" : "Total\nthis semester";
    if ($is_year) $head[] = 'Grade';
    $head[] = "Subjects\npassed";
    if ($is_year) $head[] = 'Result';
    $note = 'Session ' . exam_session_name($session_id) . '  ·  ' . ($is_year ? 'the best five subjects make the total; * = the supplementary mark is the one counted (it was the higher)' : '* = the supplementary mark is the one counted (it was the higher); theory + practical / project');
    $rows = array_merge(exam_xlsx_title('HS Tabulation — ' . $title, $note), [$head]);
    $i = 0;
    foreach ($students as $uid => $st) {
        $order = hs_slot_order($st['subjects'], $names);
        $f = $st['fig'];
        $reg = (string)($st['reg_no'] ?? '');
        $r = [++$i, $class_name, $st['section'], $st['roll'], $st['name'], $st['father'], $reg, $st['bsid'], $st['pen']];
        foreach ($slots as $k => $label) {
            if ($detail) { $p = $slot_parts($order[$k], $st); array_push($r, $p['code'], $p['s1'], $p['s2'], $p['pr'], $p['total']); }
            else { [$code, $txt] = $slot_cell($order[$k], $st); $r[] = $code; $r[] = $txt; }
        }
        $r[] = exam_fmt($f['total']);
        if ($is_year) $r[] = $f['grade'];
        $r[] = $f['passed'] . ' of ' . $f['n'];
        if ($is_year) $r[] = $f['status'];
        $rows[] = $r;
    }
    SimpleXLSXWriter::download('hs_tabulation_' . preg_replace('/[^A-Za-z0-9]+/', '_', $view_label . '_' . $where) . '.xlsx', $rows, 'Tabulation',
        exam_xlsx_opts(count($head), 20) + ['band_cols' => $band]);
    exit;
}
$view_opts = ['year' => 'Year (best of 5)'];
foreach ($semesters as $s) $view_opts['s' . $s] = HS_SEMESTERS[$s];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HS Tabulation</title>
<?php exam_styles('hs'); ?>
<style>
    .tab { overflow: auto; } .tab table { border-collapse: collapse; font-size: 12px; min-width: 100%; }
    .tab th, .tab td { border: 1px solid #cfd8e3; padding: 4px 6px; text-align: center; white-space: nowrap; }
    .tab th { background: var(--ex-soft); color: var(--ex-dark); font-size: 11px; } .tab th small { display: block; font-weight: 400; color: #6b7d90; }
    .tab td.l { text-align: left; } .tab td.tot { font-weight: 700; } .tab tr:hover td { background: #fbfdfe; }
    .tab td.slot { border-left: 2px solid var(--ex-muted); min-width: 74px; } .tab th.slot { border-left: 2px solid var(--ex-muted); }
    .tab td.slot b { display: block; font-size: 10px; letter-spacing: .3px; color: #56707c; font-weight: 700; }
    .tab td.slot span { font-size: 13px; font-weight: 700; color: #16303a; }
    .tab td.slot.f span { color: #b71c1c; } .tab td.slot.miss span { color: #b8860b; font-weight: 400; }
    .tab td.slot.out { background: #f6f8f9; } .tab td.slot.out span { color: #8c9aa4; font-weight: 400; text-decoration: line-through; }
    .tab td.slot.empty { background: #fafbfc; color: #c3ccd3; }
    .tab th.sub2, .tab tr.sub2 th { font-size: 9.5px; font-weight: 600; letter-spacing: 0; padding: 2px 4px; text-transform: none; }
    .tab td.code { font-size: 10.5px; font-weight: 700; color: #56707c; letter-spacing: .3px; }
    .tab td.sub-tot { font-weight: 700; } .tab td.f { color: #b71c1c; font-weight: 700; }
    .tab td.out { background: #f6f8f9; color: #8c9aa4; } .tab td.out.sub-tot { text-decoration: line-through; }
    .tab td.name a { color: #16303a; text-decoration: none; font-weight: 600; } .tab td.name a:hover { text-decoration: underline; }
    .tab td.id { font-size: 11px; color: #4d6178; font-variant-numeric: tabular-nums; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; } .sum span { padding: 5px 11px; border-radius: 9px; background: var(--ex-soft); border: 1px solid var(--ex-border); font-size: 12.5px; } .sum b { margin-left: 4px; }
    .legend { font-size: 11.5px; color: #6b7d90; margin-top: 8px; }
    <?php if ($print): ?> body { background: #fff; } .page-box { padding: 6px !important; } .tab table { font-size: <?php echo $detail ? "8.2" : "10"; ?>px; } .tab th, .tab td { padding: 2px 3px; } .tab td.slot { min-width: 0; } @page { size: A4 landscape; margin: 7mm; } <?php endif; ?>
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if ($print): ?>
        <?php exam_school_header('HS Tabulation Sheet — ' . $title, 'Session ' . exam_session_name($session_id)); ?>
        <div class="noprint" style="margin-bottom:8px"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button> <a href="hs_tabulation.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php else: ?>
        <?php exam_banner('HS Tabulation', 'Every student on one row: their own subjects in the Compulsory / Main / Additional columns, then the best-of-5 total, grade and result. Click a name to edit that student\'s marks.', 'fa-table',
            $students ? ["hs_tabulation.php?$qs&print=1" => '<i class="fas fa-print"></i> Print', "hs_tabulation.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel'] : []); ?>
        <?php hs_tabs('hs_tabulation.php'); ?>
        <?php exam_steps(hs_workflow($session_id, $class_id), 'hs_tabulation.php', "session_id=$session_id&class_id=$class_id"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px">
            <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id); ?></select></div>
            <div><label>Section</label><select name="section_id" onchange="this.form.submit()"><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
            <div style="min-width:210px"><label>View</label><select name="view" onchange="this.form.submit()"><?php echo exam_options($view_opts, $view); ?></select></div>
            <div><label>Order</label><select name="sort" onchange="this.form.submit()"><?php echo exam_options(['roll' => 'Roll number', 'merit' => 'Merit (total)'], $sort); ?></select></div>
            <?php if ($is_year): ?><div><label>&nbsp;</label><label style="text-transform:none;font-weight:400;display:flex;align-items:center;gap:6px;height:38px"><input type="checkbox" name="compact" value="1" <?php echo $compact ? 'checked' : ''; ?> onchange="this.form.submit()" style="min-width:auto;height:auto"> Compact — subject total only</label></div><?php endif; ?>
        </form>
    <?php endif; ?>

    <?php if (!$class_id): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-table"></i>No Higher Secondary class found.</div></div>
    <?php elseif (!$students): ?>
        <div class="card"><?php exam_guard('Nothing to tabulate yet', $warnings ? implode(' ', $warnings) : 'No student of ' . $where . ' has a subject combination yet.', "hs_subjects.php?session_id=$session_id&class_id=$class_id", 'Subject Combination'); ?></div>
    <?php else: ?>
    <div class="card">
        <?php if (!$print): ?><h2><i class="fas fa-table"></i> <?php echo h($title); ?> <small><?php echo h(exam_session_name($session_id)); ?></small></h2><?php endif; ?>
        <div class="sum">
            <span>Students<b><?php echo $summary['n']; ?></b></span>
            <?php if ($is_year): ?><span>Pass<b><?php echo $summary['PASS']; ?></b></span><span>Fail<b><?php echo $summary['FAIL']; ?></b></span><span>No marks<b><?php echo $summary['ABSENT']; ?></b></span><?php endif; ?>
            <?php foreach ($warnings as $w): ?><span class="chip warn"><?php echo h($w); ?></span><?php endforeach; ?>
        </div>
        <div class="tab"><table>
            <thead>
            <tr>
                <th <?php echo $detail ? 'rowspan="2"' : ''; ?>>#</th><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Class</th><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Sec</th><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Roll</th>
                <th style="text-align:left" <?php echo $detail ? 'rowspan="2"' : ''; ?>>Student</th><th style="text-align:left" <?php echo $detail ? 'rowspan="2"' : ''; ?>>Father</th>
                <th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Banglar<br>Shiksha ID</th><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>PEN ID</th>
                <?php foreach ($slots as $label): ?><th class="slot" <?php echo $detail ? 'colspan="5"' : ''; ?>><?php echo h($label); ?></th><?php endforeach; ?>
                <th class="slot" <?php echo $detail ? 'rowspan="2"' : ''; ?>>Total<small><?php echo $is_year ? 'best of 5' : 'this semester'; ?></small></th>
                <?php if ($is_year): ?><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Grade</th><?php endif; ?>
                <th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Subjects<br>passed</th>
                <?php if ($is_year): ?><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Result</th><th <?php echo $detail ? 'rowspan="2"' : ''; ?>>Rank</th><?php endif; ?>
            </tr>
            <?php if ($detail): ?>
            <tr class="sub2">
                <?php foreach ($slots as $label): ?>
                    <th class="slot">Sub</th><th>Sem 1</th><th>Sem 2</th><th>Pr/Proj</th><th>Total</th>
                <?php endforeach; ?>
            </tr>
            <?php endif; ?>
            </thead>
            <tbody>
            <?php $i = 0; foreach ($students as $uid => $st): $i++; $order = hs_slot_order($st['subjects'], $names); $f = $st['fig']; ?>
            <tr>
                <td><?php echo $i; ?></td><td><?php echo h($class_name); ?></td><td><?php echo h($st['section']); ?></td><td><?php echo h($st['roll']); ?></td>
                <td class="l name"><?php echo $print ? h($st['name']) : '<a href="hs_student_marks_edit.php?uid=' . urlencode($uid) . '&session_id=' . $session_id . '" title="Edit this student\'s marks">' . h($st['name']) . '</a>'; ?></td>
                <td class="l" style="color:#4d6178"><?php echo h($st['father']); ?></td>
                <td class="id"><?php echo h($st['bsid']); ?></td><td class="id"><?php echo h($st['pen']); ?></td>
                <?php foreach ($slots as $k => $label): ?>
                    <?php if ($detail): $p = $slot_parts($order[$k], $st); ?>
                        <td class="slot code <?php echo h($p['cls']); ?>"><?php echo $p['code'] !== '' ? h($p['code']) : '—'; ?></td>
                        <td class="<?php echo h($p['cls']) . ($p['f1'] ? ' f' : ''); ?>"><?php echo h($p['s1']); ?></td>
                        <td class="<?php echo h($p['cls']) . ($p['f2'] ? ' f' : ''); ?>"><?php echo h($p['s2']); ?></td>
                        <td class="<?php echo h($p['cls']) . ($p['fp'] ? ' f' : ''); ?>"><?php echo h($p['pr']); ?></td>
                        <td class="sub-tot <?php echo h($p['cls']); ?>"><?php echo h($p['total']); ?></td>
                    <?php else: [$code, $txt, $cls] = $slot_cell($order[$k], $st); ?>
                        <td class="slot <?php echo h($cls); ?>"><?php if ($code !== ''): ?><b><?php echo h($code); ?></b><span><?php echo h($txt); ?></span><?php else: ?>—<?php endif; ?></td>
                    <?php endif; ?>
                <?php endforeach; ?>
                <td class="slot tot"><?php echo exam_fmt($f['total']); ?><?php if ($f['full'] > 0): ?><small style="color:#6b7d90;font-weight:400"> / <?php echo exam_fmt($f['full']); ?></small><?php endif; ?></td>
                <?php if ($is_year): ?><td class="tot"><?php echo h($f['grade']); ?></td><?php endif; ?>
                <td><?php echo $f['passed']; ?> of <?php echo $f['n']; ?></td>
                <?php if ($is_year): ?><td><?php echo $print ? h($f['status']) : result_badge($f['status']); ?></td><td class="tot"><?php echo $f['rank'] ?? '—'; ?></td><?php endif; ?>
            </tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <div class="legend">
            <?php if ($detail): ?>Every subject shows Semester 1, Semester 2 and the practical / project on their own, then the subject total. <b>Greyed, struck-through</b> subjects are outside the best five, so they are not in the Grand Total.<?php elseif ($is_year): ?>Each subject cell is Semester 1 + Semester 2. <b>Struck-through</b> subjects are outside the best five, so they are not in the total.<?php else: ?>Each cell is the theory that counts<?php echo $exam && (int)$exam['has_practical'] ? ' + the practical / project' : ''; ?> of this semester.<?php endif; ?>
            · <b>*</b> the supplementary mark counted (it beat the regular one) · <b>AB</b> absent · <b>—</b> not entered · <span style="color:#b71c1c">red</span> = below the pass marks (theory and practical are passed separately)<?php if ($is_year): ?> · rank is within the list shown (<?php echo $section_id ? 'this section' : 'whole class'; ?>)<?php endif; ?>.
        </div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

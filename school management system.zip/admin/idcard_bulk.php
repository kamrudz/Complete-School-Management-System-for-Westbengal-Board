<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/card_document_helper.php");
require_once("../includes/base_url.php");
require_once("../includes/idcard_helper.php");
require_once("../includes/security.php");

$stage = 1;
if(isset($_GET['stage2'])) $stage = 2;
if(isset($_POST['stage3'])) $stage = 3;

// ===== Common lookups =====
$sessions = mysqli_query($conn, "SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC");
$classes  = mysqli_query($conn, "SELECT id, class_name FROM classes ORDER BY sort_order ASC");

$default_session_id = document_get_active_session_id($conn);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bulk ID Card</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 700px; }
.form-row { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 18px; }
.form-group { flex: 1; min-width: 180px; }
.form-group label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-group select { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.style-choice { display: flex; gap: 10px; flex-wrap: wrap; }
.style-choice label { flex: 1; min-width: 160px; border: 2px solid #e4edf6; border-radius: 10px; padding: 12px; text-align: center; cursor: pointer; font-size: 13px; font-weight: 600; color: #1a3b55; }
.style-choice input { display: none; }
.style-choice input:checked + span { color: #003366; }
.style-choice label:has(input:checked) { border-color: #003366; background: #eaf2fb; }

table.stu-select { width: 100%; border-collapse: collapse; margin-top: 15px; }
table.stu-select th, table.stu-select td { padding: 8px 10px; border-bottom: 1px solid #e4edf6; font-size: 13px; text-align: left; }
table.stu-select th { background: #003366; color: #fff; }
.select-all-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }

/* ===== Print grid ===== */
.toolbar { max-width: 900px; margin: 0 auto 15px auto; display: flex; gap: 10px; justify-content: flex-end; }
.toolbar button, .toolbar a { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; text-decoration: none; font-size: 14px; cursor: pointer; }
.print-sheet { max-width: 900px; margin: 0 auto; display: flex; flex-wrap: wrap; gap: 4mm; justify-content: flex-start; background: #fff; padding: 10mm; }
.id-card { border-radius: 3mm; box-shadow: 0 2px 8px rgba(0,0,0,0.15); position: relative; overflow: hidden; background: #fff; break-inside: avoid; page-break-inside: avoid; }
.id-header { background: #003366; color: #fff; padding: 2mm 3mm; display: flex; align-items: center; gap: 2mm; }
.id-header img.logo { object-fit: contain; background: #fff; border-radius: 50%; padding: 0.5mm; }
.id-header .school-name { font-weight: bold; line-height: 1.25; }
.id-header .school-name small { display: block; font-weight: normal; opacity: 0.85; }
.id-info b { color: #003366; }
.id-photo { object-fit: cover; border: 0.4mm solid #003366; border-radius: 1mm; background: #ddd; }

.landscape-card { width: 85.6mm; height: 54mm; display: flex; flex-direction: column; }
.landscape-card .id-header img.logo { height: 7mm; width: 7mm; }
.landscape-card .id-header .school-name { font-size: 2.3mm; }
.landscape-card .id-header .school-name small { font-size: 1.5mm; }
.landscape-card .id-body { display: flex; padding: 1.5mm 3mm; gap: 2mm; flex: 1; }
.landscape-card .id-photo { width: 15mm; height: 18mm; }
.landscape-card .id-info { flex: 1; font-size: 1.9mm; line-height: 1.45; color: #222; }
.landscape-card .id-info .stu-name { font-size: 2.6mm; font-weight: bold; color: #003366; margin-bottom: 0.4mm; }
.landscape-card .guardian-line { font-size: 1.8mm; color: #333; margin-top: 0.8mm; }
.landscape-card .qr-footer { display: flex; align-items: center; justify-content: space-between; padding: 0 3mm 1.5mm 3mm; }
.landscape-card .qr-footer img { width: 9mm; height: 9mm; }
.landscape-card .qr-footer .session-tag { font-size: 1.6mm; color: #555; text-align: right; }

.portrait-card { width: 54mm; height: 85.6mm; display: flex; flex-direction: column; }
.portrait-card .id-header { flex-direction: column; text-align: center; padding: 3mm 2mm; }
.portrait-card .id-header img.logo { height: 10mm; width: 10mm; margin-bottom: 1mm; }
.portrait-card .id-header .school-name { font-size: 3mm; }
.portrait-card .id-header .school-name small { font-size: 2mm; }
.portrait-card .id-photo-wrap { text-align: center; padding: 3mm 0 1mm 0; }
.portrait-card .id-photo { width: 26mm; height: 30mm; }
.portrait-card .stu-name { text-align: center; font-size: 3.6mm; font-weight: bold; color: #003366; margin: 1mm 0; }
.portrait-card .id-info { padding: 0 4mm; font-size: 2.6mm; line-height: 1.65; color: #222; text-align: center; }
.portrait-card .guardian-block { padding: 1.5mm 4mm; font-size: 2.3mm; line-height: 1.6; color: #333; text-align: center; border-top: 0.3mm dashed #ccc; margin-top: 2mm; }
.portrait-card .qr-footer { margin-top: auto; display: flex; align-items: center; justify-content: space-between; padding: 2mm 4mm 3mm 4mm; background: #f5f8fb; }
.portrait-card .qr-footer img { width: 14mm; height: 14mm; }
.portrait-card .qr-footer .session-tag { font-size: 2.1mm; color: #555; text-align: right; }
.portrait-card .note { font-size: 1.9mm; color: #a4161a; font-style: italic; text-align: center; padding: 0 3mm; }

.both-pair { display: flex; gap: 3mm; break-inside: avoid; page-break-inside: avoid; }
.id-back { padding: 3mm; font-size: 2.1mm; color: #222; display: flex; flex-direction: column; }
.id-back .back-title { background: #003366; color: #fff; text-align: center; padding: 1mm; font-size: 2.3mm; font-weight: bold; margin: -3mm -3mm 2mm -3mm; }
.id-back .row { margin-bottom: 1.3mm; }
.id-back .row b { display: inline-block; min-width: 16mm; }
.id-back .sign-area { margin-top: auto; display: flex; justify-content: space-between; align-items: flex-end; }
.id-back .sign-area img { height: 6mm; }
.id-back .sign-line { font-size: 1.8mm; border-top: 0.3mm solid #333; padding-top: 0.7mm; text-align: center; width: 22mm; }
.id-back .note { font-size: 1.8mm; color: #a4161a; font-style: italic; margin-top: 1.5mm; }

@media print {
    body { background: #fff; }
    .toolbar, .no-print { display: none !important; }
    .print-sheet { padding: 0; }
    .id-card { box-shadow: none; border: 0.2mm solid #ccc; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<?php if($stage === 1): ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-id-card"></i> Bulk ID Card <span>Class / Section wise generate</span></div>
        <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
    <div class="form-card">
        <form method="GET" action="idcard_bulk.php">
            <input type="hidden" name="stage2" value="1">
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Session</label>
                    <select name="session_id" required>
                        <?php mysqli_data_seek($sessions, 0); while($s = mysqli_fetch_assoc($sessions)): ?>
                        <option value="<?php echo $s['id']; ?>" <?php echo $s['id']==$default_session_id?'selected':''; ?>><?php echo htmlspecialchars($s['session_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-layer-group"></i> Class</label>
                    <select name="class_id" id="class_id" required onchange="loadSections()">
                        <option value="">-- Select Class --</option>
                        <?php mysqli_data_seek($classes, 0); while($c = mysqli_fetch_assoc($classes)): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['class_name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-object-group"></i> Section</label>
                    <select name="section_id" id="section_id">
                        <option value="">All Sections</option>
                    </select>
                </div>
            </div>

            <div class="form-group" style="margin-bottom:18px;">
                <label><i class="fas fa-id-badge"></i> Card Style</label>
                <div class="style-choice">
                    <label><input type="radio" name="card_style" value="single_portrait" checked><span>Single Side - Portrait</span></label>
                    <label><input type="radio" name="card_style" value="single_landscape"><span>Single Side - Landscape</span></label>
                    <label><input type="radio" name="card_style" value="both"><span>Both Side (Front+Back)</span></label>
                </div>
            </div>

            <button type="submit" class="btn btn-success"><i class="fas fa-arrow-right"></i> Next: Select Students</button>
        </form>
    </div>
</div>
<script>
async function loadSections(){
    const classId = document.getElementById('class_id').value;
    const sessionId = document.querySelector('select[name="session_id"]').value;
    const sectionSelect = document.getElementById('section_id');
    sectionSelect.innerHTML = '<option value="">All Sections</option>';
    if(!classId || !sessionId) return;
    try {
        const res = await fetch('get_sections.php?class_id=' + classId + '&session_id=' + sessionId);
        const html = await res.text();
        sectionSelect.innerHTML = '<option value="">All Sections</option>' + html;
    } catch(e) { /* get_sections.php not reachable - "All Sections" still works */ }
}
</script>

<?php elseif($stage === 2):
    $session_id = (int)($_GET['session_id'] ?? 0);
    $class_id   = (int)($_GET['class_id'] ?? 0);
    $section_id = (int)($_GET['section_id'] ?? 0);
    $card_style = in_array($_GET['card_style'] ?? '', ['single_portrait','single_landscape','both']) ? $_GET['card_style'] : 'single_portrait';

    $q = document_get_students_for_class($conn, $session_id, $class_id, $section_id);
    $class_row = ['class_name' => document_get_class_name($conn, $class_id)];
?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-id-card"></i> Select Students <span><?php echo htmlspecialchars($class_row['class_name'] ?? ''); ?></span></div>
        <a href="idcard_bulk.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Change Filter</a>
    </div>
    <form method="POST" action="idcard_bulk.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="stage3" value="1">
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
        <input type="hidden" name="card_style" value="<?php echo htmlspecialchars($card_style); ?>">

        <div class="select-all-bar">
            <label><input type="checkbox" id="selectAll" checked onclick="toggleAll(this)"> Select All</label>
            <button type="submit" class="btn btn-success"><i class="fas fa-print"></i> Generate & Print Selected</button>
        </div>

        <table class="stu-select">
            <tr><th></th><th>Roll</th><th>Name</th><th>Section</th><th>Admission No</th></tr>
            <?php $count = 0; while($row = mysqli_fetch_assoc($q)): $count++; ?>
            <tr>
                <td><input type="checkbox" name="student_ids[]" value="<?php echo $row['id']; ?>" checked class="stu-cb"></td>
                <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                <td><?php echo htmlspecialchars($row['section_name'] ?? '-'); ?></td>
                <td><?php echo htmlspecialchars($row['admission_no']); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <?php if($count === 0): ?>
            <p style="text-align:center; color:#a4161a; padding:20px;">এই class/section এ কোনো active student পাওয়া যায়নি।</p>
        <?php endif; ?>
    </form>
</div>
<script>
function toggleAll(el){
    document.querySelectorAll('.stu-cb').forEach(cb => cb.checked = el.checked);
}
</script>

<?php else: // stage 3 - print
    verify_csrf_or_die();
    $session_id = (int)($_POST['session_id'] ?? 0);
    $card_style = in_array($_POST['card_style'] ?? '', ['single_portrait','single_landscape','both']) ? $_POST['card_style'] : 'single_portrait';
    $student_ids = array_map('student_uid_clean', $_POST['student_ids'] ?? []);

    if(empty($student_ids)) {
        echo "<div class='page-box'><p>কোনো student select করা হয়নি। <a href='idcard_bulk.php'>ফিরে যান</a></p></div></body></html>";
        exit();
    }

    $students_q = document_get_selected_students($conn, $session_id, $student_ids);
    if ($students_q === false) {
        echo "<div class='page-box'><p>Invalid student selection.</p></div></body></html>";
        exit();
    }
    $school = document_get_school_settings($conn);
?>
<div class="toolbar">
    <a href="idcard_bulk.php"><i class="fas fa-arrow-left"></i> Back</a>
    <button onclick="window.print()"><i class="fas fa-print"></i> Print / Save as PDF</button>
</div>
<div class="print-sheet">
<?php while($student = mysqli_fetch_assoc($students_q)):
    $guardian = null;
    if(!empty($student['guardian_id'])) {
        $stmt = mysqli_prepare($conn, "SELECT * FROM guardians WHERE guardian_id=?");
        mysqli_stmt_bind_param($stmt, "i", $student['guardian_id']);
        mysqli_stmt_execute($stmt);
        $guardian = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    }
    $guardian_contact = $guardian['guardian_contact'] ?? ($guardian['father_mobile'] ?? '-');
    $address_short = trim(($student['village'] ?? '').(!empty($student['post_office']) ? ', '.$student['post_office'] : ''));
    $card = ensure_id_card($conn, $student['id'], $session_id);
    $qr_src = "idcard_qr.php?token=" . htmlspecialchars($card['verification_token']);
?>

<?php if($card_style === 'single_portrait'): ?>
    <div class="id-card portrait-card">
        <div class="id-header">
            <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name"><?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?><small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small></div>
        </div>
        <div class="id-photo-wrap">
            <?php if(!empty($student['photo'])): ?><img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo"><?php else: ?><div class="id-photo"></div><?php endif; ?>
        </div>
        <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
        <div class="id-info">
            <div><b>Class:</b> <?php echo htmlspecialchars($student['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($student['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($student['roll_no'] ?? '-'); ?></div>
            <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?> &nbsp; <b>Blood:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
            <div><b>DOB:</b> <?php echo !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '-'; ?></div>
        </div>
        <div class="guardian-block">
            <b style="color:#003366;">Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?><br>
            <b style="color:#003366;">Mobile:</b> <?php echo htmlspecialchars($guardian_contact); ?><br>
            <?php if(!empty($address_short)): ?><b style="color:#003366;">Address:</b> <?php echo htmlspecialchars($address_short); ?><?php endif; ?>
        </div>
        <div class="note">If found, please return to the school office.</div>
        <div class="qr-footer">
            <img src="<?php echo $qr_src; ?>" alt="QR">
            <div class="session-tag">Session<br><b><?php echo htmlspecialchars($student['session_name'] ?? '-'); ?></b></div>
        </div>
    </div>

<?php elseif($card_style === 'single_landscape'): ?>
    <div class="id-card landscape-card">
        <div class="id-header">
            <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name"><?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?><small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small></div>
        </div>
        <div class="id-body">
            <?php if(!empty($student['photo'])): ?><img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo"><?php else: ?><div class="id-photo"></div><?php endif; ?>
            <div class="id-info">
                <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
                <div><b>Class:</b> <?php echo htmlspecialchars($student['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($student['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($student['roll_no'] ?? '-'); ?></div>
                <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?> &nbsp; <b>Blood:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
                <div class="guardian-line"><b>Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?> &nbsp; <b>Mob:</b> <?php echo htmlspecialchars($guardian_contact); ?></div>
            </div>
        </div>
        <div class="qr-footer">
            <img src="<?php echo $qr_src; ?>" alt="QR">
            <div class="session-tag">Session: <b><?php echo htmlspecialchars($student['session_name'] ?? '-'); ?></b></div>
        </div>
    </div>

<?php else: /* both side */ ?>
    <div class="both-pair">
        <div class="id-card landscape-card">
            <div class="id-header">
                <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
                <div class="school-name"><?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?><small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small></div>
            </div>
            <div class="id-body">
                <?php if(!empty($student['photo'])): ?><img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo"><?php else: ?><div class="id-photo"></div><?php endif; ?>
                <div class="id-info">
                    <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
                    <div><b>Class:</b> <?php echo htmlspecialchars($student['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($student['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($student['roll_no'] ?? '-'); ?></div>
                    <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?></div>
                    <div><b>Blood Group:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
                </div>
            </div>
            <div class="qr-footer">
                <img src="<?php echo $qr_src; ?>" alt="QR">
                <div class="session-tag">Session<br><b><?php echo htmlspecialchars($student['session_name'] ?? '-'); ?></b></div>
            </div>
        </div>
        <div class="id-card landscape-card id-back">
            <div class="back-title">IF FOUND, PLEASE CONTACT</div>
            <div class="row"><b>Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?></div>
            <div class="row"><b>Mobile:</b> <?php echo htmlspecialchars($guardian_contact); ?></div>
            <div class="row"><b>Address:</b> <?php echo htmlspecialchars($address_short); ?></div>
            <div class="row"><b>School:</b> <?php echo htmlspecialchars($school['school_name'] ?? '-'); ?></div>
            <div class="row"><b>Ph:</b> <?php echo htmlspecialchars($school['phone'] ?? '-'); ?></div>
            <div class="note">This card is the property of the school.</div>
            <div class="sign-area">
                <div></div>
                <div>
                    <?php if(!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['hoi_signature']); ?>"><?php endif; ?>
                    <div class="sign-line">Head of Institution</div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php endwhile; ?>
</div>
<?php endif; ?>
</body>
</html>

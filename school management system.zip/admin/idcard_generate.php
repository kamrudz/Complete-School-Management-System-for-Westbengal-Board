<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/base_url.php");
require_once("../includes/idcard_helper.php");
require_once("../includes/card_document_helper.php");

if(student_uid_clean($_GET['id'] ?? '') === '') {
    $_SESSION['error'] = "Invalid Student ID!";
    header("Location: students.php");
    exit();
}
$student_id = student_uid_clean($_GET['id']);

// ===== Style selection =====
// style: 'both' (Front+Back, landscape) or 'single' (one side, all info combined)
// orientation (only used when style=single): 'portrait' or 'landscape'
$style = ($_GET['style'] ?? 'both') === 'single' ? 'single' : 'both';
$orientation = ($_GET['orientation'] ?? 'portrait') === 'landscape' ? 'landscape' : 'portrait';

// ===== Session (defaults to active session) =====
if(!empty($_GET['session_id'])) {
    $session_id = (int)$_GET['session_id'];
} else {
    $session_id = document_get_active_session_id($conn);
}

$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, "s", $student_id);
mysqli_stmt_execute($stmt);
$student = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$student) {
    $_SESSION['error'] = "Student not found!";
    header("Location: students.php");
    exit();
}
if ($student['student_status'] !== 'Active') {
    $_SESSION['error'] = "{$student['student_name']} is {$student['student_status']} — an ID card is issued to Active students only.";
    header("Location: students.php");
    exit();
}

$guardian = null;
if(!empty($student['guardian_id'])) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM guardians WHERE guardian_id=?");
    mysqli_stmt_bind_param($stmt, "i", $student['guardian_id']);
    mysqli_stmt_execute($stmt);
    $guardian = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$academic = document_get_student_academic($conn, $student_id, $session_id);
if (!$academic) {
    $_SESSION['error'] = 'Student has no academic record for the selected session.';
    header('Location: idcard_home.php');
    exit();
}

$school = document_get_school_settings($conn);

// ===== Get or create the ID card (token) for this student+session =====
$card = ensure_id_card($conn, $student_id, $session_id);

$guardian_contact = $guardian['guardian_contact'] ?? ($guardian['father_mobile'] ?? '-');
$address_short = trim(($student['village'] ?? '').(!empty($student['post_office']) ? ', '.$student['post_office'] : ''));

function tab_url($id, $style, $orientation) {
    return "idcard_generate.php?id=" . rawurlencode($id) . "&style=$style&orientation=$orientation";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ID Card - <?php echo htmlspecialchars($student['student_name']); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: #eef2f6; margin: 0; padding: 20px; }

.toolbar { max-width: 850px; margin: 0 auto 15px auto; display: flex; gap: 10px; justify-content: space-between; flex-wrap: wrap; align-items: center; }
.style-tabs { display: flex; gap: 8px; flex-wrap: wrap; }
.style-tabs a { padding: 9px 16px; border-radius: 8px; border: 2px solid #003366; color: #003366; text-decoration: none; font-size: 13px; font-weight: 600; }
.style-tabs a.active { background: #003366; color: #fff; }
.toolbar .actions { display: flex; gap: 10px; }
.toolbar .actions button, .toolbar .actions a { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; text-decoration: none; font-size: 14px; cursor: pointer; }

.card-wrap { max-width: 850px; margin: 0 auto; display: flex; gap: 25px; flex-wrap: wrap; justify-content: center; }

/* ============ Shared card look ============ */
.id-card { border-radius: 3mm; box-shadow: 0 4px 14px rgba(0,0,0,0.18); position: relative; overflow: hidden; background: #fff; }
.id-header { background: #003366; color: #fff; padding: 2mm 3mm; display: flex; align-items: center; gap: 2mm; }
.id-header img.logo { object-fit: contain; background: #fff; border-radius: 50%; padding: 0.5mm; }
.id-header .school-name { font-weight: bold; line-height: 1.25; }
.id-header .school-name small { display: block; font-weight: normal; opacity: 0.85; }
.id-info b { color: #003366; }
.id-photo { object-fit: cover; border: 0.4mm solid #003366; border-radius: 1mm; background: #ddd; }

/* ============ BOTH SIDE (landscape CR80: 85.6mm x 54mm) ============ */
.both .id-card { width: 85.6mm; height: 54mm; }
.both .id-front { display: flex; flex-direction: column; }
.both .id-header img.logo { height: 8mm; width: 8mm; }
.both .id-header .school-name { font-size: 2.6mm; }
.both .id-header .school-name small { font-size: 1.7mm; }
.both .id-body { display: flex; padding: 2mm 3mm; gap: 2.5mm; flex: 1; }
.both .id-photo { width: 17mm; height: 20mm; }
.both .id-info { flex: 1; font-size: 2.3mm; line-height: 1.55; color: #222; }
.both .id-info .stu-name { font-size: 3mm; font-weight: bold; color: #003366; margin-bottom: 0.5mm; }
.both .id-qr-row { display: flex; align-items: center; justify-content: space-between; padding: 0 3mm 2mm 3mm; }
.both .id-qr-row img { width: 12mm; height: 12mm; }
.both .id-qr-row .session-tag { font-size: 1.9mm; color: #555; text-align: right; }
.both .id-back { padding: 3mm; font-size: 2.1mm; color: #222; display: flex; flex-direction: column; height: 100%; }
.both .id-back .back-title { background: #003366; color: #fff; text-align: center; padding: 1mm; font-size: 2.3mm; font-weight: bold; margin: -3mm -3mm 2mm -3mm; }
.both .id-back .row { margin-bottom: 1.3mm; }
.both .id-back .row b { display: inline-block; min-width: 16mm; }
.both .id-back .sign-area { margin-top: auto; display: flex; justify-content: space-between; align-items: flex-end; }
.both .id-back .sign-area img { height: 6mm; }
.both .id-back .sign-line { font-size: 1.8mm; border-top: 0.3mm solid #333; padding-top: 0.7mm; text-align: center; width: 22mm; }
.both .id-back .note { font-size: 1.8mm; color: #a4161a; font-style: italic; margin-top: 1.5mm; }

/* ============ SINGLE SIDE - PORTRAIT (54mm x 85.6mm) ============ */
.single-portrait .id-card { width: 54mm; height: 85.6mm; display: flex; flex-direction: column; }
.single-portrait .id-header { flex-direction: column; text-align: center; padding: 3mm 2mm; }
.single-portrait .id-header img.logo { height: 10mm; width: 10mm; margin-bottom: 1mm; }
.single-portrait .id-header .school-name { font-size: 3mm; }
.single-portrait .id-header .school-name small { font-size: 2mm; }
.single-portrait .id-photo-wrap { text-align: center; padding: 3mm 0 1mm 0; }
.single-portrait .id-photo { width: 26mm; height: 30mm; }
.single-portrait .stu-name { text-align: center; font-size: 3.6mm; font-weight: bold; color: #003366; margin: 1mm 0; }
.single-portrait .id-info { padding: 0 4mm; font-size: 2.6mm; line-height: 1.65; color: #222; text-align: center; }
.single-portrait .guardian-block { padding: 1.5mm 4mm; font-size: 2.3mm; line-height: 1.6; color: #333; text-align: center; border-top: 0.3mm dashed #ccc; margin-top: 2mm; }
.single-portrait .qr-footer { margin-top: auto; display: flex; align-items: center; justify-content: space-between; padding: 2mm 4mm 3mm 4mm; background: #f5f8fb; }
.single-portrait .qr-footer img { width: 14mm; height: 14mm; }
.single-portrait .qr-footer .session-tag { font-size: 2.1mm; color: #555; text-align: right; }
.single-portrait .note { font-size: 1.9mm; color: #a4161a; font-style: italic; text-align: center; padding: 0 3mm; }

/* ============ SINGLE SIDE - LANDSCAPE (85.6mm x 54mm) ============ */
.single-landscape .id-card { width: 85.6mm; height: 54mm; display: flex; flex-direction: column; }
.single-landscape .id-header img.logo { height: 7mm; width: 7mm; }
.single-landscape .id-header .school-name { font-size: 2.3mm; }
.single-landscape .id-header .school-name small { font-size: 1.5mm; }
.single-landscape .id-body { display: flex; padding: 1.5mm 3mm; gap: 2mm; flex: 1; }
.single-landscape .id-photo { width: 15mm; height: 18mm; }
.single-landscape .id-info { flex: 1; font-size: 1.9mm; line-height: 1.45; color: #222; }
.single-landscape .id-info .stu-name { font-size: 2.6mm; font-weight: bold; color: #003366; margin-bottom: 0.4mm; }
.single-landscape .guardian-line { font-size: 1.8mm; color: #333; margin-top: 0.8mm; }
.single-landscape .qr-footer { display: flex; align-items: center; justify-content: space-between; padding: 0 3mm 1.5mm 3mm; }
.single-landscape .qr-footer img { width: 9mm; height: 9mm; }
.single-landscape .qr-footer .session-tag { font-size: 1.6mm; color: #555; text-align: right; }

@media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none; }
    .card-wrap { gap: 5mm; }
    .id-card { box-shadow: none; border: 0.2mm solid #ccc; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<div class="toolbar">
    <div class="style-tabs">
        <a href="<?php echo tab_url($student_id,'both','landscape'); ?>" class="<?php echo $style==='both'?'active':''; ?>"><i class="fas fa-clone"></i> Both Side (Landscape)</a>
        <a href="<?php echo tab_url($student_id,'single','portrait'); ?>" class="<?php echo ($style==='single'&&$orientation==='portrait')?'active':''; ?>"><i class="fas fa-mobile-alt"></i> Single Side - Portrait</a>
        <a href="<?php echo tab_url($student_id,'single','landscape'); ?>" class="<?php echo ($style==='single'&&$orientation==='landscape')?'active':''; ?>"><i class="fas fa-rectangle-landscape"></i> Single Side - Landscape</a>
    </div>
    <div class="actions">
        <a href="students.php"><i class="fas fa-arrow-left"></i> Back</a>
        <button onclick="window.print()"><i class="fas fa-print"></i> Print</button>
    </div>
</div>

<?php if($style === 'both'): ?>
<div class="card-wrap both">
    <!-- ===== FRONT ===== -->
    <div class="id-card id-front">
        <div class="id-header">
            <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name">
                <?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?>
                <small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small>
            </div>
        </div>
        <div class="id-body">
            <?php if(!empty($student['photo'])): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo">
            <?php else: ?><div class="id-photo"></div><?php endif; ?>
            <div class="id-info">
                <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
                <div><b>Class:</b> <?php echo htmlspecialchars($academic['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($academic['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($academic['roll_no'] ?? '-'); ?></div>
                <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?></div>
                <div><b>Blood Group:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
                <div><b>DOB:</b> <?php echo !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '-'; ?></div>
            </div>
        </div>
        <div class="id-qr-row">
            <img src="idcard_qr.php?token=<?php echo htmlspecialchars($card['verification_token']); ?>" alt="QR">
            <div class="session-tag">Session<br><b><?php echo htmlspecialchars($academic['session_name'] ?? '-'); ?></b></div>
        </div>
    </div>

    <!-- ===== BACK ===== -->
    <div class="id-card id-back">
        <div class="back-title">IF FOUND, PLEASE CONTACT</div>
        <div class="row"><b>Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?></div>
        <div class="row"><b>Mobile:</b> <?php echo htmlspecialchars($guardian_contact); ?></div>
        <div class="row"><b>Address:</b> <?php echo htmlspecialchars($address_short); ?></div>
        <div class="row"><b>School:</b> <?php echo htmlspecialchars($school['school_name'] ?? '-'); ?></div>
        <div class="row"><b>Ph:</b> <?php echo htmlspecialchars($school['phone'] ?? '-'); ?></div>
        <div class="note">This card is the property of the school. If lost, please return to the school office.</div>
        <div class="sign-area">
            <div></div>
            <div>
                <?php if(!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['hoi_signature']); ?>"><?php endif; ?>
                <div class="sign-line">Head of Institution</div>
            </div>
        </div>
    </div>
</div>

<?php elseif($style === 'single' && $orientation === 'portrait'): ?>
<div class="card-wrap single-portrait">
    <div class="id-card">
        <div class="id-header">
            <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name">
                <?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?>
                <small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small>
            </div>
        </div>
        <div class="id-photo-wrap">
            <?php if(!empty($student['photo'])): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo">
            <?php else: ?><div class="id-photo"></div><?php endif; ?>
        </div>
        <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
        <div class="id-info">
            <div><b>Class:</b> <?php echo htmlspecialchars($academic['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($academic['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($academic['roll_no'] ?? '-'); ?></div>
            <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?> &nbsp; <b>Blood:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
            <div><b>DOB:</b> <?php echo !empty($student['dob']) ? date('d-m-Y', strtotime($student['dob'])) : '-'; ?></div>
        </div>
        <div class="guardian-block">
            <b style="color:#003366;">Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?><br>
            <b style="color:#003366;">Mobile:</b> <?php echo htmlspecialchars($guardian_contact); ?><br>
            <?php if(!empty($address_short)): ?><b style="color:#003366;">Address:</b> <?php echo htmlspecialchars($address_short); ?><?php endif; ?>
        </div>
        <div class="note">If found, please return to the school office.</div>
        <div class="qr-footer">
            <img src="idcard_qr.php?token=<?php echo htmlspecialchars($card['verification_token']); ?>" alt="QR">
            <div class="session-tag">Session<br><b><?php echo htmlspecialchars($academic['session_name'] ?? '-'); ?></b></div>
        </div>
    </div>
</div>

<?php else: /* single-landscape */ ?>
<div class="card-wrap single-landscape">
    <div class="id-card">
        <div class="id-header">
            <?php if(!empty($school['logo'])): ?><img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
            <div class="school-name">
                <?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?>
                <small>STUDENT IDENTITY CARD<?php echo !empty($school['established_year']) ? ' · ESTD. ' . (int)$school['established_year'] : ''; ?></small>
            </div>
        </div>
        <div class="id-body">
            <?php if(!empty($student['photo'])): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" class="id-photo">
            <?php else: ?><div class="id-photo"></div><?php endif; ?>
            <div class="id-info">
                <div class="stu-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
                <div><b>Class:</b> <?php echo htmlspecialchars($academic['class_name'] ?? '-'); ?> &nbsp; <b>Sec:</b> <?php echo htmlspecialchars($academic['section_name'] ?? '-'); ?> &nbsp; <b>Roll:</b> <?php echo htmlspecialchars($academic['roll_no'] ?? '-'); ?></div>
                <div><b>Adm No:</b> <?php echo htmlspecialchars($student['admission_no'] ?? '-'); ?> &nbsp; <b>Blood:</b> <?php echo htmlspecialchars($student['blood_group'] ?? '-'); ?></div>
                <div class="guardian-line"><b>Guardian:</b> <?php echo htmlspecialchars($guardian['father_name'] ?? '-'); ?> &nbsp; <b>Mob:</b> <?php echo htmlspecialchars($guardian_contact); ?></div>
            </div>
        </div>
        <div class="qr-footer">
            <img src="idcard_qr.php?token=<?php echo htmlspecialchars($card['verification_token']); ?>" alt="QR">
            <div class="session-tag">Session: <b><?php echo htmlspecialchars($academic['session_name'] ?? '-'); ?></b><br>If found, contact school office.</div>
        </div>
    </div>
</div>
<?php endif; ?>

</body>
</html>

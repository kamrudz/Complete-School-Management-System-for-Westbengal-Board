<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

$search = trim($_GET['search'] ?? '');
$results = [];
if ($search !== '') {
    $like = '%' . $search . '%';
    $stmt = mysqli_prepare($conn, "
        SELECT s.id, s.student_name, s.admission_no, s.photo, s.banglarshiksha_id, s.pen_id,
               h.roll_no, c.class_name, sec.section_name
        FROM students s
        LEFT JOIN student_academic_history h ON h.student_id=s.id AND h.academic_status='Current'
        LEFT JOIN classes c ON c.id=h.class_id
        LEFT JOIN sections sec ON sec.id=h.section_id
        WHERE s.student_name LIKE ? OR s.admission_no LIKE ? OR s.banglarshiksha_id LIKE ? OR s.pen_id LIKE ?
        ORDER BY s.student_name ASC LIMIT 30
    ");
    mysqli_stmt_bind_param($stmt, 'ssss', $like, $like, $like, $like);
    mysqli_stmt_execute($stmt);
    $q = mysqli_stmt_get_result($stmt);
    while ($r = mysqli_fetch_assoc($q)) $results[] = $r;
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ID Card</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.option-grid { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 25px; }
.option-card { flex: 1; min-width: 260px; background: #fff; border: 1px solid #e4edf6; border-radius: 12px; padding: 25px; }
.option-card .opt-icon { width: 50px; height: 50px; border-radius: 12px; background: #eaf2fb; color: #003366; display: flex; align-items: center; justify-content: center; font-size: 22px; margin-bottom: 12px; }
.option-card h3 { margin: 0 0 6px 0; color: #003366; font-size: 17px; }
.option-card p { margin: 0 0 15px 0; font-size: 13px; color: #6c7a8a; }
.search-form { display: flex; gap: 10px; }
.search-form input { flex: 1; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }

table.stu-results { width: 100%; border-collapse: collapse; margin-top: 15px; }
table.stu-results th, table.stu-results td { padding: 10px 12px; border-bottom: 1px solid #e4edf6; font-size: 13px; text-align: left; }
table.stu-results th { background: #003366; color: #fff; }
.photo-thumb { width: 34px; height: 34px; border-radius: 6px; object-fit: cover; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-id-card"></i> Student ID Card</div>
    </div>

    <div class="option-grid">
        <div class="option-card">
            <div class="opt-icon"><i class="fas fa-user"></i></div>
            <h3>Single ID Card</h3>
            <p>একজন student খুঁজে বের করে তার card generate করুন</p>
            <form method="GET" class="search-form">
                <input type="text" name="search" placeholder="Name, Admission No, BS ID বা PEN ID দিয়ে খুঁজুন..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
            </form>
        </div>
        <div class="option-card">
            <div class="opt-icon"><i class="fas fa-layer-group"></i></div>
            <h3>Bulk ID Card</h3>
            <p>Class / Section অনুযায়ী একসাথে সবার card generate ও print করুন</p>
            <a href="idcard_bulk.php" class="btn btn-success"><i class="fas fa-arrow-right"></i> Bulk এ যান</a>
        </div>
    </div>

    <?php if($search !== ''): ?>
    <div style="overflow-x:auto;">
    <table class="stu-results">
        <tr><th></th><th>Name</th><th>Class</th><th>Roll</th><th>Admission No</th><th>Action</th></tr>
        <?php if(empty($results)): ?>
            <tr><td colspan="6" style="text-align:center; color:#a4161a; padding:20px;">কোনো student পাওয়া যায়নি।</td></tr>
        <?php endif; ?>
        <?php foreach($results as $row): ?>
        <tr>
            <td>
                <?php if(!empty($row['photo'])): ?>
                    <img src="../uploads/students/<?php echo htmlspecialchars($row['photo']); ?>" class="photo-thumb">
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
            <td><?php echo htmlspecialchars(($row['class_name'] ?? '-').' '.($row['section_name'] ?? '')); ?></td>
            <td><?php echo htmlspecialchars($row['roll_no'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($row['admission_no'] ?? '-'); ?></td>
            <td><a href="idcard_generate.php?id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm"><i class="fas fa-id-card"></i> Generate</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

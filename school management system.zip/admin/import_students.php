<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/student_import.php';

set_time_limit(0);
$result = null;
$page_error = '';
$update_existing = ($_POST['existing'] ?? '') === 'update';
if (isset($_POST['import_students'])) {
    verify_csrf_or_die();
    $file = $_FILES['import_file'] ?? null;
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])
        || strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION)) !== 'xlsx') {
        $page_error = 'Choose the filled-in template (.xlsx).';
    } else {
        try {
            $result = student_import_run($file['tmp_name'], $update_existing);
            log_action((int)($_SESSION['admin_id'] ?? 0), 'STUDENTS_IMPORTED', 'students', null, null,
                ['file' => $file['name'], 'update_existing' => $update_existing] + array_diff_key($result, ['rows' => 1]));
        } catch (Throwable $e) {
            $page_error = $e->getMessage();
        }
    }
}
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$badge = ['created' => 'success', 'updated' => 'info', 'skipped' => 'warning', 'failed' => 'danger'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Import Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    .choice { display: flex; gap: 18px; flex-wrap: wrap; margin: 12px 0 4px; }
    .choice label { display: flex; gap: 8px; align-items: flex-start; font-weight: 600; cursor: pointer; }
    .choice small { display: block; font-weight: 400; color: var(--gray); }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-file-import"></i> Import Students</div>
        <div class="row-actions">
            <a href="download_student_template.php" class="btn btn-secondary"><i class="fas fa-file-download"></i> Template</a>
            <a href="students.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>

    <?php if ($page_error !== ''): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($page_error); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="form-card">
        <?php echo csrf_field(); ?>
        <div class="form-group"><label>Filled-in template (.xlsx)</label><input type="file" name="import_file" accept=".xlsx" required></div>
        <div class="choice">
            <span style="font-weight:700">A Banglar Shiksha ID already in school:</span>
            <label><input type="radio" name="existing" value="skip" <?php echo $update_existing ? '' : 'checked'; ?>><span>Skip the row<small>only new students are added</small></span></label>
            <label><input type="radio" name="existing" value="update" <?php echo $update_existing ? 'checked' : ''; ?>><span>Update that student<small>class, section and roll for the sheet's session, and the filled-in cells; blank cells keep what is stored</small></span></label>
        </div>
        <p class="form-note">Every row is checked the same way as Add Student and saved on its own — a row with a problem is listed below and nothing of it is saved. Brothers and sisters share one guardian record when three of father's name, mother's name, father's mobile, voter ID and Aadhaar match. Students who are TC, passed out, deactivated or deleted are never changed by an import.</p>
        <div class="btn-group"><button type="submit" name="import_students" class="btn btn-success"><i class="fas fa-upload"></i> Import</button></div>
    </form>

    <?php if ($result): ?>
    <div class="stats-row">
        <div class="stat-card"><div class="number green"><?php echo $result['created']; ?></div><div class="label">Added</div></div>
        <div class="stat-card"><div class="number blue"><?php echo $result['updated']; ?></div><div class="label">Updated</div></div>
        <div class="stat-card"><div class="number orange"><?php echo $result['skipped']; ?></div><div class="label">Skipped</div></div>
        <div class="stat-card"><div class="number red"><?php echo $result['failed']; ?></div><div class="label">Not imported</div></div>
    </div>
    <?php if ($result['rows']): ?>
    <table class="table">
        <thead><tr><th>Row</th><th>Student</th><th>Result</th><th>Details</th></tr></thead>
        <tbody>
        <?php foreach ($result['rows'] as [$line, $what, $who, $note]): ?>
            <tr><td><?php echo (int)$line; ?></td><td><?php echo $h($who); ?></td><td><span class="badge badge-<?php echo $badge[$what]; ?>"><?php echo $h($what === 'failed' ? 'not imported' : $what); ?></span></td><td><?php echo $h($note); ?></td></tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><i class="fas fa-file-excel"></i><h3>The sheet has no rows under the header.</h3></div>
    <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>

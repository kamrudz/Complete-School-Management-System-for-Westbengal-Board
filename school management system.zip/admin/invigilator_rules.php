<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

// ===== ADD RULE =====
if(isset($_POST['add_rule'])) {
    verify_csrf_or_die();
    $min = (int)$_POST['min_students'];
    $max = (int)$_POST['max_students'];
    $cnt = (int)$_POST['invigilator_count'];

    if ($min <= 0 || $max < $min || $cnt <= 0) {
        $_SESSION['error'] = "সঠিক Min/Max Students এবং Invigilator Count দিন।";
    } else {
        // Warn (but still allow) if this range overlaps an existing rule
        $stmt = mysqli_prepare($conn, "SELECT id FROM invigilator_rules WHERE NOT (max_students < ? OR min_students > ?) LIMIT 1");
        mysqli_stmt_bind_param($stmt, 'ii', $min, $max);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $overlap = mysqli_stmt_num_rows($stmt) > 0;
        mysqli_stmt_close($stmt);

        if ($overlap) {
            $_SESSION['error'] = "এই range ($min-$max) আগের কোনো rule-এর সাথে overlap করছে। আগের rule-টা এডিট/ডিলিট করে নিন।";
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO invigilator_rules (min_students, max_students, invigilator_count) VALUES (?,?,?)");
            mysqli_stmt_bind_param($stmt, 'iii', $min, $max, $cnt);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            $_SESSION['success'] = "Rule যোগ হয়েছে।";
        }
    }
    header("Location: invigilator_rules.php");
    exit();
}

// ===== DELETE RULE =====
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $stmt = mysqli_prepare($conn, "DELETE FROM invigilator_rules WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    $_SESSION['success'] = "Rule মুছে ফেলা হয়েছে।";
    header("Location: invigilator_rules.php");
    exit();
}

$rules = mysqli_query($conn, "SELECT * FROM invigilator_rules ORDER BY min_students ASC");
$total_rules = mysqli_num_rows($rules);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invigilator Rules</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f0f4f9; padding: 15px 20px; }
    .page-box { background: #fff; padding: 25px; border-radius: 14px; box-shadow: 0 2px 15px rgba(0,0,0,0.08); max-width: 800px; margin: 0 auto; }
    .page-title { font-size: 26px; font-weight: 700; color: #003366; display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
    .page-title small { font-size: 14px; font-weight: 400; color: #6c7a8a; }
    .desc { font-size: 13px; color: #6c7a8a; margin-bottom: 20px; }

    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background: #f8d7da; color: #842029; border: 1px solid #f1aeb5; }

    .form-card { background: #f8f9fa; padding: 20px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr 1fr auto; gap: 12px; align-items: end; }
    .form-group label { font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 4px; display: block; }
    .form-group input { padding: 8px 12px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 13px; width: 100%; }

    table { width: 100%; border-collapse: collapse; font-size: 13px; }
    table th { background: #003366; color: #fff; padding: 9px 12px; text-align: left; }
    table td { padding: 8px 12px; border-bottom: 1px solid #e4edf6; }

    .btn { display: inline-flex; align-items: center; gap: 8px; padding: 8px 18px; border: none; border-radius: 8px; font-weight: 600; font-size: 13px; cursor: pointer; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    .btn-success { background: #28a745; color: #fff; }
    .btn-danger { background: #dc3545; color: #fff; }
    .btn-sm { padding: 4px 10px; font-size: 12px; }
    .empty-state { text-align: center; padding: 30px; background: #f8f9fa; border-radius: 12px; border: 2px dashed #d0dbe8; color: #6c7a8a; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-title">
        <i class="fas fa-sliders-h"></i> Invigilator Rules
        <small>কত ছাত্রে কতজন Invigilator</small>
    </div>
    <p class="desc">একটা রুমে কত ছাত্র থাকলে ক'জন invigilator লাগবে, সেই range-ভিত্তিক নিয়ম এখানে বানান। Duty auto-generate করার সময় প্রতিটা রুমের ছাত্রসংখ্যা এই rule-এর সাথে মিলিয়ে invigilator সংখ্যা ঠিক হবে।</p>

    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="form-card">
        <form method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-row">
            <div class="form-group">
                <label>Minimum Students</label>
                <input type="number" name="min_students" min="1" placeholder="1" required>
            </div>
            <div class="form-group">
                <label>Maximum Students</label>
                <input type="number" name="max_students" min="1" placeholder="15" required>
            </div>
            <div class="form-group">
                <label>Invigilator Count</label>
                <input type="number" name="invigilator_count" min="1" placeholder="1" required>
            </div>
            <button type="submit" name="add_rule" class="btn btn-success"><i class="fas fa-plus"></i> Add</button>
        </div>
        </form>
    </div>

    <?php if($total_rules > 0): ?>
    <table>
        <thead><tr><th>Min Students</th><th>Max Students</th><th>Invigilator Count</th><th>Action</th></tr></thead>
        <tbody>
        <?php while($r = mysqli_fetch_assoc($rules)): ?>
        <tr>
            <td><?php echo (int)$r['min_students']; ?></td>
            <td><?php echo (int)$r['max_students']; ?></td>
            <td><strong><?php echo (int)$r['invigilator_count']; ?></strong></td>
            <td>
                <form method="post" style="display:inline;" onsubmit="return confirm('Delete this rule?')">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="delete_id" value="<?php echo (int)$r['id']; ?>">
                    <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state">
        <i class="fas fa-sliders-h" style="font-size:36px;opacity:.3;"></i>
        <p style="margin-top:10px;">এখনো কোনো rule যোগ করা হয়নি। উপরের ফর্ম দিয়ে যোগ করুন।</p>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

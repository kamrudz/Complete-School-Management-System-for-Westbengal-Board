<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, school_address, established_year, logo FROM school_settings WHERE id=1 LIMIT 1"));
$school_name = trim((string)($school['school_name'] ?? 'School Name'));
$school_address = trim((string)($school['school_address'] ?? ''));
$school_logo = !empty($school['logo']) ? '../uploads/' . $school['logo'] : '';

$book_ids = $_GET['book_id'] ?? null;
$selected_book_ids = [];
if (is_array($book_ids)) {
    foreach ($book_ids as $v) {
        $id = (int)$v;
        if ($id > 0) { $selected_book_ids[] = $id; }
    }
    $selected_book_ids = array_values(array_unique($selected_book_ids));
} elseif (isset($_GET['book_id'])) {
    $selected_book_ids[] = (int)$_GET['book_id'];
}

if (!empty($selected_book_ids)) {
    $placeholders = implode(',', array_fill(0, count($selected_book_ids), '?'));
    $query = "
        SELECT c.id, c.accession_no, c.status, c.added_date,
               b.id AS book_id, b.title AS book_title, b.author AS book_author,
               b.edition AS book_edition, b.shelf_location AS book_shelf,
               cat.category_name AS book_category
        FROM library_book_copies c
        JOIN library_books b ON b.id = c.book_id
        LEFT JOIN library_categories cat ON cat.id = b.category_id
        WHERE b.status='Active' AND b.id IN ($placeholders)
        ORDER BY b.title ASC, c.accession_no ASC
    ";
    $stmt = mysqli_prepare($conn, $query);
    $types = str_repeat('i', count($selected_book_ids));
    $params = $selected_book_ids;
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $copy_rows = [];
    while ($copy = mysqli_fetch_assoc($result)) {
        $copy_rows[] = $copy;
    }
} else {
    $book_id = (int)($_GET['book_id'] ?? 0);

    if ($book_id > 0) {
        $book = mysqli_fetch_assoc(mysqli_query($conn, "SELECT b.*, c.category_name FROM library_books b LEFT JOIN library_categories c ON c.id = b.category_id WHERE b.id=$book_id LIMIT 1"));
        if (!$book) {
            echo "Book not found.";
            exit();
        }

        $copy_rows = [];
        $copies = mysqli_query($conn, "SELECT * FROM library_book_copies WHERE book_id=$book_id ORDER BY accession_no ASC");
        while ($copy = mysqli_fetch_assoc($copies)) {
            $copy_rows[] = array_merge($copy, [
               'book_title' => $book['title'],
               'book_author' => $book['author'],
               'book_edition' => $book['edition'],
               'book_category' => $book['category_name'],
               'book_shelf' => $book['shelf_location'],
               'book_id' => $book['id'],
            ]);
        }
    } else {
        $copy_rows = [];
        $q = mysqli_query($conn, "
            SELECT c.id, c.accession_no, c.status, c.added_date,
                   b.id AS book_id, b.title AS book_title, b.author AS book_author,
                   b.edition AS book_edition, b.shelf_location AS book_shelf,
                   cat.category_name AS book_category
            FROM library_book_copies c
            JOIN library_books b ON b.id = c.book_id
            LEFT JOIN library_categories cat ON cat.id = b.category_id
            WHERE b.status='Active'
            ORDER BY b.title ASC, c.accession_no ASC
        ");
        while ($copy = mysqli_fetch_assoc($q)) {
            $copy_rows[] = $copy;
        }
    }
}

$pages = array_chunk($copy_rows, 8);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Label Print</title>
    <style>
        @page { size: A4 portrait; margin: 8mm; }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #eef2f6;
            color: #1a1a1a;
        }
        .toolbar {
            position: sticky;
            top: 0;
            background: #fff;
            padding: 12px 18px;
            border-bottom: 1px solid #dfe6ef;
            margin-bottom: 16px;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .toolbar button {
            background: #003366;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 9px 15px;
            font-size: 13px;
            cursor: pointer;
        }
        .sheet-page {
            width: 100%;
            max-width: 194mm;
            height: 280mm;
            page-break-after: always;
            margin: 0 auto 12px auto;
        }
        .sheet-page:last-child { page-break-after: auto; margin-bottom: 0; }
        .sheet {
            width: 100%;
            height: 100%;
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            grid-template-rows: repeat(4, minmax(0, 1fr));
            gap: 2mm;
            align-items: stretch;
        }
        .label-card {
            background: #fff;
            border: 1px solid #c6d3e4;
            border-radius: 4px;
            padding: 3mm 3mm 2.5mm 3mm;
            page-break-inside: avoid;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
            min-height: 0;
        }
        .label-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 4px;
            margin-bottom: 2mm;
            flex-shrink: 0;
            padding: 1.5mm 0;
            border-bottom: 1px solid #ecf1f8;
            background: #f7faff;
            border-radius: 3px;
            padding-left: 2mm;
            padding-right: 2mm;
        }
        .school-mini {
            display: flex;
            align-items: center;
            gap: 5px;
            min-width: 0;
            flex: 1;
        }
        .school-mini-logo {
            width: 12mm;
            height: 12mm;
            object-fit: contain;
            border-radius: 5px;
            background: #fff;
            border: 1px solid #dfe6ef;
            padding: 1px;
            flex-shrink: 0;
        }
        .school-mini-logo.empty {
            display: block;
            background: #eef3fb;
            border: 1px dashed #bfd0ea;
        }
        .school-mini-text {
            min-width: 0;
            flex: 1;
        }
        .school-mini-name {
            font-size: 9px;
            font-weight: 900;
            color: #003366;
            text-transform: uppercase;
            line-height: 1.2;
            letter-spacing: 0.2px;
            word-break: break-word;
        }
        .school-mini-address {
            font-size: 6.2px;
            color: #4d5b6c;
            line-height: 1.25;
            margin-top: 1px;
            word-break: break-word;
        }
        .label-book-id {
            font-size: 6.5px;
            color: #6c7a8a;
            font-weight: 700;
            letter-spacing: .05em;
            text-transform: uppercase;
            flex-shrink: 0;
        }
        .label-book-id span {
            display: inline-block;
            background: #edf4ff;
            color: #003366;
            padding: 1.5px 3px;
            border-radius: 3px;
        }
        .label-row {
            display: flex;
            align-items: flex-start;
            gap: 2.5mm;
            flex: 1;
            min-height: 0;
        }
        .label-main {
            flex: 1;
            min-width: 0;
        }
        .title {
            font-weight: 800;
            font-size: 14px;
            line-height: 1.2;
            color: #003366;
            margin: 0 0 3px 0;
            word-break: break-word;
            font-family: Georgia, 'Times New Roman', serif;
        }
        .meta {
            font-size: 8px;
            line-height: 1.35;
            color: #4d5b6c;
            font-family: Arial, sans-serif;
        }
        .meta strong {
            color: #1a3b55;
        }
        .self-location {
            margin-top: 3px;
            font-size: 8px;
            color: #1a3b55;
            font-weight: 700;
            font-family: Arial, sans-serif;
        }
        .label-qr {
            width: 34mm;
            flex: 0 0 34mm;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }
        .qr-wrap {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        .qr-wrap img {
            width: 30mm;
            height: 30mm;
            display: block;
            border: 1px solid #dfe6ef;
            background: #fff;
            padding: 1px;
        }
        .acc {
            margin-top: 3px;
            font-size: 10px;
            font-weight: 800;
            color: #003366;
            letter-spacing: .04em;
            flex-shrink: 0;
            font-family: Arial, sans-serif;
        }
        @media print {
            body { background: #fff; }
            .toolbar { display: none; }
            .sheet-page { margin-bottom: 0; }
            .sheet { gap: 2mm; }
            .label-card { border: 1px solid #7d8ea3; }
        }
    </style>
</head>
<body>
    <div class="toolbar">
        <button onclick="window.print()"><i class="fas fa-print"></i> Print</button>
    </div>

    <?php foreach ($pages as $page): ?>
    <div class="sheet-page">
        <div class="sheet">
            <?php foreach ($page as $copy): ?>
            <div class="label-card">
               <div class="label-header">
                   <div class="school-mini">
                       <?php if (!empty($school_logo)): ?>
                           <img class="school-mini-logo" src="<?php echo htmlspecialchars($school_logo); ?>" alt="School Logo">
                       <?php else: ?>
                           <div class="school-mini-logo empty" aria-label="No school logo"></div>
                       <?php endif; ?>
                       <div class="school-mini-text">
                           <div class="school-mini-name"><?php echo htmlspecialchars($school_name ?: 'School Name'); ?></div>
                           <?php if (!empty($school_address)): ?><div class="school-mini-address"><?php echo htmlspecialchars($school_address); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></div><?php endif; ?>
                       </div>
                   </div>
                   <div class="label-book-id"><span>Rack: <?php echo htmlspecialchars(($copy['book_shelf'] ?? $book['shelf_location'] ?? 'N/A')); ?></span></div>
               </div>
               <div class="label-row">
                   <div class="label-main">
                       <div class="title"><?php echo htmlspecialchars(mb_strimwidth(($copy['book_title'] ?? $book['title'] ?? 'Untitled'), 0, 32, '...')); ?></div>
                       <div class="meta">
                           <div><strong>Author:</strong> <?php echo htmlspecialchars(($copy['book_author'] ?? $book['author'] ?? '-') ?: '-'); ?></div>
                           <div><strong>Category:</strong> <?php echo htmlspecialchars(($copy['book_category'] ?? $book['category_name'] ?? '-') ?: '-'); ?></div>
                           <div><strong>Edition:</strong> <?php echo htmlspecialchars(($copy['book_edition'] ?? $book['edition'] ?? '-') ?: '-'); ?></div>
                       </div>
                       <div class="self-location"><strong>Self:</strong> <?php echo htmlspecialchars(($copy['book_shelf'] ?? $book['shelf_location'] ?? 'N/A')); ?></div>
                       <div class="acc"><?php echo htmlspecialchars($copy['accession_no']); ?></div>
                   </div>
                   <div class="label-qr">
                       <div class="qr-wrap">
                           <img src="library_book_qr.php?copy_id=<?php echo (int)$copy['id']; ?>" alt="QR Code">
                       </div>
                   </div>
               </div>
            </div>
            <?php endforeach; ?>
            <?php while (count($page) < 8): ?>
               <div class="label-card" style="visibility:hidden; border-style:dashed;"></div>
               <?php $page[] = null; endwhile; ?>
        </div>
    </div>
    <?php endforeach; ?>
</body>
</html>

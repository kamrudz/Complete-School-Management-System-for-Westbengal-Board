<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/phpqrcode/qrlib.php");

// This QR is for internal use only (scanned by the librarian) — so the accession_no
// is encoded directly; no public verification token needed, unlike the certificate/admit-card QR.
$copy_id = (int)($_GET['copy_id'] ?? 0);
$copy = mysqli_fetch_assoc(mysqli_query($conn, "SELECT accession_no FROM library_book_copies WHERE id=$copy_id"));
if (!$copy) { http_response_code(404); exit(); }

header('Content-Type: image/png');
QRcode::png($copy['accession_no'], false, QR_ECLEVEL_M, 6, 2);
exit();

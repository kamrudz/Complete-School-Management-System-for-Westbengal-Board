<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

$copy_id = (int)($_GET['copy_id'] ?? 0);
$copy = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT c.accession_no, b.title
    FROM library_book_copies c JOIN library_books b ON b.id = c.book_id
    WHERE c.id=$copy_id
"));
if (!$copy) { echo "Copy not found."; exit(); }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>QR Sticker</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
body { font-family: Arial, sans-serif; background: #eef2f6; padding: 20px; }
.toolbar { max-width: 400px; margin: 0 auto 15px auto; text-align: right; }
.toolbar button { padding: 10px 18px; border-radius: 8px; border: none; background: #003366; color: #fff; cursor: pointer; }
.sticker { width: 45mm; margin: 0 auto; background: #fff; border: 1px dashed #999; border-radius: 2mm; padding: 3mm; text-align: center; }
.sticker img { width: 32mm; height: 32mm; }
.sticker .acc { font-weight: 800; font-size: 3.2mm; color: #003366; margin-top: 1mm; }
.sticker .title { font-size: 2.4mm; color: #444; margin-top: 0.5mm; line-height: 1.2; }
@media print { .toolbar { display: none; } body { background: #fff; } .sticker { border: none; } }
</style>
</head>
<body>
<div class="toolbar"><button onclick="window.print()"><i class="fas fa-print"></i> Print</button></div>
<div class="sticker">
    <img src="library_book_qr.php?copy_id=<?php echo $copy_id; ?>" alt="QR">
    <div class="acc"><?php echo htmlspecialchars($copy['accession_no']); ?></div>
    <div class="title"><?php echo htmlspecialchars(mb_strimwidth($copy['title'], 0, 40, '...')); ?></div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['add_category'])) {
        $name = trim($_POST['category_name'] ?? '');
        if ($name !== '') {
            $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO library_categories (category_name) VALUES (?)");
            mysqli_stmt_bind_param($stmt, "s", $name);
            mysqli_stmt_execute($stmt);
            $_SESSION['success'] = "Category added!";
        }
    } elseif (isset($_POST['delete_category'])) {
        $id = (int)$_POST['category_id'];
        // Prevent deleting a category that's in use (category_id on book_id would become NULL, so check first)
        $chk = db_get_row("SELECT COUNT(*) c FROM library_books WHERE category_id=?", 'i', $id);
        if ((int)$chk['c'] > 0) {
            $_SESSION['error'] = "This category has books in it — move them to another category first.";
        } else {
            db_execute("DELETE FROM library_categories WHERE id=?", 'i', $id);
            $_SESSION['success'] = "Category deleted!";
        }
    }
    header("Location: library_categories.php");
    exit();
}

$cats = mysqli_query($conn, "
    SELECT c.*, (SELECT COUNT(*) FROM library_books b WHERE b.category_id=c.id) AS book_count
    FROM library_categories c ORDER BY c.category_name ASC
");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Categories</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 20px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 480px; margin-bottom: 20px; }
.form-card form { display: flex; gap: 10px; }
.form-card input { flex: 1; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; }
table { width: 100%; border-collapse: collapse; max-width: 640px; }
table th, table td { padding: 10px 14px; border-bottom: 1px solid #e4edf6; text-align: left; font-size: 13px; }
table th { background: #003366; color: #fff; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-success { background: #d4edda; color: #155724; }
.alert-error { background: #f8d7da; color: #842029; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-tags"></i> Library Categories</div>
        <a href="library_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>

    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="category_name" placeholder="New category name (e.g. Science Fiction)" required>
            <button type="submit" name="add_category" class="btn btn-success"><i class="fas fa-plus"></i> Add</button>
        </form>
    </div>

    <table>
        <tr><th>Category</th><th>Book Count</th><th>Action</th></tr>
        <?php while ($c = mysqli_fetch_assoc($cats)): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['category_name']); ?></td>
            <td><?php echo (int)$c['book_count']; ?></td>
            <td>
                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="category_id" value="<?php echo $c['id']; ?>">
                    <button type="submit" name="delete_category" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>

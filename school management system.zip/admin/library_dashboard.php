<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/library_helper.php");

$settings = get_library_settings($conn);

// ===== Stock summary =====
$stock = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT
        (SELECT COUNT(*) FROM library_books WHERE status='Active') AS total_titles,
        (SELECT COUNT(*) FROM library_book_copies) AS total_copies,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Available') AS available_copies,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Issued') AS issued_copies,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Lost') AS lost_copies,
        (SELECT COUNT(*) FROM library_book_copies WHERE status='Damaged') AS damaged_copies
"));
$overdue_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM library_issues WHERE status='Issued' AND due_date < CURDATE()"))['c'];
$total_pending_fine = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(GREATEST(DATEDIFF(CURDATE(), due_date),0)),0) AS days FROM library_issues WHERE status='Issued' AND due_date < CURDATE()"));
$pending_fine_estimate = (float)$total_pending_fine['days'] * (float)$settings['fine_per_day'];

// ===== Book usage report (filter) =====
$usage_mode = $_GET['usage_mode'] ?? '';
$usage_months = (int)($_GET['usage_months'] ?? 6);
$unused_books = [];
if ($usage_mode === 'never') {
    $unused_books_q = mysqli_query($conn, "
        SELECT b.id, b.title, b.author
        FROM library_books b
        WHERE b.status='Active' AND NOT EXISTS (
            SELECT 1 FROM library_issues li JOIN library_book_copies c ON c.id=li.copy_id WHERE c.book_id=b.id
        )
        ORDER BY b.title ASC
    ");
    while ($r = mysqli_fetch_assoc($unused_books_q)) { $unused_books[] = $r; }
} elseif ($usage_mode === 'stale') {
    $unused_books_q = mysqli_query($conn, "
        SELECT b.id, b.title, b.author, MAX(li.issue_date) AS last_issue
        FROM library_books b
        LEFT JOIN library_book_copies c ON c.book_id = b.id
        LEFT JOIN library_issues li ON li.copy_id = c.id
        WHERE b.status='Active'
        GROUP BY b.id, b.title, b.author
        HAVING last_issue IS NULL OR last_issue < DATE_SUB(CURDATE(), INTERVAL $usage_months MONTH)
        ORDER BY last_issue ASC
    ");
    while ($r = mysqli_fetch_assoc($unused_books_q)) { $unused_books[] = $r; }
}

// ===== Overdue list (top 10 preview) =====
$overdue_q = mysqli_query($conn, "
    SELECT li.*, c.accession_no, b.title
    FROM library_issues li
    JOIN library_book_copies c ON c.id = li.copy_id
    JOIN library_books b ON b.id = c.book_id
    WHERE li.status='Issued' AND li.due_date < CURDATE()
    ORDER BY li.due_date ASC LIMIT 10
");

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.quick-links { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 24px; }
.quick-links a { flex: 1; min-width: 140px; background: #fff; border: 1px solid #e4edf6; border-radius: 12px; padding: 16px; text-align: center; text-decoration: none; color: #1a3b55; font-weight: 600; font-size: 13px; }
.quick-links a i { display: block; font-size: 22px; color: #003366; margin-bottom: 8px; }
.quick-links a:hover { background: #f0f7ff; }

.stat-grid { display: flex; gap: 14px; flex-wrap: wrap; margin-bottom: 24px; }
.stat-card { flex: 1; min-width: 150px; background: #fff; border: 1px solid #e4edf6; border-radius: 12px; padding: 16px; text-align: center; }
.stat-card .num { font-size: 26px; font-weight: 800; color: #003366; }
.stat-card .lbl { font-size: 12px; color: #6c7a8a; margin-top: 4px; }
.stat-card.warn .num { color: #a4161a; }

.section-title { font-size: 16px; font-weight: 700; color: #003366; margin: 24px 0 12px 0; display: flex; align-items: center; gap: 8px; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
table th, table td { padding: 9px 12px; border-bottom: 1px solid #e4edf6; text-align: left; }
table th { background: #003366; color: #fff; }
.filter-tabs { display: flex; gap: 8px; margin-bottom: 14px; flex-wrap: wrap; align-items: center; }
.filter-tabs a { padding: 8px 16px; border-radius: 8px; border: 2px solid #e4edf6; text-decoration: none; color: #1a3b55; font-size: 12px; font-weight: 600; }
.filter-tabs a.active { background: #003366; color: #fff; border-color: #003366; }
.filter-tabs select { padding: 7px 10px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 12px; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-book-reader"></i> Library Dashboard</div>
        <a href="library_settings.php" class="btn btn-primary"><i class="fas fa-cog"></i> Settings</a>
    </div>

    <div class="quick-links">
        <a href="library_issue.php"><i class="fas fa-hand-holding"></i> Issue Book</a>
        <a href="library_return.php"><i class="fas fa-undo-alt"></i> Return / Renew</a>
        <a href="add_book.php"><i class="fas fa-book-medical"></i> Add Book</a>
        <a href="books.php"><i class="fas fa-book"></i> Book List</a>
        <a href="library_book_print_batch.php" target="_blank" rel="noopener"><i class="fas fa-print"></i> A4 Accession Print (8/page)</a>
        <a href="library_categories.php"><i class="fas fa-tags"></i> Categories</a>
    </div>

    <!-- ===== STOCK REPORT ===== -->
    <div class="section-title"><i class="fas fa-boxes"></i> Stock Report</div>
    <div class="stat-grid">
        <div class="stat-card"><div class="num"><?php echo (int)$stock['total_titles']; ?></div><div class="lbl">Total Book Titles</div></div>
        <div class="stat-card"><div class="num"><?php echo (int)$stock['total_copies']; ?></div><div class="lbl">Total Copies</div></div>
        <div class="stat-card"><div class="num" style="color:#155724;"><?php echo (int)$stock['available_copies']; ?></div><div class="lbl">Available</div></div>
        <div class="stat-card"><div class="num" style="color:#856404;"><?php echo (int)$stock['issued_copies']; ?></div><div class="lbl">Currently Issued</div></div>
        <div class="stat-card warn"><div class="num"><?php echo (int)$overdue_count; ?></div><div class="lbl">Overdue</div></div>
        <div class="stat-card warn"><div class="num">₹<?php echo number_format($pending_fine_estimate, 0); ?></div><div class="lbl">Pending Fine (est.)</div></div>
    </div>

    <!-- ===== OVERDUE REPORT ===== -->
    <div class="section-title"><i class="fas fa-exclamation-triangle"></i> Overdue Report <small style="font-weight:400;font-size:12px;color:#6c7a8a;">(most recent 10 — use the "Overdue" filter on the Return page to see all)</small></div>
    <div style="overflow-x:auto;">
    <table>
        <tr><th>Book</th><th>Accession No</th><th>Borrower</th><th>Due Date</th><th>Days Late</th><th>Fine</th></tr>
        <?php $any_od = false; while ($r = mysqli_fetch_assoc($overdue_q)): $any_od = true;
            $borrower = get_borrower_info($conn, $r['borrower_type'], $r['borrower_id']);
            $days_late = (int)floor((strtotime(date('Y-m-d')) - strtotime($r['due_date'])) / 86400);
            $fine = calc_current_fine($r['due_date'], $settings['fine_per_day']);
        ?>
        <tr>
            <td><?php echo htmlspecialchars($r['title']); ?></td>
            <td><?php echo htmlspecialchars($r['accession_no']); ?></td>
            <td><?php echo htmlspecialchars($borrower['name'] ?? '-'); ?> <small style="color:#6c7a8a;">(<?php echo $r['borrower_type']; ?>)</small></td>
            <td><?php echo date('d M Y', strtotime($r['due_date'])); ?></td>
            <td style="color:#a4161a;font-weight:700;"><?php echo $days_late; ?></td>
            <td>₹<?php echo number_format($fine, 2); ?></td>
        </tr>
        <?php endwhile; ?>
        <?php if (!$any_od): ?><tr><td colspan="6" style="text-align:center;color:#155724;padding:16px;"><i class="fas fa-check-circle"></i> No books are currently overdue.</td></tr><?php endif; ?>
    </table>
    </div>

    <!-- ===== BOOK USAGE REPORT ===== -->
    <div class="section-title"><i class="fas fa-chart-line"></i> Book Usage Report</div>
    <div class="filter-tabs">
        <a href="?usage_mode=never" class="<?php echo $usage_mode==='never'?'active':''; ?>">Never Issued</a>
        <a href="?usage_mode=stale&usage_months=<?php echo $usage_months; ?>" class="<?php echo $usage_mode==='stale'?'active':''; ?>">Not Issued in a While</a>
        <?php if ($usage_mode === 'stale'): ?>
        <form method="GET" style="display:inline-flex; gap:6px; align-items:center;">
            <input type="hidden" name="usage_mode" value="stale">
            <select name="usage_months" onchange="this.form.submit()">
                <?php foreach ([3,6,12] as $m): ?>
                <option value="<?php echo $m; ?>" <?php echo $usage_months==$m?'selected':''; ?>>Not in the last <?php echo $m; ?> months</option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php endif; ?>
    </div>

    <?php if ($usage_mode !== ''): ?>
    <div style="overflow-x:auto;">
    <table>
        <tr><th>Title</th><th>Author</th><?php if($usage_mode==='stale'): ?><th>Last Issued</th><?php endif; ?></tr>
        <?php if (empty($unused_books)): ?>
        <tr><td colspan="3" style="text-align:center;color:#155724;padding:16px;">No books found for this filter — all books are being used reasonably well!</td></tr>
        <?php endif; ?>
        <?php foreach ($unused_books as $b): ?>
        <tr>
            <td><?php echo htmlspecialchars($b['title']); ?></td>
            <td><?php echo htmlspecialchars($b['author'] ?? '-'); ?></td>
            <?php if($usage_mode==='stale'): ?><td><?php echo !empty($b['last_issue']) ? date('d M Y', strtotime($b['last_issue'])) : 'Never'; ?></td><?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>
    </div>
    <?php else: ?>
    <p style="color:#6c7a8a; font-size:13px;">Select a mode from the tabs above to see the report.</p>
    <?php endif; ?>
</div>
</body>
</html>

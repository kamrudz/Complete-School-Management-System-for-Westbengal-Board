<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

$settings = get_library_settings($conn);
$loan_days = (int)$settings['loan_period_days'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['issue_book'])) {
    verify_csrf_or_die();
    $borrower_type = in_array($_POST['borrower_type'] ?? '', ['Student','Staff'], true) ? $_POST['borrower_type'] : 'Student';
    $borrower_id = library_borrower_id($borrower_type, $_POST['borrower_id'] ?? '');
    $copy_id = (int)$_POST['copy_id']; // the EXACT physical copy the librarian picked, not just "a book"

    if (!valid_library_borrower($conn, $borrower_type, $borrower_id) || $copy_id <= 0) {
        $_SESSION['error'] = "Invalid borrower or book copy.";
        header("Location: library_issue.php");
        exit();
    }

    // ===== Check max books limit =====
    $limit = $borrower_type === 'Student' ? (int)$settings['max_books_per_student'] : (int)$settings['max_books_per_staff'];
    $active_count = count_active_issues($conn, $borrower_type, $borrower_id);
    if ($active_count >= $limit) {
        $_SESSION['error'] = "This " . ($borrower_type === 'Student' ? 'student' : 'staff member') . " already has $active_count book(s) (max limit $limit) — one must be returned first.";
        header("Location: library_issue.php");
        exit();
    }

    // Fast pre-check so a hopeless request fails early without opening a
    // transaction at all. The real, race-safe check happens below.
    $precheck = get_library_copy($conn, $copy_id);
    if (!$precheck || $precheck['status'] !== 'Available') {
        $_SESSION['error'] = "This copy is no longer available — it may have just been issued to someone else. Please pick another copy.";
        header("Location: library_issue.php");
        exit();
    }

    $issue_date = date('Y-m-d');
    $due_date = date('Y-m-d', strtotime("+{$loan_days} days"));
    $issued_by = $_SESSION['admin_id'] ?? null;

    mysqli_begin_transaction($conn);
    try {
        // Lock the EXACT copy the librarian selected — if someone else grabbed
        // this very copy a moment ago, this correctly fails instead of two
        // people ending up with the same physical book.
        $copy = get_library_copy($conn, $copy_id, true);

        if (!$copy || $copy['status'] !== 'Available') {
            mysqli_rollback($conn);
            $_SESSION['error'] = "This copy is no longer available — it may have just been issued to someone else. Please pick another copy.";
            header("Location: library_issue.php");
            exit();
        }

        $stmt = mysqli_prepare($conn, "INSERT INTO library_issues (copy_id, borrower_type, borrower_id, issue_date, due_date, issued_by) VALUES (?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "issssi", $copy['id'], $borrower_type, $borrower_id, $issue_date, $due_date, $issued_by);
        mysqli_stmt_execute($stmt);

        if (!set_library_copy_status($conn, $copy['id'], 'Issued')) {
            throw new RuntimeException('Unable to update copy status.');
        }

        mysqli_commit($conn);
        $_SESSION['success'] = "Book issued! Accession No: {$copy['accession_no']} — Due date: " . date('d M Y', strtotime($due_date));
        $_SESSION['_just_issued'] = true; // tells the page to refocus the search box for the next issue
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Something went wrong, please try again.";
    }
    header("Location: library_issue.php");
    exit();
}

$just_issued = !empty($_SESSION['_just_issued']);
unset($_SESSION['_just_issued']);

// ===== Class → Section map for "Browse by Class/Roll" (Student only) =====
// Preloaded once here (not via AJAX) since a school's class/section list is
// small and effectively static per session — this avoids an extra network
// round-trip every time the librarian opens the class dropdown.
$cur_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$cur_session_id = (int)($cur_session['id'] ?? 0);
$class_section_map = [];
$classes_res = mysqli_query($conn, "SELECT id, class_name FROM classes ORDER BY sort_order ASC, class_name ASC");
while ($cls = mysqli_fetch_assoc($classes_res)) {
    $secs = [];
    $sec_stmt = mysqli_prepare($conn, "SELECT id, section_name FROM sections WHERE class_id=? AND session_id=? ORDER BY section_name ASC");
    mysqli_stmt_bind_param($sec_stmt, "ii", $cls['id'], $cur_session_id);
    mysqli_stmt_execute($sec_stmt);
    $sec_res = mysqli_stmt_get_result($sec_stmt);
    while ($s = mysqli_fetch_assoc($sec_res)) { $secs[] = ['id' => (int)$s['id'], 'name' => $s['section_name']]; }
    if (!empty($secs)) {
        $class_section_map[] = ['id' => (int)$cls['id'], 'name' => $cls['class_name'], 'sections' => $secs];
    }
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Issue Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.issue-card { background: #fff; padding: 28px; border-radius: 14px; border: 1px solid #e4edf6; max-width: 680px; box-shadow: 0 4px 18px rgba(15,40,70,0.05); }
.step-label { font-weight: 700; color: #003366; font-size: 14.5px; margin: 22px 0 10px 0; display:flex; align-items:center; gap:10px; }
.step-label:first-child { margin-top: 0; }
.step-label .num { background: linear-gradient(135deg,#003366,#1f5b8a); color:#fff; width:24px; height:24px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:12px; flex-shrink:0; }
.step-hint { font-weight: 400; font-size: 11.5px; color: #8a97a6; margin-left: auto; }
.search-box { position: relative; }
.search-box input { width: 100%; padding: 12px 14px 12px 38px; border: 2px solid #e4edf6; border-radius: 10px; font-size: 14px; transition: border-color .15s; background: #fbfdff url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="%236c7a8a" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg>') no-repeat 12px center; background-size: 15px; }
.search-box input:focus { outline: none; border-color: #1f5b8a; box-shadow: 0 0 0 3px rgba(31,91,138,0.1); }
.search-results { position: absolute; top: calc(100% + 6px); left: 0; right: 0; background: #fff; border: 1px solid #e4edf6; border-radius: 10px; box-shadow: 0 10px 28px rgba(15,40,70,0.14); max-height: 300px; overflow-y: auto; z-index: 20; display: none; }
.result-item { display: flex; align-items: center; gap: 11px; padding: 11px 14px; cursor: pointer; border-bottom: 1px solid #f0f3f7; transition: background .1s; }
.result-item:last-child { border-bottom: none; }
.result-item:hover { background: #f0f7ff; }
.result-item.empty { color: #8a97a6; cursor: default; justify-content: center; font-size: 13px; padding: 18px; }
.result-item.empty:hover { background: transparent; }
.result-item img { width: 34px; height: 34px; border-radius: 8px; object-fit: cover; background:#e9edf2; flex-shrink: 0; }
.result-item .rname { font-weight: 600; font-size: 13px; color: #1a3b55; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.result-item .rsub { font-size: 11.5px; color: #6c7a8a; margin-top: 1px; }
.acc-badge { display: inline-block; font-family: 'Courier New', monospace; font-size: 10.5px; font-weight: 700; background: #eaf2fb; color: #1f5b8a; border: 1px solid #cfe0f2; border-radius: 5px; padding: 2px 6px; letter-spacing: .3px; }
.acc-badge.exact { background: #d4edda; color: #155724; border-color: #b7dfc0; }
.exact-tag { font-size: 10px; font-weight: 700; color: #2f8f4e; }

.selected-box { background: #eaf2fb; border: 2px solid #b8d4f0; border-radius: 12px; padding: 13px 16px; display: none; align-items:center; gap:12px; margin-top:8px; }
.selected-box img { width: 42px; height: 42px; border-radius: 10px; object-fit: cover; background:#dbe6f0; flex-shrink: 0; }
.selected-box .rname { font-weight: 700; font-size: 13.5px; color: #14324a; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.selected-box .rsub { font-size: 11.5px; color: #4a5b6b; margin-top:2px; }
.selected-box .clear-sel { margin-left:auto; color:#a4161a; cursor:pointer; font-size:12px; font-weight:600; white-space:nowrap; padding: 4px 8px; border-radius: 6px; transition: background .1s; }
.selected-box .clear-sel:hover { background: rgba(164,22,26,0.08); }

.type-toggle { display: flex; gap: 8px; margin-bottom: 12px; }
.type-toggle button { flex: 1; padding: 10px; border: 2px solid #e4edf6; background: #fff; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 13px; color: #4a5b6b; transition: all .15s; }
.type-toggle button.active { background: linear-gradient(135deg,#003366,#1f5b8a); color: #fff; border-color: #003366; }

.mode-toggle { display: flex; gap: 16px; margin-bottom: 10px; }
.mode-toggle a { font-size: 12.5px; font-weight: 600; color: #8a97a6; cursor: pointer; padding-bottom: 4px; border-bottom: 2px solid transparent; display:flex; align-items:center; gap: 5px; }
.mode-toggle a.active { color: #1f5b8a; border-bottom-color: #1f5b8a; }
.mode-toggle a:hover { color: #1f5b8a; }

.browse-selects { display: flex; gap: 10px; margin-bottom: 10px; }
.browse-selects select { flex: 1; padding: 11px 12px; border: 2px solid #e4edf6; border-radius: 10px; font-size: 13.5px; background: #fbfdff; color: #1a3b55; font-weight: 600; }
.browse-selects select:disabled { color: #b0bac4; background: #f5f7fa; cursor: not-allowed; }
.browse-selects select:focus { outline: none; border-color: #1f5b8a; }

.roll-list { display: none; max-height: 260px; overflow-y: auto; border: 1px solid #e4edf6; border-radius: 10px; }
.roll-item { display: flex; align-items: center; gap: 11px; padding: 10px 14px; cursor: pointer; border-bottom: 1px solid #f0f3f7; transition: background .1s; }
.roll-item:last-child { border-bottom: none; }
.roll-item:hover { background: #f0f7ff; }
.roll-item .roll-badge { flex-shrink:0; min-width: 34px; height: 28px; background: #003366; color:#fff; border-radius: 7px; display:flex; align-items:center; justify-content:center; font-size: 12px; font-weight: 700; font-family: 'Courier New', monospace; }
.roll-item img { width: 30px; height: 30px; border-radius: 7px; object-fit: cover; background:#e9edf2; flex-shrink: 0; }
.roll-item .rname { font-weight: 600; font-size: 13px; color: #1a3b55; }
.roll-item .rsub { font-size: 11.5px; color: #6c7a8a; margin-top: 1px; }
.roll-empty { padding: 18px; text-align:center; color: #8a97a6; font-size: 12.5px; }
.roll-loading { padding: 14px; text-align:center; color: #8a97a6; font-size: 12.5px; }

.review-box { display:none; margin-top: 22px; background: #f7fafd; border: 1.5px dashed #b8d4f0; border-radius: 12px; padding: 16px 18px; }
.review-box h5 { font-size: 12.5px; text-transform: uppercase; letter-spacing: .5px; color: #6c7a8a; margin-bottom: 10px; font-weight: 700; }
.review-row { display:flex; justify-content: space-between; align-items:center; padding: 6px 0; font-size: 13.5px; color: #1a3b55; }
.review-row + .review-row { border-top: 1px dashed #dce6f0; }
.review-row .rlabel { color: #6c7a8a; font-size: 12.5px; }
.review-row .rval { font-weight: 600; text-align: right; }
.due-highlight { color: #a9772c; font-weight: 700; }

.alert { padding: 13px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; display:flex; align-items:center; gap:8px; }
.alert-success { background: #d4edda; color: #155724; }
.alert-error { background: #f8d7da; color: #842029; }

.btn-issue { margin-top:22px; width: 100%; padding: 13px; font-size: 14.5px; }
.btn-issue:disabled { opacity: .45; cursor: not-allowed; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-hand-holding"></i> Issue Book</div>
        <a href="library_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>
    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <div class="issue-card">
        <form method="POST" id="issueForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="borrower_type" id="borrower_type" value="Student">
            <input type="hidden" name="borrower_id" id="borrower_id" value="">
            <input type="hidden" name="copy_id" id="copy_id" value="">

            <div class="step-label"><span class="num">1</span> Who is this for? <span class="step-hint" id="borrowerHint">Name, roll no, or class-section</span></div>
            <div class="type-toggle">
                <button type="button" class="active" id="btnStudent" onclick="switchType('Student')"><i class="fas fa-user-graduate"></i> Student</button>
                <button type="button" id="btnStaff" onclick="switchType('Staff')"><i class="fas fa-chalkboard-teacher"></i> Staff</button>
            </div>

            <div class="mode-toggle" id="borrowerModeToggle">
                <a class="active" id="modeSearchBtn" onclick="setBorrowerMode('search')"><i class="fas fa-search"></i> Search by name</a>
                <a id="modeBrowseBtn" onclick="setBorrowerMode('browse')"><i class="fas fa-list-ol"></i> Browse by Class / Roll</a>
            </div>

            <div id="searchModePane">
                <div class="search-box">
                    <input type="text" id="borrowerSearch" placeholder="Name, roll no, or class-section (e.g. 10 A)..." autocomplete="off">
                    <div class="search-results" id="borrowerResults"></div>
                </div>
            </div>

            <div id="browseModePane" style="display:none;">
                <div class="browse-selects">
                    <select id="browseClass" onchange="onBrowseClassChange()">
                        <option value="">Select Class</option>
                    </select>
                    <select id="browseSection" onchange="onBrowseSectionChange()" disabled>
                        <option value="">Select Section</option>
                    </select>
                </div>
                <div class="roll-list" id="rollList"></div>
            </div>

            <div class="selected-box" id="borrowerSelected">
                <img id="borrowerImg" src="">
                <div><div class="rname" id="borrowerName"></div><div class="rsub" id="borrowerSub"></div></div>
                <span class="clear-sel" onclick="clearBorrower()"><i class="fas fa-times"></i> Change</span>
            </div>

            <div class="step-label"><span class="num">2</span> Which copy? <span class="step-hint">Title, author, or accession no.</span></div>
            <div class="search-box">
                <input type="text" id="bookSearch" placeholder="Type a title, or scan/type an accession no. (e.g. LIB-2026-014)..." autocomplete="off">
                <div class="search-results" id="bookResults"></div>
            </div>
            <div class="selected-box" id="bookSelected">
                <div><div class="rname" id="bookName"></div><div class="rsub" id="bookSub"></div></div>
                <span class="clear-sel" onclick="clearBook()"><i class="fas fa-times"></i> Change</span>
            </div>

            <div class="review-box" id="reviewBox">
                <h5><i class="fas fa-clipboard-check"></i> Confirm before issuing</h5>
                <div class="review-row"><span class="rlabel">Borrower</span><span class="rval" id="reviewBorrower">—</span></div>
                <div class="review-row"><span class="rlabel">Copy</span><span class="rval" id="reviewBook">—</span></div>
                <div class="review-row"><span class="rlabel">Issue date</span><span class="rval" id="reviewIssueDate">—</span></div>
                <div class="review-row"><span class="rlabel">Due date</span><span class="rval due-highlight" id="reviewDueDate">—</span></div>
            </div>

            <button type="submit" name="issue_book" class="btn btn-success btn-issue" id="submitBtn" disabled><i class="fas fa-hand-holding"></i> Issue This Copy</button>
        </form>
    </div>
</div>
<script>
var currentType = 'Student';
var borrowerMode = 'search';
var LOAN_DAYS = <?php echo (int)$loan_days; ?>;
var CLASS_SECTIONS = <?php echo json_encode($class_section_map); ?>;

function populateClassDropdown() {
    var sel = document.getElementById('browseClass');
    sel.innerHTML = '<option value="">Select Class</option>';
    CLASS_SECTIONS.forEach(function(c){
        var opt = document.createElement('option');
        opt.value = c.id;
        opt.textContent = c.name;
        sel.appendChild(opt);
    });
}
populateClassDropdown();

function resetBrowsePane() {
    document.getElementById('browseClass').value = '';
    var secSel = document.getElementById('browseSection');
    secSel.innerHTML = '<option value="">Select Section</option>';
    secSel.disabled = true;
    var box = document.getElementById('rollList');
    box.innerHTML = '';
    box.style.display = 'none';
}

function setBorrowerMode(mode) {
    borrowerMode = mode;
    document.getElementById('modeSearchBtn').classList.toggle('active', mode === 'search');
    document.getElementById('modeBrowseBtn').classList.toggle('active', mode === 'browse');
    document.getElementById('searchModePane').style.display = mode === 'search' ? 'block' : 'none';
    document.getElementById('browseModePane').style.display = mode === 'browse' ? 'block' : 'none';
    resetBrowsePane();
    clearBorrower();
}

function onBrowseClassChange() {
    var classId = document.getElementById('browseClass').value;
    var secSel = document.getElementById('browseSection');
    secSel.innerHTML = '<option value="">Select Section</option>';
    document.getElementById('rollList').style.display = 'none';
    if (!classId) { secSel.disabled = true; return; }
    var cls = CLASS_SECTIONS.find(function(c){ return String(c.id) === String(classId); });
    (cls ? cls.sections : []).forEach(function(s){
        var opt = document.createElement('option');
        opt.value = s.id;
        opt.textContent = s.name;
        secSel.appendChild(opt);
    });
    secSel.disabled = false;
}

function onBrowseSectionChange() {
    var classId = document.getElementById('browseClass').value;
    var sectionId = document.getElementById('browseSection').value;
    var box = document.getElementById('rollList');
    if (!classId || !sectionId) { box.style.display = 'none'; return; }
    box.innerHTML = '<div class="roll-loading"><i class="fas fa-spinner fa-spin"></i> Loading roll list...</div>';
    box.style.display = 'block';
    fetch('library_search_borrower.php?type=Student&mode=roster&class_id=' + classId + '&section_id=' + sectionId)
        .then(r => r.json())
        .then(data => {
            box.innerHTML = '';
            if (!data.results || data.results.length === 0) {
                box.innerHTML = '<div class="roll-empty"><i class="fas fa-info-circle"></i> No students found in this class-section.</div>';
                return;
            }
            data.results.forEach(function(r){
                var div = document.createElement('div');
                div.className = 'roll-item';
                div.innerHTML =
                    '<div class="roll-badge">' + r.roll_no + '</div>' +
                    '<img src="' + (r.photo || '') + '" onerror="this.style.display=\'none\'">' +
                    '<div><div class="rname">' + r.name + '</div><div class="rsub">' + (r.subtitle || '') + '</div></div>';
                div.onclick = function(){ selectBorrower(r); };
                box.appendChild(div);
            });
        });
}

function switchType(type) {
    currentType = type;
    document.getElementById('borrower_type').value = type;
    document.getElementById('btnStudent').classList.toggle('active', type === 'Student');
    document.getElementById('btnStaff').classList.toggle('active', type === 'Staff');
    document.getElementById('borrowerModeToggle').style.display = type === 'Student' ? 'flex' : 'none';
    setBorrowerMode('search');
    var hint = document.getElementById('borrowerHint');
    var input = document.getElementById('borrowerSearch');
    if (type === 'Student') {
        hint.textContent = 'Name, roll no, or class-section';
        input.placeholder = 'Name, roll no, or class-section (e.g. 10 A)...';
    } else {
        hint.textContent = 'Search by name';
        input.placeholder = 'Search by staff name...';
    }
}
function clearBorrower() {
    document.getElementById('borrower_id').value = '';
    document.getElementById('borrowerSelected').style.display = 'none';
    document.getElementById('borrowerSearch').value = '';
    document.getElementById('borrowerResults').style.display = 'none';
    if (borrowerMode === 'browse') {
        document.getElementById('browseModePane').style.display = 'block';
    } else {
        document.getElementById('borrowerSearch').style.display = 'block';
    }
    updateReview();
}
function clearBook() {
    document.getElementById('copy_id').value = '';
    document.getElementById('bookSelected').style.display = 'none';
    document.getElementById('bookSearch').value = '';
    document.getElementById('bookSearch').style.display = 'block';
    updateReview();
}
function updateReview() {
    var borrowerId = document.getElementById('borrower_id').value;
    var copyId = document.getElementById('copy_id').value;
    var ready = borrowerId && copyId;
    document.getElementById('submitBtn').disabled = !ready;

    var box = document.getElementById('reviewBox');
    if (!ready) { box.style.display = 'none'; return; }

    box.style.display = 'block';
    document.getElementById('reviewBorrower').textContent = document.getElementById('borrowerName').textContent;
    document.getElementById('reviewBook').textContent = document.getElementById('bookName').textContent.replace(/\s+/g,' ').trim();

    var today = new Date();
    var due = new Date();
    due.setDate(due.getDate() + LOAN_DAYS);
    var fmt = function(d){ return d.toLocaleDateString('en-GB', {day:'2-digit', month:'short', year:'numeric'}); };
    document.getElementById('reviewIssueDate').textContent = fmt(today);
    document.getElementById('reviewDueDate').textContent = fmt(due) + ' (' + LOAN_DAYS + ' days)';
}

var bTimer;
document.getElementById('borrowerSearch').addEventListener('input', function(){
    var q = this.value.trim();
    clearTimeout(bTimer);
    var box = document.getElementById('borrowerResults');
    if (q.length < 2) { box.style.display = 'none'; return; }
    bTimer = setTimeout(function(){
        fetch('library_search_borrower.php?type=' + currentType + '&q=' + encodeURIComponent(q))
            .then(r => r.json())
            .then(data => {
                box.innerHTML = '';
                if (!data.results || data.results.length === 0) {
                    box.innerHTML = '<div class="result-item empty"><i class="fas fa-user-slash" style="margin-right:6px;"></i> No match found</div>';
                } else {
                    data.results.forEach(function(r){
                        var div = document.createElement('div');
                        div.className = 'result-item';
                        div.innerHTML = '<img src="' + (r.photo || '') + '" onerror="this.style.display=\'none\'"><div><div class="rname">' + r.name + '</div><div class="rsub">' + r.subtitle + '</div></div>';
                        div.onclick = function(){ selectBorrower(r); };
                        box.appendChild(div);
                    });
                }
                box.style.display = 'block';
            });
    }, 300);
});
function selectBorrower(r) {
    document.getElementById('borrower_id').value = r.id;
    document.getElementById('borrowerImg').src = r.photo || '';
    document.getElementById('borrowerName').textContent = r.name;
    document.getElementById('borrowerSub').textContent = r.subtitle;
    document.getElementById('borrowerSelected').style.display = 'flex';
    document.getElementById('borrowerSearch').style.display = 'none';
    document.getElementById('borrowerResults').style.display = 'none';
    document.getElementById('browseModePane').style.display = 'none';
    updateReview();
}

var kTimer;
document.getElementById('bookSearch').addEventListener('input', function(){
    var q = this.value.trim();
    clearTimeout(kTimer);
    var box = document.getElementById('bookResults');
    if (q.length < 2) { box.style.display = 'none'; return; }
    kTimer = setTimeout(function(){
        fetch('library_search_book.php?q=' + encodeURIComponent(q))
            .then(r => r.json())
            .then(data => {
                box.innerHTML = '';
                if (!data.results || data.results.length === 0) {
                    box.innerHTML = '<div class="result-item empty"><i class="fas fa-book-dead" style="margin-right:6px;"></i> No available copy found</div>';
                } else {
                    data.results.forEach(function(r){
                        var isExact = r.accession_no && r.accession_no.toLowerCase() === q.toLowerCase();
                        var div = document.createElement('div');
                        div.className = 'result-item';
                        div.innerHTML =
                            '<div>' +
                                '<div class="rname"><span class="acc-badge' + (isExact ? ' exact' : '') + '">' + r.accession_no + '</span> ' + r.title +
                                (isExact ? ' <span class="exact-tag"><i class="fas fa-check-circle"></i> Exact match</span>' : '') +
                                '</div>' +
                                '<div class="rsub">' + (r.subtitle || '') + '</div>' +
                            '</div>';
                        div.onclick = function(){ selectBook(r); };
                        box.appendChild(div);
                    });
                }
                box.style.display = 'block';
            });
    }, 300);
});
function selectBook(r) {
    document.getElementById('copy_id').value = r.copy_id;
    document.getElementById('bookName').innerHTML = '<span class="acc-badge exact">' + r.accession_no + '</span> ' + r.title;
    document.getElementById('bookSub').textContent = r.subtitle || '';
    document.getElementById('bookSelected').style.display = 'flex';
    document.getElementById('bookSearch').style.display = 'none';
    document.getElementById('bookResults').style.display = 'none';
    updateReview();
}
document.addEventListener('click', function(e){
    if (!e.target.closest('.search-box')) {
        document.getElementById('borrowerResults').style.display = 'none';
        document.getElementById('bookResults').style.display = 'none';
    }
});

<?php if ($just_issued): ?>
// Quick-fire librarian workflow: after a successful issue, jump straight
// back into the borrower search so the next book can be issued right away.
document.getElementById('borrowerSearch').focus();
<?php endif; ?>
</script>
</body>
</html>

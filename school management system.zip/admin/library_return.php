<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

$settings = get_library_settings($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $issue_id = (int)($_POST['issue_id'] ?? 0);

    $issue = get_open_library_issue($conn, $issue_id);

    if (!$issue) {
        $_SESSION['error'] = "This transaction was not found or is already closed.";
        header("Location: library_return.php");
        exit();
    }

    if (isset($_POST['return_book'])) {
        $today = date('Y-m-d');
        $fine = calc_current_fine($issue['due_date'], $settings['fine_per_day'], $today);
        $fine_paid = isset($_POST['fine_paid']) ? 1 : 0;

        mysqli_begin_transaction($conn);
        $issue = get_open_library_issue($conn, $issue_id, true);
        if (!$issue) { mysqli_rollback($conn); $_SESSION['error'] = 'This transaction is already closed.'; header('Location: library_return.php'); exit(); }
        $stmt = mysqli_prepare($conn, "UPDATE library_issues SET return_date=?, fine_amount=?, fine_paid=?, status='Returned', returned_to=? WHERE id=?");
        $returned_to = $_SESSION['admin_id'] ?? null;
        mysqli_stmt_bind_param($stmt, "sdiii", $today, $fine, $fine_paid, $returned_to, $issue_id);
        if (!mysqli_stmt_execute($stmt) || !set_library_copy_status($conn, $issue['copy_id'], 'Available')) { mysqli_rollback($conn); $_SESSION['error']='Return could not be completed.'; header('Location: library_return.php'); exit(); }
        mysqli_commit($conn);

        $_SESSION['success'] = "\"{$issue['title']}\" ({$issue['accession_no']}) has been returned." . ($fine > 0 ? " Fine: ₹" . number_format($fine, 2) . ($fine_paid ? ' (paid)' : ' (pending)') : '');

    } elseif (isset($_POST['renew_book'])) {
        if ((int)$issue['renewal_count'] >= (int)$settings['max_renewals']) {
            $_SESSION['error'] = "Already renewed the maximum {$settings['max_renewals']} times — can't renew again, must be returned.";
        } else {
            $new_due = date('Y-m-d', strtotime($issue['due_date'] . " +{$settings['loan_period_days']} days"));
            $stmt = mysqli_prepare($conn, "UPDATE library_issues SET due_date=?, renewal_count=renewal_count+1 WHERE id=?");
            mysqli_stmt_bind_param($stmt, "si", $new_due, $issue_id);
            mysqli_stmt_execute($stmt);
            $_SESSION['success'] = "\"{$issue['title']}\" has been renewed — new due date: " . date('d M Y', strtotime($new_due));
        }

    } elseif (isset($_POST['mark_lost'])) {
        $today = date('Y-m-d');
        $fine = (float)$issue['price']; // Fine for a lost book = that book's own price
        mysqli_begin_transaction($conn);
        $issue = get_open_library_issue($conn, $issue_id, true);
        if (!$issue) { mysqli_rollback($conn); $_SESSION['error']='This transaction is already closed.'; header('Location: library_return.php'); exit(); }
        $stmt = mysqli_prepare($conn, "UPDATE library_issues SET return_date=?, fine_amount=?, status='Lost' WHERE id=?");
        mysqli_stmt_bind_param($stmt, "sdi", $today, $fine, $issue_id);
        if (!mysqli_stmt_execute($stmt) || !set_library_copy_status($conn, $issue['copy_id'], 'Lost')) { mysqli_rollback($conn); $_SESSION['error']='Lost-book update could not be completed.'; header('Location: library_return.php'); exit(); }
        mysqli_commit($conn);
        $_SESSION['success'] = "\"{$issue['title']}\" ({$issue['accession_no']}) has been marked as Lost. Fine: ₹" . number_format($fine, 2);
    }
    header("Location: library_return.php");
    exit();
}

$search = trim($_GET['search'] ?? '');
$overdue_only = isset($_GET['overdue_only']);
$sql = "SELECT li.*, c.accession_no, b.title, b.price
        FROM library_issues li
        JOIN library_book_copies c ON c.id=li.copy_id
        JOIN library_books b ON b.id=c.book_id
        WHERE li.status='Issued'";
$params = [];
$types = '';
if ($search !== '') {
    $sql .= " AND ((li.borrower_type='Student' AND EXISTS(SELECT 1 FROM students s WHERE s.id=li.borrower_id AND s.student_name LIKE ?))
              OR (li.borrower_type='Staff' AND EXISTS(SELECT 1 FROM staff st WHERE st.id=li.borrower_id AND st.staff_name LIKE ?))
              OR b.title LIKE ? OR c.accession_no LIKE ?)";
    $like = '%' . $search . '%';
    $params = [$like, $like, $like, $like];
    $types = 'ssss';
}
if ($overdue_only) $sql .= " AND li.due_date < CURDATE()";
$sql .= " ORDER BY li.due_date ASC";
$q = db_query($sql, $types, ...$params);

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Return Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.filter-box { background: #f8f9fa; padding: 15px; border-radius: 12px; border: 1px solid #e4edf6; margin-bottom: 20px; display:flex; gap:10px; flex-wrap:wrap; align-items:center; }
.filter-box input { flex: 1; min-width: 200px; padding: 9px 12px; border: 2px solid #e4edf6; border-radius: 8px; }
.issue-row { border: 1px solid #e4edf6; border-radius: 12px; padding: 14px 18px; margin-bottom: 12px; display: flex; flex-wrap: wrap; gap: 14px; align-items: center; }
.issue-row.overdue { border-color: #f1aeb5; background: #fff8f8; }
.issue-info { flex: 1; min-width: 220px; }
.issue-info .bname { font-weight: 700; color: #003366; font-size: 14px; }
.issue-info .meta { font-size: 12px; color: #6c7a8a; margin-top: 3px; }
.due-box { text-align: center; min-width: 110px; }
.due-box .label { font-size: 10px; color: #6c7a8a; text-transform: uppercase; }
.due-box .val { font-weight: 700; font-size: 13px; }
.due-ontime { color: #155724; }
.due-late { color: #a4161a; }
.fine-badge { background: #f8d7da; color: #842029; padding: 4px 10px; border-radius: 8px; font-size: 12px; font-weight: 700; }
.action-group { display: flex; gap: 6px; flex-wrap: wrap; }
.btn-sm { padding: 6px 12px; font-size: 12px; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-success { background: #d4edda; color: #155724; }
.alert-error { background: #f8d7da; color: #842029; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-undo-alt"></i> Return / Renew Book</div>
        <a href="library_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>
    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <form method="GET" class="filter-box">
        <input type="text" name="search" placeholder="Search by student/staff name, book, or Accession No..." value="<?php echo htmlspecialchars($search); ?>">
        <label style="font-size:13px; display:flex; align-items:center; gap:6px;"><input type="checkbox" name="overdue_only" value="1" <?php echo $overdue_only?'checked':''; ?>> Overdue only</label>
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
    </form>

    <?php $any = false; while ($row = mysqli_fetch_assoc($q)): $any = true;
        $is_overdue = strtotime($row['due_date']) < strtotime(date('Y-m-d'));
        $fine_now = calc_current_fine($row['due_date'], $settings['fine_per_day']);
        $borrower = get_borrower_info($conn, $row['borrower_type'], $row['borrower_id']);
        $bname = $borrower['name'] ?? '(deleted)';
        $bmeta = $row['borrower_type'] === 'Student'
            ? trim(($borrower['class_name'] ?? '') . ' ' . ($borrower['section_name'] ?? '')) . (!empty($borrower['roll_no']) ? ' • Roll: ' . $borrower['roll_no'] : '')
            : ($borrower['designation'] ?? 'Staff');
    ?>
    <div class="issue-row <?php echo $is_overdue?'overdue':''; ?>">
        <div class="issue-info">
            <div class="bname"><?php echo htmlspecialchars($row['title']); ?> <small style="color:#6c7a8a;font-weight:400;">(<?php echo htmlspecialchars($row['accession_no']); ?>)</small></div>
            <div class="meta"><i class="fas fa-user"></i> <?php echo htmlspecialchars($bname); ?> — <?php echo htmlspecialchars($bmeta); ?></div>
            <div class="meta">Issued: <?php echo date('d M Y', strtotime($row['issue_date'])); ?> &nbsp; | &nbsp; Renewed: <?php echo (int)$row['renewal_count']; ?>/<?php echo (int)$settings['max_renewals']; ?> times</div>
        </div>
        <div class="due-box">
            <div class="label">Due Date</div>
            <div class="val <?php echo $is_overdue?'due-late':'due-ontime'; ?>"><?php echo date('d M Y', strtotime($row['due_date'])); ?></div>
            <?php if ($fine_now > 0): ?><div class="fine-badge" style="margin-top:6px;">Fine ₹<?php echo number_format($fine_now,2); ?></div><?php endif; ?>
        </div>
        <div class="action-group">
            <form method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="issue_id" value="<?php echo $row['id']; ?>">
                <?php if ($fine_now > 0): ?>
                <label style="font-size:11px; display:block; margin-bottom:4px;"><input type="checkbox" name="fine_paid" value="1"> Fine paid</label>
                <?php endif; ?>
                <button type="submit" name="return_book" class="btn btn-success btn-sm" onclick="return confirm('Confirm this return?')"><i class="fas fa-check"></i> Return</button>
            </form>
            <form method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="issue_id" value="<?php echo $row['id']; ?>">
                <button type="submit" name="renew_book" class="btn btn-primary btn-sm" <?php echo ((int)$row['renewal_count'] >= (int)$settings['max_renewals']) ? 'disabled title="Maximum renewal limit reached"' : ''; ?>><i class="fas fa-redo"></i> Renew</button>
            </form>
            <form method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="issue_id" value="<?php echo $row['id']; ?>">
                <button type="submit" name="mark_lost" class="btn btn-danger btn-sm" onclick="return confirm('Mark this book as Lost? The fine will be ₹<?php echo number_format($row['price'],2); ?>')"><i class="fas fa-exclamation-circle"></i> Lost</button>
            </form>
        </div>
    </div>
    <?php endwhile; ?>
    <?php if (!$any): ?><p style="text-align:center; color:#6c7a8a; padding:30px;">No book is currently issued to anyone.</p><?php endif; ?>
</div>
</body>
</html>

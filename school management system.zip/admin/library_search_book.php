<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }

// ===== COPY-level search (not book-level) =====
// Searching by accession number matches that exact physical copy and floats
// it to the top. Searching by title/author lists every available copy of
// every matching book — one row per copy — so the librarian picks the exact
// copy in hand rather than the system silently auto-picking one for them.
$stmt = mysqli_prepare($conn, "
    SELECT c.id AS copy_id, c.accession_no, b.title, b.author, b.shelf_location
    FROM library_book_copies c
    JOIN library_books b ON b.id = c.book_id
    WHERE c.status = 'Available' AND b.status = 'Active'
      AND (
            c.accession_no LIKE CONCAT('%', ?, '%')
         OR b.title        LIKE CONCAT('%', ?, '%')
         OR b.author       LIKE CONCAT('%', ?, '%')
      )
    ORDER BY (c.accession_no LIKE CONCAT(?, '%')) DESC, b.title ASC, c.accession_no ASC
    LIMIT 15
");
mysqli_stmt_bind_param($stmt, "ssss", $q, $q, $q, $q);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

$results = [];
while ($r = mysqli_fetch_assoc($res)) {
    $bits = [];
    if (!empty($r['author'])) { $bits[] = $r['author']; }
    if (!empty($r['shelf_location'])) { $bits[] = 'Shelf: ' . $r['shelf_location']; }
    $results[] = [
        'copy_id'      => $r['copy_id'],
        'accession_no' => $r['accession_no'],
        'title'        => $r['title'],
        'subtitle'     => implode(' • ', $bits),
    ];
}
echo json_encode(['results' => $results]);

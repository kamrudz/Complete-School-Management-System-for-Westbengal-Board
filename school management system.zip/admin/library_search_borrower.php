<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");

$type = ($_GET['type'] ?? 'Student') === 'Staff' ? 'Staff' : 'Student';
$mode = ($_GET['mode'] ?? 'search') === 'roster' ? 'roster' : 'search';

// ============================================================
// ROSTER MODE — "Browse by Class/Roll": every active student in one
// class+section, ordered by roll number, with father's name shown
// right in the list so the librarian can confirm at a glance.
// ============================================================
if ($type === 'Student' && $mode === 'roster') {
    $class_id = (int)($_GET['class_id'] ?? 0);
    $section_id = (int)($_GET['section_id'] ?? 0);
    if ($class_id <= 0 || $section_id <= 0) { echo json_encode(['results' => []]); exit(); }

    $stmt = mysqli_prepare($conn, "
        SELECT s.id, s.student_name, s.photo, h.roll_no, g.father_name
        FROM students s
        JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE s.student_status='Active' AND h.class_id=? AND h.section_id=?
        ORDER BY CAST(h.roll_no AS UNSIGNED) ASC, h.roll_no ASC
        LIMIT 100
    ");
    mysqli_stmt_bind_param($stmt, "ii", $class_id, $section_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $results = [];
    while ($r = mysqli_fetch_assoc($res)) {
        $sub = !empty($r['father_name']) ? 'Father: ' . $r['father_name'] : '';
        $results[] = [
            'id' => $r['id'], 'name' => $r['student_name'], 'roll_no' => $r['roll_no'] ?? '-',
            'subtitle' => $sub,
            'photo' => !empty($r['photo']) ? '../uploads/students/' . $r['photo'] : '',
        ];
    }
    echo json_encode(['results' => $results]);
    exit();
}

// ============================================================
// SEARCH MODE — free-text search (existing behaviour)
// ============================================================
$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
$results = [];

if ($type === 'Student') {
    // Matches on name, roll number, class+section, OR father's name — so
    // "10 A", a roll number, or even a parent's name all find the right
    // student, not only the student's own name.
    $stmt = mysqli_prepare($conn, "
        SELECT s.id, s.student_name, s.photo, h.roll_no, c.class_name, sec.section_name, g.father_name
        FROM students s
        LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
        LEFT JOIN classes c ON c.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE s.student_status='Active'
          AND (
                s.student_name LIKE CONCAT('%',?,'%')
             OR h.roll_no LIKE CONCAT('%',?,'%')
             OR CONCAT(c.class_name,' ',sec.section_name) LIKE CONCAT('%',?,'%')
             OR CONCAT(c.class_name,'-',sec.section_name) LIKE CONCAT('%',?,'%')
             OR g.father_name LIKE CONCAT('%',?,'%')
          )
        ORDER BY s.student_name ASC LIMIT 12
    ");
    mysqli_stmt_bind_param($stmt, "sssss", $q, $q, $q, $q, $q);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    while ($r = mysqli_fetch_assoc($res)) {
        $bits = [];
        $cs = trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''));
        if ($cs !== '') { $bits[] = $cs; }
        if (!empty($r['roll_no'])) { $bits[] = 'Roll: ' . $r['roll_no']; }
        if (!empty($r['father_name'])) { $bits[] = 'Father: ' . $r['father_name']; }
        $results[] = [
            'id' => $r['id'], 'name' => $r['student_name'], 'subtitle' => implode(' • ', $bits),
            'photo' => !empty($r['photo']) ? '../uploads/students/' . $r['photo'] : '',
        ];
    }
} else {
    $stmt = mysqli_prepare($conn, "SELECT id, staff_name, photo, designation FROM staff WHERE service_status='Active' AND staff_name LIKE CONCAT('%',?,'%') ORDER BY staff_name ASC LIMIT 12");
    mysqli_stmt_bind_param($stmt, "s", $q);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    while ($r = mysqli_fetch_assoc($res)) {
        $results[] = [
            'id' => $r['id'], 'name' => $r['staff_name'], 'subtitle' => $r['designation'] ?? '',
            'photo' => !empty($r['photo']) ? '../uploads/staff/' . $r['photo'] : '',
        ];
    }
}
echo json_encode(['results' => $results]);

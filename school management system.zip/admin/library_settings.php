<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $loan_period_days = max(1, (int)$_POST['loan_period_days']);
    $max_renewals = max(0, (int)$_POST['max_renewals']);
    $fine_per_day = max(0, (float)$_POST['fine_per_day']);
    $max_books_per_student = max(1, (int)$_POST['max_books_per_student']);
    $max_books_per_staff = max(1, (int)$_POST['max_books_per_staff']);

    $stmt = mysqli_prepare($conn, "
        INSERT INTO library_settings (id, loan_period_days, max_renewals, fine_per_day, max_books_per_student, max_books_per_staff)
        VALUES (1, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE loan_period_days=VALUES(loan_period_days), max_renewals=VALUES(max_renewals),
            fine_per_day=VALUES(fine_per_day), max_books_per_student=VALUES(max_books_per_student), max_books_per_staff=VALUES(max_books_per_staff)
    ");
    mysqli_stmt_bind_param($stmt, "iidii", $loan_period_days, $max_renewals, $fine_per_day, $max_books_per_student, $max_books_per_staff);
    mysqli_stmt_execute($stmt);
    $_SESSION['success'] = "Library settings updated!";
    header("Location: library_settings.php");
    exit();
}

require_once("../includes/library_helper.php");
$s = get_library_settings($conn);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Settings</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 620px; }
.form-row { margin-bottom: 20px; }
.form-row label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 6px; }
.form-row label small { display: block; font-weight: 400; color: #6c7a8a; margin-top: 2px; }
.form-row input { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.form-row .input-suffix { position: relative; }
.form-row .input-suffix span { position: absolute; right: 14px; top: 50%; transform: translateY(-50%); color: #6c7a8a; font-size: 13px; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-success { background: #d4edda; color: #155724; }
.info-note { background: #eaf2fb; color: #003366; padding: 10px 14px; border-radius: 8px; font-size: 12px; margin-top: -8px; margin-bottom: 20px; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-cog"></i> Library Settings</div>
        <a href="library_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>

    <?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <div class="form-card">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <label>Loan Period <small>How many days a borrower gets after issue</small></label>
                <div class="input-suffix"><input type="number" name="loan_period_days" min="1" value="<?php echo (int)$s['loan_period_days']; ?>" required><span>days</span></div>
            </div>
            <div class="form-row">
                <label>Max Renewals <small>Maximum number of times a book can be renewed</small></label>
                <input type="number" name="max_renewals" min="0" value="<?php echo (int)$s['max_renewals']; ?>" required>
            </div>
            <div class="form-row">
                <label>Fine Per Day <small>Charged per day once the due date has passed</small></label>
                <div class="input-suffix"><input type="number" name="fine_per_day" min="0" step="0.01" value="<?php echo $s['fine_per_day']; ?>" required><span>₹</span></div>
            </div>
            <div class="info-note"><i class="fas fa-info-circle"></i> No separate setting needed for a lost book's fine — it's taken directly from that book's own "Price" field.</div>
            <div class="form-row">
                <label>Max Books Per Student <small>Maximum books a single student can hold at once</small></label>
                <input type="number" name="max_books_per_student" min="1" value="<?php echo (int)$s['max_books_per_student']; ?>" required>
            </div>
            <div class="form-row">
                <label>Max Books Per Staff <small>Maximum books a single staff member can hold at once</small></label>
                <input type="number" name="max_books_per_staff" min="1" value="<?php echo (int)$s['max_books_per_staff']; ?>" required>
            </div>
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save Settings</button>
        </form>
    </div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/security.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['add_staff'])) {
        $staff_id = (int)$_POST['staff_id'];
        $admin_id = $_SESSION['admin_id'] ?? null;
        if (!$staff_id || !db_get_row("SELECT id FROM staff WHERE id=? LIMIT 1", 'i', $staff_id)) { $_SESSION['error']='Invalid staff member.'; header('Location: library_staff_access.php'); exit(); }
        $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO library_staff_access (staff_id, assigned_by) VALUES (?,?)");
        mysqli_stmt_bind_param($stmt, "ii", $staff_id, $admin_id);
        mysqli_stmt_execute($stmt);
        $_SESSION['success'] = "Library access granted!";
    } elseif (isset($_POST['remove_staff'])) {
        $id = (int)$_POST['id'];
        db_execute("DELETE FROM library_staff_access WHERE id=?", 'i', $id);
        $_SESSION['success'] = "Library access removed!";
    }
    header("Location: library_staff_access.php");
    exit();
}

$assigned = mysqli_query($conn, "
    SELECT la.id, s.id AS staff_id, s.staff_name, s.employee_id, s.designation, s.photo,
           (s.login_password IS NOT NULL AND s.login_password != '') AS has_login
    FROM library_staff_access la
    JOIN staff s ON s.id = la.staff_id
    ORDER BY s.staff_name ASC
");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Staff Access</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
.form-card { background: #fff; padding: 20px; border-radius: 12px; border: 1px solid #e4edf6; max-width: 560px; margin-bottom: 20px; }
.search-box { position: relative; }
.search-box input { width: 100%; padding: 11px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
.search-results { position: absolute; top: 100%; left: 0; right: 0; background: #fff; border: 1px solid #e4edf6; border-radius: 8px; box-shadow: 0 6px 20px rgba(0,0,0,0.12); max-height: 260px; overflow-y: auto; z-index: 20; display: none; }
.result-item { display: flex; align-items: center; gap: 10px; padding: 10px 14px; cursor: pointer; border-bottom: 1px solid #f0f0f0; }
.result-item:hover { background: #f0f7ff; }
.result-item img { width: 32px; height: 32px; border-radius: 6px; object-fit: cover; background:#ddd; }
table { width: 100%; border-collapse: collapse; font-size: 13px; max-width: 720px; }
table th, table td { padding: 10px 12px; border-bottom: 1px solid #e4edf6; text-align: left; }
table th { background: #003366; color: #fff; }
.person-cell { display: flex; align-items: center; gap: 10px; }
.person-cell img { width: 34px; height: 34px; border-radius: 8px; object-fit: cover; background:#ddd; }
.badge-ok { background:#d4edda; color:#155724; padding:3px 10px; border-radius:10px; font-size:11px; font-weight:700; }
.badge-no { background:#f8d7da; color:#842029; padding:3px 10px; border-radius:10px; font-size:11px; font-weight:700; }
.alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; font-weight: 600; }
.alert-success { background: #d4edda; color: #155724; }
.info-note { background:#eaf2fb; color:#003366; padding:10px 14px; border-radius:8px; font-size:12px; margin-bottom:20px; max-width:720px; }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-user-shield"></i> Library Staff Access</div>
        <a href="library_dashboard.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Library Dashboard</a>
    </div>

    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>

    <div class="info-note">
        <i class="fas fa-info-circle"></i> Anyone added here will be able to use <b>Library Scan from the Teacher Portal</b> —
        regardless of their Designation (a dedicated "Librarian" or any subject teacher), none of the staff's other data changes.
        They just need to already have Teacher Login (Employee ID + password).
    </div>

    <div class="form-card">
        <h4 style="color:#003366;margin-bottom:12px;"><i class="fas fa-plus-circle"></i> Grant Library Access to Someone New</h4>
        <div class="search-box">
            <input type="text" id="staffSearch" placeholder="Search by staff name..." autocomplete="off">
            <div class="search-results" id="staffResults"></div>
        </div>
        <form method="POST" id="addForm" style="display:none; margin-top:10px;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="staff_id" id="selectedStaffId">
            <div style="background:#eaf2fb; padding:10px 14px; border-radius:8px; display:flex; align-items:center; gap:10px;">
                <span id="selectedStaffName" style="font-weight:600; color:#003366;"></span>
                <button type="submit" name="add_staff" class="btn btn-success btn-sm" style="margin-left:auto;"><i class="fas fa-check"></i> Grant Access</button>
            </div>
        </form>
    </div>

    <h4 style="color:#003366;margin-bottom:12px;"><i class="fas fa-list"></i> Staff with Library Access</h4>
    <div style="overflow-x:auto;">
    <table>
        <tr><th></th><th>Name</th><th>Designation</th><th>Employee ID</th><th>Teacher Login</th><th>Action</th></tr>
        <?php $any = false; while ($r = mysqli_fetch_assoc($assigned)): $any = true; ?>
        <tr>
            <td><?php if (!empty($r['photo'])): ?><img src="../uploads/staff/<?php echo htmlspecialchars($r['photo']); ?>" style="width:32px;height:32px;border-radius:8px;object-fit:cover;"><?php endif; ?></td>
            <td><strong><?php echo htmlspecialchars($r['staff_name']); ?></strong></td>
            <td><?php echo htmlspecialchars($r['designation'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($r['employee_id'] ?? '-'); ?></td>
            <td><?php echo $r['has_login'] ? '<span class="badge-ok">Yes</span>' : '<span class="badge-no">No — set a password first</span>'; ?></td>
            <td>
                <form method="POST" onsubmit="return confirm('Remove this access?');">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo $r['id']; ?>">
                    <button type="submit" name="remove_staff" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
        <?php if (!$any): ?><tr><td colspan="6" style="text-align:center;color:#6c7a8a;padding:20px;">No one has been granted Library Access yet.</td></tr><?php endif; ?>
    </table>
    </div>
</div>
<script>
var sTimer;
document.getElementById('staffSearch').addEventListener('input', function(){
    var q = this.value.trim();
    clearTimeout(sTimer);
    var box = document.getElementById('staffResults');
    if (q.length < 2) { box.style.display = 'none'; return; }
    sTimer = setTimeout(function(){
        fetch('library_staff_search.php?q=' + encodeURIComponent(q))
            .then(r => r.json())
            .then(data => {
                box.innerHTML = '';
                if (!data.results || data.results.length === 0) {
                    box.innerHTML = '<div class="result-item">No results found</div>';
                } else {
                    data.results.forEach(function(r){
                        var div = document.createElement('div');
                        div.className = 'result-item';
                        div.innerHTML = '<img src="' + (r.photo || '') + '" onerror="this.style.display=\'none\'"><div><b>' + r.name + '</b><br><small style="color:#6c7a8a;">' + r.designation + '</small></div>';
                        div.onclick = function(){
                            document.getElementById('selectedStaffId').value = r.id;
                            document.getElementById('selectedStaffName').textContent = r.name + ' (' + r.designation + ')';
                            document.getElementById('addForm').style.display = 'block';
                            box.style.display = 'none';
                            document.getElementById('staffSearch').value = r.name;
                        };
                        box.appendChild(div);
                    });
                }
                box.style.display = 'block';
            });
    }, 300);
});
document.addEventListener('click', function(e){
    if (!e.target.closest('.search-box')) { document.getElementById('staffResults').style.display = 'none'; }
});
</script>
</body>
</html>

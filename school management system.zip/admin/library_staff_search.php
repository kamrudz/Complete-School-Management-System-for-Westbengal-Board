<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
$esc = mysqli_real_escape_string($conn, $q);

$res = mysqli_query($conn, "
    SELECT id, staff_name, designation, photo
    FROM staff
    WHERE service_status='Active' AND staff_name LIKE '%$esc%'
    ORDER BY staff_name ASC LIMIT 12
");
$results = [];
while ($r = mysqli_fetch_assoc($res)) {
    $results[] = [
        'id' => $r['id'], 'name' => $r['staff_name'], 'designation' => $r['designation'] ?? '-',
        'photo' => !empty($r['photo']) ? '../uploads/staff/' . $r['photo'] : '',
    ];
}
echo json_encode(['results' => $results]);

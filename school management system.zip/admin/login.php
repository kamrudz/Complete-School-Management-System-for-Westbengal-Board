<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/logger.php';  // ← LOG যোগ করা হয়েছে

// Already logged in? Go to dashboard
redirect_if_logged_in();

// ===== BRUTE-FORCE PROTECTION SETTINGS =====
$MAX_ATTEMPTS = 5;
$LOCKOUT_MINUTES = 15;
$client_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

function get_login_attempt($conn, $identifier) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM login_attempts WHERE identifier = ?");
    if (!$stmt) {
        return null;
    }
    mysqli_stmt_bind_param($stmt, "s", $identifier);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return $result && mysqli_num_rows($result) > 0 ? mysqli_fetch_assoc($result) : null;
}

function register_failed_attempt($conn, $identifier, $max_attempts, $lockout_minutes) {
    $row = get_login_attempt($conn, $identifier);
    if ($row === null) {
        $stmt = mysqli_prepare($conn, "INSERT INTO login_attempts (identifier, attempt_count, first_attempt_at) VALUES (?, 1, NOW())");
        if (!$stmt) {
            return;
        }
        mysqli_stmt_bind_param($stmt, "s", $identifier);
        mysqli_stmt_execute($stmt);
        return;
    }

    $new_count = (int)$row['attempt_count'] + 1;
    if ($new_count >= $max_attempts) {
        $stmt = mysqli_prepare($conn, "UPDATE login_attempts SET attempt_count = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE identifier = ?");
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE login_attempts SET attempt_count = ? WHERE identifier = ?");
    }
    if (!$stmt) {
        return;
    }
    if ($new_count >= $max_attempts) {
        mysqli_stmt_bind_param($stmt, "iis", $new_count, $lockout_minutes, $identifier);
    } else {
        mysqli_stmt_bind_param($stmt, "is", $new_count, $identifier);
    }
    mysqli_stmt_execute($stmt);
}

function clear_login_attempts($conn, $identifier) {
    $stmt = mysqli_prepare($conn, "DELETE FROM login_attempts WHERE identifier = ?");
    if (!$stmt) {
        return;
    }
    mysqli_stmt_bind_param($stmt, "s", $identifier);
    mysqli_stmt_execute($stmt);
}

$error = '';
$locked_wait_msg = '';

// Is this IP currently locked out?
$attempt_row = get_login_attempt($conn, $client_ip);
$is_locked = false;
if ($attempt_row && !empty($attempt_row['locked_until']) && strtotime($attempt_row['locked_until']) > time()) {
    $is_locked = true;
    $mins_left = max(1, ceil((strtotime($attempt_row['locked_until']) - time()) / 60));
    $locked_wait_msg = "অনেকবার ভুল Password দেওয়ার কারণে এই IP থেকে লগইন সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে {$mins_left} মিনিট পর আবার চেষ্টা করুন।";
}

// SECURITY FIX (audit finding 4.3): the lockout used to be tracked by IP
// only, so a distributed attack (many IPs, one username) never tripped it.
// Now we also track attempts per-username and lock out on whichever limit
// is hit first.
$posted_username_for_lock = trim($_POST['username'] ?? '');
$username_identifier = $posted_username_for_lock !== '' ? 'user:' . mb_strtolower($posted_username_for_lock) : null;
if (!$is_locked && $username_identifier) {
    $user_attempt_row = get_login_attempt($conn, $username_identifier);
    if ($user_attempt_row && !empty($user_attempt_row['locked_until']) && strtotime($user_attempt_row['locked_until']) > time()) {
        $is_locked = true;
        $mins_left = max(1, ceil((strtotime($user_attempt_row['locked_until']) - time()) / 60));
        $locked_wait_msg = "অনেকবার ভুল Password দেওয়ার কারণে এই Username দিয়ে লগইন সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে {$mins_left} মিনিট পর আবার চেষ্টা করুন।";
    }
}

if(isset($_POST['login']) && !$is_locked)
{
    verify_csrf_or_die();
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if(empty($username) || empty($password)) {
        $error = "Username এবং Password দিন।";
    } else {
        // Prepared statement — SQL injection proof
        $stmt = mysqli_prepare($conn, "SELECT * FROM admins WHERE username = ?");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if(mysqli_num_rows($result) > 0) {
            $admin = mysqli_fetch_assoc($result);

            $pass_ok = false;

            // bcrypt only — the plain-text fallback is gone (every admin row is hashed)
            if(password_verify($password, $admin['password'])) {
                $pass_ok = true;
                if (password_needs_rehash($admin['password'], PASSWORD_DEFAULT)) {
                    $upd = mysqli_prepare($conn, "UPDATE admins SET password=? WHERE id=?"); $hashed = password_hash($password, PASSWORD_DEFAULT);
                    mysqli_stmt_bind_param($upd, "si", $hashed, $admin['id']); mysqli_stmt_execute($upd);
                }
            }

            if($pass_ok) {
                // Successful login — clear any failed-attempt record for this IP and username
                clear_login_attempts($conn, $client_ip);
                clear_login_attempts($conn, 'user:' . mb_strtolower($username));

                // Secure login (session_regenerate_id সহ)
                secure_login($admin);
                
                // ✅ LOG: Login entry
                log_login($admin['id'], $admin['username']);
                
                header("Location: dashboard.php");
                exit();
            } else {
                register_failed_attempt($conn, $client_ip, $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
                register_failed_attempt($conn, 'user:' . mb_strtolower($username), $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
                $error = "Username বা Password ভুল।";
            }
        } else {
            register_failed_attempt($conn, $client_ip, $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
            register_failed_attempt($conn, 'user:' . mb_strtolower($username), $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
            $error = "Username বা Password ভুল।";
        }
    }
}

$timeout_msg = isset($_GET['timeout']) ? "নিষ্ক্রিয়তার কারণে আপনি logout হয়ে গেছেন। আবার login করুন।" : '';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login — SchoolMS</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin:0; padding:0; box-sizing:border-box; }

body {
    font-family: 'Segoe UI', Arial, sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background: #0f1a2e;
    overflow: hidden;
    position: relative;
}

/* Animated background */
body::before {
    content: '';
    position: fixed;
    inset: 0;
    background:
        radial-gradient(ellipse at 20% 50%, rgba(31,91,138,0.25) 0%, transparent 60%),
        radial-gradient(ellipse at 80% 20%, rgba(0,51,102,0.3) 0%, transparent 50%),
        radial-gradient(ellipse at 60% 80%, rgba(110,168,254,0.1) 0%, transparent 50%);
    z-index: 0;
}

.floating-shapes {
    position: fixed;
    inset: 0;
    z-index: 0;
    pointer-events: none;
}
.shape {
    position: absolute;
    border-radius: 50%;
    opacity: 0.06;
    animation: float linear infinite;
}
.shape:nth-child(1) { width:300px; height:300px; background:#6ea8fe; top:-80px; left:-80px; animation-duration:20s; }
.shape:nth-child(2) { width:200px; height:200px; background:#1f5b8a; bottom:-60px; right:-60px; animation-duration:25s; animation-delay:-8s; }
.shape:nth-child(3) { width:150px; height:150px; background:#6ea8fe; top:50%; left:70%; animation-duration:18s; animation-delay:-4s; }

@keyframes float {
    0%   { transform: translate(0,0) rotate(0deg); }
    33%  { transform: translate(30px,-30px) rotate(120deg); }
    66%  { transform: translate(-20px,20px) rotate(240deg); }
    100% { transform: translate(0,0) rotate(360deg); }
}

.login-wrapper {
    position: relative;
    z-index: 1;
    width: 100%;
    max-width: 440px;
}

/* School branding bar */
.school-brand {
    text-align: center;
    margin-bottom: 24px;
    color: #fff;
}
.school-brand .school-icon {
    width: 72px;
    height: 72px;
    background: linear-gradient(135deg, #1f5b8a, #003366);
    border-radius: 20px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 34px;
    margin-bottom: 12px;
    box-shadow: 0 8px 32px rgba(31,91,138,0.4);
}
.school-brand h1 {
    font-size: 26px;
    font-weight: 800;
    letter-spacing: 1px;
    color: #fff;
}
.school-brand p {
    font-size: 13px;
    color: #8aaccc;
    margin-top: 4px;
}

/* Card */
.login-card {
    background: rgba(255,255,255,0.04);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 24px;
    padding: 40px 36px;
    box-shadow: 0 24px 64px rgba(0,0,0,0.4);
}

.card-title {
    font-size: 18px;
    font-weight: 700;
    color: #fff;
    margin-bottom: 8px;
}
.card-subtitle {
    font-size: 13px;
    color: #8aaccc;
    margin-bottom: 28px;
}

/* Alert */
.alert {
    padding: 12px 16px;
    border-radius: 12px;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
}
.alert-danger {
    background: rgba(220,53,69,0.15);
    border: 1px solid rgba(220,53,69,0.3);
    color: #ff8091;
}
.alert-warning {
    background: rgba(255,193,7,0.12);
    border: 1px solid rgba(255,193,7,0.25);
    color: #ffd666;
}

/* Form */
.form-group { margin-bottom: 20px; }

.form-group label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #a8c4e0;
    margin-bottom: 8px;
    letter-spacing: 0.5px;
    text-transform: uppercase;
}

.input-wrap {
    position: relative;
}
.input-wrap i.input-icon {
    position: absolute;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: #5a7fa0;
    font-size: 15px;
    pointer-events: none;
    transition: color .2s;
}
.input-wrap input {
    width: 100%;
    padding: 13px 16px 13px 44px;
    background: rgba(255,255,255,0.06);
    border: 1.5px solid rgba(255,255,255,0.1);
    border-radius: 12px;
    font-size: 15px;
    color: #fff;
    transition: all .25s;
    outline: none;
}
.input-wrap input::placeholder { color: #4a6a85; }
.input-wrap input:focus {
    background: rgba(110,168,254,0.08);
    border-color: #6ea8fe;
    box-shadow: 0 0 0 4px rgba(110,168,254,0.12);
}
.input-wrap input:focus + i,
.input-wrap:focus-within i.input-icon { color: #6ea8fe; }

/* Show/hide password */
.toggle-pass {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #5a7fa0;
    cursor: pointer;
    font-size: 15px;
    padding: 4px;
    transition: color .2s;
}
.toggle-pass:hover { color: #6ea8fe; }

/* Remember me */
.remember-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 24px;
}
.remember-row input[type="checkbox"] {
    width: 16px;
    height: 16px;
    accent-color: #6ea8fe;
    cursor: pointer;
}
.remember-row label {
    font-size: 13px;
    color: #8aaccc;
    cursor: pointer;
    user-select: none;
}

/* Button */
.btn-login {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, #1f5b8a 0%, #003366 100%);
    color: #fff;
    border: none;
    border-radius: 12px;
    font-size: 15px;
    font-weight: 700;
    cursor: pointer;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    transition: all .25s;
    box-shadow: 0 4px 20px rgba(0,51,102,0.4);
    position: relative;
    overflow: hidden;
}
.btn-login::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, rgba(255,255,255,0.08), transparent);
}
.btn-login:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 28px rgba(31,91,138,0.5);
}
.btn-login:active { transform: translateY(0); }
.btn-login.loading { pointer-events: none; opacity: .8; }

/* Footer */
.card-footer {
    margin-top: 24px;
    text-align: center;
    font-size: 12px;
    color: #4a6a85;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.card-footer i { color: #1f5b8a; }

/* Divider */
.divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 20px 0;
}
.divider::before, .divider::after {
    content: '';
    flex: 1;
    height: 1px;
    background: rgba(255,255,255,0.08);
}
.divider span { font-size: 12px; color: #4a6a85; white-space: nowrap; }

@media(max-width:480px) {
    .login-card { padding: 28px 20px; }
    .school-brand h1 { font-size: 22px; }
}
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<div class="floating-shapes">
    <div class="shape"></div>
    <div class="shape"></div>
    <div class="shape"></div>
</div>

<div class="login-wrapper">

    <div class="school-brand">
        <div class="school-icon">🏫</div>
        <h1>SchoolMS</h1>
        <p>School Management System</p>
    </div>

    <div class="login-card">

        <div class="card-title">Admin Login</div>
        <div class="card-subtitle">আপনার অ্যাকাউন্টে প্রবেশ করুন</div>

        <?php if($timeout_msg): ?>
        <div class="alert alert-warning">
            <i class="fas fa-clock"></i>
            <?php echo htmlspecialchars($timeout_msg); ?>
        </div>
        <?php endif; ?>

        <?php if($locked_wait_msg): ?>
        <div class="alert alert-warning">
            <i class="fas fa-lock"></i>
            <?php echo htmlspecialchars($locked_wait_msg); ?>
        </div>
        <?php endif; ?>

        <?php if($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

        <form method="post" id="loginForm">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Username</label>
                <div class="input-wrap">
                    <input type="text"
                           name="username"
                           id="username"
                           placeholder="admin username লিখুন"
                           value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>"
                           autocomplete="username"
                           <?php echo $is_locked ? 'disabled' : ''; ?>
                           required>
                    <i class="fas fa-user input-icon"></i>
                </div>
            </div>

            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap">
                    <input type="password"
                           name="password"
                           id="password"
                           placeholder="password লিখুন"
                           autocomplete="current-password"
                           <?php echo $is_locked ? 'disabled' : ''; ?>
                           required>
                    <i class="fas fa-lock input-icon"></i>
                    <button type="button" class="toggle-pass" onclick="togglePass()" id="toggleBtn">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>

            <div class="remember-row">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">এই ব্রাউজারে মনে রাখুন (২ ঘণ্টা)</label>
            </div>

            <button type="submit" name="login" class="btn-login" id="loginBtn" <?php echo $is_locked ? 'disabled' : ''; ?>>
                <i class="fas fa-sign-in-alt"></i>
                <span>Login করুন</span>
            </button>

        </form>

        <div class="divider"><span>SchoolMS Admin Panel</span></div>

        <div class="card-footer">
            <i class="fas fa-shield-alt"></i>
            Secure Login &nbsp;|&nbsp; সমস্ত তথ্য সুরক্ষিত
        </div>

    </div>
</div>

<script>
function togglePass() {
    const pwd = document.getElementById('password');
    const icon = document.getElementById('eyeIcon');
    if(pwd.type === 'password') {
        pwd.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        pwd.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

document.getElementById('loginForm').addEventListener('submit', function() {
    const btn = document.getElementById('loginBtn');
    btn.classList.add('loading');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>লগইন হচ্ছে...</span>';
});

// Auto-focus username if empty
window.onload = function() {
    const u = document.getElementById('username');
    if(!u.value) u.focus();
    else document.getElementById('password').focus();
};
</script>

</body>
</html>
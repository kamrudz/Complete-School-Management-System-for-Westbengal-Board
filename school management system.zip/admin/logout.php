<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_once '../includes/logger.php';  // ← LOG যোগ করা হয়েছে

// Log the logout before destroying session
if(isset($_SESSION['admin_login']) && $_SESSION['admin_login'] === true) {
    $admin_id = $_SESSION['admin_id'] ?? 0;
    $username = $_SESSION['username'] ?? 'Unknown';
    log_logout($admin_id, $username);
}

// সব session data মুছে দাও
$_SESSION = [];

// Session cookie মুছে দাও
if(ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

header("Location: login.php?logout=1");
exit();
?>
<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/exam_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Marks entry: exam → class → section (or all) → subject → one grid of the eligible students.
 * Bounds come from Full & Pass Marks; a third-language subject lists only the students who chose it.
 * Each student's marks are saved on their own as soon as a box is left or Absent is ticked (auto-save, see
 * assets/js/marks_autosave.js); the Save button sends whatever is not saved yet. Everything goes through
 * marks_save_rows(), so the limits are the same however a mark arrives.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = exam_list($session_id);
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = $e['exam_name'];
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? '');
$all_sections = $section_raw === 'all';
$section_id = $all_sections ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = 0;
$subject_id = (int)($_GET['subject_id'] ?? $_POST['subject_id'] ?? 0);
$subjects = ($exam && $class_id) ? exam_subjects($session_id, $exam_id, $class_id) : [];
$subject = $subjects[$subject_id] ?? null;
$ready = $exam && $class_id && ($all_sections || $section_id) && $subject;
$qs = "exam_id=$exam_id&class_id=$class_id&section=$section&section_id=" . ($all_sections ? 'all' : (int)$section_id);

// auto-save: one student's marks, answered in JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['autosave'])) {
    header('Content-Type: application/json');
    $out = function (array $a) { echo json_encode($a); exit; };
    if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) $out(['ok' => false, 'error' => 'the page has expired — reload it']);
    if (!$ready) $out(['ok' => false, 'error' => 'pick the exam, class, section and subject again']);
    $uid = student_uid_clean($_POST['uid'] ?? '');
    $row = ['written' => (string)($_POST['written'] ?? ''), 'project' => (string)($_POST['project'] ?? ''), 'absent' => !empty($_POST['absent'])];
    $r = marks_save_rows($session_id, $exam_id, $class_id, $subject_id, [$uid => $row], $admin_id, false);
    if (!$r['ok']) $out(['ok' => false, 'error' => $r['errors'][$uid] ?? ($r['errors']['_'] ?? 'not saved')]);
    log_action($admin_id, 'MARK_SAVED', 'marks', $exam_id, null, ['uid' => $uid, 'class_id' => $class_id, 'subject_id' => $subject_id]
        + ($row['absent'] ? ['absent' => 1] : ['written' => $row['written'], 'project' => $row['project']]));
    $out(['ok' => true, 'cleared' => $r['cleared'] > 0]);
}

$errors = []; $posted = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marks'])) {
    verify_csrf_or_die();
    if (!$ready) { $_SESSION['error'] = 'Pick exam, class, section and subject first.'; header("Location: marks_entry.php?$qs&subject_id=$subject_id"); exit; }
    $posted = (array)($_POST['m'] ?? []);
    $r = marks_save_rows($session_id, $exam_id, $class_id, $subject_id, $posted, $admin_id);
    if ($r['ok']) { $_SESSION['success'] = $subject['name'] . ' · Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : '') . ': ' . $r['saved'] . ' saved' . ($r['cleared'] ? ', ' . $r['cleared'] . ' cleared' : '') . '.'; header("Location: marks_entry.php?$qs&subject_id=$subject_id"); exit; }
    $errors = $r['errors'];
}

$students = $ready ? exam_students($session_id, $class_id, $section_id) : [];
$marks = $ready ? exam_marks($session_id, $exam_id, $class_id, $subject_id, $section_id) : [];
$status = ($exam && $class_id) ? exam_entry_status($session_id, $exam_id, $class_id) : [];
$has_project = $class_id && exam_class_has_project($class_id) && $subject && $subject['project_full'] > 0;
$tl_missing = 0; $listed = [];
if ($ready) foreach ($students as $uid => $st) { if ($subject['tl'] && !$st['tl']) $tl_missing++; if (exam_student_takes($st, $subject)) $listed[$uid] = $st; }
$last = null;
if ($ready && $marks) { $t = ''; foreach ($marks as $uid => $bySub) { $m = $bySub[$subject_id] ?? null; if ($m && ($m['updated_at'] ?? $m['created_at']) > $t) { $t = $m['updated_at'] ?? $m['created_at']; $last = $m; } } }
$val = function (string $uid, string $k) use ($posted, $marks, $subject_id) {   // posted value wins (failed save), else stored
    if ($posted) return (string)($posted[$uid][$k] ?? '');
    $m = $marks[$uid][$subject_id] ?? null; if (!$m) return '';
    if ($k === 'absent') return (int)$m['is_absent'] ? '1' : '';
    if ((int)$m['is_absent']) return '';
    return exam_fmt($m[$k === 'written' ? 'written_marks' : 'project_marks']);
};
$stored = function (string $uid) use ($marks, $subject_id, $has_project) {   // what the server has: [written, project, absent]
    $m = $marks[$uid][$subject_id] ?? null;
    if (!$m) return ['', '', 0];
    if ((int)$m['is_absent']) return ['', '', 1];
    return [exam_fmt($m['written_marks']), $has_project ? exam_fmt($m['project_marks']) : '', 0];
};
$sec_opts = ['all' => 'All sections'] + $sections;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Marks Entry</title>
<?php exam_styles(); ?>
<style>
    .ex-table td.err { background: #fff2f2; } .ex-table td .em { display: block; color: #b71c1c; font-size: 11px; }
    .ex-table td.st { font-size: 11px; font-weight: 700; } .ex-table td.st.p { color: #1b7a3a; } .ex-table td.st.f { color: #b71c1c; } .ex-table td.st.a { color: #616161; }
    .ex-table tr.ab input.m { background: #f2f2f2; color: #999; }
    .sticky { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 2px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .kb { font-size: 11.5px; color: #6b7d90; } .kb kbd { background: #eef1f4; border: 1px solid #d5dde5; border-radius: 4px; padding: 0 5px; font-size: 11px; }
    .meta { font-size: 12px; color: #6b7d90; margin-left: auto; }
    .ex-table th.sub { background: #e9e1f2; }
    /* ruled grid — every column separated, so the eye does not slip across rows */
    #grid th, #grid td { border: 1px solid #dde4ec; } #grid th { border-bottom: 2px solid #c9b8dd; } #grid tr:hover td { background: #f7f2fc; }
    #grid td.sep, #grid th.sep { border-left: 2px solid #b7a6cc; }
    #grid td.sv { font-size: 11px; font-weight: 700; white-space: nowrap; min-width: 58px; } .sv-saving { color: #8a98a8; } .sv-saved, .sv-cleared { color: #1b7a3a; }
    .sv-failed, .sv-bad, .sv-offline { color: #b71c1c; white-space: normal !important; } #svSum { font-size: 12.5px; font-weight: 700; } #svSum.sv-ok { color: #1b7a3a; } #svSum.sv-left { color: #b71c1c; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Marks Entry', 'One subject at a time. Written (and project for IX–X) marks per student; tick Absent for AB. Each student is saved as soon as you leave the box. Limits come from Full & Pass Marks.', 'fa-edit', ['bulk_marks_upload.php' => '<i class="fas fa-file-excel"></i> Bulk upload', 'exam_subject_marks.php' => '<i class="fas fa-sliders-h"></i> Full & Pass Marks']); ?>
    <?php exam_tabs('marks_entry.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>
    <?php if ($errors): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Nothing was saved — fix the rows marked in red<?php if (isset($errors['_'])) echo ': ' . h($errors['_']); ?>.</div><?php endif; ?>

    <form method="get" class="pick card" style="margin-bottom:12px" id="pickForm"><input type="hidden" name="section" value="<?php echo h($section); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No exams in this session'); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='';this.form.subject_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options($sec_opts, $all_sections ? 'all' : ($section_id ?: ''), 'Select section'); ?></select></div>
        <div><label>Subject</label><select name="subject_id" onchange="this.form.submit()" <?php echo $class_id && $exam ? '' : 'disabled'; ?>><?php echo exam_options(array_map(fn($s) => $s['name'] . ($s['configured'] ? '' : ' (no full marks)'), $subjects), $subject_id, 'Select subject'); ?></select></div>
    </form>

    <?php if ($exam && $class_id && $subjects): ?>
    <div class="strip">
        <?php foreach ($status as $sid => $st): $cls = !$st['configured'] ? 'nocfg' : ($st['total'] && $st['done'] >= $st['total'] ? 'done' : ($st['done'] ? 'part' : '')); ?>
        <a href="?<?php echo $qs; ?>&subject_id=<?php echo $sid; ?>" class="<?php echo $cls . ($sid === $subject_id ? ' on' : ''); ?>" title="<?php echo $st['configured'] ? $st['done'] . ' of ' . $st['total'] . ' entered (whole class)' : 'Full marks not set'; ?>"><?php echo $st['configured'] ? ($st['total'] && $st['done'] >= $st['total'] ? '<i class="fas fa-check"></i> ' : ($st['done'] ? '<i class="fas fa-adjust"></i> ' : '')) : '<i class="fas fa-ban"></i> '; ?><?php echo h($subjects[$sid]['name']); ?> <small><?php echo $st['configured'] ? $st['done'] . '/' . $st['total'] : 'no FM'; ?></small></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (!$ready): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-edit"></i><?php echo !$exams ? 'No exams in this session yet — <a href="exams.php">add one</a>.' : (!$exam ? 'Select an exam.' : (!$class_id ? 'Select a class.' : (!$subjects ? 'Class ' . h($classes[$class_id]['name']) . ' has no exam subjects — see <a href="class_subjects.php">Class Subjects</a>.' : (!($all_sections || $section_id) ? 'Select a section (or all sections).' : 'Select a subject.')))); ?></div></div>
    <?php elseif (!$subject['configured']): ?>
        <div class="card"><div class="ex-empty"><i class="fas fa-sliders-h"></i>Full marks for <?php echo h($subject['name']); ?> in <?php echo h($exam['exam_name']); ?> (Class <?php echo h($classes[$class_id]['name']); ?>) are not set — <a href="exam_subject_marks.php?exam_id=<?php echo $exam_id; ?>&class_id=<?php echo $class_id; ?>">set them first</a>.</div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-edit"></i> <?php echo h($exam['exam_name']); ?> · Class <?php echo h($classes[$class_id]['name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?> · <?php echo h($subject['name']); ?>
            <small>Written <?php echo exam_fmt($subject['written_full']); ?><?php if ($has_project): ?> + Project <?php echo exam_fmt($subject['project_full']); ?><?php endif; ?> = <?php echo exam_fmt($subject['full']); ?> · pass <?php echo exam_fmt($subject['pass']); ?> on the total<?php if ($subject['tl']): ?> · 3rd language<?php endif; ?></small></h2>
        <?php if ($tl_missing): ?><div class="alert alert-warning" style="font-size:13px"><i class="fas fa-language"></i> <?php echo $tl_missing; ?> student<?php echo $tl_missing === 1 ? ' has' : 's have'; ?> no third-language choice yet and <?php echo $tl_missing === 1 ? 'is' : 'are'; ?> not listed — <a href="assign_third_language.php?class_id=<?php echo $class_id; ?>">assign third language</a>.</div><?php endif; ?>
        <?php if (!$listed): ?><div class="ex-empty"><i class="fas fa-user-slash"></i>No students to list.</div>
        <?php else: ?>
        <form method="post" id="mf" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $all_sections ? 'all' : (int)$section_id; ?>"><input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
            <table class="ex-table" id="grid"><thead><tr><th class="num">#</th><th class="num">Class</th><th class="num">Sec</th><th class="num">Roll</th><th>Student</th><th>Father</th><th class="num sub sep">Written <small>/<?php echo exam_fmt($subject['written_full']); ?></small></th><?php if ($has_project): ?><th class="num sub">Project <small>/<?php echo exam_fmt($subject['project_full']); ?></small></th><?php endif; ?><th class="num">Absent</th><th class="num sep">Total</th><th class="num">Status</th><th>Saved</th></tr></thead><tbody>
            <?php $i = 0; foreach ($listed as $uid => $st): $i++; $e = $errors[$uid] ?? null; $ab = $val($uid, 'absent') === '1'; ?>
            <tr data-uid="<?php echo h($uid); ?>" data-saved="<?php echo h(json_encode($stored($uid))); ?>" class="<?php echo $ab ? 'ab' : ''; ?>">
                <td class="num"><?php echo $i; ?></td><td class="num"><?php echo h($classes[$class_id]['name']); ?></td><td class="num"><?php echo h($st['section']); ?></td>
                <td class="num"><?php echo h($st['roll']); ?></td><td><b><?php echo h($st['name']); ?></b><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($uid); ?></small></td><td style="color:#4d6178"><?php echo h($st['father']); ?></td>
                <td class="num sep <?php echo $e ? 'err' : ''; ?>"><input class="m w" name="m[<?php echo h($uid); ?>][written]" value="<?php echo h($val($uid, 'written')); ?>" inputmode="decimal" data-max="<?php echo $subject['written_full']; ?>" <?php echo $ab ? 'disabled' : ''; ?>><?php if ($e): ?><span class="em"><?php echo h($e); ?></span><?php endif; ?></td>
                <?php if ($has_project): ?><td class="num"><input class="m p" name="m[<?php echo h($uid); ?>][project]" value="<?php echo h($val($uid, 'project')); ?>" inputmode="decimal" data-max="<?php echo $subject['project_full']; ?>" <?php echo $ab ? 'disabled' : ''; ?>></td><?php endif; ?>
                <td class="num"><input type="checkbox" class="abx" name="m[<?php echo h($uid); ?>][absent]" value="1" <?php echo $ab ? 'checked' : ''; ?> title="Absent"></td>
                <td class="num tot sep"></td><td class="num st"></td><td class="sv"></td>
            </tr>
            <?php endforeach; ?></tbody></table>
            <div class="sticky">
                <button type="submit" name="save_marks" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save rows not saved</button> <span id="svSum"></span>
                <span class="kb"><kbd>Enter</kbd>/<kbd>↓</kbd> next student · <kbd>↑</kbd> previous · <kbd>Tab</kbd> next column · blank = not entered · Absent = AB</span>
                <?php if ($last): ?><span class="meta"><i class="fas fa-history"></i> Last saved <?php echo date('d M Y, g:i a', strtotime($last['updated_at'] ?? $last['created_at'])); ?><?php echo $last['entered_by_name'] ? ' by ' . h($last['entered_by_name']) : ''; ?></span><?php endif; ?>
            </div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
(function () {
    var pass = <?php echo json_encode($subject ? (float)$subject['pass'] : 0); ?>, hasP = <?php echo $has_project ? 'true' : 'false'; ?>;
    function row(tr) {
        var w = tr.querySelector('input.w'), p = tr.querySelector('input.p'), ab = tr.querySelector('.abx').checked, tot = tr.querySelector('.tot'), st = tr.querySelector('.st');
        tr.classList.toggle('ab', ab); w.disabled = ab; if (p) p.disabled = ab;
        [w, p].forEach(function (i) { if (!i) return; var v = i.value.trim(), mx = parseFloat(i.dataset.max); i.classList.toggle('bad', v !== '' && (!/^\d{1,3}(\.\d{1,2})?$/.test(v) || parseFloat(v) > mx)); });
        st.className = 'num st';
        if (ab) { tot.textContent = 'AB'; st.textContent = 'Absent'; st.classList.add('a'); return; }
        var wv = w.value.trim(), pv = p ? p.value.trim() : '';
        if (wv === '' && pv === '') { tot.textContent = ''; st.textContent = ''; return; }
        var t = (parseFloat(wv) || 0) + (parseFloat(pv) || 0); tot.textContent = Math.round(t * 100) / 100;
        var ok = t >= pass; st.textContent = ok ? 'Pass' : 'Fail'; st.classList.add(ok ? 'p' : 'f');
    }
    var rows = Array.prototype.slice.call(document.querySelectorAll('#grid tbody tr'));
    rows.forEach(function (tr) { row(tr); tr.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', function () { row(tr); }); i.addEventListener('change', function () { row(tr); }); }); });
    document.querySelectorAll('#grid input.m').forEach(function (i) {
        i.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
            e.preventDefault();
            var tr = i.closest('tr'), cls = i.classList.contains('w') ? 'w' : 'p', dir = e.key === 'ArrowUp' ? -1 : 1, idx = rows.indexOf(tr) + dir;
            while (idx >= 0 && idx < rows.length) { var n = rows[idx].querySelector('input.' + cls); if (n && !n.disabled) { n.focus(); n.select(); return; } idx += dir; }
        });
    });
    var first = document.querySelector('#grid input.w:not(:disabled)'); if (first && !document.querySelector('.err')) first.focus();
})();
</script>
<script src="../assets/js/marks_autosave.js"></script>
</body>
</html>

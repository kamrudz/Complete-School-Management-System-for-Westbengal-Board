<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Notices. A notice is on the website only when it is published and its date has come, so a notice can be
 * written today and left to appear on its own day. Whether it is new is read off that date, never off the
 * row's position in the list.
 */
$self = fn(array $extra = []) => 'notices.php?' . http_build_query(array_merge($_GET, $extra));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $id = (int)($_POST['id'] ?? 0);
    $notice = $id ? db_get_row('SELECT id, notice_title, status FROM notices WHERE id = ?', 'i', $id) : null;
    if (!$notice) $_SESSION['error'] = 'That notice is gone — look at the list again.';
    elseif (isset($_POST['publish']) || isset($_POST['unpublish'])) {
        $to = isset($_POST['publish']) ? 'Published' : 'Draft';
        db_execute('UPDATE notices SET status = ? WHERE id = ?', 'si', $to, $id);
        $_SESSION['success'] = $notice['notice_title'] . ' is now a ' . ($to === 'Draft' ? 'draft' : 'published notice') . '.';
    }
    header('Location: ' . $self());
    exit();
}

$status = (string)($_GET['status'] ?? '');
if (!in_array($status, ['Draft', 'Published', 'live', 'waiting'], true)) $status = '';
$search = trim((string)($_GET['search'] ?? ''));
$per = (int)($_GET['per'] ?? 25);
if (!in_array($per, [25, 50, 100], true)) $per = 25;
$page = max(1, (int)($_GET['page'] ?? 1));

$where = '1';
$types = '';
$params = [];
if ($status === 'Draft' || $status === 'Published') { $where .= ' AND status = ?'; $types .= 's'; $params[] = $status; }
if ($status === 'live')    $where .= ' AND ' . NOTICE_LIVE;
if ($status === 'waiting') $where .= " AND status = 'Published' AND (publish_date IS NULL OR publish_date > CURDATE())";
if ($search !== '') {
    $where .= ' AND (notice_title LIKE ? OR notice_details LIKE ?)';
    $types .= 'ss';
    $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
    array_push($params, $like, $like);
}

$counts = db_get_row("SELECT COUNT(*) total,
    SUM(status = 'Published') published,
    SUM(status = 'Draft') draft,
    SUM(" . NOTICE_LIVE . ") live,
    SUM(status = 'Published' AND (publish_date IS NULL OR publish_date > CURDATE())) waiting
    FROM notices") ?: [];
$total = (int)(db_get_row("SELECT COUNT(*) n FROM notices WHERE $where", $types, ...$params)['n'] ?? 0);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$rows = db_get_all("SELECT * FROM notices WHERE $where ORDER BY publish_date DESC, id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notices</title>
<?php exam_styles('web'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 9px; margin-bottom: 14px; }
    .sb a { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; text-decoration: none; display: block; }
    .sb a.on { border-color: var(--ex-dark); border-left-color: var(--ex-dark); background: var(--ex-soft); }
    .sb b { display: block; font-size: 20px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .acts { display: flex; gap: 5px; flex-wrap: wrap; }
    .acts form { display: inline; }
    .uid { color: #93a2b2; font-size: 11.5px; }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 12px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Notices', 'What the school tells everyone, on the website and on paper', 'fa-bullhorn',
        ['add_notice.php' => '<i class="fas fa-plus"></i> Write a notice', '../notices.php' => '<i class="fas fa-external-link-alt"></i> See them on the site']); ?>
    <?php exam_tabs('notices.php', WEB_PAGES); exam_flash(); ?>

    <div class="sb">
        <a href="notices.php" class="<?php echo $status === '' ? 'on' : ''; ?>"><b><?php echo (int)($counts['total'] ?? 0); ?></b><span>All notices</span></a>
        <a href="<?php echo h('notices.php?status=live'); ?>" class="<?php echo $status === 'live' ? 'on' : ''; ?>"><b><?php echo (int)($counts['live'] ?? 0); ?></b><span>On the website</span></a>
        <a href="<?php echo h('notices.php?status=waiting'); ?>" class="<?php echo $status === 'waiting' ? 'on' : ''; ?>"><b><?php echo (int)($counts['waiting'] ?? 0); ?></b><span>Waiting for its day</span></a>
        <a href="<?php echo h('notices.php?status=Draft'); ?>" class="<?php echo $status === 'Draft' ? 'on' : ''; ?>"><b><?php echo (int)($counts['draft'] ?? 0); ?></b><span>Drafts</span></a>
    </div>

    <form method="get" class="card pick">
        <input type="hidden" name="status" value="<?php echo h($status); ?>">
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Title or text" style="min-width:240px"></div>
        <div><label>Per page</label><select name="per"><?php echo exam_options([25 => 25, 50 => 50, 100 => 100], $per); ?></select></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
        <div><a href="notices.php" class="btn btn-secondary">Reset</a></div>
    </form>

    <div class="card">
        <h2><i class="fas fa-list"></i> <?php echo $status === '' ? 'Every notice' : 'Notices'; ?> <small><?php echo number_format($total); ?><?php echo $pages > 1 ? ' · page ' . $page . ' of ' . $pages : ''; ?></small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-bullhorn"></i><?php echo $counts['total'] ?? 0 ? 'No notice matches what you asked for.' : 'No notice yet. Write the first one.'; ?></div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th style="width:44px">#</th><th>Notice</th><th>Date</th><th>Where it stands</th><th>File</th><th></th></tr></thead>
            <tbody>
            <?php $i = ($page - 1) * $per; foreach ($rows as $r): [$label, $chip] = notice_state($r); ?>
                <tr>
                    <td class="num"><?php echo ++$i; ?></td>
                    <td>
                        <b><?php echo h($r['notice_title']); ?></b>
                        <?php if (notice_is_new($r['publish_date']) && $r['status'] === 'Published' && $r['publish_date'] <= date('Y-m-d')): ?>
                            <span class="chip ok">NEW</span>
                        <?php endif; ?>
                        <div class="uid"><?php echo h(mb_substr(trim(preg_replace('/\s+/', ' ', (string)$r['notice_details'])), 0, 90)); ?></div>
                    </td>
                    <td><?php echo $r['publish_date'] ? h(date('d M Y', strtotime($r['publish_date']))) : '<span class="chip bad">not given</span>'; ?></td>
                    <td><span class="chip <?php echo h($chip); ?>"><?php echo h($label); ?></span></td>
                    <td><?php echo !empty($r['attachment'])
                        ? '<a href="../uploads/notices/' . h($r['attachment']) . '" target="_blank" title="' . h($r['attachment']) . '"><i class="fas fa-paperclip"></i></a>'
                        : '<span class="uid">—</span>'; ?></td>
                    <td>
                        <div class="acts">
                            <a href="<?php echo h('../notice.php?id=' . (int)$r['id']); ?>" target="_blank" class="btn btn-info btn-sm" title="See it"><i class="fas fa-eye"></i></a>
                            <a href="<?php echo h('edit_notice.php?id=' . (int)$r['id']); ?>" class="btn btn-warning btn-sm" title="Change it"><i class="fas fa-edit"></i></a>
                            <form method="post">
                                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <?php if ($r['status'] === 'Published'): ?>
                                    <button type="submit" name="unpublish" class="btn btn-secondary btn-sm" title="Take it off the website"><i class="fas fa-eye-slash"></i></button>
                                <?php else: ?>
                                    <button type="submit" name="publish" class="btn btn-success btn-sm" title="Put it on the website"><i class="fas fa-upload"></i></button>
                                <?php endif; ?>
                            </form>
                            <form method="post" action="delete_notice.php" onsubmit="return confirm('Delete <?php echo h(addslashes($r['notice_title'])); ?>? The file with it goes too.')">
                                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" title="Delete"><i class="fas fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php if ($pages > 1): ?>
        <div class="pager">
            <span>Page <?php echo $page; ?> of <?php echo $pages; ?></span>
            <?php if ($page > 1): ?><a href="<?php echo h($self(['page' => $page - 1])); ?>"><i class="fas fa-angle-left"></i> Back</a><?php endif; ?>
            <?php for ($p = max(1, $page - 3); $p <= min($pages, $page + 3); $p++): ?>
                <a href="<?php echo h($self(['page' => $p])); ?>" class="<?php echo $p === $page ? 'on' : ''; ?>"><?php echo $p; ?></a>
            <?php endfor; ?>
            <?php if ($page < $pages): ?><a href="<?php echo h($self(['page' => $page + 1])); ?>">Next <i class="fas fa-angle-right"></i></a><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <p class="note">A notice reaches the website when it is published <b>and</b> its date has come — so one written today for next Monday waits until Monday. NEW shows for <?php echo NOTICE_NEW_DAYS; ?> days from that date.</p>
    </div>
</div>
</body>
</html>

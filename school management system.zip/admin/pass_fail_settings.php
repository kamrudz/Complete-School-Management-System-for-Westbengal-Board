<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Result rules per class (pass_fail_settings) and grade bands per class group (grade_bands).
 * Both are read by result_helper.php only, so every result page follows the same rules.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
// Grade bands are kept per stage, so every section can carry its own — Higher Secondary included.
$groups = [];
foreach (class_stages() as $gk => $gs) $groups[$gk] = $gs['label'] . ' (' . $gs['classes'] . ')';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['save_rules'])) {
        $n = 0; $errors = [];
        foreach ($classes as $cid => $c) {
            $r = (array)($_POST['r'][$cid] ?? []);
            $d = ['no_fail_policy' => empty($r['no_fail_policy']) ? 0 : 1, 'puc_enabled' => empty($r['puc_enabled']) ? 0 : 1,
                  'puc_max_fail_subjects' => (int)($r['puc_max_fail_subjects'] ?? 1), 'puc_min_percentage' => (float)($r['puc_min_percentage'] ?? 25), 'pass_min_percentage' => (float)($r['pass_min_percentage'] ?? 33)];
            if ($d['puc_max_fail_subjects'] < 0 || $d['puc_max_fail_subjects'] > 10) { $errors[] = 'Class ' . $c['name'] . ': PUC max failed subjects must be 0–10.'; continue; }
            foreach (['puc_min_percentage', 'pass_min_percentage'] as $k) if ($d[$k] < 0 || $d[$k] > 100) { $errors[] = 'Class ' . $c['name'] . ': percentages must be 0–100.'; continue 2; }
            if ($d['puc_min_percentage'] > $d['pass_min_percentage']) { $errors[] = 'Class ' . $c['name'] . ': PUC minimum % cannot be above the pass minimum %.'; continue; }
            if (db_get_row('SELECT id FROM pass_fail_settings WHERE class_id = ?', 'i', $cid)) db_update('pass_fail_settings', $d, ['class_id' => $cid], 'i');
            else db_insert('pass_fail_settings', $d + ['class_id' => $cid]);
            $n++;
        }
        log_action($admin_id, 'PASS_FAIL_RULES_SAVED', 'pass_fail_settings', null, null, ['classes' => $n]);
        $_SESSION[$errors ? 'error' : 'success'] = $errors ? implode(' ', $errors) . ($n ? " ($n classes saved.)" : '') : "Result rules saved for $n classes.";
    } elseif (isset($_POST['save_grades'])) {
        $group = (string)($_POST['group'] ?? ''); $rows = (array)($_POST['g'] ?? []);
        if (!isset($groups[$group])) { $_SESSION['error'] = 'Unknown class group.'; header('Location: pass_fail_settings.php?section=' . $section); exit; }
        $clean = []; $err = null;
        foreach ($rows as $r) {
            $g = strtoupper(trim((string)($r['grade'] ?? ''))); $min = trim((string)($r['min'] ?? '')); $max = trim((string)($r['max'] ?? '')); $rem = trim((string)($r['remark'] ?? ''));
            if ($g === '' && $min === '' && $max === '') continue;
            if (!preg_match('/^[A-Z][A-Z+\-]{0,2}$/', $g)) { $err = "Grade \"$g\" — use A+, A, B+ … (up to 3 characters)."; break; }
            if (!preg_match('/^\d{1,3}(\.\d{1,2})?$/', $min) || !preg_match('/^\d{1,3}(\.\d{1,2})?$/', $max) || (float)$min > (float)$max || (float)$max > 100) { $err = "Grade $g: range must be 0–100 with from ≤ to."; break; }
            if (isset($clean[$g])) { $err = "Grade $g is listed twice."; break; }
            $clean[$g] = ['grade' => $g, 'min_pct' => (float)$min, 'max_pct' => (float)$max, 'remark' => mb_substr($rem, 0, 60)];
        }
        if (!$err && !$clean) $err = 'At least one grade band is needed.';
        if (!$err) {   // bands must not overlap and together should cover 0–100
            $bands = array_values($clean); usort($bands, fn($a, $b) => $a['min_pct'] <=> $b['min_pct']);
            for ($i = 1; $i < count($bands); $i++) if ($bands[$i]['min_pct'] <= $bands[$i - 1]['max_pct']) { $err = 'Bands ' . $bands[$i - 1]['grade'] . ' and ' . $bands[$i]['grade'] . ' overlap.'; break; }
            if (!$err && ($bands[0]['min_pct'] > 0 || end($bands)['max_pct'] < 100)) $err = 'Bands must run from 0 to 100 (lowest band from 0, highest band to 100).';
        }
        if ($err) $_SESSION['error'] = $err;
        else {
            db_begin_transaction();
            try {
                db_execute('DELETE FROM grade_bands WHERE class_group = ?', 's', $group);
                $i = 0; $bands = array_values($clean); usort($bands, fn($a, $b) => $b['min_pct'] <=> $a['min_pct']);
                foreach ($bands as $b) db_insert('grade_bands', $b + ['class_group' => $group, 'sort_order' => ++$i]);
                db_commit(); log_action($admin_id, 'GRADE_BANDS_SAVED', 'grade_bands', null, null, ['group' => $group, 'bands' => count($bands)]);
                $_SESSION['success'] = 'Grade bands saved for ' . $groups[$group] . '.';
            } catch (Throwable $e) { db_rollback(); $_SESSION['error'] = 'Save failed.'; }
        }
    }
    header('Location: pass_fail_settings.php?section=' . $section); exit;
}
$rules = []; foreach ($classes as $cid => $c) $rules[$cid] = result_settings($cid);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Result Rules & Grades</title>
<?php exam_styles(); ?>
<style>
    .ex-table input.m { width: 70px; } .ex-table input.t { height: 32px; border: 1px solid #c9d6e2; border-radius: 6px; padding: 0 8px; font-size: 13px; width: 100%; }
    .ex-table input[type=checkbox] { width: 17px; height: 17px; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; align-items: start; } @media (max-width: 950px) { .two { grid-template-columns: 1fr; } }
    .rule { font-size: 12.5px; color: #3b5168; background: #f8f6fb; border: 1px solid #e3d9ee; border-radius: 10px; padding: 10px 14px; margin-top: 10px; line-height: 1.6; } .rule b { color: #3b1d5c; }
    .gdel { background: none; border: 0; color: #b71c1c; cursor: pointer; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Result Rules & Grades', 'How a result is decided (per class) and the grade for a percentage (per class group). Every result page uses these.', 'fa-cog'); ?>
    <?php exam_tabs('pass_fail_settings.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>

    <div class="card">
        <h2><i class="fas fa-balance-scale"></i> Pass / fail rules <small>per class</small></h2>
        <form method="post">
            <?php echo csrf_field(); ?>
            <table class="ex-table"><thead><tr><th>Class</th><th class="num">Pass minimum %</th><th class="num">No-fail policy</th><th class="num">PUC allowed</th><th class="num">PUC: max failed subjects</th><th class="num">PUC: minimum %</th></tr></thead><tbody>
            <?php foreach ($classes as $cid => $c): $r = $rules[$cid]; ?>
            <tr><td><b>Class <?php echo h($c['name']); ?></b> <span class="chip off"><?php echo h(class_stage_label($c['group'])); ?></span></td>
                <td class="num"><input class="m" name="r[<?php echo $cid; ?>][pass_min_percentage]" value="<?php echo exam_fmt($r['pass_min_percentage']); ?>" inputmode="decimal"></td>
                <td class="num"><input type="checkbox" name="r[<?php echo $cid; ?>][no_fail_policy]" value="1" <?php echo (int)$r['no_fail_policy'] ? 'checked' : ''; ?>></td>
                <td class="num"><input type="checkbox" name="r[<?php echo $cid; ?>][puc_enabled]" value="1" <?php echo (int)$r['puc_enabled'] ? 'checked' : ''; ?>></td>
                <td class="num"><input class="m" name="r[<?php echo $cid; ?>][puc_max_fail_subjects]" value="<?php echo (int)$r['puc_max_fail_subjects']; ?>" inputmode="numeric"></td>
                <td class="num"><input class="m" name="r[<?php echo $cid; ?>][puc_min_percentage]" value="<?php echo exam_fmt($r['puc_min_percentage']); ?>" inputmode="decimal"></td></tr>
            <?php endforeach; ?></tbody></table>
            <div style="margin-top:12px"><button type="submit" name="save_rules" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save rules</button></div>
        </form>
        <div class="rule">
            <b>How a student's result is decided</b> (a subject is failed when absent or marks incl. grace &lt; pass marks):<br>
            1. Every subject absent / not entered → <b>ABSENT</b>.&nbsp; 2. No subject failed and overall % ≥ pass minimum → <b>PASS</b>.<br>
            3. Otherwise, with <b>no-fail policy</b> on (RTE, V–VIII) → <b>PUC</b> (promoted under consideration).&nbsp;
            4. Otherwise, with <b>PUC allowed</b>, failed subjects ≤ max and overall % ≥ PUC minimum → <b>PUC</b>.&nbsp; 5. Else → <b>FAIL</b>.<br>
            The annual result applies the same rules to the year's totals: Σ of the exams marked "counts in the annual result".
            HPRC <b>formative</b> marks (Primary &amp; Upper Primary) are shown on the report card only — they are never added to a total, a grade, a result or a rank.
        </div>
    </div>

    <div class="two">
    <?php foreach ($groups as $gk => $glabel): $bands = grade_bands($gk); ?>
        <div class="card">
            <h2><i class="fas fa-medal"></i> Grade bands <small><?php echo h($glabel); ?></small></h2>
            <form method="post" id="gf-<?php echo h($gk); ?>">
                <?php echo csrf_field(); ?><input type="hidden" name="group" value="<?php echo h($gk); ?>">
                <table class="ex-table gtab"><thead><tr><th>Grade</th><th class="num">From %</th><th class="num">To %</th><th>Remark</th><th></th></tr></thead><tbody>
                <?php foreach ($bands as $i => $b): ?>
                <tr><td><input class="t" name="g[<?php echo $i; ?>][grade]" value="<?php echo h($b['grade']); ?>" maxlength="3" style="width:64px;font-weight:700"></td>
                    <td class="num"><input class="m" name="g[<?php echo $i; ?>][min]" value="<?php echo exam_fmt($b['min_pct']); ?>" inputmode="decimal"></td>
                    <td class="num"><input class="m" name="g[<?php echo $i; ?>][max]" value="<?php echo exam_fmt($b['max_pct']); ?>" inputmode="decimal"></td>
                    <td><input class="t" name="g[<?php echo $i; ?>][remark]" value="<?php echo h($b['remark']); ?>" maxlength="60"></td>
                    <td><button type="button" class="gdel" title="Remove" onclick="this.closest('tr').remove()"><i class="fas fa-times"></i></button></td></tr>
                <?php endforeach; ?></tbody></table>
                <div style="margin-top:10px;display:flex;gap:8px"><button type="submit" name="save_grades" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save</button><button type="button" class="btn btn-secondary" onclick="addBand('gf-<?php echo h($gk); ?>')"><i class="fas fa-plus"></i> Add band</button></div>
            </form>
            <p class="note">Bands may not overlap and must run from 0 to 100. The % is rounded to 2 decimals before the grade is looked up (89.995 → 90.00 → A+).</p>
        </div>
    <?php endforeach; ?>
    </div>
</div>
<script>
function addBand(fid) {
    var tb = document.querySelector('#' + fid + ' tbody'), i = Date.now() % 100000;
    var tr = document.createElement('tr');
    tr.innerHTML = '<td><input class="t" name="g[' + i + '][grade]" maxlength="3" style="width:64px;font-weight:700"></td><td class="num"><input class="m" name="g[' + i + '][min]" inputmode="decimal"></td><td class="num"><input class="m" name="g[' + i + '][max]" inputmode="decimal"></td><td><input class="t" name="g[' + i + '][remark]" maxlength="60"></td><td><button type="button" class="gdel" onclick="this.closest(\'tr\').remove()"><i class="fas fa-times"></i></button></td>';
    tb.appendChild(tr); tr.querySelector('input').focus();
}
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/promotion_helper.php';

/**
 * Pass Out: the classes that do not go up by promotion — Class X after Madhyamik and Class XII after Higher
 * Secondary. Ticked students are closed as Passed (their row becomes History, the student Passed); Undo brings
 * them back while they have no newer class. A merit list is not needed (XII never has one); when there is one,
 * its result is shown and FAIL / ABSENT start unticked — they stay behind through Not Promoted.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions');
usort($sessions, fn($a, $b) => strnatcmp($b['session_name'], $a['session_name']));
$names = array_column($sessions, 'session_name', 'id');
$active = 0;
foreach ($sessions as $s) if ($s['status'] === 'Active') $active = (int)$s['id'];
$terminal = array_filter(class_rows(), fn($c, $id) => promotion_next_class($id) === null, ARRAY_FILTER_USE_BOTH);   // X and XII

$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0); if (!isset($names[$session_id])) $session_id = $active;
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($terminal[$class_id])) $class_id = 0;
$back = 'pass_out_students.php?' . http_build_query(['session_id' => $session_id, 'class_id' => $class_id]);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $undo = isset($_POST['undo_pass_out']);
    $uids = array_values(array_unique(array_filter(array_map('student_uid_clean', (array)($_POST[$undo ? 'undo_student_id' : 'student_id'] ?? [])))));
    if (!$class_id || !$uids) { $_SESSION['error'] = $class_id ? 'Tick at least one student.' : 'Choose Class X or XII.'; header("Location: $back"); exit(); }
    $done = 0; $skipped = 0;
    db_begin_transaction();
    try {
        foreach ($uids as $uid) {
            if (!$undo) {
                // only a student still Current in this class is closed; anyone else is left alone
                $n = db_execute("UPDATE student_academic_history SET academic_status = 'History', promotion_status = 'Promoted', student_status = 'Passed'
                                 WHERE student_id = ? AND session_id = ? AND class_id = ? AND academic_status = 'Current'", 'sii', $uid, $session_id, $class_id);
                if (!$n) { $skipped++; continue; }
                db_execute("UPDATE students SET student_status = 'Passed' WHERE id = ?", 's', $uid);
                log_action($admin_id, 'STUDENT_PASSED_OUT', 'students', $uid, null, ['session_id' => $session_id, 'class_id' => $class_id]);
            } else {
                // a student already placed somewhere newer (Class XI after X, say) is not taken back
                if (db_get_row("SELECT id FROM student_academic_history WHERE student_id = ? AND academic_status = 'Current' LIMIT 1", 's', $uid)) { $skipped++; continue; }
                $n = db_execute("UPDATE student_academic_history SET academic_status = 'Current', promotion_status = 'Studying', student_status = 'Active'
                                 WHERE student_id = ? AND session_id = ? AND class_id = ? AND academic_status = 'History' AND promotion_status = 'Promoted' AND student_status = 'Passed'",
                                 'sii', $uid, $session_id, $class_id);
                if (!$n) { $skipped++; continue; }
                db_execute("UPDATE students SET student_status = 'Active' WHERE id = ? AND student_status = 'Passed'", 's', $uid);
                log_action($admin_id, 'STUDENT_PASS_OUT_UNDONE', 'students', $uid, null, ['session_id' => $session_id, 'class_id' => $class_id]);
            }
            $done++;
        }
        db_commit();
        $_SESSION['success'] = $undo ? "$done student(s) are Active in this class again." : "$done student(s) passed out.";
        if ($skipped) $_SESSION['success'] .= " $skipped skipped — " . ($undo ? 'already in a newer class, or not passed out here.' : 'not in this class any more.');
    } catch (Throwable $e) {
        db_rollback();
        error_log('pass out: ' . $e->getMessage());
        $_SESSION['error'] = 'Nothing was changed — please try again.';
    }
    header("Location: $back"); exit();
}

$students = $passed = []; $has_merit = false;
if ($class_id) {
    $students = db_get_all("SELECT s.id, s.student_name, s.admission_no, h.roll_no, sec.section_name, r.result_status, r.percentage
        FROM student_academic_history h JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN student_merit_ranks r ON r.student_id = h.student_id AND r.academic_session_id = h.session_id AND r.class_id = h.class_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.academic_status = 'Current'
        ORDER BY sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name", 'ii', $session_id, $class_id);
    $has_merit = (bool)array_filter(array_column($students, 'result_status'));
    $passed = db_get_all("SELECT s.id, s.student_name, s.admission_no, h.roll_no, sec.section_name
        FROM student_academic_history h JOIN students s ON s.id = h.student_id LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.academic_status = 'History' AND h.promotion_status = 'Promoted' AND h.student_status = 'Passed'
        ORDER BY s.student_name", 'ii', $session_id, $class_id);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pass Out Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
<style>
    .pick-row { display: flex; flex-wrap: wrap; gap: 14px; }
    .pick-row .form-group { flex: 1; min-width: 180px; margin: 0; }
    .pick-row select { width: 100%; padding: 9px 10px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; }
    .po-table { width: 100%; border-collapse: collapse; background: #fff; font-size: 13px; }
    .po-table th, .po-table td { border: 1px solid #e4edf6; padding: 7px 10px; text-align: left; }
    .po-table th { background: #003366; color: #fff; font-weight: 600; }
    .res-PASS { color: #2e7d32; font-weight: 700; } .res-FAIL, .res-ABSENT { color: #c62828; font-weight: 700; } .res-PUC, .res-COMPARTMENT { color: #e65100; font-weight: 700; }
    .confirm-bar { margin-top: 14px; padding: 12px 16px; background: #e8f4ff; border: 1px solid #c9e3ff; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; font-size: 13px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-graduation-cap"></i> Pass Out Students</div>
        <a href="promotion.php?<?php echo $h(http_build_query(['from_session_id' => $session_id])); ?>" class="btn btn-primary"><i class="fas fa-level-up-alt"></i> Promotion</a>
    </div>
    <p style="font-size:12.5px; color:#4d6178; margin:0 0 12px">For Class X after Madhyamik and Class XII after Higher Secondary — the classes that do not go up by promotion. Ticked students are closed as <b>Passed</b>. Own Class X students who continue come into Class XI through a new admission form, with the same School UID.</p>
    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $k => $icon): if (isset($_SESSION[$k])): ?>
    <div class="alert alert-<?php echo $k === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <form method="get" class="form-card" style="margin-bottom:14px">
        <div class="pick-row">
            <div class="form-group"><label>Session</label>
                <select name="session_id" onchange="this.form.submit()">
                    <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"<?php echo (int)$s['id'] === $session_id ? ' selected' : ''; ?>><?php echo $h($s['session_name'] . ($s['status'] === 'Active' ? ' (Active)' : '')); ?></option><?php endforeach; ?>
                </select></div>
            <div class="form-group"><label>Class</label>
                <select name="class_id" onchange="this.form.submit()">
                    <option value="">Select class</option>
                    <?php foreach ($terminal as $id => $c): ?><option value="<?php echo $id; ?>"<?php echo $id === $class_id ? ' selected' : ''; ?>>Class <?php echo $h($c['name']); ?></option><?php endforeach; ?>
                </select></div>
        </div>
    </form>

    <?php if ($class_id && !$students): ?>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> No active students of Class <?php echo $h($terminal[$class_id]['name']); ?> in <?php echo $h($names[$session_id]); ?>.</div>
    <?php elseif ($students): ?>
    <form method="post" onsubmit="return confirm('Pass out the ticked students? Their class record is closed as Passed.');">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <div class="table-responsive">
        <table class="po-table">
            <thead><tr><th><input type="checkbox" onclick="document.querySelectorAll('.po-check').forEach(c => c.checked = this.checked)" title="All"></th><th>Student</th><th>Admission No</th><th>Section</th><th>Roll</th><?php if ($has_merit): ?><th>Result</th><th>%</th><?php endif; ?></tr></thead>
            <tbody>
            <?php foreach ($students as $st): $res = (string)$st['result_status']; ?>
                <tr>
                    <td><input type="checkbox" class="po-check" name="student_id[]" value="<?php echo $h($st['id']); ?>"<?php echo in_array($res, ['FAIL', 'ABSENT'], true) ? '' : ' checked'; ?>></td>
                    <td><b><?php echo $h($st['student_name']); ?></b> <small style="color:#8a98a8"><?php echo $h($st['id']); ?></small></td>
                    <td><?php echo $h($st['admission_no'] ?? '—'); ?></td>
                    <td><?php echo $h($st['section_name'] ?? '—'); ?></td>
                    <td><?php echo $h($st['roll_no'] ?? '—'); ?></td>
                    <?php if ($has_merit): ?><td class="res-<?php echo $h($res); ?>"><?php echo $h($res !== '' ? $res : '—'); ?></td><td><?php echo $st['percentage'] !== null ? $h($st['percentage']) : '—'; ?></td><?php endif; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="confirm-bar">
            <span><i class="fas fa-info-circle"></i> Only ticked students pass out.<?php echo $has_merit ? ' FAIL and ABSENT start unticked — keep them in the class from Not Promoted.' : ''; ?></span>
            <button type="submit" class="btn btn-success"><i class="fas fa-graduation-cap"></i> Pass Out ticked</button>
        </div>
    </form>
    <?php endif; ?>

    <?php if ($passed): ?>
    <h3 style="color:#6c7a8a; font-size:15px; margin:26px 0 8px"><i class="fas fa-undo"></i> Already passed out (<?php echo count($passed); ?>)</h3>
    <form method="post" onsubmit="return confirm('Undo Pass Out for the ticked students? They become Active in this class again.');">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>">
        <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
        <input type="hidden" name="undo_pass_out" value="1">
        <div class="table-responsive">
        <table class="po-table">
            <thead><tr><th><input type="checkbox" onclick="document.querySelectorAll('.undo-check').forEach(c => c.checked = this.checked)" title="All"></th><th>Student</th><th>Admission No</th><th>Section</th><th>Roll</th></tr></thead>
            <tbody>
            <?php foreach ($passed as $st): ?>
                <tr><td><input type="checkbox" class="undo-check" name="undo_student_id[]" value="<?php echo $h($st['id']); ?>"></td><td><b><?php echo $h($st['student_name']); ?></b> <small style="color:#8a98a8"><?php echo $h($st['id']); ?></small></td><td><?php echo $h($st['admission_no'] ?? '—'); ?></td><td><?php echo $h($st['section_name'] ?? '—'); ?></td><td><?php echo $h($st['roll_no'] ?? '—'); ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <div class="confirm-bar">
            <span><i class="fas fa-info-circle"></i> A student already placed in a newer class (Class XI after X, say) is not taken back.</span>
            <button type="submit" class="btn btn-warning"><i class="fas fa-undo"></i> Undo ticked</button>
        </div>
    </form>
    <?php endif; ?>
</div>
</body>
</html>

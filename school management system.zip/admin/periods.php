<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/routine_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * The periods are the columns of every routine: one list for Monday to Saturday, and Saturday uses the
 * first few (Routine Settings). A period anything still points at — routine, provisional routine, a closed
 * period, a teacher's blocked slot — is locked, since deleting it would take those rows with it.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);

function period_clean(array $in, int $exclude_id = 0): array {
    $name = trim((string)($in['period_name'] ?? '')); $st = trim((string)($in['start_time'] ?? '')); $en = trim((string)($in['end_time'] ?? '')); $ord = (int)($in['sort_order'] ?? 0);
    if ($name === '' || mb_strlen($name) > 20) return ['error' => 'Period name is required (up to 20 characters).'];
    foreach ([$st, $en] as $t) if ($t !== '' && !preg_match('/^\d{2}:\d{2}$/', $t)) return ['error' => 'Time must be HH:MM.'];
    if ($st !== '' && $en !== '' && $en <= $st) return ['error' => 'End time must be after the start time.'];
    if ($ord < 1 || $ord > 30) return ['error' => 'Order must be between 1 and 30.'];
    if (db_get_row('SELECT id FROM periods WHERE period_name = ? AND id <> ?', 'si', $name, $exclude_id)) return ['error' => 'A period named ' . $name . ' already exists.'];
    if (db_get_row('SELECT id FROM periods WHERE sort_order = ? AND id <> ?', 'ii', $ord, $exclude_id)) return ['error' => 'Another period already has order ' . $ord . '.'];
    if ($st !== '' && $en !== '') { $o = db_get_row('SELECT period_name FROM periods WHERE id <> ? AND start_time IS NOT NULL AND end_time IS NOT NULL AND start_time < ? AND end_time > ?', 'iss', $exclude_id, $en, $st); if ($o) return ['error' => 'Time overlaps with ' . $o['period_name'] . '.']; }
    return ['data' => ['period_name' => $name, 'start_time' => $st ?: null, 'end_time' => $en ?: null, 'sort_order' => $ord]];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (isset($_POST['add_period'])) {
        $r = period_clean($_POST);
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else { $id = db_insert('periods', $r['data']); log_action($admin_id, 'PERIOD_ADDED', 'periods', $id, null, $r['data']); $_SESSION['success'] = 'Period ' . $r['data']['period_name'] . ' added.'; }
    } elseif (isset($_POST['update_period'])) {
        $id = (int)($_POST['period_id'] ?? 0); $old = db_get_row('SELECT * FROM periods WHERE id = ?', 'i', $id);
        $r = $old ? period_clean($_POST, $id) : ['error' => 'Period not found.'];
        if (isset($r['error'])) $_SESSION['error'] = $r['error'];
        else { db_update('periods', $r['data'], ['id' => $id], 'i'); log_action($admin_id, 'PERIOD_UPDATED', 'periods', $id, $old, $r['data']); $_SESSION['success'] = 'Period ' . $r['data']['period_name'] . ' updated.'; }
    } elseif (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id']; $old = db_get_row('SELECT * FROM periods WHERE id = ?', 'i', $id);
        $deps = $old ? db_dependents('periods', $id) : [];
        if (!$old) $_SESSION['error'] = 'Period not found.';
        elseif ($deps) $_SESSION['error'] = $old['period_name'] . ' is still used in ' . db_dependents_text($deps) . ' — clear those first.';
        else { db_execute('DELETE FROM periods WHERE id = ?', 'i', $id); log_action($admin_id, 'PERIOD_DELETED', 'periods', $id, $old, null); $_SESSION['success'] = 'Period ' . $old['period_name'] . ' deleted.'; }
    }
    header('Location: periods.php'); exit();
}

$periods = db_get_all('SELECT p.*, (SELECT COUNT(*) FROM routine r WHERE r.period_id = p.id) AS used FROM periods p ORDER BY p.sort_order, p.id');
$in_use = db_referenced_ids('periods');
$s = routine_settings(); $sat = $s['saturday_periods'];
$edit_id = (int)($_GET['edit'] ?? 0); $edit = $edit_id ? db_get_row('SELECT * FROM periods WHERE id = ?', 'i', $edit_id) : null;
$next_order = $periods ? max(array_map(fn($p) => (int)$p['sort_order'], $periods)) + 1 : 1;
$next_start = ''; if ($periods) { $last = end($periods); if ($last['end_time']) $next_start = substr($last['end_time'], 0, 5); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Periods</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .two { display: grid; grid-template-columns: 1fr 330px; gap: 18px; align-items: start; } @media (max-width: 900px) { .two { grid-template-columns: 1fr; } }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 14px; padding: 16px 18px; } .card h2 { margin: 0 0 10px; font-size: 15px; color: #0b3d5c; }
    .pf label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin: 10px 0 4px; text-transform: uppercase; } .pf input { width: 100%; height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; } .pf .row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; } .pf .acts { margin-top: 14px; display: flex; gap: 8px; }
    .tl { display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 14px; } .tl span { padding: 6px 10px; border-radius: 8px; background: #eef6fc; border: 1px solid #b7d7ee; font-size: 12px; font-weight: 700; color: #0b3d5c; } .tl span small { display: block; font-weight: 400; color: #4d6178; font-size: 10.5px; } .tl span.sat { background: #fff6e5; border-color: #f0c987; color: #7a4a00; }
    .lc-table td.num { text-align: center; font-variant-numeric: tabular-nums; } .lc-table tr.editing td { background: #fff9ec; } .lc-table .btn { padding: 5px 10px; font-size: 12px; }
    .satbadge { display: inline-block; background: #fff6e5; color: #7a4a00; border: 1px solid #f0c987; border-radius: 999px; padding: 1px 8px; font-size: 10.5px; font-weight: 700; margin-left: 6px; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-clock"></i></div>
        <div><h1>Periods</h1><p>The columns of every routine. Saturday uses the first <?php echo $sat ?: 'none'; ?><?php echo $sat ? ' (set in Routine Settings)' : ' — no Saturday classes (Routine Settings)'; ?>.</p></div>
        <div class="links"><a href="routine_settings.php"><i class="fas fa-sliders-h"></i> Routine Settings</a><a href="routine_entry.php"><i class="fas fa-edit"></i> Routine Entry</a></div>
    </div>
    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <?php if ($periods): ?><div class="tl"><?php foreach ($periods as $i => $p): ?><span class="<?php echo $i < $sat ? 'sat' : ''; ?>" title="<?php echo $i < $sat ? 'also on Saturday' : 'Mon–Fri only'; ?>"><?php echo h($p['period_name']); ?><small><?php echo $p['start_time'] ? routine_time($p['start_time']) . '–' . routine_time($p['end_time']) : 'no time'; ?></small></span><?php endforeach; ?></div><?php endif; ?>

    <div class="two">
        <div class="card">
            <h2><i class="fas fa-list-ol"></i> <?php echo count($periods); ?> period<?php echo count($periods) === 1 ? '' : 's'; ?></h2>
            <?php if (!$periods): ?><div class="lc-empty"><i class="fas fa-clock"></i>No periods yet — add the first one on the right (e.g. P1 11:00–11:40).</div>
            <?php else: ?>
            <table class="lc-table"><thead><tr><th>#</th><th>Period</th><th>Start</th><th>End</th><th>Length</th><th>In routine</th><th></th></tr></thead><tbody>
            <?php foreach ($periods as $i => $p): ?>
            <tr class="<?php echo $edit && (int)$edit['id'] === (int)$p['id'] ? 'editing' : ''; ?>"><td class="num"><?php echo (int)$p['sort_order']; ?></td><td><b><?php echo h($p['period_name']); ?></b><?php if ($i < $sat) echo '<span class="satbadge">Sat</span>'; ?></td><td><?php echo h(routine_time($p['start_time'])); ?></td><td><?php echo h(routine_time($p['end_time'])); ?></td><td class="num"><?php echo $p['start_time'] && $p['end_time'] ? (int)((strtotime($p['end_time']) - strtotime($p['start_time'])) / 60) . ' min' : '—'; ?></td><td class="num"><?php echo (int)$p['used'] ?: '—'; ?></td>
                <td class="lc-actions"><a href="?edit=<?php echo (int)$p['id']; ?>#form" class="btn btn-secondary"><i class="fas fa-pen"></i></a>
                    <?php if (!isset($in_use[(int)$p['id']])): ?><form method="post" onsubmit="return confirm('Delete period <?php echo h($p['period_name']); ?>?');"><?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo (int)$p['id']; ?>"><button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button></form><?php else: ?><span class="btn btn-secondary" style="opacity:.45;cursor:not-allowed" title="In use (routine, provisional routine, closed periods or blocked slots) — cannot delete"><i class="fas fa-lock"></i></span><?php endif; ?></td></tr>
            <?php endforeach; ?></tbody></table>
            <?php endif; ?>
        </div>
        <div class="card" id="form">
            <h2><i class="fas <?php echo $edit ? 'fa-pen' : 'fa-plus'; ?>"></i> <?php echo $edit ? 'Edit ' . h($edit['period_name']) : 'Add period'; ?></h2>
            <form method="post" class="pf">
                <?php echo csrf_field(); ?>
                <?php if ($edit): ?><input type="hidden" name="period_id" value="<?php echo (int)$edit['id']; ?>"><?php endif; ?>
                <label>Name</label><input type="text" name="period_name" maxlength="20" required value="<?php echo h($edit['period_name'] ?? ('P' . $next_order)); ?>" placeholder="P1">
                <div class="row"><div><label>Start</label><input type="time" name="start_time" value="<?php echo h($edit ? substr((string)$edit['start_time'], 0, 5) : $next_start); ?>"></div><div><label>End</label><input type="time" name="end_time" value="<?php echo h($edit ? substr((string)$edit['end_time'], 0, 5) : ''); ?>"></div></div>
                <label>Order</label><input type="number" name="sort_order" min="1" max="30" required value="<?php echo (int)($edit['sort_order'] ?? $next_order); ?>">
                <div class="acts"><button type="submit" name="<?php echo $edit ? 'update_period' : 'add_period'; ?>" value="1" class="btn btn-primary"><i class="fas fa-save"></i> <?php echo $edit ? 'Save' : 'Add'; ?></button><?php if ($edit): ?><a href="periods.php" class="btn btn-secondary">Cancel</a><?php endif; ?></div>
            </form>
            <p style="color:#6b7d90;font-size:12px;margin:12px 0 0">Tiffin / assembly is not a period — leave the gap in the times. Times are optional but print on the routine.</p>
        </div>
    </div>
</div>
</body>
</html>

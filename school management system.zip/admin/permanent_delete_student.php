<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';

/**
 * Permanent delete — only from the Deleted list, only after the admin has typed
 * the student's School UID. Removes the four uploaded files and the students row;
 * the 22 foreign keys (ON DELETE CASCADE) take every dependent row with it.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: deleted_students.php'); exit(); }
verify_csrf_or_die();

$id = student_uid_clean($_POST['id'] ?? '');
$typed = strtoupper(trim((string)($_POST['confirm_uid'] ?? '')));
$student = $id !== '' ? db_get_row('SELECT * FROM students WHERE id = ?', 's', $id) : null;

if (!$student) { $_SESSION['error'] = 'Student not found.'; header('Location: deleted_students.php'); exit(); }
if ($student['student_status'] !== 'Deleted') { $_SESSION['error'] = 'Only a student on the Deleted list can be permanently deleted.'; header('Location: deleted_students.php'); exit(); }
if ($typed !== $id) { $_SESSION['error'] = "Type the School UID $id exactly to confirm. Nothing was deleted."; header('Location: deleted_students.php'); exit(); }

if (db_get_row('SELECT 1 FROM fee_receipts WHERE student_id = ? LIMIT 1', 's', $id)) {
    $_SESSION['error'] = "{$student['student_name']} has fee receipts. Money records are kept for the school's accounts, so this student cannot be deleted for good. Nothing was deleted.";
    header('Location: deleted_students.php');
    exit();
}
$deps = student_dependency_counts($id);
$files = student_files($student);
$guardian_id = (int)($student['guardian_id'] ?? 0);

db_begin_transaction();
try {
    db_execute("DELETE FROM library_issues WHERE borrower_type = 'Student' AND borrower_id = ?", 's', $id);   // no FK possible: borrower_id is shared with staff
    db_execute('DELETE FROM students WHERE id = ?', 's', $id);          // CASCADE clears the dependent tables
    // the family row goes too when no other student (a sibling) still uses it
    if ($guardian_id > 0 && !db_get_row('SELECT id FROM students WHERE guardian_id = ? LIMIT 1', 'i', $guardian_id)) {
        db_execute('DELETE FROM guardians WHERE guardian_id = ?', 'i', $guardian_id);
    }
    db_commit();
} catch (Throwable $e) {
    db_rollback();
    error_log('permanent delete failed for ' . $id . ': ' . $e->getMessage());
    $_SESSION['error'] = 'Could not delete — nothing was changed. (' . $e->getMessage() . ')';
    header('Location: deleted_students.php');
    exit();
}
foreach ($files as [$dir, $name]) app_unlink_upload($dir, $name);

$summary = $deps ? implode(', ', array_map(fn($t, $n) => "$t $n", array_keys($deps), $deps)) : 'no dependent rows';
log_action((int)($_SESSION['admin_id'] ?? 0), 'STUDENT_PERMANENT_DELETE', 'students', $id, null, "{$student['student_name']} ($id) removed permanently; $summary; " . count($files) . ' file(s)');
$_SESSION['success'] = "{$student['student_name']} ($id) permanently deleted — $summary, " . count($files) . ' file(s) removed.';
header('Location: deleted_students.php');
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';

/**
 * Photo booth — take every student's photo of one section, one after another.
 * ?session_id&class_id&section_id[&start=UID]. Full screen, no navbar; the work is
 * done by assets/js/photo_booth.js (camera → white background → 240×320 ≤ 10 KB → upload).
 */
$session_id = (int)($_GET['session_id'] ?? 0); $class_id = (int)($_GET['class_id'] ?? 0); $section_id = (int)($_GET['section_id'] ?? 0);
$start = student_uid_clean($_GET['start'] ?? '');
$students = ($session_id && $class_id && $section_id) ? db_get_all("
    SELECT s.id AS uid, s.student_name, s.photo, h.roll_no
    FROM students s JOIN student_academic_history h ON h.student_id = s.id AND h.session_id = ? AND h.academic_status = 'Current'
    WHERE s.student_status = 'Active' AND h.class_id = ? AND h.section_id = ?
    ORDER BY CAST(h.roll_no AS UNSIGNED), s.student_name", 'iii', $session_id, $class_id, $section_id) : [];
$label = db_get_row('SELECT c.class_name, sec.section_name FROM sections sec JOIN classes c ON c.id = sec.class_id WHERE sec.id = ?', 'i', $section_id);
$back = "student_bulk_update.php?session_id=$session_id&class_id=$class_id&section_id=$section_id";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<title>Photo Booth<?php echo $label ? ' — ' . htmlspecialchars($label['class_name'] . '-' . $label['section_name']) : ''; ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/bulk_grid.css">
<style> body { background: #0b1622; } .pb-intro { color: #cfe0f0; max-width: 520px; margin: 60px auto; text-align: center; font-family: "Segoe UI", Arial, sans-serif; } .pb-intro a { color: #fff; } </style>
</head>
<body>
<?php if (!$students): ?>
<div class="pb-intro"><i class="fas fa-camera" style="font-size:40px"></i><p>No active students in this section.</p><a href="<?php echo htmlspecialchars($back); ?>">← Back to Bulk Update</a></div>
<?php else: ?>
<script id="booth-data" type="application/json"><?php echo json_encode(['csrf' => csrf_token(), 'students' => $students, 'start' => $start, 'back' => $back, 'secure' => (!empty($_SERVER['HTTPS']) || in_array($_SERVER['SERVER_NAME'] ?? '', ['localhost', '127.0.0.1'], true))], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?></script>
<script type="module">
import PhotoBooth from '../assets/js/photo_booth.js';
const D = JSON.parse(document.getElementById('booth-data').textContent);
const booth = PhotoBooth.open({ csrf: D.csrf, students: D.students, onClose: () => { location.href = D.back; } });
if (D.start) booth.goto(D.start);
</script>
<?php endif; ?>
</body>
</html>

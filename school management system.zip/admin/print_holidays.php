<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/misc_helper.php';

// One calendar year, the same year the holiday list shows.
$school = db_get_row("SELECT * FROM school_settings WHERE id = 1") ?: [];
$years = holiday_years();
$year = (int)($_GET['year'] ?? 0);
if (!isset($years[$year])) $year = (int)date('Y');

$holidays_data = holidays_of_year($year);
$total_holidays = count($holidays_data);
$total_days_sum = 0;
foreach ($holidays_data as $row) $total_days_sum += holiday_working_days($row);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Holiday List <?php echo $year; ?> - <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    /* ===== PAGE SETUP FOR A4 PORTRAIT ===== */
    @page {
        size: A4 portrait;
        margin: 8mm 10mm 8mm 10mm;
    }
    
    /* ===== STANDARD OFFICIAL FONT ===== */
    body {
        font-family: 'Times New Roman', Times, serif;
        font-size: 11pt;
        color: #000;
        margin: 0;
        padding: 0;
        line-height: 1.3;
        background: #f4f4f4;
    }
    
    /* ===== SCREEN VIEW (A4 Preview) ===== */
    .page {
        background: #fff;
        width: 210mm;
        min-height: 297mm;
        padding: 8mm 10mm;
        margin: 15px auto;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    
    /* ===== HEADER SECTION (Logo Left, Info Right) ===== */
    .header {
        display: flex;
        align-items: center;
        gap: 12px;
        border-bottom: 2px solid #000;
        padding-bottom: 8px;
        margin-bottom: 12px;
    }
    
    .header .logo-box {
        flex-shrink: 0;
        width: 70px;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .header .logo-box img {
        max-width: 70px;
        max-height: 70px;
        object-fit: contain;
    }
    
    .header .logo-box .logo-placeholder {
        width: 60px;
        height: 60px;
        border: 2px solid #000;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        font-weight: bold;
        color: #000;
    }
    
    .header .school-info {
        flex: 1;
        text-align: center;
    }
    
    .header .school-info h1 {
        font-size: 18pt;
        margin: 0 0 3px 0;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: bold;
        line-height: 1.2;
    }
    
    .header .school-info p {
        font-size: 10pt;
        margin: 2px 0;
        line-height: 1.3;
    }
    
    /* ===== DOCUMENT TITLE ===== */
    .doc-title {
        text-align: center;
        font-size: 14pt;
        font-weight: bold;
        margin: 10px 0 8px;
        text-decoration: underline;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    /* ===== TABLE STYLES ===== */
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 5px;
    }
    
    th, td {
        border: 1px solid #000;
        padding: 4px 6px;
        vertical-align: middle;
        font-size: 10pt;
    }
    
    th {
        background-color: #e9ecef !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        font-weight: bold;
        text-align: center;
        font-size: 10pt;
    }
    
    .text-center { text-align: center; }
    .text-left { text-align: left; }
    .text-right { text-align: right; }
    
    /* ===== TOTAL ROW ===== */
    .total-row {
        background-color: #003366 !important;
        color: #fff !important;
        font-weight: bold;
        font-size: 11pt;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }
    
    .total-row td {
        border-color: #000;
        padding: 5px 6px;
    }
    
    /* ===== FOOTER / SIGNATURE ===== */
    .footer {
        margin-top: 40px;
        display: flex;
        justify-content: space-between;
        font-size: 10pt;
    }
    
    .signature-box {
        text-align: center;
        width: 180px;
    }
    
    .signature-line {
        border-top: 1px solid #000;
        margin-top: 40px;
        padding-top: 4px;
        font-weight: bold;
    }
    
    /* ===== PRINT BUTTON (Screen Only) ===== */
    .no-print {
        text-align: center;
        margin: 15px 0;
    }
    
    .btn {
        padding: 8px 18px;
        background: #003366;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        font-family: 'Segoe UI', Arial, sans-serif;
        font-size: 13px;
        border: none;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 0 4px;
    }
    
    .btn:hover { background: #004d99; }
    .btn-secondary { background: #6c757d; }
    
    /* ===== PRINT MEDIA ===== */
    @media print {
        body { background: #fff; }
        .no-print { display: none !important; }
        .page { 
            box-shadow: none; 
            margin: 0; 
            padding: 0; 
            width: 100%; 
            min-height: auto; 
        }
        th {
            background-color: #e9ecef !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .total-row {
            background-color: #003366 !important;
            color: #fff !important;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
    }
    
    @media (max-width: 768px) {
        .header { flex-direction: column; text-align: center; }
        .header .school-info { text-align: center; }
    }
</style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>

<!-- ===== PRINT BUTTON ===== -->
<div class="no-print">
    <button class="btn" onclick="window.print()"><i class="fas fa-print"></i> Print Holiday List</button>
    <a href="holidays.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<div class="page">
    <!-- ===== HEADER (Logo Left + School Info Right) ===== -->
    <div class="header">
        <div class="logo-box">
            <?php if(!empty($school['logo'])): ?>
                <img src="../uploads/<?php echo $school['logo']; ?>" alt="School Logo">
            <?php else: ?>
                <div class="logo-placeholder">
                    <i class="fas fa-school"></i>
                </div>
            <?php endif; ?>
        </div>
        <div class="school-info">
            <h1><?php echo htmlspecialchars($school['school_name'] ?? 'SCHOOL NAME'); ?></h1>
            <?php if(!empty($school['school_address'])): ?>
                <p><?php echo htmlspecialchars($school['school_address']); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
            <?php endif; ?>
            <p>
                <?php if(!empty($school['phone'])): ?>Phone: <?php echo htmlspecialchars($school['phone']); ?><?php endif; ?>
                <?php if(!empty($school['email'])): ?> | Email: <?php echo htmlspecialchars($school['email']); ?><?php endif; ?>
                <?php if(!empty($school['udise_code'])): ?> | UDISE: <?php echo htmlspecialchars($school['udise_code']); ?><?php endif; ?>
            </p>
        </div>
    </div>

    <!-- ===== DOCUMENT TITLE ===== -->
    <div class="doc-title">List of Holidays — <?php echo $year; ?></div>

    <!-- ===== HOLIDAY TABLE ===== -->
    <table>
        <thead>
            <tr>
                <th style="width: 5%;">SL</th>
                <th style="width: 30%;">Holiday Name</th>
                <th style="width: 22%;">Date / Period</th>
                <th style="width: 13%;">Day</th>
                <th style="width: 12%;">Type</th>
                <th style="width: 18%;">Working days</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($holidays_data) > 0): ?>
                <?php 
                $sl = 1;
                foreach($holidays_data as $row): 
                    // Handle Date Display for Long Vacation
                    [$from, $to] = holiday_span($row);
                    if (!$from || !$to) { $date_display = '—'; $day_display = '—'; }
                    elseif ($from !== $to) {
                        $date_display = date('d-m-Y', strtotime($from)) . ' to ' . date('d-m-Y', strtotime($to));
                        $day_display = date('l', strtotime($from)) . ' - ' . date('l', strtotime($to));
                    } else {
                        $date_display = date('d-m-Y', strtotime($from));
                        $day_display = date('l', strtotime($from));
                    }

                    $days_count = holiday_working_days($row);
                    $type = ucfirst($row['holiday_type']);
                ?>
                <tr>
                    <td class="text-center"><?php echo $sl++; ?></td>
                    <td class="text-left"><strong><?php echo htmlspecialchars($row['holiday_name']); ?></strong></td>
                    <td class="text-center"><?php echo $date_display; ?></td>
                    <td class="text-center"><?php echo $day_display; ?></td>
                    <td class="text-center"><?php echo $type; ?></td>
                    <td class="text-center"><strong><?php echo $days_count; ?></strong></td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center" style="padding:15px;">No holidays found.</td>
                </tr>
            <?php endif; ?>
            
            <!-- ===== TOTAL ROW ===== -->
            <tr class="total-row">
                <td colspan="5" class="text-right" style="padding-right:10px;">WORKING DAYS LOST IN <?php echo $year; ?>:</td>
                <td class="text-center"><strong><?php echo $total_days_sum; ?> Days</strong></td>
            </tr>
        </tbody>
    </table>

    <!-- ===== SIGNATURE FOOTER ===== -->
    <div class="footer">
        <div class="signature-box">
            <div class="signature-line">
                Date
            </div>
        </div>
        <div class="signature-box">
            <div class="signature-line">
                <?php echo !empty($school['hoi_name']) ? htmlspecialchars($school['hoi_name']) : 'Head of Institution'; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>
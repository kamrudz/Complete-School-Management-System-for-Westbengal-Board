<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/promotion_helper.php';

/**
 * Promotion, step by step: the class and the new session, the sections on both sides, and the rule the new
 * sections and rolls are given by. The class always goes to the next class; the preview shows every student's
 * new section and roll before anything is saved. Section by Section is set up here one section at a time: its
 * steps travel in the address, so Back and Refresh keep them, and the class is still saved in one go.
 */
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$classes = class_rows();
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions');
usort($sessions, fn($a, $b) => strnatcmp($b['session_name'], $a['session_name']));   // newest first
$names = array_column($sessions, 'session_name', 'id');
$active = 0;
foreach ($sessions as $s) if ($s['status'] === 'Active') $active = (int)$s['id'];

$from_session_id = (int)($_GET['from_session_id'] ?? 0); if (!isset($names[$from_session_id])) $from_session_id = $active;
$later = array_reverse(array_values(array_filter($sessions, fn($s) => $from_session_id && promotion_session_later($from_session_id, (int)$s['id']))));
$to_session_id = (int)($_GET['to_session_id'] ?? 0);
if (!in_array($to_session_id, array_map('intval', array_column($later, 'id')), true)) $to_session_id = (int)($later[0]['id'] ?? 0);
$from_class_id = (int)($_GET['from_class_id'] ?? 0); if (!isset($classes[$from_class_id])) $from_class_id = 0;
$to_class_id = $from_class_id ? (int)promotion_next_class($from_class_id) : 0;
$method = (string)($_GET['promotion_method'] ?? ''); if (!isset(PROMOTION_METHODS[$method])) $method = '';

// what stops the class from going up now: [message, link, link text]
$stop = null; $pool = null; $to_sections = [];
if ($from_class_id) {
    $cls = 'Class ' . $classes[$from_class_id]['name'];
    $qs = http_build_query(['session_id' => $from_session_id, 'class_id' => $from_class_id]);
    $batch = db_get_row('SELECT id, total_students FROM promotion_batches WHERE from_session_id = ? AND from_class_id = ?', 'ii', $from_session_id, $from_class_id);
    if (!$to_class_id) $stop = [promotion_no_next_reason($from_class_id), "pass_out_students.php?$qs", 'Pass Out'];
    elseif ($batch) $stop = ["$cls of {$names[$from_session_id]} has already gone up ({$batch['total_students']} students).", "promotion_history.php?batch_id={$batch['id']}", 'See that promotion'];
    elseif (!$to_session_id) $stop = ["There is no session after {$names[$from_session_id]} yet — add it first.", 'add_session.php', 'Add Session'];
    elseif (!promotion_get_merit_count($conn, $from_session_id, $from_class_id)) $stop = ["The merit list of $cls for {$names[$from_session_id]} has not been made yet — generate it first.", "student_merit_ranks.php?$qs" . ($classes[$from_class_id]['stage'] === 'higher_secondary' ? '&section=hs' : ''), 'Merit List'];
    elseif (!($to_sections = promotion_get_sections($conn, $to_class_id, $to_session_id))) $stop = ['Class ' . $classes[$to_class_id]['name'] . " has no sections in {$names[$to_session_id]} yet — copy them from {$names[$from_session_id]} first.", 'copy_sections.php', 'Copy Sections'];
    else {
        $pool = promotion_students($from_session_id, $from_class_id);
        $not_promoted = 'fail_students.php?' . http_build_query(['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id]);
        if (!$pool['eligible']) { $stop = ["No student of $cls passed in {$names[$from_session_id]} — there is nobody to promote.", $not_promoted, 'Not Promoted']; $pool = null; }
    }
}

if ($pool) {
    $to_name = 'Class ' . $classes[$to_class_id]['name'];
    $gender_of = fn(array $st) => in_array($st['gender'], ['Male', 'Female'], true) ? $st['gender'] : 'Other';
    $count = ['Male' => 0, 'Female' => 0, 'Other' => 0];
    $rows = [];   // section letter => ['name', 'going' => [gender => n], 'new' => bool]: this year's sections beside the new ones
    foreach ($pool['eligible'] as $st) {
        $g = $gender_of($st); $count[$g]++;
        $k = strtoupper(trim($st['section']));
        $rows[$k]['name'] = $st['section'] !== '' ? $st['section'] : '(no section)';
        $rows[$k]['going'][$g] = ($rows[$k]['going'][$g] ?? 0) + 1;
    }
    foreach ($to_sections as $sec) {
        $k = strtoupper(trim($sec['section_name']));
        $rows[$k]['name'] = $rows[$k]['name'] ?? $sec['section_name'];
        $rows[$k]['new'] = true;
    }
    uksort($rows, 'strnatcasecmp');
    $missing = array_filter($rows, fn($r) => !empty($r['going']) && empty($r['new']));
    $people = fn(array $g) => implode(', ', array_filter([
        !empty($g['Male']) ? $g['Male'] . ' boys' : '', !empty($g['Female']) ? $g['Female'] . ' girls' : '', !empty($g['Other']) ? $g['Other'] . ' other / not set' : '']));

    // which new section is for boys and which for girls: as the next class was split this year, else this class
    $split = promotion_section_genders($to_class_id, $from_session_id) + promotion_section_genders($from_class_id, $from_session_id);
    $default_method = $classes[$from_class_id]['stage'] === 'higher_secondary' ? 'keep_existing' : '';   // XI → XII: the sections are streams
    $chosen = $method !== '' ? $method : $default_method;

    // Section by Section: steps[] are the steps added so far, next[] the one being set up — the list below shows
    // whom it would take before it is added. After a step: the same who and order, the first section no step has
    // used yet, and one gap less (2 → 1 → continue is A → C → E round again).
    $to_names = array_column($to_sections, 'section_name', 'id');
    $steps = promotion_steps_clean($_GET['steps'] ?? [], $to_names);
    $next_for = function (array $steps) use ($to_names): array {
        $last = $steps ? end($steps) : null;
        $free = array_values(array_diff(array_keys($to_names), array_column($steps, 'section')));
        return ['who' => $last['who'] ?? 'all', 'order' => $last['order'] ?? 'merit', 'section' => $free[0] ?? array_key_first($to_names), 'start' => null, 'gap' => $last ? max(0, $last['gap'] - 1) : 0];
    };
    $next = promotion_step_clean($_GET['next'] ?? null, $to_names) ?? $next_for($steps);
    $here = ['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id, 'promotion_method' => 'section_steps'];
    $builder_url = fn(array $steps, ?array $next = null) => 'promotion.php?' . http_build_query($here + ['steps' => $steps, 'next' => $next ?? $next_for($steps)]) . '#builder';
    if (isset($_GET['add'])) { header('Location: ' . $builder_url(array_merge($steps, [$next]))); exit(); }

    $plan = promotion_plan($from_session_id, $from_class_id, $to_session_id, $to_class_id, 'section_steps', [], [], $steps);
    $trial = promotion_plan($from_session_id, $from_class_id, $to_session_id, $to_class_id, 'section_steps', [], [], array_merge($steps, [$next]));
    $taking = array_filter($trial['students'], fn($st) => $st['step'] === count($steps) + 1);   // whom the next step would take
    $waiting = array_filter($plan['students'], fn($st) => $st['new_section'] === null);
    $line = array_filter($waiting, fn($st) => promotion_step_takes($next['who'], $st['gender']));
    promotion_sort_step($line, $next['order']);
    $left = ['Male' => 0, 'Female' => 0, 'Other' => 0];
    foreach ($waiting as $st) $left[$gender_of($st)]++;
    $by_step = []; $by_section = [];   // rolls given by each step; who each new section has so far
    foreach ($plan['students'] as $st) {
        if ($st['new_section'] === null) continue;
        $by_step[$st['step']][] = (int)$st['new_roll'];
        $by_section[$st['new_section']][$gender_of($st)] = ($by_section[$st['new_section']][$gender_of($st)] ?? 0) + 1;
        $by_section[$st['new_section']]['rolls'][] = (int)$st['new_roll'];
    }
    $nth = fn(int $n) => $n . (in_array($n % 100, [11, 12, 13], true) ? 'th' : (['th', 'st', 'nd', 'rd'][$n % 10] ?? 'th'));
    $rolls = fn(array $r) => $r ? (min($r) === max($r) ? 'roll ' . min($r) : 'rolls ' . min($r) . '–' . max($r)) : '';
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Promote Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
<style>
    .step-no { width: 24px; height: 24px; border-radius: 50%; background: var(--primary); color: #fff; display: inline-flex; align-items: center; justify-content: center; font-size: 12px; flex: none; }
    .pick { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; }
    .pick label { display: block; font-weight: 600; font-size: 13px; color: #1a3b55; margin-bottom: 5px; }
    .pick select, .pick input, .pick .fixed { width: 100%; padding: 9px 10px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; background: #fff; box-sizing: border-box; }
    .pick .fixed { background: #eef3f8; color: #003366; font-weight: 600; }
    .pick .fixed.none { color: #8a98a8; font-weight: 500; }
    .sec-table { width: 100%; border-collapse: collapse; font-size: 13px; background: #fff; }
    .sec-table th, .sec-table td { border: 1px solid #e4edf6; padding: 7px 10px; text-align: left; }
    .sec-table th { background: #003366; color: #fff; font-weight: 600; }
    .sec-table tfoot td { background: #f3f8ff; font-weight: 700; color: #1a3b55; }
    .ok { color: #1b7a3a; font-weight: 600; } .miss { color: #c62828; font-weight: 600; } .dim { color: #8a98a8; }
    .rules { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; margin-bottom: 14px; }
    .rule { display: block; border: 2px solid #e4edf6; border-radius: 10px; padding: 12px 14px; cursor: pointer; background: #fff; }
    .rule:has(input:checked) { border-color: #1565c0; background: #f3f8ff; }
    .rule b { color: #003366; font-size: 14px; }
    .rule p { margin: 6px 0 0; font-size: 12.5px; color: #5b6b7c; line-height: 1.5; }
    .group-title { font-weight: 700; font-size: 13px; margin-top: 4px; }
    .chips { display: flex; flex-wrap: wrap; gap: 8px; margin: 6px 0 12px; }
    .chip { display: inline-flex; align-items: center; gap: 6px; background: #f0f4f8; border: 1px solid #dde6ee; border-radius: 20px; padding: 5px 12px; font-size: 13px; cursor: pointer; }
    .chip:has(input:checked) { background: #e3efff; border-color: #90b8f0; }
    .chip small { color: #8a98a8; font-size: 10.5px; }
    .rotation { font-size: 12.5px; color: #1a3b55; background: #f7fafd; border: 1px dashed #c9dcee; border-radius: 8px; padding: 8px 12px; margin: 0 0 8px; line-height: 1.7; white-space: pre-line; }
    .hint { font-size: 12px; color: #6c7a8a; margin: 8px 0 0; }
    .hidden { display: none; }
    #stepsPick .sec-table { margin-bottom: 10px; }
    .sec-table tr.take td { background: #e3efff; font-weight: 600; }
    .new-secs { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 10px; margin: 10px 0 16px; }
    .new-sec { background: #fff; border: 1px solid #e4edf6; border-left: 4px solid #1565c0; border-radius: 8px; padding: 7px 11px; font-size: 12px; color: #5b6b7c; }
    .new-sec b { display: block; color: #003366; font-size: 14px; }
    .new-sec.empty { border-left-color: #cfd8e3; }
    .next-step { background: #f7fafd; border: 1px solid #dde6ee; border-radius: 10px; padding: 12px 14px; margin-bottom: 12px; }
    .next-step .group-title { margin-bottom: 8px; }
    .next-step .hint { font-size: 13px; color: #1a3b55; margin: 10px 0; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-level-up-alt"></i> Promote Students</div>
        <a href="promotion_history.php" class="btn btn-primary"><i class="fas fa-history"></i> Promotion History</a>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <form method="get" class="form-card">
        <h4><span class="step-no">1</span> Class</h4>
        <div class="pick">
            <div><label>From session</label>
                <select name="from_session_id" onchange="this.form.to_session_id.value='';this.form.submit()">
                    <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>"<?php echo (int)$s['id'] === $from_session_id ? ' selected' : ''; ?>><?php echo $h($s['session_name'] . ($s['status'] === 'Active' ? ' (Active)' : '')); ?></option><?php endforeach; ?>
                </select></div>
            <div><label>From class</label>
                <select name="from_class_id" onchange="this.form.submit()">
                    <option value="">Select class</option>
                    <?php foreach ($classes as $id => $c): ?><option value="<?php echo $id; ?>"<?php echo $id === $from_class_id ? ' selected' : ''; ?>>Class <?php echo $h($c['name']); ?></option><?php endforeach; ?>
                </select></div>
            <div><label>To session</label>
                <select name="to_session_id" onchange="this.form.submit()">
                    <?php if (!$later): ?><option value="">— no later session yet —</option><?php endif; ?>
                    <?php foreach ($later as $s): ?><option value="<?php echo (int)$s['id']; ?>"<?php echo (int)$s['id'] === $to_session_id ? ' selected' : ''; ?>><?php echo $h($s['session_name']); ?></option><?php endforeach; ?>
                </select></div>
            <div><label>To class</label>
                <?php if ($to_class_id): ?><div class="fixed">Class <?php echo $h($classes[$to_class_id]['name']); ?></div>
                <?php else: ?><div class="fixed none"><?php echo $from_class_id ? 'Pass Out' : 'the next class'; ?></div><?php endif; ?>
            </div>
        </div>
        <noscript><button type="submit" class="btn btn-primary btn-sm" style="margin-top:12px">Show</button></noscript>
    </form>

    <?php if ($stop): ?>
    <div class="alert alert-warning"><i class="fas fa-info-circle"></i> <span><?php echo $h($stop[0]); ?></span> <a href="<?php echo $h($stop[1]); ?>" class="btn btn-sm btn-primary"><?php echo $h($stop[2]); ?></a></div>
    <?php endif; ?>

    <?php if ($pool): ?>
    <div class="form-card">
        <h4><span class="step-no">2</span> Sections</h4>
        <div class="table-responsive">
        <table class="sec-table">
            <thead><tr><th>Section</th><th>Class <?php echo $h($classes[$from_class_id]['name']); ?> · <?php echo $h($names[$from_session_id]); ?> — going up</th><th><?php echo $h($to_name); ?> · <?php echo $h($names[$to_session_id]); ?></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><b><?php echo $h($r['name']); ?></b></td>
                    <td><?php echo !empty($r['going']) ? $h($people($r['going'])) : '<span class="dim">—</span>'; ?></td>
                    <td><?php echo !empty($r['new']) ? '<span class="ok"><i class="fas fa-check"></i> ready</span>' : '<span class="miss"><i class="fas fa-times"></i> not in ' . $h($names[$to_session_id]) . '</span>'; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr><td>Total</td><td><?php echo count($pool['eligible']); ?> — <?php echo $h($people($count)); ?></td><td><?php echo count($to_sections); ?> sections</td></tr></tfoot>
        </table>
        </div>
        <?php if ($missing): ?><p class="hint"><span class="miss">Same Section &amp; Roll</span> needs section <?php echo $h(implode(', ', array_column($missing, 'name'))); ?> in <?php echo $h($to_name); ?> of <?php echo $h($names[$to_session_id]); ?> — add it in <a href="sections.php">Sections</a>, or use By Merit.</p><?php endif; ?>
        <?php if ($pool['left']): ?><p class="hint">Not going up: <b><?php echo count($pool['left']); ?></b> (failed, absent or not on the merit list) — they wait on <a href="<?php echo $h($not_promoted); ?>">Not Promoted</a>.</p><?php endif; ?>
    </div>

    <form method="get" action="promotion_preview.php" class="form-card" id="ruleForm">
        <input type="hidden" name="from_session_id" value="<?php echo $from_session_id; ?>">
        <input type="hidden" name="from_class_id" value="<?php echo $from_class_id; ?>">
        <input type="hidden" name="to_session_id" value="<?php echo $to_session_id; ?>">
        <h4><span class="step-no">3</span> Promotion rule</h4>
        <div class="rules">
            <?php foreach (PROMOTION_METHODS as $key => [$label, $about]): ?>
            <label class="rule"><input type="radio" name="promotion_method" value="<?php echo $h($key); ?>" required<?php echo $key === $chosen ? ' checked' : ''; ?>> <b><?php echo $h($label); ?></b><p><?php echo $h($about); ?></p></label>
            <?php endforeach; ?>
        </div>

        <div id="meritPick" class="hidden">
            <?php foreach (['boys' => ['Boys\' sections', '#1565c0', ['Boys', 'Co-ed']], 'girls' => ['Girls\' sections', '#c2185b', ['Girls', 'Co-ed']]] as $group => [$title, $colour, $types]): ?>
            <div class="group-title" style="color:<?php echo $colour; ?>"><?php echo $title; ?> of <?php echo $h($to_name); ?></div>
            <div class="chips">
                <?php foreach ($to_sections as $sec): $type = $split[strtoupper(trim($sec['section_name']))] ?? ''; ?>
                <label class="chip"><input type="checkbox" name="<?php echo $group; ?>_sections[]" value="<?php echo (int)$sec['id']; ?>" data-group="<?php echo $group; ?>" data-name="<?php echo $h($sec['section_name']); ?>"<?php echo in_array($type, $types, true) ? ' checked' : ''; ?>> <?php echo $h($sec['section_name']); ?><?php if ($type !== ''): ?> <small><?php echo $h(strtolower($type === 'Co-ed' ? 'both' : $type)); ?></small><?php endif; ?></label>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
            <div class="rotation" id="boysLine" data-count="<?php echo $count['Male']; ?>"></div>
            <div class="rotation" id="girlsLine" data-count="<?php echo $count['Female']; ?>"></div>
            <p class="hint">Ticked as the sections of <?php echo $h($to_name); ?> were split this year. A section ticked in both lists takes boys and girls. If a section already has students in <?php echo $h($names[$to_session_id]); ?>, its new rolls follow theirs.<?php if ($count['Other']): ?> <span class="miss"><?php echo $count['Other']; ?> student(s) have gender Other or not set</span> — they fit neither list; set the gender in Edit Student, or use Same Section &amp; Roll.<?php endif; ?></p>
        </div>

        <div id="stepsPick"<?php echo $chosen === 'section_steps' ? '' : ' class="hidden"'; ?>>
            <a id="builder"></a>
            <?php foreach ($steps as $i => $s) foreach (array_filter($s, fn($v) => $v !== null) as $k => $v) echo '<input type="hidden" name="steps[' . $i . '][' . $k . ']" value="' . $h($v) . '">'; ?>
            <?php if ($steps): ?>
            <div class="group-title">Steps added</div>
            <div class="table-responsive">
            <table class="sec-table">
                <thead><tr><th>Step</th><th>Who</th><th>Order</th><th>Section</th><th>First roll</th><th>Gap</th><th>Placed</th></tr></thead>
                <tbody>
                <?php foreach ($steps as $i => $s): $got = $by_step[$i + 1] ?? []; ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo $h(PROMOTION_STEP_WHO[$s['who']]); ?></td>
                    <td><?php echo $h(PROMOTION_STEP_ORDERS[$s['order']]); ?></td>
                    <td><b><?php echo $h($classes[$to_class_id]['name'] . '-' . $to_names[$s['section']]); ?></b></td>
                    <td><?php echo $s['start'] ?? '<span class="dim">next free</span>'; ?></td>
                    <td><?php echo $h(PROMOTION_STEP_GAPS[$s['gap']]); ?></td>
                    <td><?php echo $got ? count($got) . ' · ' . $rolls($got) : '<span class="miss">nobody</span>'; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <p class="hint"><a href="<?php echo $h($builder_url(array_slice($steps, 0, -1), end($steps))); ?>"><i class="fas fa-undo"></i> Undo step <?php echo count($steps); ?></a> &nbsp;·&nbsp; <a href="<?php echo $h($builder_url([])); ?>">Start again</a></p>
            <div class="new-secs">
                <?php foreach ($to_names as $id => $name): $p = $by_section[$id] ?? []; ?>
                <div class="new-sec<?php echo $p ? '' : ' empty'; ?>"><b><?php echo $h($classes[$to_class_id]['name'] . '-' . $name); ?></b><?php echo $p ? $h($people($p)) . '<br>' . $rolls($p['rolls']) : 'nobody yet'; ?></div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($waiting): ?>
            <div class="next-step">
                <div class="group-title">Step <?php echo count($steps) + 1; ?> — not placed yet: <?php echo count($waiting); ?> (<?php echo $h($people($left)); ?>)</div>
                <div class="pick">
                    <div><label>Who</label><select name="next[who]" class="refresh"><?php foreach (PROMOTION_STEP_WHO as $k => $l): ?><option value="<?php echo $k; ?>"<?php echo $k === $next['who'] ? ' selected' : ''; ?>><?php echo $h($l); ?></option><?php endforeach; ?></select></div>
                    <div><label>Order</label><select name="next[order]" class="refresh"><?php foreach (PROMOTION_STEP_ORDERS as $k => $l): ?><option value="<?php echo $k; ?>"<?php echo $k === $next['order'] ? ' selected' : ''; ?>><?php echo $h($l); ?></option><?php endforeach; ?></select></div>
                    <div><label>Section of <?php echo $h($to_name); ?></label><select name="next[section]" class="refresh"><?php foreach ($to_names as $id => $name): ?><option value="<?php echo (int)$id; ?>"<?php echo $id === $next['section'] ? ' selected' : ''; ?>><?php echo $h($name); ?></option><?php endforeach; ?></select></div>
                    <div><label>First roll</label><input type="number" name="next[start]" min="1" value="<?php echo $h($next['start'] ?? ''); ?>" placeholder="next free" class="refresh"></div>
                    <div><label>Gap</label><select name="next[gap]" class="refresh"><?php foreach (PROMOTION_STEP_GAPS as $k => $l): ?><option value="<?php echo $k; ?>"<?php echo $k === $next['gap'] ? ' selected' : ''; ?>><?php echo $h($l); ?></option><?php endforeach; ?></select></div>
                </div>
                <p class="hint">
                <?php if ($taking): $g = $next['gap'] + 1; ?>
                    Takes <b><?php echo count($taking); ?></b> of the <?php echo count($line); ?> below — <?php echo $next['gap'] ? 'the ' . $nth(1) . ', ' . $nth(1 + $g) . ', ' . $nth(1 + 2 * $g) . ' …' : 'all of them, in this order'; ?> — into <b><?php echo $h($classes[$to_class_id]['name'] . '-' . $to_names[$next['section']]); ?></b> as <?php echo $rolls(array_map(fn($st) => (int)$st['new_roll'], $taking)); ?>.
                <?php else: ?>
                    <span class="miss">Nobody is left for this step</span> — choose other students.
                <?php endif; ?>
                </p>
                <button type="submit" name="add" value="1" formaction="promotion.php#builder" class="btn btn-primary btn-sm"<?php echo $taking ? '' : ' disabled'; ?>><i class="fas fa-plus"></i> Add step <?php echo count($steps) + 1; ?></button>
            </div>
            <?php if ($line): ?>
            <div class="table-responsive">
            <table class="sec-table">
                <thead><tr><th>#</th><th>Merit</th><th>Student</th><th>School UID</th><th>Gender</th><th>Now (Section · Roll)</th><th>PEN ID</th><th>Banglar Shiksha ID</th><th>Step <?php echo count($steps) + 1; ?></th></tr></thead>
                <tbody>
                <?php $n = 0; foreach ($line as $uid => $st): $t = $taking[$uid] ?? null; ?>
                <tr<?php echo $t ? ' class="take"' : ''; ?>>
                    <td><?php echo ++$n; ?></td>
                    <td><?php echo $st['rank'] ?: '—'; ?></td>
                    <td><?php echo $h($st['name']); ?></td>
                    <td><?php echo $h($uid); ?></td>
                    <td><?php echo $h($st['gender'] !== '' ? $st['gender'] : '—'); ?></td>
                    <td><?php echo $h(($st['section'] !== '' ? $st['section'] : '—') . ' · ' . ($st['roll'] ?? '—')); ?></td>
                    <td><?php echo $h($st['pen'] !== '' ? $st['pen'] : '—'); ?></td>
                    <td><?php echo $h($st['bsid'] !== '' ? $st['bsid'] : '—'); ?></td>
                    <td><?php echo $t ? $h($to_names[$t['new_section']] . ' · ' . $t['new_roll']) : '<span class="dim">later</span>'; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <p class="ok"><i class="fas fa-check"></i> Everyone going up has a section — Preview, then confirm.</p>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn btn-success"><i class="fas fa-eye"></i> Preview</button>
    </form>
    <script>
    (function () {
        var form = document.getElementById('ruleForm'), pick = document.getElementById('meritPick'), steps = document.getElementById('stepsPick');
        var nth = function (n) { var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); };
        var method = function () { return (form.querySelector('input[name="promotion_method"]:checked') || {}).value || ''; };
        function chosen(group) {   // the ticked sections of a group, in name order
            return Array.prototype.filter.call(form.querySelectorAll('input[data-group="' + group + '"]'), function (i) { return i.checked; })
                .map(function (i) { return i.dataset.name; })
                .sort(function (a, b) { return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }); });
        }
        function line(group, who) {   // 1st → A roll 1 · 2nd → C roll 1 …, and how many each section gets
            var box = document.getElementById(group + 'Line'), n = +box.dataset.count, secs = chosen(group), steps = [];
            if (!n) { box.textContent = 'No ' + who + ' going up.'; return; }
            if (!secs.length) { box.textContent = n + ' ' + who + ': tick at least one section for them.'; return; }
            for (var i = 0; i < Math.min(n, secs.length + 1); i++) steps.push(nth(i + 1) + ' → ' + secs[i % secs.length] + ' roll ' + (Math.floor(i / secs.length) + 1));
            var each = secs.map(function (s, i) { return s + ': ' + (Math.floor(n / secs.length) + (i < n % secs.length ? 1 : 0)); });
            box.textContent = n + ' ' + who + ' in merit order — ' + steps.join(' · ') + (n > steps.length ? ' …' : '') + '\nIn each section: ' + each.join(' · ');
        }
        function update() {
            pick.classList.toggle('hidden', method() !== 'merit_distribution');
            steps.classList.toggle('hidden', method() !== 'section_steps');
            Array.prototype.forEach.call(steps.querySelectorAll('input, select'), function (el) { el.disabled = method() !== 'section_steps'; });   // sent only with this rule
            line('boys', 'boys'); line('girls', 'girls');
        }
        form.addEventListener('change', update);
        Array.prototype.forEach.call(form.querySelectorAll('.refresh'), function (el) {   // show whom the step would take
            el.addEventListener('change', function () { form.action = 'promotion.php#builder'; form.submit(); });
        });
        form.addEventListener('submit', function (e) {
            if (method() !== 'merit_distribution') return;
            var need = [];
            if (+document.getElementById('boysLine').dataset.count && !chosen('boys').length) need.push('boys');
            if (+document.getElementById('girlsLine').dataset.count && !chosen('girls').length) need.push('girls');
            if (need.length) { e.preventDefault(); alert('Tick at least one section for the ' + need.join(' and the ') + '.'); }
        });
        update();
    })();
    </script>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
 
require_once '../includes/auth.php';
require_admin_login();
 
$export_mode = $_GET['export'] ?? '';
if($export_mode === 'excel' || $export_mode === 'pdf') {
    ob_start();
}
 
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/simple_xlsx_writer.php");
require_once("../includes/promotion_helper.php");
 
$batch_id = isset($_GET['batch_id']) ? (int)$_GET['batch_id'] : 0;
 
if($batch_id > 0) {
    // ===== DETAIL VIEW FOR ONE BATCH =====
    $batch = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT pb.*, fs.session_name AS from_session_name, fc.class_name AS from_class_name,
               ts.session_name AS to_session_name, tc.class_name AS to_class_name, a.full_name AS promoted_by_name
        FROM promotion_batches pb
        LEFT JOIN academic_sessions fs ON fs.id = pb.from_session_id
        LEFT JOIN classes fc ON fc.id = pb.from_class_id
        LEFT JOIN academic_sessions ts ON ts.id = pb.to_session_id
        LEFT JOIN classes tc ON tc.id = pb.to_class_id
        LEFT JOIN admins a ON a.id = pb.promoted_by
        WHERE pb.id='$batch_id'
    "));
 
    if(!$batch) {
        $_SESSION['error'] = "⚠️ Promotion batch not found.";
        header("Location: promotion_history.php");
        exit();
    }
 
    $details = [];
    $det_q = mysqli_query($conn, "
        SELECT pd.*, s.student_name, s.admission_no, osec.section_name AS old_section_name, nsec.section_name AS new_section_name,
               g.father_name, smr.final_total AS marks_obtained, smr.merit_rank
        FROM promotion_details pd
        JOIN students s ON s.id = pd.student_id
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections osec ON osec.id = pd.old_section_id
        LEFT JOIN sections nsec ON nsec.id = pd.new_section_id
        LEFT JOIN student_merit_ranks smr ON smr.student_id = pd.student_id AND smr.class_id = pd.old_class_id
        WHERE pd.batch_id='$batch_id'
        ORDER BY CAST(pd.new_roll_no AS UNSIGNED) ASC, pd.id ASC
    ");
    while($r = mysqli_fetch_assoc($det_q)) { $details[] = $r; }

    // ===== FAIL/ABSENT students (in from_session+class but NOT in promotion_details) =====
    $promoted_ids = array_column($details, 'student_id');
    $fail_students = [];
    $fail_q = mysqli_query($conn, "
        SELECT s.id, s.student_name, s.admission_no, s.gender,
               g.father_name, sec.section_name AS old_section_name, sah.roll_no AS old_roll_no,
               smr.final_total AS marks_obtained, smr.result_status
        FROM student_academic_history sah
        JOIN students s ON s.id = sah.student_id
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = sah.section_id
        LEFT JOIN student_merit_ranks smr ON smr.student_id = s.id AND smr.academic_session_id = sah.session_id AND smr.class_id = sah.class_id
        WHERE sah.session_id='{$batch['from_session_id']}' AND sah.class_id='{$batch['from_class_id']}'
          AND s.student_status='Active'
        ORDER BY sec.section_name ASC, CAST(sah.roll_no AS UNSIGNED) ASC
    ");
    while($r = mysqli_fetch_assoc($fail_q)) {
        if(!in_array($r['id'], $promoted_ids)) {
            $fail_students[] = $r;
        }
    }
 
    if($export_mode === 'excel') {
        $xlsx_rows = [
            ['Promotion: ' . $batch['from_class_name'] . ' (' . $batch['from_session_name'] . ') to ' . $batch['to_class_name'] . ' (' . $batch['to_session_name'] . ')'],
            ['SL No', 'Student Name', 'Father Name', 'Admission No', 'Gender', 'Old Class', 'Old Section', 'Old Roll', 'Marks Obtained', 'New Class', 'New Section', 'New Roll', 'Rank']
        ];
        $merge_cells = ['A1:M1'];
        $sl = 1;
        foreach($details as $d) {
            $xlsx_rows[] = [
                $sl,
                (string)$d['student_name'],
                (string)($d['father_name'] ?? ''),
                (string)$d['admission_no'],
                (string)($d['gender'] ?? ''),
                (string)$batch['from_class_name'],
                (string)($d['old_section_name'] ?? ''),
                (string)$d['old_roll_no'],
                (string)($d['marks_obtained'] ?? ''),
                (string)$batch['to_class_name'],
                (string)($d['new_section_name'] ?? 'Unassigned'),
                (string)$d['new_roll_no'],
                (string)($d['merit_rank'] ?? '-'),
            ];
            $sl++;
        }
        if(!empty($fail_students)) {
            $xlsx_rows[] = [];
            $fail_title_row = count($xlsx_rows) + 1;
            $xlsx_rows[] = ['Not Promoted (Fail / Absent)'];
            $merge_cells[] = 'A' . $fail_title_row . ':M' . $fail_title_row;
            $xlsx_rows[] = ['SL No', 'Student Name', 'Father Name', 'Admission No', 'Gender', 'Section', 'Roll', 'Marks Obtained', 'Status', '', '', '', ''];
            $fsl = 1;
            foreach($fail_students as $f) {
                $xlsx_rows[] = [
                    $fsl,
                    (string)$f['student_name'],
                    (string)($f['father_name'] ?? ''),
                    (string)$f['admission_no'],
                    (string)($f['gender'] ?? ''),
                    (string)($f['old_section_name'] ?? ''),
                    (string)$f['old_roll_no'],
                    (string)($f['marks_obtained'] ?? ''),
                    (string)($f['result_status'] ?? 'FAIL'),
                    '', '', '', ''
                ];
                $fsl++;
            }
        }
        SimpleXLSXWriter::download(
            'promotion_batch_' . $batch_id . '.xlsx',
            $xlsx_rows,
            'Promotion Batch',
            ['title_rows' => 1, 'header_rows' => 1, 'freeze_rows' => 2, 'merge_cells' => $merge_cells]
        );
    }
 
    if($export_mode === 'pdf') {
        while (ob_get_level() > 0) { ob_end_clean(); }
        $school_print = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings WHERE id=1"));
        ?>
        <!DOCTYPE html><html><head><meta charset="utf-8"><title>Promotion Details</title>
        <style>
        body{font-family:Arial;margin:25px;color:#1a3b55;}
        .school-header{display:flex;align-items:center;gap:12px;border-bottom:2px solid #003366;padding-bottom:8px;margin-bottom:15px;}
        .school-header img{max-width:60px;max-height:60px;object-fit:contain;}
        .school-header .info{flex:1;text-align:center;}
        .school-header h1{font-size:18pt;color:#003366;margin:0 0 3px;text-transform:uppercase;}
        .school-header p{font-size:10pt;margin:2px 0;color:#555;}
        h2{text-align:center;color:#003366;margin-bottom:2px;}
        p.sub{text-align:center;color:#6c7a8a;margin-top:0;}
        table{width:100%;border-collapse:collapse;margin-top:15px;} th,td{border:1px solid #999;padding:6px 8px;font-size:12px;text-align:left;}
        th{background:#003366;color:#fff;} .btn-print{margin-bottom:15px;padding:10px 20px;background:#003366;color:#fff;border:none;border-radius:5px;cursor:pointer;}
        @media print{.no-print{display:none;} @page{margin:8mm 10mm;}}
        </style>
        <link rel="stylesheet" href="../assets/css/global-responsive.css">
        <script src="../assets/js/global-responsive.js" defer></script>
        </head><body>
        <button class="btn-print no-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
        <div class="school-header">
            <?php if(!empty($school_print['logo'])): ?>
            <img src="../uploads/<?php echo htmlspecialchars($school_print['logo'], ENT_QUOTES, 'UTF-8'); ?>" alt="Logo">
            <?php endif; ?>
            <div class="info">
                <h1><?php echo htmlspecialchars($school_print['school_name'] ?? 'School'); ?></h1>
                <?php if(!empty($school_print['school_address'])): ?><p><?php echo htmlspecialchars($school_print['school_address']); ?><?php echo !empty($school_print['established_year']) ? ' · Estd. ' . (int)$school_print['established_year'] : ''; ?></p><?php endif; ?>
                <?php if(!empty($school_print['phone'])): ?><p>Phone: <?php echo htmlspecialchars($school_print['phone']); ?><?php if(!empty($school_print['udise_code'])): ?> | UDISE: <?php echo htmlspecialchars($school_print['udise_code']); ?><?php endif; ?></p><?php endif; ?>
            </div>
        </div>
        <h2>Promotion Details</h2>
        <p class="sub"><?php echo htmlspecialchars($batch['from_class_name'].' ('.$batch['from_session_name'].')'); ?> → <?php echo htmlspecialchars($batch['to_class_name'].' ('.$batch['to_session_name'].')'); ?> — Method: <?php echo htmlspecialchars(promotion_method_label($batch['promotion_method'])); ?></p>
        <table>
        <tr><th>SL No</th><th>Student Name</th><th>Father Name</th><th>Admission No</th><th>Gender</th><th>Old Section</th><th>Old Roll</th><th>Marks Obtained</th><th>New Section</th><th>New Roll</th><th>Rank</th></tr>
        <?php $sl=1; foreach($details as $d): ?>
        <tr>
            <td><?php echo $sl; ?></td>
            <td><?php echo htmlspecialchars($d['student_name']); ?></td>
            <td><?php echo htmlspecialchars($d['father_name'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($d['admission_no']); ?></td>
            <td><?php echo htmlspecialchars($d['gender'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($d['old_section_name'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($d['old_roll_no']); ?></td>
            <td><?php echo htmlspecialchars($d['marks_obtained'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($d['new_section_name'] ?? 'Unassigned'); ?></td>
            <td><?php echo htmlspecialchars($d['new_roll_no']); ?></td>
            <td><?php echo htmlspecialchars($d['merit_rank'] ?? '-'); ?></td>
        </tr>
        <?php $sl++; endforeach; ?>
        </table>

        <?php if(!empty($fail_students)): ?>
        <h3 style="color:#c62828; margin-top:28px;">❌ Not Promoted — Fail / Absent (<?php echo count($fail_students); ?>)</h3>
        <table>
        <tr><th>SL No</th><th>Student Name</th><th>Father Name</th><th>Admission No</th><th>Gender</th><th>Section</th><th>Roll</th><th>Marks Obtained</th><th>Status</th></tr>
        <?php $fsl=1; foreach($fail_students as $f): ?>
        <tr>
            <td><?php echo $fsl; ?></td>
            <td><?php echo htmlspecialchars($f['student_name']); ?></td>
            <td><?php echo htmlspecialchars($f['father_name'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($f['admission_no']); ?></td>
            <td><?php echo htmlspecialchars($f['gender'] ?? ''); ?></td>
            <td><?php echo htmlspecialchars($f['old_section_name'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($f['old_roll_no']); ?></td>
            <td><?php echo htmlspecialchars($f['marks_obtained'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($f['result_status'] ?? 'FAIL'); ?></td>
        </tr>
        <?php $fsl++; endforeach; ?>
        </table>
        <?php endif; ?>

        <script>window.onload=function(){window.print();};</script>
        </body></html>
        <?php
        exit();
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promotion Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        table.detail-table { width:100%; border-collapse:collapse; background:#fff; }
        table.detail-table th, table.detail-table td { border:1px solid #e4edf6; padding:9px 12px; text-align:left; font-size:13px; }
        table.detail-table th { background:#003366; color:#fff; }
        .meta-bar { display:flex; flex-wrap:wrap; gap:18px; align-items:center; background:#e8f4ff; border:1px solid #cfe2f3; border-radius:10px; padding:12px 18px; margin-bottom:16px; font-size:13px; color:#1a3b55; }
        @media print { .no-print{display:none;} }
    </style>
    </head>
    <body>
    <?php include("../includes/navbar.php"); ?>
    <div class="page-box">
        <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
        <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($_SESSION[$kind], ENT_QUOTES, 'UTF-8'); unset($_SESSION[$kind]); ?></div>
        <?php endforeach; ?>
        <a href="promotion_history.php" class="no-print" style="color:#003366; text-decoration:none; font-weight:600; font-size:13px; display:inline-flex; align-items:center; gap:6px; margin-bottom:14px;">
            <i class="fas fa-arrow-left"></i> Back to Promotion History
        </a>
        <div class="page-header">
            <div class="page-title"><i class="fas fa-list-alt"></i> Promotion Details</div>
        </div>
 
        <div class="meta-bar">
            <span>From: <strong><?php echo htmlspecialchars($batch['from_class_name'].' ('.$batch['from_session_name'].')'); ?></strong></span>
            <span><i class="fas fa-arrow-right"></i></span>
            <span>To: <strong><?php echo htmlspecialchars($batch['to_class_name'].' ('.$batch['to_session_name'].')'); ?></strong></span>
            <span>Method: <strong><?php echo htmlspecialchars(promotion_method_label($batch['promotion_method'])); ?></strong></span>
            <span>Students: <strong><?php echo htmlspecialchars($batch['total_students']); ?></strong></span>
            <span>By: <strong><?php echo htmlspecialchars($batch['promoted_by_name'] ?? 'Admin'); ?></strong></span>
            <span>At: <strong><?php echo htmlspecialchars($batch['promoted_at']); ?></strong></span>
        </div>
 
        <?php
        $further_check = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT id FROM promotion_batches WHERE from_session_id='" . (int)$batch['to_session_id'] . "' AND from_class_id='" . (int)$batch['to_class_id'] . "' LIMIT 1"
        ));
        $can_rollback = !$further_check;
        ?>
        <div class="action-bar no-print" style="display:flex; gap:10px; margin-bottom:16px; flex-wrap:wrap; align-items:center;">
            <input type="text" id="detailSearch" placeholder="🔍 Search by name..." style="padding:10px; border:2px solid #e4edf6; border-radius:8px; font-size:14px; min-width:220px;">
            <button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button>
            <a href="promotion_history.php?batch_id=<?php echo $batch_id; ?>&export=excel" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel Export</a>
            <a href="promotion_history.php?batch_id=<?php echo $batch_id; ?>&export=pdf" target="_blank" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF Export</a>
            <?php if($can_rollback): ?>
            <form method="POST" action="rollback_promotion.php"
                  onsubmit="return confirm('⚠️ ROLLBACK এই promotion?\n\n<?php echo addslashes($batch['from_class_name'].' ('.$batch['from_session_name'].')'); ?> ← <?php echo addslashes($batch['to_class_name'].' ('.$batch['to_session_name'].')'); ?>\n\n<?php echo (int)$batch['total_students']; ?> জন student কে আগের class এ ফেরত পাঠানো হবে।\n\nConfirm করুন।');"
                  style="display:inline;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="batch_id" value="<?php echo $batch_id; ?>">
                <button type="submit" class="btn btn-danger">
                    <i class="fas fa-undo"></i> Rollback This Promotion
                </button>
            </form>
            <?php else: ?>
            <span style="background:#fff3cd; border:1px solid #ffc107; color:#856404; padding:8px 14px; border-radius:8px; font-size:13px; font-weight:600;">
                <i class="fas fa-lock"></i> Rollback not available — students already promoted further
            </span>
            <?php endif; ?>
        </div>
 
        <div class="table-responsive">
            <table class="detail-table" id="detailTable">
                <thead>
                    <tr><th>SL No</th><th>Student Name</th><th>Father Name</th><th>Admission No</th><th>Gender</th><th>Old Section</th><th>Old Roll</th><th>Marks Obtained</th><th>New Section</th><th>New Roll</th><th>Rank</th></tr>
                </thead>
                <tbody>
                    <?php $sl=1; foreach($details as $d): ?>
                    <tr>
                        <td><?php echo $sl; ?></td>
                        <td><?php echo htmlspecialchars($d['student_name']); ?></td>
                        <td><?php echo htmlspecialchars($d['father_name'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($d['admission_no']); ?></td>
                        <td><?php echo htmlspecialchars($d['gender'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($d['old_section_name'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($d['old_roll_no']); ?></td>
                        <td><?php echo htmlspecialchars($d['marks_obtained'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($d['new_section_name'] ?? 'Unassigned'); ?></td>
                        <td><?php echo htmlspecialchars($d['new_roll_no']); ?></td>
                        <td><?php echo htmlspecialchars($d['merit_rank'] ?? '-'); ?></td>
                    </tr>
                    <?php $sl++; endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if(!empty($fail_students)): ?>
        <div style="margin-top:30px;">
            <div style="background:#c62828; color:#fff; padding:10px 16px; border-radius:8px 8px 0 0; font-weight:700; font-size:14px;">
                <i class="fas fa-times-circle"></i> Not Promoted — Fail / Absent
                <span style="background:rgba(255,255,255,0.25); padding:2px 10px; border-radius:20px; font-size:13px; margin-left:8px;"><?php echo count($fail_students); ?> জন</span>
            </div>
            <div class="table-responsive">
                <table class="detail-table" id="failTable" style="border-top:none;">
                    <thead>
                        <tr style="background:#b71c1c;">
                            <th>SL No</th><th>Student Name</th><th>Father Name</th><th>Admission No</th><th>Gender</th><th>Section</th><th>Roll</th><th>Marks Obtained</th><th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $fsl=1; foreach($fail_students as $f): ?>
                        <tr style="background:#fff8f8;">
                            <td><?php echo $fsl; ?></td>
                            <td><?php echo htmlspecialchars($f['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($f['father_name'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($f['admission_no']); ?></td>
                            <td><?php echo htmlspecialchars($f['gender'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($f['old_section_name'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($f['old_roll_no']); ?></td>
                            <td><?php echo htmlspecialchars($f['marks_obtained'] ?? '-'); ?></td>
                            <td>
                                <?php
                                $rs = $f['result_status'] ?? 'FAIL';
                                $badge = ($rs === 'COMPARTMENT' || $rs === 'PUC') ? 'background:#e65100;color:#fff;' : 'background:#c62828;color:#fff;';
                                ?>
                                <span style="<?php echo $badge; ?> padding:2px 8px; border-radius:4px; font-size:12px; font-weight:700;"><?php echo htmlspecialchars($rs); ?></span>
                            </td>
                        </tr>
                        <?php $fsl++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>
    <script>
    document.getElementById('detailSearch').addEventListener('keyup', function() {
        var term = this.value.toLowerCase();
        document.querySelectorAll('#detailTable tbody tr, #failTable tbody tr').forEach(function(row) {
            row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
        });
    });
    </script>
    </body>
    </html>
    <?php
    exit();
}
 
// ===== BATCH LIST VIEW =====
$batches = [];
$q = mysqli_query($conn, "
    SELECT pb.*, fs.session_name AS from_session_name, fc.class_name AS from_class_name,
           ts.session_name AS to_session_name, tc.class_name AS to_class_name, a.full_name AS promoted_by_name
    FROM promotion_batches pb
    LEFT JOIN academic_sessions fs ON fs.id = pb.from_session_id
    LEFT JOIN classes fc ON fc.id = pb.from_class_id
    LEFT JOIN academic_sessions ts ON ts.id = pb.to_session_id
    LEFT JOIN classes tc ON tc.id = pb.to_class_id
    LEFT JOIN admins a ON a.id = pb.promoted_by
    ORDER BY pb.promoted_at DESC
");
while($r = mysqli_fetch_assoc($q)) { $batches[] = $r; }
 
if($export_mode === 'excel') {
    $xlsx_rows = [['From', 'To', 'Method', 'Students', 'Promoted By', 'Date']];
    foreach($batches as $b) {
        $xlsx_rows[] = [
            (string)($b['from_class_name'].' ('.$b['from_session_name'].')'),
            (string)($b['to_class_name'].' ('.$b['to_session_name'].')'),
            promotion_method_label((string)$b['promotion_method']),
            (string)$b['total_students'],
            (string)($b['promoted_by_name'] ?? ''),
            (string)$b['promoted_at'],
        ];
    }
    SimpleXLSXWriter::download(
        'promotion_history.xlsx',
        $xlsx_rows,
        'Promotion History',
        ['header_rows' => 1, 'freeze_rows' => 1]
    );
}
 
if($export_mode === 'pdf') {
    while (ob_get_level() > 0) { ob_end_clean(); }
    ?>
    <!DOCTYPE html><html><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promotion History</title>
    <style>
    body{font-family:Arial;margin:25px;color:#1a3b55;} h2{text-align:center;color:#003366;}
    table{width:100%;border-collapse:collapse;margin-top:15px;} th,td{border:1px solid #999;padding:6px 8px;font-size:12px;text-align:left;}
    th{background:#003366;color:#fff;} .btn-print{margin-bottom:15px;padding:10px 20px;background:#003366;color:#fff;border:none;border-radius:5px;cursor:pointer;}
    @media print{.no-print{display:none;}}
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
    </head><body>
    <button class="btn-print no-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
    <h2>Promotion History</h2>
    <table>
    <tr><th>From</th><th>To</th><th>Method</th><th>Students</th><th>Promoted By</th><th>Date</th></tr>
    <?php foreach($batches as $b): ?>
    <tr>
        <td><?php echo htmlspecialchars($b['from_class_name'].' ('.$b['from_session_name'].')'); ?></td>
        <td><?php echo htmlspecialchars($b['to_class_name'].' ('.$b['to_session_name'].')'); ?></td>
        <td><?php echo htmlspecialchars(promotion_method_label($b['promotion_method'])); ?></td>
        <td><?php echo htmlspecialchars($b['total_students']); ?></td>
        <td><?php echo htmlspecialchars($b['promoted_by_name'] ?? ''); ?></td>
        <td><?php echo htmlspecialchars($b['promoted_at']); ?></td>
    </tr>
    <?php endforeach; ?>
    </table>
    <script>window.onload=function(){window.print();};</script>
    </body></html>
    <?php
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Promotion History</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    table.history-table { width:100%; border-collapse:collapse; background:#fff; }
    table.history-table th, table.history-table td { border:1px solid #e4edf6; padding:9px 12px; text-align:left; font-size:13px; }
    table.history-table th { background:#003366; color:#fff; }
    table.history-table tbody tr:hover { background:#f8fbff; }
    @media print { .no-print{display:none;} }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-history"></i> Promotion History</div>
        <a href="promotion.php" class="btn btn-primary"><i class="fas fa-level-up-alt"></i> New Promotion</a>
    </div>
 
    <?php if(isset($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success'] ?? '', ENT_QUOTES, 'UTF-8'); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if(isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error'] ?? '', ENT_QUOTES, 'UTF-8'); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
 
    <?php if(empty($batches)): ?>
    <div class="empty-state">
        <i class="fas fa-history"></i>
        <h3>No Promotions Yet</h3>
        <p>Promotion batches will appear here once you promote students.</p>
    </div>
    <?php else: ?>
 
    <div class="action-bar no-print" style="display:flex; gap:10px; margin-bottom:16px;">
        <input type="text" id="historySearch" placeholder="🔍 Search by class or session..." style="padding:10px; border:2px solid #e4edf6; border-radius:8px; font-size:14px; min-width:240px;">
        <button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button>
        <a href="promotion_history.php?export=excel" class="btn btn-success"><i class="fas fa-file-excel"></i> Excel Export</a>
        <a href="promotion_history.php?export=pdf" target="_blank" class="btn btn-danger"><i class="fas fa-file-pdf"></i> PDF Export</a>
    </div>
 
    <div class="table-responsive">
        <table class="history-table" id="historyTable">
            <thead>
                <tr><th>From</th><th>To</th><th>Method</th><th>Students</th><th>Promoted By</th><th>Date</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php foreach($batches as $b):
                    // Check if a further promotion exists from the destination
                    $further = mysqli_fetch_assoc(mysqli_query($conn,
                        "SELECT id FROM promotion_batches WHERE from_session_id='" . (int)$b['to_session_id'] . "' AND from_class_id='" . (int)$b['to_class_id'] . "' LIMIT 1"
                    ));
                    $can_rollback = !$further;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($b['from_class_name'].' ('.$b['from_session_name'].')'); ?></td>
                    <td><?php echo htmlspecialchars($b['to_class_name'].' ('.$b['to_session_name'].')'); ?></td>
                    <td><?php echo htmlspecialchars(promotion_method_label($b['promotion_method'])); ?></td>
                    <td><?php echo htmlspecialchars($b['total_students']); ?></td>
                    <td><?php echo htmlspecialchars($b['promoted_by_name'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($b['promoted_at']); ?></td>
                    <td style="display:flex; gap:6px; flex-wrap:wrap;">
                        <a href="promotion_history.php?batch_id=<?php echo $b['id']; ?>" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i> View</a>
                        <?php if($can_rollback): ?>
                        <form method="POST" action="rollback_promotion.php" onsubmit="return confirm('⚠️ Are you sure you want to ROLLBACK this promotion?\n\n<?php echo addslashes($b['from_class_name'].' ('.$b['from_session_name'].')'); ?> ← <?php echo addslashes($b['to_class_name'].' ('.$b['to_session_name'].')'); ?>\n\nThis will restore <?php echo (int)$b['total_students']; ?> student(s) back to their previous class. This cannot be undone.');" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="batch_id" value="<?php echo (int)$b['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-undo"></i> Rollback</button>
                        </form>
                        <?php else: ?>
                        <span style="font-size:11px; color:#6c7a8a; padding:4px 8px;"><i class="fas fa-lock"></i> Further promoted</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
 
    <script>
    document.getElementById('historySearch').addEventListener('keyup', function() {
        var term = this.value.toLowerCase();
        document.querySelectorAll('#historyTable tbody tr').forEach(function(row) {
            row.style.display = row.textContent.toLowerCase().includes(term) ? '' : 'none';
        });
    });
    </script>
 
    <?php endif; ?>
</div>
</body>
</html>

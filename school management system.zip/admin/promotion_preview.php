<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/promotion_helper.php';

/**
 * Promotion preview: every student's new section and roll exactly as they would be saved (promotion_plan()).
 * Nothing is written here. Confirm sends only the choices and the plan's fingerprint; the save works the plan
 * out again and refuses it if anything has changed in between. With Manual this is where the sections and rolls
 * are given: they go to the save as one JSON list, and come back here if the save refuses them.
 */
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
$classes = class_rows();
$from_session_id = (int)($_GET['from_session_id'] ?? 0);
$from_class_id   = (int)($_GET['from_class_id'] ?? 0);
$to_session_id   = (int)($_GET['to_session_id'] ?? 0);
$method          = (string)($_GET['promotion_method'] ?? '');
$ids = fn($key) => $method === 'merit_distribution' ? array_values(array_unique(array_filter(array_map('intval', (array)($_GET[$key] ?? []))))) : [];
$boys = $ids('boys_sections'); $girls = $ids('girls_sections');
$steps = $method === 'section_steps' ? (array)($_GET['steps'] ?? []) : [];   // Section by Section; promotion_plan() checks them
$manual_mode = $method === 'manual';
$manual = $manual_mode ? (array)($_SESSION['promotion_manual']["$from_session_id-$from_class_id-$to_session_id"] ?? []) : [];   // kept from a refused save
$back = 'promotion.php?' . http_build_query(['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id, 'promotion_method' => $method]
      + ($method === 'section_steps' ? ['steps' => $steps] : []));
$fail = function (string $msg) use ($back) { $_SESSION['error'] = $msg; header("Location: $back"); exit(); };

if (!isset($classes[$from_class_id]) || !isset(PROMOTION_METHODS[$method])) $fail('Choose the class and a promotion rule first.');
$to_class_id = (int)promotion_next_class($from_class_id);
if (!$to_class_id) $fail(promotion_no_next_reason($from_class_id));
if (!promotion_session_later($from_session_id, $to_session_id)) $fail('The new session must come after the old one.');
if (!promotion_get_merit_count($conn, $from_session_id, $from_class_id)) $fail('The merit list of this class has not been made yet — generate it first.');
if (promotion_batch_exists($conn, $from_session_id, $from_class_id)) $fail('This class has already gone up — see Promotion History.');

$plan = promotion_plan($from_session_id, $from_class_id, $to_session_id, $to_class_id, $method, $boys, $girls, $steps, $manual);
if (!$plan['sections']) $fail('The new class has no sections in the new session yet — copy them first.');
if (!$plan['students']) $fail('No student of this class is waiting to go up.');

$from = 'Class ' . $classes[$from_class_id]['name'] . ' · ' . promotion_get_session_name(null, $from_session_id);
$to   = 'Class ' . $classes[$to_class_id]['name'] . ' · ' . promotion_get_session_name(null, $to_session_id);
$sections = $plan['sections'];
$students = $plan['students'];
$merit = $method === 'merit_distribution';
$by_steps = $method === 'section_steps';
if ($merit) {   // boys in their merit order, then girls, then anyone who fits neither
    $group = fn(array $st) => ['Male' => 0, 'Female' => 1][$st['gender']] ?? 2;
    uasort($students, fn($a, $b) => ($group($a) <=> $group($b)) ?: (($a['order'] ?? PHP_INT_MAX) <=> ($b['order'] ?? PHP_INT_MAX)));
} elseif ($by_steps) {   // new section by new section, each in roll order; no section yet last
    uasort($students, fn($a, $b) => strnatcasecmp($sections[$a['new_section']] ?? '~', $sections[$b['new_section']] ?? '~') ?: ((int)$a['new_roll'] <=> (int)$b['new_roll']));
} elseif (!$manual_mode) {   // as they sit this year (Manual keeps merit order, and can be reordered on the page)
    uasort($students, fn($a, $b) => strnatcasecmp($a['section'], $b['section']) ?: ((int)$a['roll'] <=> (int)$b['roll']) ?: strcasecmp($a['name'], $b['name']));
}
if ($manual_mode) {   // each student's place in every order, so the page reorders without losing what is typed; rolls already used
    $by = [];
    foreach (array_keys(PROMOTION_STEP_ORDERS) as $o) { $l = $students; promotion_sort_step($l, $o); $by[$o] = array_flip(array_map('strval', array_keys($l))); }
    $taken = array_map(fn($rolls) => array_map('strval', array_keys($rolls)), promotion_taken_rolls($to_session_id, $to_class_id));
}

$count = ['Male' => 0, 'Female' => 0, 'Other' => 0];
$per = array_fill_keys(array_keys($sections), ['Male' => 0, 'Female' => 0, 'Other' => 0, 'rolls' => []]);   // what each new section gets
$changed = 0;
foreach ($students as $st) {
    $g = in_array($st['gender'], ['Male', 'Female'], true) ? $st['gender'] : 'Other';
    $count[$g]++;
    if ($st['new_section'] === null) continue;
    $per[$st['new_section']][$g]++;
    $per[$st['new_section']]['rolls'][] = (int)$st['new_roll'];
    if ($st['note'] !== '') $changed++;
}
$people = fn(array $c) => implode(', ', array_filter([$c['Male'] ? $c['Male'] . ' boys' : '', $c['Female'] ? $c['Female'] . ' girls' : '', $c['Other'] ? $c['Other'] . ' other / not set' : '']));
$not_promoted = 'fail_students.php?' . http_build_query(['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id]);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Promotion Preview</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
<style>
    .meta-bar { display: flex; flex-wrap: wrap; gap: 8px 22px; align-items: center; background: #e8f4ff; border: 1px solid #cfe2f3; border-radius: 10px; padding: 12px 18px; margin-bottom: 16px; font-size: 13.5px; color: #1a3b55; }
    .alert a.btn { margin-left: auto; }
    .new-secs { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 10px; margin-bottom: 16px; }
    .new-sec { background: #fff; border: 1px solid #e4edf6; border-left: 4px solid #1565c0; border-radius: 8px; padding: 8px 12px; font-size: 12.5px; color: #5b6b7c; }
    .new-sec b { display: block; color: #003366; font-size: 15px; }
    .new-sec.empty { border-left-color: #cfd8e3; }
    table.preview-table { width: 100%; border-collapse: collapse; background: #fff; }
    table.preview-table th, table.preview-table td { border: 1px solid #e4edf6; padding: 7px 10px; text-align: left; font-size: 13px; }
    table.preview-table th { background: #003366; color: #fff; }
    table.preview-table tr.boy-girl-break td { border-top: 3px solid #90b8f0; }
    table.preview-table td.new { font-weight: 700; color: #003366; white-space: nowrap; }
    table.preview-table tr.changed td { background: #fff8e6; }
    table.preview-table tr.unplaced td { background: #fdecec; }
    .why { display: block; font-size: 11.5px; font-weight: 500; color: #9a6700; }
    tr.unplaced .why { color: #c62828; }
    .unassigned-badge { color: #c62828; font-weight: 700; font-size: 12px; }
    .confirm-bar { margin-top: 20px; padding: 16px 18px; background: #e8f4ff; border: 1px solid #c9e3ff; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; }
    .confirm-bar button:disabled { opacity: .5; cursor: not-allowed; }
    .manual-bar { display: flex; flex-wrap: wrap; gap: 10px 18px; align-items: center; background: #f7fafd; border: 1px solid #dde6ee; border-radius: 10px; padding: 10px 14px; margin-bottom: 6px; font-size: 13px; color: #1a3b55; }
    .manual-bar select { margin-left: 6px; padding: 5px 8px; border: 2px solid #e4edf6; border-radius: 6px; font-size: 13px; }
    .m-status { margin-left: auto; font-weight: 600; color: #c62828; }
    .m-status.ok { color: #1b7a3a; }
    .m-hint { font-size: 12px; color: #6c7a8a; margin: 0 0 10px; }
    table.preview-table select.msec, table.preview-table input.mroll { padding: 4px 6px; border: 2px solid #e4edf6; border-radius: 6px; font-size: 13px; }
    table.preview-table input.mroll { width: 64px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <a href="<?php echo $h($back); ?>" style="color:#003366; text-decoration:none; font-weight:600; font-size:13px; display:inline-flex; align-items:center; gap:6px; margin-bottom:14px;">
        <i class="fas fa-arrow-left"></i> Back
    </a>

    <div class="page-header">
        <div class="page-title"><i class="fas fa-eye"></i> Promotion Preview</div>
    </div>

    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="meta-bar">
        <span><strong><?php echo $h($from); ?></strong> <i class="fas fa-arrow-right"></i> <strong><?php echo $h($to); ?></strong></span>
        <span>Rule: <strong><?php echo $h(promotion_method_label($method)); ?></strong></span>
        <span>Going up: <strong><?php echo count($students); ?></strong> (<?php echo $h($people($count)); ?>)</span>
    </div>

    <?php if ($plan['unplaced'] && !$manual_mode): ?>
    <div class="alert alert-danger"><i class="fas fa-times-circle"></i>
        <span><?php echo $plan['unplaced']; ?> student(s) have no section (marked red below) — nothing can be saved until every student has one. Go back and change the sections, or fix the student.</span>
        <a href="<?php echo $h($back); ?>" class="btn btn-sm btn-primary">Back</a>
    </div>
    <?php endif; ?>
    <?php if ($changed && !$manual_mode): ?>
    <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> <span><?php echo $changed; ?> student(s) get a different roll (marked yellow below) — the reason is shown beside the new roll.</span></div>
    <?php endif; ?>
    <?php if ($plan['already']): ?>
    <div class="alert alert-info"><i class="fas fa-info-circle"></i> <span><?php echo count($plan['already']); ?> passed student(s) are already placed in the new session and are not moved again: <?php echo $h(implode(', ', array_map(fn($st) => "{$st['name']} ({$st['uid']})", array_slice($plan['already'], 0, 5))) . (count($plan['already']) > 5 ? ' …' : '')); ?></span></div>
    <?php endif; ?>
    <?php if ($plan['left']): ?>
    <div class="alert alert-info"><i class="fas fa-user-clock"></i> <span><?php echo count($plan['left']); ?> student(s) do not go up (failed, absent or not on the merit list) — they wait on Not Promoted.</span>
        <a href="<?php echo $h($not_promoted); ?>" class="btn btn-sm btn-warning"><i class="fas fa-box-open"></i> Not Promoted</a>
    </div>
    <?php endif; ?>

    <div class="new-secs">
        <?php foreach ($sections as $id => $name): $p = $per[$id]; $n = $p['Male'] + $p['Female'] + $p['Other']; ?>
        <div class="new-sec<?php echo $n ? '' : ' empty'; ?>" data-sec="<?php echo (int)$id; ?>"><b><?php echo $h($classes[$to_class_id]['name'] . '-' . $name); ?></b>
            <span><?php echo $n ? $h($people($p)) . '<br>rolls ' . min($p['rolls']) . '–' . max($p['rolls']) : 'nobody'; ?></span></div>
        <?php endforeach; ?>
    </div>

    <?php if ($manual_mode): ?>
    <div class="manual-bar">
        <label>Show<select id="mShow"><?php foreach (PROMOTION_STEP_WHO as $k => $l): ?><option value="<?php echo $k; ?>"><?php echo $h($l); ?></option><?php endforeach; ?></select></label>
        <label>Order<select id="mOrder"><?php foreach (PROMOTION_STEP_ORDERS as $k => $l): ?><option value="<?php echo $k; ?>"><?php echo $h($l); ?></option><?php endforeach; ?></select></label>
        <button type="button" class="btn btn-sm" id="mClear"><i class="fas fa-eraser"></i> Clear all</button>
        <span class="m-status" id="mStatus"></span>
    </div>
    <p class="m-hint">Choose a section for every student: its next free roll is filled in, and you can change it. Enter in a roll box moves to the next student.</p>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="preview-table" id="previewTable">
            <thead>
                <tr>
                    <th>Merit Rank</th>
                    <?php if ($merit): ?><th>Order</th><?php endif; ?>
                    <?php if ($by_steps): ?><th>Step</th><?php endif; ?>
                    <th>Student Name</th>
                    <th>School UID</th>
                    <th>Gender</th>
                    <th>Result</th>
                    <th>Now (Section · Roll)</th>
                    <?php if ($manual_mode): ?><th>New section (Class <?php echo $h($classes[$to_class_id]['name']); ?>)</th><th>New roll</th>
                    <?php else: ?><th>New (Section · Roll)</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $last = null; foreach ($students as $uid => $st):
                    $g = $st['gender'];
                    $cls = $manual_mode ? '' : ($st['new_section'] === null ? 'unplaced' : ($st['note'] !== '' ? 'changed' : ''));   // Manual: marked by the page as you type
                    if ($merit && $last !== null && $last !== $g) $cls .= ' boy-girl-break';
                    $last = $g; ?>
                <tr data-uid="<?php echo $h($uid); ?>" data-sec="<?php echo (int)$st['new_section']; ?>" data-roll="<?php echo $h($st['new_roll'] ?? ''); ?>" class="<?php echo trim($cls); ?>"<?php echo $manual_mode ? ' data-g="' . $h($g) . '"' . implode('', array_map(fn($o) => " data-by-$o=\"" . $by[$o][(string)$uid] . '"', array_keys($by))) : ''; ?>>
                    <td><?php echo $st['rank'] ? (int)$st['rank'] : '—'; ?></td>
                    <?php if ($merit): ?><td><?php echo $st['order'] ? ($g === 'Male' ? 'Boy ' : 'Girl ') . (int)$st['order'] : '—'; ?></td><?php endif; ?>
                    <?php if ($by_steps): ?><td><?php echo $st['step'] ? (int)$st['step'] : '—'; ?></td><?php endif; ?>
                    <td><?php echo $h($st['name']); ?></td>
                    <td><?php echo $h($uid); ?></td>
                    <td><?php echo $h($g !== '' ? $g : '—'); ?></td>
                    <td><?php echo $h($st['status']); ?></td>
                    <td><?php echo $h(($st['section'] !== '' ? $st['section'] : '—') . ' · ' . ($st['roll'] ?? '—')); ?></td>
                    <?php if ($manual_mode): [$msec, $mroll] = $manual[$uid] ?? [0, '']; ?>
                    <td><select class="msec" aria-label="New section"><option value="">— choose —</option><?php foreach ($sections as $id => $name): ?><option value="<?php echo (int)$id; ?>"<?php echo (int)$id === $msec ? ' selected' : ''; ?>><?php echo $h($name); ?></option><?php endforeach; ?></select></td>
                    <td><input type="text" class="mroll" inputmode="numeric" maxlength="4" autocomplete="off" aria-label="New roll" value="<?php echo $h($mroll); ?>"></td>
                    <?php else: ?>
                    <td class="new">
                        <?php if ($st['new_section'] === null): ?><span class="unassigned-badge">No section</span>
                        <?php else: ?><?php echo $h($sections[$st['new_section']] . ' · ' . $st['new_roll']); ?><?php endif; ?>
                        <?php if ($st['note'] !== ''): ?><span class="why"><?php echo $h($st['note']); ?></span><?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <form method="post" action="promotion_process.php" id="promoForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="from_session_id" value="<?php echo $from_session_id; ?>">
        <input type="hidden" name="from_class_id" value="<?php echo $from_class_id; ?>">
        <input type="hidden" name="to_session_id" value="<?php echo $to_session_id; ?>">
        <input type="hidden" name="promotion_method" value="<?php echo $h($method); ?>">
        <?php foreach ($boys as $id): ?><input type="hidden" name="boys_sections[]" value="<?php echo $id; ?>"><?php endforeach; ?>
        <?php foreach ($girls as $id): ?><input type="hidden" name="girls_sections[]" value="<?php echo $id; ?>"><?php endforeach; ?>
        <?php foreach ($plan['steps'] as $i => $s) foreach (array_filter($s, fn($v) => $v !== null) as $k => $v) echo '<input type="hidden" name="steps[' . $i . '][' . $k . ']" value="' . $h($v) . '">'; ?>
        <?php if ($manual_mode): ?><input type="hidden" name="manual_rows" id="manualRows" value=""><?php endif; ?>
        <input type="hidden" name="plan_key" value="<?php echo $h($plan['key']); ?>">
        <div class="confirm-bar">
            <span><i class="fas fa-info-circle"></i> Nothing is saved until you confirm. It can be undone from Promotion History (Rollback).</span>
            <button type="submit" class="btn btn-success"<?php echo $plan['unplaced'] ? ' disabled' : ''; ?>><i class="fas fa-check-circle"></i> Confirm Promotion (<?php echo count($students); ?>)</button>
        </div>
    </form>
</div>
<?php if ($manual_mode): ?>
<script>
(function () {   // Manual: every row needs a section and a roll no other row has and nobody uses in the new session yet
    var form = document.getElementById('promoForm'), body = document.querySelector('#previewTable tbody');
    var rows = Array.prototype.slice.call(body.rows), btn = form.querySelector('button[type="submit"]'), status = document.getElementById('mStatus');
    var taken = <?php echo json_encode((object)$taken, JSON_HEX_TAG | JSON_HEX_AMP); ?>;   // section id => rolls already used in the new session
    var cards = {};
    Array.prototype.forEach.call(document.querySelectorAll('.new-sec[data-sec]'), function (c) { cards[c.dataset.sec] = c; });
    function cell(tr) { return { sec: tr.querySelector('.msec'), roll: tr.querySelector('.mroll') }; }
    function nextRoll(sec, except) {   // after the highest roll of that section: already used, or given on this page
        var top = 0;
        (taken[sec] || []).forEach(function (r) { top = Math.max(top, +r || 0); });
        rows.forEach(function (tr) { var c = cell(tr); if (tr !== except && c.sec.value === sec) top = Math.max(top, +c.roll.value.trim() || 0); });
        return top + 1;
    }
    function refresh() {
        var given = {}, per = {}, todo = 0, bad = 0;
        rows.forEach(function (tr) { var c = cell(tr), k = c.sec.value + '|' + c.roll.value.trim(); if (c.sec.value && c.roll.value.trim() !== '') given[k] = (given[k] || 0) + 1; });
        rows.forEach(function (tr) {
            var c = cell(tr), sec = c.sec.value, roll = c.roll.value.trim();
            var wrong = sec !== '' && roll !== '' && (!/^[1-9]\d{0,3}$/.test(roll) || (taken[sec] || []).indexOf(roll) !== -1 || given[sec + '|' + roll] > 1);
            tr.classList.toggle('unplaced', wrong);
            if (wrong) { bad++; return; }
            if (sec === '' || roll === '') { todo++; return; }
            var p = per[sec] = per[sec] || { Male: 0, Female: 0, Other: 0, lo: Infinity, hi: 0 };
            p[tr.dataset.g === 'Male' || tr.dataset.g === 'Female' ? tr.dataset.g : 'Other']++;
            p.lo = Math.min(p.lo, +roll); p.hi = Math.max(p.hi, +roll);
        });
        Object.keys(cards).forEach(function (sec) {
            var p = per[sec], span = cards[sec].querySelector('span');
            cards[sec].classList.toggle('empty', !p);
            if (!p) { span.textContent = 'nobody'; return; }
            span.innerHTML = [p.Male ? p.Male + ' boys' : '', p.Female ? p.Female + ' girls' : '', p.Other ? p.Other + ' other / not set' : ''].filter(Boolean).join(', ')
                + '<br>' + (p.lo === p.hi ? 'roll ' + p.lo : 'rolls ' + p.lo + '–' + p.hi);
        });
        var done = rows.length - todo - bad;
        status.textContent = done + ' of ' + rows.length + ' done' + (todo ? ' · ' + todo + ' still need a section and roll' : '')
            + (bad ? ' · ' + bad + ' to fix (red: a roll given twice, already used, or not 1–9999)' : '');
        status.classList.toggle('ok', done === rows.length);
        btn.disabled = done !== rows.length;
        return done === rows.length;
    }
    rows.forEach(function (tr) {
        var c = cell(tr);
        c.sec.addEventListener('change', function () { c.roll.value = c.sec.value ? nextRoll(c.sec.value, tr) : ''; refresh(); });
        c.roll.addEventListener('input', refresh);
        c.roll.addEventListener('keydown', function (e) {   // Enter: on to the next student shown, instead of sending the form
            if (e.key !== 'Enter') return;
            e.preventDefault();
            var next = tr.nextElementSibling;
            while (next && next.style.display === 'none') next = next.nextElementSibling;
            if (next) next.querySelector('.msec').focus();
        });
    });
    document.getElementById('mShow').addEventListener('change', function () {
        var only = { boys: 'Male', girls: 'Female' }[this.value];
        rows.forEach(function (tr) { tr.style.display = !only || tr.dataset.g === only ? '' : 'none'; });
    });
    document.getElementById('mOrder').addEventListener('change', function () {
        var key = 'by' + this.value.charAt(0).toUpperCase() + this.value.slice(1);
        rows.slice().sort(function (a, b) { return a.dataset[key] - b.dataset[key]; }).forEach(function (tr) { body.appendChild(tr); });
    });
    document.getElementById('mClear').addEventListener('click', function () {
        if (!confirm('Clear the new section and roll of every student?')) return;
        rows.forEach(function (tr) { var c = cell(tr); c.sec.value = ''; c.roll.value = ''; });
        refresh();
    });
    form.addEventListener('submit', function (e) {   // runs before the confirm below
        if (!refresh()) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        document.getElementById('manualRows').value = JSON.stringify(rows.map(function (tr) { var c = cell(tr); return [tr.dataset.uid, +c.sec.value, c.roll.value.trim()]; }));
    });
    refresh();
})();
</script>
<?php endif; ?>
<script>
document.getElementById('promoForm').addEventListener('submit', function (e) {
    if (!confirm(<?php echo json_encode('Promote ' . count($students) . " student(s) from $from to $to?", JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?>)) e.preventDefault();
});
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/promotion_helper.php';
require_once '../includes/hs_helper.php';

/**
 * Save a promotion. The plan is worked out again from the database and saved only if it is exactly the one the
 * preview showed and every student has a section. For each student the old year's row becomes History /
 * Promoted and the new session gets a Current row with the new section and roll; the batch and one detail row
 * per student keep the move so it can be rolled back. From XI to XII the class subjects and each student's
 * subjects follow. All of it is one transaction: every write is checked, and nothing stays unless all succeed.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: promotion.php'); exit(); }
verify_csrf_or_die();

$from_session_id = (int)($_POST['from_session_id'] ?? 0);
$from_class_id   = (int)($_POST['from_class_id'] ?? 0);
$to_session_id   = (int)($_POST['to_session_id'] ?? 0);
$method          = (string)($_POST['promotion_method'] ?? '');
$admin_id        = (int)($_SESSION['admin_id'] ?? 0);
$ids = fn($key) => $method === 'merit_distribution' ? array_values(array_unique(array_filter(array_map('intval', (array)($_POST[$key] ?? []))))) : [];
$boys = $ids('boys_sections'); $girls = $ids('girls_sections');
$steps = $method === 'section_steps' ? (array)($_POST['steps'] ?? []) : [];   // Section by Section; promotion_plan() checks them
$manual = $method === 'manual' ? promotion_manual_clean(json_decode((string)($_POST['manual_rows'] ?? ''), true)) : [];
$draft = "$from_session_id-$from_class_id-$to_session_id";
if ($method === 'manual') $_SESSION['promotion_manual'][$draft] = $manual;   // back on the preview if the save is refused
$where = ['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id];
$start = 'promotion.php?' . http_build_query($where);
$preview = 'promotion_preview.php?' . http_build_query($where + ['promotion_method' => $method, 'boys_sections' => $boys, 'girls_sections' => $girls, 'steps' => $steps]);
$fail = function (string $msg, string $to = '') use ($preview) { $_SESSION['error'] = $msg; header('Location: ' . ($to ?: $preview)); exit(); };

if (!isset(class_rows()[$from_class_id]) || !isset(PROMOTION_METHODS[$method])) $fail('Invalid promotion request — start again.', 'promotion.php');
$to_class_id = (int)promotion_next_class($from_class_id);
if (!$to_class_id) $fail(promotion_no_next_reason($from_class_id), $start);
if (!promotion_session_later($from_session_id, $to_session_id)) $fail('The new session must come after the old one.', $start);
if (!promotion_get_merit_count($conn, $from_session_id, $from_class_id)) $fail('The merit list has not been made for this session and class yet.', $start);
if (promotion_batch_exists($conn, $from_session_id, $from_class_id)) $fail('This session and class have already been promoted.', 'promotion_history.php');

$plan = promotion_plan($from_session_id, $from_class_id, $to_session_id, $to_class_id, $method, $boys, $girls, $steps, $manual);
if (!$plan['students']) $fail('No student of this class is waiting to go up — nothing was promoted.', $start);
if (!hash_equals($plan['key'], (string)($_POST['plan_key'] ?? ''))) $fail('Something changed since the preview (a student, a roll or the merit list) — nothing was promoted. Check this new preview and confirm again.');
if ($plan['unplaced']) {
    $why = $method === 'manual' ? array_values(array_map(fn($st) => "{$st['uid']}: {$st['note']}", array_filter($plan['students'], fn($st) => $st['new_section'] === null))) : [];
    $fail($plan['unplaced'] . ' student(s) have no section' . ($why ? ' or a roll that cannot be given (' . implode('; ', array_slice($why, 0, 5)) . (count($why) > 5 ? ' …' : '') . ')' : '') . ' — nothing was promoted.');
}
$moves = $plan['students'];

db_begin_transaction();
try {
    // the unique (from session, from class) key stops a second promotion of the same class
    $batch_id = (int)db_insert('promotion_batches', ['from_session_id' => $from_session_id, 'from_class_id' => $from_class_id, 'to_session_id' => $to_session_id,
        'to_class_id' => $to_class_id, 'promotion_method' => $method, 'total_students' => count($moves), 'promoted_by' => $admin_id ?: null]);
    if (!$batch_id) throw new RuntimeException('the promotion could not be recorded');
    $hs_to_hs = hs_is_hs_class($from_class_id) && hs_is_hs_class($to_class_id);   // XI → XII
    if ($hs_to_hs) {   // XII offers the subjects XI did
        db_execute('INSERT IGNORE INTO class_subjects (session_id, class_id, subject_id, has_exam) SELECT ?, ?, subject_id, has_exam FROM class_subjects WHERE session_id = ? AND class_id = ?',
            'iiii', $to_session_id, $to_class_id, $from_session_id, $from_class_id);
    }
    foreach ($moves as $uid => $st) {
        $uid = (string)$uid;
        if (db_execute("UPDATE student_academic_history SET promotion_status = 'Promoted', academic_status = 'History' WHERE student_id = ? AND session_id = ? AND class_id = ? AND academic_status = 'Current'",
                'sii', $uid, $from_session_id, $from_class_id) !== 1) throw new RuntimeException("$uid is no longer in the class");
        if (!db_insert('student_academic_history', ['student_id' => $uid, 'session_id' => $to_session_id, 'class_id' => $to_class_id, 'section_id' => $st['new_section'], 'roll_no' => $st['new_roll'],
                'promotion_status' => 'Studying', 'student_status' => 'Active', 'academic_status' => 'Current', 'previous_school' => $st['previous_school']])) throw new RuntimeException("$uid could not be placed in the new class");
        if (!db_insert('promotion_details', ['batch_id' => $batch_id, 'student_id' => $uid, 'gender' => in_array($st['gender'], ['Male', 'Female', 'Other'], true) ? $st['gender'] : null,
                'old_class_id' => $from_class_id, 'old_section_id' => $st['section_id'], 'old_roll_no' => $st['roll'], 'new_class_id' => $to_class_id, 'new_section_id' => $st['new_section'], 'new_roll_no' => $st['new_roll']])) throw new RuntimeException("$uid could not be recorded in the batch");

        // an HS student keeps their subject combination, as far as the new class offers it
        if ($hs_to_hs && !hs_student_subjects_one($to_session_id, $uid)) {
            $carry = array_values(array_intersect(array_keys(hs_student_subjects_one($from_session_id, $uid)), array_keys(hs_class_subject_list($to_session_id, $to_class_id))));
            if ($carry) {
                $r = hs_subjects_save($to_session_id, $to_class_id, $uid, $carry, 0, false);
                if (!$r['ok']) throw new RuntimeException("HS subjects of $uid: {$r['error']}");
            }
        }
    }
    db_commit();
} catch (Throwable $e) {
    db_rollback();
    $fail((int)$e->getCode() === 1062 ? 'This class was promoted a moment ago, or a roll was taken meanwhile — nothing was changed. Check the preview again.' : 'Promotion failed, nothing was changed: ' . $e->getMessage());
}
unset($_SESSION['promotion_manual'][$draft]);

log_action($admin_id, 'PROMOTION_DONE', 'promotion_batches', $batch_id, null,
    ['from' => [$from_session_id, $from_class_id], 'to' => [$to_session_id, $to_class_id], 'method' => $method, 'students' => count($moves)]);
$_SESSION['success'] = count($moves) . ' student(s) promoted.';
header("Location: promotion_history.php?batch_id=$batch_id");
exit();

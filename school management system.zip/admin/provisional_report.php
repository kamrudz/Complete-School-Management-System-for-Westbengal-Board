<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/routine_helper.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Substitution reports:  day (who covered what) · month (teacher × date substitution counts) ·
 * teacher-wise (range: own periods, lost to absence, covered, taken as substitute).  Excel for each.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$session_id = (int)($active['id'] ?? 0);
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$view = in_array($_GET['view'] ?? '', ['day', 'month', 'teacher'], true) ? $_GET['view'] : 'day';
$date = (string)($_GET['date'] ?? date('Y-m-d')); if (!DateTime::createFromFormat('Y-m-d', $date)) $date = date('Y-m-d');
$month = (int)($_GET['month'] ?? date('n')); $year = (int)($_GET['year'] ?? date('Y')); if ($month < 1 || $month > 12) $month = (int)date('n'); if ($year < 2000 || $year > 2100) $year = (int)date('Y');
$from = (string)($_GET['from'] ?? date('Y-m-01')); $to = (string)($_GET['to'] ?? date('Y-m-d'));
if (!DateTime::createFromFormat('Y-m-d', $from)) $from = date('Y-m-01'); if (!DateTime::createFromFormat('Y-m-d', $to)) $to = date('Y-m-d'); if ($from > $to) $from = $to;
$teachers = routine_teachers();
$status_word = ['absent' => 'Absent', 'leave' => 'On leave', 'on_duty' => 'On duty', 'present' => 'Present'];

if ($view === 'day') {
    $unit_label = []; $unit_of = [];
    foreach (db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order') as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $unit_label[$k] = $c['class_name'] . '-' . $u['label']; foreach ($u['section_ids'] as $sid) $unit_of[$sid] = $k; }
    $rows = db_get_all('SELECT p.*, sub.subject_name, o.staff_name AS orig_name, s.staff_name AS sub_name, a.full_name FROM provisional_routine p LEFT JOIN subjects sub ON sub.id = p.original_subject_id LEFT JOIN staff o ON o.id = p.original_teacher_id LEFT JOIN staff s ON s.id = p.provisional_teacher_id LEFT JOIN admins a ON a.id = p.created_by WHERE p.session_id = ? AND p.provisional_date = ? ORDER BY p.period_id, p.id', 'is', $session_id, $date);
    $pord = array_flip(array_map(fn($p) => (int)$p['id'], routine_periods()));
    $list = [];
    foreach ($rows as $r) { $k = $r['period_id'] . '|' . $r['original_teacher_id'] . '|' . $r['original_subject_id'] . '|' . $r['adjustment_type'] . '|' . $r['provisional_teacher_id']; $u = $unit_of[(int)$r['section_id']] ?? ('s' . $r['section_id']); $list[$k] = $list[$k] ?? $r + ['units' => []]; $list[$k]['units'][$u] = $unit_label[$u] ?? '?'; }
    uasort($list, fn($a, $b) => [$pord[(int)$a['period_id']] ?? 99, implode(',', $a['units'])] <=> [$pord[(int)$b['period_id']] ?? 99, implode(',', $b['units'])]);
    $absent = []; foreach (db_get_all("SELECT t.teacher_id, t.attendance_status, s.staff_name FROM teacher_attendance t JOIN staff s ON s.id = t.teacher_id WHERE t.attendance_date = ? AND t.attendance_status IN ('absent','leave','on_duty') ORDER BY s.staff_name", 's', $date) as $r) $absent[] = $r;
    $closed = db_get_all('SELECT c.class_name, cc.reason FROM closed_classes cc JOIN classes c ON c.id = cc.class_id WHERE cc.session_id = ? AND cc.closed_date = ? ORDER BY c.sort_order', 'is', $session_id, $date);
    $closedp = db_get_all('SELECT p.period_name, cp.reason FROM closed_periods cp JOIN periods p ON p.id = cp.period_id WHERE cp.session_id = ? AND cp.closed_date = ? ORDER BY p.sort_order', 'is', $session_id, $date);
    $xlsx = [['Period', 'Class', 'Subject', 'Absent teacher', 'Substitute / status', 'Note']];
    foreach ($list as $r) { asort($r['units']); $xlsx[] = [routine_period_name((int)$r['period_id']), implode(' + ', $r['units']), $r['subject_name'] ?? '', $r['orig_name'] ?? '', $r['adjustment_type'] === 'closed' ? 'Class closed' : ($r['sub_name'] ?: 'not covered'), $r['reason'] ?? '']; }
    $title = 'Substitution — ' . date('l d-m-Y', strtotime($date));
} elseif ($view === 'month') {
    $first = sprintf('%04d-%02d-01', $year, $month); $last = date('Y-m-t', strtotime($first)); if ($last > date('Y-m-d')) $last = date('Y-m-d');
    $dl = routine_daily_load($session_id, $first, $last); $days = array_keys($dl['days']);
    $tot = []; $cnt = []; foreach ($dl['load'] as $d => $per) foreach ($per as $t => $l) { if ($l['subs']) { $cnt[$t][$d] = $l['subs']; $tot[$t] = ($tot[$t] ?? 0) + $l['subs']; } }
    $days_with = count(array_filter($dl['load'], fn($per) => array_sum(array_column($per, 'subs')) > 0));
    $xlsx = [array_merge(['Teacher'], array_map(fn($d) => (int)substr($d, 8, 2), $days), ['Total'])];
    foreach ($teachers as $id => $t) { if (empty($tot[$id])) continue; $line = [$t['staff_name']]; foreach ($days as $d) $line[] = $cnt[$id][$d] ?? ''; $line[] = $tot[$id]; $xlsx[] = $line; }
    $title = 'Substitutions given — ' . date('F Y', strtotime($first));
} else {
    $dl = routine_daily_load($session_id, $from, $to);
    $sum = []; $absent_days = [];
    foreach ($dl['load'] as $d => $per) foreach ($per as $t => $l) { $sum[$t] = $sum[$t] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'uncovered' => 0]; foreach (['regular', 'closed', 'subs', 'lost'] as $k) $sum[$t][$k] += $l[$k]; if (in_array($l['status'], ['absent', 'leave', 'on_duty'], true)) { $absent_days[$t] = ($absent_days[$t] ?? 0) + 1; $sum[$t]['uncovered'] += max(0, $l['regular'] - $l['lost']); } }
    $working = count($dl['load']);
    $xlsx = [['Teacher', 'Designation', 'Days away', 'Own periods (planned)', 'Handed to a substitute', 'Not covered while away', 'Closed', 'Taken as substitute']];
    foreach ($teachers as $id => $t) { $s = $sum[$id] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'uncovered' => 0]; $xlsx[] = [$t['staff_name'], $t['designation'], (int)($absent_days[$id] ?? 0), $s['regular'] + $s['lost'], $s['lost'], $s['uncovered'], $s['closed'], $s['subs']]; }
    $title = 'Teacher-wise substitution — ' . date('d-m-Y', strtotime($from)) . ' to ' . date('d-m-Y', strtotime($to)) . " ($working working days)";
}
if (!empty($_GET['xlsx'])) SimpleXLSXWriter::download('substitution_' . $view . '_' . date('Y-m-d') . '.xlsx', $xlsx, 'Substitution', ['header_rows' => 1, 'freeze_rows' => 1]);
$q = array_filter(['view' => $view, 'date' => $view === 'day' ? $date : null, 'month' => $view === 'month' ? $month : null, 'year' => $view === 'month' ? $year : null, 'from' => $view === 'teacher' ? $from : null, 'to' => $view === 'teacher' ? $to : null]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Substitution Reports</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #5a2d0c 0%, #b0632a 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(90,45,12,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #f5e3d3; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #5a2d0c; }
    .tabs { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; } .tabs a { padding: 8px 16px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #5a2d0c; text-decoration: none; font-weight: 600; font-size: 13.5px; } .tabs a.on { background: #5a2d0c; color: #fff; border-color: #5a2d0c; }
    .hd { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; } .hd h3 { margin: 0; font-size: 15px; color: #5a2d0c; }
    .lc-table th { background: #5a2d0c; } .lc-table td.num { text-align: center; font-variant-numeric: tabular-nums; } .lc-table td.per { font-weight: 800; color: #5a2d0c; } .lc-table td.no { color: #9d2630; font-weight: 700; } .lc-table td.cl { color: #6b7d90; font-style: italic; }
    .side { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; font-size: 12.5px; } .side span { background: #f3f6f9; border-radius: 999px; padding: 4px 11px; } .side span.a { background: #fde2e4; color: #9d2630; } .side span.l { background: #fff6e5; color: #9a5a00; } .side span.o { background: #dbeafe; color: #1e40af; } .side span.c { background: #eef2f6; color: #4d6178; }
    .rg-wrap { overflow: auto; border: 1px solid #dfe7ef; border-radius: 10px; background: #fff; } table.rg { border-collapse: collapse; font-size: 12px; min-width: 100%; } .rg th, .rg td { border: 1px solid #e6edf3; padding: 3px 4px; text-align: center; white-space: nowrap; } .rg th { background: #5a2d0c; color: #fff; font-size: 11px; position: sticky; top: 0; } .rg th small { display: block; font-weight: 400; font-size: 9px; opacity: .85; } .rg th.off { background: #6b7d90; } .rg td.off { background: #eef2f6; } .rg .nm { text-align: left; min-width: 160px; position: sticky; left: 0; background: #fff; } .rg th.nm { z-index: 2; } .rg td.v { background: #fff3e6; color: #7a4a00; font-weight: 800; } .rg td.tot { font-weight: 800; background: #f8fafc; }
    .print-head { display: none; }
    @media print { @page { size: A4 landscape; margin: 8mm; } html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; } .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; } .rt-banner, .tabs, .lc-filter { display: none !important; } .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #5a2d0c; padding-bottom: 6px; margin-bottom: 8px; } .print-head img { width: 44px; height: 44px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #5a2d0c; } .print-head small { color: #444; font-size: 10.5px; } .rg-wrap { border: 0; overflow: visible; } .rg .nm { position: static; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — <?php echo h($title); ?></h2><small>printed <?php echo date('d-m-Y'); ?></small></div></div>
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-chart-bar"></i></div>
        <div><h1>Substitution Reports</h1><p>Who covered whom, how often each teacher substitutes, and what was lost or closed while teachers were away.</p></div>
        <div class="links"><a href="provisional_routine.php"><i class="fas fa-exchange-alt"></i> Substitution</a><a href="teacher_workload_report.php"><i class="fas fa-balance-scale"></i> Workload</a><a href="#" onclick="window.print();return false;"><i class="fas fa-print"></i> Print</a><a href="?<?php echo h(http_build_query($q + ['xlsx' => 1])); ?>" class="solid"><i class="fas fa-file-excel"></i> Excel</a></div>
    </div>
    <div class="tabs"><a href="?view=day" class="<?php echo $view === 'day' ? 'on' : ''; ?>"><i class="fas fa-calendar-day"></i> One day</a><a href="?view=month" class="<?php echo $view === 'month' ? 'on' : ''; ?>"><i class="fas fa-calendar-alt"></i> Month</a><a href="?view=teacher" class="<?php echo $view === 'teacher' ? 'on' : ''; ?>"><i class="fas fa-user-tie"></i> Teacher-wise</a></div>
    <form method="get" class="lc-filter">
        <input type="hidden" name="view" value="<?php echo $view; ?>">
        <?php if ($view === 'day'): ?><div><label>Date</label><input type="date" name="date" value="<?php echo h($date); ?>"></div>
        <?php elseif ($view === 'month'): ?><div><label>Month</label><select name="month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m === $month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 1)); ?></option><?php endfor; ?></select></div><div><label>Year</label><select name="year"><?php for ($y = (int)date('Y') - 3; $y <= (int)date('Y'); $y++): ?><option value="<?php echo $y; ?>" <?php echo $y === $year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
        <?php else: ?><div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div><div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>"></div><?php endif; ?>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="hd"><h3><?php echo h($title); ?></h3></div>

    <?php if ($view === 'day'): ?>
        <div class="side"><?php foreach ($absent as $a): ?><span class="<?php echo $a['attendance_status'][0]; ?>"><?php echo h($a['staff_name']); ?> · <?php echo h($status_word[$a['attendance_status']]); ?></span><?php endforeach; ?><?php foreach ($closed as $c): ?><span class="c">Class <?php echo h($c['class_name']); ?> closed<?php echo $c['reason'] ? ' — ' . h($c['reason']) : ''; ?></span><?php endforeach; ?><?php foreach ($closedp as $c): ?><span class="c"><?php echo h($c['period_name']); ?> closed<?php echo $c['reason'] ? ' — ' . h($c['reason']) : ''; ?></span><?php endforeach; ?></div>
        <?php if (!$list): ?><div class="lc-empty"><i class="fas fa-calendar-check"></i>No substitution recorded for this date.</div>
        <?php else: ?><table class="lc-table"><thead><tr><th>Period</th><th>Class</th><th>Subject</th><th>Absent teacher</th><th>Substitute</th><th>Note</th></tr></thead><tbody>
        <?php foreach ($list as $r): asort($r['units']); ?><tr><td class="per"><?php echo h(routine_period_name((int)$r['period_id'])); ?></td><td><?php echo h(implode(' + ', $r['units'])); ?></td><td><?php echo h($r['subject_name'] ?? ''); ?></td><td><?php echo h($r['orig_name'] ?? ''); ?></td><td class="<?php echo $r['adjustment_type'] === 'closed' ? 'cl' : ($r['sub_name'] ? '' : 'no'); ?>"><?php echo $r['adjustment_type'] === 'closed' ? 'Class closed' : h($r['sub_name'] ?: 'not covered'); ?></td><td><?php echo h($r['reason'] ?? ''); ?></td></tr><?php endforeach; ?>
        </tbody></table><p style="color:#6b7d90;font-size:12px;margin-top:8px">Saved by <?php echo h(reset($list)['full_name'] ?: 'admin'); ?> at <?php echo date('d-m-Y H:i', strtotime(reset($list)['created_at'])); ?></p><?php endif; ?>

    <?php elseif ($view === 'month'): ?>
        <?php if (!$tot): ?><div class="lc-empty"><i class="fas fa-calendar-check"></i>No substitutions in this month.</div>
        <?php else: ?><div class="side"><span><?php echo $days_with; ?> day<?php echo $days_with === 1 ? '' : 's'; ?> with substitutions</span><span><?php echo array_sum($tot); ?> periods covered</span></div>
        <div class="rg-wrap"><table class="rg"><thead><tr><th class="nm">Teacher</th><?php foreach ($days as $d): $i = $dl['days'][$d]; ?><th class="<?php echo $i['sunday'] || $i['holiday'] ? 'off' : ''; ?>" title="<?php echo h($i['holiday'] ?? ($i['sunday'] ? 'Sunday' : date('l', strtotime($d)))); ?>"><?php echo (int)substr($d, 8, 2); ?><small><?php echo substr(date('D', strtotime($d)), 0, 2); ?></small></th><?php endforeach; ?><th>Total</th></tr></thead><tbody>
        <?php foreach ($teachers as $id => $t): if (empty($tot[$id])) continue; ?><tr><td class="nm"><b><?php echo h($t['staff_name']); ?></b></td><?php foreach ($days as $d): $i = $dl['days'][$d]; $v = $cnt[$id][$d] ?? 0; ?><td class="<?php echo $i['sunday'] || $i['holiday'] ? 'off' : ($v ? 'v' : ''); ?>"><?php echo $v ?: ''; ?></td><?php endforeach; ?><td class="tot"><?php echo $tot[$id]; ?></td></tr><?php endforeach; ?>
        </tbody></table></div><?php endif; ?>

    <?php else: ?>
        <table class="lc-table"><thead><tr><th>Teacher</th><th>Days away</th><th>Own periods planned</th><th>Handed to a substitute</th><th>Not covered while away</th><th>Closed</th><th>Taken as substitute</th></tr></thead><tbody>
        <?php foreach ($teachers as $id => $t): $s = $sum[$id] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'uncovered' => 0]; ?><tr><td><b><?php echo h($t['staff_name']); ?></b><br><small style="color:#6b7d90"><?php echo h($t['designation']); ?></small></td><td class="num"><?php echo (int)($absent_days[$id] ?? 0); ?></td><td class="num"><?php echo $s['regular'] + $s['lost']; ?></td><td class="num"><?php echo $s['lost']; ?></td><td class="num <?php echo $s['uncovered'] ? 'no' : ''; ?>"><?php echo $s['uncovered']; ?></td><td class="num"><?php echo $s['closed']; ?></td><td class="num"><b><?php echo $s['subs']; ?></b></td></tr><?php endforeach; ?>
        </tbody></table>
    <?php endif; ?>
</div>
</body>
</html>

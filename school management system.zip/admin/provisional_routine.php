<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/routine_helper.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Substitution (provisional routine) for one date.
 * Staff attendance says who is absent / on leave / on duty → their periods that day (one row per
 * routine unit) → a free teacher covers each, or the class is marked closed.  Classes or periods
 * closed for the day (exam, rain…) drop out of the list; a teacher can be excluded from substituting
 * that day.  Saved per section into provisional_routine (adjustment_type none = substitute, closed).
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$session_id = (int)($active['id'] ?? 0);
$date = (string)($_REQUEST['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !DateTime::createFromFormat('Y-m-d', $date)) $date = date('Y-m-d');
$block = attendance_day_block($date); if ($block === 'That date is in the future.' && $date <= date('Y-m-d', strtotime('+7 days'))) $block = '';   // substitutions may be planned a week ahead
$day = date('l', strtotime($date));
$self = 'provisional_routine.php?date=' . $date;
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$teachers = routine_teachers(); $periods = routine_periods($day); $pid_list = array_map(fn($p) => (int)$p['id'], $periods);
$prio = ['Assistant Teacher' => 1, 'Para Teacher' => 1, 'Librarian' => 2, 'Teacher-In-Charge' => 3, 'Assistant Headmaster' => 3, 'Headmaster' => 4];

// ── who is unavailable today (staff attendance) and who is excluded from substituting
$att = []; foreach (db_get_all('SELECT teacher_id, attendance_status FROM teacher_attendance WHERE attendance_date = ?', 's', $date) as $r) $att[(int)$r['teacher_id']] = $r['attendance_status'];
$att_taken = count($att) > 0;
$unavailable = array_filter($att, fn($s) => in_array($s, ['absent', 'leave', 'on_duty'], true));
$excluded = []; foreach (db_get_all('SELECT teacher_id FROM teacher_exclusions WHERE session_id = ? AND provisional_date = ?', 'is', $session_id, $date) as $r) $excluded[(int)$r['teacher_id']] = true;
$closed_classes = []; foreach (db_get_all('SELECT class_id, reason FROM closed_classes WHERE session_id = ? AND closed_date = ?', 'is', $session_id, $date) as $r) $closed_classes[(int)$r['class_id']] = $r['reason'];
$closed_periods = []; foreach (db_get_all('SELECT period_id, reason FROM closed_periods WHERE session_id = ? AND closed_date = ?', 'is', $session_id, $date) as $r) $closed_periods[(int)$r['period_id']] = $r['reason'];

// ── units and today's routine
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$unit_label = []; $unit_of = []; $unit_secs = [];
foreach ($classes as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $unit_label[$k] = $c['class_name'] . '-' . $u['label']; $unit_secs[$k] = $u['section_ids']; foreach ($u['section_ids'] as $sid) $unit_of[$sid] = $k; }
$rows = $session_id ? db_get_all('SELECT r.class_id, r.section_id, r.period_id, r.group_id, r.subject_id, r.teacher_id, sub.subject_name FROM routine r LEFT JOIN subjects sub ON sub.id = r.subject_id WHERE r.session_id = ? AND r.day_name = ? AND r.teacher_id IS NOT NULL', 'is', $session_id, $day) : [];
// busy map for the day (teacher => pid => true), ignoring closed classes/periods; and the slots needing cover
$busy = []; $slots = [];
foreach ($rows as $r) {
    $t = (int)$r['teacher_id']; $pid = (int)$r['period_id']; $cid = (int)$r['class_id'];
    if (!in_array($pid, $pid_list, true)) continue;
    if (!isset($closed_classes[$cid]) && !isset($closed_periods[$pid])) $busy[$t][$pid] = true;
    if (!isset($unavailable[$t])) continue;
    $uk = $unit_of[(int)$r['section_id']] ?? ('s' . $r['section_id']);
    // one room = one slot: a unit's row, or a combined class (group -1) spanning several units
    $key = ((int)$r['group_id'] < 0 ? 'c' : $uk) . '|' . $pid . '|' . $r['group_id'] . '|' . $r['subject_id'];
    $slots[$key] = $slots[$key] ?? ['key' => $key, 'units' => [], 'class_id' => $cid, 'period_id' => $pid, 'group_id' => (int)$r['group_id'], 'subject_id' => (int)$r['subject_id'], 'subject' => $r['subject_name'] ?? '—', 'teacher_id' => $t, 'sections' => [], 'closed_reason' => $closed_classes[$cid] ?? ($closed_periods[$pid] ?? null)];
    $slots[$key]['units'][$uk] = $unit_label[$uk] ?? '?';
    $slots[$key]['sections'][(int)$r['section_id']] = true;
}
foreach ($slots as &$sl) { $sl['sections'] = array_keys($sl['sections']); asort($sl['units']); $sl['label'] = implode(' + ', $sl['units']); $sl['first'] = $sl['sections'][0]; } unset($sl);
$porder = array_flip($pid_list);
uasort($slots, fn($a, $b) => [$porder[$a['period_id']], $a['label']] <=> [$porder[$b['period_id']], $b['label']]);
// existing substitutions for the date, by slot
$existing = []; $taken_by = null;
foreach (db_get_all('SELECT p.*, a.full_name FROM provisional_routine p LEFT JOIN admins a ON a.id = p.created_by WHERE p.session_id = ? AND p.provisional_date = ? ORDER BY p.id', 'is', $session_id, $date) as $r) {
    $existing[$r['section_id'] . '|' . $r['period_id'] . '|' . (int)$r['original_subject_id']] = $r;
    if (!$taken_by) $taken_by = ($r['full_name'] ?: 'admin') . ' at ' . date('d-m-Y H:i', strtotime($r['created_at']));
}
// today's load per teacher (own periods + substitutions already saved) for the candidate ordering
$load = []; foreach ($busy as $t => $pp) $load[$t] = count($pp);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if ($block) { $_SESSION['error'] = 'No substitution on this day — ' . $block; header('Location: ' . $self); exit(); }
    if (isset($_POST['toggle_exclude'])) {
        $t = (int)$_POST['toggle_exclude'];
        if (isset($teachers[$t])) { if (isset($excluded[$t])) db_execute('DELETE FROM teacher_exclusions WHERE session_id = ? AND teacher_id = ? AND provisional_date = ?', 'iis', $session_id, $t, $date); else db_execute('INSERT IGNORE INTO teacher_exclusions (session_id, teacher_id, provisional_date) VALUES (?, ?, ?)', 'iis', $session_id, $t, $date); }
        header('Location: ' . $self); exit();
    }
    if (isset($_POST['save_closed'])) {
        $cc = array_values(array_filter(array_map('intval', (array)($_POST['closed_classes'] ?? [])))); $cp = array_values(array_filter(array_map('intval', (array)($_POST['closed_periods'] ?? []))));
        $reason = mb_substr(trim((string)($_POST['closed_reason'] ?? '')), 0, 200);
        $valid_c = array_map(fn($c) => (int)$c['id'], $classes);
        db_begin_transaction();
        try {
            db_execute('DELETE FROM closed_classes WHERE session_id = ? AND closed_date = ?', 'is', $session_id, $date); db_execute('DELETE FROM closed_periods WHERE session_id = ? AND closed_date = ?', 'is', $session_id, $date);
            foreach ($cc as $c) if (in_array($c, $valid_c, true)) db_insert('closed_classes', ['session_id' => $session_id, 'class_id' => $c, 'closed_date' => $date, 'reason' => $reason ?: null]);
            foreach ($cp as $p) if (in_array($p, $pid_list, true)) db_insert('closed_periods', ['session_id' => $session_id, 'period_id' => $p, 'closed_date' => $date, 'reason' => $reason ?: null]);
            db_commit();
        } catch (Throwable $e) { db_rollback(); error_log('closed save: ' . $e->getMessage()); $_SESSION['error'] = 'Could not save.'; header('Location: ' . $self); exit(); }
        log_action($admin_id, 'DAY_CLOSURES_SAVED', 'closed_classes', $date, null, ['classes' => $cc, 'periods' => $cp, 'reason' => $reason]);
        $_SESSION['success'] = 'Closed classes / periods saved for ' . date('d-m-Y', strtotime($date)) . '.'; header('Location: ' . $self); exit();
    }
    if (isset($_POST['save_subs'])) {
        $in = json_decode((string)($_POST['subs'] ?? ''), true); if (!is_array($in)) $in = [];
        $reason = mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 200);
        $errors = []; $used = []; $plan = [];
        foreach ($slots as $key => $sl) {
            if ($sl['closed_reason'] !== null) continue;
            $c = $in[$key] ?? null; $sub = (int)($c['t'] ?? 0); $closed = !empty($c['closed']);
            if ($closed) { $plan[] = $sl + ['sub' => 0, 'closed' => true]; continue; }
            if (!$sub) { $plan[] = $sl + ['sub' => 0, 'closed' => false]; continue; }
            $lbl = $sl['label'] . ' ' . routine_period_name($sl['period_id']);
            if (!isset($teachers[$sub])) { $errors[] = "$lbl: unknown teacher."; continue; }
            if (isset($unavailable[$sub])) { $errors[] = "$lbl: " . $teachers[$sub]['staff_name'] . ' is not present today.'; continue; }
            if (isset($excluded[$sub])) { $errors[] = "$lbl: " . $teachers[$sub]['staff_name'] . ' is excluded today.'; continue; }
            if (!empty($busy[$sub][$sl['period_id']])) { $errors[] = "$lbl: " . $teachers[$sub]['staff_name'] . ' has a class in that period.'; continue; }
            if (isset($used[$sub][$sl['period_id']])) { $errors[] = "$lbl: " . $teachers[$sub]['staff_name'] . ' is already substituting in that period.'; continue; }
            $used[$sub][$sl['period_id']] = true;
            $plan[] = $sl + ['sub' => $sub, 'closed' => false];
        }
        if ($errors) { $_SESSION['error'] = implode(' · ', array_slice($errors, 0, 6)); header('Location: ' . $self); exit(); }
        $n_sub = 0; $n_closed = 0; $n_open = 0;
        db_begin_transaction();
        try {
            db_execute('DELETE FROM provisional_routine WHERE session_id = ? AND provisional_date = ?', 'is', $session_id, $date);
            foreach ($plan as $p) {
                if ($p['sub']) $n_sub++; elseif ($p['closed']) $n_closed++; else $n_open++;
                foreach ($p['sections'] as $sid) db_insert('provisional_routine', ['session_id' => $session_id, 'class_id' => $p['class_id'], 'section_id' => $sid, 'day_name' => $day, 'period_id' => $p['period_id'], 'provisional_date' => $date, 'original_teacher_id' => $p['teacher_id'], 'original_subject_id' => $p['subject_id'] ?: null, 'provisional_teacher_id' => $p['sub'] ?: null, 'provisional_subject_id' => $p['sub'] ? ($p['subject_id'] ?: null) : null, 'status' => $p['sub'] ? 'assigned' : 'unassigned', 'adjustment_type' => $p['closed'] ? 'closed' : 'none', 'reason' => $reason ?: null, 'created_by' => $admin_id]);
            }
            db_commit();
        } catch (Throwable $e) { db_rollback(); error_log('substitution save: ' . $e->getMessage()); $_SESSION['error'] = 'Could not save — nothing was changed.'; header('Location: ' . $self); exit(); }
        log_action($admin_id, 'SUBSTITUTION_SAVED', 'provisional_routine', $date, null, ['date' => $date, 'substituted' => $n_sub, 'closed' => $n_closed, 'uncovered' => $n_open]);
        $_SESSION['success'] = "Substitution saved for " . date('d-m-Y', strtotime($date)) . " — $n_sub covered, $n_closed closed" . ($n_open ? ", $n_open still without a teacher" : '') . '.';
        header('Location: ' . $self); exit();
    }
}

// ── candidates per period: present, not excluded, free — ordered by designation, then today's own load (the page adds substitutions as they are picked)
$subj_of = []; foreach (db_get_all("SELECT id, subject_name FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'") as $r) $subj_of[(int)$r['id']] = mb_strtolower((string)$r['subject_name']);
$cand = [];
foreach ($pid_list as $pid) {
    $list = [];
    foreach ($teachers as $id => $t) { if (isset($unavailable[$id]) || isset($excluded[$id]) || !empty($busy[$id][$pid])) continue; $list[] = ['id' => $id, 'code' => $t['short_code'], 'name' => $t['staff_name'], 'subj' => $subj_of[$id] ?? '', 'load' => (int)($load[$id] ?? 0), 'prio' => $prio[$t['designation']] ?? 2]; }
    usort($list, fn($a, $b) => [$a['prio'], $a['load'], $a['name']] <=> [$b['prio'], $b['load'], $b['name']]);
    $cand[$pid] = $list;
}
$jslots = []; foreach ($slots as $key => $sl) { $e = $existing[$sl['first'] . '|' . $sl['period_id'] . '|' . $sl['subject_id']] ?? null; $jslots[] = ['key' => $key, 'label' => $sl['label'], 'period_id' => $sl['period_id'], 'period' => routine_period_name($sl['period_id']), 'subject' => $sl['subject'], 'subj' => mb_strtolower($sl['subject']), 'teacher' => $teachers[$sl['teacher_id']]['staff_name'] ?? '?', 'code' => $teachers[$sl['teacher_id']]['short_code'] ?? '', 'status' => $unavailable[$sl['teacher_id']] ?? '', 'closed_reason' => $sl['closed_reason'], 't' => $e ? (int)$e['provisional_teacher_id'] : 0, 'closed' => $e ? $e['adjustment_type'] === 'closed' : false]; }
$payload = ['slots' => $jslots, 'cand' => $cand, 'periods' => array_map(fn($p) => ['id' => (int)$p['id'], 'name' => $p['period_name']], $periods)];
$unavail_list = []; foreach ($unavailable as $t => $st) if (isset($teachers[$t])) $unavail_list[] = ['t' => $teachers[$t], 'status' => $st, 'n' => count(array_filter($slots, fn($s) => $s['teacher_id'] === $t))];
$status_word = ['absent' => 'Absent', 'leave' => 'On leave', 'on_duty' => 'On duty'];
$print = !empty($_GET['print']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Substitution</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #5a2d0c 0%, #b0632a 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(90,45,12,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #f5e3d3; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #5a2d0c; }
    .at-block { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 12px; padding: 12px 16px; margin-bottom: 14px; font-size: 14px; display: flex; gap: 10px; align-items: center; } .at-block i { font-size: 20px; }
    .warn { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 10px; padding: 9px 13px; font-size: 13px; margin-bottom: 12px; }
    .cols { display: grid; grid-template-columns: 1fr 320px; gap: 16px; align-items: start; } @media (max-width: 960px) { .cols { grid-template-columns: 1fr; } }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 14px 16px; margin-bottom: 14px; } .card h2 { margin: 0 0 8px; font-size: 15px; color: #5a2d0c; display: flex; align-items: center; gap: 8px; } .card h2 small { font-weight: 400; color: #6b7d90; font-size: 12px; }
    .un { display: flex; gap: 8px; flex-wrap: wrap; } .un span { border-radius: 999px; padding: 4px 11px; font-size: 12.5px; font-weight: 700; border: 1px solid; } .un .absent { background: #fde2e4; color: #9d2630; border-color: #f5b5bb; } .un .leave { background: #fff6e5; color: #9a5a00; border-color: #f0c987; } .un .on_duty { background: #dbeafe; color: #1e40af; border-color: #b7d0f5; } .un span small { font-weight: 400; }
    table.sb { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 13px; } .sb th { background: #5a2d0c; color: #fff; padding: 8px 10px; text-align: left; font-size: 11.5px; text-transform: uppercase; } .sb td { padding: 7px 10px; border-bottom: 1px solid #e6edf3; vertical-align: middle; }
    .sb tr.p-first td { border-top: 2px solid #b0632a; } .sb td.per { font-weight: 800; color: #5a2d0c; white-space: nowrap; } .sb td.cl { font-weight: 700; color: #10253a; } .sb td.cl small { display: block; color: #6b7d90; font-weight: 400; }
    .sb td.orig small { display: block; font-size: 11px; } .sb td.orig .absent { color: #9d2630; } .sb td.orig .leave { color: #9a5a00; } .sb td.orig .on_duty { color: #1e40af; }
    .sb select { height: 32px; padding: 3px 6px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 12.5px; min-width: 200px; max-width: 100%; } .sb select.ok { border-color: #1b7a3d; background: #f3faf5; } .sb select.dup { border-color: #d63a4a; background: #fde2e4; }
    .sb td.closedcell { color: #6b7d90; font-style: italic; } .sb label.cl { font-size: 12px; white-space: nowrap; display: inline-flex; align-items: center; gap: 4px; margin-left: 8px; color: #3b5168; }
    .chips { display: flex; gap: 6px; flex-wrap: wrap; } .chips form { margin: 0; } .chips button { border: 1px solid #c9d6e2; background: #fff; border-radius: 999px; padding: 4px 10px; font-size: 12px; font-weight: 700; color: #1f4e79; cursor: pointer; } .chips button.ex { background: #5a2d0c; color: #fff; border-color: #5a2d0c; text-decoration: line-through; }
    .cc { display: grid; grid-template-columns: 1fr 1fr; gap: 6px 10px; font-size: 13px; } .cc label { display: flex; align-items: center; gap: 6px; } .cc input[type=text] { grid-column: 1 / -1; height: 34px; padding: 5px 9px; border: 1px solid #c9d6e2; border-radius: 7px; }
    .savebar { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-top: 12px; } .savebar input[type=text] { height: 36px; padding: 5px 10px; border: 1px solid #c9d6e2; border-radius: 7px; flex: 1; min-width: 200px; }
    .counts { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; } .counts span { padding: 4px 11px; border-radius: 999px; font-weight: 700; font-size: 12.5px; background: #f3f6f9; color: #10253a; } .counts .ok { background: #d7f3e1; color: #1b7a3d; } .counts .bad { background: #fde2e4; color: #9d2630; } .counts .cl { background: #eef2f6; color: #4d6178; }
    .taken { font-size: 12.5px; color: #6b7d90; background: #f3f6f9; padding: 4px 10px; border-radius: 999px; }
    .print-head { display: none; } .slip { display: none; }
    @media print { @page { size: A4; margin: 10mm; } html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; } .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; } .page-box > *:not(.slip) { display: none !important; } .slip { display: block; } .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #5a2d0c; padding-bottom: 6px; margin-bottom: 10px; } .print-head img { width: 46px; height: 46px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 16px; color: #5a2d0c; } .print-head small { color: #444; font-size: 11px; } table.slip-t { width: 100%; border-collapse: collapse; font-size: 12.5px; } .slip-t th, .slip-t td { border: 1px solid #999; padding: 5px 8px; text-align: left; } .slip-t th { background: #eee; } .slip-t td.per { font-weight: 800; } .slip p { font-size: 12px; color: #333; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-exchange-alt"></i></div>
        <div><h1>Substitution</h1><p><?php echo h(date('l, d F Y', strtotime($date))); ?> · absent / on-leave / on-duty teachers come from staff attendance; free teachers are offered by today's load, assistant teachers first.</p></div>
        <div class="links"><a href="teacher_attendance.php?attendance_date=<?php echo $date; ?>"><i class="fas fa-user-tie"></i> Staff attendance</a><a href="daywise_teacher_routine.php?day_name=<?php echo h($day === 'Sunday' ? 'Monday' : $day); ?>"><i class="fas fa-user-clock"></i> Who is free</a><a href="provisional_report.php"><i class="fas fa-chart-bar"></i> Reports</a><?php if ($slots): ?><a href="#" class="solid" onclick="window.print();return false;"><i class="fas fa-print"></i> Print slip</a><?php endif; ?></div>
    </div>
    <?php if (isset($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>
    <form method="get" class="lc-filter"><div><label>Date</label><input type="date" name="date" value="<?php echo h($date); ?>" max="<?php echo date('Y-m-d', strtotime('+7 days')); ?>"></div><button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Open</button>
        <a href="?date=<?php echo date('Y-m-d'); ?>" class="btn btn-secondary">Today</a><a href="?date=<?php echo date('Y-m-d', strtotime($date . ' -1 day')); ?>" class="btn btn-secondary"><i class="fas fa-chevron-left"></i></a><a href="?date=<?php echo date('Y-m-d', strtotime($date . ' +1 day')); ?>" class="btn btn-secondary"><i class="fas fa-chevron-right"></i></a></form>

    <?php if ($block): ?><div class="at-block"><i class="fas fa-calendar-times"></i><div>No substitution on <b><?php echo h(date('d M Y', strtotime($date))); ?></b> — <?php echo h($block); ?></div></div>
    <?php elseif (!$session_id): ?><div class="warn">No active session.</div>
    <?php else: ?>
    <?php if (!$att_taken): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> Staff attendance for this date has not been taken yet — <a href="teacher_attendance.php?attendance_date=<?php echo $date; ?>">take it first</a>; the list below is built from it.</div><?php endif; ?>
    <div class="cols">
        <div>
            <div class="card">
                <h2><i class="fas fa-user-slash"></i> Not available today <small><?php echo count($unavail_list); ?> teacher<?php echo count($unavail_list) === 1 ? '' : 's'; ?></small></h2>
                <?php if (!$unavail_list): ?><div style="color:#6b7d90;font-size:13px">Everyone is present<?php echo $att_taken ? '' : ' (attendance not taken)'; ?> — nothing to substitute.</div>
                <?php else: ?><div class="un"><?php foreach ($unavail_list as $u): ?><span class="<?php echo h($u['status']); ?>"><?php echo h($u['t']['staff_name']); ?> <small>· <?php echo h($status_word[$u['status']]); ?> · <?php echo (int)$u['n']; ?> period<?php echo $u['n'] === 1 ? '' : 's'; ?></small></span><?php endforeach; ?></div><?php endif; ?>
            </div>
            <?php if ($slots): ?>
            <div class="card">
                <h2><i class="fas fa-list"></i> Periods to cover <small><?php echo count($slots); ?></small><?php if ($taken_by): ?><span class="taken" style="margin-left:auto">Saved by <?php echo h($taken_by); ?></span><?php endif; ?></h2>
                <div class="counts" id="counts"></div>
                <div style="overflow-x:auto"><table class="sb" id="sb"><thead><tr><th>Period</th><th>Class</th><th>Absent teacher</th><th>Substitute</th></tr></thead><tbody></tbody></table></div>
                <form method="post" id="subForm" class="savebar">
                    <?php echo csrf_field(); ?><input type="hidden" name="date" value="<?php echo h($date); ?>"><input type="hidden" name="subs" id="subs">
                    <button type="button" class="btn btn-secondary" id="autoBtn"><i class="fas fa-magic"></i> Auto-fill empty</button>
                    <input type="text" name="reason" placeholder="Note (optional) — e.g. HM on duty at DI office" maxlength="200" value="<?php echo h($existing ? (reset($existing)['reason'] ?? '') : ''); ?>">
                    <button type="submit" name="save_subs" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save substitution</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <div>
            <div class="card">
                <h2><i class="fas fa-door-closed"></i> Closed today <small>no substitute needed</small></h2>
                <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="date" value="<?php echo h($date); ?>">
                    <div class="cc">
                        <?php foreach ($classes as $c): ?><label><input type="checkbox" name="closed_classes[]" value="<?php echo (int)$c['id']; ?>" <?php echo isset($closed_classes[(int)$c['id']]) ? 'checked' : ''; ?>> Class <?php echo h($c['class_name']); ?></label><?php endforeach; ?>
                        <?php foreach ($periods as $p): ?><label><input type="checkbox" name="closed_periods[]" value="<?php echo (int)$p['id']; ?>" <?php echo isset($closed_periods[(int)$p['id']]) ? 'checked' : ''; ?>> <?php echo h($p['period_name']); ?> (all classes)</label><?php endforeach; ?>
                        <input type="text" name="closed_reason" placeholder="Reason — exam, rain, function…" maxlength="200" value="<?php echo h(reset($closed_classes) ?: (reset($closed_periods) ?: '')); ?>">
                    </div>
                    <button type="submit" name="save_closed" value="1" class="btn btn-primary" style="margin-top:8px"><i class="fas fa-save"></i> Save closed</button>
                </form>
            </div>
            <div class="card">
                <h2><i class="fas fa-user-minus"></i> Not to be used as substitute today <small>click to toggle</small></h2>
                <div class="chips"><?php foreach ($teachers as $id => $t): if (isset($unavailable[$id])) continue; ?><form method="post"><?php echo csrf_field(); ?><input type="hidden" name="date" value="<?php echo h($date); ?>"><button type="submit" name="toggle_exclude" value="<?php echo $id; ?>" class="<?php echo isset($excluded[$id]) ? 'ex' : ''; ?>" title="<?php echo h($t['staff_name']); ?>"><?php echo h($t['short_code'] ?: $t['staff_name']); ?></button></form><?php endforeach; ?></div>
            </div>
        </div>
    </div>

    <div class="slip">
        <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — Substitution, <?php echo h(date('l d-m-Y', strtotime($date))); ?></h2><small>printed <?php echo date('d-m-Y H:i'); ?></small></div></div>
        <?php if ($unavail_list): ?><p>Not available: <?php echo h(implode(', ', array_map(fn($u) => $u['t']['staff_name'] . ' (' . $status_word[$u['status']] . ')', $unavail_list))); ?></p><?php endif; ?>
        <table class="slip-t"><thead><tr><th>Period</th><th>Class</th><th>Subject</th><th>Absent teacher</th><th>Substitute</th></tr></thead><tbody>
        <?php foreach ($slots as $sl): $e = $existing[$sl['first'] . '|' . $sl['period_id'] . '|' . $sl['subject_id']] ?? null; ?><tr><td class="per"><?php echo h(routine_period_name($sl['period_id'])); ?></td><td><?php echo h($sl['label']); ?></td><td><?php echo h($sl['subject']); ?></td><td><?php echo h($teachers[$sl['teacher_id']]['staff_name'] ?? ''); ?></td><td><?php echo $sl['closed_reason'] !== null ? 'Closed — ' . h($sl['closed_reason']) : ($e && $e['adjustment_type'] === 'closed' ? 'Class closed' : ($e && $e['provisional_teacher_id'] ? '<b>' . h($teachers[(int)$e['provisional_teacher_id']]['staff_name'] ?? '') . '</b>' : '—')); ?></td></tr><?php endforeach; ?>
        </tbody></table>
        <?php if ($existing && reset($existing)['reason']): ?><p>Note: <?php echo h(reset($existing)['reason']); ?></p><?php endif; ?>
    </div>

    <?php if ($slots): ?>
    <script id="sb-data" type="application/json"><?php echo json_encode($payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
    <script>
    (function () {
        var D = JSON.parse(document.getElementById('sb-data').textContent), state = {};
        D.slots.forEach(function (s) { state[s.key] = {t: s.t, closed: s.closed}; });
        function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
        function usedIn(pid, except) { var u = {}; D.slots.forEach(function (s) { if (s.period_id === pid && s.key !== except && state[s.key].t) u[state[s.key].t] = (u[state[s.key].t] || 0) + 1; }); return u; }
        function subCount() { var n = {}; D.slots.forEach(function (s) { if (state[s.key].t) n[state[s.key].t] = (n[state[s.key].t] || 0) + 1; }); return n; }
        function options(s) {
            var used = usedIn(s.period_id, s.key), n = subCount(), html = '<option value="0">— choose —</option>';
            (D.cand[s.period_id] || []).forEach(function (c) { var extra = (n[c.id] || 0) - (state[s.key].t === c.id ? 1 : 0), busy = !!used[c.id]; html += '<option value="' + c.id + '"' + (state[s.key].t === c.id ? ' selected' : '') + (busy ? ' disabled' : '') + '>' + (c.subj && s.subj && c.subj === s.subj ? '★ ' : '') + esc(c.code ? c.code + ' — ' : '') + esc(c.name) + ' (' + (c.load + extra) + ' today' + (busy ? ', already substituting' : '') + ')</option>'; });
            return html;
        }
        function render() {
            var tb = document.querySelector('#sb tbody'), html = '', last = null, ok = 0, bad = 0, cl = 0;
            D.slots.forEach(function (s) {
                var st = state[s.key], first = s.period_id !== last; last = s.period_id;
                html += '<tr class="' + (first ? 'p-first' : '') + '" data-key="' + esc(s.key) + '"><td class="per">' + esc(s.period) + '</td><td class="cl">' + esc(s.label) + '<small>' + esc(s.subject) + '</small></td><td class="orig">' + esc(s.teacher) + '<small class="' + esc(s.status) + '">' + esc({absent: 'Absent', leave: 'On leave', on_duty: 'On duty'}[s.status] || '') + '</small></td>';
                if (s.closed_reason !== null) { html += '<td class="closedcell">Closed — ' + esc(s.closed_reason) + '</td></tr>'; cl++; return; }
                if (st.closed) { html += '<td class="closedcell">Class closed this period <label class="cl"><input type="checkbox" data-act="closed" checked> closed</label></td></tr>'; cl++; return; }
                html += '<td><select data-act="t" class="' + (st.t ? 'ok' : '') + '">' + options(s) + '</select><label class="cl"><input type="checkbox" data-act="closed"> closed</label></td></tr>';
                if (st.t) ok++; else bad++;
            });
            tb.innerHTML = html;
            document.getElementById('counts').innerHTML = '<span class="ok">' + ok + ' covered</span><span class="bad">' + bad + ' without teacher</span><span class="cl">' + cl + ' closed</span>';
        }
        document.getElementById('sb').addEventListener('change', function (e) {
            var tr = e.target.closest('tr'), key = tr.dataset.key; if (!key) return;
            if (e.target.dataset.act === 't') state[key].t = parseInt(e.target.value, 10) || 0;
            if (e.target.dataset.act === 'closed') { state[key].closed = e.target.checked; if (e.target.checked) state[key].t = 0; }
            render();
        });
        document.getElementById('autoBtn').addEventListener('click', function () {
            D.slots.forEach(function (s) {
                if (s.closed_reason !== null || state[s.key].closed || state[s.key].t) return;
                var used = usedIn(s.period_id, s.key), n = subCount(), best = null, bestScore = 1e9;
                (D.cand[s.period_id] || []).forEach(function (c) { if (used[c.id]) return; var score = c.prio * 1000 + (c.load + (n[c.id] || 0)) * 10 - (c.subj && c.subj === s.subj ? 5 : 0); if (score < bestScore) { bestScore = score; best = c.id; } });
                if (best) state[s.key].t = best;
            });
            render();
        });
        document.getElementById('subForm').addEventListener('submit', function () { document.getElementById('subs').value = JSON.stringify(state); });
        render();
    })();
    </script>
    <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * Progress report card — one A4 page per student of a class/section (or a single student with ?uid=).
 * Term-wise subject marks, formative (Primary & Upper Primary — shown only, never added), annual total / % / grade / result / rank, attendance, class teacher and HM.
 */
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? exam_active_session_id()); if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
/*
 * One student's sheet from the Roll No. box of the filter row (exam_find_students() also reads a
 * Banglar Shiksha ID, PEN or School UID given as ?find=, for a link from elsewhere). A single match
 * goes straight to that student's sheet in their own class and section; a roll used in several
 * sections is listed to pick from; no match is said so.
 */
$find = trim((string)($_GET['find'] ?? ''));
$found = [];
// the Roll box of the filter row is the same lookup, held to a roll number inside the chosen class
$roll_q = trim((string)($_GET['roll'] ?? ''));
if ($find === '' && $roll_q !== '') {
    if (!preg_match('/^\d{1,4}$/', $roll_q)) {
        $_SESSION['error'] = 'Roll No. takes one roll number, such as 12.';
        header('Location: report_card.php?session_id=' . $session_id . '&section=' . urlencode((string)($_GET['section'] ?? '')) . '&class_id=' . (int)($_GET['class_id'] ?? 0) . '&section_id=' . urlencode((string)($_GET['section_id'] ?? 'all'))); exit;
    }
    $find = $roll_q;
}
if ($find !== '') {
    $fc = (int)($_GET['class_id'] ?? 0);
    $fs = (string)($_GET['section_id'] ?? 'all');
    $r = exam_find_students($session_id, $find, $fc, $fs === 'all' || $fs === '' ? null : (int)$fs);
    $back = 'report_card.php?session_id=' . $session_id . '&section=' . urlencode((string)($_GET['section'] ?? '')) . ($fc ? '&class_id=' . $fc . '&section_id=' . urlencode($fs) : '');
    if (count($r['hits']) === 1) {
        $h = reset($r['hits']);
        if (!in_array($h['stage'], EXAM_STAGES, true)) {
            $_SESSION['error'] = $h['name'] . ' is in Class ' . $h['class'] . ' — open the HS Mark Sheet for that class.';
            header('Location: ' . $back); exit;
        }
        header('Location: report_card.php?session_id=' . $session_id . '&section=' . exam_section_of_stage($h['stage']) . '&class_id=' . $h['class_id']
            . '&section_id=' . $h['section_id'] . '&uid=' . urlencode($h['uid'])); exit;
    }
    if (!$r['hits']) {
        $_SESSION['error'] = $r['need_class'] ? 'A roll number is only unique inside a class — choose the class (and section) first, then search the roll.'
            : ($r['kind'] === '' ? 'Type a roll number, a Banglar Shiksha ID (14 digits), a PEN (11 digits) or a School UID.'
            : 'No current student found for "' . $find . '".');
        header('Location: ' . $back); exit;
    }
    $found = $r['hits'];   // several: the page lists them to pick from
}
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = null;
$only = student_uid_clean((string)($_GET['uid'] ?? ''));
$print = !empty($_GET['print']);
$ready = $class_id > 0;
$qs = "session_id=$session_id&class_id=$class_id&section=$section&section_id=" . ($section_id ?: 'all') . ($only !== '' ? '&uid=' . urlencode($only) : '');
$res = $ready ? result_annual($session_id, $class_id, $section_id, true) : null;   // also those promoted or passed out since
$students = $res['students'] ?? []; $subjects = $res['subjects'] ?? []; $exams = $res['exams'] ?? []; $formative = $res['formative'] ?? false;
if ($only !== '') $students = isset($students[$only]) ? [$only => $students[$only]] : [];
$school = db_get_row('SELECT school_name, school_address, udise_code, established_year, school_code, hs_code, logo, hoi_name, hoi_signature FROM school_settings WHERE id = 1') ?: [];
$teachers = []; $att = []; $working = [];
if ($ready) {
    foreach (db_get_all('SELECT sec.id, st.staff_name FROM sections sec LEFT JOIN staff st ON st.id = sec.class_teacher_id WHERE sec.session_id = ? AND sec.class_id = ?', 'ii', $session_id, $class_id) as $r) $teachers[(int)$r['id']] = (string)$r['staff_name'];
    foreach (db_get_all("SELECT student_id, SUM(status = 'Present') AS p, COUNT(*) AS n FROM student_attendance WHERE session_id = ? AND class_id = ? GROUP BY student_id", 'ii', $session_id, $class_id) as $r) $att[$r['student_id']] = [(int)$r['p'], (int)$r['n']];
    foreach (db_get_all('SELECT section_id, COUNT(DISTINCT attendance_date) AS d FROM student_attendance WHERE session_id = ? AND class_id = ? GROUP BY section_id', 'ii', $session_id, $class_id) as $r) $working[(int)$r['section_id']] = (int)$r['d'];
}
$short = fn($name) => preg_replace('/^(\d)(st|nd|rd|th) /', '$1', str_ireplace('Summative', 'S', $name));
$ex_cell = function ($v): string { if ($v === null) return '—'; if ($v === 'AB') return 'AB'; return exam_fmt($v); };

/**
 * Secondary (IX–X) is issued in the WBBSE Madhyamik mark sheet layout the board itself uses:
 * FULL MARKS split into written and internal, MARKS OBTAINED exam by exam, then the total and the
 * grade; the grand total in words; Result as P / Comp / N; the grade scale printed at the foot.
 */
$board = $section === 'sec';
$photos = []; $mother = [];
if ($ready && $board && $students) {
    $ids = array_keys($students);
    $in = implode(',', array_fill(0, count($ids), '?'));
    foreach (db_get_all("SELECT s.id, s.photo, g.mother_name FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id WHERE s.id IN ($in)", str_repeat('s', count($ids)), ...$ids) as $r) {
        $photos[$r['id']] = (string)$r['photo']; $mother[$r['id']] = (string)$r['mother_name'];
    }
}
/**
 * Each examination's own full marks, for the column heads: the school's report card prints
 * "1st — W (40) · P (10) · T (50)" once at the top instead of repeating the full marks on every row.
 * When an examination does not carry the same full marks for every subject, the head is left plain
 * and each subject's own total is printed beside its marks instead.
 */
$exam_fm = [];
if ($ready && $board) {
    foreach ($exams as $e) {
        $eid = (int)$e['id'];
        $cfg = array_filter(exam_subjects($session_id, $eid, $class_id), fn($s) => $s['configured']);
        $pairs = [];
        foreach ($subjects as $sid => $s) if (isset($cfg[$sid])) $pairs[exam_fmt($cfg[$sid]['written_full']) . '|' . exam_fmt($cfg[$sid]['project_full'])] = $cfg[$sid];
        $one = count($pairs) === 1 ? reset($pairs) : null;
        $exam_fm[$eid] = ['uniform' => (bool)$one, 'w' => $one['written_full'] ?? 0, 'p' => $one['project_full'] ?? 0, 't' => $one['full'] ?? 0];
    }
}
$year_full_uniform = null;   // the year's full marks per subject, when every subject carries the same
if ($ready && $board && $students) {
    $fulls = [];
    $first = reset($students);
    foreach ($subjects as $sid => $s) if (isset($first['subjects'][$sid])) $fulls[exam_fmt($first['subjects'][$sid]['full'])] = $first['subjects'][$sid]['full'];
    if (count($fulls) === 1) $year_full_uniform = reset($fulls);
}
$bands = $board ? grade_bands(class_stage($class_id) ?: 'secondary') : [];
$result_word = ['PASS' => 'P', 'PUC' => 'Comp', 'FAIL' => 'N', 'ABSENT' => '—'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Report Card</title>
<?php exam_styles(); ?>
<style>
    .rc { background: #fff; border: 1px solid #cfd8e3; border-radius: 10px; padding: 18px 22px; margin: 0 auto 18px; max-width: 900px; page-break-after: always; font-size: 12.5px; color: #111; position: relative; }
    .rc .head { display: flex; align-items: center; gap: 14px; border-bottom: 2px solid #3b1d5c; padding-bottom: 8px; margin-bottom: 10px; } .rc .head img { height: 60px; } .rc .head .n { font-size: 20px; font-weight: 800; color: #3b1d5c; letter-spacing: .5px; } .rc .head .a { font-size: 11px; color: #444; } .rc .head .t { margin-left: auto; text-align: right; } .rc .head .t b { display: block; font-size: 15px; } .rc .head .t span { font-size: 11px; color: #555; }
    .rc .who { display: grid; grid-template-columns: repeat(3, 1fr); gap: 4px 16px; margin-bottom: 10px; } .rc .who div { font-size: 12px; } .rc .who div b { color: #000; }
    .rc table { width: 100%; border-collapse: collapse; } .rc th, .rc td { border: 1px solid #999; padding: 4px 6px; text-align: center; font-size: 12px; } .rc th { background: #f3eef8; font-size: 11px; } .rc td.l { text-align: left; font-weight: 600; } .rc td.f { color: #b71c1c; font-weight: 700; }
    .rc .foot { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; margin-top: 12px; } .rc .box { border: 1px solid #999; border-radius: 6px; padding: 8px 10px; font-size: 12px; } .rc .box b { display: block; font-size: 11px; color: #555; text-transform: uppercase; margin-bottom: 4px; } .rc .big { font-size: 20px; font-weight: 800; color: #3b1d5c; }
    .rc .sign { display: flex; justify-content: space-between; margin-top: 34px; font-size: 11.5px; } .rc .sign div { text-align: center; border-top: 1px solid #333; padding-top: 4px; min-width: 150px; } .rc .sign img { height: 34px; display: block; margin: -40px auto 4px; }
    .rc .stamp { position: absolute; right: 22px; top: 96px; padding: 3px 10px; border: 2px solid; border-radius: 6px; font-weight: 800; font-size: 13px; transform: rotate(-6deg); }
    @media print { .rc { border: 0; border-radius: 0; margin: 0; max-width: none; padding: 0; } }

    /* ── Secondary: the WBBSE Madhyamik mark sheet layout ── */
    /* the sheet is one A4 page: it fills the width and the height, with the signatures at the very foot */
    .mk { position: relative; background: #fff; border: 3px double #1a3d7a; border-radius: 6px; padding: 10px 12px 8px; margin: 0 auto 18px;
          width: 194mm; min-height: 281mm; box-sizing: border-box; color: #10203a; font-size: 14px; page-break-after: always; overflow: hidden;
          display: flex; }
    .mk:last-child { page-break-after: auto; }
    .mk::before { content: ''; position: absolute; inset: 5px; border: 1px solid #9db4d6; border-radius: 4px; pointer-events: none; }
    .mk .wm { position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); width: 120mm; opacity: .06; pointer-events: none; }
    .mk .in { position: relative; z-index: 1; display: flex; flex-direction: column; flex: 1; width: 100%; }
    .mk .hd { text-align: center; border-bottom: 2px solid #1a3d7a; padding-bottom: 6px; }
    .mk .hd img.logo { height: 52px; float: left; }
    .mk .hd h1 { margin: 0; font-size: 27px; letter-spacing: 1.2px; color: #1a3d7a; text-transform: uppercase; }
    .mk .hd .ad { font-size: 13px; color: #3c5169; margin-top: 3px; }
    .mk .hd .ti { margin-top: 6px; font-size: 17px; font-weight: 800; letter-spacing: 2px; color: #10203a; }
    .mk .hd .ti small { display: block; font-weight: 600; letter-spacing: .5px; font-size: 13.5px; color: #3c5169; margin-top: 3px; }
    /* the student block reads as a form: a ruled panel of labelled fields with the photograph beside it */
    .mk .who { display: flex; gap: 0; margin: 8px 0 0; align-items: stretch; border: 1px solid #5c7ba6; background: #fbfdff; }
    .mk .who .fields { flex: 1; display: grid; grid-template-columns: repeat(6, 1fr); }
    .mk .who .f { padding: 5px 9px; border-right: 1px dotted #9db4d6; border-bottom: 1px dotted #9db4d6; min-width: 0; }
    .mk .who .f.s2 { grid-column: span 2; } .mk .who .f.s3 { grid-column: span 3; }
    .mk .who .f:nth-last-child(-n+3) { border-bottom: 0; }   /* the last row */
    .mk .who .f span { display: block; font-size: 9.5px; letter-spacing: .5px; text-transform: uppercase; color: #5f7d96; }
    .mk .who .f b { display: block; font-size: 14px; color: #10203a; letter-spacing: .2px; line-height: 1.25; min-height: 17px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .mk .who .ph { width: 30mm; height: 37mm; align-self: center; margin: 5px 6px; border: 1.5px solid #1a3d7a; border-radius: 3px; object-fit: cover; background: #fff; padding: 3px; }
    .mk .who .ph.none { display: flex; align-items: center; justify-content: center; font-size: 9px; color: #93a6bd; border-style: dashed; text-align: center; box-sizing: border-box; }
    /*
     * global-responsive.css pads every cell 6px 8px !important below 768px wide, and a printed A4 page is
     * only ~733px wide, so on paper it would swell every row and push the signatures off the sheet; the
     * sheet's own cell padding is therefore !important too. global-responsive.js also wraps each table in
     * a scroll box with a top margin, which must add nothing here.
     */
    .mk .auto-table-scroll { margin: 0; border-radius: 0; overflow: visible; }
    .mk table.mkt { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; table-layout: fixed; }
    .mk table.mkt th, .mk table.mkt td { border: 1px solid #5c7ba6; padding: 5px 3px !important; text-align: center; white-space: normal; }
    .mk table.mkt thead th { background: #e8f0fb; color: #1a3d7a; font-size: 12px; letter-spacing: .3px; line-height: 1.2; padding: 6px 3px !important; } .mk table.mkt thead th.sm { font-size: 10px; letter-spacing: 0; font-weight: 600; padding: 3px 1px !important; line-height: 1.15; white-space: nowrap; }
    .mk table.mkt td.sub { text-align: left; font-weight: 700; letter-spacing: 0; padding-left: 7px !important; font-size: 12.5px; line-height: 1.15; }
    .mk table.mkt tr.grp td { background: #f4f7fc; font-weight: 700; font-size: 11px; letter-spacing: 1.3px; text-align: left; color: #46617f; padding: 5px 8px !important; }
    .mk table.mkt td.tot { font-weight: 800; background: #f6f9fd; } .mk table.mkt td.gr { font-weight: 800; color: #1a3d7a; }
    /* the obtained half is tinted, so the eye tells the two blocks apart at a glance */
    .mk table.mkt th.ob, .mk table.mkt td.ob { background: #eef6ee; } .mk table.mkt td.tot.ob { background: #e2f0e2; }
    .mk table.mkt tr.sum td { background: #e8f0fb; font-weight: 800; } .mk table.mkt tr.sum td.ob { background: #ddecdd; } .mk table.mkt tr.sum.full td { background: #f2f6fc; font-weight: 700; } .mk table.mkt tr.sum.full td.ob { background: #eaf3ea; } .mk table.mkt td small { font-size: 8px; color: #5c7ba6; font-weight: 400; }
    .mk table.mkt td.f { color: #b71c1c; font-weight: 800; }
    .mk .gt { display: flex; align-items: center; gap: 12px; border: 1px solid #5c7ba6; border-top: 0; padding: 8px 10px; font-size: 14px; background: #f6f9fd; }
    .mk .gt b { font-size: 18px; color: #1a3d7a; } .mk .gt .w { font-style: italic; color: #3c5169; }
    .mk .rs { display: flex; gap: 12px; margin-top: 12px; font-size: 13.5px; }
    .mk .rs div { border: 1px solid #5c7ba6; border-radius: 5px; padding: 7px 14px; } .mk .rs b { font-size: 17px; color: #1a3d7a; }
    /* only the grade scale is compact; the RESULT note beside it keeps the sheet's reading size */
    .mk .legend { display: grid; grid-template-columns: 70mm 1fr; gap: 14px; margin-top: 8px; font-size: 12.5px; align-items: start; }
    .mk .legend table { width: 100%; border-collapse: collapse; font-size: 11px; }
    .mk .legend td, .mk .legend th { border: 1px solid #8aa3c4; padding: 1px 6px !important; line-height: 1.2; white-space: nowrap; }
    .mk .legend th { background: #e8f0fb; font-size: 10.5px; } .mk .legend .note { color: #3c5169; line-height: 1.5; }
    .mk .sg { display: flex; justify-content: space-between; margin-top: auto; padding-top: 16mm; font-size: 12.5px; }
    .mk .sg div { text-align: center; min-width: 52mm; } .mk .sg img { height: 32px; display: block; margin: 0 auto 2px; }
    .mk .sg .ln { border-top: 1px solid #10203a; padding-top: 3px; }
    .mk .ov { display: flex; align-items: stretch; border: 1px solid #5c7ba6; border-top: 0; background: #f6f9fd; }
    .mk .ov .lbl { display: flex; align-items: center; padding: 0 12px; font-weight: 800; font-size: 12px; letter-spacing: .6px; color: #1a3d7a; background: #e8f0fb; border-right: 1px solid #5c7ba6; }
    .mk .ov .cell { flex: 1; text-align: center; padding: 5px 4px; border-right: 1px solid #b9cde4; }
    .mk .ov .cell:last-child { border-right: 0; }
    .mk .ov .cell span { display: block; font-size: 10.5px; color: #46617f; letter-spacing: .3px; }
    .mk .ov .cell b { display: block; font-size: 18px; color: #1a3d7a; line-height: 1.2; }
    .mk .ov .cell small { display: block; font-size: 9.5px; color: #5c7ba6; font-style: italic; }
    .mk .ov .cell.res b { color: #1b7a3a; }
    .mk .pub { margin-top: 6px; font-size: 12.5px; }
    /* on paper the sheet keeps filling the page, so the signatures still fall at the foot */
    /*
     * On paper every sheet is exactly one A4 page: the printable area is 297 − 2×8 = 281mm tall, the
     * sheet is fixed at 279mm (a little under, for the printer's rounding), nothing around it takes any
     * room, and a sheet is never split across pages. The last sheet does not push a blank page after it.
     */
    @media print {
        html, body { margin: 0 !important; padding: 0 !important; background: #fff !important; min-height: 0 !important; }
        .page-box { margin: 0 !important; padding: 0 !important; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; max-width: none !important; background: none !important; }
        .navbar, .main-navbar-2tier, .ex-banner, .ex-tabs, .ex-steps, .pick, .alert, .noprint { display: none !important; }
        .mk { width: 194mm; height: 279mm; min-height: 0; margin: 0; border-width: 2px; box-shadow: none; overflow: hidden;
              break-inside: avoid; page-break-inside: avoid; break-after: page; page-break-after: always; }
        .mk.last { break-after: auto; page-break-after: auto; }
        * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
    @page { size: A4 portrait; margin: 8mm; }
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if ($print): ?><div class="noprint" style="margin-bottom:8px;text-align:center"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print <?php echo count($students); ?> card<?php echo count($students) === 1 ? '' : 's'; ?></button> <a href="report_card.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php else: ?>
        <?php exam_banner('Report Card', 'Progress report of every student — one page each. Marks of the counting exams, annual total, grade, result, rank and attendance.', 'fa-id-card', $ready && $students ? ["report_card.php?$qs&print=1" => '<i class="fas fa-print"></i> Print all'] : []); ?>
        <?php exam_tabs('report_card.php', EXAM_PAGES, "section=$section"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
            <?php $shown_roll = ($only !== '' && isset($students[$only])) ? $students[$only]['roll'] : ''; ?>
            <div><label>Session</label><select name="session_id" onchange="this.form.class_id.value='';this.form.roll.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.roll.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
            <div><label>Section</label><select name="section_id" onchange="this.form.roll.value='';this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
            <div><label>Roll No.</label><input type="text" name="roll" value="<?php echo h($shown_roll); ?>" inputmode="numeric" maxlength="4" placeholder="All" style="width:90px;min-width:0" <?php echo $class_id ? '' : 'disabled'; ?> title="One roll number for that student's mark sheet; leave empty for everyone"></div>
            <div><label>&nbsp;</label><button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button></div>
            <?php if ($only !== ''): ?><div><label>&nbsp;</label><a class="btn btn-secondary" href="report_card.php?session_id=<?php echo $session_id; ?>&section=<?php echo h($section); ?>&class_id=<?php echo $class_id; ?>&section_id=<?php echo $section_id ?: 'all'; ?>"><i class="fas fa-users"></i> Everyone in <?php echo $section_id ? 'the section' : 'the class'; ?></a></div><?php endif; ?>
        </form>


        <?php if ($found): ?>
        <div class="card" style="margin-bottom:12px">
            <h2><i class="fas fa-user-friends"></i> <?php echo count($found); ?> students match "<?php echo h($find); ?>" <small>pick one</small></h2>
            <table class="ex-table"><thead><tr><th>Class</th><th>Section</th><th>Roll</th><th>Student</th><th>Father</th><th>School UID</th><th></th></tr></thead><tbody>
            <?php foreach ($found as $h): ?>
                <tr><td><?php echo h($h['class']); ?></td><td><?php echo h($h['section']); ?></td><td><?php echo h($h['roll']); ?></td><td><b><?php echo h($h['name']); ?></b></td><td><?php echo h($h['father']); ?></td><td><?php echo h($h['uid']); ?></td>
                    <td><a class="btn btn-primary btn-sm" href="report_card.php?session_id=<?php echo $session_id; ?>&section=<?php echo h(exam_section_of_stage($h['stage'])); ?>&class_id=<?php echo $h['class_id']; ?>&section_id=<?php echo $h['section_id']; ?>&uid=<?php echo urlencode($h['uid']); ?>"><i class="fas fa-id-card"></i> Mark sheet</a></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ($found): ?>
    <?php elseif (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-id-card"></i>Select a class, or find one student above.</div></div>
    <?php elseif (!$exams || !$subjects): ?><div class="card"><div class="ex-empty"><i class="fas fa-clipboard-list"></i>No counting exam with full marks for this class yet.</div></div>
    <?php elseif (!$students): ?><div class="card"><div class="ex-empty"><i class="fas fa-user-slash"></i>No student found.</div></div>
    <?php else: ?>
    <?php if (!$print) foreach ($res['warnings'] as $w): ?><div class="alert alert-warning" style="font-size:12.5px;padding:6px 10px"><i class="fas fa-exclamation-triangle"></i> <?php echo h($w); ?></div><?php endforeach; ?>
    <?php $last_uid = array_key_last($students); foreach ($students as $uid => $st): $a = $att[$uid] ?? null; $wd = $working[$st['section_id']] ?? 0; ?>
    <?php if ($board): $photo = $photos[$uid] ?? ''; $cols = 4 + count($exams) + 1; ?>
    <div class="mk<?php echo $uid === $last_uid ? ' last' : ''; ?>">
        <?php if (!empty($school['logo'])): ?><img class="wm" src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?>
        <div class="in">
            <div class="hd">
                <?php if (!empty($school['logo'])): ?><img class="logo" src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?>
                <h1><?php echo h($school['school_name'] ?? ''); ?></h1>
                <div class="ad"><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></div>
                <div class="ad"><?php
                    $codes = [];
                    if (!empty($school['school_code'])) $codes[] = 'Index No. ' . h($school['school_code']);
                    if (!empty($school['hs_code'])) $codes[] = 'H.S. Code ' . h($school['hs_code']);
                    if (!empty($school['udise_code'])) $codes[] = 'UDISE ' . h($school['udise_code']);
                    echo implode(' &nbsp;·&nbsp; ', $codes);
                ?></div>
                <div class="ti">PROGRESS REPORT CARD<small>Academic Session : <?php echo h(exam_session_name($session_id)); ?> &nbsp;·&nbsp; Class <?php echo h($classes[$class_id]['name']); ?></small></div>
            </div>

            <div class="who">
                <div class="fields">
                    <div class="f s3"><span>Name of the Student</span><b><?php echo h($st['name']); ?></b></div>
                    <div class="f"><span>Class</span><b><?php echo h($classes[$class_id]['name']); ?></b></div>
                    <div class="f"><span>Section</span><b><?php echo h($st['section']); ?></b></div>
                    <div class="f"><span>Roll No.</span><b><?php echo h($st['roll']); ?></b></div>
                    <div class="f s2"><span>Father's Name</span><b><?php echo h($st['father']); ?></b></div>
                    <div class="f s2"><span>Mother's Name</span><b><?php echo h($mother[$uid] ?? ''); ?></b></div>
                    <div class="f s2"><span>School UID</span><b><?php echo h($uid); ?></b></div>
                    <div class="f s2"><span>Date of Birth</span><b><?php echo $st['dob'] ? h(date('d-m-Y', strtotime($st['dob']))) : ''; ?></b></div>
                    <div class="f s2"><span>Banglar Shiksha ID</span><b><?php echo h($st['bsid']); ?></b></div>
                    <div class="f s2"><span>PEN</span><b><?php echo h($st['pen']); ?></b></div>
                </div>
                <?php if ($photo !== ''): ?><img class="ph" src="../uploads/students/<?php echo rawurlencode($photo); ?>" alt=""><?php else: ?><div class="ph none">Photograph</div><?php endif; ?>
            </div>

            <table class="mkt">
                <?php // the full marks live in the heads, so each row only carries what was obtained ?>
                <colgroup>
                    <col style="width:19%">
                    <?php foreach ($exams as $e): ?><col style="width:5.6%"><col style="width:5.6%"><col style="width:6.2%"><?php endforeach; ?>
                    <col style="width:8%"><col style="width:8%"><col style="width:7%">
                </colgroup>
                <thead>
                    <tr>
                        <th rowspan="2" style="text-align:left;padding-left:6px">NAME OF SUBJECT</th>
                        <?php foreach ($exams as $e): ?><th colspan="3"><?php echo h($e['exam_name']); ?></th><?php endforeach; ?>
                        <th rowspan="2">TOTAL<?php if ($year_full_uniform !== null): ?><br><small>(<?php echo exam_fmt($year_full_uniform); ?>)</small><?php endif; ?></th>
                        <th rowspan="2">MARKS<br><small>(%)</small></th>
                        <th rowspan="2">GRADE</th>
                    </tr>
                    <tr>
                        <?php foreach ($exams as $e): $fm = $exam_fm[(int)$e['id']] ?? null; ?>
                            <th class="sm">W<?php if ($fm && $fm['uniform']): ?><br>(<?php echo exam_fmt($fm['w']); ?>)<?php endif; ?></th>
                            <th class="sm">P<?php if ($fm && $fm['uniform']): ?><br>(<?php echo exam_fmt($fm['p']); ?>)<?php endif; ?></th>
                            <th class="sm">T<?php if ($fm && $fm['uniform']): ?><br>(<?php echo exam_fmt($fm['t']); ?>)<?php endif; ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($subjects as $sid => $s): $x = $st['subjects'][$sid] ?? null; if (!$x) continue; ?>
                    <tr>
                        <td class="sub"><?php echo h($s['name']); ?></td>
                        <?php foreach ($exams as $e): $eid = (int)$e['id'];
                            $fm = $exam_fm[$eid] ?? null; $fp = $x['exams_full_p'][$eid] ?? null; $ft = $x['exams_full'][$eid] ?? null; ?>
                            <td><?php echo $ex_cell($x['exams_w'][$eid] ?? null); ?></td>
                            <td><?php echo $fp === null ? '—' : ($fp <= 0 ? '–' : $ex_cell($x['exams_p'][$eid] ?? null)); ?></td>
                            <td class="tot"><?php echo $ex_cell($x['exams'][$eid] ?? null);
                                if ($ft !== null && $fm && !$fm['uniform']) echo '<small>/' . exam_fmt($ft) . '</small>'; ?></td>
                        <?php endforeach; ?>
                        <td class="tot ob <?php echo $x['fail'] ? 'f' : ''; ?>"><?php echo $x['absent'] ? 'AB' : exam_fmt($x['obtained']) . ($x['grace'] > 0 ? '†' : ''); ?><?php if ($year_full_uniform === null) echo '<small>/' . exam_fmt($x['full']) . '</small>'; ?></td>
                        <td class="ob"><?php echo $x['full'] > 0 && !$x['absent'] ? exam_fmt(round($x['obtained'] / $x['full'] * 100, 2)) : '—'; ?></td>
                        <td class="gr"><?php echo h($x['grade']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="sum">
                        <td class="sub">TOTAL MARKS OBTAIN</td>
                        <?php foreach ($exams as $e): $eid = (int)$e['id']; $ot = 0; $any = false;
                            foreach ($subjects as $sid => $s) { $x = $st['subjects'][$sid] ?? null; if (!$x) continue; $v = $x['exams'][$eid] ?? null; if (is_numeric($v)) { $ot += (float)$v; $any = true; } } ?>
                            <td>-</td><td>-</td><td class="tot"><?php echo $any ? exam_fmt($ot) : '—'; ?></td>
                        <?php endforeach; ?>
                        <td class="tot ob"><?php echo exam_fmt($st['total']); ?></td>
                        <td class="ob"><?php echo exam_fmt($st['pct']); ?></td>
                        <td class="gr"><?php echo h($st['grade']); ?></td>
                    </tr>
                    <tr class="sum full">
                        <td class="sub">TOTAL FULL MARKS</td>
                        <?php foreach ($exams as $e): $eid = (int)$e['id']; $ft = 0;
                            foreach ($subjects as $sid => $s) { $x = $st['subjects'][$sid] ?? null; if (!$x) continue; $ft += (float)($x['exams_full'][$eid] ?? 0); } ?>
                            <td>-</td><td>-</td><td class="tot"><?php echo exam_fmt($ft); ?></td>
                        <?php endforeach; ?>
                        <td class="tot ob"><?php echo exam_fmt($st['full']); ?></td>
                        <td class="ob"></td><td class="gr"></td>
                    </tr>
                </tbody>
            </table>
            <div class="ov">
                <div class="lbl">OVERALL MARKS</div>
                <div class="cell"><span>Marks Obtained</span><b><?php echo exam_fmt($st['total']); ?></b><small><?php echo h(exam_words((int)round($st['total']))); ?></small></div>
                <div class="cell"><span>Full Marks</span><b><?php echo exam_fmt($st['full']); ?></b></div>
                <div class="cell"><span>Marks (%)</span><b><?php echo exam_fmt($st['pct']); ?></b></div>
                <div class="cell"><span>Grade</span><b><?php echo h($st['grade']); ?></b></div>
                <div class="cell res"><span>Result</span><b><?php echo h($result_word[$st['status']] ?? ''); ?></b><small><?php echo h(result_label($st['status'])); ?></small></div>
                <div class="cell"><span>Rank</span><b><?php echo $st['rank'] ?? '—'; ?></b><small>in the <?php echo $section_id ? 'section' : 'class'; ?></small></div>
                <?php if ($a): ?><div class="cell"><span>Attendance</span><b><?php echo $a[0]; ?></b><small>of <?php echo $wd ?: $a[1]; ?> days</small></div><?php endif; ?>
            </div>

            <div class="pub">Date of publication: <b><?php echo date('d/m/Y'); ?></b></div>
<div class="legend">
                <?php $has_remark = (bool)array_filter(array_map(fn($b) => trim((string)$b['remark']), $bands)); ?>
                <table>
                    <thead><tr><th>Grade Scale</th><th>Grade</th><?php if ($has_remark): ?><th>Performance Indicator</th><?php endif; ?></tr></thead>
                    <tbody>
                    <?php foreach ($bands as $b): ?>
                        <tr><td><?php echo exam_fmt($b['min_pct']); ?>–<?php echo exam_fmt($b['max_pct']); ?></td><td style="font-weight:700"><?php echo h($b['grade']); ?></td><?php if ($has_remark): ?><td style="text-align:left"><?php echo h($b['remark']); ?></td><?php endif; ?></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="note">
                    <b>RESULT:</b> &nbsp; P — for a successful candidate &nbsp;·&nbsp; Comp — for a compartmental candidate &nbsp;·&nbsp; N — for an unsuccessful candidate.<br>
                    The overall grade is taken on the grand total of all subjects; the percentage is rounded to two decimals before the grade is read from the scale.
                    A subject below its pass marks is printed in red. † includes grace marks · AB absent · — not held or not entered.<br>
                    Marks shown under each examination are that examination's total for the subject (written + internal / project).
                </div>
            </div>

            <div class="sg">
                <div><div class="ln">Signature of the Class Teacher<br><small><?php echo h($teachers[$st['section_id']] ?? ''); ?></small></div></div>
                <div><div class="ln">Signature of the Guardian</div></div>
                <div><?php if (!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo h($school['hoi_signature']); ?>" alt=""><?php endif; ?><div class="ln">Signature of the Head of the Institution<br><small><?php echo h($school['hoi_name'] ?? ''); ?></small></div></div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="rc">
        <div class="head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?>
            <div><div class="n"><?php echo h($school['school_name'] ?? ''); ?></div><div class="a"><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['udise_code']) ? ' · UDISE ' . h($school['udise_code']) : ''; ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></div></div>
            <div class="t"><b>Progress Report</b><span>Session <?php echo h(exam_session_name($session_id)); ?></span></div></div>
        <div class="stamp" style="color:<?php echo ['PASS' => '#1b7a3a', 'PUC' => '#b26a00', 'FAIL' => '#b71c1c'][$st['status']] ?? '#616161'; ?>"><?php echo h(result_label($st['status'])); ?></div>
        <div class="who"><div>Name: <b><?php echo h($st['name']); ?></b></div><div>Class: <b><?php echo h($classes[$class_id]['name']); ?>-<?php echo h($st['section']); ?></b> &nbsp; Roll: <b><?php echo h($st['roll']); ?></b></div><div>UID: <b><?php echo h($uid); ?></b></div>
            <div>Father: <b><?php echo h($st['father']); ?></b></div><div>Date of birth: <b><?php echo $st['dob'] ? date('d-m-Y', strtotime($st['dob'])) : '—'; ?></b></div><div>Class teacher: <b><?php echo h($teachers[$st['section_id']] ?? '—'); ?></b></div></div>
        <table><thead><tr><th style="text-align:left">Subject</th><?php foreach ($exams as $e): ?><th><?php echo h($short($e['exam_name'])); ?></th><?php endforeach; ?><?php if ($formative): ?><th>Formative</th><?php endif; ?><th>Total</th><th>Full</th><th>Grade</th></tr></thead><tbody>
            <?php foreach ($subjects as $sid => $s): $x = $st['subjects'][$sid] ?? null; if (!$x) continue; ?>
            <tr><td class="l"><?php echo h($s['name']); ?></td><?php foreach ($exams as $e): ?><td><?php echo $ex_cell($x['exams'][(int)$e['id']] ?? null); ?></td><?php endforeach; ?><?php if ($formative): ?><td><?php echo $x['formative'] !== null ? exam_fmt($x['formative']) : '—'; ?></td><?php endif; ?>
                <td class="<?php echo $x['fail'] ? 'f' : ''; ?>" style="font-weight:700"><?php echo $x['absent'] ? 'AB' : exam_fmt($x['obtained']) . ($x['grace'] > 0 ? '†' : ''); ?></td><td><?php echo exam_fmt($x['full']); ?></td><td><?php echo h($x['grade']); ?></td></tr>
            <?php endforeach; ?>
            <tr style="background:#f3eef8;font-weight:700"><td class="l">Grand total</td><td colspan="<?php echo count($exams) + ($formative ? 1 : 0); ?>"></td><td><?php echo exam_fmt($st['total']); ?></td><td><?php echo exam_fmt($st['full']); ?></td><td><?php echo h($st['grade']); ?></td></tr>
        </tbody></table>
        <div class="foot">
            <div class="box"><b>Percentage</b><span class="big"><?php echo exam_fmt($st['pct']); ?>%</span> &nbsp; Grade <span class="big"><?php echo h($st['grade']); ?></span><div style="font-size:11px;color:#555"><?php echo h($st['grade_remark']); ?></div></div>
            <div class="box"><b>Result</b><span class="big"><?php echo h(result_label($st['status'])); ?></span><div style="font-size:11px;color:#555">Rank <?php echo $st['rank'] ? $st['rank'] . ' of ' . count(array_filter($res['students'], fn($z) => $z['status'] !== 'ABSENT')) : '—'; ?> (<?php echo $section_id ? 'section' : 'class'; ?>)<?php echo $st['failed_n'] ? ' · ' . $st['failed_n'] . ' subject' . ($st['failed_n'] === 1 ? '' : 's') . ' below pass marks' : ''; ?></div></div>
            <div class="box"><b>Attendance</b><span class="big"><?php echo $a ? $a[0] : '—'; ?></span><?php if ($a): ?> of <?php echo $wd ?: $a[1]; ?> days (<?php echo $wd ? round($a[0] / $wd * 100) : round($a[0] / max(1, $a[1]) * 100); ?>%)<?php else: ?><div style="font-size:11px;color:#555">no attendance recorded</div><?php endif; ?></div>
        </div>
        <div class="sign"><div>Guardian</div><div>Class Teacher</div><div><?php if (!empty($school['hoi_signature'])): ?><img src="../uploads/<?php echo h($school['hoi_signature']); ?>" alt=""><?php endif; ?>Head of the Institution<br><small><?php echo h($school['hoi_name'] ?? ''); ?></small></div></div>
        <div style="font-size:10px;color:#777;margin-top:8px">† includes grace marks · AB absent · — not held / not entered</div>
    </div>
    <?php endif; ?>
    <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';

/**
 * Restore a student to Active from the TC, Deleted or Deactivated list.
 * POST: uid, from (tc|deleted|deactivated), optional class_id / section_id / roll_no
 * (required when the student's last enrolment is not in the running session),
 * optional cancel_reason for a TC.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: students.php'); exit(); }
verify_csrf_or_die();

$from = $_POST['from'] ?? 'deleted';
$back = ['tc' => 'tc_students.php', 'deleted' => 'deleted_students.php', 'deactivated' => 'deactivated_students.php'][$from] ?? 'students.php';
$uid = student_uid_clean($_POST['uid'] ?? '');
if ($uid === '') { $_SESSION['error'] = 'Invalid student.'; header("Location: $back"); exit(); }

$r = student_set_status($conn, $uid, 'Active', [
    'class_id'      => (int)($_POST['class_id'] ?? 0),
    'section_id'    => (int)($_POST['section_id'] ?? 0),
    'roll_no'       => trim((string)($_POST['roll_no'] ?? '')),
    'cancel_reason' => trim((string)($_POST['cancel_reason'] ?? '')) ?: 'Restored to Active',
], (int)($_SESSION['admin_id'] ?? 0));

$_SESSION[$r['ok'] ? 'success' : 'error'] = $r['message'];
header('Location: ' . ($r['ok'] ? student_page_url('view_student.php', $uid) : $back));
exit();

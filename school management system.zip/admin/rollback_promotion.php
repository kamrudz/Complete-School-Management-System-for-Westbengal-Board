<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/promotion_helper.php");
require_once("../includes/hs_helper.php");

if($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: promotion_history.php");
    exit();
}

verify_csrf_or_die();

$batch_id = (int)($_POST['batch_id'] ?? 0);

if($batch_id <= 0) {
    $_SESSION['error'] = "⚠️ Invalid batch.";
    header("Location: promotion_history.php");
    exit();
}

// ===== LOAD BATCH INFO =====
$batch = promotion_get_batch($conn, $batch_id);

if(!$batch) {
    $_SESSION['error'] = "⚠️ Promotion batch not found.";
    header("Location: promotion_history.php");
    exit();
}

$from_session_id = (int)$batch['from_session_id'];
$from_class_id   = (int)$batch['from_class_id'];
$to_session_id   = (int)$batch['to_session_id'];
$to_class_id     = (int)$batch['to_class_id'];

// ===== SAFETY: block if a further promotion has already been done from the destination =====
if (promotion_batch_exists($conn, $to_session_id, $to_class_id)) {
    $_SESSION['error'] = "⚠️ Cannot rollback — students from this batch have already been promoted again (to a further class). Rollback the later promotion first.";
    header("Location: promotion_history.php?batch_id=$batch_id");
    exit();
}

// ===== LOAD STUDENT IDS FROM THIS BATCH =====
$student_ids = promotion_get_batch_student_ids($conn, $batch_id);

if(empty($student_ids)) {
    $_SESSION['error'] = "⚠️ No students found in this batch.";
    header("Location: promotion_history.php?batch_id=$batch_id");
    exit();
}

$placeholders = implode(',', array_fill(0, count($student_ids), '?'));
$id_types = str_repeat('s', count($student_ids));

mysqli_begin_transaction($conn);
try {

    // STEP 1: Delete the new (promoted) academic_history records
    //         Only delete rows that match to_session + to_class + Current
    //         (guard: don't delete if student was manually moved elsewhere)
    $delete_sql = "DELETE FROM student_academic_history
        WHERE student_id IN ($placeholders)
          AND session_id=? AND class_id=? AND academic_status='Current'";
    $delete_params = array_merge($student_ids, [$to_session_id, $to_class_id]);
    if (db_execute($delete_sql, $id_types . 'ii', ...$delete_params) === false) {
        throw new Exception('Failed to remove promoted academic records.');
    }

    // XI → XII: the subjects each student was given in XII go with the XII row
    if (hs_is_hs_class($from_class_id) && hs_is_hs_class($to_class_id)
        && db_execute("DELETE FROM hs_student_subjects WHERE student_id IN ($placeholders) AND session_id=? AND class_id=?", $id_types . 'ii', ...$delete_params) === false) {
        throw new Exception('Failed to remove the XII subjects.');
    }

    // STEP 2: Restore the previous (from_session + from_class) records back to Current
    $restore_sql = "UPDATE student_academic_history
        SET academic_status='Current', promotion_status='Studying'
        WHERE student_id IN ($placeholders)
          AND session_id=? AND class_id=?
          AND academic_status='History' AND promotion_status='Promoted'";
    $restore_params = array_merge($student_ids, [$from_session_id, $from_class_id]);
    if (db_execute($restore_sql, $id_types . 'ii', ...$restore_params) === false) {
        throw new Exception('Failed to restore original academic records.');
    }

    // STEP 3: Delete promotion_details
    if (db_execute('DELETE FROM promotion_details WHERE batch_id=?', 'i', $batch_id) === false) {
        throw new Exception('Failed to delete promotion details.');
    }

    // STEP 4: Delete promotion_batch record
    if (db_execute('DELETE FROM promotion_batches WHERE id=?', 'i', $batch_id) === false) {
        throw new Exception('Failed to delete promotion batch.');
    }

    mysqli_commit($conn);

    $label = htmlspecialchars($batch['from_class_name'].' ('.$batch['from_session_name'].')')
           . ' → '
           . htmlspecialchars($batch['to_class_name'].' ('.$batch['to_session_name'].')');
    $_SESSION['success'] = "✅ Promotion rollback successful! "
        . count($student_ids) . " student(s) restored to "
        . $batch['from_class_name'] . " (" . $batch['from_session_name'] . ").";

} catch (Exception $e) {
    mysqli_rollback($conn);
    error_log("Rollback error batch $batch_id: " . $e->getMessage());
    $_SESSION['error'] = "⚠️ Rollback failed: " . htmlspecialchars($e->getMessage()) . ". No changes were made.";
}

header("Location: promotion_history.php");
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/routine_helper.php';
require_once '../includes/routine_builder.php';
require_once '../includes/staff_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Routine Builder — automatic / semi-automatic routine for classes V–X in five steps:
 *   1 method & rules · 2 weekly periods per class-subject · 3 teachers (subjects, blocks) ·
 *   4 who teaches what (auto-distributed or entered) · 5 generate, preview, apply.
 * Manual entry stays in routine_entry.php; the builder writes through the same routine_save_unit().
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$session_id = (int)($active['id'] ?? 0);
$step = max(1, min(5, (int)($_REQUEST['step'] ?? 1)));
$method = in_array($_REQUEST['method'] ?? ($_SESSION['rb_method'] ?? ''), ['auto', 'semi'], true) ? ($_REQUEST['method'] ?? $_SESSION['rb_method']) : 'auto';
$_SESSION['rb_method'] = $method;
$self = fn(int $s) => "routine_builder.php?step=$s&method=$method";
$classes = rb_scope_classes(); $class_ids = array_map(fn($c) => (int)$c['id'], $classes);
$subjects = []; foreach (db_get_all('SELECT id, subject_name FROM subjects ORDER BY subject_name') as $r) $subjects[(int)$r['id']] = $r['subject_name'];
$s = routine_settings(); $periods = routine_periods(); $slots_n = count(rb_slots());

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (!$session_id) { $_SESSION['error'] = 'No active session.'; header('Location: ' . $self(1)); exit(); }
    // ── step 1: rules
    if (isset($_POST['save_rules'])) {
        $d = ['teacher_max_per_day' => max(1, min(10, (int)$_POST['teacher_max_per_day'])), 'teacher_max_consecutive' => max(1, min(8, (int)$_POST['teacher_max_consecutive'])), 'class_teacher_first_period' => !empty($_POST['class_teacher_first_period']) ? 1 : 0];
        db_update('routine_settings', $d, ['id' => 1], 'i'); log_action($admin_id, 'ROUTINE_SETTINGS_UPDATED', 'routine_settings', 1, null, $d);
        $_SESSION['success'] = 'Rules saved.'; header('Location: ' . $self(2)); exit();
    }
    // ── step 2: weekly periods
    if (isset($_POST['save_periods'])) {
        $rows = (array)($_POST['pw'] ?? []); $n = 0;
        db_begin_transaction();
        try {
            foreach (db_get_all('SELECT id, class_id, subject_id FROM class_subjects WHERE session_id = ?', 'i', $session_id) as $cs) {
                if (!in_array((int)$cs['class_id'], $class_ids, true)) continue;
                $in = $rows[(int)$cs['id']] ?? null; if ($in === null) continue;
                $d = ['periods_per_week' => max(0, min(20, (int)($in['n'] ?? 0))), 'max_per_day' => max(1, min(4, (int)($in['max'] ?? 1))), 'pref_band' => in_array($in['band'] ?? '', ['any', 'early', 'late'], true) ? $in['band'] : 'any', 'slot_mode' => !empty($in['combined']) ? 'combined' : 'normal'];
                db_update('class_subjects', $d, ['id' => (int)$cs['id']], 'i'); $n++;
            }
            db_commit();
        } catch (Throwable $e) { db_rollback(); $_SESSION['error'] = 'Could not save.'; header('Location: ' . $self(2)); exit(); }
        log_action($admin_id, 'ROUTINE_WEEKLY_PERIODS_SAVED', 'class_subjects', $session_id, null, ['rows' => $n]);
        $_SESSION['success'] = "Weekly periods saved for $n class-subjects."; header('Location: ' . $self(isset($_POST['next']) ? 3 : 2)); exit();
    }
    // ── step 3: teachers
    if (isset($_POST['save_teachers'])) {
        $ts = (array)($_POST['ts'] ?? []); $ids = array_keys(routine_teachers());
        db_begin_transaction();
        try {
            foreach ($ids as $tid) { db_execute('DELETE FROM teacher_subjects WHERE teacher_id = ?', 'i', $tid); foreach (array_unique(array_map('intval', (array)($ts[$tid] ?? []))) as $sid) if (isset($subjects[$sid])) db_insert('teacher_subjects', ['teacher_id' => $tid, 'subject_id' => $sid]); }
            db_commit();
        } catch (Throwable $e) { db_rollback(); $_SESSION['error'] = 'Could not save.'; header('Location: ' . $self(3)); exit(); }
        $_SESSION['success'] = 'Teacher subjects saved.'; header('Location: ' . $self(isset($_POST['next']) ? 4 : 3)); exit();
    }
    if (isset($_POST['seed_subjects'])) {   // match staff.subject_name (govt list) to the subjects table by name; teachers with nothing ticked only
        $n = 0; $alias = ['LIFE SCIENCE' => 'SCIENCE', 'PHYSICAL SCIENCE' => 'SCIENCE', 'MATHEMATICS' => 'MATHEMATICS', 'PHYSICAL EDUCATION' => 'PHYSICAL EDUCATION', 'WORK EDUCATION' => 'WORK EDUCATION'];
        $byName = []; foreach ($subjects as $sid => $nm) $byName[mb_strtoupper($nm)] = $sid;
        foreach (db_get_all("SELECT id, subject_name FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'") as $r) {
            if (db_get_row('SELECT 1 FROM teacher_subjects WHERE teacher_id = ?', 'i', (int)$r['id'])) continue;
            $key = mb_strtoupper(trim((string)$r['subject_name'])); $key = $alias[$key] ?? $key;
            if (isset($byName[$key])) { db_execute('INSERT IGNORE INTO teacher_subjects (teacher_id, subject_id) VALUES (?, ?)', 'ii', (int)$r['id'], $byName[$key]); $n++; }
        }
        $_SESSION['success'] = "Subjects matched by name for $n teacher" . ($n === 1 ? '' : 's') . ' — check the ticks.'; header('Location: ' . $self(3)); exit();
    }
    if (isset($_POST['add_block'])) {
        $tid = (int)$_POST['teacher_id']; $day = (string)($_POST['day_name'] ?? ''); $pid = (int)$_POST['period_id']; $reason = mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 100);
        if (isset(routine_teachers()[$tid]) && ($day === '' || schoolms_valid_weekday($day)) && in_array($pid, array_map(fn($p) => (int)$p['id'], $periods), true)) db_execute('INSERT IGNORE INTO teacher_slot_blocks (session_id, teacher_id, day_name, period_id, reason) VALUES (?, ?, ?, ?, ?)', 'iisis', $session_id, $tid, $day === '' ? null : $day, $pid, $reason ?: null);
        header('Location: ' . $self(3) . '#blocks'); exit();
    }
    if (isset($_POST['del_block'])) { db_execute('DELETE FROM teacher_slot_blocks WHERE id = ? AND session_id = ?', 'ii', (int)$_POST['del_block'], $session_id); header('Location: ' . $self(3) . '#blocks'); exit(); }
    // ── step 4: assignment
    if (isset($_POST['auto_assign'])) {
        $r = rb_auto_assign($session_id, $admin_id);
        log_action($admin_id, 'ROUTINE_AUTO_ASSIGNED', 'teacher_assignments', $session_id, null, ['problems' => count($r['problems'] ?? []), 'over' => $r['over'] ?? []]);
        $_SESSION[$r['ok'] ? 'success' : 'error'] = $r['ok'] ? 'Teachers distributed — ' . count($r['class_teachers']) . ' class teachers set.' . ($r['over'] ? ' Over the limit: ' . implode(', ', array_slice($r['over'], 0, 6)) . '.' : '') . ($r['problems'] ? ' ' . implode(' ', $r['problems']) : '') : implode(' ', $r['problems']);
        header('Location: ' . $self(4)); exit();
    }
    if (isset($_POST['save_assign'])) {
        $a = (array)($_POST['a'] ?? []); $ct = (array)($_POST['ct'] ?? []); $teachers = routine_teachers(); $n = 0;
        db_begin_transaction();
        try {
            foreach ($classes as $c) {
                $cid = (int)$c['id']; $units = routine_units($session_id, $cid);
                foreach ($units as $k => $u) {
                    foreach ((array)($a[$k] ?? []) as $sid => $tid) { $sid = (int)$sid; $tid = (int)$tid; if (!isset($subjects[$sid])) continue; foreach ($u['section_ids'] as $sec) { if ($tid && isset($teachers[$tid])) { db_execute('INSERT INTO teacher_assignments (session_id, section_id, subject_id, teacher_id) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE teacher_id = VALUES(teacher_id)', 'iiii', $session_id, $sec, $sid, $tid); $n++; } else db_execute('DELETE FROM teacher_assignments WHERE session_id = ? AND section_id = ? AND subject_id = ?', 'iii', $session_id, $sec, $sid); } }
                    [$ctid, $csid] = array_map('intval', explode('|', (string)($ct[$k] ?? '0|0') . '|0')); $okct = $ctid && isset($teachers[$ctid]) && isset($subjects[$csid]);
                    foreach ($u['section_ids'] as $sec) db_update('sections', ['class_teacher_id' => $okct ? $ctid : null, 'class_teacher_subject_id' => $okct ? $csid : null], ['id' => $sec], 'i');
                }
                // class-wide subjects: one teacher for every section of the class
                foreach ((array)($a['c' . $cid] ?? []) as $sid => $tid) { $sid = (int)$sid; $tid = (int)$tid; if (!isset($subjects[$sid])) continue; foreach ($units as $u) foreach ($u['section_ids'] as $sec) { if ($tid && isset($teachers[$tid])) { db_execute('INSERT INTO teacher_assignments (session_id, section_id, subject_id, teacher_id) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE teacher_id = VALUES(teacher_id)', 'iiii', $session_id, $sec, $sid, $tid); $n++; } else db_execute('DELETE FROM teacher_assignments WHERE session_id = ? AND section_id = ? AND subject_id = ?', 'iii', $session_id, $sec, $sid); } }
            }
            db_commit();
        } catch (Throwable $e) { db_rollback(); error_log('assign save: ' . $e->getMessage()); $_SESSION['error'] = 'Could not save.'; header('Location: ' . $self(4)); exit(); }
        log_action($admin_id, 'ROUTINE_ASSIGNMENTS_SAVED', 'teacher_assignments', $session_id, null, ['rows' => $n]);
        $_SESSION['success'] = 'Assignments saved.'; header('Location: ' . $self(isset($_POST['next']) ? 5 : 4)); exit();
    }
    // ── step 5: generate / apply
    if (isset($_POST['generate'])) {
        set_time_limit(60);
        $opts = ['time_limit' => max(3, min(30, (int)($_POST['seconds'] ?? 8))), 'seed' => mt_rand()];
        if ($method === 'semi' && !empty($_POST['keep_existing'])) { $keep = []; foreach ($classes as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $cells = routine_unit_cells($session_id, (int)$c['id'], $k); if ($cells) $keep[$k] = $cells; } $opts['keep'] = $keep; }
        $g = rb_generate($session_id, $opts);
        $id = db_insert('routine_drafts', ['session_id' => $session_id, 'method' => $method, 'params' => json_encode(['time_limit' => $opts['time_limit'], 'keep' => !empty($opts['keep'])]), 'result' => json_encode($g['result']), 'stats' => json_encode(['stats' => $g['stats'], 'unplaced' => $g['unplaced'], 'load' => $g['load']]), 'created_by' => $admin_id]);
        db_execute('DELETE FROM routine_drafts WHERE session_id = ? AND id NOT IN (SELECT id FROM (SELECT id FROM routine_drafts WHERE session_id = ? ORDER BY id DESC LIMIT 5) x)', 'ii', $session_id, $session_id);
        log_action($admin_id, 'ROUTINE_GENERATED', 'routine_drafts', $id, null, $g['stats']);
        header('Location: ' . $self(5) . '&draft=' . $id); exit();
    }
    if (isset($_POST['apply'])) {
        $draft = db_get_row('SELECT * FROM routine_drafts WHERE id = ? AND session_id = ?', 'ii', (int)$_POST['draft_id'], $session_id);
        if (!$draft) { $_SESSION['error'] = 'Draft not found.'; header('Location: ' . $self(5)); exit(); }
        $result = json_decode($draft['result'], true) ?: []; $only = isset($_POST['unit']) && $_POST['unit'] !== '' ? [(string)$_POST['unit']] : null;
        $r = rb_apply($session_id, $result, $admin_id, $only);
        log_action($admin_id, 'ROUTINE_GENERATED_APPLIED', 'routine', $session_id, null, ['draft' => (int)$draft['id'], 'units' => count($r['done']), 'errors' => $r['errors']]);
        $_SESSION[$r['errors'] ? 'error' : 'success'] = ($r['done'] ? count($r['done']) . ' routine' . (count($r['done']) === 1 ? '' : 's') . ' written.' : '') . ($r['errors'] ? ' Not written: ' . implode('; ', array_map(fn($k, $e) => "$k — $e", array_keys($r['errors']), $r['errors'])) : '');
        header('Location: ' . $self(5) . '&draft=' . (int)$draft['id']); exit();
    }
}

// ── data for the current step
$teachers = routine_teachers(); $limits = routine_workload_limits();
$done = ['2' => (int)(db_get_row('SELECT COUNT(*) c FROM class_subjects WHERE session_id = ? AND periods_per_week > 0', 'i', $session_id)['c'] ?? 0) > 0, '3' => $teachers && (int)(db_get_row('SELECT COUNT(DISTINCT teacher_id) c FROM teacher_subjects')['c'] ?? 0) > 0, '4' => (int)(db_get_row('SELECT COUNT(*) c FROM teacher_assignments WHERE session_id = ?', 'i', $session_id)['c'] ?? 0) > 0];
$page = [];
if ($step === 2) {
    $page['cs'] = []; foreach (db_get_all('SELECT cs.*, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.session_id = ? ORDER BY cs.class_id, s.subject_name', 'i', $session_id) as $r) if (in_array((int)$r['class_id'], $class_ids, true)) $page['cs'][(int)$r['class_id']][] = $r;
} elseif ($step === 3) {
    $page['ts'] = []; foreach (db_get_all('SELECT teacher_id, subject_id FROM teacher_subjects') as $r) $page['ts'][(int)$r['teacher_id']][(int)$r['subject_id']] = true;
    $page['staff'] = []; foreach (db_get_all("SELECT id, subject_name, academic_section FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'") as $r) $page['staff'][(int)$r['id']] = $r;
    $page['scope_subjects'] = []; foreach (db_get_all('SELECT DISTINCT subject_id FROM class_subjects WHERE session_id = ? AND periods_per_week > 0', 'i', $session_id) as $r) if (isset($subjects[(int)$r['subject_id']])) $page['scope_subjects'][(int)$r['subject_id']] = $subjects[(int)$r['subject_id']];
    if (!$page['scope_subjects']) $page['scope_subjects'] = $subjects;
    asort($page['scope_subjects']);
    $page['blocks'] = db_get_all('SELECT b.*, p.period_name, st.staff_name FROM teacher_slot_blocks b JOIN periods p ON p.id = b.period_id JOIN staff st ON st.id = b.teacher_id WHERE b.session_id = ? ORDER BY st.staff_name, b.day_name, p.sort_order', 'i', $session_id);
    $need = []; foreach (db_get_all('SELECT DISTINCT subject_id FROM class_subjects WHERE session_id = ? AND periods_per_week > 0', 'i', $session_id) as $r) { $sid = (int)$r['subject_id']; $has = false; foreach ($page['ts'] as $t => $ss) if (isset($ss[$sid]) && isset($teachers[$t])) { $has = true; break; } if (!$has) $need[] = $subjects[$sid] ?? $sid; }
    $page['need'] = $need;
} elseif ($step === 4) {
    $in = rb_inputs($session_id); $dm = rb_demands($session_id, $in); $page['in'] = $in; $page['dm'] = $dm;
    $page['elig'] = []; foreach ($in['teachers'] as $tid => $t) foreach (array_keys($t['subjects']) as $sid) $page['elig'][$sid][] = $tid;
    $page['load'] = []; foreach ($dm['demands'] as $d) foreach ($d['teachers'] as $tid) if ($tid) $page['load'][$tid] = ($page['load'][$tid] ?? 0) + $d['n'];
} elseif ($step === 5) {
    $page['drafts'] = db_get_all('SELECT d.id, d.method, d.created_at, d.stats, a.full_name FROM routine_drafts d LEFT JOIN admins a ON a.id = d.created_by WHERE d.session_id = ? ORDER BY d.id DESC', 'i', $session_id);
    $did = (int)($_GET['draft'] ?? ($page['drafts'][0]['id'] ?? 0));
    $page['draft'] = $did ? db_get_row('SELECT * FROM routine_drafts WHERE id = ? AND session_id = ?', 'ii', $did, $session_id) : null;
    if ($page['draft']) {
        $page['result'] = json_decode($page['draft']['result'], true) ?: []; $st = json_decode($page['draft']['stats'], true) ?: []; $page['stats'] = $st['stats'] ?? []; $page['unplaced'] = $st['unplaced'] ?? []; $page['load'] = $st['load'] ?? [];
        $in = rb_inputs($session_id); $page['units'] = $in['units'];
        // preview grids: cells → rows the shared renderer understands
        $page['grids'] = [];
        foreach ($page['result'] as $k => $days) { $grid = []; foreach ($days as $day => $per) foreach ($per as $pid => $c) { $rows = []; foreach (['g0', 'g1'] as $i => $gk) { if (empty($c[$gk]) || empty($c[$gk]['s'])) continue; $t = $teachers[(int)$c[$gk]['t']] ?? null; $rows[] = ['subject_name' => $subjects[(int)$c[$gk]['s']] ?? '?', 'short_code' => $t['short_code'] ?? '', 'staff_name' => $t['staff_name'] ?? '', 'group_id' => $c['combined'] ? ($i ? -2 : -1) : $i, 'teacher_id' => (int)$c[$gk]['t']]; } $grid[$day][(int)$pid] = $rows; } $page['grids'][$k] = $grid; }
        $page['partners'] = []; foreach ($page['result'] as $k => $days) foreach ($days as $day => $per) foreach ($per as $pid => $c) if (!empty($c['combined'])) $page['partners'][$k][$day][(int)$pid] = 'with ' . implode(', ', array_map(fn($x) => $in['units'][$x]['label'] ?? $x, $c['combined']));
    }
    $page['existing'] = (int)(db_get_row('SELECT COUNT(*) c FROM routine r JOIN classes c ON c.id = r.class_id WHERE r.session_id = ? AND c.class_name NOT IN ("XI","XII")', 'i', $session_id)['c'] ?? 0);
}
$stepNames = [1 => 'Method & rules', 2 => 'Weekly periods', 3 => 'Teachers', 4 => 'Who teaches what', 5 => 'Generate & apply'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Routine Builder</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); echo routine_view_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #2d0b5c 0%, #6b3fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(45,11,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #e4d8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .steps { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 14px; } .steps a { display: inline-flex; align-items: center; gap: 7px; padding: 7px 13px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #2d0b5c; text-decoration: none; font-size: 12.5px; font-weight: 600; } .steps a b { background: #c9d6e2; color: #2d0b5c; border-radius: 50%; width: 20px; height: 20px; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; } .steps a.on { background: #2d0b5c; color: #fff; border-color: #2d0b5c; } .steps a.on b { background: #fff; } .steps a.ok b { background: #1b7a3d; color: #fff; }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 14px; padding: 18px 20px; margin-bottom: 16px; } .card h2 { margin: 0 0 6px; font-size: 16px; color: #2d0b5c; display: flex; align-items: center; gap: 8px; } .card h2 small { font-weight: 400; color: #6b7d90; font-size: 12.5px; } .card .lead { color: #4d6178; font-size: 13px; margin: 0 0 14px; }
    .modes { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; margin-bottom: 14px; } .mode { border: 2px solid #dfe7ef; border-radius: 12px; padding: 14px; background: #fbfcfe; text-decoration: none; color: inherit; display: block; } .mode.on { border-color: #6b3fa3; background: #f3eefb; box-shadow: 0 0 0 3px rgba(107,63,163,.12); } .mode b { display: flex; align-items: center; gap: 8px; font-size: 14.5px; color: #2d0b5c; } .mode p { margin: 6px 0 0; font-size: 12.5px; color: #3b5168; line-height: 1.5; }
    .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-bottom: 14px; } .grid2 label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin-bottom: 4px; text-transform: uppercase; } .grid2 input, .grid2 select { height: 38px; width: 100%; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; } .grid2 small { display: block; color: #6b7d90; font-size: 11.5px; margin-top: 4px; }
    table.pw { width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 8px; } .pw th { background: #2d0b5c; color: #fff; padding: 7px 8px; text-align: left; font-size: 11.5px; text-transform: uppercase; } .pw td { padding: 5px 8px; border-bottom: 1px solid #e6edf3; } .pw input[type=number] { width: 60px; height: 32px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; font-weight: 700; } .pw select { height: 32px; border: 1px solid #c9d6e2; border-radius: 6px; } .pw td.tl { color: #6b3fa3; font-weight: 700; }
    .cls { display: flex; align-items: center; gap: 10px; margin: 14px 0 6px; } .cls h3 { margin: 0; font-size: 15px; color: #2d0b5c; } .cls .tot { margin-left: auto; font-weight: 800; padding: 3px 12px; border-radius: 999px; background: #eef2f6; color: #4d6178; } .cls .tot.ok { background: #d7f3e1; color: #1b7a3d; } .cls .tot.bad { background: #fde2e4; color: #9d2630; }
    table.tt { width: 100%; border-collapse: collapse; font-size: 12.5px; } .tt th { background: #2d0b5c; color: #fff; padding: 7px 8px; text-align: left; font-size: 11px; text-transform: uppercase; position: sticky; top: 0; } .tt td { padding: 6px 8px; border-bottom: 1px solid #e6edf3; vertical-align: top; } .tt .chips { display: flex; flex-wrap: wrap; gap: 4px; } .tt .chips label { border: 1px solid #c9d6e2; border-radius: 999px; padding: 2px 8px; font-size: 11.5px; cursor: pointer; background: #fff; } .tt .chips label:has(input:checked) { background: #6b3fa3; color: #fff; border-color: #6b3fa3; } .tt .chips input { display: none; }
    .warn { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 10px; padding: 9px 13px; font-size: 13px; margin-bottom: 12px; }
    .as { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-bottom: 6px; } .as th { background: #2d0b5c; color: #fff; padding: 6px 8px; font-size: 11px; text-transform: uppercase; text-align: left; } .as td { padding: 4px 6px; border-bottom: 1px solid #e6edf3; } .as select { height: 32px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 12.5px; max-width: 170px; } .as select.none { border-color: #d63a4a; background: #fde2e4; } .as td.sub { font-weight: 700; color: #10253a; white-space: nowrap; } .as td.sub small { color: #6b7d90; font-weight: 400; }
    .loads { display: flex; gap: 6px; flex-wrap: wrap; } .loads span { font-size: 12px; border: 1px solid #dfe7ef; border-radius: 999px; padding: 3px 10px; background: #fff; } .loads span.over { background: #fff6e5; border-color: #f0c987; color: #7a4a00; } .loads span.zero { color: #8a9aab; }
    .cols { display: grid; grid-template-columns: 1fr 260px; gap: 16px; align-items: start; } @media (max-width: 900px) { .cols { grid-template-columns: 1fr; } }
    .sticky { position: sticky; top: 10px; }
    .stat { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 12px; } .stat span { padding: 6px 12px; border-radius: 10px; background: #f3f6f9; font-size: 13px; } .stat span b { font-size: 16px; display: block; color: #2d0b5c; } .stat span.ok { background: #d7f3e1; } .stat span.bad { background: #fde2e4; }
    .utabs { display: flex; gap: 5px; flex-wrap: wrap; margin: 10px 0; } .utabs a { padding: 5px 11px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #2d0b5c; text-decoration: none; font-size: 12px; font-weight: 700; } .utabs a.on { background: #2d0b5c; color: #fff; }
    .ublk { display: none; } .ublk.on { display: block; }
    .ld { width: 100%; border-collapse: collapse; font-size: 12px; } .ld th, .ld td { border: 1px solid #e6edf3; padding: 3px 6px; text-align: center; } .ld th { background: #2d0b5c; color: #fff; } .ld td.nm { text-align: left; font-weight: 700; } .ld td.hi { background: #fff6e5; color: #7a4a00; font-weight: 800; }
    .drafts a { display: inline-block; margin: 0 6px 6px 0; padding: 4px 10px; border-radius: 8px; border: 1px solid #dfe7ef; font-size: 12px; text-decoration: none; color: #10253a; } .drafts a.on { border-color: #6b3fa3; background: #f3eefb; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-magic"></i></div>
        <div><h1>Routine Builder <small style="font-size:13px;font-weight:400;opacity:.85">— <?php echo $method === 'auto' ? 'Automatic' : 'Semi-automatic'; ?></small></h1><p>Classes V–X · session <?php echo h($active['session_name'] ?? '—'); ?> · <?php echo count($periods); ?> periods, Saturday up to <?php echo $s['saturday_periods']; ?> → <?php echo $slots_n; ?> periods a week per section. XI–XII stay manual.</p></div>
        <div class="links"><a href="routine_entry.php"><i class="fas fa-edit"></i> Manual entry</a><a href="routine_settings.php"><i class="fas fa-sliders-h"></i> Settings</a><a href="class_routine.php"><i class="fas fa-table"></i> Class routines</a></div>
    </div>
    <div class="steps"><?php foreach ($stepNames as $i => $nm): ?><a href="<?php echo h($self($i)); ?>" class="<?php echo $i === $step ? 'on' : (!empty($done[(string)$i]) ? 'ok' : ''); ?>"><b><?php echo !empty($done[(string)$i]) && $i !== $step ? '✓' : $i; ?></b> <?php echo h($nm); ?></a><?php endforeach; ?></div>
    <?php if (isset($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>
    <?php if (!$session_id): ?><div class="warn">No active session.</div><?php elseif (!$periods): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No periods yet — <a href="periods.php">add periods</a> first.</div><?php endif; ?>

<?php if ($step === 1): ?>
    <div class="card">
        <h2><i class="fas fa-route"></i> Method</h2>
        <div class="modes">
            <a class="mode <?php echo $method === 'auto' ? 'on' : ''; ?>" href="routine_builder.php?step=1&method=auto"><b><i class="fas fa-magic"></i> Automatic</b><p>আপনি দেবেন শুধু class-প্রতি subject-এর সাপ্তাহিক period (govt নিয়ম) আর teacher-দের subject। System নিজে teacher ↔ class ভাগ করবে (সবার load প্রায় সমান, class-level পছন্দ দেখে), class teacher ঠিক করবে (রোজ P1 নিজের class-এ), তারপর পুরো সপ্তাহ বানাবে।</p></a>
            <a class="mode <?php echo $method === 'semi' ? 'on' : ''; ?>" href="routine_builder.php?step=1&method=semi"><b><i class="fas fa-hands-helping"></i> Semi-automatic</b><p>কে কোন class-এ কী পড়াবেন, class teacher, period সংখ্যা, কোন subject combined — সব আপনি দেবেন (step 4); system শুধু সপ্তাহে ছড়াবে। চাইলে এখনকার routine-এর cell রেখে বাকিটা ভরবে।</p></a>
            <a class="mode" href="routine_entry.php"><b><i class="fas fa-edit"></i> Manual</b><p>সব হাতে — Routine Entry পেজ। Builder-এর ফল-ও পরে ওখানে হাতে বদলানো যায়।</p></a>
        </div>
        <h2 style="margin-top:6px"><i class="fas fa-gavel"></i> Rules <small>— both methods</small></h2>
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="grid2">
                <div><label>Teacher: max periods a day</label><input type="number" name="teacher_max_per_day" min="1" max="10" value="<?php echo (int)$s['teacher_max_per_day']; ?>"><small>Soft — exceeded only when a teacher's weekly load leaves no choice.</small></div>
                <div><label>Teacher: max consecutive periods</label><input type="number" name="teacher_max_consecutive" min="1" max="8" value="<?php echo (int)$s['teacher_max_consecutive']; ?>"><small>Soft.</small></div>
                <div><label>Class teacher first period</label><select name="class_teacher_first_period"><option value="1" <?php echo (int)$s['class_teacher_first_period'] ? 'selected' : ''; ?>>Yes — class teacher takes P1 every day</option><option value="0" <?php echo !(int)$s['class_teacher_first_period'] ? 'selected' : ''; ?>>No</option></select><small>The class teacher takes the first period every day with the same subject — that subject needs at least 6 periods a week in the section (step 4).</small></div>
            </div>
            <div class="warn" style="margin-bottom:12px"><i class="fas fa-info-circle"></i> Hard rules always: one class per room per period, a teacher in one room at a time, teacher blocks (step 3), subject max per day (step 2), Saturday <?php echo $s['saturday_periods']; ?> periods, 3rd language = every section together in the Arabic and Sanskrit halls.</div>
            <button type="submit" name="save_rules" value="1" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Save & continue</button>
        </form>
    </div>

<?php elseif ($step === 2): ?>
    <div class="card">
        <h2><i class="fas fa-list-ol"></i> Weekly periods per subject <small>— govt norms; every section needs <?php echo $slots_n; ?> a week</small></h2>
        <p class="lead">Subjects come from Class Subjects. <b>Max/day</b>: how many periods of the subject on one day (1 = spread over the week). <b>Combined</b>: every section of the class in one room with one teacher (PE, assembly-type periods). 3rd-language pairs are handled automatically: all sections together, split into the two halls.</p>
        <?php if (!$page['cs']): ?><div class="lc-empty"><i class="fas fa-book"></i>No subjects assigned to classes V–X in this session — do that in <a href="class_subjects.php">Class Subjects</a> first.</div>
        <?php else: ?>
        <form method="post" id="pwForm">
            <?php echo csrf_field(); ?>
            <?php foreach ($classes as $c): $cid = (int)$c['id']; $list = $page['cs'][$cid] ?? []; if (!$list) continue; ?>
            <div class="cls"><h3>Class <?php echo h($c['class_name']); ?></h3><span class="tot" data-class="<?php echo $cid; ?>">0 / <?php echo $slots_n; ?></span></div>
            <table class="pw"><thead><tr><th>Subject</th><th>Periods / week</th><th>Max / day</th><th>Preferred time</th><th>Combined (all sections)</th></tr></thead><tbody>
            <?php foreach ($list as $r): $tl = (int)$r['is_third_language']; ?>
            <tr><td class="<?php echo $tl ? 'tl' : ''; ?>"><?php echo h($r['subject_name']); ?><?php echo $tl ? ' <small>(3rd language)</small>' : ''; ?></td>
                <td><input type="number" name="pw[<?php echo (int)$r['id']; ?>][n]" min="0" max="20" value="<?php echo (int)$r['periods_per_week']; ?>" data-class="<?php echo $cid; ?>" data-tl="<?php echo $tl; ?>"></td>
                <td><input type="number" name="pw[<?php echo (int)$r['id']; ?>][max]" min="1" max="4" value="<?php echo max(1, (int)$r['max_per_day']); ?>"></td>
                <td><select name="pw[<?php echo (int)$r['id']; ?>][band]"><option value="any" <?php echo $r['pref_band'] === 'any' ? 'selected' : ''; ?>>Any</option><option value="early" <?php echo $r['pref_band'] === 'early' ? 'selected' : ''; ?>>Early periods</option><option value="late" <?php echo $r['pref_band'] === 'late' ? 'selected' : ''; ?>>Late periods</option></select></td>
                <td><?php if (!$tl): ?><input type="checkbox" name="pw[<?php echo (int)$r['id']; ?>][combined]" value="1" <?php echo $r['slot_mode'] === 'combined' ? 'checked' : ''; ?>><?php else: ?><small style="color:#6b7d90">always, both halls</small><?php endif; ?></td></tr>
            <?php endforeach; ?></tbody></table>
            <?php endforeach; ?>
            <div style="display:flex;gap:8px;margin-top:10px"><button type="submit" name="save_periods" value="1" class="btn btn-secondary"><i class="fas fa-save"></i> Save</button><button type="submit" name="save_periods" value="1" class="btn btn-primary" onclick="this.form.insertAdjacentHTML('beforeend','<input type=hidden name=next value=1>')"><i class="fas fa-arrow-right"></i> Save & continue</button></div>
        </form>
        <script>
        (function () { function tot() { var t = {}; document.querySelectorAll('#pwForm input[data-class]').forEach(function (i) { var c = i.dataset.class; t[c] = t[c] || {n: 0, tl: []}; if (i.dataset.tl === '1') t[c].tl.push(parseInt(i.value, 10) || 0); else t[c].n += parseInt(i.value, 10) || 0; }); document.querySelectorAll('.tot[data-class]').forEach(function (el) { var x = t[el.dataset.class] || {n: 0, tl: []}; var n = x.n + (x.tl.length ? Math.max.apply(null, x.tl) : 0); el.textContent = n + ' / <?php echo $slots_n; ?>'; el.className = 'tot ' + (n === <?php echo $slots_n; ?> ? 'ok' : (n > <?php echo $slots_n; ?> ? 'bad' : '')); }); } document.getElementById('pwForm').addEventListener('input', tot); tot(); })();
        </script>
        <?php endif; ?>
    </div>

<?php elseif ($step === 3): ?>
    <div class="card">
        <h2><i class="fas fa-chalkboard-teacher"></i> Teachers <small>— which subjects each can take, level preference, weekly limit</small></h2>
        <p class="lead">Tick every subject a teacher can teach in V–X. Level preference comes from the staff record (Academic section); the weekly limit from Routine Settings. Teachers with nothing ticked are not used.</p>
        <?php if ($page['need']): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No teacher ticked for: <b><?php echo h(implode(', ', $page['need'])); ?></b> — those periods cannot be placed.</div><?php endif; ?>
        <?php if (!$teachers): ?><div class="lc-empty"><i class="fas fa-user-slash"></i>No active teaching staff.</div>
        <?php else: ?>
        <form method="post" style="margin-bottom:10px"><?php echo csrf_field(); ?><button type="submit" name="seed_subjects" value="1" class="btn btn-secondary"><i class="fas fa-magic"></i> Match subjects by name (teachers with nothing ticked)</button></form>
        <form method="post">
            <?php echo csrf_field(); ?>
            <div style="overflow:auto;max-height:70vh"><table class="tt"><thead><tr><th>Teacher</th><th>Level</th><th>Limit</th><th>Can teach</th></tr></thead><tbody>
            <?php foreach ($teachers as $tid => $t): $st = $page['staff'][$tid] ?? []; ?>
            <tr><td><b><?php echo h($t['staff_name']); ?></b><br><small style="color:#6b7d90"><?php echo h(($t['short_code'] ? $t['short_code'] . ' · ' : '') . $t['designation'] . ($st['subject_name'] ?? '' ? ' · ' . $st['subject_name'] : '')); ?></small></td>
                <td><small><?php echo h($st['academic_section'] ?? '—'); ?></small></td><td><b><?php echo (int)($limits[$t['designation']] ?? 0) ?: '<span style="color:#9d2630">0</span>'; ?></b></td>
                <td><div class="chips"><?php foreach ($page['scope_subjects'] as $sid => $nm): ?><label><input type="checkbox" name="ts[<?php echo $tid; ?>][]" value="<?php echo $sid; ?>" <?php echo isset($page['ts'][$tid][$sid]) ? 'checked' : ''; ?>><?php echo h($nm); ?></label><?php endforeach; ?></div></td></tr>
            <?php endforeach; ?></tbody></table></div>
            <div style="display:flex;gap:8px;margin-top:10px"><button type="submit" name="save_teachers" value="1" class="btn btn-secondary"><i class="fas fa-save"></i> Save</button><button type="submit" name="save_teachers" value="1" class="btn btn-primary" onclick="this.form.insertAdjacentHTML('beforeend','<input type=hidden name=next value=1>')"><i class="fas fa-arrow-right"></i> Save & continue</button></div>
        </form>
        <?php endif; ?>
    </div>
    <div class="card" id="blocks">
        <h2><i class="fas fa-ban"></i> When a teacher is not available <small>— that period is never given to them</small></h2>
        <form method="post" class="lc-filter" style="margin-bottom:10px">
            <?php echo csrf_field(); ?>
            <div><label>Teacher</label><select name="teacher_id" required><option value="">— choose —</option><?php foreach ($teachers as $tid => $t): ?><option value="<?php echo $tid; ?>"><?php echo h($t['staff_name']); ?></option><?php endforeach; ?></select></div>
            <div><label>Day</label><select name="day_name"><option value="">Every day</option><?php foreach (routine_days() as $d): ?><option value="<?php echo $d; ?>"><?php echo $d; ?></option><?php endforeach; ?></select></div>
            <div><label>Period</label><select name="period_id" required><?php foreach ($periods as $p): ?><option value="<?php echo (int)$p['id']; ?>"><?php echo h($p['period_name']); ?></option><?php endforeach; ?></select></div>
            <div><label>Reason</label><input type="text" name="reason" maxlength="100" placeholder="HM office / bus"></div>
            <button type="submit" name="add_block" value="1" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
        </form>
        <?php if (!$page['blocks']): ?><span style="color:#6b7d90;font-size:13px">No blocks.</span><?php else: ?><div class="chips" style="display:flex;flex-wrap:wrap;gap:6px"><?php foreach ($page['blocks'] as $b): ?><form method="post" style="margin:0"><?php echo csrf_field(); ?><span class="lc-tag" style="border-color:#f5b5bb;background:#fde2e4;color:#9d2630"><?php echo h($b['staff_name']); ?> · <?php echo h($b['day_name'] ?: 'every day'); ?> <?php echo h($b['period_name']); ?><?php echo $b['reason'] ? ' · ' . h($b['reason']) : ''; ?> <button type="submit" name="del_block" value="<?php echo (int)$b['id']; ?>" style="border:0;background:none;color:#9d2630;cursor:pointer" title="Remove">×</button></span></form><?php endforeach; ?></div><?php endif; ?>
    </div>

<?php elseif ($step === 4): $in = $page['in']; $dm = $page['dm']; ?>
    <?php foreach ($dm['warnings'] as $w): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> <?php echo h($w); ?></div><?php endforeach; ?>
    <div class="cols">
    <div class="card">
        <h2><i class="fas fa-people-arrows"></i> Who teaches what <small>— per section / pair; class-wide subjects once per class</small></h2>
        <?php if ($method === 'auto'): ?>
        <form method="post" style="margin-bottom:12px"><?php echo csrf_field(); ?><p class="lead">Automatic: let the system distribute — balanced weekly load against each teacher's limit, level preference, and a class teacher for every section. You can still change any cell below afterwards.</p><button type="submit" name="auto_assign" value="1" class="btn btn-primary" onclick="return confirm('Replace the current assignments and class teachers of V–X?');"><i class="fas fa-magic"></i> Distribute automatically</button></form>
        <?php else: ?><p class="lead">Semi-automatic: choose the teacher for every subject in every section / pair, and the class teacher. Only teachers who can take the subject (step 3) are offered.</p><?php endif; ?>
        <?php if (!$dm['demands']): ?><div class="lc-empty"><i class="fas fa-list-ol"></i>No weekly periods set yet — go to step 2.</div>
        <?php else: ?>
        <form method="post" id="asForm">
            <?php echo csrf_field(); ?>
            <?php foreach ($classes as $c): $cid = (int)$c['id']; $units = array_filter($in['units'], fn($u) => $u['class_id'] === $cid); if (!$units) continue;
                $rows = []; foreach ($dm['demands'] as $d) if ($d['class_id'] === $cid) foreach ($d['subjects'] as $i => $sid) $rows[$sid] = ['type' => $d['type'], 'n' => $d['n']];
                if (!$rows) continue; ?>
            <div class="cls"><h3>Class <?php echo h($c['class_name']); ?></h3><small style="color:#6b7d90"><?php echo count($units); ?> <?php echo count($units) === 1 ? 'section' : 'sections / pairs'; ?></small></div>
            <div style="overflow-x:auto"><table class="as"><thead><tr><th>Subject</th><?php foreach ($units as $k => $u): ?><th><?php echo h($u['label']); ?></th><?php endforeach; ?></tr></thead><tbody>
            <?php foreach ($rows as $sid => $info): $opts = $page['elig'][$sid] ?? []; ?>
            <tr><td class="sub"><?php echo h($subjects[$sid] ?? $sid); ?> <small>×<?php echo $info['n']; ?><?php echo $info['type'] !== 'normal' ? ' · all sections' : ''; ?></small></td>
                <?php if ($info['type'] !== 'normal'): $first = reset($units); $cur = (int)($in['assign'][$first['first']][$sid] ?? 0); ?><td colspan="<?php echo count($units); ?>"><select name="a[c<?php echo $cid; ?>][<?php echo $sid; ?>]" class="<?php echo $cur ? '' : 'none'; ?>" data-n="<?php echo $info['n']; ?>"><option value="0">— teacher —</option><?php foreach ($opts as $tid): ?><option value="<?php echo $tid; ?>" <?php echo $tid === $cur ? 'selected' : ''; ?>><?php echo h($in['teachers'][$tid]['name']); ?></option><?php endforeach; ?></select> <small style="color:#6b7d90">one teacher, every section together</small></td>
                <?php else: foreach ($units as $k => $u): $cur = (int)($in['assign'][$u['first']][$sid] ?? 0); ?><td><select name="a[<?php echo h($k); ?>][<?php echo $sid; ?>]" class="<?php echo $cur ? '' : 'none'; ?>" data-n="<?php echo $info['n']; ?>"><option value="0">—</option><?php foreach ($opts as $tid): ?><option value="<?php echo $tid; ?>" <?php echo $tid === $cur ? 'selected' : ''; ?>><?php echo h($in['teachers'][$tid]['code'] ?: $in['teachers'][$tid]['name']); ?></option><?php endforeach; ?></select></td><?php endforeach; endif; ?></tr>
            <?php endforeach; ?>
            <tr><td class="sub">Class teacher <small>same subject, P1 every day</small></td><?php foreach ($units as $k => $u): $cur = $in['class_teacher'][$k] ?? null; $curv = $cur ? $cur['t'] . '|' . $cur['s'] : ''; ?><td><select name="ct[<?php echo h($k); ?>]" data-ct="1"><option value="">—</option><?php foreach ($rows as $sid => $info): if ($info['type'] !== 'normal') continue; $tid = (int)($in['assign'][$u['first']][$sid] ?? 0); if (!$tid || !isset($in['teachers'][$tid])) continue; $v = $tid . '|' . $sid; ?><option value="<?php echo $v; ?>" <?php echo $v === $curv ? 'selected' : ''; ?>><?php echo h(($in['teachers'][$tid]['code'] ?: $in['teachers'][$tid]['name']) . ' · ' . ($subjects[$sid] ?? '') . ($info['n'] < count(routine_days()) ? ' (only ' . $info['n'] . '/wk)' : '')); ?></option><?php endforeach; ?></select><?php if ($cur && $cur['t'] && !$curv): ?><?php endif; ?></td><?php endforeach; ?></tr>
            </tbody></table></div>
            <?php endforeach; ?>
            <div style="display:flex;gap:8px;margin-top:10px"><button type="submit" name="save_assign" value="1" class="btn btn-secondary"><i class="fas fa-save"></i> Save</button><button type="submit" name="save_assign" value="1" class="btn btn-primary" onclick="this.form.insertAdjacentHTML('beforeend','<input type=hidden name=next value=1>')"><i class="fas fa-arrow-right"></i> Save & continue</button></div>
        </form>
        <?php endif; ?>
    </div>
    <div class="card sticky">
        <h2><i class="fas fa-balance-scale"></i> Weekly load</h2>
        <div class="loads" id="loads"></div>
        <p style="color:#6b7d90;font-size:12px;margin:10px 0 0">Periods a week from the choices on the left (a pair or a class-wide period counts once) against the designation limit.</p>
    </div>
    </div>
    <script id="rb-teachers" type="application/json"><?php echo json_encode(array_map(fn($t) => ['name' => $t['name'], 'code' => $t['code'], 'limit' => $t['limit']], $in['teachers']), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
    <script>
    (function () { var T = JSON.parse(document.getElementById('rb-teachers').textContent); var f = document.getElementById('asForm'); if (!f) return;
        function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
        function calc() { var L = {}; f.querySelectorAll('select[data-n]').forEach(function (s) { var t = s.value; s.classList.toggle('none', !parseInt(t, 10)); if (parseInt(t, 10)) L[t] = (L[t] || 0) + parseInt(s.dataset.n, 10); });
            var html = ''; Object.keys(T).forEach(function (id) { var n = L[id] || 0, lim = T[id].limit; html += '<span class="' + (lim && n > lim ? 'over' : (n ? '' : 'zero')) + '" title="' + esc(T[id].name) + '">' + esc(T[id].code || T[id].name) + ' ' + n + (lim ? '/' + lim : '') + (lim && n > lim ? ' ⚠' : '') + '</span>'; });
            document.getElementById('loads').innerHTML = html; }
        f.addEventListener('change', calc); calc(); })();
    </script>

<?php else: ?>
    <div class="card">
        <h2><i class="fas fa-cogs"></i> Generate <small>— the whole week for every section of V–X</small></h2>
        <?php if ($page['existing']): ?><div class="warn"><i class="fas fa-info-circle"></i> V–X already have <?php echo $page['existing']; ?> routine rows. Applying a draft replaces the routine of the sections it covers; XI–XII are untouched.</div><?php endif; ?>
        <form method="post" class="lc-filter">
            <?php echo csrf_field(); ?>
            <div><label>Search time</label><select name="seconds"><option value="5">5 seconds</option><option value="8" selected>8 seconds</option><option value="15">15 seconds</option><option value="30">30 seconds — best result</option></select></div>
            <?php if ($method === 'semi'): ?><div><label>Existing routine</label><label style="display:flex;align-items:center;gap:6px;height:38px;text-transform:none;font-weight:600"><input type="checkbox" name="keep_existing" value="1" <?php echo $page['existing'] ? 'checked' : ''; ?>> keep what is already entered, fill the rest</label></div><?php endif; ?>
            <button type="submit" name="generate" value="1" class="btn btn-primary" onclick="this.disabled=true;this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> Working…';this.form.submit();"><i class="fas fa-magic"></i> Generate</button>
        </form>
        <?php if ($page['drafts']): ?><div class="drafts" style="margin-top:10px"><?php foreach ($page['drafts'] as $d): $st = json_decode($d['stats'], true)['stats'] ?? []; ?><a href="<?php echo h($self(5)); ?>&draft=<?php echo (int)$d['id']; ?>" class="<?php echo $page['draft'] && (int)$page['draft']['id'] === (int)$d['id'] ? 'on' : ''; ?>">#<?php echo (int)$d['id']; ?> · <?php echo date('d-m H:i', strtotime($d['created_at'])); ?> · <?php echo (int)($st['placed'] ?? 0); ?>/<?php echo (int)($st['demanded'] ?? 0); ?> placed<?php echo !empty($st['unplaced']) ? ', ' . (int)$st['unplaced'] . ' left' : ''; ?></a><?php endforeach; ?></div><?php endif; ?>
    </div>
    <?php if ($page['draft']): $st = $page['stats']; $ct = $st['ct_first'] ?? [0, 0]; ?>
    <div class="card">
        <h2><i class="fas fa-poll"></i> Draft #<?php echo (int)$page['draft']['id']; ?> <small>— <?php echo $page['draft']['method'] === 'auto' ? 'automatic' : 'semi-automatic'; ?>, <?php echo date('d-m-Y H:i', strtotime($page['draft']['created_at'])); ?></small></h2>
        <div class="stat"><span class="<?php echo empty($st['unplaced']) ? 'ok' : 'bad'; ?>"><b><?php echo (int)$st['placed']; ?> / <?php echo (int)$st['demanded']; ?></b>periods placed</span><span class="<?php echo empty($st['unplaced']) ? 'ok' : 'bad'; ?>"><b><?php echo (int)$st['unplaced']; ?></b>not placed</span><span><b><?php echo (int)$st['units']; ?></b>sections / pairs</span><?php if ($ct[1]): ?><span class="<?php echo $ct[0] === $ct[1] ? 'ok' : ''; ?>"><b><?php echo $ct[0]; ?> / <?php echo $ct[1]; ?></b>class-teacher first periods</span><?php endif; ?><span><b><?php echo (int)$st['soft']; ?></b>soft-rule cost (lower is better)</span><span><b><?php echo h($st['seconds']); ?>s</b><?php echo (int)$st['attempts']; ?> attempts</span></div>
        <?php foreach ($st['warnings'] ?? [] as $w): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> <?php echo h($w); ?></div><?php endforeach; ?>
        <?php if ($page['unplaced']): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> Not placed: <?php echo h(implode(' · ', array_map(fn($u) => $u['label'] . ' ×' . $u['left'] . ' (' . $u['why'] . ')', $page['unplaced']))); ?>. Fix by adding teachers for the subject, easing max/day, or lowering the weekly count — then generate again.</div><?php endif; ?>
        <form method="post" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"><?php echo csrf_field(); ?><input type="hidden" name="draft_id" value="<?php echo (int)$page['draft']['id']; ?>"><button type="submit" name="apply" value="1" class="btn btn-success" onclick="return confirm('Write this draft into the routine of every section of V–X? Their current routine is replaced.');"><i class="fas fa-check"></i> Apply all</button><a href="class_routine.php" class="btn btn-secondary"><i class="fas fa-table"></i> See class routines</a></form>
        <h2 style="font-size:14px"><i class="fas fa-user-clock"></i> Teacher load per day</h2>
        <div style="overflow-x:auto"><table class="ld"><thead><tr><th>Teacher</th><?php foreach (routine_days() as $d): ?><th><?php echo substr($d, 0, 3); ?></th><?php endforeach; ?><th>Week</th></tr></thead><tbody>
        <?php foreach ($teachers as $tid => $t): $l = $page['load'][$tid] ?? []; $w = array_sum($l); if (!$w) continue; ?><tr><td class="nm"><?php echo h($t['staff_name']); ?></td><?php foreach (routine_days() as $d): $n = (int)($l[$d] ?? 0); ?><td class="<?php echo $n > (int)$s['teacher_max_per_day'] ? 'hi' : ''; ?>"><?php echo $n ?: ''; ?></td><?php endforeach; ?><td><b><?php echo $w; ?></b><?php $lim = (int)($limits[$t['designation']] ?? 0); echo $lim ? '/' . $lim : ''; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
        <h2 style="font-size:14px;margin-top:14px"><i class="fas fa-table"></i> Preview</h2>
        <div class="utabs"><?php $i = 0; foreach ($page['grids'] as $k => $g): $u = $page['units'][$k] ?? null; if (!$u) continue; ?><a href="#" data-u="<?php echo h($k); ?>" class="<?php echo $i++ === 0 ? 'on' : ''; ?>"><?php echo h($u['class'] . '-' . $u['label']); ?></a><?php endforeach; ?></div>
        <?php $i = 0; foreach ($page['grids'] as $k => $g): $u = $page['units'][$k] ?? null; if (!$u) continue; ?>
        <div class="ublk <?php echo $i++ === 0 ? 'on' : ''; ?>" data-u="<?php echo h($k); ?>"><?php echo routine_render_week($g, $page['partners'][$k] ?? []); ?>
            <form method="post" style="margin-top:8px"><?php echo csrf_field(); ?><input type="hidden" name="draft_id" value="<?php echo (int)$page['draft']['id']; ?>"><input type="hidden" name="unit" value="<?php echo h($k); ?>"><button type="submit" name="apply" value="1" class="btn btn-secondary" onclick="return confirm('Write only <?php echo h($u['class'] . '-' . $u['label']); ?>?');"><i class="fas fa-check"></i> Apply this one</button></form></div>
        <?php endforeach; ?>
        <script>document.querySelectorAll('.utabs a').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); document.querySelectorAll('.utabs a').forEach(function (x) { x.classList.toggle('on', x === a); }); document.querySelectorAll('.ublk').forEach(function (b) { b.classList.toggle('on', b.dataset.u === a.dataset.u); }); }); });</script>
    </div>
    <?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/routine_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Routine entry — one unit (a section, a pair, or a whole class: see Routine Settings) for the whole
 * week in one grid.  Each cell: subject + teacher; "Split" adds a second group in the same period
 * (Arabic / Sanskrit); "Combined" teaches the period together with other units of the class.
 * Everything is checked again on the server (routine_save_unit) and written in one transaction.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$session_id = (int)($_REQUEST['session_id'] ?? ($active['id'] ?? 0));
$class_id = (int)($_REQUEST['class_id'] ?? 0);
$unit = preg_match('/^[sgc]\d{1,9}$/', (string)($_REQUEST['unit'] ?? '')) ? (string)$_REQUEST['unit'] : '';
$units = $session_id && $class_id ? routine_units($session_id, $class_id) : [];
if ($unit && !isset($units[$unit])) $unit = '';
$self = 'routine_entry.php?session_id=' . $session_id . '&class_id=' . $class_id . '&unit=' . $unit;

// ── AJAX: is this teacher free at day+period (ignoring the unit being edited and its combined partners)?
if (($_GET['ajax'] ?? '') === 'teacher_free') {
    header('Content-Type: application/json');
    $t = (int)($_GET['teacher_id'] ?? 0); $day = (string)($_GET['day'] ?? ''); $pid = (int)($_GET['period_id'] ?? 0);
    $ignore = $unit ? $units[$unit]['section_ids'] : [];
    foreach (explode(',', (string)($_GET['with'] ?? '')) as $k) if (isset($units[$k])) $ignore = array_merge($ignore, $units[$k]['section_ids']);
    $hall = (int)($_GET['s'] ?? 0);   // sent only for combined / split cells
    $busy = ($t && schoolms_valid_weekday($day) && $pid) ? routine_teacher_busy($session_id, $t, $day, $pid, $ignore, $hall ?: null) : null;
    echo json_encode(['busy' => $busy ? trim($busy['class_name'] . '-' . $busy['section_name'], '-') . ($busy['subject_name'] ? ' · ' . $busy['subject_name'] : '') : null], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    if (!$unit) { $_SESSION['error'] = 'Choose a class and section first.'; header('Location: ' . $self); exit(); }
    $label = $units[$unit]['label'];
    if (isset($_POST['save_routine'])) {
        $cells = json_decode((string)($_POST['cells'] ?? ''), true);
        if (!is_array($cells)) { $_SESSION['error'] = 'Nothing to save.'; header('Location: ' . $self); exit(); }
        $r = routine_save_unit($session_id, $class_id, $unit, $cells, $admin_id);
        if ($r['ok']) { log_action($admin_id, 'ROUTINE_SAVED', 'routine', $class_id, null, ['session_id' => $session_id, 'unit' => $label, 'slots' => $r['slots'], 'rows' => $r['rows']]); $_SESSION["success"] = "Routine saved for $label — {$r["slots"]} periods in the week." . (!empty($r["cleared_partner_rows"]) ? " Combined periods you changed were also cleared from the partner sections — check their routine." : ""); }
        else $_SESSION['error'] = implode(' · ', array_slice($r['errors'], 0, 6)) . (count($r['errors']) > 6 ? ' · …' : '');
    } elseif (isset($_POST['copy_routine'])) {
        $src_session = (int)($_POST['src_session'] ?? 0); $src_unit = (string)($_POST['src_unit'] ?? '');
        $src_units = $src_session ? routine_units($src_session, $class_id) : [];
        if (!isset($src_units[$src_unit]) || ($src_session === $session_id && $src_unit === $unit)) $_SESSION['error'] = 'Choose what to copy from.';
        else {
            $cells = routine_unit_cells($src_session, $class_id, $src_unit);
            foreach ($cells as $d => &$per) foreach ($per as &$c) $c['combined'] = [];   // combined partners are not carried over
            unset($per, $c);
            $r = routine_save_unit($session_id, $class_id, $unit, $cells, $admin_id, true);
            if ($r['ok']) { log_action($admin_id, 'ROUTINE_COPIED', 'routine', $class_id, ['from_session' => $src_session, 'from_unit' => $src_units[$src_unit]['label']], ['session_id' => $session_id, 'unit' => $label, 'slots' => $r['slots']]); $_SESSION['success'] = "Copied {$r['slots']} periods from {$src_units[$src_unit]['label']} into $label." . ($r['dropped'] ? ' Teachers dropped where they were already busy: ' . implode('; ', array_slice($r['dropped'], 0, 5)) . (count($r['dropped']) > 5 ? '; …' : '') : ''); }
            else $_SESSION['error'] = implode(' · ', $r['errors']);
        }
    } elseif (isset($_POST['clear_routine'])) {
        $r = routine_save_unit($session_id, $class_id, $unit, [], $admin_id);
        if ($r['ok']) { log_action($admin_id, 'ROUTINE_CLEARED', 'routine', $class_id, null, ['session_id' => $session_id, 'unit' => $label]); $_SESSION['success'] = "Routine of $label cleared."; } else $_SESSION['error'] = implode(' · ', $r['errors']);
    }
    header('Location: ' . $self); exit();
}

$s = routine_settings(); $mode = $s['routine_mode'];
$periods = routine_periods(); $sat_n = $s['saturday_periods'];
$class = $class_id ? db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $class_id) : null;
$payload = null;
if ($unit) {
    $own = $units[$unit]['section_ids'];
    $teachers = routine_teachers(); $limits = routine_workload_limits(); $full = routine_teacher_week_load($session_id); $mine = routine_teacher_week_load($session_id, [], $own);
    // load outside this unit = every slot the teacher has minus the slots this unit is part of (a combined slot counts once)
    $tlist = []; foreach ($teachers as $id => $t) $tlist[] = ['id' => $id, 'name' => $t['staff_name'], 'code' => $t['short_code'], 'limit' => (int)($limits[$t['designation']] ?? 0), 'base' => count(array_diff($full[$id]['slots'] ?? [], $mine[$id]['slots'] ?? []))];
    $slist = []; foreach (routine_class_subjects($session_id, $class_id) as $id => $sub) $slist[] = ['id' => $id, 'name' => $sub['subject_name'], 'tl' => (int)$sub['is_third_language']];
    $others = []; foreach ($units as $k => $u) if ($k !== $unit) $others[$k] = $u['label'];
    // where each teacher already is on each day (outside this unit) — shown in the day view's status column
    $sched = []; $ph = implode(',', array_fill(0, count($own), '?'));
    foreach (db_get_all("SELECT r.teacher_id, r.day_name, p.period_name, p.sort_order, c.class_name, s.section_name FROM routine r JOIN periods p ON p.id = r.period_id JOIN classes c ON c.id = r.class_id JOIN sections s ON s.id = r.section_id WHERE r.session_id = ? AND r.teacher_id IS NOT NULL AND r.section_id NOT IN ($ph) GROUP BY r.teacher_id, r.day_name, r.period_id, r.class_id, r.subject_id ORDER BY p.sort_order", 'i' . str_repeat('i', count($own)), $session_id, ...$own) as $r) { $k = $r['period_name'] . ' ' . $r['class_name'] . '-' . $r['section_name']; $d = &$sched[(int)$r['teacher_id']][$r['day_name']]; $d = $d ?? []; if (!in_array($k, $d, true)) $d[] = $k; unset($d); }
    $payload = ['csrf' => csrf_token(), 'session_id' => $session_id, 'class_id' => $class_id, 'unit' => $unit, 'label' => $units[$unit]['label'], 'days' => routine_days(),
        'periods' => array_map(fn($p) => ['id' => (int)$p['id'], 'name' => $p['period_name'], 'time' => $p['start_time'] ? routine_time($p['start_time']) . '–' . routine_time($p['end_time']) : ''], $periods),
        'saturday' => $sat_n, 'subjects' => $slist, 'teachers' => $tlist, 'others' => $others, 'schedule' => $sched, 'cells' => routine_unit_cells($session_id, $class_id, $unit)];
    // copy sources: other units in this session's class, and units of the same class in other sessions
    $copy_src = [];
    foreach ($sessions as $ss) { foreach (routine_units((int)$ss['id'], $class_id) as $k => $u) { if ((int)$ss['id'] === $session_id && $k === $unit) continue; $n = (int)(db_get_row('SELECT COUNT(*) AS c FROM routine WHERE session_id = ? AND section_id = ?', 'ii', (int)$ss['id'], $u['section_ids'][0])['c'] ?? 0); if ($n) $copy_src[] = ['session_id' => (int)$ss['id'], 'session' => $ss['session_name'], 'unit' => $k, 'label' => $u['label'], 'n' => $n]; } }
}
$staff_n = count(routine_teachers());
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Routine Entry</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .warn { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 10px; padding: 9px 13px; font-size: 13px; margin-bottom: 12px; }
    .unitbar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; } .unitbar h3 { margin: 0; font-size: 16px; color: #0b3d5c; } .unitbar .lc-tag { border-color: #b7d7ee; background: #eef6fc; color: #0b3d5c; } .unitbar .sp { flex: 1; }
    .unitbar .btn { padding: 7px 12px; font-size: 12.5px; }
    .gridwrap { overflow: auto; border: 1px solid #dfe7ef; border-radius: 12px; background: #fff; }
    table.rg { border-collapse: separate; border-spacing: 0; min-width: 100%; font-size: 12px; }
    .rg th { background: #0b3d5c; color: #fff; padding: 7px 6px; text-align: center; font-size: 11.5px; position: sticky; top: 0; z-index: 2; white-space: nowrap; } .rg th small { display: block; font-weight: 400; opacity: .8; font-size: 10px; }
    .rg th.day { text-align: left; left: 0; z-index: 3; min-width: 70px; } .rg td.day { position: sticky; left: 0; background: #f5f9fc; font-weight: 800; color: #0b3d5c; padding: 6px 8px; z-index: 1; border-right: 2px solid #dfe7ef; }
    .rg td { border-bottom: 1px solid #e6edf3; border-right: 1px solid #eef2f6; vertical-align: top; padding: 4px; min-width: 150px; } .rg td.off { background: repeating-linear-gradient(45deg, #f7f9fb, #f7f9fb 6px, #eef2f6 6px, #eef2f6 12px); min-width: 40px; }
    .cell { display: flex; flex-direction: column; gap: 3px; } .cell select { width: 100%; height: 28px; font-size: 12px; padding: 2px 4px; border: 1px solid #c9d6e2; border-radius: 6px; background: #fff; }
    .cell select.sub { font-weight: 700; color: #0b3d5c; } .cell select:disabled { background: #f3f6f9; }
    .cell.filled { background: #f3faf5; border-radius: 8px; padding: 3px; } .cell.comb { background: #eef6fc; } .cell.busy select.tea { border-color: #d63a4a; background: #fde2e4; }
    .cell .g1 { border-top: 1px dashed #c9d6e2; padding-top: 3px; margin-top: 1px; }
    .cell .tools { display: flex; gap: 3px; justify-content: flex-end; } .cell:not(.wide) .tools button i { display: none; } .cell:not(.wide) .tools button::after { content: attr(title); } .cell:not(.wide) .tools button.x::after { content: '×'; } .cell:not(.wide) .tools button.tl::after { content: '3rd lang'; } .cell:not(.wide) .tools button[data-act=split]::after { content: 'Split'; } .cell:not(.wide) .tools button[data-act=comb]::after { content: 'Combined'; } .cell .tools button { border: 1px solid #dfe7ef; background: #fff; border-radius: 5px; font-size: 10.5px; padding: 1px 6px; cursor: pointer; color: #3b5168; } .cell .tools button.on { background: #1a6fa3; color: #fff; border-color: #1a6fa3; } .cell .tools button:hover { border-color: #1a6fa3; }
    .cell .msg { font-size: 10.5px; color: #9d2630; font-weight: 700; } .cell .msg.w { color: #7a4a00; } .cell .combwith { font-size: 10.5px; color: #1a6fa3; font-weight: 700; }
    .pop label.all { border-bottom: 1px dashed #c9d6e2; margin-bottom: 4px; padding-bottom: 5px; }
    .pop { position: absolute; background: #fff; border: 1px solid #c9d6e2; border-radius: 9px; box-shadow: 0 10px 30px rgba(0,0,0,.18); padding: 8px 10px; z-index: 50; font-size: 12.5px; min-width: 180px; } .pop label { display: block; padding: 3px 0; cursor: pointer; } .pop b { display: block; margin-bottom: 4px; color: #0b3d5c; }
    .legend { display: flex; gap: 14px; flex-wrap: wrap; font-size: 12px; color: #3b5168; margin: 8px 0; } .legend i { display: inline-block; width: 12px; height: 12px; border-radius: 3px; vertical-align: -1px; margin-right: 4px; border: 1px solid #d5dee7; }
    .loadbar { display: flex; gap: 6px; flex-wrap: wrap; margin: 10px 0 0; } .loadbar span { font-size: 11.5px; border: 1px solid #dfe7ef; border-radius: 999px; padding: 3px 9px; background: #fff; color: #10253a; } .loadbar span.over { background: #fff6e5; border-color: #f0c987; color: #7a4a00; } .loadbar span.zero { color: #8a9aab; }
    .viewbar { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin: 4px 0 10px; } .vtoggle { display: inline-flex; border: 1px solid #c9d6e2; border-radius: 9px; overflow: hidden; } .vtoggle button { border: 0; background: #fff; padding: 7px 13px; font-size: 12.5px; font-weight: 700; color: #0b3d5c; cursor: pointer; } .vtoggle button.on { background: #0b3d5c; color: #fff; }
    .daypick { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; background: #f5f9fc; border: 1px solid #e1eaf2; border-radius: 12px; padding: 10px 14px; } .daypick label { font-size: 11.5px; font-weight: 700; color: #3b5168; text-transform: uppercase; } .daypick select { height: 40px; min-width: 260px; padding: 6px 12px; border: 2px solid #0b3d5c; border-radius: 8px; font-size: 15px; font-weight: 700; color: #0b3d5c; background: #fff; } .daynote { font-size: 12.5px; color: #6b7d90; }
    .daytabs { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; } .daytabs a { padding: 7px 14px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #0b3d5c; text-decoration: none; font-weight: 700; font-size: 13px; } .daytabs a.on { background: #0b3d5c; color: #fff; border-color: #0b3d5c; } .daytabs a .n { display: inline-block; margin-left: 6px; background: #1b7a3d; color: #fff; border-radius: 999px; font-size: 10.5px; padding: 0 6px; } .daytabs a.on .n { background: #fff; color: #0b3d5c; }
    table.dt { border-collapse: separate; border-spacing: 0; width: 100%; font-size: 13px; } .dt th { background: #0b3d5c; color: #fff; padding: 8px 10px; text-align: left; font-size: 11.5px; text-transform: uppercase; } .dt td { padding: 7px 10px; border-bottom: 1px solid #e6edf3; vertical-align: top; } .dt td.per { width: 90px; white-space: nowrap; } .dt td.per b { display: block; font-size: 14px; color: #0b3d5c; } .dt td.per small { color: #6b7d90; } .dt td.status { width: 34%; font-size: 12.5px; } .dt tr.off td { background: #f7f9fb; color: #6b7d90; font-size: 12.5px; }
    .cell.wide { flex-direction: row; flex-wrap: wrap; align-items: center; gap: 6px 8px; } .cell.wide .g0 { display: flex; gap: 8px; flex: 1 1 auto; min-width: 0; } .cell.wide .g1 { display: flex; gap: 8px; flex: 1 1 100%; border-top: 0; border-left: 3px solid #f0c987; padding: 0 0 0 8px; margin: 0; position: relative; } .cell.wide .g1::before { content: '2nd group'; position: absolute; left: 10px; top: -9px; font-size: 9.5px; font-weight: 700; color: #9a5a00; background: #fff; padding: 0 4px; border-radius: 4px; } .cell.wide select { height: 36px; font-size: 13px; width: auto; flex: 1; min-width: 160px; }
    .cell.wide .tools { flex: 0 0 auto; margin-left: 0; gap: 4px; } .cell.wide .tools button { width: 30px; height: 30px; border-radius: 8px; padding: 0; font-size: 12.5px; display: inline-flex; align-items: center; justify-content: center; opacity: .35; transition: .12s; border-color: transparent; background: #f3f6f9; color: #3b5168; } .dt tr:hover .cell.wide .tools button, .cell.wide .tools button.on, .cell.wide .tools button.tl { opacity: 1; } .cell.wide .tools button.on { background: #1a6fa3; color: #fff; } .cell.wide .tools button.tl { background: #f3eefb; color: #6b3fa3; border: 1px dashed #c9b3e6; } .cell.wide .tools button.x:hover { background: #fde2e4; color: #9d2630; } .cell.wide .tools button:hover { border-color: #1a6fa3; }
    .cell.wide .combwith { flex: 1 1 100%; margin: -2px 0 0; } .cell.wide .combwith i { margin-right: 4px; } .cell.wide .msg { flex: 1 1 100%; }
    .cell.wide.filled { background: transparent; padding: 0; } .cell.wide.comb { background: transparent; } .cell.wide.comb .combwith { display: inline-block; background: #eef6fc; border: 1px solid #b7d7ee; border-radius: 999px; padding: 2px 10px; flex: 0 0 auto; } .cell.wide.busy select.tea { border-color: #d63a4a; background: #fde2e4; }
    .st { display: block; padding: 4px 0; } .st.ok { color: #1b7a3d; } .st.bad { color: #9d2630; } .st small { display: block; color: #6b7d90; font-weight: 400; } .st.muted { color: #b0bec9; }
    .savebar { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 0; margin-top: 12px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap; } .savebar .dirty { color: #7a4a00; font-size: 12.5px; font-weight: 700; display: none; }
    .lc-dialog .src { display: block; border: 1px solid #dfe7ef; border-radius: 8px; padding: 8px 10px; margin-bottom: 6px; cursor: pointer; font-size: 13px; } .lc-dialog .src:has(input:checked) { border-color: #1a6fa3; background: #eef6fc; } .lc-dialog .src small { color: #6b7d90; display: block; }
    @media (max-width: 700px) { .rg td { min-width: 130px; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-edit"></i></div>
        <div><h1>Routine Entry</h1><p>Mode: <b><?php echo h(ROUTINE_MODES[$mode]); ?></b> · <?php echo count($periods); ?> periods, Saturday up to <?php echo $sat_n ? h($periods[$sat_n - 1]['period_name'] ?? $sat_n) : 'none'; ?> · a teacher cannot be in two rooms at once; workload over the limit only warns.</p></div>
        <div class="links"><a href="routine_builder.php"><i class="fas fa-magic"></i> Builder</a><a href="routine_settings.php"><i class="fas fa-sliders-h"></i> Settings</a><a href="class_routine.php"><i class="fas fa-table"></i> Class routines</a><a href="teacher_routine.php"><i class="fas fa-chalkboard-teacher"></i> Teacher routines</a></div>
    </div>
    <?php if (isset($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>
    <?php if (!$periods): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No periods yet — <a href="periods.php">add periods</a> first.</div><?php endif; ?>
    <?php if (!$staff_n): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No active teaching staff — <a href="add_staff.php">add staff</a> first; you can still place subjects and add teachers later.</div><?php endif; ?>

    <form method="get" class="lc-filter">
        <div><label>Session</label><select name="session_id" onchange="this.form.unit.value='';this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.unit.value='';this.form.submit()"><option value="">— choose —</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label><?php echo $mode === 'group_wise' ? 'Section / pair' : ($mode === 'class_wise' ? 'Unit' : 'Section'); ?></label><select name="unit" onchange="this.form.submit()" <?php echo $units ? '' : 'disabled'; ?>><option value="">— choose —</option><?php foreach ($units as $k => $u): ?><option value="<?php echo h($k); ?>" <?php echo $k === $unit ? 'selected' : ''; ?>><?php echo h($u['label']); ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Open</button>
    </form>

    <?php if ($class_id && !$units): ?><div class="lc-empty"><i class="fas fa-th-large"></i>This class has no sections in the chosen session.</div>
    <?php elseif (!$unit): ?><div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class and <?php echo $mode === 'group_wise' ? 'a section or pair' : 'a section'; ?> to open its week.</div>
    <?php else: ?>
    <div class="unitbar"><h3><i class="fas fa-calendar-week"></i> Class <?php echo h($class['class_name'] ?? ''); ?> — <?php echo h($units[$unit]['label']); ?></h3>
        <?php if (count($units[$unit]['section_ids']) > 1): ?><span class="lc-tag"><?php echo count($units[$unit]['section_ids']); ?> sections sit together</span><?php endif; ?>
        <?php $ctr = db_get_row('SELECT st.staff_name, sub.subject_name FROM sections s JOIN staff st ON st.id = s.class_teacher_id LEFT JOIN subjects sub ON sub.id = s.class_teacher_subject_id WHERE s.id = ?', 'i', $units[$unit]['section_ids'][0]); if ($ctr): ?><span class="lc-tag" title="Class teacher — first period every day"><i class="fas fa-user-tie"></i> <?php echo h($ctr['staff_name'] . ($ctr['subject_name'] ? ' · ' . $ctr['subject_name'] : '')); ?></span><?php endif; ?>
        <span class="sp"></span>
        <?php if ($copy_src): ?><button type="button" class="btn btn-secondary" onclick="document.getElementById('copyModal').style.display='flex'"><i class="fas fa-copy"></i> Copy from…</button><?php endif; ?>
        <a class="btn btn-secondary" href="class_routine.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $class_id; ?>&unit=<?php echo h($unit); ?>" target="_blank"><i class="fas fa-print"></i> View / print</a>
        <form method="post" onsubmit="return confirm('Clear the whole week of <?php echo h($units[$unit]['label']); ?>?');" style="margin:0"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="unit" value="<?php echo h($unit); ?>"><button type="submit" name="clear_routine" value="1" class="btn btn-danger"><i class="fas fa-eraser"></i> Clear week</button></form>
    </div>
    <div id="entry">
    <div class="viewbar"><div class="vtoggle"><button type="button" data-view="day"><i class="fas fa-list"></i> Day by day</button><button type="button" data-view="week"><i class="fas fa-th"></i> Whole week</button></div>
        <div class="legend"><span><i style="background:#f3faf5"></i> filled</span><span><i style="background:#eef6fc"></i> combined with another section</span><span><i style="background:#fde2e4"></i> teacher busy elsewhere</span><span><b>Split</b> = two groups in one period</span><span><b>3rd language</b> = whole class split into the Arabic and Sanskrit halls</span></div></div>
    <div id="dayView"><div class="daypick"><label for="daySel"><i class="fas fa-calendar-day"></i> Day</label><select id="daySel"><option value="">— choose the day first —</option></select><span class="daynote" id="dayNote"></span></div><div class="gridwrap" id="dayWrap" style="display:none"><table class="dt" id="dayTable"></table></div><div class="lc-empty" id="dayEmpty"><i class="fas fa-hand-pointer"></i>Choose a day from the list — the periods of that day open below, so nothing goes into the wrong day.</div></div>
    <div id="weekView" style="display:none"><div class="gridwrap"><table class="rg" id="grid"></table></div></div>
    <div class="loadbar" id="loads"></div>
    </div>
    <form method="post" id="saveForm" class="savebar">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="unit" value="<?php echo h($unit); ?>"><input type="hidden" name="cells" id="cells">
        <button type="submit" name="save_routine" value="1" class="btn btn-success" id="saveBtn"><i class="fas fa-save"></i> Save week</button>
        <span class="dirty" id="dirty"><i class="fas fa-circle"></i> unsaved changes</span>
        <span style="color:#6b7d90;font-size:12px;margin-left:auto">Save writes all six days of this <?php echo count($units[$unit]['section_ids']) > 1 ? 'pair' : 'section'; ?>.</span>
    </form>
    <?php if ($copy_src): ?>
    <div class="lc-modal" id="copyModal" onclick="if(event.target===this)this.style.display='none'"><div class="lc-dialog"><h3><i class="fas fa-copy"></i> Copy a routine into <?php echo h($units[$unit]['label']); ?></h3><form method="post" class="body">
        <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="unit" value="<?php echo h($unit); ?>">
        <p style="margin:0 0 10px;color:#4d6178;font-size:13px">The current week of <?php echo h($units[$unit]['label']); ?> is replaced. Teachers who are already busy in that period are left blank (subject kept); combined periods are not copied.</p>
        <?php foreach ($copy_src as $cs): ?><label class="src"><input type="radio" name="src" value="<?php echo (int)$cs['session_id']; ?>|<?php echo h($cs['unit']); ?>" required> <b><?php echo h($cs['label']); ?></b> — session <?php echo h($cs['session']); ?><small><?php echo (int)$cs['n']; ?> routine rows</small></label><?php endforeach; ?>
        <input type="hidden" name="src_session" id="srcSession"><input type="hidden" name="src_unit" id="srcUnit">
        <div style="margin-top:12px;display:flex;gap:8px"><button type="submit" name="copy_routine" value="1" class="btn btn-primary" onclick="var r=document.querySelector('input[name=src]:checked');if(!r)return false;var p=r.value.split('|');document.getElementById('srcSession').value=p[0];document.getElementById('srcUnit').value=p[1];return confirm('Replace the week of <?php echo h($units[$unit]['label']); ?>?');"><i class="fas fa-copy"></i> Copy</button><button type="button" class="btn btn-secondary" onclick="document.getElementById('copyModal').style.display='none'">Cancel</button></div>
    </form></div></div>
    <?php endif; ?>
    <script id="rt-data" type="application/json"><?php echo json_encode($payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
    <script>
    (function () {
        var D = JSON.parse(document.getElementById('rt-data').textContent);
        var cells = D.cells || {}, dirty = false, busyMap = {}, checked = {};
        var view = 'day'; try { view = localStorage.getItem('rt_view') === 'week' ? 'week' : 'day'; } catch (e) {}
        var curDay = '';   // the day is always picked explicitly
        var subById = {}; D.subjects.forEach(function (s) { subById[s.id] = s; });
        var teaById = {}; D.teachers.forEach(function (t) { teaById[t.id] = t; });
        var tl = D.subjects.filter(function (s) { return s.tl; });
        function cell(day, pid) { cells[day] = cells[day] || {}; return cells[day][pid] || null; }
        function setCell(day, pid, c) { cells[day] = cells[day] || {}; if (c) cells[day][pid] = c; else delete cells[day][pid]; dirty = true; document.getElementById('dirty').style.display = 'inline'; }
        function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
        function periodsOf(day) { return day === 'Saturday' ? D.periods.slice(0, D.saturday) : D.periods; }
        function counts() { // periods per teacher in this unit (a slot counts once)
            var n = {}; Object.keys(cells).forEach(function (d) { Object.keys(cells[d]).forEach(function (p) { var c = cells[d][p]; ['g0', 'g1'].forEach(function (g) { if (c[g] && c[g].t) n[c[g].t] = (n[c[g].t] || 0) + 1; }); }); }); return n;
        }
        function dayCount(day) { var n = 0; Object.keys(cells[day] || {}).forEach(function (p) { if (cells[day][p].g0 && cells[day][p].g0.s) n++; }); return n; }
        function teacherOptions(sel) {
            var n = counts(), html = '<option value="0">— teacher —</option>';
            D.teachers.forEach(function (t) { var load = t.base + (n[t.id] || 0), over = t.limit && load > t.limit; html += '<option value="' + t.id + '"' + (t.id === sel ? ' selected' : '') + (over ? ' style="color:#7a4a00"' : '') + '>' + esc(t.code || '') + ' ' + esc(t.name) + ' (' + load + (t.limit ? '/' + t.limit : '') + ')</option>'; });
            return html;
        }
        function subjectOptions(sel) { var html = '<option value="0">— subject —</option>'; D.subjects.forEach(function (s) { html += '<option value="' + s.id + '"' + (s.id === sel ? ' selected' : '') + '>' + esc(s.name) + (s.tl ? ' ◇' : '') + '</option>'; }); return html; }
        function groupHtml(g, which) {
            g = g || {s: 0, t: 0};
            return '<div class="' + which + '"><select class="sub" data-g="' + which + '">' + subjectOptions(g.s) + '</select><select class="tea" data-g="' + which + '">' + teacherOptions(g.t) + '</select></div>';
        }
        function cellHtml(day, pid, compact) {
            var c = cell(day, pid), k = day + '|' + pid, busy = busyMap[k];
            var cls = 'cell' + (compact ? '' : ' wide') + (c && c.g0 && c.g0.s ? ' filled' : '') + (c && c.combined && c.combined.length ? ' comb' : '') + (busy ? ' busy' : '');
            var canComb = Object.keys(D.others).length > 0, has = c && c.g0 && c.g0.s, isTL = tl.length === 2 && canComb;
            var on = function (x) { return x ? ' on' : ''; };
            var tools = '<div class="tools">'
                + (isTL && !has ? '<button type="button" data-act="tl" class="tl" title="3rd language period: ' + esc(tl[0].name + ' / ' + tl[1].name) + ' — every section of the class, split by language"><i class="fas fa-language"></i></button>' : '')
                + (has ? '<button type="button" data-act="split" class="' + on(c.g1) + '" title="' + (c.g1 ? 'Remove the second group' : 'Split: two groups in this period (e.g. Arabic / Sanskrit)') + '"><i class="fas fa-code-branch"></i></button>' : '')
                + (canComb && has ? '<button type="button" data-act="comb" class="' + on(c.combined && c.combined.length) + '" title="' + (c.combined && c.combined.length ? 'Combined with ' + c.combined.map(function (k) { return D.others[k] || k; }).join(', ') + ' — click to change' : 'Combined: teach together with other sections') + '"><i class="fas fa-people-arrows"></i></button>' : '')
                + (c ? '<button type="button" data-act="clear" class="x" title="Clear this period"><i class="fas fa-times"></i></button>' : '')
                + '</div>';
            var html = '<div class="' + cls + '" data-day="' + day + '" data-pid="' + pid + '">' + groupHtml(c && c.g0, 'g0') + (compact ? '' : tools);
            if (c && c.g1) html += groupHtml(c.g1, 'g1');
            if (c && c.combined && c.combined.length) html += '<div class="combwith"><i class="fas fa-people-arrows"></i> with ' + c.combined.map(function (k) { return esc(D.others[k] || k); }).join(', ') + '</div>';
            if (busy && compact) html += '<div class="msg"><i class="fas fa-ban"></i> busy: ' + esc(busy) + '</div>';
            html += (compact ? tools : '') + '</div>';
            return html;
        }
        function statusHtml(day, pid) {
            var c = cell(day, pid), k = day + '|' + pid, busy = busyMap[k], out = [];
            ['g0', 'g1'].forEach(function (g) {
                if (!c || !c[g] || !c[g].t) return;
                var t = teaById[c[g].t]; if (!t) return;
                var n = counts(), load = t.base + (n[t.id] || 0);
                var pname = (D.periods.filter(function (p) { return p.id === pid; })[0] || {}).name || ''; var today = ((D.schedule[t.id] || {})[day] || []).filter(function (x) { return !(c.combined && c.combined.length && x.indexOf(pname + ' ') === 0); }); // partners of a combined slot are this same room
                out.push('<div class="st' + (busy ? ' bad' : ' ok') + '"><b>' + esc(t.code || t.name) + '</b> ' + (busy ? '<i class="fas fa-ban"></i> busy — ' + esc(busy) : '<i class="fas fa-check"></i> free this period') + '<small>' + esc(load + (t.limit ? ' / ' + t.limit : '') + ' a week' + (t.limit && load > t.limit ? ' — over the limit' : '')) + (today.length ? ' · today: ' + esc(today.join(', ')) : '') + '</small></div>');
            });
            return out.length ? out.join('') : '<span class="st muted">—</span>';
        }
        function renderCell(td, day, pid) {
            td.innerHTML = cellHtml(day, pid, view === 'week');
            var st = td.parentElement && td.parentElement.querySelector('td.status'); if (st) st.innerHTML = statusHtml(day, pid);
        }
        function renderTabs() {
            var sel = document.getElementById('daySel'), html = '<option value="">— choose the day first —</option>';
            D.days.forEach(function (d) { var n = dayCount(d); html += '<option value="' + d + '"' + (d === curDay ? ' selected' : '') + '>' + d + (n ? ' — ' + n + ' period' + (n === 1 ? '' : 's') + ' filled' : ' — empty') + '</option>'; });
            sel.innerHTML = html;
            document.getElementById('dayNote').textContent = curDay ? 'Entering ' + curDay + (curDay === 'Saturday' ? ' (up to ' + esc(D.periods[Math.max(0, D.saturday - 1)] ? D.periods[Math.max(0, D.saturday - 1)].name : '') + ')' : '') : '';
        }
        function renderDay() {
            renderTabs();
            document.getElementById('dayWrap').style.display = curDay ? '' : 'none'; document.getElementById('dayEmpty').style.display = curDay ? 'none' : '';
            if (!curDay) { renderLoads(); return; }
            var t = document.getElementById('dayTable'), html = '<thead><tr><th class="per">Period</th><th>Subject &amp; teacher</th><th>Teacher status</th></tr></thead><tbody>';
            periodsOf(curDay).forEach(function (p) { html += '<tr><td class="per"><b>' + esc(p.name) + '</b><small>' + esc(p.time) + '</small></td><td data-day="' + curDay + '" data-pid="' + p.id + '"></td><td class="status"></td></tr>'; });
            if (curDay === 'Saturday' && D.saturday < D.periods.length) html += '<tr class="off"><td colspan="3"><i class="fas fa-info-circle"></i> Saturday runs up to ' + esc(D.periods[Math.max(0, D.saturday - 1)].name) + ' — the other periods are not held.</td></tr>';
            t.innerHTML = html + '</tbody>';
            t.querySelectorAll('td[data-day]').forEach(function (td) { renderCell(td, td.dataset.day, parseInt(td.dataset.pid, 10)); });
            renderLoads(); firstChecks(t);
        }
        function renderGrid() {
            var t = document.getElementById('grid'), html = '<thead><tr><th class="day">Day</th>';
            D.periods.forEach(function (p) { html += '<th>' + esc(p.name) + '<small>' + esc(p.time) + '</small></th>'; });
            html += '</tr></thead><tbody>';
            D.days.forEach(function (day) { html += '<tr><td class="day">' + day.substr(0, 3) + '</td>'; D.periods.forEach(function (p, i) { var off = day === 'Saturday' && i >= D.saturday; html += off ? '<td class="off" title="No ' + esc(p.name) + ' on Saturday"></td>' : '<td data-day="' + day + '" data-pid="' + p.id + '"></td>'; }); html += '</tr>'; });
            t.innerHTML = html + '</tbody>';
            t.querySelectorAll('td[data-day]').forEach(function (td) { renderCell(td, td.dataset.day, parseInt(td.dataset.pid, 10)); });
            renderLoads(); firstChecks(t);
        }
        // pre-existing clashes (e.g. after a copy) are looked up once per cell when it first appears
        function firstChecks(t) { t.querySelectorAll('td[data-day]').forEach(function (td) { var d = td.dataset.day, p = parseInt(td.dataset.pid, 10), c = cell(d, p); if (!checked[d + '|' + p] && c && ((c.g0 && c.g0.t) || (c.g1 && c.g1.t))) checkBusy(d, p, td); }); }
        function render() {
            document.getElementById('dayView').style.display = view === 'day' ? '' : 'none';
            document.getElementById('weekView').style.display = view === 'week' ? '' : 'none';
            document.querySelectorAll('.vtoggle button').forEach(function (b) { b.classList.toggle('on', b.dataset.view === view); });
            if (view === 'day') renderDay(); else renderGrid();
        }
        function renderLoads() {
            var n = counts(), html = '';
            D.teachers.forEach(function (t) { var load = t.base + (n[t.id] || 0); if (!load && !n[t.id]) return; var over = t.limit && load > t.limit; html += '<span class="' + (over ? 'over' : '') + '" title="' + esc(t.name) + '">' + esc(t.code || t.name) + ' ' + load + (t.limit ? '/' + t.limit : '') + (over ? ' ⚠' : '') + '</span>'; });
            document.getElementById('loads').innerHTML = html ? '<span class="zero">Weekly load (this unit included):</span>' + html : '';
        }
        function refreshTeacherLists() { document.querySelectorAll('.cell select.tea').forEach(function (s) { var v = parseInt(s.value, 10) || 0; s.innerHTML = teacherOptions(v); }); renderLoads(); if (view === 'day') { renderTabs(); document.querySelectorAll('#dayTable td[data-day]').forEach(function (td) { var st = td.parentElement.querySelector('td.status'); if (st) st.innerHTML = statusHtml(td.dataset.day, parseInt(td.dataset.pid, 10)); }); } }
        function checkBusy(day, pid, td) {
            var c = cell(day, pid), k = day + '|' + pid; delete busyMap[k]; checked[k] = true;
            var checks = []; ['g0', 'g1'].forEach(function (g) { if (c && c[g] && c[g].t) checks.push(c[g].t); });
            if (!checks.length) { renderCell(td, day, pid); return; }
            var withKeys = (c.combined || []).join(',');
            Promise.all(checks.map(function (t) { return fetch('routine_entry.php?ajax=teacher_free&session_id=' + D.session_id + '&class_id=' + D.class_id + '&unit=' + encodeURIComponent(D.unit) + '&day=' + day + '&period_id=' + pid + '&teacher_id=' + t + '&with=' + encodeURIComponent(withKeys) + '&s=' + ((withKeys || c.g1) ? ((c.g0 && c.g0.t === t) ? c.g0.s : (c.g1 ? c.g1.s : 0)) : 0)).then(function (r) { return r.json(); }).then(function (j) { return j.busy ? (teaById[t] ? teaById[t].code + ' → ' : '') + j.busy : null; }); }))
                .then(function (res) { var b = res.filter(Boolean); if (b.length) busyMap[k] = b.join('; '); renderCell(td, day, pid); }).catch(function () { renderCell(td, day, pid); });
        }
        var root = document.getElementById('entry');
        document.getElementById('daySel').addEventListener('change', function () { curDay = this.value; renderDay(); });
        root.addEventListener('change', function (e) {
            var sel = e.target, box = sel.closest('.cell'); if (!box) return;
            var day = box.dataset.day, pid = parseInt(box.dataset.pid, 10), g = sel.dataset.g, c = cell(day, pid) || {g0: {s: 0, t: 0}, g1: null, combined: []};
            c[g] = c[g] || {s: 0, t: 0};
            if (sel.classList.contains('sub')) {
                c[g].s = parseInt(sel.value, 10) || 0;
                // a third-language subject in g0 opens the split with the other third-language subject
                if (g === 'g0' && c.g0.s && subById[c.g0.s] && subById[c.g0.s].tl && tl.length === 2 && !c.g1) { var other = tl.filter(function (s) { return s.id !== c.g0.s; })[0]; c.g1 = {s: other.id, t: 0}; }
            } else c[g].t = parseInt(sel.value, 10) || 0;
            if (!c.g0.s && !c.g0.t && (!c.g1 || (!c.g1.s && !c.g1.t))) c = null;
            setCell(day, pid, c);
            var td = box.parentElement; refreshTeacherLists(); checkBusy(day, pid, td);
        });
        root.addEventListener('click', function (e) {
            var vb = e.target.closest('.vtoggle button'); if (vb) { view = vb.dataset.view; try { localStorage.setItem('rt_view', view); } catch (x) {} render(); return; }
            var b = e.target.closest('button[data-act]'); if (!b) return;
            var box = b.closest('.cell'), day = box.dataset.day, pid = parseInt(box.dataset.pid, 10), c = cell(day, pid), td = box.parentElement;
            if (b.dataset.act === 'clear') { setCell(day, pid, null); delete busyMap[day + '|' + pid]; renderCell(td, day, pid); refreshTeacherLists(); return; }
            if (b.dataset.act === 'split') { c.g1 = c.g1 ? null : {s: 0, t: 0}; setCell(day, pid, c); renderCell(td, day, pid); return; }
            if (b.dataset.act === 'tl') { setCell(day, pid, {g0: {s: tl[0].id, t: 0}, g1: {s: tl[1].id, t: 0}, combined: Object.keys(D.others)}); renderCell(td, day, pid); return; }
            if (b.dataset.act === 'comb') {
                var old = document.querySelector('.pop'); if (old) old.remove();
                var pop = document.createElement('div'); pop.className = 'pop'; var html = '<b>Teach this period together with:</b><label class="all"><input type="checkbox" data-all="1"> <i>all sections of the class</i></label>';
                Object.keys(D.others).forEach(function (k) { html += '<label><input type="checkbox" value="' + esc(k) + '"' + ((c.combined || []).indexOf(k) >= 0 ? ' checked' : '') + '> ' + esc(D.others[k]) + '</label>'; });
                html += '<div style="margin-top:6px;text-align:right"><button type="button" class="btn btn-primary" style="padding:4px 10px;font-size:12px">Done</button></div>';
                pop.innerHTML = html; document.body.appendChild(pop); var r = b.getBoundingClientRect(); pop.style.left = Math.min(r.left + window.scrollX, window.innerWidth - 220) + 'px'; pop.style.top = (r.bottom + window.scrollY + 4) + 'px';
                pop.querySelector('input[data-all]').addEventListener('change', function () { var on = this.checked; pop.querySelectorAll('input[value]').forEach(function (i) { i.checked = on; }); });
                pop.querySelector('button').addEventListener('click', function () { c.combined = Array.prototype.map.call(pop.querySelectorAll('input[value]:checked'), function (i) { return i.value; }); setCell(day, pid, c); pop.remove(); renderCell(td, day, pid); checkBusy(day, pid, td); });
            }
        });
        document.addEventListener('click', function (e) { var p = document.querySelector('.pop'); if (p && !p.contains(e.target) && !e.target.closest('button[data-act=comb]')) p.remove(); });
        document.getElementById('saveForm').addEventListener('submit', function () { document.getElementById('cells').value = JSON.stringify(cells); dirty = false; });
        window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
        render();
    })();
    </script>
    <?php endif; ?>
</div>
</body>
</html>

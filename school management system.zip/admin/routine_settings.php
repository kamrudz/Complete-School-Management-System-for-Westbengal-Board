<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/routine_helper.php';
require_once '../includes/staff_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Routine settings — how the routine is entered (mode), which sections sit together (pairs),
 * how long Saturday runs, and the weekly period limit per designation (a warning, not a block).
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name FROM academic_sessions ORDER BY id DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? ($active['id'] ?? 0));
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0);
$back = 'routine_settings.php?session_id=' . $session_id . '&class_id=' . $class_id . '#pairs';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $old = routine_settings();
    if (isset($_POST['save_mode'])) {
        $mode = (string)($_POST['routine_mode'] ?? '');
        if (!isset(ROUTINE_MODES[$mode])) { $_SESSION['error'] = 'Unknown routine mode.'; header('Location: routine_settings.php'); exit(); }
        db_update('routine_settings', ['routine_mode' => $mode], ['id' => 1], 'i');
        log_action($admin_id, 'ROUTINE_SETTINGS_UPDATED', 'routine_settings', 1, ['routine_mode' => $old['routine_mode']], ['routine_mode' => $mode]);
        $_SESSION['success'] = 'Routine mode: ' . ROUTINE_MODES[$mode] . '.'; header('Location: routine_settings.php'); exit();
    }
    if (isset($_POST['save_general'])) {
        $sat = (int)($_POST['saturday_periods'] ?? 4); $n = count(routine_periods()); if ($sat < 0 || $sat > max($n, 12)) $sat = min(4, $n);
        $w = (float)($_POST['hs_period_weight'] ?? 1); if ($w < 0.5 || $w > 3) $w = 1.0;
        $limits = []; foreach (array_keys(staff_designations()) as $d) { $v = (int)($_POST['limit'][$d] ?? 0); $limits[$d] = max(0, min(60, $v)); }
        db_begin_transaction();
        try {
            db_update('routine_settings', ['saturday_periods' => $sat, 'hs_period_weight' => number_format($w, 2, '.', '')], ['id' => 1], 'i');
            foreach ($limits as $d => $v) db_execute('INSERT INTO workload_limits (designation, max_weekly_periods) VALUES (?, ?) ON DUPLICATE KEY UPDATE max_weekly_periods = VALUES(max_weekly_periods)', 'si', $d, $v);
            db_commit();
        } catch (Throwable $e) { db_rollback(); error_log('routine settings: ' . $e->getMessage()); $_SESSION['error'] = 'Could not save.'; header('Location: routine_settings.php#general'); exit(); }
        log_action($admin_id, 'ROUTINE_SETTINGS_UPDATED', 'routine_settings', 1, ['saturday_periods' => $old['saturday_periods'], 'hs_period_weight' => $old['hs_period_weight']], ['saturday_periods' => $sat, 'hs_period_weight' => $w, 'limits' => $limits]);
        $_SESSION['success'] = 'Saturday periods, HS weight and workload limits saved.'; header('Location: routine_settings.php#general'); exit();
    }
    if (isset($_POST['add_pair'])) {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['section_ids'] ?? []))))); sort($ids);
        $sections = $session_id && $class_id ? routine_sections($session_id, $class_id) : [];
        $bad = array_diff($ids, array_keys($sections));
        if (count($ids) < 2) $_SESSION['error'] = 'Pick at least two sections for a pair.';
        elseif ($bad) $_SESSION['error'] = 'Those sections do not belong to this class.';
        else {
            $name = implode(' + ', array_map(fn($i) => $sections[$i], $ids));
            db_begin_transaction();
            try {
                $gid = db_insert('section_groups', ['session_id' => $session_id, 'class_id' => $class_id, 'group_name' => $name]);
                foreach ($ids as $i) db_insert('section_group_members', ['group_id' => $gid, 'section_id' => $i]);
                db_commit();
                log_action($admin_id, 'SECTION_PAIR_ADDED', 'section_groups', $gid, null, ['name' => $name, 'section_ids' => $ids]);
                $_SESSION['success'] = 'Pair ' . $name . ' added.';
            } catch (mysqli_sql_exception $e) { db_rollback(); $_SESSION['error'] = $e->getCode() === 1062 ? 'One of those sections is already in a pair.' : 'Could not save the pair.'; }
        }
        header('Location: ' . $back); exit();
    }
    if (isset($_POST['delete_pair'])) {
        $gid = (int)$_POST['delete_pair'];
        $g = db_get_row('SELECT id, group_name, session_id, class_id FROM section_groups WHERE id = ?', 'i', $gid);
        if ($g) { db_execute('DELETE FROM section_groups WHERE id = ?', 'i', $gid); log_action($admin_id, 'SECTION_PAIR_REMOVED', 'section_groups', $gid, ['name' => $g['group_name']], null); $_SESSION['success'] = 'Pair ' . $g['group_name'] . ' removed. Each section keeps the routine rows it already has.'; }
        header('Location: ' . $back); exit();
    }
}

$s = routine_settings(); $mode = $s['routine_mode'];
$periods = routine_periods(); $limits = routine_workload_limits();
$pairs = []; $paired = []; $sections = [];
if ($session_id && $class_id) {
    $sections = routine_sections($session_id, $class_id);
    foreach (db_get_all('SELECT g.id, g.group_name, m.section_id FROM section_groups g JOIN section_group_members m ON m.group_id = g.id WHERE g.session_id = ? AND g.class_id = ? ORDER BY g.group_name, m.section_id', 'ii', $session_id, $class_id) as $r) { $pairs[(int)$r['id']]['name'] = $r['group_name']; $pairs[(int)$r['id']]['ids'][] = (int)$r['section_id']; $paired[(int)$r['section_id']] = true; }
}
$all_pairs = db_get_all('SELECT g.id, g.group_name, g.session_id, g.class_id, c.class_name, a.session_name, (SELECT COUNT(*) FROM routine r JOIN section_group_members m ON m.section_id = r.section_id WHERE m.group_id = g.id) AS routine_rows FROM section_groups g JOIN classes c ON c.id = g.class_id JOIN academic_sessions a ON a.id = g.session_id ORDER BY a.id DESC, c.sort_order, g.group_name');
$staff_count = (int)(db_get_row("SELECT COUNT(*) AS c FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'")['c'] ?? 0);
$designations = staff_designations();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Routine Settings</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 16px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .rt-steps { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px; } .rt-steps a { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #1f4e79; text-decoration: none; font-size: 12.5px; font-weight: 600; } .rt-steps a b { background: #1f4e79; color: #fff; border-radius: 50%; width: 18px; height: 18px; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 14px; padding: 18px 20px; margin-bottom: 18px; }
    .card h2 { margin: 0 0 4px; font-size: 16px; color: #0b3d5c; display: flex; align-items: center; gap: 8px; } .card h2 small { font-weight: 400; color: #6b7d90; font-size: 12.5px; }
    .card .lead { color: #4d6178; font-size: 13px; margin: 0 0 14px; }
    .modes { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 12px; margin-bottom: 14px; }
    .mode { border: 2px solid #dfe7ef; border-radius: 12px; padding: 14px; cursor: pointer; background: #fbfcfe; transition: .15s; position: relative; } .mode:hover { border-color: #9fc3e0; } .mode.on { border-color: #1a6fa3; background: #eef6fc; box-shadow: 0 0 0 3px rgba(26,111,163,.12); }
    .mode input { position: absolute; opacity: 0; } .mode b { display: flex; align-items: center; gap: 8px; font-size: 14.5px; color: #0b3d5c; } .mode b i { color: #1a6fa3; } .mode p { margin: 6px 0 0; font-size: 12.5px; color: #3b5168; line-height: 1.5; } .mode .ex { margin-top: 8px; font-size: 11.5px; color: #6b7d90; background: #fff; border-radius: 7px; padding: 5px 8px; border: 1px dashed #c9d6e2; }
    .mode .cur { position: absolute; top: 10px; right: 10px; background: #1b7a3d; color: #fff; font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 999px; }
    .chips { display: flex; gap: 8px; flex-wrap: wrap; } .chip { display: inline-flex; align-items: center; gap: 6px; border: 1.5px solid #c9d6e2; border-radius: 999px; padding: 6px 12px; font-size: 13px; font-weight: 700; color: #1f4e79; background: #fff; cursor: pointer; user-select: none; } .chip input { accent-color: #1a6fa3; } .chip.dis { opacity: .45; cursor: not-allowed; } .chip:has(input:checked) { background: #1a6fa3; color: #fff; border-color: #1a6fa3; }
    .pair { display: inline-flex; align-items: center; gap: 10px; border: 1px solid #b7d7ee; background: #eef6fc; border-radius: 10px; padding: 8px 12px; margin: 0 8px 8px 0; font-weight: 700; color: #0b3d5c; } .pair form { margin: 0; } .pair button { border: 0; background: transparent; color: #9d2630; cursor: pointer; font-size: 14px; }
    .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px; margin-bottom: 14px; } .grid2 label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin-bottom: 4px; text-transform: uppercase; } .grid2 select, .grid2 input { height: 38px; width: 100%; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; } .grid2 small { display: block; color: #6b7d90; font-size: 11.5px; margin-top: 4px; }
    .limits { display: grid; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); gap: 8px 14px; } .limits label { display: flex; align-items: center; justify-content: space-between; gap: 10px; border: 1px solid #e6edf3; border-radius: 9px; padding: 7px 10px; font-size: 13px; font-weight: 600; color: #10253a; } .limits label span small { display: block; font-weight: 400; color: #6b7d90; font-size: 11px; } .limits input { width: 64px; height: 32px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; font-weight: 700; }
    .warn { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 10px; padding: 9px 13px; font-size: 13px; margin-bottom: 12px; }
    .muted { color: #6b7d90; font-size: 12.5px; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-sliders-h"></i></div>
        <div><h1>Routine Settings</h1><p>How the routine is entered, which sections sit together, how long Saturday runs and how many periods a teacher should carry.</p></div>
        <div class="links"><a href="periods.php"><i class="fas fa-clock"></i> Periods</a><a href="routine_entry.php"><i class="fas fa-edit"></i> Routine Entry</a></div>
    </div>
    <div class="rt-steps"><a href="periods.php"><b>1</b> Periods<?php echo $periods ? ' · ' . count($periods) : ' · none yet'; ?></a><a href="#mode"><b>2</b> Mode</a><a href="#pairs"><b>3</b> Section pairs</a><a href="#general"><b>4</b> Saturday & workload</a><a href="routine_entry.php"><b>5</b> Enter routine</a></div>

    <?php if (isset($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>
    <?php if (!$periods): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No periods yet — <a href="periods.php">set up the periods</a> first; the routine grid is built from them.</div><?php endif; ?>
    <?php if ($staff_count === 0): ?><div class="warn"><i class="fas fa-exclamation-triangle"></i> No active teaching staff — <a href="add_staff.php">add staff</a> before entering a routine.</div><?php endif; ?>

    <div class="card" id="mode">
        <h2><i class="fas fa-layer-group"></i> Routine mode <small>— the unit a routine is written for</small></h2>
        <p class="lead">Whatever the mode, the routine is stored per section, so attendance, substitution and the teacher portal always work section by section.</p>
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="modes">
                <label class="mode <?php echo $mode === 'section_wise' ? 'on' : ''; ?>"><input type="radio" name="routine_mode" value="section_wise" <?php echo $mode === 'section_wise' ? 'checked' : ''; ?>><?php if ($mode === 'section_wise') echo '<span class="cur">current</span>'; ?><b><i class="fas fa-th"></i> Section-wise</b><p>প্রতিটা section-এর নিজের routine। সবচেয়ে flexible; দুটো section কোনো period-এ একসাথে বসলে entry-তে সেই cell "Combined" করা যায়।</p><div class="ex">V-A, V-B, V-C … প্রত্যেকের আলাদা routine</div></label>
                <label class="mode <?php echo $mode === 'group_wise' ? 'on' : ''; ?>"><input type="radio" name="routine_mode" value="group_wise" <?php echo $mode === 'group_wise' ? 'checked' : ''; ?>><?php if ($mode === 'group_wise') echo '<span class="cur">current</span>'; ?><b><i class="fas fa-people-arrows"></i> Paired sections</b><p>দুটো (বা তার বেশি) section একই ঘরে বসে — যেমন A (boys) + B (girls)। Pair-এর জন্য routine একবার লেখা হয়, দুটো section-এই বসে। Pair-এ নেই এমন section একা থাকে।</p><div class="ex">(A + B), (C + D), (E + F) — নিচে Step 3-এ pair ঠিক করুন</div></label>
                <label class="mode <?php echo $mode === 'class_wise' ? 'on' : ''; ?>"><input type="radio" name="routine_mode" value="class_wise" <?php echo $mode === 'class_wise' ? 'checked' : ''; ?>><?php if ($mode === 'class_wise') echo '<span class="cur">current</span>'; ?><b><i class="fas fa-chalkboard"></i> Class-wise</b><p>Class-এর সব section-এর একটাই routine (একই teacher একই সময়ে সব section-এ)। শুধু ছোট স্কুলে, যেখানে section আসলে একটাই ঘর।</p><div class="ex">Class V-এর A, B, C, D — একই routine</div></label>
            </div>
            <button type="submit" name="save_mode" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save mode</button>
        </form>
    </div>

    <div class="card" id="pairs">
        <h2><i class="fas fa-people-arrows"></i> Section pairs <small>— used when the mode is "Paired sections"<?php echo $mode !== 'group_wise' ? ' (mode is ' . ROUTINE_MODES[$mode] . ' now, pairs are kept but not used)' : ''; ?></small></h2>
        <p class="lead">A section can be in one pair only. Pairs are per session, so set them again each year. Removing a pair keeps the routine rows each section already has.</p>
        <form method="get" class="lc-filter" style="margin-bottom:14px">
            <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo (int)$ss['id'] === (int)($active['id'] ?? 0) ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="">— choose —</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        </form>
        <?php if ($class_id && !$sections): ?><div class="lc-empty"><i class="fas fa-th-large"></i>This class has no sections in the chosen session.</div>
        <?php elseif ($class_id): ?>
            <div style="margin-bottom:10px"><?php if (!$pairs): ?><span class="muted">No pairs in this class yet.</span><?php endif; ?>
            <?php foreach ($pairs as $gid => $p): ?><span class="pair"><i class="fas fa-link"></i> <?php echo h($p['name']); ?><form method="post" onsubmit="return confirm('Remove pair <?php echo h($p['name']); ?>?');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><button type="submit" name="delete_pair" value="<?php echo $gid; ?>" title="Remove pair"><i class="fas fa-times-circle"></i></button></form></span><?php endforeach; ?></div>
            <?php $free = array_diff_key($sections, $paired); if (count($free) >= 2): ?>
            <form method="post" id="pairForm">
                <?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                <div class="muted" style="margin-bottom:6px">New pair — tick the sections that sit together:</div>
                <div class="chips" style="margin-bottom:10px"><?php foreach ($sections as $sid => $nm): ?><label class="chip <?php echo isset($paired[$sid]) ? 'dis' : ''; ?>"><input type="checkbox" name="section_ids[]" value="<?php echo $sid; ?>" <?php echo isset($paired[$sid]) ? 'disabled' : ''; ?>> <?php echo h($nm); ?></label><?php endforeach; ?></div>
                <button type="submit" name="add_pair" value="1" class="btn btn-success"><i class="fas fa-link"></i> Add pair</button>
            </form>
            <?php else: ?><span class="muted">Every section of this class is already paired.</span><?php endif; ?>
        <?php else: ?><div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class to see or add its pairs.</div><?php endif; ?>
        <?php if ($all_pairs): ?>
        <h2 style="margin-top:18px;font-size:14px"><i class="fas fa-list"></i> All pairs</h2>
        <table class="lc-table" style="margin-top:6px"><thead><tr><th>Session</th><th>Class</th><th>Pair</th><th>Routine rows</th></tr></thead><tbody>
            <?php foreach ($all_pairs as $p): ?><tr><td><?php echo h($p['session_name']); ?></td><td><?php echo h($p['class_name']); ?></td><td><a href="?session_id=<?php echo (int)$p['session_id']; ?>&class_id=<?php echo (int)$p['class_id']; ?>#pairs" style="font-weight:700"><?php echo h($p['group_name']); ?></a></td><td><?php echo (int)$p['routine_rows']; ?></td></tr><?php endforeach; ?>
        </tbody></table>
        <?php endif; ?>
    </div>

    <div class="card" id="general">
        <h2><i class="fas fa-calendar-day"></i> Saturday & workload</h2>
        <form method="post">
            <?php echo csrf_field(); ?>
            <div class="grid2">
                <div><label>Saturday runs up to</label><select name="saturday_periods"><option value="0" <?php echo $s['saturday_periods'] === 0 ? 'selected' : ''; ?>>No classes on Saturday</option><?php foreach ($periods as $i => $p): ?><option value="<?php echo $i + 1; ?>" <?php echo $s['saturday_periods'] === $i + 1 ? 'selected' : ''; ?>><?php echo h($p['period_name']); ?><?php echo $p['end_time'] ? ' (ends ' . routine_time($p['end_time']) . ')' : ''; ?> — <?php echo $i + 1; ?> period<?php echo $i ? 's' : ''; ?></option><?php endforeach; ?></select><small>School starts at the usual time on Saturday; the routine grid shows only these periods for Saturday.</small></div>
                <div><label>Weight of one XI/XII period</label><input type="number" name="hs_period_weight" step="0.05" min="0.5" max="3" value="<?php echo h(number_format($s['hs_period_weight'], 2, '.', '')); ?>"><small>Used in the workload report only. 1.00 = same as any other period.</small></div>
            </div>
            <label class="muted" style="display:block;margin-bottom:8px;font-weight:700;text-transform:uppercase;font-size:11.5px;color:#3b5168">Maximum periods per week, by designation <span style="font-weight:400;text-transform:none">(0 = does not take classes; going over only shows a warning)</span></label>
            <div class="limits"><?php foreach ($designations as $d => $info): ?><label><span><?php echo h($d); ?><small><?php echo h($info[0]); ?></small></span><input type="number" name="limit[<?php echo h($d); ?>]" min="0" max="60" value="<?php echo (int)($limits[$d] ?? 0); ?>"></label><?php endforeach; ?></div>
            <div style="margin-top:14px"><button type="submit" name="save_general" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save</button></div>
        </form>
    </div>
</div>
<script>
document.querySelectorAll('.mode input').forEach(function (r) { r.addEventListener('change', function () { document.querySelectorAll('.mode').forEach(function (m) { m.classList.toggle('on', m.querySelector('input').checked); }); }); });
</script>
</body>
</html>

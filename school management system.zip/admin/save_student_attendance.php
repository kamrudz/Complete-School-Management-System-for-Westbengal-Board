<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/attendance_helper.php';

/**
 * Save one section's attendance for one day (POST from student_attendance.php).
 * Refused on a Sunday / holiday / future date; only students enrolled in that section are
 * written; the whole section is one transaction; who took it is recorded and logged.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: student_attendance.php'); exit(); }
verify_csrf_or_die();

$session_id = (int)($_POST['session_id'] ?? 0); $class_id = (int)($_POST['class_id'] ?? 0); $section_id = (int)($_POST['section_id'] ?? 0);
$date = trim((string)($_POST['attendance_date'] ?? ''));
$back = 'student_attendance.php?' . http_build_query(['session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $section_id, 'attendance_date' => $date]);
if (!$session_id || !$class_id || !$section_id) { $_SESSION['error'] = 'Choose the class and section first.'; header("Location: student_attendance.php"); exit(); }
if (($why = attendance_day_block($date)) !== '') { $_SESSION['error'] = 'Attendance is not taken on this day — ' . $why; header("Location: $back"); exit(); }
if (!db_get_row('SELECT id FROM sections WHERE id = ? AND class_id = ? AND session_id = ?', 'iii', $section_id, $class_id, $session_id)) { $_SESSION['error'] = 'That section does not belong to the class in this session.'; header("Location: student_attendance.php"); exit(); }

$students = attendance_section_students($session_id, $class_id, $section_id);
if (!$students) { $_SESSION['error'] = 'No active students in this section.'; header("Location: $back"); exit(); }
$status = (array)($_POST['status'] ?? []); $remarks = (array)($_POST['remarks'] ?? []);
$existing = attendance_existing($session_id, $class_id, $section_id, $date);
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$n = ['Present' => 0, 'Absent' => 0, 'Leave' => 0]; $changed = 0;

db_begin_transaction();
try {
    foreach ($students as $s) {
        $uid = $s['id'];
        $st = $status[$uid] ?? 'Present';                                 // untouched = present
        if (!in_array($st, ATTENDANCE_STATUSES, true)) $st = 'Present';
        $rem = $st === 'Present' ? '' : mb_substr(trim((string)($remarks[$uid] ?? '')), 0, 200);
        $n[$st]++;
        $old = $existing[$uid] ?? null;
        if ($old && $old['status'] === $st && (string)$old['remarks'] === $rem) continue;   // nothing to write
        db_execute('INSERT INTO student_attendance (session_id, class_id, section_id, student_id, attendance_date, status, remarks, marked_by_type, marked_by)
            VALUES (?,?,?,?,?,?,?,\'admin\',?) ON DUPLICATE KEY UPDATE status = VALUES(status), remarks = VALUES(remarks), marked_by_type = VALUES(marked_by_type), marked_by = VALUES(marked_by)',
            'iiissssi', $session_id, $class_id, $section_id, $uid, $date, $st, $rem, $admin_id);
        $changed++;
    }
    db_commit();
} catch (Throwable $e) {
    db_rollback();
    error_log('attendance save: ' . $e->getMessage());
    $_SESSION['error'] = 'Attendance could not be saved — nothing was changed.';
    header("Location: $back"); exit();
}
$sec = db_get_row('SELECT c.class_name, s.section_name FROM sections s JOIN classes c ON c.id = s.class_id WHERE s.id = ?', 'i', $section_id) ?: [];
log_action($admin_id, $existing ? 'ATTENDANCE_UPDATED' : 'ATTENDANCE_TAKEN', 'student_attendance', ($sec['class_name'] ?? '') . '-' . ($sec['section_name'] ?? '') . ' ' . $date, null,
    ['date' => $date, 'class' => $sec['class_name'] ?? '', 'section' => $sec['section_name'] ?? '', 'present' => $n['Present'], 'absent' => $n['Absent'], 'leave' => $n['Leave'], 'rows_written' => $changed]);
$_SESSION['success'] = ($existing ? 'Attendance updated' : 'Attendance saved') . ' for ' . ($sec['class_name'] ?? '') . '-' . ($sec['section_name'] ?? '') . ' on ' . date('d-m-Y', strtotime($date)) . " — Present {$n['Present']}, Absent {$n['Absent']}, Leave {$n['Leave']}.";
header("Location: $back");
exit();

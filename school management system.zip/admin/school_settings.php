<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/base_url.php';
require_once '../includes/logger.php';

// The school's own details: every certificate, ID card and mark sheet prints the name, address, codes,
// logo and the HOI's signature from here, and a new student's School UID starts with the prefix.
$school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];
$fields = ['school_name', 'udise_code', 'established_year', 'school_address', 'phone', 'email', 'school_code', 'hs_code', 'vocational_code', 'hoi_name', 'student_id_prefix', 'site_base_url'];
$images = ['logo' => ['logo_', 'Logo'], 'hoi_signature' => ['sig_', 'Signature']];

if (isset($_POST['update_settings'])) {
    verify_csrf_or_die();
    $v = [];
    foreach ($fields as $f) $v[$f] = trim((string)($_POST[$f] ?? ''));
    $v['student_id_prefix'] = preg_replace('/[^A-Z0-9_-]/', '', strtoupper($v['student_id_prefix']));
    $year = $v['established_year'];
    $v['established_year'] = $year === '' ? null : $year;
    $email = app_safe_email_or_empty($v['email']);
    $url = app_safe_url_or_empty($v['site_base_url']);

    $error = '';
    if ($year !== '' && (!ctype_digit($year) || (int)$year < 1800 || (int)$year > (int)date('Y'))) {
        $error = 'The year the school was established must be a year, like 1966.';
    } elseif ($email === false) {
        $error = 'Please enter a valid email address.';
    } elseif ($url === false) {
        $error = 'Public site address must be a full URL, for example http://192.168.1.5/schooltest';
    } else {
        $v['email'] = $email;
        $v['site_base_url'] = rtrim($url, '/');
        // the setup gate's list; the logo counts when one is stored or is being uploaded now
        $has_logo = !empty($school['logo']) || ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK;
        $missing = [];
        foreach (schoolms_required_settings() as $col => $label) {
            if ($col === 'logo' ? !$has_logo : $v[$col] === '') $missing[] = $label;
        }
        if ($missing) $error = 'এই ঘরগুলো ছাড়া School Settings সেভ করা যাবে না: ' . implode(', ', $missing);
    }
    if ($error !== '') {
        $_SESSION['error'] = $error;
        header('Location: school_settings.php'); exit;
    }

    db_execute('INSERT INTO school_settings (id, ' . implode(', ', $fields) . ') VALUES (1' . str_repeat(', ?', count($fields)) . ')
        ON DUPLICATE KEY UPDATE ' . implode(', ', array_map(fn($f) => "$f = VALUES($f)", $fields)),
        str_repeat('s', count($fields)), ...array_values($v));

    $failed = [];
    foreach ($images as $col => [$prefix, $label]) {
        $up = safe_uploaded_file($_FILES[$col] ?? [], '../uploads/', ['jpg', 'jpeg', 'png', 'gif', 'webp'],
            ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], $prefix, 2 * 1024 * 1024);
        if (!$up['ok']) { $failed[] = "$label: " . $up['error']; continue; }
        if ($up['filename'] === '') continue;   // no new file chosen
        if (!empty($school[$col])) app_unlink_upload('../uploads/', $school[$col]);
        db_execute("UPDATE school_settings SET $col = ? WHERE id = 1", 's', $up['filename']);
    }
    log_action((int)($_SESSION['admin_id'] ?? 0), 'SCHOOL_SETTINGS_SAVED', 'school_settings', 1);
    $_SESSION[$failed ? 'error' : 'success'] = $failed ? 'Settings saved, but not the image — ' . implode('; ', $failed) : 'School Settings saved.';
    header('Location: school_settings.php'); exit;
}

$val = fn(string $f): string => htmlspecialchars((string)($school[$f] ?? ''), ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Arial, sans-serif; }
    body { background: #f4f6f9; padding: 20px; }
    .container { background: #fff; padding: 25px; border-radius: 14px; max-width: 900px; margin: auto; box-shadow: 0 2px 15px rgba(0,0,0,0.08); }
    h2 { color: #003366; display: flex; align-items: center; gap: 10px; font-size: 26px; margin-bottom: 20px; }
    .info-box { background: #e8f4ff; padding: 14px 20px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid #1f5b8a; display: flex; align-items: center; gap: 14px; font-size: 14px; color: #1a3b55; }
    .info-box i { color: #1f5b8a; font-size: 22px; } .info-box a { color: #003366; font-weight: 600; text-decoration: none; }
    .box { background: #f8f9fa; padding: 15px 18px; border-radius: 10px; margin-bottom: 20px; }
    .box h4 { color: #003366; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
    .form-group { margin-bottom: 18px; }
    .form-group label { display: block; font-weight: 600; margin-bottom: 5px; color: #1a3b55; font-size: 14px; }
    .form-group label i { margin-right: 8px; color: #1f5b8a; width: 18px; }
    .form-group input, .form-group textarea { width: 100%; padding: 10px 14px; border: 2px solid #e4edf6; border-radius: 8px; font-size: 14px; background: #fff; }
    .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #1f5b8a; box-shadow: 0 0 0 3px rgba(31,91,138,0.1); }
    .form-group textarea { min-height: 80px; resize: vertical; }
    .req { color: #dc3545; font-weight: 700; }
    .hint { font-size: 12px; color: #6c7a8a; margin-top: 4px; display: block; }
    .preview-img { margin-top: 10px; border-radius: 8px; border: 2px solid #e4edf6; padding: 4px; max-width: 200px; max-height: 120px; object-fit: contain; background: #f8f9fa; display: block; }
    .btn { padding: 12px 30px; background: #28a745; color: #fff; border: 2px solid transparent; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 15px; display: inline-flex; align-items: center; gap: 10px; text-decoration: none; }
    .btn:hover { background: #218838; }
    .btn-outline { background: transparent; color: #003366; border-color: #003366; } .btn-outline:hover { background: #003366; color: #fff; }
    .actions { display: flex; gap: 12px; margin-top: 20px; flex-wrap: wrap; }
    .alert { padding: 12px 18px; border-radius: 10px; margin-bottom: 18px; display: flex; align-items: center; gap: 12px; font-weight: 600; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    @media (max-width: 768px) { .form-row { grid-template-columns: 1fr; } .actions { flex-direction: column; } .btn { justify-content: center; } }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="container">
    <h2><i class="fas fa-school"></i> School Settings</h2>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($_SESSION[$kind], ENT_QUOTES, 'UTF-8'); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <div class="info-box"><i class="fas fa-info-circle"></i>
        <div>The public website's content (hero, headmaster, about, admission) is set in <a href="website_settings.php"><i class="fas fa-globe"></i> Website Settings</a>.</div>
    </div>

    <form method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="box">
            <h4><i class="fas fa-university"></i> Basic Information</h4>
            <div class="form-row">
                <div class="form-group"><label><i class="fas fa-university"></i> School Name <span class="req">*</span></label>
                    <input type="text" name="school_name" required value="<?php echo $val('school_name'); ?>" placeholder="Enter school name"></div>
                <div class="form-group"><label><i class="fas fa-id-card"></i> DISE Code <span class="req">*</span></label>
                    <input type="text" name="udise_code" required value="<?php echo $val('udise_code'); ?>" placeholder="Enter DISE code"></div>
                <div class="form-group"><label><i class="fas fa-landmark"></i> Established (year)</label>
                    <input type="number" name="established_year" min="1800" max="<?php echo date('Y'); ?>" value="<?php echo $val('established_year'); ?>" placeholder="e.g. 1966">
                    <small class="hint">Printed as "Estd. <?php echo (int)($school['established_year'] ?? 0) ?: 'YYYY'; ?>" under the school's name on every printed sheet and on the website.</small></div>
            </div>
            <div class="form-group"><label><i class="fas fa-map-marker-alt"></i> School Address <span class="req">*</span></label>
                <textarea name="school_address" required placeholder="Enter school address"><?php echo $val('school_address'); ?></textarea></div>
            <div class="form-row">
                <div class="form-group"><label><i class="fas fa-phone"></i> Phone <span class="req">*</span></label>
                    <input type="text" name="phone" required value="<?php echo $val('phone'); ?>" placeholder="Enter phone number"></div>
                <div class="form-group"><label><i class="fas fa-envelope"></i> Email <span class="req">*</span></label>
                    <input type="email" name="email" required value="<?php echo $val('email'); ?>" placeholder="Enter email address"></div>
            </div>
        </div>

        <div class="box">
            <h4><i class="fas fa-code"></i> School Codes</h4>
            <div class="form-row">
                <div class="form-group"><label><i class="fas fa-code"></i> Index No.</label>
                    <input type="text" name="school_code" value="<?php echo $val('school_code'); ?>" placeholder="Madhyamik Index No., e.g. R-152"></div>
                <div class="form-group"><label><i class="fas fa-code"></i> HS Code</label>
                    <input type="text" name="hs_code" value="<?php echo $val('hs_code'); ?>" placeholder="Enter HS code"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label><i class="fas fa-code"></i> Vocational Code</label>
                    <input type="text" name="vocational_code" value="<?php echo $val('vocational_code'); ?>" placeholder="Enter vocational code"></div>
                <div class="form-group"><label><i class="fas fa-user-tie"></i> HOI Name <span class="req">*</span></label>
                    <input type="text" name="hoi_name" required value="<?php echo $val('hoi_name'); ?>" placeholder="Enter Head of Institution name"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label><i class="fas fa-id-badge"></i> Student ID Prefix</label>
                    <input type="text" name="student_id_prefix" value="<?php echo $val('student_id_prefix'); ?>" placeholder="যেমন: ULPHS, DHS, MHS" maxlength="15" style="text-transform:uppercase" oninput="this.value=this.value.toUpperCase()">
                    <small class="hint">এই prefix দিয়ে Student ID তৈরি হবে — যেমন <strong><?php echo htmlspecialchars(($school['student_id_prefix'] ?? '') ?: 'ULPHS', ENT_QUOTES, 'UTF-8'); ?>-<?php echo date('Y'); ?>-0001</strong></small></div>
            </div>
        </div>

        <div class="box">
            <h4><i class="fas fa-qrcode"></i> Public Site Address</h4>
            <div class="form-group"><label><i class="fas fa-link"></i> Site Base URL</label>
                <input type="url" name="site_base_url" placeholder="http://192.168.1.5/schooltest" value="<?php echo $val('site_base_url'); ?>">
                <small class="hint">⚠️ Certificate, Admit Card আর ID Card-এর QR কোড এই ঠিকানা দিয়ে তৈরি হয়। কাগজে একবার ছাপা হয়ে গেলে লিঙ্ক আর বদলানো যায় না, তাই
                    <strong>কার্ড ছাপার আগে</strong> এটা ঠিক করে নিন। খালি রাখলে এখনকার ঠিকানা থেকে অনুমান করে নেওয়া হবে — যা এখন
                    <strong><?php echo htmlspecialchars(get_site_base_url($conn), ENT_QUOTES, 'UTF-8'); ?></strong>, এবং সেটা অন্য কম্পিউটার থেকে কাজ নাও করতে পারে।</small></div>
        </div>

        <div class="box">
            <h4><i class="fas fa-image"></i> Logo &amp; Signature</h4>
            <div class="form-row">
                <?php foreach ($images as $col => [, $label]): $has = !empty($school[$col]); ?>
                <div class="form-group"><label><i class="fas fa-<?php echo $col === 'logo' ? 'image' : 'pen'; ?>"></i> <?php echo $col === 'logo' ? 'School Logo <span class="req">*</span>' : 'HOI Signature'; ?></label>
                    <input type="file" name="<?php echo $col; ?>" accept="image/*"<?php echo $col === 'logo' && !$has ? ' required' : ''; ?>>
                    <?php if ($has): ?><img src="../uploads/<?php echo $val($col); ?>" class="preview-img" alt="<?php echo $label; ?>"><?php endif; ?>
                    <small class="hint">JPG, PNG, GIF, WEBP · Max 2MB<?php echo $has ? ' — নতুন ফাইল দিলে পুরনোটা বদলে যাবে' : ''; ?></small></div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="actions">
            <button type="submit" name="update_settings" class="btn"><i class="fas fa-save"></i> Update Settings</button>
            <a href="dashboard.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Dashboard</a>
        </div>
    </form>
</div>
</body>
</html>

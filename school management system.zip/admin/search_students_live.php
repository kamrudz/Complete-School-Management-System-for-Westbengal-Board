<?php
require_once '../includes/auth.php';
require_admin_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');


include("../includes/db.php");
require_once '../includes/student_helper.php';

$q = trim($_GET['q'] ?? '');
if(mb_strlen($q) < 2) {
    echo json_encode(['results' => []]);
    exit();
}
$limit = 12;
// Escape LIKE wildcard characters in the user's search term so % and _ are treated literally
$like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';

$results = [];
$stmt = mysqli_prepare($conn, "
    SELECT s.id, s.student_name, s.photo, s.mobile, s.banglarshiksha_id, s.pen_id, s.student_status,
           h.roll_no, c.class_name, sec.section_name,
           g.father_name, g.guardian_name
    FROM students s
    LEFT JOIN student_academic_history h ON h.id = (
        SELECT h2.id FROM student_academic_history h2
        WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1
    )
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    WHERE s.student_status != 'Deleted'
      AND (
            s.student_name LIKE ? ESCAPE '\\\\'
         OR s.id LIKE ? ESCAPE '\\\\'
         OR s.mobile LIKE ? ESCAPE '\\\\'
         OR s.banglarshiksha_id LIKE ? ESCAPE '\\\\'
         OR s.pen_id LIKE ? ESCAPE '\\\\'
         OR g.father_name LIKE ? ESCAPE '\\\\'
         OR g.guardian_name LIKE ? ESCAPE '\\\\'
      )
    ORDER BY s.student_name ASC
    LIMIT ?
");
mysqli_stmt_bind_param($stmt, 'sssssssi', $like, $like, $like, $like, $like, $like, $like, $limit);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

while($r = mysqli_fetch_assoc($res)) {
    $guardian = $r['guardian_name'] ?: $r['father_name'];
    $classSec = trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''));

    $sub = [];
    if($guardian) $sub[] = $guardian;
    if($classSec) $sub[] = $classSec;
    if(!empty($r['roll_no'])) $sub[] = 'Roll: ' . $r['roll_no'];
    $sub[] = $r['id'];
    if(!empty($r['mobile'])) $sub[] = $r['mobile'];

    $results[] = [
        'id'      => $r['id'],
        'title'   => $r['student_name'],
        'subtitle'=> implode(' • ', $sub),
        'photo'   => !empty($r['photo']) ? '../uploads/students/' . $r['photo'] : '',
        'status'  => $r['student_status'],
        'url'     => student_page_url('view_student.php', $r['id']),
    ];
}

echo json_encode(['results' => $results]);

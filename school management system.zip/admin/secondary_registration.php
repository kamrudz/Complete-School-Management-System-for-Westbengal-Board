<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/board_registration_page.php';

/** Madhyamik (WBBSE) Registration, Class IX — the shared board page of includes/board_registration_page.php. */
board_registration_page('wbbse', 'secondary_registration.php');

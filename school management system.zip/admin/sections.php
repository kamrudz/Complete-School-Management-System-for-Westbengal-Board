<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/section_helper.php';
require_once '../includes/logger.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $section = db_get_row('SELECT s.section_name, c.class_name FROM sections s JOIN classes c ON c.id = s.class_id WHERE s.id = ?', 'i', $id);
    $deps = $section ? db_dependents('sections', $id) : [];
    if (!$section) {
        $_SESSION['error'] = 'Section not found.';
    } elseif ($deps) {
        $_SESSION['error'] = 'Cannot delete — the section is in use by ' . db_dependents_text($deps) . '.';
    } else {
        db_execute('DELETE FROM sections WHERE id = ?', 'i', $id);
        log_action((int)($_SESSION['admin_id'] ?? 0), 'SECTION_DELETED', 'sections', $id, $section);
        $_SESSION['success'] = "Section {$section['class_name']}-{$section['section_name']} deleted.";
    }
    header('Location: sections.php?' . http_build_query(['session_id' => $_POST['session_id'] ?? '', 'class_id' => $_POST['class_id'] ?? ''])); exit;
}

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$active_id = 0; foreach ($sessions as $s) if ($s['status'] === 'Active') $active_id = (int)$s['id'];
$session_id = isset($_GET['session_id']) ? (int)$_GET['session_id'] : $active_id;   // 0 = every session
$class_id = (int)($_GET['class_id'] ?? 0);

$sql = 'SELECT s.id, s.section_name, s.class_id, s.session_id, c.class_name, a.session_name
        FROM sections s JOIN classes c ON c.id = s.class_id JOIN academic_sessions a ON a.id = s.session_id WHERE 1 = 1';
$types = ''; $params = [];
if ($session_id) { $sql .= ' AND s.session_id = ?'; $types .= 'i'; $params[] = $session_id; }
if ($class_id) { $sql .= ' AND s.class_id = ?'; $types .= 'i'; $params[] = $class_id; }
$groups = [];   // one row per class and session
foreach (db_get_all($sql . ' ORDER BY a.session_name DESC, c.sort_order, s.section_name', $types, ...$params) as $r) {
    $key = $r['session_id'] . '-' . $r['class_id'];
    $groups[$key] ??= ['class' => $r['class_name'], 'session' => $r['session_name'], 'sections' => []];
    $groups[$key]['sections'][] = $r;
}
$in_use = db_referenced_ids('sections');
$shown = 0; $locked = 0;
foreach ($groups as $g) foreach ($g['sections'] as $s) { $shown++; if (isset($in_use[(int)$s['id']])) $locked++; }
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sections</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
    .tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag { display: inline-flex; align-items: center; gap: 4px; padding: 3px 4px 3px 10px; background: #eef4fb; border: 1px solid #d6e4f2; border-radius: 16px; font-weight: 700; color: #003366; font-size: 13px; }
    .tag.locked { background: #f4f6f8; border-color: #e1e6eb; color: #55677a; }
    .tag .icon-btn { font-size: 11px; padding: 3px 5px; }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-layer-group"></i> Sections</div>
        <div class="row-actions">
            <a href="copy_sections.php" class="btn btn-primary"><i class="fas fa-copy"></i> Copy Sections</a>
            <a href="add_section.php" class="btn btn-success"><i class="fas fa-plus"></i> Add Sections</a>
        </div>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <div class="stats-row">
        <div class="stat-card"><div class="number"><?php echo $shown; ?></div><div class="label">Sections</div></div>
        <div class="stat-card"><div class="number green"><?php echo count($groups); ?></div><div class="label">Classes</div></div>
        <div class="stat-card"><div class="number orange"><?php echo $locked; ?></div><div class="label">In use (locked)</div></div>
    </div>

    <form method="get" class="filter-box"><div class="filter-row">
        <div class="filter-group"><label><i class="fas fa-calendar-alt"></i> Session</label>
            <select name="session_id" onchange="this.form.submit()">
                <option value="0">All sessions</option>
                <?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === $session_id ? 'selected' : ''; ?>><?php echo $h($s['session_name']) . ($s['status'] === 'Active' ? ' (Active)' : ''); ?></option><?php endforeach; ?>
            </select></div>
        <div class="filter-group"><label><i class="fas fa-chalkboard"></i> Class</label>
            <select name="class_id" onchange="this.form.submit()">
                <option value="0">All classes</option>
                <?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo $h($c['class_name']); ?></option><?php endforeach; ?>
            </select></div>
    </div></form>

    <?php if (!$groups): ?>
    <div class="empty-state"><i class="fas fa-layer-group"></i><h3>No sections here</h3><p>Click <strong>Add Sections</strong> to create them.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Class</th><th>Session</th><th>Sections</th><th>Count</th></tr></thead>
            <tbody>
            <?php foreach ($groups as $g): ?>
                <tr>
                    <td><strong><?php echo $h($g['class']); ?></strong></td>
                    <td><?php echo $h($g['session']); ?></td>
                    <td><div class="tags">
                    <?php foreach ($g['sections'] as $s): $sid = (int)$s['id']; ?>
                        <?php if (isset($in_use[$sid])): ?>
                        <span class="tag locked" title="In use — locked"><?php echo $h($s['section_name']); ?> <a href="edit_section.php?id=<?php echo $sid; ?>" class="icon-btn" title="In use — see why"><i class="fas fa-lock"></i></a></span>
                        <?php else: ?>
                        <span class="tag"><?php echo $h($s['section_name']); ?>
                            <a href="edit_section.php?id=<?php echo $sid; ?>" class="icon-btn" title="Edit"><i class="fas fa-edit"></i></a>
                            <form method="post" onsubmit="return confirm('Delete section <?php echo $h($g['class'] . '-' . $s['section_name']); ?>?')" style="display:inline">
                                <?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo $sid; ?>"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                                <button type="submit" class="icon-btn danger" title="Delete"><i class="fas fa-trash"></i></button>
                            </form></span>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    </div></td>
                    <td><span class="badge badge-info"><?php echo count($g['sections']); ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$active = count(array_filter($sessions, fn($s) => $s['status'] === 'Active'));
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Sessions</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-calendar-alt"></i> Academic Sessions</div>
        <a href="add_session.php" class="btn btn-success"><i class="fas fa-plus"></i> Add New Session</a>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($_SESSION[$kind], ENT_QUOTES, 'UTF-8'); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <div class="stats-row">
        <div class="stat-card"><div class="number"><?php echo count($sessions); ?></div><div class="label">Total Sessions</div></div>
        <div class="stat-card"><div class="number green"><?php echo $active; ?></div><div class="label">Active</div></div>
        <div class="stat-card"><div class="number red"><?php echo count($sessions) - $active; ?></div><div class="label">Inactive</div></div>
    </div>

    <?php if (!$sessions): ?>
    <div class="empty-state"><i class="fas fa-calendar-times"></i><h3>No sessions yet</h3><p>Click <strong>Add New Session</strong> to create one.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>#</th><th>Session</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($sessions as $i => $s): $is_active = $s['status'] === 'Active'; ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><strong><?php echo htmlspecialchars($s['session_name'], ENT_QUOTES, 'UTF-8'); ?></strong></td>
                    <td><span class="badge badge-<?php echo $is_active ? 'success' : 'danger'; ?>"><?php echo $is_active ? 'ACTIVE' : 'INACTIVE'; ?></span></td>
                    <td><div class="row-actions">
                        <a href="edit_session.php?id=<?php echo (int)$s['id']; ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i> Rename</a>
                        <?php if ($is_active): ?>
                            <span style="color:#28a745;font-size:13px;font-weight:600"><i class="fas fa-check-circle"></i> Current</span>
                        <?php else: ?>
                            <form method="post" action="activate_session.php" onsubmit="return confirm('Make <?php echo htmlspecialchars($s['session_name'], ENT_QUOTES, 'UTF-8'); ?> the active session?')">
                                <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$s['id']; ?>">
                                <button type="submit" class="btn btn-warning btn-sm"><i class="fas fa-play"></i> Activate</button>
                            </form>
                        <?php endif; ?>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

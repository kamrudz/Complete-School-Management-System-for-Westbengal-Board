<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/stats_helper.php';
require_once '../includes/sibling_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Brothers and sisters. Children of one guardian row are a family — the database already says so — and the
 * five guardian fields are only used for the one thing the guardian row cannot answer: two children of the
 * same parents sitting on two different guardian rows, which someone has to join up by hand.
 */
const SIB_MANY = 5;   // more children than this on one guardian row is worth a second look

$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? 0);
if (!isset($sessions[$session_id])) $session_id = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? array_key_first($sessions));
$classes = class_rows();
$class_id = (int)($_GET['class_id'] ?? 0);
if (!isset($classes[$class_id])) $class_id = 0;
$search = trim((string)($_GET['search'] ?? ''));
$per = (int)($_GET['per'] ?? 50);
if (!in_array($per, [25, 50, 100, 200], true)) $per = 50;
$page = max(1, (int)($_GET['page'] ?? 1));
$export = !empty($_GET['export']);
$session_name = exam_session_name($session_id);

/** Status of a student, for the chip beside the name. */
$chips = ['Active' => ['On the roll', 'ok'], 'TC' => ['Took a TC', 'warn'], 'Passed' => ['Passed out', 'off'],
    'Deactivated' => ['Deactivated', 'bad'], 'Deleted' => ['Deleted', 'bad']];

$families = sib_families($session_id, $class_id, $search);
$not_linked = sib_not_linked($conn);
$too_many = sib_too_many(SIB_MANY);
$children = array_sum(array_map(fn($f) => count($f['children']), $families));

if ($export) {
    $rows = [];
    foreach ($families as $fam) {
        foreach ($fam['children'] as $i => $ch) {
            $rows[] = [$i === 0 ? (string)$fam['father_name'] : '', $i === 0 ? (string)$fam['mother_name'] : '', $i === 0 ? (string)$fam['mobile'] : '',
                $ch['id'], $ch['student_name'], $ch['gender'], (string)$ch['class_name'], (string)$ch['section_name'], (string)$ch['roll_no'], $ch['student_status']];
        }
    }
    $out = exam_xlsx_title('Brothers & sisters — ' . count($families) . ' families, ' . $children . ' students',
        'Session ' . $session_name . ($class_id ? ' · Class ' . $classes[$class_id]['name'] : '') . ($search !== '' ? ' · "' . $search . '"' : ''));
    $out[] = ['Father', 'Mother', 'Mobile', 'School UID', 'Student', 'Gender', 'Class', 'Section', 'Roll', 'Status'];
    foreach ($rows as $r) $out[] = $r;
    SimpleXLSXWriter::download('Siblings_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $session_name) . '.xlsx', $out, 'Siblings', exam_xlsx_opts(10, 22));
}

$total = count($families);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$shown = array_slice($families, ($page - 1) * $per, $per, true);
$link = fn(array $extra = []) => 'sibling_report.php?' . http_build_query(array_merge(
    ['session_id' => $session_id, 'class_id' => $class_id, 'search' => $search, 'per' => $per, 'page' => $page], $extra));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Brothers &amp; Sisters</title>
<?php exam_styles('rpt'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb div { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; }
    .sb b { display: block; font-size: 21px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .fam { border: 1px solid #e3e9f0; border-radius: 11px; padding: 10px 13px; margin-bottom: 9px; }
    .fam .par { display: flex; gap: 14px; flex-wrap: wrap; align-items: baseline; margin-bottom: 7px; font-size: 13px; }
    .fam .par b { color: var(--ex-dark); }
    .fam .par small { color: #6b7d90; }
    .kid { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; padding: 5px 0 5px 12px; border-left: 2px solid var(--ex-border); font-size: 13px; }
    .kid a { font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .kid a:hover { text-decoration: underline; }
    .kid .uid { color: #93a2b2; font-size: 11.5px; }
    .kid .cls { color: #41566c; }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 12px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
    .print-head { display: none; }
    @media print {
        .print-head { display: block; }
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .pick, .pager, .noprint { display: none !important; }
        .fam { page-break-inside: avoid; }
        .ex-table { font-size: 10px; } .ex-table th, .ex-table td { padding: 2px 4px; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Brothers & Sisters', 'The families of the school, and the ones still to be joined up', 'fa-people-roof',
        [$link(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php exam_tabs('sibling_report.php', STATS_PAGES); ?>

    <form method="get" class="card pick noprint">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <div><label>Class</label><select name="class_id"><option value="0">All classes</option><?php echo exam_options(array_map(fn($c) => $c['name'], $classes), $class_id); ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Student, father, mother or mobile" style="min-width:230px"></div>
        <div><label>Per page</label><select name="per"><?php echo exam_options([25 => 25, 50 => 50, 100 => 100, 200 => 200], $per); ?></select></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
        <div><a href="sibling_report.php" class="btn btn-secondary">Reset</a></div>
    </form>

    <div class="print-head"><?php exam_school_header('BROTHERS & SISTERS', 'Session ' . $session_name . ($class_id ? ' · Class ' . $classes[$class_id]['name'] : '')); ?></div>

    <div class="sb">
        <div><b><?php echo number_format($total); ?></b><span>Families</span></div>
        <div><b><?php echo number_format($children); ?></b><span>Students in them</span></div>
        <div><b><?php echo number_format(count($not_linked)); ?></b><span>Still to be joined</span></div>
        <div><b><?php echo number_format(count($too_many)); ?></b><span>Guardians to check</span></div>
    </div>

    <?php if ($too_many): ?>
    <div class="card" style="border-color:#f0c987;background:#fffaf0">
        <h2><i class="fas fa-triangle-exclamation" style="color:#b26a00"></i> Check this guardian <small>more than <?php echo SIB_MANY; ?> students on one guardian record</small></h2>
        <p class="note" style="margin-top:0">One guardian record cannot belong to this many children. It usually happens when a whole block of students is entered or imported at once. Nothing here is changed by this page — open each student and give them their own guardian.</p>
        <?php foreach ($too_many as $r): ?>
        <div class="fam" style="background:#fff">
            <div class="par"><b><?php echo h($r['father_name'] ?: '(no father name)'); ?></b> <small>mother <?php echo h($r['mother_name'] ?: '—'); ?></small>
                <small>mobile <?php echo h($r['father_mobile'] ?: '—'); ?></small>
                <span class="chip bad"><?php echo (int)$r['n']; ?> students</span></div>
            <div style="font-size:12.5px;color:#41566c;line-height:1.7">
                <?php foreach ($r['kids'] as $k): ?>
                    <a href="<?php echo h(student_page_url('edit_student.php', $k['id'])); ?>" style="color:var(--ex-dark);text-decoration:none"><b><?php echo h($k['name']); ?></b></a>
                    <span class="uid" style="color:#93a2b2"><?php echo h($k['class'] ? $k['class'] : '—'); ?></span> &nbsp;
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <h2><i class="fas fa-link-slash"></i> Still to be joined up <small><?php echo count($not_linked); ?> pair(s)</small></h2>
        <?php if (!$not_linked): ?>
            <div class="ex-empty"><i class="fas fa-check-circle"></i>Every pair of brothers and sisters the records can find is already on one guardian record.</div>
        <?php else: ?>
        <p class="note" style="margin-top:0">These two look like brother and sister — three or more of the father's name, mother's name, mobile, voter ID and Aadhaar are the same — but they are on two different guardian records. Open one of them and point it at the other's guardian.</p>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>One student</th><th>The other</th><th class="num">Matches</th><th>Father / Mother</th></tr></thead>
            <tbody>
            <?php foreach ($not_linked as $p): ?>
                <tr>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $p['a']['id'])); ?>"><b><?php echo h($p['a']['student_name']); ?></b></a>
                        <div class="uid" style="color:#93a2b2;font-size:11.5px"><?php echo h($p['a']['id'] . ' · ' . trim(($p['a']['class_name'] ?? '') . ' ' . ($p['a']['section_name'] ?? ''))); ?></div></td>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $p['b']['id'])); ?>"><b><?php echo h($p['b']['student_name']); ?></b></a>
                        <div class="uid" style="color:#93a2b2;font-size:11.5px"><?php echo h($p['b']['id'] . ' · ' . trim(($p['b']['class_name'] ?? '') . ' ' . ($p['b']['section_name'] ?? ''))); ?></div></td>
                    <td class="num"><span class="chip warn"><?php echo (int)$p['score']; ?> of 5</span></td>
                    <td><small><?php echo h(($p['a']['father_name'] ?: '—') . ' / ' . ($p['a']['mother_name'] ?: '—')); ?></small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>

    <div class="card">
        <h2><i class="fas fa-people-roof"></i> Families <small><?php echo number_format($total); ?> with a child in <?php echo h($session_name); ?><?php echo $class_id ? ' · Class ' . h($classes[$class_id]['name']) : ''; ?></small></h2>
        <?php if (!$shown): ?>
            <div class="ex-empty"><i class="fas fa-user-group"></i>No family matches what you asked for.</div>
        <?php else: ?>
            <?php foreach ($shown as $fam): ?>
            <div class="fam">
                <div class="par">
                    <b><?php echo h($fam['father_name'] ?: ($fam['guardian_name'] ?: '(no name)')); ?></b>
                    <small>mother <?php echo h($fam['mother_name'] ?: '—'); ?></small>
                    <small><i class="fas fa-phone"></i> <?php echo h($fam['mobile'] ?: '—'); ?></small>
                    <span class="chip off"><?php echo count($fam['children']); ?> children</span>
                </div>
                <?php foreach ($fam['children'] as $ch): [$lbl, $chip] = $chips[$ch['student_status']] ?? [$ch['student_status'], 'off']; ?>
                <div class="kid">
                    <a href="<?php echo h(student_page_url('view_student.php', $ch['id'])); ?>"><?php echo h($ch['student_name']); ?></a>
                    <span class="uid"><?php echo h($ch['id']); ?></span>
                    <span class="cls"><?php echo $ch['class_name'] ? h('Class ' . $ch['class_name'] . ($ch['section_name'] ? '-' . $ch['section_name'] : '') . ($ch['roll_no'] ? ' · Roll ' . $ch['roll_no'] : '')) : '<span class="uid">not in this session</span>'; ?></span>
                    <?php if ($ch['student_status'] !== 'Active'): ?><span class="chip <?php echo h($chip); ?>"><?php echo h($lbl); ?></span><?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
            <?php if ($pages > 1): ?>
            <div class="pager noprint">
                <span>Page <?php echo $page; ?> of <?php echo $pages; ?></span>
                <?php if ($page > 1): ?><a href="<?php echo h($link(['page' => $page - 1])); ?>"><i class="fas fa-angle-left"></i> Back</a><?php endif; ?>
                <?php for ($p = max(1, $page - 3); $p <= min($pages, $page + 3); $p++): ?>
                    <a href="<?php echo h($link(['page' => $p])); ?>" class="<?php echo $p === $page ? 'on' : ''; ?>"><?php echo $p; ?></a>
                <?php endfor; ?>
                <?php if ($page < $pages): ?><a href="<?php echo h($link(['page' => $page + 1])); ?>">Next <i class="fas fa-angle-right"></i></a><?php endif; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
        <p class="note">A family is one guardian record holding more than one student, which is what the database already says — the five guardian fields are only used for the pairs above, where two records should be one.</p>
    </div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Staff list. Filters: type, designation, status (Active default), subject, search
 * (name / employee id / govt ids / short code / mobile / email). 50 per page. Row actions:
 * view, edit, set password, change status (delete_staff.php).
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$type   = in_array($_GET['type'] ?? '', ['Teaching', 'Non-teaching'], true) ? $_GET['type'] : '';
$desig  = isset(staff_designations()[$_GET['designation'] ?? '']) ? $_GET['designation'] : '';
$status = in_array($_GET['status'] ?? '', array_merge(staff_service_statuses(), ['all']), true) ? $_GET['status'] : 'Active';
$subject = in_array($_GET['subject'] ?? '', staff_subjects(), true) ? $_GET['subject'] : '';
$search = trim((string)($_GET['search'] ?? ''));
$sort   = in_array($_GET['sort'] ?? '', ['name', 'id', 'joined', 'designation'], true) ? $_GET['sort'] : 'name';
$page   = max(1, (int)($_GET['page'] ?? 1)); $per = 50;

$where = []; $params = []; $types = '';
if ($status !== 'all') { $where[] = 'service_status = ?'; $params[] = $status; $types .= 's'; }
if ($type !== '')  { $where[] = 'staff_type = ?';  $params[] = $type;  $types .= 's'; }
if ($desig !== '') { $where[] = 'designation = ?'; $params[] = $desig; $types .= 's'; }
if ($subject !== '') { $where[] = 'subject_name = ?'; $params[] = $subject; $types .= 's'; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(staff_name LIKE ? OR employee_id LIKE ? OR state_govt_id LIKE ? OR national_code LIKE ? OR short_code LIKE ? OR mobile LIKE ? OR email LIKE ?)';
    array_push($params, $like, $like, $like, $like, $like, $like, $like); $types .= 'sssssss';
}
$from = 'FROM staff' . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
$order = ['name' => 'staff_name', 'id' => 'employee_id', 'joined' => 'date_of_joining, staff_name', 'designation' => "FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher', 'Librarian', 'Clerk', 'Accountant', 'Group D'), staff_name"][$sort];
$total = (int)(db_get_row("SELECT COUNT(*) AS c $from", $types, ...$params)['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per)); if ($page > $pages) $page = $pages; $offset = ($page - 1) * $per;
$rows = $total ? db_get_all("SELECT id, employee_id, state_govt_id, staff_name, short_code, designation, staff_type, can_login, subject_name, academic_section, gender, mobile, email, photo, service_status, status_date, date_of_joining, login_password IS NOT NULL AND login_password <> '' AS has_pw $from ORDER BY $order LIMIT $per OFFSET $offset", $types, ...$params) : [];
$counts = db_get_row("SELECT COUNT(*) AS total, SUM(service_status = 'Active') AS active, SUM(service_status = 'Active' AND staff_type = 'Teaching') AS teaching, SUM(service_status = 'Active' AND staff_type = 'Non-teaching') AS nonteaching,
    SUM(service_status = 'Active' AND can_login = 1 AND (login_password IS NULL OR login_password = '')) AS no_pw, SUM(service_status <> 'Active') AS left_school FROM staff") ?: [];
$qs = array_filter(['type' => $type, 'designation' => $desig, 'status' => $status !== 'Active' ? $status : null, 'subject' => $subject, 'search' => $search !== '' ? $search : null, 'sort' => $sort !== 'name' ? $sort : null]);
function page_url(int $p): string { global $qs; return 'staff.php?' . http_build_query($qs + ($p > 1 ? ['page' => $p] : [])); }
$filtered = $type !== '' || $desig !== '' || $status !== 'Active' || $subject !== '' || $search !== '';
$badge = ['Active' => 'ok', 'Transferred' => 'info', 'Retired' => 'muted', 'Deceased' => 'bad'];
$win = []; foreach (array_unique(array_filter(array_merge([1, 2], range($page - 2, $page + 2), [$pages - 1, $pages]), fn($p) => $p >= 1 && $p <= $pages)) as $p) $win[] = $p; sort($win);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .st-banner { background: linear-gradient(135deg, #1f4e79 0%, #2b78b6 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(31,78,121,.25); }
    .st-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .st-banner h1 { margin: 0; font-size: 21px; } .st-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e6f5; } .st-banner p b { color: #fff; }
    .st-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .st-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .st-banner .links a.add { background: #21a98a; border-color: #21a98a; }
    .st-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .st-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
    .st-stat i { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex: 0 0 38px; }
    .st-stat b { font-size: 22px; display: block; line-height: 1.1; color: #10253a; } .st-stat small { color: #6b7d90; font-size: 12px; }
    .st-stat.t1 i { background: #eaf2fb; color: #1f4e79; } .st-stat.t2 i { background: #ecf9f0; color: #1b7a3d; } .st-stat.t3 i { background: #f3f0fb; color: #5b3fa0; } .st-stat.t4 i { background: #fff6e5; color: #9a5a00; }
    .st-stat a { color: inherit; text-decoration: none; }
    .lc-filter input[type=text] { min-width: 230px; }
    .st-bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 8px; font-size: 13px; color: #3b5168; }
    .st-bar .spacer { flex: 1; } .st-bar select { height: 32px; border: 1px solid #c9d6e2; border-radius: 7px; padding: 0 8px; font-size: 13px; background: #fff; }
    .lc-table .emp { display: inline-block; background: #003366; color: #fff; font-size: 10.5px; font-weight: 700; padding: 1px 8px; border-radius: 8px; letter-spacing: .4px; }
    .lc-table .code { display: inline-block; background: #eaf2fb; color: #1f4e79; font-weight: 700; padding: 2px 8px; border-radius: 7px; font-size: 12px; }
    .lc-table small { color: #6b7d90; display: block; }
    .lc-table .pw { font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 999px; } .pw.ok { background: #ecf9f0; color: #1b7a3d; } .pw.no { background: #fff6e5; color: #9a5a00; } .pw.off { background: #f3f6f9; color: #7a8a9a; }
    .lc-actions .btn { padding: 4px 7px; margin: 0 3px 0 0; }
    .pg { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; justify-content: center; margin: 12px 0 4px; }
    .pg a, .pg span.cur, .pg span.gap { min-width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; background: #fff; color: #1f4e79; text-decoration: none; font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg span.cur { background: #1f4e79; color: #fff; border-color: #1f4e79; } .pg span.gap { border: 0; color: #8a9aab; } .pg a.dis { pointer-events: none; opacity: .4; }
    .dx-dlg .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 12px; }
    .dx-dlg .stu { display: flex; align-items: center; gap: 12px; background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 10px 12px; }
    .dx-dlg .stu img, .dx-dlg .stu .noimg { width: 46px; height: 46px; border-radius: 10px; object-fit: cover; background: #edf2f7; border: 1px solid #d5dee7; display: inline-flex; align-items: center; justify-content: center; color: #8a9aab; }
    .dx-dlg .stu small { color: #6b7d90; display: block; }
    .dx-dlg h3.warn { background: linear-gradient(135deg, #9a5a00, #d08a2a) !important; }
    @media (max-width: 900px) { .st-stats { grid-template-columns: 1fr 1fr; } .dx-dlg .row2 { grid-template-columns: 1fr; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="st-banner">
        <div class="ico"><i class="fas fa-chalkboard-teacher"></i></div>
        <div><h1>Staff</h1><p><b><?php echo (int)($counts['active'] ?? 0); ?></b> active · <?php echo (int)($counts['teaching'] ?? 0); ?> teaching · <?php echo (int)($counts['nonteaching'] ?? 0); ?> non-teaching · <?php echo (int)($counts['left_school'] ?? 0); ?> transferred / retired</p></div>
        <div class="links">
            <a href="add_staff.php" class="add"><i class="fas fa-user-plus"></i> Add Staff</a>
            <a href="export_staff.php?<?php echo h(http_build_query($qs)); ?>"><i class="fas fa-file-excel"></i> Export</a>
            <a href="teacher_passwords.php"><i class="fas fa-key"></i> Passwords</a>
            <a href="teacher_routine.php"><i class="fas fa-calendar-alt"></i> Teacher routine</a>
            <a href="teacher_attendance.php"><i class="fas fa-user-check"></i> Attendance</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <div class="st-stats">
        <div class="st-stat t1"><i class="fas fa-users"></i><div><b><?php echo (int)($counts['active'] ?? 0); ?></b><small>Active staff (of <?php echo (int)($counts['total'] ?? 0); ?> records)</small></div></div>
        <div class="st-stat t2"><i class="fas fa-chalkboard-teacher"></i><div><b><?php echo (int)($counts['teaching'] ?? 0); ?></b><small>Teaching (can be put on the routine)</small></div></div>
        <div class="st-stat t3"><i class="fas fa-user-tie"></i><div><b><?php echo (int)($counts['nonteaching'] ?? 0); ?></b><small>Non-teaching</small></div></div>
        <div class="st-stat t4"><i class="fas fa-key"></i><div><b><?php echo (int)($counts['no_pw'] ?? 0); ?></b><small><a href="staff.php?search=&status=Active#nopw">Portal login allowed but no password yet</a></small></div></div>
    </div>

    <form method="get" class="lc-filter">
        <div><label>Status</label><select name="status"><?php foreach (['Active' => 'Active', 'all' => 'All', 'Transferred' => 'Transferred', 'Retired' => 'Retired', 'Deceased' => 'Deceased'] as $val => $l): ?><option value="<?php echo $val; ?>" <?php echo $status === $val ? 'selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
        <div><label>Type</label><select name="type"><option value="">All</option><option value="Teaching" <?php echo $type === 'Teaching' ? 'selected' : ''; ?>>Teaching</option><option value="Non-teaching" <?php echo $type === 'Non-teaching' ? 'selected' : ''; ?>>Non-teaching</option></select></div>
        <div><label>Designation</label><select name="designation"><option value="">All</option><?php foreach (array_keys(staff_designations()) as $d): ?><option value="<?php echo h($d); ?>" <?php echo $desig === $d ? 'selected' : ''; ?>><?php echo h($d); ?></option><?php endforeach; ?></select></div>
        <div><label>Subject</label><select name="subject"><option value="">All</option><?php foreach (staff_subjects() as $sub): ?><option value="<?php echo h($sub); ?>" <?php echo $subject === $sub ? 'selected' : ''; ?>><?php echo h($sub); ?></option><?php endforeach; ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, Employee ID, Govt ID, code, mobile, email"></div>
        <input type="hidden" name="sort" value="<?php echo h($sort); ?>">
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <?php if ($filtered): ?><a href="staff.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <div class="st-bar">
        <span><b><?php echo number_format($total); ?></b> staff<?php echo $total ? ' · showing ' . number_format($offset + 1) . '–' . number_format(min($offset + $per, $total)) : ''; ?></span>
        <span class="spacer"></span>
        <label>Sort <select onchange="var u = new URL(location.href); u.searchParams.set('sort', this.value); u.searchParams.delete('page'); location.href = u;"><option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Name</option><option value="designation" <?php echo $sort === 'designation' ? 'selected' : ''; ?>>Designation (seniority of post)</option><option value="joined" <?php echo $sort === 'joined' ? 'selected' : ''; ?>>Date of joining</option><option value="id" <?php echo $sort === 'id' ? 'selected' : ''; ?>>Employee ID</option></select></label>
    </div>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-chalkboard-teacher"></i>No staff match<?php echo $filtered ? ' these filters' : ''; ?>.<?php if (!$filtered): ?><br><a href="add_staff.php" class="btn btn-success" style="margin-top:12px"><i class="fas fa-user-plus"></i> Add the first staff member</a><?php endif; ?></div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>#</th><th>Staff</th><th>Designation</th><th>Subject / section</th><th>Contact</th><th>Portal</th><?php if ($status !== 'Active'): ?><th>Status</th><?php endif; ?><th>Actions</th></tr></thead>
        <tbody>
        <?php $sl = $offset; foreach ($rows as $r): $sl++; ?>
        <tr>
            <td><?php echo $sl; ?></td>
            <td><div class="lc-stu"><?php echo $r['photo'] ? '<img src="' . h(staff_photo_url($r['photo'])) . '" alt="">' : '<span class="noimg">' . h($r['short_code']) . '</span>'; ?><div><a href="view_staff.php?id=<?php echo (int)$r['id']; ?>"><?php echo h($r['staff_name']); ?></a><br><span class="emp"><?php echo h($r['employee_id']); ?></span><?php if ($r['state_govt_id']): ?> <small style="display:inline">Govt <?php echo h($r['state_govt_id']); ?></small><?php endif; ?></div></div></td>
            <td><?php echo h($r['designation']); ?><small><?php echo h($r['staff_type']); ?><?php echo $r['date_of_joining'] ? ' · since ' . date('Y', strtotime($r['date_of_joining'])) : ''; ?></small></td>
            <td><?php echo $r['subject_name'] ? '<span class="code">' . h($r['subject_name']) . '</span>' : '—'; ?><?php if ($r['academic_section']): ?><small><?php echo h($r['academic_section']); ?></small><?php endif; ?></td>
            <td><?php echo h($r['mobile']); ?><?php if ($r['email']): ?><small><?php echo h($r['email']); ?></small><?php endif; ?></td>
            <td><?php if (!$r['can_login']): ?><span class="pw off">no login</span><?php elseif (!$r['state_govt_id']): ?><span class="pw no">no Govt ID</span><?php elseif ($r['has_pw']): ?><span class="pw ok">ready</span><small><?php echo h($r['state_govt_id']); ?></small><?php else: ?><span class="pw no">no password</span><?php endif; ?></td>
            <?php if ($status !== 'Active'): ?><td><span class="lc-tag <?php echo $badge[$r['service_status']] ?? 'muted'; ?>"><?php echo h($r['service_status']); ?></span><?php if ($r['status_date']): ?><small><?php echo date('d-m-Y', strtotime($r['status_date'])); ?></small><?php endif; ?></td><?php endif; ?>
            <td class="lc-actions">
                <a href="view_staff.php?id=<?php echo (int)$r['id']; ?>" class="btn btn-info btn-sm" title="View"><i class="fas fa-eye"></i></a>
                <a href="edit_staff.php?id=<?php echo (int)$r['id']; ?>" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                <?php if ($r['can_login'] && $r['service_status'] === 'Active'): ?><a href="teacher_passwords.php?search=<?php echo rawurlencode($r['employee_id']); ?>" class="btn btn-secondary btn-sm" title="Portal password"><i class="fas fa-key"></i></a><?php endif; ?>
                <?php if ($r['service_status'] === 'Active'): ?>
                <button type="button" class="btn btn-danger btn-sm" title="Transferred / retired / left" onclick="stStatus(<?php echo h(json_encode(['id' => (int)$r['id'], 'name' => $r['staff_name'], 'emp' => $r['employee_id'], 'desig' => $r['designation'], 'photo' => $r['photo'] ? staff_photo_url($r['photo']) : ''])); ?>)"><i class="fas fa-user-slash"></i></button>
                <?php else: ?>
                <form method="post" action="delete_staff.php" onsubmit="return confirm('Mark <?php echo h(addslashes($r['staff_name'])); ?> as Active again?')"><?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>"><input type="hidden" name="status" value="Active"><button type="submit" class="btn btn-success btn-sm" title="Back to Active"><i class="fas fa-undo"></i></button></form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="pg">
        <a href="<?php echo h(page_url($page - 1)); ?>" class="<?php echo $page <= 1 ? 'dis' : ''; ?>"><i class="fas fa-chevron-left"></i></a>
        <?php $prev = 0; foreach ($win as $p): if ($p - $prev > 1): ?><span class="gap">…</span><?php endif; $prev = $p; ?><?php if ($p === $page): ?><span class="cur"><?php echo $p; ?></span><?php else: ?><a href="<?php echo h(page_url($p)); ?>"><?php echo $p; ?></a><?php endif; endforeach; ?>
        <a href="<?php echo h(page_url($page + 1)); ?>" class="<?php echo $page >= $pages ? 'dis' : ''; ?>"><i class="fas fa-chevron-right"></i></a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<!-- status change: transferred / retired / deceased -->
<div class="lc-modal" id="stModal">
    <form class="lc-dialog dx-dlg" method="post" action="delete_staff.php">
        <?php echo csrf_field(); ?><input type="hidden" name="id" id="stId">
        <h3 class="warn"><i class="fas fa-user-slash"></i> Staff member leaving</h3>
        <div class="body">
            <div class="stu"><span id="stPhoto"></span><div><b id="stName"></b> <span class="lc-uid" id="stEmp"></span><small id="stDesig"></small></div></div>
            <div class="row2">
                <div><label>New status</label><select name="status" required><option value="Transferred">Transferred</option><option value="Retired">Retired</option><option value="Deceased">Deceased</option></select></div>
                <div><label>Date</label><input type="date" name="status_date" required value="<?php echo date('Y-m-d'); ?>"></div>
            </div>
            <div class="row2" style="grid-template-columns:1fr"><div><label>Note (optional)</label><input type="text" name="note" maxlength="200" placeholder="e.g. transferred to … school, memo no."></div></div>
            <div class="note">The record stays (service history, routine and attendance are kept). Portal login is switched off. They can be marked Active again from the list (status filter: All).</div>
        </div>
        <div class="foot"><button type="button" class="btn btn-secondary" onclick="document.getElementById('stModal').classList.remove('open')">Cancel</button><button type="submit" class="btn btn-danger"><i class="fas fa-check"></i> Save status</button></div>
    </form>
</div>
<script>
function stStatus(s) {
    document.getElementById('stId').value = s.id; document.getElementById('stName').textContent = s.name; document.getElementById('stEmp').textContent = s.emp; document.getElementById('stDesig').textContent = s.desig;
    document.getElementById('stPhoto').innerHTML = s.photo ? '<img src="' + s.photo.replace(/"/g, '&quot;') + '" alt="">' : '<span class="noimg"><i class="fas fa-user"></i></span>';
    document.getElementById('stModal').classList.add('open');
}
document.getElementById('stModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

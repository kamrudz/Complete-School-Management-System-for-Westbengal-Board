<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Take Attendance — class → section → date, then one row per student (roll order) with big
 * P / A / L buttons. Everyone starts Present; live counts; a note only for Absent / Leave.
 * Sundays, holidays and future dates are refused (the same rule as the save endpoint).
 * Reopening a day that is already taken shows the saved marks and who took them.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = (int)($_GET['session_id'] ?? 0) ?: $active_session;
$class_id   = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$date       = trim((string)($_GET['attendance_date'] ?? date('Y-m-d')));
if (!DateTime::createFromFormat('Y-m-d', $date)) $date = date('Y-m-d');
$block      = attendance_day_block($date);

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id) : [];
$class_name = ''; foreach ($classes as $c) if ((int)$c['id'] === $class_id) $class_name = $c['class_name'];
$section_name = ''; foreach ($sections as $x) if ((int)$x['id'] === $section_id) $section_name = $x['section_name'];
$ready = $session_id && $class_id && $section_id && $section_name !== '';
$students = $ready ? attendance_section_students($session_id, $class_id, $section_id) : [];
$existing = $ready ? attendance_existing($session_id, $class_id, $section_id, $date) : [];
$taken_by = attendance_taken_by($existing);

// today's overview across the session: which sections are taken
$today = date('Y-m-d');
$overview = $session_id ? db_get_all("SELECT c.class_name, s.section_name, s.id AS section_id, c.id AS class_id,
        (SELECT COUNT(*) FROM student_academic_history h JOIN students st ON st.id = h.student_id AND st.student_status = 'Active' WHERE h.session_id = s.session_id AND h.class_id = s.class_id AND h.section_id = s.id AND h.academic_status = 'Current') AS strength,
        (SELECT COUNT(*) FROM student_attendance a WHERE a.session_id = s.session_id AND a.section_id = s.id AND a.attendance_date = ?) AS taken,
        (SELECT COUNT(*) FROM student_attendance a WHERE a.session_id = s.session_id AND a.section_id = s.id AND a.attendance_date = ? AND a.status = 'Present') AS present
    FROM sections s JOIN classes c ON c.id = s.class_id WHERE s.session_id = ? ORDER BY c.sort_order, s.section_name", 'ssi', $date, $date, $session_id) : [];
$ov_total = count(array_filter($overview, fn($o) => (int)$o['strength'] > 0)); $ov_done = count(array_filter($overview, fn($o) => (int)$o['taken'] > 0));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Take Attendance</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .at-banner { background: linear-gradient(135deg, #0f6e56 0%, #1fa37f 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(15,110,86,.25); }
    .at-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .at-banner h1 { margin: 0; font-size: 21px; } .at-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d5f2e8; } .at-banner p b { color: #fff; }
    .at-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .at-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .at-banner .links a.solid { background: #fff; color: #0f6e56; }
    .at-block { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 12px; padding: 12px 16px; margin-bottom: 14px; font-size: 14px; display: flex; gap: 10px; align-items: center; }
    .at-block i { font-size: 20px; }
    .at-head { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 4px 0 10px; }
    .at-head h3 { margin: 0; font-size: 16px; color: #0f6e56; }
    .at-head .taken { font-size: 12.5px; color: #6b7d90; background: #f3f6f9; padding: 4px 10px; border-radius: 999px; }
    .at-counts { display: flex; gap: 8px; margin-left: auto; flex-wrap: wrap; }
    .at-counts span { padding: 5px 12px; border-radius: 999px; font-weight: 700; font-size: 13px; }
    .at-counts .p { background: #d7f3e1; color: #1b7a3d; } .at-counts .a { background: #fde2e4; color: #9d2630; } .at-counts .l { background: #fff6e5; color: #9a5a00; }
    .at-tools { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; }
    .at-tools .btn { padding: 6px 12px; font-size: 13px; }
    .at-row { display: grid; grid-template-columns: 40px 44px 1fr auto; gap: 10px; align-items: center; padding: 6px 10px; border-bottom: 1px solid #eef2f6; background: #fff; }
    .at-row:nth-child(even) { background: #fbfdff; }
    .at-row.abs { background: #fff3f4; } .at-row.lv { background: #fff9ec; }
    .at-row .roll { text-align: center; font-weight: 800; color: #1f4e79; }
    .at-row img, .at-row .noimg { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1px solid #d5dee7; background: #edf2f7; display: flex; align-items: center; justify-content: center; font-size: 11px; color: #8a9aab; }
    .at-row .who b { display: block; font-size: 14px; color: #10253a; } .at-row .who small { color: #6b7d90; }
    .at-row .who input { margin-top: 4px; width: 100%; max-width: 320px; height: 30px; padding: 4px 8px; border: 1px solid #f0c987; border-radius: 6px; font-size: 12.5px; }
    .seg { display: inline-flex; border: 1px solid #c9d6e2; border-radius: 10px; overflow: hidden; }
    .seg label { padding: 0; margin: 0; }
    .seg input { position: absolute; opacity: 0; pointer-events: none; }
    .seg span { display: inline-flex; align-items: center; justify-content: center; min-width: 52px; height: 40px; font-weight: 800; font-size: 15px; cursor: pointer; color: #6b7d90; background: #fff; border-right: 1px solid #c9d6e2; user-select: none; }
    .seg label:last-child span { border-right: 0; }
    .seg input:checked + span.p { background: #1b7a3d; color: #fff; } .seg input:checked + span.a { background: #b0454f; color: #fff; } .seg input:checked + span.l { background: #d08a2a; color: #fff; }
    .at-list { border: 1px solid #dfe7ef; border-radius: 12px; overflow: hidden; }
    .at-save { position: sticky; bottom: 0; background: rgba(255,255,255,.96); border-top: 1px solid #e1eaf2; padding: 12px 0; margin-top: 12px; display: flex; gap: 10px; align-items: center; backdrop-filter: blur(4px); }
    .at-save .spacer { flex: 1; }
    .ov { margin-top: 18px; }
    .ov h3 { font-size: 15px; color: #1f4e79; margin: 0 0 8px; }
    .ov-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 6px; }
    .ov-grid a { display: flex; justify-content: space-between; align-items: center; border: 1px solid #dfe7ef; border-radius: 9px; padding: 7px 10px; text-decoration: none; color: #10253a; font-size: 13px; background: #fff; }
    .ov-grid a.done { border-color: #9fd3b2; background: #f2fbf5; } .ov-grid a.pending { border-color: #f0c987; background: #fffaf0; }
    .ov-grid a small { color: #6b7d90; } .ov-grid a.done small { color: #1b7a3d; font-weight: 700; }
    @media (max-width: 700px) { .at-row { grid-template-columns: 32px 1fr auto; } .at-row img, .at-row .noimg { display: none; } .seg span { min-width: 44px; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="at-banner">
        <div class="ico"><i class="fas fa-user-check"></i></div>
        <div><h1>Take Attendance</h1><p><?php echo date('l, d F Y', strtotime($date)); ?> · <b><?php echo $ov_done; ?></b> of <?php echo $ov_total; ?> sections taken<?php echo $date === $today ? ' today' : ''; ?></p></div>
        <div class="links">
            <a href="student_attendance_register.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo $class_id; ?>&section_id=<?php echo $section_id; ?>"><i class="fas fa-table"></i> Register</a>
            <a href="student_attendance_report.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-chart-pie"></i> Reports</a>
            <a href="holidays.php" class="solid"><i class="fas fa-calendar-times"></i> Holidays</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <form method="get" class="lc-filter" id="pick">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="0">Select class</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="0">Select section</option><?php foreach ($sections as $x): ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Date</label><input type="date" name="attendance_date" value="<?php echo h($date); ?>" max="<?php echo $today; ?>"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Open</button>
    </form>

    <?php if ($block): ?>
    <div class="at-block"><i class="fas fa-calendar-times"></i><div><b>No attendance on <?php echo date('d-m-Y', strtotime($date)); ?></b> — <?php echo h($block); ?><?php if ($block[0] === 'H'): ?> Holidays come from the <a href="holidays.php">holiday list</a>.<?php endif; ?></div></div>
    <?php elseif (!$ready): ?>
    <div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class and section to take attendance.</div>
    <?php elseif (!$students): ?>
    <div class="lc-empty"><i class="fas fa-users"></i>No active students in <?php echo h($class_name . '-' . $section_name); ?>.</div>
    <?php else: ?>
    <form method="post" action="save_student_attendance.php" id="attForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $section_id; ?>"><input type="hidden" name="attendance_date" value="<?php echo h($date); ?>">
        <div class="at-head">
            <h3><i class="fas fa-users"></i> <?php echo h($class_name . '-' . $section_name); ?> · <?php echo count($students); ?> students · <?php echo date('d-m-Y', strtotime($date)); ?></h3>
            <?php if ($taken_by): ?><span class="taken"><i class="fas fa-check-circle" style="color:#1b7a3d"></i> <?php echo h($taken_by); ?> — editing</span><?php else: ?><span class="taken">not taken yet</span><?php endif; ?>
            <div class="at-counts"><span class="p">Present <b id="nP">0</b></span><span class="a">Absent <b id="nA">0</b></span><span class="l">Leave <b id="nL">0</b></span></div>
        </div>
        <div class="at-tools">
            <button type="button" class="btn btn-success" onclick="setAll('Present')"><i class="fas fa-check-double"></i> All present</button>
            <button type="button" class="btn btn-secondary" onclick="setAll('Absent')"><i class="fas fa-times"></i> All absent</button>
            <span style="font-size:12.5px;color:#6b7d90;align-self:center">Tap P / A / L on each row. Keyboard: ↓ ↑ move, P / A / L set.</span>
        </div>
        <div class="at-list" id="list">
            <?php foreach ($students as $i => $s): $cur = $existing[$s['id']]['status'] ?? 'Present'; $rem = $existing[$s['id']]['remarks'] ?? ''; ?>
            <div class="at-row <?php echo $cur === 'Absent' ? 'abs' : ($cur === 'Leave' ? 'lv' : ''); ?>" data-i="<?php echo $i; ?>">
                <div class="roll"><?php echo h($s['roll_no']); ?></div>
                <?php echo $s['photo'] ? '<img src="../uploads/students/' . rawurlencode($s['photo']) . '" alt="">' : '<span class="noimg">N/A</span>'; ?>
                <div class="who"><b><?php echo h($s['student_name']); ?></b><small><?php echo h($s['father_name'] ?? ''); ?><?php echo ($s['guardian_contact'] ?: $s['mobile']) ? ' · ' . h($s['guardian_contact'] ?: $s['mobile']) : ''; ?> · <?php echo h($s['id']); ?></small>
                    <input type="text" name="remarks[<?php echo h($s['id']); ?>]" value="<?php echo h($rem); ?>" placeholder="note (optional)" maxlength="200" <?php echo $cur === 'Present' ? 'hidden' : ''; ?>></div>
                <div class="seg">
                    <?php foreach (['Present' => 'p', 'Absent' => 'a', 'Leave' => 'l'] as $st => $k): ?>
                    <label><input type="radio" name="status[<?php echo h($s['id']); ?>]" value="<?php echo $st; ?>" <?php echo $cur === $st ? 'checked' : ''; ?>><span class="<?php echo $k; ?>"><?php echo $st[0]; ?></span></label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="at-save">
            <span style="font-size:13px;color:#6b7d90">Everyone not touched is saved as Present.</span>
            <span class="spacer"></span>
            <a href="student_attendance.php?session_id=<?php echo $session_id; ?>" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> <?php echo $taken_by ? 'Save changes' : 'Save attendance'; ?></button>
        </div>
    </form>
    <?php endif; ?>

    <?php if ($overview && !$block): ?>
    <div class="ov">
        <h3><i class="fas fa-th"></i> <?php echo date('d-m-Y', strtotime($date)); ?> — every section <small style="font-weight:400;color:#6b7d90">(green = taken · amber = pending; click to open)</small></h3>
        <div class="ov-grid">
            <?php foreach ($overview as $o): if ((int)$o['strength'] === 0) continue; $done = (int)$o['taken'] > 0; ?>
            <a href="student_attendance.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo (int)$o['class_id']; ?>&section_id=<?php echo (int)$o['section_id']; ?>&attendance_date=<?php echo h($date); ?>" class="<?php echo $done ? 'done' : 'pending'; ?>"><b><?php echo h($o['class_name'] . '-' . $o['section_name']); ?></b><small><?php echo $done ? (int)$o['present'] . '/' . (int)$o['taken'] : (int)$o['strength'] . ' · pending'; ?></small></a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<script>
var SESSION = <?php echo (int)$session_id; ?>;
document.getElementById('fClass').addEventListener('change', function () {
    var sel = document.getElementById('fSection'); sel.innerHTML = '<option value="0">Select section</option>';
    if (!this.value || this.value === '0') return;
    fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + SESSION + '&no_placeholder=1').then(function (r) { return r.text(); }).then(function (html) { sel.innerHTML += html; });
});
(function () {
    var list = document.getElementById('list'); if (!list) return;
    function count() {
        var p = 0, a = 0, l = 0;
        list.querySelectorAll('.at-row').forEach(function (row) {
            var v = row.querySelector('input[type=radio]:checked'); v = v ? v.value : 'Present';
            row.classList.toggle('abs', v === 'Absent'); row.classList.toggle('lv', v === 'Leave');
            row.querySelector('input[type=text]').hidden = v === 'Present';
            if (v === 'Present') p++; else if (v === 'Absent') a++; else l++;
        });
        document.getElementById('nP').textContent = p; document.getElementById('nA').textContent = a; document.getElementById('nL').textContent = l;
    }
    list.addEventListener('change', count);
    window.setAll = function (v) { list.querySelectorAll('input[type=radio][value="' + v + '"]').forEach(function (r) { r.checked = true; }); count(); };
    // keyboard: arrows move the focused row, P/A/L set it
    var cur = -1, rows = list.querySelectorAll('.at-row');
    function focusRow(i) { if (i < 0 || i >= rows.length) return; cur = i; rows.forEach(function (r) { r.style.outline = ''; }); rows[i].style.outline = '2px solid #1fa37f'; rows[i].scrollIntoView({ block: 'nearest' }); }
    document.addEventListener('keydown', function (e) {
        if (e.target.tagName === 'INPUT' && e.target.type === 'text' || e.target.tagName === 'SELECT') return;
        var k = e.key.toLowerCase();
        if (e.key === 'ArrowDown') { e.preventDefault(); focusRow(cur + 1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); focusRow(cur - 1); }
        else if ((k === 'p' || k === 'a' || k === 'l') && cur >= 0) { e.preventDefault(); rows[cur].querySelector('input[value="' + { p: 'Present', a: 'Absent', l: 'Leave' }[k] + '"]').checked = true; count(); focusRow(cur + 1); }
    });
    rows.forEach(function (r, i) { r.addEventListener('click', function () { focusRow(i); }); });
    count();
})();
</script>
</body>
</html>

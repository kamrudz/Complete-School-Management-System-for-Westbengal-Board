<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Attendance Register — one section, one month: a P / A / L grid, day by day. Sundays and
 * holidays (incl. vacations) are shaded and never counted; each student gets P/A/L totals
 * and a percentage of the working days taken so far. Prints on A4 landscape.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = (int)($_GET['session_id'] ?? 0) ?: $active_session;
$class_id   = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$month = (int)($_GET['month'] ?? date('n')); $year = (int)($_GET['year'] ?? date('Y'));
if ($month < 1 || $month > 12) $month = (int)date('n'); if ($year < 2000 || $year > 2100) $year = (int)date('Y');

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id) : [];
$class_name = ''; foreach ($classes as $c) if ((int)$c['id'] === $class_id) $class_name = $c['class_name'];
$section_name = ''; foreach ($sections as $x) if ((int)$x['id'] === $section_id) $section_name = $x['section_name'];
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$ready = $session_id && $class_id && $section_id && $section_name !== '';

$days = attendance_working_days($year, $month);
$first = sprintf('%04d-%02d-01', $year, $month); $last = sprintf('%04d-%02d-%02d', $year, $month, count($days));
$students = $ready ? attendance_section_students($session_id, $class_id, $section_id) : [];
$marks = []; $taken_days = [];
if ($ready) {
    foreach (db_get_all('SELECT student_id, attendance_date, status FROM student_attendance WHERE session_id = ? AND class_id = ? AND section_id = ? AND attendance_date BETWEEN ? AND ?', 'iiiss', $session_id, $class_id, $section_id, $first, $last) as $r) {
        $marks[$r['student_id']][$r['attendance_date']] = $r['status']; $taken_days[$r['attendance_date']] = true;
    }
}
$working = array_keys(array_filter($days, fn($d) => $d['working'] && !$d['future']));
$taken_n = count(array_intersect($working, array_keys($taken_days)));
$prev = mktime(0, 0, 0, $month - 1, 1, $year); $next = mktime(0, 0, 0, $month + 1, 1, $year);
$qs = ['session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $section_id];
$tot = ['P' => 0, 'A' => 0, 'L' => 0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Register</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rg-banner { background: linear-gradient(135deg, #0f6e56 0%, #1fa37f 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(15,110,86,.25); }
    .rg-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rg-banner h1 { margin: 0; font-size: 21px; } .rg-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d5f2e8; }
    .rg-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .rg-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .rg-banner .links a.solid { background: #fff; color: #0f6e56; }
    .rg-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 12px; }
    .rg-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; } .rg-stat b { display: block; font-size: 20px; color: #10253a; } .rg-stat small { color: #6b7d90; font-size: 12px; }
    .rg-month { display: flex; align-items: center; gap: 8px; }
    .rg-month a { border: 1px solid #c9d6e2; border-radius: 7px; padding: 6px 10px; color: #1f4e79; text-decoration: none; }
    .rg-wrap { overflow: auto; border: 1px solid #dfe7ef; border-radius: 10px; background: #fff; }
    table.rg { border-collapse: collapse; font-size: 12px; min-width: 100%; }
    .rg th, .rg td { border: 1px solid #e6edf3; padding: 3px 4px; text-align: center; white-space: nowrap; }
    .rg th { background: #1f4e79; color: #fff; font-weight: 700; position: sticky; top: 0; font-size: 11px; }
    .rg th.d small { display: block; font-weight: 400; font-size: 9px; opacity: .85; }
    .rg th.sun, .rg th.hol { background: #6b7d90; } .rg td.sun, .rg td.hol { background: #eef2f6; color: #b0bec9; }
    .rg th.hol { background: #9a5a00; }
    .rg td.fut { background: #fafbfc; color: #d5dee7; }
    .rg td.nt { background: #fff9ec; color: #d08a2a; }
    .rg .nm { text-align: left; min-width: 180px; position: sticky; left: 0; background: #fff; z-index: 1; }
    .rg th.nm { z-index: 2; }
    .rg .nm small { color: #6b7d90; display: block; font-size: 10px; }
    .rg td.P { color: #1b7a3d; font-weight: 700; } .rg td.A { background: #fde2e4; color: #9d2630; font-weight: 800; } .rg td.L { background: #fff6e5; color: #9a5a00; font-weight: 800; }
    .rg td.tot { font-weight: 700; background: #f8fafc; } .rg td.pct { font-weight: 800; } .rg td.pct.low { background: #fde2e4; color: #9d2630; }
    .rg tfoot td { background: #eaf2fb; font-weight: 700; }
    .rg-legend { display: flex; gap: 14px; flex-wrap: wrap; font-size: 12px; color: #3b5168; margin: 8px 0; }
    .rg-legend span i { display: inline-block; width: 14px; height: 14px; border-radius: 3px; vertical-align: -2px; margin-right: 4px; border: 1px solid #d5dee7; }
    .print-head { display: none; }
    @media (max-width: 900px) { .rg-stats { grid-template-columns: 1fr 1fr; } }
    @media print {
        @page { size: A4 landscape; margin: 8mm; }
        html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; }
        body > *:not(.page-box) { display: none !important; }
        .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; }
        .page-box, .page-box * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .rg-banner, .lc-filter, .rg-stats, .alert, .rg-month { display: none !important; }
        .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #1f4e79; padding-bottom: 6px; margin-bottom: 8px; }
        .print-head img { width: 44px; height: 44px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #1f4e79; } .print-head small { color: #444; font-size: 10.5px; }
        .rg-wrap { border: 0; overflow: visible; } table.rg { font-size: 9.5px; } .rg th, .rg td { padding: 2px 3px; } .rg .nm { min-width: 120px; position: static; }
        .rg-legend { font-size: 9.5px; }
    }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — Attendance Register</h2><small><?php echo h($class_name . '-' . $section_name); ?> · <?php echo date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?> · working days <?php echo count($working); ?> · printed <?php echo date('d-m-Y'); ?></small></div></div>
    <div class="rg-banner">
        <div class="ico"><i class="fas fa-table"></i></div>
        <div><h1>Attendance Register</h1><p>One section, one month — Sundays and holidays are shaded and not counted.</p></div>
        <div class="links">
            <a href="student_attendance.php?<?php echo h(http_build_query($qs)); ?>"><i class="fas fa-user-check"></i> Take attendance</a>
            <a href="student_attendance_report.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-chart-pie"></i> Reports</a>
            <?php if ($ready && $students): ?><a href="#" onclick="window.print(); return false;" class="solid"><i class="fas fa-print"></i> Print</a><?php endif; ?>
        </div>
    </div>

    <form method="get" class="lc-filter">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="0">Select class</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="0">Select section</option><?php foreach ($sections as $x): ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Month</label><select name="month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m === $month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 1)); ?></option><?php endfor; ?></select></div>
        <div><label>Year</label><select name="year"><?php for ($y = (int)date('Y') - 3; $y <= (int)date('Y') + 1; $y++): ?><option value="<?php echo $y; ?>" <?php echo $y === $year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Show</button>
    </form>

    <?php if (!$ready): ?>
    <div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class and section.</div>
    <?php elseif (!$students): ?>
    <div class="lc-empty"><i class="fas fa-users"></i>No active students in <?php echo h($class_name . '-' . $section_name); ?>.</div>
    <?php else:
        // per-student totals over the working days taken so far
        $rowsum = [];
        foreach ($students as $s) { $p = $a = $l = 0; foreach ($working as $d) { $st = $marks[$s['id']][$d] ?? null; if ($st === 'Present') $p++; elseif ($st === 'Absent') $a++; elseif ($st === 'Leave') $l++; } $rowsum[$s['id']] = [$p, $a, $l]; $tot['P'] += $p; $tot['A'] += $a; $tot['L'] += $l; }
        $avg = $taken_n && count($students) ? round($tot['P'] / ($taken_n * count($students)) * 100, 1) : null;
    ?>
    <div class="rg-stats">
        <div class="rg-stat"><b><?php echo h($class_name . '-' . $section_name); ?></b><small><?php echo count($students); ?> students · <?php echo date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?></small></div>
        <div class="rg-stat"><b><?php echo count($working); ?></b><small>Working days so far (<?php echo count(array_filter($days, fn($d) => $d['working'])); ?> in the month)</small></div>
        <div class="rg-stat"><b><?php echo $taken_n; ?> / <?php echo count($working); ?></b><small>Days attendance was taken<?php echo count($working) - $taken_n > 0 ? ' · ' . (count($working) - $taken_n) . ' missing' : ''; ?></small></div>
        <div class="rg-stat"><b><?php echo $avg === null ? '—' : $avg . '%'; ?></b><small>Section average presence</small></div>
    </div>
    <div class="rg-month">
        <a href="?<?php echo h(http_build_query($qs + ['month' => (int)date('n', $prev), 'year' => (int)date('Y', $prev)])); ?>"><i class="fas fa-chevron-left"></i></a>
        <b><?php echo date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?></b>
        <a href="?<?php echo h(http_build_query($qs + ['month' => (int)date('n', $next), 'year' => (int)date('Y', $next)])); ?>"><i class="fas fa-chevron-right"></i></a>
    </div>
    <div class="rg-legend"><span><i style="background:#d7f3e1"></i> P present</span><span><i style="background:#fde2e4"></i> A absent</span><span><i style="background:#fff6e5"></i> L leave</span><span><i style="background:#fff9ec"></i> · not taken</span><span><i style="background:#eef2f6"></i> Sunday / holiday</span><span>% = present ÷ days taken</span></div>
    <div class="rg-wrap">
    <table class="rg">
        <thead><tr><th class="nm">Roll · Student</th>
            <?php foreach ($days as $d => $info): $cls = $info['holiday'] ? 'hol' : ($info['sunday'] ? 'sun' : ''); ?><th class="d <?php echo $cls; ?>" title="<?php echo h($info['holiday'] ?? ($info['sunday'] ? 'Sunday' : date('l', strtotime($d)))); ?>"><?php echo (int)substr($d, 8, 2); ?><small><?php echo substr(date('D', strtotime($d)), 0, 2); ?></small></th><?php endforeach; ?>
            <th>P</th><th>A</th><th>L</th><th>%</th></tr></thead>
        <tbody>
        <?php foreach ($students as $s): [$p, $a, $l] = $rowsum[$s['id']]; $pct = $taken_n ? round($p / $taken_n * 100) : null; ?>
        <tr><td class="nm"><b><?php echo h($s['roll_no']); ?></b> · <?php echo h($s['student_name']); ?><small><?php echo h($s['id']); ?></small></td>
            <?php foreach ($days as $d => $info): $st = $marks[$s['id']][$d] ?? null;
                if ($info['holiday'] || $info['sunday']) echo '<td class="' . ($info['holiday'] ? 'hol' : 'sun') . '">·</td>';
                elseif ($info['future']) echo '<td class="fut"></td>';
                elseif ($st === null) echo '<td class="nt">·</td>';
                else echo '<td class="' . $st[0] . '">' . $st[0] . '</td>';
            endforeach; ?>
            <td class="tot"><?php echo $p; ?></td><td class="tot"><?php echo $a; ?></td><td class="tot"><?php echo $l; ?></td><td class="pct <?php echo $pct !== null && $pct < 75 ? 'low' : ''; ?>"><?php echo $pct === null ? '—' : $pct . '%'; ?></td></tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr><td class="nm">Present / day</td>
            <?php foreach ($days as $d => $info): if ($info['holiday'] || $info['sunday'] || $info['future'] || empty($taken_days[$d])) { echo '<td></td>'; continue; } $c = 0; foreach ($students as $s) if (($marks[$s['id']][$d] ?? '') === 'Present') $c++; echo '<td>' . $c . '</td>'; endforeach; ?>
            <td><?php echo $tot['P']; ?></td><td><?php echo $tot['A']; ?></td><td><?php echo $tot['L']; ?></td><td><?php echo $avg === null ? '—' : $avg . '%'; ?></td></tr></tfoot>
    </table>
    </div>
    <?php endif; ?>
</div>
<script>
var SESSION = <?php echo (int)$session_id; ?>;
document.getElementById('fClass').addEventListener('change', function () {
    var sel = document.getElementById('fSection'); sel.innerHTML = '<option value="0">Select section</option>';
    if (!this.value || this.value === '0') return;
    fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + SESSION + '&no_placeholder=1').then(function (r) { return r.text(); }).then(function (html) { sel.innerHTML += html; });
});
</script>
</body>
</html>

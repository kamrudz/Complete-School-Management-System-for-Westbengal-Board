<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Attendance Reports.
 *   day      — one date, every section: taken / pending, present / absent / leave, %
 *   monthly  — one month, every section: working days taken, average presence %
 *   students — one class (or section), a date range: per-student P/A/L and %, the below-75% list
 * Each view has an Excel download (?xlsx=1).
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = (int)($_GET['session_id'] ?? 0) ?: $active_session;
$view = in_array($_GET['view'] ?? '', ['day', 'monthly', 'students'], true) ? $_GET['view'] : 'day';
$date = trim((string)($_GET['date'] ?? date('Y-m-d'))); if (!DateTime::createFromFormat('Y-m-d', $date)) $date = date('Y-m-d');
$month = (int)($_GET['month'] ?? date('n')); $year = (int)($_GET['year'] ?? date('Y')); if ($month < 1 || $month > 12) $month = (int)date('n');
$class_id = (int)($_GET['class_id'] ?? 0); $section_id = (int)($_GET['section_id'] ?? 0);
$from = trim((string)($_GET['from'] ?? date('Y-m-01'))); $to = trim((string)($_GET['to'] ?? date('Y-m-d')));
if (!DateTime::createFromFormat('Y-m-d', $from)) $from = date('Y-m-01'); if (!DateTime::createFromFormat('Y-m-d', $to)) $to = date('Y-m-d'); if ($to > date('Y-m-d')) $to = date('Y-m-d'); if ($from > $to) $from = $to;
$threshold = (int)($_GET['threshold'] ?? 75); if ($threshold < 1 || $threshold > 100) $threshold = 75;

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id) : [];
$school = db_get_row('SELECT school_name FROM school_settings WHERE id = 1') ?: [];

/** Working days (not Sunday / holiday, not future) between two dates. */
function att_working_between(string $from, string $to): array {
    $hol = attendance_holiday_map($from, $to); $out = [];
    for ($d = new DateTime($from); $d <= new DateTime($to); $d->modify('+1 day')) { $k = $d->format('Y-m-d'); if ($k > date('Y-m-d')) break; if ((int)$d->format('N') !== 7 && !isset($hol[$k])) $out[] = $k; }
    return $out;
}

$rows = []; $xlsx = []; $title = '';
if ($view === 'day') {
    $block = attendance_day_block($date);
    $rows = db_get_all("SELECT c.class_name, s.section_name, s.id AS section_id, c.id AS class_id,
            (SELECT COUNT(*) FROM student_academic_history h JOIN students st ON st.id = h.student_id AND st.student_status = 'Active' WHERE h.session_id = s.session_id AND h.class_id = s.class_id AND h.section_id = s.id AND h.academic_status = 'Current') AS strength,
            SUM(a.id IS NOT NULL) AS taken, SUM(a.status = 'Present') AS p, SUM(a.status = 'Absent') AS ab, SUM(a.status = 'Leave') AS l
        FROM sections s JOIN classes c ON c.id = s.class_id
        LEFT JOIN student_attendance a ON a.section_id = s.id AND a.session_id = s.session_id AND a.attendance_date = ?
        WHERE s.session_id = ? GROUP BY s.id ORDER BY c.sort_order, s.section_name", 'si', $date, $session_id);
    $rows = array_values(array_filter($rows, fn($r) => (int)$r['strength'] > 0));
    $title = 'Attendance on ' . date('d-m-Y', strtotime($date));
    $xlsx = [['Class', 'Section', 'Students', 'Taken', 'Present', 'Absent', 'Leave', 'Present %']];
    foreach ($rows as $r) $xlsx[] = [$r['class_name'], $r['section_name'], (int)$r['strength'], (int)$r['taken'] ? 'Yes' : 'No', (int)$r['p'], (int)$r['ab'], (int)$r['l'], (int)$r['taken'] ? round($r['p'] / $r['taken'] * 100, 1) : ''];
} elseif ($view === 'monthly') {
    $first = sprintf('%04d-%02d-01', $year, $month); $last = date('Y-m-t', strtotime($first));
    $working = att_working_between($first, $last);
    $rows = db_get_all("SELECT c.class_name, s.section_name, s.id AS section_id, c.id AS class_id,
            (SELECT COUNT(*) FROM student_academic_history h JOIN students st ON st.id = h.student_id AND st.student_status = 'Active' WHERE h.session_id = s.session_id AND h.class_id = s.class_id AND h.section_id = s.id AND h.academic_status = 'Current') AS strength,
            COUNT(DISTINCT a.attendance_date) AS days_taken, SUM(a.status = 'Present') AS p, SUM(a.status = 'Absent') AS ab, SUM(a.status = 'Leave') AS l, COUNT(a.id) AS marks
        FROM sections s JOIN classes c ON c.id = s.class_id
        LEFT JOIN student_attendance a ON a.section_id = s.id AND a.session_id = s.session_id AND a.attendance_date BETWEEN ? AND ?
        WHERE s.session_id = ? GROUP BY s.id ORDER BY c.sort_order, s.section_name", 'ssi', $first, $last, $session_id);
    $rows = array_values(array_filter($rows, fn($r) => (int)$r['strength'] > 0));
    $title = 'Monthly summary — ' . date('F Y', strtotime($first)) . ' (' . count($working) . ' working days so far)';
    $xlsx = [['Class', 'Section', 'Students', 'Working days', 'Days taken', 'Present marks', 'Absent', 'Leave', 'Average presence %']];
    foreach ($rows as $r) $xlsx[] = [$r['class_name'], $r['section_name'], (int)$r['strength'], count($working), (int)$r['days_taken'], (int)$r['p'], (int)$r['ab'], (int)$r['l'], (int)$r['marks'] ? round($r['p'] / $r['marks'] * 100, 1) : ''];
} else {
    $working = att_working_between($from, $to);
    if ($class_id) {
        $where = 'h.session_id = ? AND h.class_id = ?'; $types = 'ii'; $params = [$session_id, $class_id];
        if ($section_id) { $where .= ' AND h.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
        $rows = db_get_all("SELECT st.id, st.student_name, st.photo, g.father_name, g.guardian_contact, st.mobile, h.roll_no, c.class_name, sec.section_name, sec.id AS section_id, c.id AS class_id,
                (SELECT COUNT(*) FROM student_attendance a WHERE a.student_id = st.id AND a.session_id = h.session_id AND a.attendance_date BETWEEN ? AND ? AND a.status = 'Present') AS p,
                (SELECT COUNT(*) FROM student_attendance a WHERE a.student_id = st.id AND a.session_id = h.session_id AND a.attendance_date BETWEEN ? AND ? AND a.status = 'Absent') AS ab,
                (SELECT COUNT(*) FROM student_attendance a WHERE a.student_id = st.id AND a.session_id = h.session_id AND a.attendance_date BETWEEN ? AND ? AND a.status = 'Leave') AS l
            FROM student_academic_history h JOIN students st ON st.id = h.student_id AND st.student_status = 'Active'
            LEFT JOIN guardians g ON g.guardian_id = st.guardian_id LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id
            WHERE $where AND h.academic_status = 'Current' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED)", 'ssssss' . $types, $from, $to, $from, $to, $from, $to, ...$params);
    }
    $title = 'Student-wise — ' . date('d-m-Y', strtotime($from)) . ' to ' . date('d-m-Y', strtotime($to)) . ' (' . count($working) . ' working days)';
    $xlsx = [['Class', 'Section', 'Roll', 'Student', 'School UID', 'Father', 'Contact', 'Days taken', 'Present', 'Absent', 'Leave', 'Present %']];
    foreach ($rows as $r) { $t = $r['p'] + $r['ab'] + $r['l']; $xlsx[] = [$r['class_name'], $r['section_name'], $r['roll_no'], $r['student_name'], $r['id'], $r['father_name'] ?? '', $r['guardian_contact'] ?: $r['mobile'], $t, (int)$r['p'], (int)$r['ab'], (int)$r['l'], $t ? round($r['p'] / $t * 100, 1) : '']; }
}
if (!empty($_GET['xlsx'])) { SimpleXLSXWriter::download('attendance_' . $view . '_' . date('Y-m-d') . '.xlsx', $xlsx, 'Attendance', ['header_rows' => 1, 'freeze_rows' => 1]); }
$q = array_filter(['session_id' => $session_id, 'view' => $view, 'date' => $view === 'day' ? $date : null, 'month' => $view === 'monthly' ? $month : null, 'year' => $view === 'monthly' ? $year : null, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null, 'from' => $view === 'students' ? $from : null, 'to' => $view === 'students' ? $to : null, 'threshold' => $threshold !== 75 ? $threshold : null]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attendance Reports</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rp-banner { background: linear-gradient(135deg, #0f6e56 0%, #1fa37f 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(15,110,86,.25); }
    .rp-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rp-banner h1 { margin: 0; font-size: 21px; } .rp-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d5f2e8; }
    .rp-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .rp-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .rp-banner .links a.solid { background: #fff; color: #0f6e56; }
    .rp-tabs { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; }
    .rp-tabs a { padding: 8px 16px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #1f4e79; text-decoration: none; font-weight: 600; font-size: 13.5px; }
    .rp-tabs a.on { background: #1f4e79; color: #fff; border-color: #1f4e79; }
    .rp-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; } .rp-head h3 { margin: 0; font-size: 15px; color: #0f6e56; } .rp-head .spacer { flex: 1; }
    .rp-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 12px; }
    .rp-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; } .rp-stat b { display: block; font-size: 20px; color: #10253a; } .rp-stat small { color: #6b7d90; font-size: 12px; }
    .bar { display: inline-block; width: 90px; height: 8px; background: #eef2f6; border-radius: 4px; vertical-align: middle; margin-right: 6px; overflow: hidden; } .bar i { display: block; height: 100%; background: #1fa37f; }
    .bar.low i { background: #b0454f; }
    .lc-table td.low { background: #fde2e4; color: #9d2630; font-weight: 800; }
    .lc-table td.num { text-align: right; font-variant-numeric: tabular-nums; }
    .lc-filter .chk { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 13px; color: #3b5168; text-transform: none; letter-spacing: 0; margin: 0; font-weight: 600; }
    @media (max-width: 900px) { .rp-stats { grid-template-columns: 1fr 1fr; } }
    @media print { body > *:not(.page-box) { display: none !important; } .rp-banner .links, .rp-tabs, .lc-filter, .rp-head .btn { display: none !important; } .page-box { box-shadow: none; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rp-banner">
        <div class="ico"><i class="fas fa-chart-pie"></i></div>
        <div><h1>Attendance Reports</h1><p><?php echo h($school['school_name'] ?? ''); ?> · Sundays and holidays are never counted as working days</p></div>
        <div class="links"><a href="student_attendance.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-user-check"></i> Take attendance</a><a href="student_attendance_register.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-table"></i> Register</a><a href="?<?php echo h(http_build_query($q + ['xlsx' => 1])); ?>" class="solid"><i class="fas fa-file-excel"></i> Excel</a></div>
    </div>

    <div class="rp-tabs">
        <a href="?session_id=<?php echo $session_id; ?>&view=day" class="<?php echo $view === 'day' ? 'on' : ''; ?>"><i class="fas fa-calendar-day"></i> One day — all sections</a>
        <a href="?session_id=<?php echo $session_id; ?>&view=monthly" class="<?php echo $view === 'monthly' ? 'on' : ''; ?>"><i class="fas fa-calendar-alt"></i> Monthly — all sections</a>
        <a href="?session_id=<?php echo $session_id; ?>&view=students" class="<?php echo $view === 'students' ? 'on' : ''; ?>"><i class="fas fa-user-graduate"></i> Student-wise %</a>
    </div>

    <form method="get" class="lc-filter">
        <input type="hidden" name="view" value="<?php echo h($view); ?>">
        <div><label>Session</label><select name="session_id"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?></option><?php endforeach; ?></select></div>
        <?php if ($view === 'day'): ?>
        <div><label>Date</label><input type="date" name="date" value="<?php echo h($date); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <?php elseif ($view === 'monthly'): ?>
        <div><label>Month</label><select name="month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m === $month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 1)); ?></option><?php endfor; ?></select></div>
        <div><label>Year</label><select name="year"><?php for ($y = (int)date('Y') - 3; $y <= (int)date('Y'); $y++): ?><option value="<?php echo $y; ?>" <?php echo $y === $year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
        <?php else: ?>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="0">Select class</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="0">All sections</option><?php foreach ($sections as $x): ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div>
        <div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <div><label>Flag below</label><select name="threshold"><?php foreach ([60, 70, 75, 80, 90] as $t): ?><option value="<?php echo $t; ?>" <?php echo $t === $threshold ? 'selected' : ''; ?>><?php echo $t; ?>%</option><?php endforeach; ?></select></div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>

    <?php if ($view === 'day'): $taken = array_filter($rows, fn($r) => (int)$r['taken'] > 0); $sp = array_sum(array_column($taken, 'p')); $sm = array_sum(array_column($taken, 'taken')); ?>
    <div class="rp-head"><h3><?php echo h($title); ?></h3><?php if ($block): ?><span class="lc-tag warn"><?php echo h($block); ?></span><?php endif; ?></div>
    <div class="rp-stats">
        <div class="rp-stat"><b><?php echo count($taken); ?> / <?php echo count($rows); ?></b><small>Sections taken</small></div>
        <div class="rp-stat"><b><?php echo $sm ? round($sp / $sm * 100, 1) . '%' : '—'; ?></b><small>Present (of students marked)</small></div>
        <div class="rp-stat"><b><?php echo array_sum(array_column($taken, 'ab')); ?></b><small>Absent</small></div>
        <div class="rp-stat"><b><?php echo array_sum(array_column($taken, 'l')); ?></b><small>On leave</small></div>
    </div>
    <div style="overflow-x:auto"><table class="lc-table">
        <thead><tr><th>Class</th><th>Section</th><th>Students</th><th>Status</th><th>Present</th><th>Absent</th><th>Leave</th><th>Present %</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): $pct = (int)$r['taken'] ? round($r['p'] / $r['taken'] * 100) : null; ?>
        <tr><td><?php echo h($r['class_name']); ?></td><td><?php echo h($r['section_name']); ?></td><td class="num"><?php echo (int)$r['strength']; ?></td>
            <td><?php echo (int)$r['taken'] ? '<span class="lc-tag ok">taken</span>' : ($block ? '<span class="lc-tag muted">holiday</span>' : '<span class="lc-tag warn">pending</span>'); ?></td>
            <td class="num"><?php echo (int)$r['taken'] ? (int)$r['p'] : '—'; ?></td><td class="num"><?php echo (int)$r['taken'] ? (int)$r['ab'] : '—'; ?></td><td class="num"><?php echo (int)$r['taken'] ? (int)$r['l'] : '—'; ?></td>
            <td class="num <?php echo $pct !== null && $pct < $threshold ? 'low' : ''; ?>"><?php if ($pct !== null): ?><span class="bar <?php echo $pct < $threshold ? 'low' : ''; ?>"><i style="width:<?php echo $pct; ?>%"></i></span><?php echo $pct; ?>%<?php else: ?>—<?php endif; ?></td>
            <td><a href="student_attendance.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo (int)$r['class_id']; ?>&section_id=<?php echo (int)$r['section_id']; ?>&attendance_date=<?php echo h($date); ?>" class="btn btn-secondary btn-sm"><?php echo (int)$r['taken'] ? 'Open' : 'Take'; ?></a></td></tr>
        <?php endforeach; ?></tbody></table></div>

    <?php elseif ($view === 'monthly'): ?>
    <div class="rp-head"><h3><?php echo h($title); ?></h3></div>
    <div style="overflow-x:auto"><table class="lc-table">
        <thead><tr><th>Class</th><th>Section</th><th>Students</th><th>Days taken</th><th>Present marks</th><th>Absent</th><th>Leave</th><th>Average presence</th><th></th></tr></thead>
        <tbody><?php foreach ($rows as $r): $pct = (int)$r['marks'] ? round($r['p'] / $r['marks'] * 100) : null; $missing = count($working) - (int)$r['days_taken']; ?>
        <tr><td><?php echo h($r['class_name']); ?></td><td><?php echo h($r['section_name']); ?></td><td class="num"><?php echo (int)$r['strength']; ?></td>
            <td class="num"><?php echo (int)$r['days_taken']; ?> / <?php echo count($working); ?><?php echo $missing > 0 ? ' <span class="lc-tag warn">' . $missing . ' missing</span>' : ''; ?></td>
            <td class="num"><?php echo (int)$r['p']; ?></td><td class="num"><?php echo (int)$r['ab']; ?></td><td class="num"><?php echo (int)$r['l']; ?></td>
            <td class="num <?php echo $pct !== null && $pct < $threshold ? 'low' : ''; ?>"><?php if ($pct !== null): ?><span class="bar <?php echo $pct < $threshold ? 'low' : ''; ?>"><i style="width:<?php echo $pct; ?>%"></i></span><?php echo $pct; ?>%<?php else: ?>—<?php endif; ?></td>
            <td><a href="student_attendance_register.php?session_id=<?php echo $session_id; ?>&class_id=<?php echo (int)$r['class_id']; ?>&section_id=<?php echo (int)$r['section_id']; ?>&month=<?php echo $month; ?>&year=<?php echo $year; ?>" class="btn btn-secondary btn-sm">Register</a></td></tr>
        <?php endforeach; ?></tbody></table></div>

    <?php else: ?>
    <div class="rp-head"><h3><?php echo h($title); ?></h3><span class="spacer"></span><?php if ($rows): ?><label class="chk" style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="onlyLow"> only below <?php echo $threshold; ?>%</label><?php endif; ?></div>
    <?php if (!$class_id): ?><div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a class (and optionally a section) and a date range.</div>
    <?php elseif (!$rows): ?><div class="lc-empty"><i class="fas fa-users"></i>No active students.</div>
    <?php else: $low = 0; foreach ($rows as $r) { $t = $r['p'] + $r['ab'] + $r['l']; if ($t && $r['p'] / $t * 100 < $threshold) $low++; } ?>
    <div class="rp-stats">
        <div class="rp-stat"><b><?php echo count($rows); ?></b><small>Students</small></div>
        <div class="rp-stat"><b><?php echo count($working); ?></b><small>Working days in the range</small></div>
        <div class="rp-stat"><b><?php echo $low; ?></b><small>Below <?php echo $threshold; ?>%</small></div>
        <div class="rp-stat"><b><?php $tp = array_sum(array_column($rows, 'p')); $tm = $tp + array_sum(array_column($rows, 'ab')) + array_sum(array_column($rows, 'l')); echo $tm ? round($tp / $tm * 100, 1) . '%' : '—'; ?></b><small>Average presence</small></div>
    </div>
    <div style="overflow-x:auto"><table class="lc-table" id="stuTable">
        <thead><tr><th>#</th><th>Student</th><th>Class</th><th>Father / contact</th><th>Days</th><th>P</th><th>A</th><th>L</th><th>Present %</th></tr></thead>
        <tbody><?php $sl = 0; foreach ($rows as $r): $sl++; $t = $r['p'] + $r['ab'] + $r['l']; $pct = $t ? round($r['p'] / $t * 100) : null; $isLow = $pct !== null && $pct < $threshold; ?>
        <tr class="<?php echo $isLow ? 'low' : 'ok'; ?>"><td><?php echo $sl; ?></td><td><?php echo lifecycle_student_cell($r); ?></td><td><?php echo h($r['class_name'] . '-' . $r['section_name']); ?> · <?php echo h($r['roll_no']); ?></td>
            <td><?php echo h($r['father_name'] ?? ''); ?><br><small style="color:#6b7d90"><?php echo h($r['guardian_contact'] ?: $r['mobile']); ?></small></td>
            <td class="num"><?php echo $t; ?></td><td class="num"><?php echo (int)$r['p']; ?></td><td class="num"><?php echo (int)$r['ab']; ?></td><td class="num"><?php echo (int)$r['l']; ?></td>
            <td class="num <?php echo $isLow ? 'low' : ''; ?>"><?php if ($pct !== null): ?><span class="bar <?php echo $isLow ? 'low' : ''; ?>"><i style="width:<?php echo $pct; ?>%"></i></span><?php echo $pct; ?>%<?php else: ?>—<?php endif; ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    <?php endif; endif; ?>
</div>
<script>
var SESSION = <?php echo (int)$session_id; ?>;
var fc = document.getElementById('fClass'); if (fc) fc.addEventListener('change', function () {
    var sel = document.getElementById('fSection'); sel.innerHTML = '<option value="0">All sections</option>';
    if (!this.value || this.value === '0') return;
    fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + SESSION + '&no_placeholder=1').then(function (r) { return r.text(); }).then(function (html) { sel.innerHTML += html; });
});
var ol = document.getElementById('onlyLow'); if (ol) ol.addEventListener('change', function () { document.querySelectorAll('#stuTable tbody tr').forEach(function (tr) { tr.hidden = ol.checked && !tr.classList.contains('low'); }); });
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/student_fields.php';
require_once '../includes/security.php';

/**
 * Bulk Update — a spreadsheet of the students in one section.
 * Rows = Active students enrolled in the chosen session / class / section;
 * columns = whichever fields the admin ticks. Editing happens in the browser
 * (assets/js/bulk_grid.js); only changed cells are posted, as JSON, to
 * bulk_update_save.php. Photos / signatures / certificates go one at a time
 * through student_photo_upload.php (file chooser or the photo booth).
 */
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$active   = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = (int)($_GET['session_id'] ?? $active);
$class_id   = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$search     = trim((string)($_GET['search'] ?? ''));

$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $session_id ? db_get_all('SELECT id, class_id, section_name FROM sections WHERE session_id = ? ORDER BY class_id, section_name', 'i', $session_id) : [];

$students = [];
if ($session_id && $class_id && $section_id) {
    $params = [$session_id, $class_id, $section_id]; $types = 'iii'; $extra = '';
    if ($search !== '') {
        $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
        $extra = ' AND (s.student_name LIKE ? OR s.id LIKE ? OR h.roll_no = ?)';
        array_push($params, $like, $like, $search); $types .= 'sss';
    }
    $students = db_get_all("
        SELECT s.*, h.id AS hist_id, h.class_id, h.section_id, h.roll_no, h.previous_school,
               g.father_name, g.father_aadhaar, g.father_voter_id, g.father_mobile, g.father_occupation, g.father_qualification, g.annual_income,
               g.mother_name, g.mother_aadhaar, g.mother_voter_id, g.mother_occupation,
               g.guardian_name, g.guardian_relation, g.guardian_contact, g.guardian_email
        FROM students s
        JOIN student_academic_history h ON h.student_id = s.id AND h.session_id = ? AND h.academic_status = 'Current'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE s.student_status = 'Active' AND h.class_id = ? AND h.section_id = ? $extra
        ORDER BY CAST(h.roll_no AS UNSIGNED), s.student_name", $types, ...$params);
}

// ---- payload for the grid: only the whitelisted fields, NULL -> '' ----
$FIELDS = student_bulk_fields();
$rows = [];
foreach ($students as $s) {
    $r = ['uid' => $s['id']];
    foreach ($FIELDS as $key => $d) {
        $v = $s[$d['col']] ?? '';
        if ($key === 'disability_percentage' || $key === 'annual_income') $v = ($v === null || $v === '') ? '' : rtrim(rtrim((string)$v, '0'), '.');
        $r[$key] = $v === null ? '' : (string)$v;
    }
    $rows[] = $r;
}
$payload = [
    'csrf' => csrf_token(), 'session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $section_id,
    'fields' => $FIELDS, 'groups' => student_bulk_groups(),
    'classes' => array_map(fn($c) => ['id' => (int)$c['id'], 'name' => $c['class_name']], $classes),
    'sections' => array_map(fn($x) => ['id' => (int)$x['id'], 'class_id' => (int)$x['class_id'], 'name' => $x['section_name']], $sections),
    'students' => $rows,
    'booth_url' => "photo_booth.php?session_id=$session_id&class_id=$class_id&section_id=$section_id",
];
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$class_name = ''; foreach ($classes as $c) if ((int)$c['id'] === $class_id) $class_name = $c['class_name'];
$section_name = ''; foreach ($sections as $x) if ((int)$x['id'] === $section_id) $section_name = $x['section_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bulk Update<?php echo $class_name ? " — $class_name" . ($section_name ? "-$section_name" : '') : ''; ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link rel="stylesheet" href="../assets/css/bulk_grid.css">
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box bg-page">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-table"></i> Bulk Update
            <?php if ($students): ?><span class="bg-count"><?php echo count($students); ?> students</span><?php endif; ?>
        </div>
        <div>
            <?php if ($students): ?><a href="<?php echo h($payload['booth_url']); ?>" class="btn btn-secondary"><i class="fas fa-camera"></i> Photo booth</a><?php endif; ?>
            <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>

    <form method="get" class="bg-filter">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="">Select</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="">Select</option><?php foreach ($sections as $x): if ((int)$x['class_id'] !== $class_id) continue; ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Find in section</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="name / UID / roll"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-list"></i> Load</button>
    </form>

    <?php if (!$session_id || !$class_id || !$section_id): ?>
    <div class="bg-empty"><i class="fas fa-hand-pointer"></i>Choose a class and section, then Load.</div>
    <?php elseif (!$students): ?>
    <div class="bg-empty"><i class="fas fa-user-slash"></i>No active students in this section<?php echo $search !== '' ? ' match the search' : ''; ?>.</div>
    <?php else: ?>

    <div class="bg-picker" id="picker">
        <span class="bg-picker-title"><i class="fas fa-columns"></i> Columns</span>
        <?php foreach (student_bulk_groups() as $grp): ?>
        <span class="bg-group"><b><?php echo h($grp); ?></b>
            <?php foreach ($FIELDS as $key => $d): if ($d['group'] !== $grp) continue; ?>
            <label class="chip"><input type="checkbox" value="<?php echo h($key); ?>"> <?php echo h($d['label']); ?></label>
            <?php endforeach; ?>
        </span>
        <?php endforeach; ?>
        <button type="button" class="btn btn-secondary btn-sm" id="clearCols" title="Show only Roll and Name">Clear</button>
    </div>

    <div class="bg-toolbar">
        <span class="bg-hint"><b>Tab / Enter / ↑↓</b> move · <b>Ctrl+D</b> fill down · <b>Esc</b> undo cell · paste rows from Excel</span>
        <span class="spacer"></span>
        <span id="dirtyCount" class="bg-dirty-count" hidden>0 changes</span>
        <button type="button" class="btn btn-secondary" id="revertAll" disabled><i class="fas fa-undo"></i> Discard</button>
        <button type="button" class="btn btn-success" id="saveBtn" disabled><i class="fas fa-save"></i> Save changes</button>
    </div>
    <div id="rowErrors" class="alert alert-danger" hidden></div>

    <div class="bg-scroll"><table class="bg-grid" id="grid"><thead></thead><tbody></tbody></table></div>
    <div id="toast" class="bg-toast" hidden></div>

    <script id="grid-data" type="application/json"><?php echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP); ?></script>
    <script src="../assets/js/bulk_grid.js"></script>
    <script type="module" src="../assets/js/photo_booth.js"></script>
    <?php endif; ?>
</div>

<script>
// the section list follows the class (all sections of the session are in the page)
(function () {
    var secs = <?php echo json_encode(array_map(fn($x) => ['id' => (int)$x['id'], 'class_id' => (int)$x['class_id'], 'name' => $x['section_name']], $sections)); ?>;
    var c = document.getElementById('fClass'), s = document.getElementById('fSection');
    c.addEventListener('change', function () {
        s.innerHTML = '<option value="">Select</option>' + secs.filter(function (x) { return x.class_id === +c.value; }).map(function (x) { return '<option value="' + x.id + '">' + x.name.replace(/[<>&"]/g, '') + '</option>'; }).join('');
    });
})();
</script>
</body>
</html>

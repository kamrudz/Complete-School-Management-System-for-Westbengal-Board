<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/fee_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Fee discounts (concessions): one per student per session. A percentage comes off each fee that takes a discount; a
 * fixed amount comes off once a session, from the fees collected first. A fee takes the ACTIVE discount when it is
 * collected; a fee collected earlier keeps its figures.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$active_session = fee_active_session_id();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0) ?: $active_session;
$reasons = ['BPL / financially weak', 'Sibling concession', 'Staff ward', 'Merit scholarship', 'Orphan / single parent', 'Other'];

/**
 * Each student's fees of the session that the whole class pays: their total and the part that takes a discount (paise),
 * what they pay with the active discount, and what is billed and paid so far.
 */
function discount_fees(int $session_id, array $rows): array {
    if (!$rows) return [];
    $students = fee_class_students($session_id, array_unique(array_map(fn($r) => (int)$r['class_id'], $rows)), 0, array_column($rows, 'id'));
    if (!$students) return [];
    $uids = array_map('strval', array_keys($students));
    $heads = array_filter(fee_session_heads(), fn($h) => in_array($h['who_pays'], ['everyone', 'new', 'continuing'], true));
    $amounts = fee_class_amounts($session_id, array_unique(array_map(fn($st) => (int)$st['class_id'], $students)));
    $discounts = fee_discounts($session_id, $uids);
    $billed = [];
    foreach (db_get_all("SELECT student_id, SUM(total) AS total, SUM(paid_amount) AS paid FROM fee_invoices WHERE session_id = ? AND status <> 'cancelled' AND demand_key IS NOT NULL
        AND student_id IN (" . implode(',', array_fill(0, count($uids), '?')) . ') GROUP BY student_id', 'i' . str_repeat('s', count($uids)), $session_id, ...$uids) as $b) {
        $paid = fee_paise($b['paid']);
        $billed[$b['student_id']] = ['total' => $b['total'], 'paid_amount' => $b['paid'], 'status' => $paid >= fee_paise($b['total']) ? 'paid' : ($paid > 0 ? 'partial' : 'pending'), 'due_date' => null];
    }
    $out = [];
    foreach ($students as $uid => $st) {
        $uid = (string)$uid;
        $sub = $base = 0;
        foreach ($heads as $hid => $h) {
            $a = $amounts[(int)$st['class_id']][$hid]['amount'] ?? 0;
            if (!$a || ($h['who_pays'] === 'new' && $st['continuing']) || ($h['who_pays'] === 'continuing' && !$st['continuing'])) continue;
            $sub += $a;
            if ($h['discountable']) $base += $a;
        }
        $d = $discounts[$uid] ?? null;
        $off = !$d ? 0 : ($d['discount_type'] === 'percentage' ? (int)round($base * min(100, max(0, (float)$d['discount_value'])) / 100) : min($base, fee_paise($d['discount_value'])));
        $out[$uid] = ['subtotal' => $sub, 'base' => $base, 'pays' => $sub - $off, 'bill' => $billed[$uid] ?? null];
    }
    return $out;
}
function discount_bill_json(?array $b): ?array {
    return $b ? ['total' => (float)$b['total'], 'paid' => (float)$b['paid_amount'], 'state' => fee_bill_state($b)] : null;
}
function discount_label(?string $type, $value): string {
    if ($type === null) return '';
    return $type === 'percentage' ? rtrim(rtrim(number_format((float)$value, 2, '.', ''), '0'), '.') . '%' : fee_money($value);
}

// ---------- AJAX: search Active students of the session (for the "give a discount" box) ----------
if (($_GET['ajax'] ?? '') === 'search') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? ''));
    if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    $rows = db_get_all("
        SELECT s.id, s.student_name, s.photo, h.class_id, h.roll_no, c.class_name, sec.section_name, g.father_name,
               d.id AS discount_id, d.discount_type, d.discount_value, d.discount_reason, d.is_active
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN classes c ON c.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN student_discounts d ON d.student_id = s.id AND d.session_id = h.session_id
        WHERE h.session_id = ? AND h.academic_status = 'Current' AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ?)
        ORDER BY s.student_name LIMIT 12", 'issss', $session_id, $like, $like, $like, $like);
    $adm = discount_fees($session_id, $rows);
    $out = [];
    foreach ($rows as $r) {
        $a = $adm[$r['id']] ?? ['subtotal' => 0, 'base' => 0, 'bill' => null];
        $out[] = ['id' => $r['id'], 'name' => $r['student_name'], 'father' => $r['father_name'] ?? '',
            'photo' => $r['photo'] ? '../uploads/students/' . rawurlencode($r['photo']) : '',
            'where' => trim(($r['class_name'] ?? '') . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · Roll ' . $r['roll_no'] : '')),
            'subtotal' => $a['subtotal'] / 100, 'base' => $a['base'] / 100,
            'discount' => $r['discount_id'] ? ['type' => $r['discount_type'], 'value' => (float)$r['discount_value'], 'reason' => $r['discount_reason'], 'active' => (int)$r['is_active']] : null,
            'invoice' => discount_bill_json($a['bill'])];
    }
    echo json_encode(['results' => $out]);
    exit();
}

// ---------- POST: save / remove / copy ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $back = 'student_discounts.php?' . http_build_query(array_filter(['session_id' => $session_id, 'class_id' => (int)($_POST['back_class'] ?? 0), 'section_id' => (int)($_POST['back_section'] ?? 0), 'show' => $_POST['back_show'] ?? '']));

    if (isset($_POST['save_discount'])) {
        $uid = student_uid_clean($_POST['student_id'] ?? '');
        $type = in_array($_POST['discount_type'] ?? '', ['percentage', 'fixed'], true) ? $_POST['discount_type'] : '';
        $value = (float)($_POST['discount_value'] ?? -1);
        $reason = trim((string)($_POST['reason'] ?? '')); $detail = trim((string)($_POST['reason_text'] ?? ''));
        if ($reason === 'Other' || $reason === '') $reason = $detail; elseif ($detail !== '') $reason .= ' — ' . $detail;
        $reason = mb_substr($reason, 0, 200);
        $is_active = !empty($_POST['is_active']) && $_POST['is_active'] !== '0' ? 1 : 0;
        $student = $uid !== '' ? db_get_row("SELECT s.id, s.student_name, h.class_id FROM students s JOIN student_academic_history h ON h.student_id = s.id AND h.session_id = ? WHERE s.id = ? AND s.student_status = 'Active'", 'is', $session_id, $uid) : null;
        $base = $student ? (discount_fees($session_id, [$student])[$uid]['base'] ?? 0) : 0;
        $err = '';
        if (!$student) $err = 'Student not found, not Active, or not enrolled in this session.';
        elseif ($type === '') $err = 'Choose percentage or fixed amount.';
        elseif ($value < 0 || ($type === 'percentage' && $value > 100)) $err = 'A percentage must be between 0 and 100.';
        elseif ($type === 'fixed' && $base > 0 && fee_paise($value) > $base) $err = 'A fixed discount cannot be more than the session\'s fees that take a discount (' . fee_money_p($base) . ').';
        elseif ($reason === '') $err = 'Give a reason for the discount.';
        if ($err) { $_SESSION['error'] = $err; header("Location: $back"); exit(); }
        $old = db_get_row('SELECT * FROM student_discounts WHERE student_id = ? AND session_id = ?', 'si', $uid, $session_id);
        if ($old) {
            db_update('student_discounts', ['discount_type' => $type, 'discount_value' => $value, 'discount_reason' => $reason, 'is_active' => $is_active], ['id' => (int)$old['id']], 'i');
        } else {
            db_insert('student_discounts', ['student_id' => $uid, 'session_id' => $session_id, 'discount_type' => $type, 'discount_value' => $value, 'discount_reason' => $reason, 'is_active' => $is_active, 'created_by' => $admin_id ?: null]);
        }
        log_action($admin_id, $old ? 'DISCOUNT_UPDATED' : 'DISCOUNT_SET', 'student_discounts', $uid, $old ? ['type' => $old['discount_type'], 'value' => $old['discount_value'], 'reason' => $old['discount_reason'], 'active' => $old['is_active']] : null,
            ['session' => $session_id, 'type' => $type, 'value' => $value, 'reason' => $reason, 'active' => $is_active]);
        $_SESSION['success'] = "{$student['student_name']}: discount " . discount_label($type, $value) . ($is_active ? '' : ' (inactive)') . ' saved for this session.';
        header("Location: $back"); exit();
    }

    if (isset($_POST['delete_id'])) {
        $row = db_get_row('SELECT d.*, s.student_name FROM student_discounts d JOIN students s ON s.id = d.student_id WHERE d.id = ?', 'i', (int)$_POST['delete_id']);
        if ($row) {
            db_execute('DELETE FROM student_discounts WHERE id = ?', 'i', (int)$row['id']);
            log_action($admin_id, 'DISCOUNT_REMOVED', 'student_discounts', $row['student_id'], ['session' => $row['session_id'], 'type' => $row['discount_type'], 'value' => $row['discount_value'], 'reason' => $row['discount_reason']], null);
            $_SESSION['success'] = "{$row['student_name']}: discount removed.";
        } else $_SESSION['error'] = 'Discount not found.';
        header("Location: $back"); exit();
    }

    if (isset($_POST['copy_from'])) {
        // carry last session's active discounts over to students who are enrolled in this session and have none yet
        $from = (int)$_POST['copy_from'];
        $src = db_get_all("SELECT d.* FROM student_discounts d JOIN students s ON s.id = d.student_id AND s.student_status = 'Active'
            JOIN student_academic_history h ON h.student_id = d.student_id AND h.session_id = ?
            WHERE d.session_id = ? AND d.is_active = 1 AND NOT EXISTS (SELECT 1 FROM student_discounts x WHERE x.student_id = d.student_id AND x.session_id = ?)", 'iii', $session_id, $from, $session_id);
        $n = 0;
        db_begin_transaction();
        try {
            foreach ($src as $d) { db_insert('student_discounts', ['student_id' => $d['student_id'], 'session_id' => $session_id, 'discount_type' => $d['discount_type'], 'discount_value' => $d['discount_value'], 'discount_reason' => $d['discount_reason'], 'is_active' => 1, 'created_by' => $admin_id ?: null]); $n++; }
            db_commit();
        } catch (Throwable $e) { db_rollback(); $_SESSION['error'] = 'Copy failed: ' . $e->getMessage(); header("Location: $back"); exit(); }
        log_action($admin_id, 'DISCOUNT_COPIED', 'student_discounts', (string)$session_id, null, "$n discount(s) copied from session $from to $session_id");
        $_SESSION['success'] = "$n discount(s) copied from the previous session (students who already had one, or are not enrolled this session, were skipped).";
        header("Location: $back"); exit();
    }
}

// ---------- the list ----------
$class_id   = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$show       = ($_GET['show'] ?? 'discounted') === 'all' && $class_id ? 'all' : 'discounted';   // "all" = every student of a class/section, with or without a discount
$roll       = trim((string)($_GET['roll'] ?? ''));
$search     = trim((string)($_GET['search'] ?? ''));
if ($roll !== '' && $class_id) $show = 'all';   // looking up one roll: show that student even without a discount
$page       = max(1, (int)($_GET['page'] ?? 1)); $per = 50;

$where = ['h.session_id = ?', "h.academic_status = 'Current'", "s.student_status = 'Active'"]; $params = [$session_id]; $types = 'i';
if ($show === 'discounted') $where[] = 'd.id IS NOT NULL';
if ($class_id)   { $where[] = 'h.class_id = ?';   $params[] = $class_id;   $types .= 'i'; }
if ($section_id) { $where[] = 'h.section_id = ?'; $params[] = $section_id; $types .= 'i'; }
if ($roll !== '')   { $where[] = 'h.roll_no = ?';    $params[] = $roll;       $types .= 's'; }
if ($search !== '') { $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%'; $where[] = '(s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ? OR d.discount_reason LIKE ?)'; array_push($params, $like, $like, $like, $like, $like); $types .= 'sssss'; }
$from = "FROM student_academic_history h
    JOIN students s ON s.id = h.student_id
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    LEFT JOIN student_discounts d ON d.student_id = s.id AND d.session_id = h.session_id
    LEFT JOIN admins a ON a.id = d.created_by
    WHERE " . implode(' AND ', $where);
$total = (int)(db_get_row("SELECT COUNT(*) AS c $from", $types, ...$params)['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per)); if ($page > $pages) $page = $pages; $offset = ($page - 1) * $per;
$rows = $total ? db_get_all("SELECT s.id, s.student_name, s.photo, h.class_id, h.roll_no, c.class_name, sec.section_name, g.father_name, g.guardian_contact, s.mobile,
        d.id AS discount_id, d.discount_type, d.discount_value, d.discount_reason, d.is_active, d.created_at, d.updated_at, a.full_name AS by_name
    $from ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name LIMIT $per OFFSET $offset", $types, ...$params) : [];
$adm = discount_fees($session_id, $rows);

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id) : [];
$prev_session = db_get_row('SELECT id, session_name FROM academic_sessions WHERE session_name < (SELECT session_name FROM academic_sessions WHERE id = ?) ORDER BY session_name DESC LIMIT 1', 'i', $session_id);
$stat = db_get_row("SELECT COUNT(*) AS total, SUM(d.is_active = 1) AS active, SUM(d.discount_type = 'percentage') AS pct
    FROM student_discounts d JOIN students s ON s.id = d.student_id AND s.student_status = 'Active' WHERE d.session_id = ?", 'i', $session_id) ?: [];
$waived = fee_paise(db_get_row("SELECT COALESCE(SUM(discount_amount), 0) AS t FROM fee_invoices WHERE session_id = ? AND status <> 'cancelled'", 'i', $session_id)['t'] ?? 0);
$has_amounts = (bool)db_get_row("SELECT 1 FROM fee_structures f JOIN fee_types t ON t.id = f.fee_type_id WHERE f.session_id = ? AND t.charge = 'session' AND f.amount > 0 LIMIT 1", 'i', $session_id);
$qs = array_filter(['session_id' => $session_id, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null, 'roll' => $roll !== '' ? $roll : null, 'show' => $show === 'all' ? 'all' : null, 'search' => $search !== '' ? $search : null]);
function page_url(int $p): string { global $qs; return 'student_discounts.php?' . http_build_query($qs + ($p > 1 ? ['page' => $p] : [])); }
$win = []; foreach (array_unique(array_filter(array_merge([1, 2], range($page - 2, $page + 2), [$pages - 1, $pages]), fn($p) => $p >= 1 && $p <= $pages)) as $p) $win[] = $p; sort($win);
$session_name = ''; foreach ($sessions as $ss) if ((int)$ss['id'] === $session_id) $session_name = $ss['session_name'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Fee Discounts</title>
<?php exam_styles('fee'); lifecycle_styles(); ?>
<style>
    .ex-banner .links button.give { background: #fff; color: var(--ex-dark); border-color: #fff; }
    .lc-table th { background: var(--ex-dark); }
    #fdFind .lc-dialog { max-width: 640px; }
    #fdFind .fd-res { max-height: 360px; overflow: auto; }
    .fd-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .fd-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
    .fd-stat i { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex: 0 0 38px; }
    .fd-stat b { font-size: 21px; display: block; line-height: 1.1; color: #10253a; }
    .fd-stat small { color: #6b7d90; font-size: 12px; }
    .fd-stat.t1 i { background: #e7f6ec; color: #1f8a4c; } .fd-stat.t2 i { background: #eaf2fb; color: #1f4e79; } .fd-stat.t3 i { background: #fff6e5; color: #9a5a00; } .fd-stat.t4 i { background: #f3f0fb; color: #5b3fa0; }
    .fd-wrap { position: relative; }
    .fd-wrap input { width: 100%; height: 44px; padding: 8px 14px 8px 40px; border: 1px solid #c9d6e2; border-radius: 10px; font-size: 14.5px; box-sizing: border-box; }
    .fd-wrap input:focus { outline: none; border-color: #1f8a4c; box-shadow: 0 0 0 3px rgba(31,138,76,.15); }
    .fd-wrap > i { position: absolute; left: 14px; top: 15px; color: #8a9aab; }
    .fd-res { margin-top: 10px; border: 1px solid #dfe7ef; border-radius: 10px; overflow: hidden; display: none; }
    .fd-res.open { display: block; }
    .fd-item { display: flex; align-items: center; gap: 12px; padding: 9px 12px; border-bottom: 1px solid #eef2f6; }
    .fd-item:last-child { border-bottom: 0; }
    .fd-item img, .fd-item .noimg { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; background: #edf2f7; flex: 0 0 40px; border: 1px solid #d5dee7; }
    .fd-item .who { flex: 1; font-size: 13.5px; min-width: 0; }
    .fd-item .who small { color: #6b7d90; display: block; }
    .fd-item .has { color: #1f8a4c; font-weight: 700; font-size: 12.5px; white-space: nowrap; }
    .fd-item .none { color: #7a8a9a; padding: 4px 0; }
    .fd-hint { color: #6b7d90; font-size: 12.5px; margin-top: 8px; }
    .fd-hint i { color: #1f8a4c; }
    .fd-warn { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 10px; padding: 9px 14px; font-size: 13px; margin-bottom: 12px; }
    .fd-list-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; }
    .fd-list-head h3 { margin: 0; font-size: 15px; color: #14532d; }
    .fd-list-head .n { color: #6b7d90; font-size: 13px; }
    .lc-filter .chk { display: flex; align-items: center; gap: 7px; height: 38px; font-size: 13px; color: #3b5168; text-transform: none; letter-spacing: 0; margin: 0; font-weight: 600; }
    .lc-filter .chk input { width: 17px; height: 17px; min-width: 0; margin: 0; accent-color: #1f8a4c; }
    .lc-table .place span { background: #eaf2fb; color: #1f4e79; font-weight: 700; padding: 2px 8px; border-radius: 7px; font-size: 12px; margin-right: 3px; }
    .lc-table .place span.roll { background: #1f4e79; color: #fff; }
    .lc-table .disc { font-weight: 800; color: #1f8a4c; font-size: 15px; }
    .lc-table .disc.off { color: #9aa9b8; text-decoration: line-through; }
    .lc-table small { color: #6b7d90; display: block; }
    .lc-table .inv { font-size: 12px; }
    .pg { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; justify-content: center; margin: 12px 0 4px; }
    .pg a, .pg span.cur, .pg span.gap { min-width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; background: #fff; color: #1f4e79; text-decoration: none; font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg span.cur { background: #1f8a4c; color: #fff; border-color: #1f8a4c; } .pg span.gap { border: 0; color: #8a9aab; } .pg a.dis { pointer-events: none; opacity: .4; }
    /* dialog */
    .fd-dlg h3 { background: linear-gradient(135deg, #1f8a4c, #2fb36a) !important; }
    .fd-dlg .stu { display: flex; align-items: center; gap: 12px; background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 10px 12px; }
    .fd-dlg .stu img, .fd-dlg .stu .noimg { width: 46px; height: 46px; border-radius: 50%; object-fit: cover; background: #edf2f7; border: 1px solid #d5dee7; display: inline-block; }
    .fd-dlg .stu small { color: #6b7d90; display: block; }
    .fd-dlg .row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 12px; }
    .fd-dlg .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
    .fd-dlg .calc { margin-top: 12px; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; text-align: center; }
    .fd-dlg .calc div { background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 8px; }
    .fd-dlg .calc b { display: block; font-size: 17px; color: #10253a; } .fd-dlg .calc small { color: #6b7d90; font-size: 11px; text-transform: uppercase; letter-spacing: .4px; }
    .fd-dlg .calc div.net b { color: #1f8a4c; }
    .fd-dlg .warn { display: none; margin-top: 10px; background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 8px; padding: 8px 12px; font-size: 13px; } .fd-dlg .warn.on { display: block; }
    .fd-dlg .chk { display: flex; align-items: center; gap: 8px; margin-top: 12px; font-size: 13.5px; } .fd-dlg .chk input { width: 17px; height: 17px; accent-color: #1f8a4c; }
    @media (max-width: 900px) { .fd-stats { grid-template-columns: 1fr 1fr; } .fd-dlg .row3, .fd-dlg .row2, .fd-dlg .calc { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="ex-banner">
        <div class="ico"><i class="fas fa-percent"></i></div>
        <div><h1>Discounts</h1><p>Concessions for session <?php echo h($session_name); ?> — taken off when a fee is collected</p></div>
        <div class="links">
            <button type="button" class="give" onclick="document.getElementById('fdFind').classList.add('open'); document.getElementById('fdSearch').focus()"><i class="fas fa-user-tag"></i> Give a discount</button>
            <?php if ($prev_session): ?><button type="button" onclick="copyPrev()"><i class="fas fa-copy"></i> Copy from <?php echo h($prev_session['session_name']); ?></button><?php endif; ?>
        </div>
    </div>
    <?php fee_tabs('student_discounts.php'); exam_flash(); ?>
    <?php if (!$has_amounts): ?>
    <div class="fd-warn"><i class="fas fa-exclamation-triangle"></i> No class amounts are set for <?php echo h($session_name); ?> yet, so the fees show ₹0.00. Discounts can still be recorded; set the amounts in <a href="fee_settings.php?<?php echo h(http_build_query(['session_id' => $session_id])); ?>">Fee Settings</a> before collecting.</div>
    <?php endif; ?>

    <div class="fd-stats">
        <div class="fd-stat t1"><i class="fas fa-percent"></i><div><b><?php echo (int)($stat['total'] ?? 0); ?></b><small>Students with a discount</small></div></div>
        <div class="fd-stat t2"><i class="fas fa-check"></i><div><b><?php echo (int)($stat['active'] ?? 0); ?></b><small>Active</small></div></div>
        <div class="fd-stat t3"><i class="fas fa-rupee-sign"></i><div><b><?php echo h(fee_money_p($waived)); ?></b><small>Taken off the bills of this session</small></div></div>
        <div class="fd-stat t4"><i class="fas fa-chart-pie"></i><div><b><?php echo (int)($stat['pct'] ?? 0); ?> / <?php echo (int)($stat['total'] ?? 0) - (int)($stat['pct'] ?? 0); ?></b><small>Percentage / fixed-amount</small></div></div>
    </div>

    <form method="get" class="lc-filter" id="filters">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="0">All classes</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="0">All sections</option><?php foreach ($sections as $x): ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Roll no</label><input type="text" name="roll" value="<?php echo h($roll); ?>" inputmode="numeric" maxlength="4" placeholder="e.g. 12" style="min-width:90px;width:90px"></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, UID, BSID, father, reason" style="min-width:200px"></div>
        <label class="chk" title="Needs a class"><input type="checkbox" name="show" value="all" <?php echo $show === 'all' ? 'checked' : ''; ?>> Every student of the class</label>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <?php if ($class_id || $section_id || $roll !== '' || $search !== '' || $show === 'all'): ?><a href="student_discounts.php?session_id=<?php echo $session_id; ?>" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <div class="fd-list-head">
        <h3><i class="fas fa-list"></i> <?php echo $show === 'all' ? ($roll !== '' ? 'Student at this roll' : 'All students of the class') : 'Students with a discount'; ?></h3>
        <span class="n"><?php echo number_format($total); ?> · showing <?php echo $total ? number_format($offset + 1) . '–' . number_format(min($offset + $per, $total)) : '0'; ?><?php if ($show !== 'all'): ?> · tick "Every student of the class" or type a roll to give a new discount from the list<?php endif; ?></span>
    </div>
    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-percent"></i><?php echo $show === 'all' ? 'No students match.' : 'No discounts in this session' . ($class_id || $search !== '' ? ' for this filter' : '') . ' — use the search box above to give one.'; ?></div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>#</th><th>Student</th><th>Father / contact</th><th>Class · Sec · Roll</th><th>Session fees</th><th>Discount</th><th>Reason · given by</th><th>Collected</th><th>Actions</th></tr></thead>
        <tbody>
        <?php $sl = $offset; foreach ($rows as $r): $sl++; $a = $adm[$r['id']] ?? ['subtotal' => 0, 'base' => 0, 'pays' => 0, 'bill' => null]; ?>
        <tr>
            <td><?php echo $sl; ?></td>
            <td><?php echo lifecycle_student_cell($r); ?></td>
            <td><?php echo h($r['father_name'] ?? ''); ?><?php if ($r['guardian_contact'] ?: $r['mobile']): ?><small><i class="fas fa-phone" style="color:#8a9aab"></i> <?php echo h($r['guardian_contact'] ?: $r['mobile']); ?></small><?php endif; ?></td>
            <td style="white-space:nowrap"><span class="place"><span><?php echo h($r['class_name']); ?></span><?php if ($r['section_name']): ?><span><?php echo h($r['section_name']); ?></span><?php endif; ?><?php if ($r['roll_no']): ?><span class="roll"><?php echo h($r['roll_no']); ?></span><?php endif; ?></span></td>
            <td style="white-space:nowrap"><?php echo h(fee_money_p($a['subtotal'])); ?></td>
            <td style="white-space:nowrap"><?php if ($r['discount_id']): ?><span class="disc <?php echo $r['is_active'] ? '' : 'off'; ?>"><?php echo h(discount_label($r['discount_type'], $r['discount_value'])); ?></span><small><?php echo $r['is_active'] ? 'pays ' . h(fee_money_p($a['pays'])) : 'inactive — no effect'; ?></small><?php else: ?><span style="color:#9aa9b8">—</span><?php endif; ?></td>
            <td><?php if ($r['discount_id']): ?><?php echo h($r['discount_reason']); ?><small><?php echo h($r['by_name'] ?: 'admin'); ?> · <?php echo date('d-m-Y', strtotime($r['updated_at'] ?: $r['created_at'])); ?></small><?php endif; ?></td>
            <td class="inv"><?php if ($a['bill']): ?><?php echo fee_state_chip(fee_bill_state($a['bill'])); ?><small><?php echo h(fee_money($a['bill']['paid_amount'])); ?> of <?php echo h(fee_money($a['bill']['total'])); ?></small><?php else: ?><span class="chip off">Nothing yet</span><?php endif; ?></td>
            <td class="lc-actions">
                <button type="button" class="btn <?php echo $r['discount_id'] ? 'btn-warning' : 'btn-success'; ?> btn-sm" title="<?php echo $r['discount_id'] ? 'Edit discount' : 'Give discount'; ?>" onclick="fdOpen(<?php echo h(json_encode(['id' => $r['id'], 'name' => $r['student_name'], 'photo' => $r['photo'] ? '../uploads/students/' . rawurlencode($r['photo']) : '', 'father' => $r['father_name'] ?? '', 'where' => trim($r['class_name'] . ($r['section_name'] ? '-' . $r['section_name'] : '') . ($r['roll_no'] ? ' · Roll ' . $r['roll_no'] : '')), 'subtotal' => $a['subtotal'] / 100, 'base' => $a['base'] / 100, 'discount' => $r['discount_id'] ? ['type' => $r['discount_type'], 'value' => (float)$r['discount_value'], 'reason' => $r['discount_reason'], 'active' => (int)$r['is_active']] : null, 'invoice' => discount_bill_json($a['bill'])])); ?>)"><i class="fas <?php echo $r['discount_id'] ? 'fa-edit' : 'fa-plus'; ?>"></i></button>
                <?php if ($r['discount_id']): ?>
                <form method="post" onsubmit="return confirm('Remove the discount for <?php echo h(addslashes($r['student_name'])); ?>?')"><?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo (int)$r['discount_id']; ?>"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="back_class" value="<?php echo $class_id; ?>"><input type="hidden" name="back_section" value="<?php echo $section_id; ?>"><input type="hidden" name="back_show" value="<?php echo h($show === 'all' ? 'all' : ''); ?>"><button type="submit" class="btn btn-danger btn-sm" title="Remove discount"><i class="fas fa-trash"></i></button></form>
                <?php endif; ?>
                <a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>" class="btn btn-info btn-sm" title="View student"><i class="fas fa-eye"></i></a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="pg">
        <a href="<?php echo h(page_url($page - 1)); ?>" class="<?php echo $page <= 1 ? 'dis' : ''; ?>"><i class="fas fa-chevron-left"></i></a>
        <?php $prev = 0; foreach ($win as $p): if ($p - $prev > 1): ?><span class="gap">…</span><?php endif; $prev = $p; ?><?php if ($p === $page): ?><span class="cur"><?php echo $p; ?></span><?php else: ?><a href="<?php echo h(page_url($p)); ?>"><?php echo $p; ?></a><?php endif; endforeach; ?>
        <a href="<?php echo h(page_url($page + 1)); ?>" class="<?php echo $page >= $pages ? 'dis' : ''; ?>"><i class="fas fa-chevron-right"></i></a>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<!-- find a student to give a discount -->
<div class="lc-modal" id="fdFind">
    <div class="lc-dialog fd-dlg">
        <h3><i class="fas fa-user-tag"></i> Give a discount <small style="font-weight:400;margin-left:auto">Active students of <?php echo h($session_name); ?></small></h3>
        <div class="body">
            <div class="fd-wrap"><i class="fas fa-search"></i><input type="text" id="fdSearch" placeholder="Type a name, School UID, Banglar Shiksha ID or father's name…" autocomplete="off"></div>
            <div class="fd-res" id="fdRes"></div>
            <div class="fd-hint"><i class="fas fa-info-circle"></i> One discount per student per session. It comes off each fee when it is <b>collected</b>; a fee collected earlier keeps its figures. Every change is logged with your name.</div>
        </div>
        <div class="foot"><button type="button" class="btn btn-secondary" onclick="document.getElementById('fdFind').classList.remove('open')">Close</button></div>
    </div>
</div>

<!-- give / edit discount -->
<div class="lc-modal" id="fdModal">
    <form class="lc-dialog fd-dlg" method="post" action="student_discounts.php" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="save_discount" value="1"><input type="hidden" name="student_id" id="fdUid">
        <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="back_class" value="<?php echo $class_id; ?>"><input type="hidden" name="back_section" value="<?php echo $section_id; ?>"><input type="hidden" name="back_show" value="<?php echo h($show === 'all' ? 'all' : ''); ?>">
        <h3 id="fdTitle"><i class="fas fa-percent"></i> Give a discount</h3>
        <div class="body">
            <div class="stu"><span id="fdPhoto"></span><div><b id="fdName"></b> <span class="lc-uid" id="fdUidBadge"></span><small id="fdWhere"></small></div></div>
            <div class="row3">
                <div><label>Type</label><select name="discount_type" id="fdType"><option value="percentage">Percentage (%)</option><option value="fixed">Fixed amount (₹)</option></select></div>
                <div><label>Value</label><input type="number" name="discount_value" id="fdValue" min="0" step="0.01" required></div>
                <div><label>Reason</label><select name="reason" id="fdReason"><?php foreach ($reasons as $x): ?><option><?php echo h($x); ?></option><?php endforeach; ?></select></div>
            </div>
            <div class="row2" style="grid-template-columns:1fr">
                <div><label>Note (kept with the reason)</label><input type="text" name="reason_text" id="fdText" maxlength="150" placeholder="e.g. BPL card no. …"></div>
            </div>
            <div class="calc"><div><small>Session fees</small><b id="fdSub">₹0.00</b></div><div><small>Discount</small><b id="fdOff">₹0.00</b></div><div class="net"><small>Student pays</small><b id="fdNet">₹0.00</b></div></div>
            <div class="fd-hint" id="fdRule"></div>
            <div class="warn" id="fdInv"></div>
            <label class="chk"><input type="checkbox" name="is_active" id="fdActive" checked> Active — take it off the fees collected from now on</label>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('fdModal').classList.remove('open')">Cancel</button>
            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save discount</button>
        </div>
    </form>
</div>
<form method="post" id="copyForm" hidden><?php echo csrf_field(); ?><input type="hidden" name="copy_from" value="<?php echo (int)($prev_session['id'] ?? 0); ?>"><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"></form>
<script>
var SESSION = <?php echo (int)$session_id; ?>, REASONS = <?php echo json_encode($reasons); ?>;
function money(v) { return '₹' + Number(v || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
document.getElementById('fClass').addEventListener('change', function () {
    var sel = document.getElementById('fSection'); sel.innerHTML = '<option value="0">All sections</option>';
    if (!this.value || this.value === '0') return;
    fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + SESSION + '&no_placeholder=1').then(function (r) { return r.text(); }).then(function (html) { sel.innerHTML += html; });
});
// search box
(function () {
    var input = document.getElementById('fdSearch'), res = document.getElementById('fdRes'), timer = null, ctrl = null; window.fdFound = {};
    input.addEventListener('input', function () {
        clearTimeout(timer); var q = this.value.trim(); if (q.length < 2) { res.classList.remove('open'); return; }
        timer = setTimeout(function () {
            if (ctrl) ctrl.abort(); ctrl = new AbortController();
            fetch('student_discounts.php?ajax=search&session_id=' + SESSION + '&q=' + encodeURIComponent(q), { signal: ctrl.signal }).then(function (r) { return r.json(); }).then(function (d) {
                window.fdFound = {};
                if (!d.results.length) { res.innerHTML = '<div class="fd-item"><span class="none"><i class="fas fa-search"></i> No Active student of this session matches "' + esc(q) + '".</span></div>'; res.classList.add('open'); return; }
                res.innerHTML = d.results.map(function (s) {
                    window.fdFound[s.id] = s;
                    return '<div class="fd-item">' + (s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="noimg"></span>') +
                        '<div class="who"><b>' + esc(s.name) + '</b> <span class="lc-uid">' + esc(s.id) + '</span><small>' + esc(s.where) + (s.father ? ' · Father: ' + esc(s.father) : '') + ' · fees ' + money(s.subtotal) + '</small></div>' +
                        (s.discount ? '<span class="has"><i class="fas fa-percent"></i> ' + (s.discount.type === 'percentage' ? s.discount.value + '%' : money(s.discount.value)) + (s.discount.active ? '' : ' (inactive)') + '</span>' : '') +
                        '<button type="button" class="btn ' + (s.discount ? 'btn-warning' : 'btn-success') + ' btn-sm" onclick="fdOpen(window.fdFound[' + JSON.stringify(s.id) + '])"><i class="fas ' + (s.discount ? 'fa-edit' : 'fa-plus') + '"></i> ' + (s.discount ? 'Edit' : 'Give discount') + '</button></div>';
                }).join(''); res.classList.add('open');
            }).catch(function () {});
        }, 250);
    });
})();
// dialog
var fdSub = 0, fdBase = 0;
function fdCalc() {
    var t = document.getElementById('fdType').value, v = parseFloat(document.getElementById('fdValue').value) || 0;
    var off = t === 'percentage' ? fdBase * Math.min(100, Math.max(0, v)) / 100 : Math.min(fdBase, Math.max(0, v));
    document.getElementById('fdSub').textContent = money(fdSub); document.getElementById('fdOff').textContent = money(off); document.getElementById('fdNet').textContent = money(Math.max(0, fdSub - off));
    document.getElementById('fdValue').max = t === 'percentage' ? 100 : (fdBase || '');
    document.getElementById('fdRule').innerHTML = '<i class="fas fa-info-circle"></i> ' + (fdBase < fdSub ? money(fdBase) + ' of the fees takes a discount. ' : '') +
        (t === 'percentage' ? 'A percentage comes off each fee that takes a discount.' : 'A fixed amount comes off once in the session, from the fees collected first.');
}
document.getElementById('fdType').addEventListener('change', fdCalc); document.getElementById('fdValue').addEventListener('input', fdCalc);
function fdOpen(s) {
    if (!s) return;
    fdSub = s.subtotal || 0; fdBase = s.base || 0;
    document.getElementById('fdUid').value = s.id; document.getElementById('fdName').textContent = s.name; document.getElementById('fdUidBadge').textContent = s.id;
    document.getElementById('fdWhere').textContent = s.where + (s.father ? ' · Father: ' + s.father : '');
    document.getElementById('fdPhoto').innerHTML = s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="noimg"></span>';
    document.getElementById('fdTitle').innerHTML = '<i class="fas fa-percent"></i> ' + (s.discount ? 'Edit discount' : 'Give a discount');
    var d = s.discount || { type: 'percentage', value: '', reason: '', active: 1 };
    document.getElementById('fdType').value = d.type; document.getElementById('fdValue').value = d.value; document.getElementById('fdActive').checked = !!d.active;
    var sel = document.getElementById('fdReason'), txt = document.getElementById('fdText'), r = d.reason || '', base = r, note = '';
    var i = r.indexOf(' — '); if (i > 0) { base = r.slice(0, i); note = r.slice(i + 3); }
    if (REASONS.indexOf(base) >= 0) { sel.value = base; txt.value = note; } else { sel.value = 'Other'; txt.value = r; }
    var w = document.getElementById('fdInv');
    w.innerHTML = s.invoice ? '<i class="fas fa-file-invoice"></i> Fees collected so far (' + money(s.invoice.total) + ' billed, ' + money(s.invoice.paid) + ' paid) keep their figures; this discount comes off the fees collected from now on.' + (s.invoice.paid < s.invoice.total ? ' A bill not paid yet can be cancelled in Bills and the fee collected again.' : '') : '';
    w.classList.toggle('on', !!s.invoice);
    fdCalc(); document.getElementById('fdFind').classList.remove('open'); document.getElementById('fdModal').classList.add('open'); document.getElementById('fdValue').focus();
}
document.getElementById('fdModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
document.getElementById('fdFind').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
function copyPrev() { if (confirm('Copy every ACTIVE discount of the previous session to students who are enrolled this session and have no discount yet?')) document.getElementById('copyForm').submit(); }
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

/**
 * Shows one locked student document (Aadhaar card / birth certificate) to a logged-in admin.
 *   GET uid=ULPHS-YYYY-NNNN&type=birth|aadhaar   (&dl=1 to download instead of view)
 * The files sit in uploads/students/docs/, which Apache refuses to serve, so this is the
 * only way in. Nothing here is cached by the browser or a proxy.
 */
$uid  = student_uid_clean($_GET['uid'] ?? '');
$type = (string)($_GET['type'] ?? '');
$kinds = student_doc_kinds();
if ($uid === '' || !isset($kinds[$type])) { http_response_code(400); exit('Bad request.'); }

$col = $kinds[$type]['col'];
$row = db_get_row('SELECT `' . $col . '` AS f FROM students WHERE id = ?', 's', $uid);
$name = basename((string)($row['f'] ?? ''));
$path = $name !== '' ? student_docs_dir() . $name : '';
if ($path === '' || !is_file($path)) { http_response_code(404); exit('No document on file.'); }

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], true)) $mime = 'application/octet-stream';
$ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'application/pdf' => 'pdf'][$mime] ?? 'bin';

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . (!empty($_GET['dl']) ? 'attachment' : 'inline') . '; filename="' . $uid . '-' . $type . '.' . $ext . '"');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex');
readfile($path);
exit();

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';

/**
 * One student × one exam: every subject on one form (written / project / absent), grace shown read-only.
 * Linked from the tabulation sheet. Each subject is saved through marks_save_rows() so the same bounds apply.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$uid = student_uid_clean((string)($_GET['uid'] ?? $_POST['uid'] ?? ''));
$exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
$student = null; $class_id = 0;
if ($uid !== '' && $exam) {
    $student = db_get_row('SELECT s.id, s.student_name, g.father_name, sah.class_id, sah.section_id, sah.roll_no, sec.section_name, stl.subject_id AS tl
        FROM students s JOIN student_academic_history sah ON sah.student_id = s.id AND sah.session_id = ? AND sah.academic_status = "Current"
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id LEFT JOIN sections sec ON sec.id = sah.section_id LEFT JOIN student_third_language stl ON stl.student_id = s.id
        WHERE s.id = ? AND s.student_status = "Active"', 'is', (int)$exam['session_id'], $uid);
    if ($student) { $class_id = (int)$student['class_id']; if (!exam_class_group($class_id)) $student = null; }
}
$section = exam_section_clean($_GET['section'] ?? '', $class_id);   // came from one section's tabulation sheet
$back = $student ? "tabulation_sheet.php?exam_id=$exam_id&class_id=$class_id&section=$section&section_id=" . (int)$student['section_id'] : 'tabulation_sheet.php';
$errors = []; $posted = [];
if ($student && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    verify_csrf_or_die();
    $posted = (array)($_POST['m'] ?? []); $saved = 0;
    foreach ($posted as $sid => $v) {
        $r = marks_save_rows((int)$exam['session_id'], $exam_id, $class_id, (int)$sid, [$uid => $v], $admin_id);
        if ($r['ok']) $saved += $r['saved'] + $r['cleared']; else $errors[(int)$sid] = $r['errors'][$uid] ?? ($r['errors']['_'] ?? 'error');
    }
    if (!$errors) { $_SESSION['success'] = $student['student_name'] . ': ' . $saved . ' subject' . ($saved === 1 ? '' : 's') . ' saved.'; header("Location: student_marks_edit.php?uid=" . urlencode($uid) . "&exam_id=$exam_id"); exit; }
}
$res = $student ? result_exam((int)$exam['session_id'], $class_id, $exam_id, (int)$student['section_id']) : null;
$row = $res['students'][$uid] ?? null;
$subjects = $res['subjects'] ?? [];
$has_project = $class_id && exam_class_has_project($class_id);
$v = function (int $sid, string $k) use ($posted, $row) {
    if ($posted) return (string)($posted[$sid][$k] ?? '');
    $s = $row['subjects'][$sid] ?? null; if (!$s || $s['missing']) return '';
    if ($k === 'absent') return $s['absent'] ? '1' : ''; if ($s['absent']) return '';
    return exam_fmt($s[$k]);
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Student Marks</title>
<?php exam_styles(); ?>
<style>
    .who { display: flex; gap: 18px; flex-wrap: wrap; font-size: 13px; color: #3b5168; margin-bottom: 10px; } .who b { color: #222; }
    .ex-table td.err { background: #fff2f2; } .ex-table .em { display: block; color: #b71c1c; font-size: 11px; }
    .ex-table tr.ab input.m { background: #f2f2f2; color: #999; } .ex-table td.st { font-weight: 700; font-size: 11.5px; } .ex-table td.st.p { color: #1b7a3a; } .ex-table td.st.f { color: #b71c1c; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 12px; } .sum span { padding: 6px 12px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 13px; } .sum b { display: block; font-size: 15px; }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php exam_banner('Edit Student Marks', 'All subjects of one student in one exam. Same limits as marks entry; grace marks are changed on the Grace page.', 'fa-user-edit', [$back => '<i class="fas fa-arrow-left"></i> Back to tabulation']); ?>
    <?php exam_tabs('tabulation_sheet.php', EXAM_PAGES, "section=$section"); ?>
    <?php exam_flash(); ?>
    <?php if ($errors): $other = array_diff_key($errors, $subjects); ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Not saved — see the subjects marked in red.<?php foreach ($other as $sid => $m) echo ' Subject #' . (int)$sid . ': ' . h($m) . '.'; ?></div><?php endif; ?>

    <?php if (!$student): ?><div class="card"><div class="ex-empty"><i class="fas fa-user-slash"></i><?php echo !$exam ? 'Exam not found.' : ($uid === '' ? 'No student given.' : 'Student ' . h($uid) . ' is not a current student of a V–X class in ' . h($exam['session_name']) . '.'); ?> Open a student from the <a href="tabulation_sheet.php">tabulation sheet</a>.</div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-user-edit"></i> <?php echo h($student['student_name']); ?> <small><?php echo h($uid); ?></small></h2>
        <div class="who"><span>Class <b><?php echo h(exam_class_name($class_id)); ?>-<?php echo h($student['section_name']); ?></b></span><span>Roll <b><?php echo h($student['roll_no']); ?></b></span><span>Father <b><?php echo h($student['father_name']); ?></b></span><span>Exam <b><?php echo h($exam['exam_name']); ?></b> (<?php echo h($exam['session_name']); ?>)</span></div>
        <?php if (!$subjects): ?><div class="ex-empty"><i class="fas fa-sliders-h"></i>No full marks set for this class in this exam.</div>
        <?php else: ?>
        <form method="post" autocomplete="off"><?php echo csrf_field(); ?><input type="hidden" name="uid" value="<?php echo h($uid); ?>"><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
        <table class="ex-table"><thead><tr><th>Subject</th><th class="num">Written</th><?php if ($has_project): ?><th class="num">Project</th><?php endif; ?><th class="num">Absent</th><th class="num">Grace</th><th class="num">Total</th><th class="num">Pass</th><th class="num">Result</th></tr></thead><tbody>
        <?php foreach ($subjects as $sid => $s): if (!isset($row['subjects'][$sid])) continue; $r = $row['subjects'][$sid]; $ab = $v($sid, 'absent') === '1'; $e = $errors[$sid] ?? null; ?>
        <tr class="<?php echo $ab ? 'ab' : ''; ?>" data-pass="<?php echo $s['pass']; ?>" data-grace="<?php echo $r['grace']; ?>">
            <td><b><?php echo h($s['name']); ?></b><?php if ($s['tl']): ?> <span class="chip off">3rd lang</span><?php endif; ?></td>
            <td class="num <?php echo $e ? 'err' : ''; ?>"><input class="m w" name="m[<?php echo $sid; ?>][written]" value="<?php echo h($v($sid, 'written')); ?>" data-max="<?php echo $s['written_full']; ?>" inputmode="decimal" <?php echo $ab ? 'disabled' : ''; ?>> <small>/<?php echo exam_fmt($s['written_full']); ?></small><?php if ($e): ?><span class="em"><?php echo h($e); ?></span><?php endif; ?></td>
            <?php if ($has_project): ?><td class="num"><input class="m p" name="m[<?php echo $sid; ?>][project]" value="<?php echo h($v($sid, 'project')); ?>" data-max="<?php echo $s['project_full']; ?>" inputmode="decimal" <?php echo $ab || $s['project_full'] <= 0 ? 'disabled' : ''; ?>> <small>/<?php echo exam_fmt($s['project_full']); ?></small></td><?php endif; ?>
            <td class="num"><input type="checkbox" class="abx" name="m[<?php echo $sid; ?>][absent]" value="1" <?php echo $ab ? 'checked' : ''; ?>></td>
            <td class="num" style="color:#6b7d90"><?php echo $r['grace'] > 0 ? exam_fmt($r['grace']) . '†' : '—'; ?></td>
            <td class="num tot"></td><td class="num"><?php echo exam_fmt($s['pass']); ?></td><td class="num st"></td>
        </tr>
        <?php endforeach; ?></tbody></table>
        <div class="sum"><span>Total<b><?php echo exam_fmt($row['total']); ?> / <?php echo exam_fmt($row['full']); ?></b></span><span>Percentage<b><?php echo exam_fmt($row['pct']); ?>%</b></span><span>Grade<b><?php echo h($row['grade']); ?></b></span><span>Result<b><?php echo result_badge($row['status']); ?></b></span><span>Rank in section<b><?php echo $row['rank'] ?? '—'; ?></b></span></div>
        <div style="margin-top:12px;display:flex;gap:8px"><button type="submit" name="save" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save</button><a href="<?php echo h($back); ?>" class="btn btn-secondary">Cancel</a></div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
document.querySelectorAll('tr[data-pass]').forEach(function (tr) {
    var w = tr.querySelector('input.w'), p = tr.querySelector('input.p'), ab = tr.querySelector('.abx'), tot = tr.querySelector('.tot'), st = tr.querySelector('.st');
    function f() {
        var a = ab.checked; tr.classList.toggle('ab', a); w.disabled = a; if (p && parseFloat(p.dataset.max) > 0) p.disabled = a;
        [w, p].forEach(function (i) { if (!i) return; var v = i.value.trim(); i.classList.toggle('bad', v !== '' && (!/^\d{1,3}(\.\d{1,2})?$/.test(v) || parseFloat(v) > parseFloat(i.dataset.max))); });
        st.className = 'num st';
        if (a) { tot.textContent = 'AB'; st.textContent = 'Absent'; return; }
        if (w.value.trim() === '' && (!p || p.value.trim() === '')) { tot.textContent = ''; st.textContent = ''; return; }
        var t = (parseFloat(w.value) || 0) + (p ? (parseFloat(p.value) || 0) : 0) + parseFloat(tr.dataset.grace); tot.textContent = Math.round(t * 100) / 100 + (parseFloat(tr.dataset.grace) > 0 ? '†' : '');
        var ok = t >= parseFloat(tr.dataset.pass); st.textContent = ok ? 'Pass' : 'Fail'; st.classList.add(ok ? 'p' : 'f');
    }
    f(); tr.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', f); i.addEventListener('change', f); });
});
</script>
</body>
</html>

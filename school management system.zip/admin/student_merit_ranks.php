<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/result_helper.php';
require_once '../includes/hs_result_helper.php';
require_once '../includes/promotion_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Merit list of a class for the year (student_merit_ranks) — the input of promotion.
 * Preview = the year result live (result_annual() for V–X, hs_result_year() for XI with section=hs);
 * Generate stores it (whole class, all sections, rank across the class).
 * Once a promotion batch exists for the class the stored list is locked.
 */
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$sessions = exam_sessions();
$session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? exam_active_session_id()); if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
// Primary & Upper Primary, Secondary, or 'hs' — Class XI, whose year is Semester 1 + 2 (XII is examined by the board)
$hs = ($_GET['section'] ?? '') === 'hs' || (($_GET['section'] ?? '') === '' && hs_is_hs_class((int)($_GET['class_id'] ?? 0)));
$section = $hs ? 'hs' : exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));
$classes = $hs ? hs_exam_classes() : exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$year_result = fn() => $hs ? hs_result_year($session_id, $class_id) : result_annual($session_id, $class_id);
$print = !empty($_GET['print']); $xlsx = !empty($_GET['xlsx']);
$ready = $class_id > 0;
$qs = "session_id=$session_id&class_id=$class_id&section=$section";
$locked = $ready && promotion_batch_exists($conn, $session_id, $class_id);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $ready) {
    verify_csrf_or_die();
    if ($locked) $_SESSION['error'] = 'Promotion has already been run from this class — the merit list is locked.';
    elseif (isset($_POST['generate'])) {
        $res = $year_result();
        if (!$res['exams'] || !$res['subjects']) $_SESSION['error'] = 'Nothing to rank — no counting exam with full marks for this class.';
        else {
            db_begin_transaction();
            try {
                db_execute('DELETE FROM student_merit_ranks WHERE academic_session_id = ? AND class_id = ?', 'ii', $session_id, $class_id);
                $n = 0; $absent = count(array_filter($res['students'], fn($s) => $s['status'] === 'ABSENT'));
                $last_rank = max(array_filter(array_column($res['students'], 'rank')) ?: [0]);
                foreach ($res['students'] as $uid => $st) {
                    $remarks = $st['failed_n'] ? $st['failed_n'] . ' subject' . ($st['failed_n'] === 1 ? '' : 's') . ' below pass marks' : null;
                    db_execute('INSERT INTO student_merit_ranks (academic_session_id, class_id, student_id, gender, final_total, percentage, merit_rank, result_status, remarks, created_by) VALUES (?,?,?,?,?,?,?,?,?,?)',
                        'iissddissi', $session_id, $class_id, $uid, in_array($st['gender'], ['Male', 'Female', 'Other'], true) ? $st['gender'] : null, $st['total'], $st['pct'], $st['rank'] ?? $last_rank + 1, $st['status'], $remarks, $admin_id);
                    $n++;
                }
                db_commit();
                log_action($admin_id, 'MERIT_LIST_GENERATED', 'student_merit_ranks', $class_id, null, ['session_id' => $session_id, 'students' => $n, 'absent' => $absent]);
                $_SESSION['success'] = 'Merit list generated for Class ' . $classes[$class_id]['name'] . ' — ' . $n . ' students' . ($res['warnings'] ? '. Note: ' . implode('; ', $res['warnings']) : '.');
            } catch (Throwable $e) { db_rollback(); error_log('merit generate: ' . $e->getMessage()); $_SESSION['error'] = 'Generate failed.'; }
        }
    } elseif (isset($_POST['delete'])) {
        $n = (int)db_execute('DELETE FROM student_merit_ranks WHERE academic_session_id = ? AND class_id = ?', 'ii', $session_id, $class_id);
        log_action($admin_id, 'MERIT_LIST_DELETED', 'student_merit_ranks', $class_id, ['session_id' => $session_id, 'rows' => $n], null);
        $_SESSION['success'] = 'Stored merit list of Class ' . $classes[$class_id]['name'] . ' deleted (' . $n . ' rows).';
    }
    header("Location: student_merit_ranks.php?$qs"); exit;
}

$stored = $ready ? db_get_all('SELECT r.*, s.student_name, g.father_name, sec.section_name, sah.roll_no, a.username AS by_name
    FROM student_merit_ranks r JOIN students s ON s.id = r.student_id LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN student_academic_history sah ON sah.student_id = s.id AND sah.session_id = r.academic_session_id AND sah.class_id = r.class_id
    LEFT JOIN sections sec ON sec.id = sah.section_id LEFT JOIN admins a ON a.id = r.created_by
    WHERE r.academic_session_id = ? AND r.class_id = ? ORDER BY r.merit_rank, s.student_name', 'ii', $session_id, $class_id) : [];
$preview = ($ready && !$stored && !$xlsx) ? $year_result() : null;
$plist = [];
if ($preview) { $plist = $preview['students']; uasort($plist, fn($a, $b) => (($a['rank'] ?? PHP_INT_MAX) <=> ($b['rank'] ?? PHP_INT_MAX)) ?: strcmp($a['name'], $b['name'])); }
$title = $ready ? 'Class ' . $classes[$class_id]['name'] : '';
$counts = []; foreach (['PASS', 'PUC', 'FAIL', 'ABSENT'] as $s) $counts[$s] = count(array_filter($stored ?: $plist, fn($x) => ($x['result_status'] ?? $x['status']) === $s));

if ($ready && $xlsx && $stored) {
    $head = ['Rank', 'Sec', 'Roll', 'School UID', 'Student', 'Father', 'Gender', "Total\nmarks", '%', 'Result', 'Remarks'];
    $rows = array_merge(exam_xlsx_title('Merit List — ' . $title, 'Session ' . exam_session_name($session_id)), [$head]);
    foreach ($stored as $r) $rows[] = [(int)$r['merit_rank'], $r['section_name'], $r['roll_no'], $r['student_id'], $r['student_name'], $r['father_name'], $r['gender'], exam_fmt($r['final_total']), exam_fmt($r['percentage']), $r['result_status'], $r['remarks']];
    SimpleXLSXWriter::download('merit_list_' . preg_replace('/[^A-Za-z0-9]+/', '_', $title) . '.xlsx', $rows, 'Merit', exam_xlsx_opts(count($head), 24));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Merit List</title>
<?php exam_styles(); ?>
<style>
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; align-items: center; } .sum span { padding: 5px 11px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 12.5px; } .sum b { margin-left: 4px; }
    .ex-table td.rk { font-weight: 800; color: #3b1d5c; font-size: 14px; } .ex-table tr.top td { background: #fffbe6; }
    .acts { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin-top: 12px; } .acts form { display: inline; }
    <?php if ($print): ?> body { background: #fff; } .ex-table { font-size: 11.5px; } .ex-table td, .ex-table th { padding: 3px 6px; border: 1px solid #bbb; } @page { size: A4 portrait; margin: 10mm; } <?php endif; ?>
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if ($print): ?>
        <?php exam_school_header('Merit List — ' . $title, 'Session ' . exam_session_name($session_id)); ?>
        <div class="noprint" style="margin-bottom:8px"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button> <a href="student_merit_ranks.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php else: ?>
        <?php exam_banner('Merit List', 'Rank of the whole class for the year, stored for promotion. Preview first; Generate stores it — regenerate any time until promotion is run.', 'fa-trophy', $stored ? ["student_merit_ranks.php?$qs&print=1" => '<i class="fas fa-print"></i> Print', "student_merit_ranks.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel', 'promotion.php?' . http_build_query(['from_session_id' => $session_id, 'from_class_id' => $class_id]) => '<i class="fas fa-level-up-alt"></i> Promotion'] : []); ?>
        <?php $hs ? hs_tabs('student_merit_ranks.php?section=hs') : exam_tabs('student_merit_ranks.php', EXAM_PAGES, "section=$section"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
            <div><label>Session</label><select name="session_id" onchange="this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        </form>
    <?php endif; ?>

    <?php if (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-trophy"></i>Select a class.</div></div>
    <?php elseif ($stored): ?>
    <div class="card">
        <?php if (!$print): ?><h2><i class="fas fa-trophy"></i> Stored merit list · <?php echo h($title); ?> <small>generated <?php echo date('d M Y, g:i a', strtotime($stored[0]['created_at'])); ?><?php echo $stored[0]['by_name'] ? ' by ' . h($stored[0]['by_name']) : ''; ?><?php echo $locked ? ' · <span class="chip warn"><i class="fas fa-lock"></i> locked — promotion done</span>' : ''; ?></small></h2><?php endif; ?>
        <div class="sum"><span>Students<b><?php echo count($stored); ?></b></span><span>Pass<b><?php echo $counts['PASS']; ?></b></span><span>PUC<b><?php echo $counts['PUC']; ?></b></span><span>Fail<b><?php echo $counts['FAIL']; ?></b></span><span>Absent<b><?php echo $counts['ABSENT']; ?></b></span></div>
        <table class="ex-table"><thead><tr><th class="num">Rank</th><th>Sec</th><th class="num">Roll</th><th>Student</th><th>Father</th><th>Gender</th><th class="num">Total</th><th class="num">%</th><th class="num">Result</th><th>Remarks</th></tr></thead><tbody>
        <?php foreach ($stored as $r): ?><tr class="<?php echo (int)$r['merit_rank'] <= 3 && $r['result_status'] !== 'ABSENT' ? 'top' : ''; ?>"><td class="num rk"><?php echo $r['result_status'] === 'ABSENT' ? '—' : (int)$r['merit_rank']; ?></td><td><?php echo h($r['section_name']); ?></td><td class="num"><?php echo h($r['roll_no']); ?></td><td><b><?php echo h($r['student_name']); ?></b><?php if (!$print): ?><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($r['student_id']); ?></small><?php endif; ?></td><td style="color:#4d6178"><?php echo h($r['father_name']); ?></td><td><?php echo h($r['gender']); ?></td><td class="num"><?php echo exam_fmt($r['final_total']); ?></td><td class="num"><?php echo exam_fmt($r['percentage']); ?></td><td class="num"><?php echo $print ? h($r['result_status']) : result_badge($r['result_status']); ?></td><td style="font-size:11.5px;color:#6b7d90"><?php echo h($r['remarks']); ?></td></tr><?php endforeach; ?>
        </tbody></table>
        <?php if (!$print && !$locked): ?><div class="acts noprint">
            <form method="post" onsubmit="return confirm('Regenerate the merit list from the current marks? The stored list is replaced.');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><button type="submit" name="generate" value="1" class="btn btn-primary"><i class="fas fa-sync-alt"></i> Regenerate from current marks</button></form>
            <form method="post" onsubmit="return confirm('Delete the stored merit list of this class?');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><button type="submit" name="delete" value="1" class="btn btn-danger"><i class="fas fa-trash"></i> Delete stored list</button></form>
            <a href="<?php echo $hs ? 'hs_tabulation.php' : 'annual_result.php'; ?>?session_id=<?php echo $session_id; ?>&class_id=<?php echo $class_id; ?>&sort=merit" class="btn btn-secondary"><i class="fas fa-award"></i> <?php echo $hs ? 'HS Tabulation' : 'Annual result'; ?></a></div><?php endif; ?>
    </div>
    <?php elseif (!$preview['exams'] || !$preview['subjects']): ?><div class="card"><div class="ex-empty"><i class="fas fa-clipboard-list"></i>No <?php echo $hs ? 'semester exam' : 'counting exam'; ?> with full marks for Class <?php echo h($classes[$class_id]['name']); ?> yet.</div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas fa-eye"></i> Preview · <?php echo h($title); ?> <small>from the current marks — not stored yet</small></h2>
        <?php foreach ($preview['warnings'] as $w): ?><div class="alert alert-warning" style="font-size:12.5px;padding:6px 10px"><i class="fas fa-exclamation-triangle"></i> <?php echo h($w); ?></div><?php endforeach; ?>
        <div class="sum"><span>Students<b><?php echo count($plist); ?></b></span><span>Pass<b><?php echo $counts['PASS']; ?></b></span><span>PUC<b><?php echo $counts['PUC']; ?></b></span><span>Fail<b><?php echo $counts['FAIL']; ?></b></span><span>Absent<b><?php echo $counts['ABSENT']; ?></b></span>
            <form method="post" style="margin-left:auto" onsubmit="return confirm('Store this merit list for Class <?php echo h($classes[$class_id]['name']); ?>?');"><?php echo csrf_field(); ?><input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><button type="submit" name="generate" value="1" class="btn btn-primary" <?php echo $locked ? 'disabled' : ''; ?>><i class="fas fa-save"></i> Generate & store</button></form></div>
        <table class="ex-table"><thead><tr><th class="num">Rank</th><th>Sec</th><th class="num">Roll</th><th>Student</th><th>Father</th><th class="num">Total</th><th class="num">%</th><th class="num">Grade</th><th class="num">Result</th><th class="num">Failed</th></tr></thead><tbody>
        <?php foreach ($plist as $uid => $st): ?><tr class="<?php echo ($st['rank'] ?? 99) <= 3 ? 'top' : ''; ?>"><td class="num rk"><?php echo $st['rank'] ?? '—'; ?></td><td><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['roll']); ?></td><td><b><?php echo h($st['name']); ?></b></td><td style="color:#4d6178"><?php echo h($st['father']); ?></td><td class="num"><?php echo exam_fmt($st['total']); ?> <small style="color:#888">/<?php echo exam_fmt($st['full']); ?></small></td><td class="num"><?php echo exam_fmt($st['pct']); ?></td><td class="num"><?php echo h($st['grade']); ?></td><td class="num"><?php echo result_badge($st['status']); ?></td><td class="num"><?php echo $st['failed_n'] ?: ''; ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once "../includes/photo_helper.php";
include("../includes/document_helper.php");
include("../includes/logger.php");

/**
 * One student file, uploaded by AJAX from the bulk grid / photo booth.
 * POST multipart: csrf_token, uid, kind = photo | signature | birth_certificate | student_aadhaar_image, file
 * Locked documents (birth certificate, Aadhaar) are stored in uploads/students/docs/ and the
 * returned url goes through student_doc.php, never to the file itself.
 * Response JSON: { ok, url, size, kind } or { ok:false, error }
 * The photo is re-processed on the server regardless of what the browser sent
 * (upright, ≤ 320 px, ≤ 10 KB JPEG).
 */
header('Content-Type: application/json; charset=utf-8');
function out(array $o, int $code = 200) { http_response_code($code); echo json_encode($o, JSON_UNESCAPED_UNICODE); exit(); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok' => false, 'error' => 'POST only.'], 405);
if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) out(['ok' => false, 'error' => 'Invalid request token — reload the page.'], 403);

$uid  = student_uid_clean($_POST['uid'] ?? '');
$kind = $_POST['kind'] ?? 'photo';
$kinds = [
    'photo'             => ['col' => 'photo',             'dir' => '../uploads/students/',              'max' => 8 * 1024 * 1024],
    'signature'         => ['col' => 'signature',         'dir' => '../uploads/students/signatures/',   'max' => 10 * 1024 * 1024],
    'birth_certificate'     => ['col' => 'birth_certificate',     'dir' => student_docs_dir(), 'max' => 10 * 1024 * 1024, 'doc' => 'birth'],
    'student_aadhaar_image' => ['col' => 'student_aadhaar_image', 'dir' => student_docs_dir(), 'max' => 10 * 1024 * 1024, 'doc' => 'aadhaar'],
];
if (!isset($kinds[$kind])) out(['ok' => false, 'error' => 'Unknown file kind.'], 400);
$k = $kinds[$kind];
$student = $uid !== '' ? db_get_row('SELECT id, student_name, student_status, `' . $k['col'] . '` AS cur FROM students WHERE id = ?', 's', $uid) : null;
if (!$student) out(['ok' => false, 'error' => 'Student not found.'], 404);
if ($student['student_status'] !== 'Active') out(['ok' => false, 'error' => "Student is {$student['student_status']} — only Active students can be updated."], 400);

$file = $_FILES['file'] ?? null;
if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) out(['ok' => false, 'error' => 'No file received.'], 400);
if ($file['error'] !== UPLOAD_ERR_OK) out(['ok' => false, 'error' => 'Upload failed (code ' . $file['error'] . ').'], 400);
if ($file['size'] > $k['max']) out(['ok' => false, 'error' => 'File too large.'], 400);
if (!is_uploaded_file($file['tmp_name']) || @getimagesize($file['tmp_name']) === false) out(['ok' => false, 'error' => 'The file is not an image.'], 400);

$r = $kind === 'photo'
    ? process_student_photo($file, $k['dir'], 10240, 320)
    : (isset($k['doc']) ? student_doc_store_upload($file, $k['doc']) : process_student_document($file, $k['dir'], 10, 'sig'));
if (!$r['ok'] || !$r['filename']) out(['ok' => false, 'error' => $r['error'] ?: 'Could not process the file.'], 422);

try {
    db_execute('UPDATE students SET `' . $k['col'] . '` = ? WHERE id = ?', 'ss', $r['filename'], $uid);
} catch (Throwable $e) {
    app_unlink_upload($k['dir'], $r['filename']);
    out(['ok' => false, 'error' => 'Could not save (' . $e->getMessage() . ')'], 500);
}
if (!empty($student['cur'])) app_unlink_upload($k['dir'], $student['cur']);   // the replaced file goes only after the row is updated

$path = rtrim($k['dir'], '/') . '/' . $r['filename'];
$size = @filesize($path) ?: null;
$url  = isset($k['doc']) ? student_doc_url($uid, $k['doc']) . '&v=' . time() : $path;
log_student_edit((int)($_SESSION['admin_id'] ?? 0), $uid, null, json_encode([$k['col'] => ['from' => $student['cur'], 'to' => $r['filename']]]));
out(['ok' => true, 'kind' => $kind, 'url' => $url, 'name' => $r['filename'], 'size' => $size, 'uid' => $uid]);

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/stats_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

$f = stats_filter($_GET);
$view = (string)($_GET['view'] ?? 'overview');
if (!isset(STATS_VIEWS[$view])) $view = 'overview';
$export = !empty($_GET['export']);
$classes = stats_classes($f);
$where = 'Session ' . $f['session_name']
    . ($f['class_id'] ? ' · Class ' . ($classes[$f['class_id']] ?? '') : '')
    . ($f['section_id'] ? ' · ' . $f['sections'][$f['section_id']] : '')
    . ($f['gender'] ? ' · ' . $f['gender'] : '')
    . ' · ' . STATS_SCOPES[$f['scope']];

$link = function (array $extra = []) use ($f, $view) {
    return 'student_statistics.php?' . http_build_query(array_merge([
        'view' => $view, 'session_id' => $f['session_id'], 'class_id' => $f['class_id'],
        'section_id' => $f['section_id'], 'gender' => $f['gender'], 'scope' => $f['scope'],
    ], $extra));
};
$xlsx = function (string $subtitle, array $head, array $rows, string $file) use ($where) {
    $out = exam_xlsx_title($subtitle, $where);
    $out[] = $head;
    foreach ($rows as $r) $out[] = $r;
    SimpleXLSXWriter::download($file, $out, 'Statistics', exam_xlsx_opts(count($head), 24));
};
$safe = fn(string $s) => preg_replace('/[^A-Za-z0-9_-]/', '_', $s);

$gender_cols = ['Male' => 'Boys', 'Female' => 'Girls', 'Other' => 'Other'];

if ($view === 'overview') {
    $overview = stats_overview($f);
    $cats = stats_live_categories($overview);
    $genders = array_filter($gender_cols, fn($lbl, $g) => $g !== 'Other' || $overview['total']['Other'] > 0, ARRAY_FILTER_USE_BOTH);
    if ($export) {
        $head = array_merge(['Class'], array_values($genders), ['Total']);
        foreach ($cats as $c) foreach ($genders as $lbl) $head[] = "$c $lbl";
        $rows = [];
        foreach ($overview as $key => $r) {
            $line = [$key === 'total' ? 'All classes' : 'Class ' . $r['name']];
            foreach ($genders as $g => $lbl) $line[] = $r[$g];
            $line[] = $r['total'];
            foreach ($cats as $c) foreach ($genders as $g => $lbl) $line[] = $r[$c][$g];
            $rows[] = $line;
        }
        $xlsx('Student Statistics — overview', $head, $rows, 'Statistics_overview_' . $safe($f['session_name']) . '.xlsx');
    }
}
if ($view === 'status') {
    $status = stats_status($f);
    $left = stats_left_list($f);
    if ($export) {
        $head = ['Class'];
        foreach (STATS_LEFT as [$lbl]) { $head[] = "$lbl boys"; $head[] = "$lbl girls"; $head[] = "$lbl total"; }
        $rows = [];
        foreach ($status as $key => $r) {
            $line = [$key === 'total' ? 'All classes' : 'Class ' . $r['name']];
            foreach (STATS_LEFT as $st => $_) { $line[] = $r[$st]['Male']; $line[] = $r[$st]['Female']; $line[] = $r[$st]['total']; }
            $rows[] = $line;
        }
        $xlsx('Student Statistics — who left', $head, $rows, 'Statistics_who_left_' . $safe($f['session_name']) . '.xlsx');
    }
}
if ($view === 'social') {
    $social = stats_social($f);
    if ($export) {
        $head = array_merge(['Group'], array_map(fn($n) => "Class $n", $classes), ['Total']);
        $rows = [];
        foreach ($social as $kind => $items) {
            $rows[] = [strtoupper($kind === 'religion' ? 'Religion' : 'Caste')];
            foreach ($items as $label => $r) {
                $line = [$label];
                foreach ($classes as $cid => $n) $line[] = (int)($r[$cid] ?? 0);
                $line[] = (int)$r['total'];
                $rows[] = $line;
            }
        }
        $xlsx('Student Statistics — religion & caste', $head, $rows, 'Statistics_religion_caste_' . $safe($f['session_name']) . '.xlsx');
    }
}
if ($view === 'age') {
    $age = stats_age($f);
    $outliers = stats_age_outliers($f);
    if ($export) {
        if (($_GET['list'] ?? '') === 'outliers') {
            $xlsx('Student Statistics — age outside the class band',
                ['School UID', 'Student', 'Class', 'Section', 'Roll', 'Date of birth', 'Age on ' . $age['ref'], 'Usual age', 'Note'],
                array_map(fn($r) => [$r['id'], $r['student_name'], $r['class_name'], $r['section_name'], $r['roll_no'], $r['dob'], (int)$r['age'], $r['band'], $r['why']], $outliers),
                'Statistics_age_outside_' . $safe($f['session_name']) . '.xlsx');
        }
        $head = array_merge(['Class', 'Usual age'], array_map(fn($a) => "$a yrs", $age['ages']), ['Total']);
        $rows = [];
        foreach ($classes as $cid => $name) {
            [$lo, $hi] = stats_age_band($name);
            $line = ['Class ' . $name, $lo ? $lo . '-' . $hi : '—'];
            $sum = 0;
            foreach ($age['ages'] as $a) { $n = (int)($age['grid'][$cid][$a] ?? 0); $line[] = $n ?: ''; $sum += $n; }
            $line[] = $sum;
            $rows[] = $line;
        }
        $xlsx('Student Statistics — age on ' . $age['ref'], $head, $rows, 'Statistics_age_' . $safe($f['session_name']) . '.xlsx');
    }
}
if ($view === 'places') {
    $strength = stats_section_strength($f);
    $column = (string)($_GET['place'] ?? 'police_station');
    $places = stats_places($f, $column);
    if ($export) {
        if (($_GET['list'] ?? '') === 'sections') {
            $rows = [];
            foreach ($classes as $cid => $name) foreach (($strength[$cid] ?? []) as $sec) $rows[] = ['Class ' . $name, $sec['name'], $sec['Male'], $sec['Female'], $sec['Other'], $sec['total']];
            $xlsx('Student Statistics — section strength', ['Class', 'Section', 'Boys', 'Girls', 'Other', 'Total'], $rows,
                'Statistics_sections_' . $safe($f['session_name']) . '.xlsx');
        }
        $rows = array_map(fn($r) => [$r['p'], (int)$r['boys'], (int)$r['girls'], (int)$r['n']], $places['rows']);
        if ($places['other']) $rows[] = [$places['other']['p'], $places['other']['boys'], $places['other']['girls'], $places['other']['n']];
        $xlsx('Student Statistics — by ' . strtolower($places['label']), [$places['label'], 'Boys', 'Girls', 'Total'], $rows,
            'Statistics_' . $safe($places['label']) . '_' . $safe($f['session_name']) . '.xlsx');
    }
}
if ($view === 'data') {
    $complete = stats_completeness($f);
    $field = (string)($_GET['field'] ?? '');
    if (!isset(STATS_FIELDS[$field])) $field = '';
    $missing = $field ? stats_missing_list($f, $field) : [];
    $dupes = stats_duplicate_ids($f);
    if ($export) {
        if ($field) {
            $xlsx('Student Statistics — ' . STATS_FIELDS[$field][0] . ' not filled in',
                ['School UID', 'Student', 'Class', 'Section', 'Roll', 'Father', 'Mobile'],
                array_map(fn($r) => [$r['id'], $r['student_name'], $r['class_name'], $r['section_name'], $r['roll_no'], $r['father_name'], $r['father_mobile']], $missing),
                'Statistics_missing_' . $safe(STATS_FIELDS[$field][0]) . '.xlsx');
        }
        $head = array_merge(['What', 'Filled in', 'Missing'], array_map(fn($n) => "Class $n missing", $classes));
        $rows = [];
        foreach ($complete['fields'] as $r) {
            $line = [$r['label'], $r['have'], $r['missing']];
            foreach ($classes as $cid => $n) $line[] = (int)($r['classes'][$cid]['missing'] ?? 0);
            $rows[] = $line;
        }
        $xlsx('Student Statistics — what is missing', $head, $rows, 'Statistics_missing_' . $safe($f['session_name']) . '.xlsx');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Statistics</title>
<?php exam_styles('rpt'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(132px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb div { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; }
    .sb b { display: block; font-size: 21px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; font-variant-numeric: tabular-nums; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .seg { display: inline-flex; flex-wrap: wrap; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 10px; padding: 3px; margin-bottom: 12px; }
    .seg a { padding: 7px 13px; border-radius: 8px; font-size: 12.5px; font-weight: 600; color: var(--ex-dark); text-decoration: none; }
    .seg a.on { background: var(--ex-dark); color: #fff; }
    .seg a i { margin-right: 5px; }
    .ex-table th.g { background: var(--ex-group); }
    .ex-table tr.sum td { background: var(--ex-soft); font-weight: 700; border-top: 2px solid var(--ex-border); }
    .ex-table td.band { background: #eef7f0; }
    .ex-table td.dim { color: #b3bfcb; }
    .scroll { overflow-x: auto; }
    .print-head { display: none; }
    @media print {
        .print-head { display: block; }
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .seg, .pick, .noprint { display: none !important; }
        .ex-table { font-size: 10px; } .ex-table th, .ex-table td { padding: 2px 4px; }
        .scroll { overflow: visible !important; }   /* on paper nothing may be cut off the right edge */
        .sb { grid-template-columns: repeat(4, 1fr); } .sb b { font-size: 16px; }
        .card { page-break-inside: avoid; border: 0; padding: 0; margin-bottom: 10px; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Student Statistics', 'Every count of the school, session by session', 'fa-chart-pie',
        [$link(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php exam_tabs('student_statistics.php', STATS_PAGES); ?>

    <div class="seg">
        <?php foreach (STATS_VIEWS as $key => [$label, $icon]): ?>
        <a href="<?php echo h('student_statistics.php?' . http_build_query(['view' => $key, 'session_id' => $f['session_id'], 'class_id' => $f['class_id'], 'section_id' => $f['section_id'], 'gender' => $f['gender'], 'scope' => $f['scope']])); ?>"
           class="<?php echo $key === $view ? 'on' : ''; ?>"><i class="fas <?php echo h($icon); ?>"></i><?php echo h($label); ?></a>
        <?php endforeach; ?>
    </div>

    <form method="get" class="card pick noprint">
        <input type="hidden" name="view" value="<?php echo h($view); ?>">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php echo exam_options($f['sessions'], $f['session_id']); ?></select></div>
        <div><label>Class</label><select name="class_id" onchange="this.form.submit()"><option value="0">All classes</option><?php echo exam_options($classes, $f['class_id']); ?></select></div>
        <div><label>Section</label><select name="section_id"><option value="0">All sections</option><?php echo exam_options($f['sections'], $f['section_id']); ?></select></div>
        <div><label>Girls / boys</label><select name="gender"><option value="">Everyone</option><?php echo exam_options(['Male' => 'Boys', 'Female' => 'Girls', 'Other' => 'Other'], $f['gender']); ?></select></div>
        <div><label>Who to count</label><select name="scope"><?php echo exam_options(STATS_SCOPES, $f['scope']); ?></select></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button></div>
        <div><a href="student_statistics.php?view=<?php echo h($view); ?>" class="btn btn-secondary">Reset</a></div>
    </form>

    <div class="print-head"><?php exam_school_header('STUDENT STATISTICS — ' . strtoupper(STATS_VIEWS[$view][0]), $where); ?></div>

<?php if ($view === 'overview'): ?>
    <div class="sb">
        <div><b><?php echo number_format($overview['total']['total']); ?></b><span>Students</span></div>
        <?php foreach ($genders as $g => $lbl): ?><div><b><?php echo number_format($overview['total'][$g]); ?></b><span><?php echo h($lbl); ?></span></div><?php endforeach; ?>
        <?php foreach ($cats as $c): ?><div><b><?php echo number_format($overview['total'][$c]['total']); ?></b><span><?php echo h($c); ?></span></div><?php endforeach; ?>
    </div>
    <div class="card">
        <h2><i class="fas fa-table"></i> Class by class <small><?php echo h($where); ?></small></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead>
                <tr>
                    <th rowspan="2">#</th><th rowspan="2">Class</th>
                    <th class="num g" colspan="<?php echo count($genders) + 1; ?>">All students</th>
                    <?php foreach ($cats as $c): ?><th class="num" colspan="<?php echo count($genders); ?>"><?php echo h($c); ?></th><?php endforeach; ?>
                </tr>
                <tr>
                    <?php foreach ($genders as $lbl): ?><th class="num g"><?php echo h($lbl); ?></th><?php endforeach; ?><th class="num g">Total</th>
                    <?php foreach ($cats as $c): foreach ($genders as $lbl): ?><th class="num"><?php echo h($lbl); ?></th><?php endforeach; endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php $i = 1; foreach ($classes as $cid => $name): $r = $overview[$cid]; ?>
                <tr>
                    <td class="num"><?php echo $i++; ?></td><td><b>Class <?php echo h($name); ?></b></td>
                    <?php foreach ($genders as $g => $lbl): ?><td class="num"><?php echo $r[$g] ?: '<span class="dim">0</span>'; ?></td><?php endforeach; ?>
                    <td class="num"><b><?php echo $r['total']; ?></b></td>
                    <?php foreach ($cats as $c): foreach ($genders as $g => $lbl): ?><td class="num"><?php echo $r[$c][$g] ?: '<span class="dim">0</span>'; ?></td><?php endforeach; endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="sum">
                    <td colspan="2" style="text-align:right">All classes</td>
                    <?php foreach ($genders as $g => $lbl): ?><td class="num"><?php echo $overview['total'][$g]; ?></td><?php endforeach; ?>
                    <td class="num"><?php echo $overview['total']['total']; ?></td>
                    <?php foreach ($cats as $c): foreach ($genders as $g => $lbl): ?><td class="num"><?php echo $overview['total'][$c][$g]; ?></td><?php endforeach; endforeach; ?>
                </tr>
            </tfoot>
        </table>
        </div>
        <p class="note">Minority is read off the religion — every religion other than Hindu. OBC-A and OBC-B were merged, so both are counted as OBC. A category nobody here belongs to is left out of the table.</p>
    </div>

<?php elseif ($view === 'status'): ?>
    <div class="card">
        <h2><i class="fas fa-user-clock"></i> Who stayed and who left <small>Session <?php echo h($f['session_name']); ?></small></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead>
                <tr><th rowspan="2">Class</th><?php foreach (STATS_LEFT as [$lbl]): ?><th class="num" colspan="3"><?php echo h($lbl); ?></th><?php endforeach; ?></tr>
                <tr><?php foreach (STATS_LEFT as $st => $_): ?><th class="num">Boys</th><th class="num">Girls</th><th class="num g">All</th><?php endforeach; ?></tr>
            </thead>
            <tbody>
            <?php foreach ($classes as $cid => $name): $r = $status[$cid]; ?>
                <tr>
                    <td><b>Class <?php echo h($name); ?></b></td>
                    <?php foreach (STATS_LEFT as $st => $_): ?>
                        <td class="num"><?php echo $r[$st]['Male'] ?: '<span class="dim">0</span>'; ?></td>
                        <td class="num"><?php echo $r[$st]['Female'] ?: '<span class="dim">0</span>'; ?></td>
                        <td class="num g"><b><?php echo $r[$st]['total'] ?: '<span class="dim">0</span>'; ?></b></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="sum"><td style="text-align:right">All classes</td>
                <?php foreach (STATS_LEFT as $st => $_): ?><td class="num"><?php echo $status['total'][$st]['Male']; ?></td><td class="num"><?php echo $status['total'][$st]['Female']; ?></td><td class="num"><?php echo $status['total'][$st]['total']; ?></td><?php endforeach; ?>
                </tr>
            </tfoot>
        </table>
        </div>
        <p class="note">This view always shows everyone, whatever "who to count" says — that is the point of it. A student's history row for the session records how they left, so the numbers hold even for an old session.</p>
    </div>
    <div class="card">
        <h2><i class="fas fa-door-open"></i> The ones who left <small><?php echo count($left); ?> student(s)</small></h2>
        <?php if (!$left): ?>
            <div class="ex-empty"><i class="fas fa-check-circle"></i>Nobody left in this session — everyone is on the roll.</div>
        <?php else: ?>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>Student</th><th>Class</th><th>Roll</th><th>How</th><th>When</th><th>Why</th></tr></thead>
            <tbody>
            <?php foreach ($left as $r): [$lbl, $chip] = STATS_LEFT[$r['st']] ?? [$r['st'], 'off']; ?>
                <tr>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>"><b><?php echo h($r['student_name']); ?></b></a><br><small style="color:#6b7d90"><?php echo h($r['id']); ?></small></td>
                    <td><?php echo h(trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''))); ?></td>
                    <td class="num"><?php echo h($r['roll_no']); ?></td>
                    <td><span class="chip <?php echo h($chip); ?>"><?php echo h($lbl); ?></span><?php echo $r['tc_no'] ? '<br><small>' . h($r['tc_no']) . '</small>' : ''; ?></td>
                    <td><?php echo h($r['tc_date'] ? date('d M Y', strtotime($r['tc_date'])) : ($r['note_at'] ? date('d M Y', strtotime($r['note_at'])) : '—')); ?></td>
                    <td style="max-width:320px"><small><?php echo h($r['tc_reason'] ?: ($r['note'] ?: '—')); ?></small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>

<?php elseif ($view === 'social'): ?>
    <?php foreach (['religion' => 'Religion', 'caste' => 'Caste'] as $kind => $title): ?>
    <div class="card">
        <h2><i class="fas fa-layer-group"></i> <?php echo h($title); ?> <small><?php echo h($where); ?></small></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th><?php echo h($title); ?></th><?php foreach ($classes as $name): ?><th class="num"><?php echo h($name); ?></th><?php endforeach; ?><th class="num g">Total</th></tr></thead>
            <tbody>
            <?php foreach ($social[$kind] as $label => $r): ?>
                <tr>
                    <td><b><?php echo h($label); ?></b></td>
                    <?php foreach ($classes as $cid => $name): ?><td class="num"><?php echo ($r[$cid] ?? 0) ?: '<span class="dim">0</span>'; ?></td><?php endforeach; ?>
                    <td class="num g"><b><?php echo $r['total']; ?></b></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$social[$kind]): ?><tr><td colspan="<?php echo count($classes) + 2; ?>"><div class="ex-empty">Nothing to show.</div></td></tr><?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php endforeach; ?>

<?php elseif ($view === 'age'): ?>
    <div class="card">
        <h2><i class="fas fa-cake-candles"></i> Age on <?php echo h(date('d M Y', strtotime($age['ref']))); ?> <small><?php echo h($where); ?></small></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>Class</th><th class="num">Usual age</th><?php foreach ($age['ages'] as $a): ?><th class="num"><?php echo (int)$a; ?></th><?php endforeach; ?><th class="num g">Total</th></tr></thead>
            <tbody>
            <?php foreach ($classes as $cid => $name): [$lo, $hi] = stats_age_band($name); $sum = 0; ?>
                <tr>
                    <td><b>Class <?php echo h($name); ?></b></td>
                    <td class="num"><?php echo $lo ? $lo . '–' . $hi : '—'; ?></td>
                    <?php foreach ($age['ages'] as $a): $n = (int)($age['grid'][$cid][$a] ?? 0); $sum += $n; ?>
                        <td class="num <?php echo $lo && $a >= $lo && $a <= $hi ? 'band' : ''; ?>"><?php echo $n ?: '<span class="dim">·</span>'; ?></td>
                    <?php endforeach; ?>
                    <td class="num g"><b><?php echo $sum; ?></b></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">The green band is the age a class is normally in — Class I is 6 on the 1st of April, and a year either side is fine.<?php echo $age['no_dob'] ? ' ' . (int)$age['no_dob'] . ' student(s) have no date of birth, so they are not in this table.' : ''; ?></p>
    </div>
    <div class="card">
        <h2><i class="fas fa-triangle-exclamation"></i> Outside the band <small><?php echo count($outliers); ?> student(s)</small>
            <a class="btn btn-success btn-sm noprint" style="float:right" href="<?php echo h($link(['export' => 1, 'list' => 'outliers'])); ?>"><i class="fas fa-file-excel"></i> Excel</a></h2>
        <?php if (!$outliers): ?>
            <div class="ex-empty"><i class="fas fa-check-circle"></i>Everyone is the usual age for their class.</div>
        <?php else: ?>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>Student</th><th>Class</th><th>Roll</th><th>Date of birth</th><th class="num">Age</th><th class="num">Usual</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($outliers as $r): ?>
                <tr>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>"><b><?php echo h($r['student_name']); ?></b></a> <small style="color:#6b7d90"><?php echo h($r['id']); ?></small></td>
                    <td><?php echo h(trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''))); ?></td>
                    <td class="num"><?php echo h($r['roll_no']); ?></td>
                    <td><?php echo h($r['dob'] ? date('d M Y', strtotime($r['dob'])) : '—'); ?></td>
                    <td class="num"><b><?php echo (int)$r['age']; ?></b></td>
                    <td class="num"><?php echo h($r['band']); ?></td>
                    <td><span class="chip <?php echo $r['why'] === 'older' ? 'warn' : 'off'; ?>"><?php echo h($r['why']); ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">A date of birth typed wrongly shows up here first — check these against the birth certificate before a board registration.</p>
        <?php endif; ?>
    </div>

<?php elseif ($view === 'places'): ?>
    <div class="card">
        <h2><i class="fas fa-users-rectangle"></i> Section strength <small><?php echo h($where); ?></small>
            <a class="btn btn-success btn-sm noprint" style="float:right" href="<?php echo h($link(['export' => 1, 'list' => 'sections'])); ?>"><i class="fas fa-file-excel"></i> Excel</a></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>Class</th><th>Section</th><th class="num">Boys</th><th class="num">Girls</th><th class="num g">Total</th><th>Share of the class</th></tr></thead>
            <tbody>
            <?php foreach ($classes as $cid => $name): $secs = $strength[$cid] ?? []; $ctotal = array_sum(array_column($secs, 'total')); ?>
                <?php if (!$secs): ?>
                <tr><td><b>Class <?php echo h($name); ?></b></td><td colspan="5"><span class="dim">nobody</span></td></tr>
                <?php endif; ?>
                <?php $first = true; foreach ($secs as $sec): ?>
                <tr>
                    <td><?php echo $first ? '<b>Class ' . h($name) . '</b>' : ''; $first = false; ?></td>
                    <td><b><?php echo h($sec['name']); ?></b></td>
                    <td class="num"><?php echo $sec['Male']; ?></td>
                    <td class="num"><?php echo $sec['Female']; ?></td>
                    <td class="num g"><b><?php echo $sec['total']; ?></b></td>
                    <td><div style="background:var(--ex-soft);border-radius:5px;height:9px;width:160px;max-width:100%"><div style="background:var(--ex-light);height:9px;border-radius:5px;width:<?php echo $ctotal ? round($sec['total'] * 100 / $ctotal) : 0; ?>%"></div></div></td>
                </tr>
                <?php endforeach; ?>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
    <div class="card">
        <h2><i class="fas fa-location-dot"></i> Where they come from <small><?php echo (int)$places['places']; ?> different <?php echo h(strtolower($places['label'])); ?>(s)</small></h2>
        <div class="seg noprint">
            <?php foreach (stats_place_columns() as $col => $lbl): ?><a href="<?php echo h($link(['place' => $col])); ?>" class="<?php echo $col === $places['column'] ? 'on' : ''; ?>"><?php echo h($lbl); ?></a><?php endforeach; ?>
        </div>
        <table class="ex-table">
            <thead><tr><th><?php echo h($places['label']); ?></th><th class="num">Boys</th><th class="num">Girls</th><th class="num g">Total</th><th></th></tr></thead>
            <tbody>
            <?php $top = (int)($places['rows'][0]['n'] ?? 1); foreach ($places['rows'] as $r): ?>
                <tr>
                    <td><b><?php echo h($r['p']); ?></b></td>
                    <td class="num"><?php echo (int)$r['boys']; ?></td>
                    <td class="num"><?php echo (int)$r['girls']; ?></td>
                    <td class="num g"><b><?php echo (int)$r['n']; ?></b></td>
                    <td style="width:200px"><div style="background:var(--ex-soft);border-radius:5px;height:9px"><div style="background:var(--ex-light);height:9px;border-radius:5px;width:<?php echo $top ? round((int)$r['n'] * 100 / $top) : 0; ?>%"></div></div></td>
                </tr>
            <?php endforeach; ?>
            <?php if ($places['other']): ?>
                <tr class="sum"><td><?php echo h($places['other']['p']); ?></td><td class="num"><?php echo $places['other']['boys']; ?></td><td class="num"><?php echo $places['other']['girls']; ?></td><td class="num"><?php echo $places['other']['n']; ?></td><td></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php elseif ($view === 'data'): ?>
    <div class="card">
        <h2><i class="fas fa-clipboard-check"></i> What is filled in <small><?php echo h($where); ?> · <?php echo number_format($complete['total']); ?> student(s)</small></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>What</th><th class="num">Filled in</th><th class="num">Missing</th><th>How much is done</th><?php foreach ($classes as $name): ?><th class="num"><?php echo h($name); ?></th><?php endforeach; ?><th></th></tr></thead>
            <tbody>
            <?php foreach ($complete['fields'] as $key => $r): $pct = $complete['total'] ? round($r['have'] * 100 / $complete['total']) : 0; ?>
                <tr>
                    <td><b><?php echo h($r['label']); ?></b></td>
                    <td class="num"><?php echo number_format($r['have']); ?></td>
                    <td class="num"><?php echo $r['missing'] ? '<b style="color:#b71c1c">' . number_format($r['missing']) . '</b>' : '<span class="chip ok">all done</span>'; ?></td>
                    <td style="width:170px"><div style="background:var(--ex-soft);border-radius:5px;height:9px"><div style="background:<?php echo $pct === 100 ? '#1b7a3a' : 'var(--ex-light)'; ?>;height:9px;border-radius:5px;width:<?php echo $pct; ?>%"></div></div><small style="color:#6b7d90"><?php echo $pct; ?>%</small></td>
                    <?php foreach ($classes as $cid => $name): $m = (int)($r['classes'][$cid]['missing'] ?? 0); ?><td class="num"><?php echo $m ?: '<span class="dim">·</span>'; ?></td><?php endforeach; ?>
                    <td class="noprint"><?php echo $r['missing'] ? '<a class="btn btn-info btn-sm" href="' . h($link(['field' => $key])) . '">See who</a>' : ''; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p class="note">The numbers under the class names are how many are <b>missing</b> in that class.</p>
    </div>
    <?php if ($field): ?>
    <div class="card">
        <h2><i class="fas fa-user-pen"></i> <?php echo h(STATS_FIELDS[$field][0]); ?> not filled in <small><?php echo count($missing); ?> student(s)<?php echo count($missing) >= 500 ? ', the first 500' : ''; ?></small>
            <a class="btn btn-success btn-sm noprint" style="float:right" href="<?php echo h($link(['export' => 1, 'field' => $field])); ?>"><i class="fas fa-file-excel"></i> Excel</a></h2>
        <div class="scroll">
        <table class="ex-table">
            <thead><tr><th>Student</th><th>Class</th><th>Roll</th><th>Father</th><th>Mobile</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($missing as $r): ?>
                <tr>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>"><b><?php echo h($r['student_name']); ?></b></a> <small style="color:#6b7d90"><?php echo h($r['id']); ?></small></td>
                    <td><?php echo h(trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''))); ?></td>
                    <td class="num"><?php echo h($r['roll_no']); ?></td>
                    <td><?php echo h($r['father_name']); ?></td>
                    <td><?php echo h($r['father_mobile']); ?></td>
                    <td class="noprint"><a class="btn btn-warning btn-sm" href="<?php echo h(student_page_url('edit_student.php', $r['id'])); ?>"><i class="fas fa-edit"></i></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php endif; ?>
    <div class="card">
        <h2><i class="fas fa-clone"></i> One number on two students</h2>
        <?php if (!$dupes): ?>
            <div class="ex-empty"><i class="fas fa-check-circle"></i>No Aadhaar, PEN, Banglar Shiksha ID or APAAR is shared by two students.</div>
        <?php else: ?>
        <table class="ex-table">
            <thead><tr><th>What</th><th>Number</th><th>Students</th></tr></thead>
            <tbody>
            <?php foreach ($dupes as $label => $rows): foreach ($rows as $r): ?>
                <tr><td><b><?php echo h($label); ?></b></td><td><?php echo h($r['v']); ?></td><td><?php echo h($r['who']); ?></td></tr>
            <?php endforeach; endforeach; ?>
            </tbody>
        </table>
        <p class="note">The same number cannot belong to two students. Check both against the original card and correct one of them — until then a unique index cannot be put on the column. This block looks at the whole school, not just the filter above.</p>
        <?php endif; ?>
    </div>
<?php endif; ?>
</div>
</body>
</html>

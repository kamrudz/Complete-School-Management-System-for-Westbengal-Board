<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/stats_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Where each student sat last year and where they sit now. What happened between the two years is read off
 * what was recorded — the promotion run first, then the status on the older year's history row — and only
 * when nothing was recorded is it worked out by comparing the two classes. Comparing a year with itself
 * would make every student look held back, so it is not allowed.
 */
const YEAR_MOVES = [
    'promoted'  => ['Promoted', 'ok'],
    'same'      => ['Same class', 'warn'],
    'failed'    => ['Held back', 'bad'],
    'new'       => ['New', 'off'],
    'passed'    => ['Passed out', 'off'],
    'tc'        => ['Took a TC', 'warn'],
    'left'      => ['Left', 'bad'],
];

/** What happened to one student between the two years. */
function year_move(array $r): string
{
    $promo = strtoupper((string)$r['promo']);
    if ($promo === 'PROMOTED') return 'promoted';
    if ($promo === 'FAILED' || $promo === 'NOT_PROMOTED') return 'failed';
    if ($promo === 'TC') return 'tc';
    if ($promo === 'DROPOUT') return 'left';
    $was = (string)$r['prev_status'];
    if ($was === 'Passed') return 'passed';
    if ($was === 'TC') return 'tc';
    if (in_array($was, ['Dropped', 'Transferred', 'Deactivated'], true)) return 'left';
    if (!$r['prev_class_id']) return 'new';
    if (!$r['cur_class_id']) return 'left';
    return (int)$r['prev_class_id'] === (int)$r['cur_class_id'] ? 'same' : 'promoted';
}

$sessions = [];
foreach (db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name') as $s) $sessions[(int)$s['id']] = $s;
$names = array_map(fn($s) => $s['session_name'] . ((string)$s['status'] === 'Active' ? ' (Active)' : ''), $sessions);

$cur = (int)($_GET['cur_session_id'] ?? 0);
if (!isset($sessions[$cur])) {
    foreach ($sessions as $id => $s) if ((string)$s['status'] === 'Active') $cur = $id;
    if (!isset($sessions[$cur])) $cur = (int)(array_key_last($sessions) ?: 0);
}
/** The year just before the one being looked at — never the same year, and empty when there is no earlier one. */
$before = 0;
foreach ($sessions as $id => $s) if ($cur && $s['session_name'] < $sessions[$cur]['session_name']) $before = $id;
$prev = isset($_GET['prev_session_id']) ? (int)$_GET['prev_session_id'] : -1;   // 0 is "no earlier year", asked for on purpose
if ($prev !== 0 && !isset($sessions[$prev])) $prev = $before;
$same_year = $prev && $prev === $cur;
if ($same_year) $prev = $before;

$classes = class_rows();
$cur_class = (int)($_GET['class_id'] ?? 0);
if (!isset($classes[$cur_class])) $cur_class = 0;
$prev_class = (int)($_GET['prev_class_id'] ?? 0);
if (!isset($classes[$prev_class])) $prev_class = 0;
$move = (string)($_GET['move'] ?? '');
if (!isset(YEAR_MOVES[$move])) $move = '';
$search = trim((string)($_GET['search'] ?? ''));
$per = (int)($_GET['per'] ?? 100);
if (!in_array($per, [50, 100, 200, 500], true)) $per = 100;
$page = max(1, (int)($_GET['page'] ?? 1));
$export = !empty($_GET['export']);
$prev_name = $prev ? $sessions[$prev]['session_name'] : '';
$cur_name = $cur ? $sessions[$cur]['session_name'] : '';

$rows = [];
if ($cur) {
    $sql = "SELECT s.id, s.student_name, s.banglarshiksha_id, s.gender, g.father_name,
                   hp.class_id prev_class_id, hp.roll_no prev_roll, hp.student_status prev_status, pc.class_name prev_class_name, ps.section_name prev_section_name,
                   hc.class_id cur_class_id, hc.roll_no cur_roll, cc.class_name cur_class_name, cs.section_name cur_section_name,
                   (SELECT pd.promotion_status FROM promotion_details pd JOIN promotion_batches pb ON pb.id = pd.batch_id
                     WHERE pd.student_id = s.id AND pb.from_session_id = ? AND pb.to_session_id = ? ORDER BY pd.id DESC LIMIT 1) promo
            FROM students s
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN student_academic_history hp ON hp.id = (SELECT MAX(h.id) FROM student_academic_history h WHERE h.student_id = s.id AND h.session_id = ?)
            LEFT JOIN classes pc ON pc.id = hp.class_id
            LEFT JOIN sections ps ON ps.id = hp.section_id
            LEFT JOIN student_academic_history hc ON hc.id = (SELECT MAX(h.id) FROM student_academic_history h WHERE h.student_id = s.id AND h.session_id = ?)
            LEFT JOIN classes cc ON cc.id = hc.class_id
            LEFT JOIN sections cs ON cs.id = hc.section_id
            WHERE s.student_status <> 'Deleted' AND (hp.id IS NOT NULL OR hc.id IS NOT NULL)";
    $types = 'iiii';
    $params = [$prev, $cur, $prev, $cur];
    if ($cur_class)  { $sql .= ' AND hc.class_id = ?'; $types .= 'i'; $params[] = $cur_class; }
    if ($prev_class) { $sql .= ' AND hp.class_id = ?'; $types .= 'i'; $params[] = $prev_class; }
    if ($search !== '') {
        $sql .= ' AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR g.father_name LIKE ?)';
        $types .= 'ssss';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
        array_push($params, $like, $like, $like, $like);
    }
    $sql .= ' ORDER BY (hc.id IS NULL), cc.sort_order, cs.section_name, CAST(hc.roll_no AS UNSIGNED), s.student_name';
    $rows = db_get_all($sql, $types, ...$params);
}

$counts = array_fill_keys(array_keys(YEAR_MOVES), 0);
foreach ($rows as $i => $r) {
    $m = $prev ? year_move($r) : '';
    $rows[$i]['move'] = $m;
    if ($m !== '') $counts[$m]++;
}
if ($move !== '') $rows = array_values(array_filter($rows, fn($r) => $r['move'] === $move));

$where = ($prev_name ? $prev_name . ' to ' : '') . $cur_name
    . ($prev_class ? ' · was Class ' . $classes[$prev_class]['name'] : '')
    . ($cur_class ? ' · now Class ' . $classes[$cur_class]['name'] : '')
    . ($move !== '' ? ' · ' . YEAR_MOVES[$move][0] : '')
    . ($search !== '' ? ' · "' . $search . '"' : '');

if ($export) {
    $out = exam_xlsx_title('Year by year — ' . count($rows) . ' student(s)', $where);
    $out[] = ['School UID', 'Student', 'Father', 'BS ID', 'Gender',
        ($prev_name ?: 'Earlier') . ' class', 'Section', 'Roll', $cur_name . ' class', 'Section', 'Roll', 'What happened'];
    foreach ($rows as $r) {
        $out[] = [$r['id'], $r['student_name'], (string)$r['father_name'], (string)$r['banglarshiksha_id'], (string)$r['gender'],
            (string)$r['prev_class_name'], (string)$r['prev_section_name'], (string)$r['prev_roll'],
            (string)$r['cur_class_name'], (string)$r['cur_section_name'], (string)$r['cur_roll'],
            $r['move'] !== '' ? YEAR_MOVES[$r['move']][0] : ''];
    }
    SimpleXLSXWriter::download('Year_by_year_' . preg_replace('/[^A-Za-z0-9_-]/', '_', ($prev_name ? $prev_name . '_' : '') . $cur_name) . '.xlsx',
        $out, 'Year by year', exam_xlsx_opts(12, 20));
}

$total = count($rows);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$shown = array_slice($rows, ($page - 1) * $per, $per);
$link = fn(array $extra = []) => 'student_year_comparison.php?' . http_build_query(array_merge(
    ['prev_session_id' => $prev, 'cur_session_id' => $cur, 'prev_class_id' => $prev_class, 'class_id' => $cur_class,
     'move' => $move, 'search' => $search, 'per' => $per, 'page' => $page], $extra));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Year by Year</title>
<?php exam_styles('rpt'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(126px, 1fr)); gap: 9px; margin-bottom: 14px; }
    .sb a { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; text-decoration: none; display: block; }
    .sb a.on { border-color: var(--ex-dark); border-left-color: var(--ex-dark); background: var(--ex-soft); }
    .sb b { display: block; font-size: 20px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .ex-table th.g { background: var(--ex-group); }
    .ex-table td.arrow { text-align: center; color: var(--ex-muted); }
    .uid { color: #93a2b2; font-size: 11.5px; }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; margin-top: 12px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
    .scroll { overflow-x: auto; }
    .print-head { display: none; }
    @media print {
        .print-head { display: block; }
        nav.main-navbar-2tier, .ex-banner, .ex-tabs, .pick, .pager, .sb, .noprint { display: none !important; }
        .scroll { overflow: visible !important; }
        .ex-table { font-size: 10px; } .ex-table th, .ex-table td { padding: 2px 4px; }
        .card { border: 0; padding: 0; }
    }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Year by Year', 'Where each student was last year and where they are now', 'fa-arrows-left-right',
        [$link(['export' => 1]) => '<i class="fas fa-file-excel"></i> Excel', 'javascript:window.print()' => '<i class="fas fa-print"></i> Print']); ?>
    <?php exam_tabs('student_year_comparison.php', STATS_PAGES); ?>

    <form method="get" class="card pick noprint">
        <div><label>Earlier year</label><select name="prev_session_id"><option value="0">— none —</option><?php echo exam_options($names, $prev); ?></select></div>
        <div><label>This year</label><select name="cur_session_id" onchange="this.form.submit()"><?php echo exam_options($names, $cur); ?></select></div>
        <div><label>Was in class</label><select name="prev_class_id"><option value="0">Any class</option><?php echo exam_options(array_map(fn($c) => $c['name'], $classes), $prev_class); ?></select></div>
        <div><label>Now in class</label><select name="class_id"><option value="0">Any class</option><?php echo exam_options(array_map(fn($c) => $c['name'], $classes), $cur_class); ?></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, UID, BS ID or father" style="min-width:210px"></div>
        <div><label>Per page</label><select name="per"><?php echo exam_options([50 => 50, 100 => 100, 200 => 200, 500 => 500], $per); ?></select></div>
        <input type="hidden" name="move" value="<?php echo h($move); ?>">
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Show</button></div>
        <div><a href="student_year_comparison.php" class="btn btn-secondary">Reset</a></div>
    </form>

    <?php if ($same_year): ?>
        <div class="ex-guard noprint"><i class="fas fa-circle-info big"></i><div><b>A year cannot be compared with itself</b>
            Every student would look held back. The earlier year is back to <?php echo h($prev_name ?: 'none'); ?>.</div></div>
    <?php endif; ?>
    <?php if (!$prev): ?>
        <div class="ex-guard noprint"><i class="fas fa-circle-info big"></i><div><b>There is no earlier year to compare with</b>
            <?php echo h($cur_name); ?> is the first session that has students, so the list below just shows where everyone is now. Once a second session has students, pick it on the left.</div></div>
    <?php endif; ?>

    <div class="print-head"><?php exam_school_header('YEAR BY YEAR', $where); ?></div>

    <?php if ($prev): ?>
    <div class="sb noprint">
        <a href="<?php echo h($link(['move' => '', 'page' => 1])); ?>" class="<?php echo $move === '' ? 'on' : ''; ?>"><b><?php echo number_format(array_sum($counts)); ?></b><span>Everyone</span></a>
        <?php foreach (YEAR_MOVES as $key => [$label]): if (!$counts[$key]) continue; ?>
        <a href="<?php echo h($link(['move' => $key, 'page' => 1])); ?>" class="<?php echo $move === $key ? 'on' : ''; ?>"><b><?php echo number_format($counts[$key]); ?></b><span><?php echo h($label); ?></span></a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="card">
        <h2><i class="fas fa-table-list"></i> <?php echo h($where ?: 'Students'); ?> <small><?php echo number_format($total); ?> student(s)<?php echo $pages > 1 ? ', page ' . $page . ' of ' . $pages : ''; ?></small></h2>
        <?php if (!$shown): ?>
            <div class="ex-empty"><i class="fas fa-user-group"></i>No student matches what you asked for.</div>
        <?php else: ?>
        <div class="scroll">
        <table class="ex-table">
            <thead>
                <tr>
                    <th rowspan="2">#</th><th rowspan="2">Student</th><th rowspan="2">Father</th>
                    <th class="num g" colspan="3"><?php echo h($prev_name ?: 'Earlier year'); ?></th>
                    <th rowspan="2"></th>
                    <th class="num g" colspan="3"><?php echo h($cur_name); ?></th>
                    <th rowspan="2">What happened</th>
                </tr>
                <tr>
                    <th class="num g">Class</th><th class="num g">Section</th><th class="num g">Roll</th>
                    <th class="num g">Class</th><th class="num g">Section</th><th class="num g">Roll</th>
                </tr>
            </thead>
            <tbody>
            <?php $i = ($page - 1) * $per; foreach ($shown as $r): [$label, $chip] = YEAR_MOVES[$r['move']] ?? ['', 'off']; ?>
                <tr>
                    <td class="num"><?php echo ++$i; ?></td>
                    <td><a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>"><b><?php echo h($r['student_name']); ?></b></a>
                        <div class="uid"><?php echo h($r['id']); ?></div></td>
                    <td><small><?php echo h($r['father_name']); ?></small></td>
                    <td class="num"><?php echo h($r['prev_class_name'] ?: '—'); ?></td>
                    <td class="num"><?php echo h($r['prev_section_name'] ?: '—'); ?></td>
                    <td class="num"><?php echo h($r['prev_roll'] ?: '—'); ?></td>
                    <td class="arrow"><i class="fas fa-arrow-right"></i></td>
                    <td class="num"><?php echo h($r['cur_class_name'] ?: '—'); ?></td>
                    <td class="num"><?php echo h($r['cur_section_name'] ?: '—'); ?></td>
                    <td class="num"><?php echo h($r['cur_roll'] ?: '—'); ?></td>
                    <td><?php echo $label !== '' ? '<span class="chip ' . h($chip) . '">' . h($label) . '</span>' : ''; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php if ($pages > 1): ?>
        <div class="pager noprint">
            <span>Page <?php echo $page; ?> of <?php echo $pages; ?></span>
            <?php if ($page > 1): ?><a href="<?php echo h($link(['page' => $page - 1])); ?>"><i class="fas fa-angle-left"></i> Back</a><?php endif; ?>
            <?php for ($p = max(1, $page - 3); $p <= min($pages, $page + 3); $p++): ?>
                <a href="<?php echo h($link(['page' => $p])); ?>" class="<?php echo $p === $page ? 'on' : ''; ?>"><?php echo $p; ?></a>
            <?php endfor; ?>
            <?php if ($page < $pages): ?><a href="<?php echo h($link(['page' => $page + 1])); ?>">Next <i class="fas fa-angle-right"></i></a><?php endif; ?>
            <span class="noprint">Excel takes all <?php echo number_format($total); ?>.</span>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <p class="note">What happened is read off the promotion that was run, then off the status on the earlier year's record. Only when neither says anything are the two classes compared — a student in the same class then reads "Same class", not "held back", because nothing recorded says they were.</p>
    </div>
</div>
</body>
</html>

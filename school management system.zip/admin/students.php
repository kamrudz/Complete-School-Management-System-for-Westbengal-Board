<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Students — the main list. 50 per page (up to 200), ordered class V → XII, section A → …,
 * roll 1 → n. Filters: session, class, section, status, gender, search (name / UID /
 * Banglar Shiksha ID / PEN / father / guardian / mobile). One student at a time: the row
 * Delete button asks for a reason and moves them to the Deleted list (restorable).
 * Siblings = students who share the same guardian row.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// ---- AJAX: siblings (same guardian row) — the family and every other student in it ----
if (($_GET['ajax'] ?? '') === 'siblings') {
    $uid = student_uid_clean($_GET['uid'] ?? '');
    $me = $uid !== '' ? db_get_row('SELECT s.guardian_id, g.father_name, g.mother_name, g.guardian_name, g.guardian_relation, g.guardian_contact, g.father_mobile, s.village FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id WHERE s.id = ?', 's', $uid) : null;
    $sibs = $me && $me['guardian_id'] ? db_get_all("SELECT s.id, s.student_name, s.photo, s.gender, s.dob, s.student_status, s.banglarshiksha_id, c.class_name, sec.section_name, h.roll_no, a.session_name
        FROM students s
        LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
        LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id LEFT JOIN academic_sessions a ON a.id = h.session_id
        WHERE s.guardian_id = ? AND s.id <> ? AND s.student_status <> 'Deleted' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name", 'is', (int)$me['guardian_id'], $uid) : [];
    if (!$sibs) { echo '<div class="lc-empty" style="padding:18px"><i class="fas fa-users"></i>No other student shares this family record.</div>'; exit(); }
    $badge = ['Active' => 'ok', 'TC' => 'warn', 'Passed' => 'info', 'Deactivated' => 'muted'];
    $fam = array_filter(['Father' => $me['father_name'], 'Mother' => $me['mother_name'], 'Guardian' => trim(($me['guardian_name'] ?? '') . ($me['guardian_relation'] ? ' (' . $me['guardian_relation'] . ')' : '')), 'Contact' => $me['guardian_contact'] ?: $me['father_mobile'], 'Village' => $me['village']]);
    echo '<div class="sib-fam">';
    foreach ($fam as $k => $v) echo '<span><small>' . h($k) . '</small>' . h($v) . '</span>';
    echo '</div>';
    foreach ($sibs as $x) {
        $place = trim(($x['class_name'] ?? '') . ($x['section_name'] ? '-' . $x['section_name'] : '') . ($x['roll_no'] ? ' · Roll ' . $x['roll_no'] : ''));
        echo '<div class="sib-card">'
            . (!empty($x['photo']) ? '<img src="../uploads/students/' . rawurlencode($x['photo']) . '" alt="">' : '<span class="noimg">N/A</span>')
            . '<div class="who"><a href="' . h(student_page_url('view_student.php', $x['id'])) . '"><b>' . h($x['student_name']) . '</b></a> <span class="lc-uid">' . h($x['id']) . '</span>'
            . '<small>' . h($place ?: 'not enrolled') . ($x['session_name'] ? ' · ' . h($x['session_name']) : '') . '</small>'
            . '<small>' . h($x['gender']) . ($x['dob'] ? ' · DOB ' . date('d-m-Y', strtotime($x['dob'])) : '') . ($x['banglarshiksha_id'] ? ' · BSID ' . h($x['banglarshiksha_id']) : '') . '</small></div>'
            . '<span class="lc-tag ' . ($badge[$x['student_status']] ?? 'muted') . '">' . h($x['student_status']) . '</span>'
            . '<a href="' . h(student_page_url('view_student.php', $x['id'])) . '" class="btn btn-info btn-sm" title="View"><i class="fas fa-eye"></i></a>'
            . '<a href="' . h(student_page_url('edit_student.php', $x['id'])) . '" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>'
            . '</div>';
    }
    exit();
}

// ---------- filters ----------
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$session_id = isset($_GET['session_id']) ? (int)$_GET['session_id'] : $active_session;   // 0 = any session (latest enrolment)
$class_id   = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$gender     = in_array($_GET['gender'] ?? '', ['Male', 'Female', 'Other'], true) ? $_GET['gender'] : '';
$status     = in_array($_GET['status'] ?? '', ['Active', 'TC', 'Passed', 'Deactivated', 'all'], true) ? $_GET['status'] : 'Active';
$search     = trim((string)($_GET['search'] ?? ''));
$sort       = in_array($_GET['sort'] ?? '', ['class', 'name', 'newest', 'uid'], true) ? $_GET['sort'] : 'class';
$per        = (int)($_GET['per'] ?? 50); if (!in_array($per, [50, 100, 200], true)) $per = 50;
$page       = max(1, (int)($_GET['page'] ?? 1));

$where = []; $params = []; $types = '';
if ($session_id) {
    // a year view: the student's enrolment row of that session
    $join = 'LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.session_id = ?'; $params[] = $session_id; $types .= 'i';
    $where[] = 'h.id IS NOT NULL';
} else {
    $join = 'LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)';
}
$where[] = $status === 'all' ? "s.student_status <> 'Deleted'" : 's.student_status = ?';
if ($status !== 'all') { $params[] = $status; $types .= 's'; }
if ($class_id)   { $where[] = 'h.class_id = ?';   $params[] = $class_id;   $types .= 'i'; }
if ($section_id) { $where[] = 'h.section_id = ?'; $params[] = $section_id; $types .= 'i'; }
if ($gender !== '') { $where[] = 's.gender = ?'; $params[] = $gender; $types .= 's'; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where[] = '(s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR s.pen_id LIKE ? OR g.father_name LIKE ? OR g.guardian_name LIKE ? OR s.mobile LIKE ? OR g.guardian_contact LIKE ?)';
    array_push($params, $like, $like, $like, $like, $like, $like, $like, $like); $types .= 'ssssssss';
}
$from = "FROM students s $join
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    WHERE " . implode(' AND ', $where);
$order = ['class'  => 'c.sort_order IS NULL, c.sort_order, sec.section_name, h.roll_no IS NULL, CAST(h.roll_no AS UNSIGNED), s.student_name',
          'name'   => 's.student_name, c.sort_order, sec.section_name',
          'newest' => 's.created_at DESC, s.id DESC',
          'uid'    => 's.id'][$sort];

$total = (int)(db_get_row("SELECT COUNT(*) AS c $from", $types, ...$params)['c'] ?? 0);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$offset = ($page - 1) * $per;
$rows = $total ? db_get_all("SELECT s.id, s.student_name, s.photo, s.gender, s.dob, s.mobile, s.banglarshiksha_id, s.student_status, s.guardian_id, s.village,
           h.roll_no, h.session_id AS h_session, c.class_name, sec.section_name, g.father_name, g.guardian_contact,
           (SELECT COUNT(*) FROM students x WHERE x.guardian_id = s.guardian_id AND x.id <> s.id AND x.student_status <> 'Deleted') AS siblings
    $from ORDER BY $order LIMIT $per OFFSET $offset", $types, ...$params) : [];

$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY session_name DESC');
$classes  = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
$sections = $class_id ? db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ? ORDER BY section_name', 'ii', $class_id, $session_id ?: $active_session) : [];
$counts   = db_get_row("SELECT SUM(student_status = 'Active') AS active, SUM(student_status = 'TC') AS tc, SUM(student_status = 'Passed') AS passed, SUM(student_status = 'Deactivated') AS deactivated FROM students") ?: [];
$class_name = ''; foreach ($classes as $c) if ((int)$c['id'] === $class_id) $class_name = $c['class_name'];

// the current filters as a query string, for page links / export / bulk-update
$qs = array_filter(['session_id' => isset($_GET['session_id']) ? (string)$session_id : null, 'class_id' => $class_id ?: null, 'section_id' => $section_id ?: null,
    'status' => $status !== 'Active' ? $status : null, 'gender' => $gender ?: null, 'search' => $search !== '' ? $search : null, 'sort' => $sort !== 'class' ? $sort : null, 'per' => $per !== 50 ? $per : null], fn($v) => $v !== null && $v !== '');
function page_url(int $p): string { global $qs; return 'students.php?' . http_build_query($qs + ($p > 1 ? ['page' => $p] : [])); }
$filtered = $class_id || $section_id || $gender !== '' || $search !== '' || $status !== 'Active' || (isset($_GET['session_id']) && $session_id !== $active_session);
$badge = ['Active' => 'ok', 'TC' => 'warn', 'Passed' => 'info', 'Deactivated' => 'muted', 'Deleted' => 'bad'];

// page-number window: 1 … p-2 p-1 [p] p+1 p+2 … N
$win = []; foreach (array_unique(array_filter(array_merge([1, 2], range($page - 2, $page + 2), [$pages - 1, $pages]), fn($p) => $p >= 1 && $p <= $pages)) as $p) $win[] = $p; sort($win);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .st-banner { background: linear-gradient(135deg, #1f4e79 0%, #2b78b6 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(31,78,121,.25); }
    .st-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .st-banner h1 { margin: 0; font-size: 21px; }
    .st-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e6f5; }
    .st-banner p b { color: #fff; }
    .st-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .st-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .st-banner .links a:hover { background: rgba(255,255,255,.26); }
    .st-banner .links a.solid { background: #fff; color: #1f4e79; }
    .st-banner .links a.add { background: #21a98a; border-color: #21a98a; }
    .lc-filter { margin-bottom: 10px; }
    .lc-filter input[type=text] { min-width: 260px; }
    .lc-filter .go { display: flex; gap: 6px; }
    .st-wrap { position: relative; }
    .st-live { position: absolute; top: 100%; left: 0; width: 360px; max-width: 90vw; background: #fff; border: 1px solid #c9d6e2; border-radius: 10px; box-shadow: 0 10px 30px rgba(20,50,80,.15); z-index: 40; max-height: 320px; overflow: auto; display: none; }
    .st-live.open { display: block; }
    .st-live a { display: flex; align-items: center; gap: 10px; padding: 7px 12px; border-bottom: 1px solid #eef2f6; color: #10253a; text-decoration: none; font-size: 13px; }
    .st-live a:hover { background: #f5f9fc; }
    .st-live img, .st-live .noimg { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; background: #edf2f7; flex: 0 0 30px; }
    .st-live small { display: block; color: #6b7d90; }
    .st-bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 8px; font-size: 13px; color: #3b5168; }
    .st-bar .spacer { flex: 1; }
    .st-bar select { height: 32px; border: 1px solid #c9d6e2; border-radius: 7px; padding: 0 8px; font-size: 13px; background: #fff; }
    .lc-table td.nowrap { white-space: nowrap; }
    .lc-table .place { display: inline-flex; gap: 4px; align-items: center; }
    .lc-table .place span { background: #eaf2fb; color: #1f4e79; font-weight: 700; padding: 2px 8px; border-radius: 7px; font-size: 12px; }
    .lc-table .place span.roll { background: #1f4e79; color: #fff; }
    .lc-table small { color: #6b7d90; }
    .sib { display: inline-block; min-width: 24px; text-align: center; background: #f3f0fb; color: #5b3fa0; font-weight: 700; border-radius: 999px; padding: 2px 8px; font-size: 12px; cursor: pointer; }
    .sib.none { background: transparent; color: #b0bec9; cursor: default; }
    .lc-actions .btn { padding: 4px 7px; margin: 0 3px 0 0; }
    #sibModal .lc-dialog { max-width: 640px; }
    .sib-fam { display: flex; flex-wrap: wrap; gap: 6px 18px; background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 8px 12px; margin-bottom: 10px; font-size: 13px; }
    .sib-fam small { display: block; color: #6b7d90; font-size: 10.5px; text-transform: uppercase; letter-spacing: .4px; }
    .sib-card { display: flex; align-items: center; gap: 10px; padding: 8px 4px; border-bottom: 1px solid #eef2f6; }
    .sib-card img, .sib-card .noimg { width: 44px; height: 44px; border-radius: 50%; object-fit: cover; border: 1px solid #d5dee7; background: #edf2f7; flex: 0 0 44px; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #8a9aab; }
    .sib-card .who { flex: 1; min-width: 0; font-size: 13.5px; }
    .sib-card .who a { color: #10253a; text-decoration: none; } .sib-card .who a:hover { color: #145da0; }
    .sib-card .who small { display: block; color: #6b7d90; font-size: 12px; }
    .sib-card .btn { padding: 4px 7px; }
    .pg { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; justify-content: center; margin: 12px 0 4px; }
    .pg a, .pg span.cur, .pg span.gap { min-width: 34px; height: 34px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #c9d6e2; background: #fff; color: #1f4e79; text-decoration: none; font-weight: 600; font-size: 13px; padding: 0 8px; }
    .pg a:hover { background: #eaf2fb; }
    .pg span.cur { background: #1f4e79; color: #fff; border-color: #1f4e79; }
    .pg span.gap { border: 0; color: #8a9aab; }
    .pg a.dis { pointer-events: none; opacity: .4; }
    .dx-dlg .names { max-height: 200px; overflow: auto; border: 1px solid #e1eaf2; border-radius: 8px; padding: 6px 10px; margin-top: 10px; font-size: 13px; display: grid; grid-template-columns: 1fr 1fr; gap: 0 12px; }
    .dx-dlg .names div { break-inside: avoid; padding: 2px 0; }
    .dx-dlg .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 12px; }
    .dx-dlg h3.danger { background: linear-gradient(135deg, #b0454f, #d2606a) !important; }
    @media (max-width: 800px) { .dx-dlg .row2, .dx-dlg .names { grid-template-columns: 1fr; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="st-banner">
        <div class="ico"><i class="fas fa-user-graduate"></i></div>
        <div>
            <h1>Students</h1>
            <p><b><?php echo number_format((int)($counts['active'] ?? 0)); ?></b> active · <?php echo (int)($counts['tc'] ?? 0); ?> TC · <?php echo (int)($counts['passed'] ?? 0); ?> passed out · <?php echo (int)($counts['deactivated'] ?? 0); ?> deactivated</p>
        </div>
        <div class="links">
            <a href="add_student.php" class="add"><i class="fas fa-plus"></i> Add Student</a>
            <a href="import_students.php"><i class="fas fa-file-import"></i> Import</a>
            <a href="student_bulk_update.php?<?php echo h(http_build_query(array_filter(['session_id' => $session_id ?: $active_session, 'class_id' => $class_id, 'section_id' => $section_id]))); ?>"><i class="fas fa-table"></i> Bulk Update</a>
            <a href="export_students.php?<?php echo h(http_build_query($qs)); ?>"><i class="fas fa-file-excel"></i> Export</a>
            <a href="deactivated_students.php"><i class="fas fa-user-slash"></i> Deactivated</a>
            <a href="tc_students.php"><i class="fas fa-file-export"></i> TC</a>
            <a href="deleted_students.php"><i class="fas fa-trash-alt"></i> Deleted</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <form method="get" class="lc-filter" id="filters">
        <div><label>Session</label><select name="session_id"><option value="0" <?php echo $session_id === 0 ? 'selected' : ''; ?>>Any (latest enrolment)</option><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Class</label><select name="class_id" id="fClass"><option value="0">All classes</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>" <?php echo (int)$c['id'] === $class_id ? 'selected' : ''; ?>><?php echo h($c['class_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Section</label><select name="section_id" id="fSection"><option value="0">All sections</option><?php foreach ($sections as $x): ?><option value="<?php echo (int)$x['id']; ?>" <?php echo (int)$x['id'] === $section_id ? 'selected' : ''; ?>><?php echo h($x['section_name']); ?></option><?php endforeach; ?></select></div>
        <div><label>Status</label><select name="status"><?php foreach (['Active' => 'Active', 'all' => 'All (except deleted)', 'TC' => 'TC', 'Passed' => 'Passed out', 'Deactivated' => 'Deactivated'] as $v => $l): ?><option value="<?php echo $v; ?>" <?php echo $status === $v ? 'selected' : ''; ?>><?php echo $l; ?></option><?php endforeach; ?></select></div>
        <div><label>Gender</label><select name="gender"><option value="">All</option><?php foreach (['Male', 'Female', 'Other'] as $gv): ?><option value="<?php echo $gv; ?>" <?php echo $gender === $gv ? 'selected' : ''; ?>><?php echo $gv; ?></option><?php endforeach; ?></select></div>
        <div class="st-wrap"><label>Search</label><input type="text" name="search" id="fSearch" value="<?php echo h($search); ?>" placeholder="Name, UID, Banglar Shiksha ID, PEN, father, mobile" autocomplete="off"><div class="st-live" id="stLive"></div></div>
        <input type="hidden" name="sort" value="<?php echo h($sort); ?>"><input type="hidden" name="per" value="<?php echo $per; ?>">
        <div class="go"><button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button><?php if ($filtered): ?><a href="students.php" class="btn btn-secondary">Reset</a><?php endif; ?></div>
    </form>

    <div class="st-bar">
        <span><b><?php echo number_format($total); ?></b> student<?php echo $total === 1 ? '' : 's'; ?><?php echo $total ? ' · showing ' . number_format($offset + 1) . '–' . number_format(min($offset + $per, $total)) : ''; ?><?php echo $class_name ? ' · ' . h($class_name) . ($section_id && $sections ? '-' . h(current(array_filter($sections, fn($x) => (int)$x['id'] === $section_id))['section_name'] ?? '') : '') : ''; ?></span>
        <span class="spacer"></span>
        <label>Sort <select onchange="setParam('sort', this.value)"><option value="class" <?php echo $sort === 'class' ? 'selected' : ''; ?>>Class → Section → Roll</option><option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Name</option><option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest first</option><option value="uid" <?php echo $sort === 'uid' ? 'selected' : ''; ?>>School UID</option></select></label>
        <label>Per page <select onchange="setParam('per', this.value)"><?php foreach ([50, 100, 200] as $n): ?><option value="<?php echo $n; ?>" <?php echo $per === $n ? 'selected' : ''; ?>><?php echo $n; ?></option><?php endforeach; ?></select></label>
    </div>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-search"></i>No students match<?php echo $filtered ? ' these filters' : ''; ?>.<?php if (!$filtered): ?><br><a href="add_student.php" class="btn btn-success" style="margin-top:12px"><i class="fas fa-plus"></i> Add the first student</a><?php endif; ?></div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table" id="list">
        <thead><tr>
            <th>#</th><th>Student</th><th>Father / contact</th><th>Class · Sec · Roll</th><th>Gender / DOB</th><th>Siblings</th><?php if ($status !== 'Active'): ?><th>Status</th><?php endif; ?><th>Actions</th>
        </tr></thead>
        <tbody>
        <?php $sl = $offset; foreach ($rows as $r): $sl++; $canAct = $r['student_status'] === 'Active'; ?>
        <tr data-uid="<?php echo h($r['id']); ?>" data-name="<?php echo h($r['student_name']); ?>" data-roll="<?php echo h($r['roll_no']); ?>">
            <td><?php echo $sl; ?></td>
            <td><?php echo lifecycle_student_cell($r); ?></td>
            <td><?php echo h($r['father_name'] ?? ''); ?><?php if ($r['guardian_contact'] ?: $r['mobile']): ?><br><small><i class="fas fa-phone" style="color:#8a9aab"></i> <?php echo h($r['guardian_contact'] ?: $r['mobile']); ?></small><?php endif; ?><?php if ($r['village']): ?><br><small><?php echo h($r['village']); ?></small><?php endif; ?></td>
            <td class="nowrap"><?php if ($r['class_name']): ?><span class="place"><span><?php echo h($r['class_name']); ?></span><?php if ($r['section_name']): ?><span><?php echo h($r['section_name']); ?></span><?php endif; ?><?php if ($r['roll_no'] !== null && $r['roll_no'] !== ''): ?><span class="roll"><?php echo h($r['roll_no']); ?></span><?php endif; ?></span><?php else: ?><span class="lc-tag muted">not enrolled</span><?php endif; ?></td>
            <td class="nowrap"><?php echo h($r['gender']); ?><br><small><?php echo $r['dob'] ? date('d-m-Y', strtotime($r['dob'])) : '—'; ?></small></td>
            <td style="text-align:center"><?php if ((int)$r['siblings'] > 0): ?><span class="sib" onclick="sibOpen(<?php echo htmlspecialchars(json_encode($r['id']), ENT_QUOTES, "UTF-8"); ?>, <?php echo htmlspecialchars(json_encode($r['student_name']), ENT_QUOTES, "UTF-8"); ?>)"><i class="fas fa-users"></i> <?php echo (int)$r['siblings']; ?></span><?php else: ?><span class="sib none">—</span><?php endif; ?></td>
            <?php if ($status !== 'Active'): ?><td><span class="lc-tag <?php echo $badge[$r['student_status']] ?? 'muted'; ?>"><?php echo h($r['student_status']); ?></span></td><?php endif; ?>
            <td class="lc-actions">
                <a href="<?php echo h(student_page_url('view_student.php', $r['id'])); ?>" class="btn btn-info btn-sm" title="View"><i class="fas fa-eye"></i></a>
                <a href="<?php echo h(student_page_url('edit_student.php', $r['id'])); ?>" class="btn btn-warning btn-sm" title="Edit"><i class="fas fa-edit"></i></a>
                <?php if ($canAct): ?>
                <a href="tc_student.php?uid=<?php echo rawurlencode($r['id']); ?>" class="btn btn-tc btn-sm" title="Issue TC"><i class="fas fa-file-export"></i></a>
                <a href="certificate_add.php?id=<?php echo rawurlencode($r['id']); ?>" class="btn btn-cert btn-sm" title="Certificate"><i class="fas fa-certificate"></i></a>
                <button type="button" class="btn btn-danger btn-sm" title="Delete (to the Deleted list)" onclick="delOpen(this.closest('tr'))"><i class="fas fa-trash"></i></button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="pg">
        <a href="<?php echo h(page_url($page - 1)); ?>" class="<?php echo $page <= 1 ? 'dis' : ''; ?>"><i class="fas fa-chevron-left"></i></a>
        <?php $prev = 0; foreach ($win as $p): if ($p - $prev > 1): ?><span class="gap">…</span><?php endif; $prev = $p; ?>
        <?php if ($p === $page): ?><span class="cur"><?php echo $p; ?></span><?php else: ?><a href="<?php echo h(page_url($p)); ?>"><?php echo $p; ?></a><?php endif; ?>
        <?php endforeach; ?>
        <a href="<?php echo h(page_url($page + 1)); ?>" class="<?php echo $page >= $pages ? 'dis' : ''; ?>"><i class="fas fa-chevron-right"></i></a>
        <span style="color:#6b7d90;font-size:12.5px;margin-left:8px">page <?php echo $page; ?> of <?php echo $pages; ?></span>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<!-- delete one student: they go to the Deleted list, with a reason -->
<div class="lc-modal" id="delModal">
    <form class="lc-dialog dx-dlg" method="post" action="delete_student.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="back" value="students">
        <input type="hidden" name="id" id="delId">
        <h3 class="danger"><i class="fas fa-trash"></i> Delete student</h3>
        <div class="body">
            <div class="names" id="delName"></div>
            <div class="row2">
                <div><label>Reason</label><select name="reason"><?php foreach (['Duplicate record', 'Wrong entry', 'Left without TC', 'Other'] as $x): ?><option><?php echo $x; ?></option><?php endforeach; ?></select></div>
                <div><label>Note (optional)</label><input type="text" name="reason_text" maxlength="150" placeholder="e.g. entered twice"></div>
            </div>
            <div class="note">They move to the <b>Deleted list</b> — nothing is removed, and they can be restored from there. Permanent removal is a separate step on that page.</div>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="document.getElementById('delModal').classList.remove('open')">Cancel</button>
            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Move to Deleted</button>
        </div>
    </form>
</div>

<!-- siblings -->
<div class="lc-modal" id="sibModal">
    <div class="lc-dialog">
        <h3><i class="fas fa-users"></i> Siblings of <span id="sibName"></span></h3>
        <div class="body"><div id="sibList" style="font-size:13.5px">Loading…</div><div class="note">Students who share the same family (guardian) record. To link another sibling, pick this family on the Add / Edit page.</div></div>
        <div class="foot"><button type="button" class="btn btn-secondary" onclick="document.getElementById('sibModal').classList.remove('open')">Close</button></div>
    </div>
</div>
<script>
var ACTIVE_SESSION = <?php echo (int)$active_session; ?>, SESSION = <?php echo (int)($session_id ?: $active_session); ?>;
function setParam(k, v) { var u = new URL(location.href); u.searchParams.set(k, v); u.searchParams.delete('page'); location.href = u.toString(); }
// class -> sections
document.getElementById('fClass').addEventListener('change', function () {
    var sel = document.getElementById('fSection'); sel.innerHTML = '<option value="0">All sections</option>';
    if (!this.value || this.value === '0') return;
    fetch('get_sections.php?class_id=' + encodeURIComponent(this.value) + '&session_id=' + SESSION + '&no_placeholder=1').then(function (r) { return r.text(); }).then(function (html) { sel.innerHTML += html; });
});
// live search
(function () {
    var inp = document.getElementById('fSearch'), box = document.getElementById('stLive'), timer = null, ctrl = null;
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    inp.addEventListener('input', function () {
        clearTimeout(timer); var q = this.value.trim(); if (q.length < 2) { box.classList.remove('open'); return; }
        timer = setTimeout(function () {
            if (ctrl) ctrl.abort(); ctrl = new AbortController();
            fetch('search_students_live.php?q=' + encodeURIComponent(q), { signal: ctrl.signal }).then(function (r) { return r.json(); }).then(function (d) {
                var list = d.results || [];
                box.innerHTML = list.length ? list.map(function (s) { return '<a href="' + esc(s.url) + '">' + (s.photo ? '<img src="' + esc(s.photo) + '" alt="">' : '<span class="noimg"></span>') + '<span><b>' + esc(s.title) + '</b><small>' + esc(s.subtitle) + '</small></span></a>'; }).join('')
                    : '<a><span style="color:#7a8a9a">No match — press Apply to search the full list</span></a>';
                box.classList.add('open');
            }).catch(function () {});
        }, 250);
    });
    document.addEventListener('click', function (e) { if (!box.contains(e.target) && e.target !== inp) box.classList.remove('open'); });
})();
function delOpen(tr) {
    document.getElementById('delId').value = tr.dataset.uid;
    document.getElementById('delName').textContent = (tr.dataset.roll ? 'Roll ' + tr.dataset.roll + ' · ' : '') + tr.dataset.name + ' (' + tr.dataset.uid + ')';
    document.getElementById('delModal').classList.add('open');
}
document.getElementById('delModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
// siblings
function sibOpen(uid, name) {
    document.getElementById('sibName').textContent = name; var el = document.getElementById('sibList'); el.textContent = 'Loading…';
    document.getElementById('sibModal').classList.add('open');
    fetch('students.php?ajax=siblings&uid=' + encodeURIComponent(uid)).then(function (r) { return r.text(); }).then(function (t) { el.innerHTML = t; });
}
document.getElementById('sibModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

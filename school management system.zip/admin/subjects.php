<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';

// Deleting moves a subject to Deleted Subjects. A subject still assigned to a class stays: its marks,
// routine and results hang off that assignment, so it is removed under Class Subjects first.
if (isset($_POST['delete_id'])) {
    verify_csrf_or_die();
    $id = (int)$_POST['delete_id'];
    $subject = db_get_row('SELECT subject_name FROM subjects WHERE id = ? AND is_active = 1', 'i', $id);
    $classes = $subject ? array_column(db_get_all('SELECT DISTINCT c.class_name FROM class_subjects cs JOIN classes c ON c.id = cs.class_id WHERE cs.subject_id = ? ORDER BY c.sort_order', 'i', $id), 'class_name') : [];
    if (!$subject) {
        $_SESSION['error'] = 'Subject not found.';
    } elseif ($classes) {
        $_SESSION['error'] = $subject['subject_name'] . ' is assigned to Class ' . implode(', ', $classes) . ' — remove it under Class Subjects first.';
    } else {
        db_execute('UPDATE subjects SET is_active = 0 WHERE id = ?', 'i', $id);
        log_action((int)($_SESSION['admin_id'] ?? 0), 'SUBJECT_DELETED', 'subjects', $id, $subject);
        $_SESSION['success'] = $subject['subject_name'] . ' moved to Deleted Subjects.';
    }
    header('Location: subjects.php'); exit;
}

$subjects = db_get_all('SELECT s.id, s.subject_name, s.subject_code, COUNT(DISTINCT cs.class_id) AS classes
                        FROM subjects s LEFT JOIN class_subjects cs ON cs.subject_id = s.id
                        WHERE s.is_active = 1 GROUP BY s.id ORDER BY s.subject_name');
$deleted = (int)db_get_row('SELECT COUNT(*) AS n FROM subjects WHERE is_active = 0')['n'];
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subjects</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-book"></i> Subjects <small>(<?php echo count($subjects); ?>)</small></div>
        <div class="row-actions">
            <a href="add_subject.php" class="btn btn-success"><i class="fas fa-plus"></i> Add Subjects</a>
            <a href="deleted_subjects.php" class="btn btn-secondary"><i class="fas fa-trash-restore"></i> Deleted (<?php echo $deleted; ?>)</a>
        </div>
    </div>

    <?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $kind => $icon): if (!isset($_SESSION[$kind])) continue; ?>
    <div class="alert alert-<?php echo $kind === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$kind]); unset($_SESSION[$kind]); ?></div>
    <?php endforeach; ?>

    <?php if (!$subjects): ?>
    <div class="empty-state"><i class="fas fa-book"></i><h3>No subjects yet</h3><p>Click <strong>Add Subjects</strong> to create them.</p></div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>#</th><th>Subject</th><th>Code</th><th>Classes</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($subjects as $i => $s): $n = (int)$s['classes']; ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><strong><?php echo $h($s['subject_name']); ?></strong></td>
                    <td><?php echo $s['subject_code'] !== null && $s['subject_code'] !== '' ? $h($s['subject_code']) : '—'; ?></td>
                    <td><?php echo $n ? '<span class="badge badge-info">' . $n . ' class' . ($n === 1 ? '' : 'es') . '</span>' : '<span class="badge badge-warning">not assigned</span>'; ?></td>
                    <td><div class="row-actions">
                        <a href="edit_subject.php?id=<?php echo (int)$s['id']; ?>" class="icon-btn" title="Edit"><i class="fas fa-edit"></i></a>
                        <?php if (!$n): ?>
                        <form method="post" onsubmit="return confirm('Move <?php echo $h(addslashes($s['subject_name'])); ?> to Deleted Subjects?')">
                            <?php echo csrf_field(); ?><input type="hidden" name="delete_id" value="<?php echo (int)$s['id']; ?>">
                            <button type="submit" class="icon-btn danger" title="Delete"><i class="fas fa-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </div></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <p class="form-hint">A subject assigned to a class can't be deleted — remove it under <a href="class_subjects.php">Class Subjects</a> first.</p>
    <?php endif; ?>
</div>
</body>
</html>

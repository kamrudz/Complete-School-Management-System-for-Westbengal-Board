<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/result_helper.php';
require_once '../includes/exam_ui.php';
require_once '../includes/simple_xlsx_writer.php';

/**
 * Tabulation sheet of ONE exam: exam → class → section (or all). Per subject the total (written + project + grace†),
 * then total / % / grade / result / rank — all from result_exam(). ?print=1 = A4 landscape, ?xlsx=1 = Excel.
 */
$sessions = exam_sessions();
$exam_id = (int)($_GET['exam_id'] ?? 0);
$exam = $exam_id ? exam_get($exam_id) : null;
$session_id = $exam ? (int)$exam['session_id'] : (int)($_GET['session_id'] ?? exam_active_session_id());
if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
$exams = exam_list($session_id);
$exam_opts = []; foreach ($exams as $e) $exam_opts[(int)$e['id']] = $e['exam_name'];
$section = exam_section_clean($_GET['section'] ?? '', (int)($_GET['class_id'] ?? 0));   // Primary & Upper Primary, or Secondary
$classes = exam_classes($section);
$class_id = (int)($_GET['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
$sections = $class_id ? exam_sections($session_id, $class_id) : [];
$section_raw = (string)($_GET['section_id'] ?? 'all');
$section_id = $section_raw === 'all' ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = null;
$sort = ($_GET['sort'] ?? 'roll') === 'merit' ? 'merit' : 'roll';
$detail = !empty($_GET['detail']);
$print = !empty($_GET['print']); $xlsx = !empty($_GET['xlsx']);
$ready = $exam && $class_id;
$qs = "exam_id=$exam_id&class_id=$class_id&section=$section&section_id=" . ($section_id ?: 'all') . "&sort=$sort" . ($detail ? '&detail=1' : '');
$res = $ready ? result_exam($session_id, $class_id, $exam_id, $section_id, true) : null;   // also those promoted or passed out since
$students = $res['students'] ?? []; $subjects = $res['subjects'] ?? [];
if ($sort === 'merit') uasort($students, fn($a, $b) => (($a['rank'] ?? PHP_INT_MAX) <=> ($b['rank'] ?? PHP_INT_MAX)) ?: strcmp($a['section'] . $a['roll'], $b['section'] . $b['roll']));
$has_project = $class_id && exam_class_has_project($class_id);
$title = $ready ? $exam['exam_name'] . ' · Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : ' (all sections)') : '';
$summary = ['n' => count($students)]; foreach (['PASS', 'PUC', 'FAIL', 'ABSENT'] as $s) $summary[$s] = count(array_filter($students, fn($x) => $x['status'] === $s));
$cell = function (array $s, bool $html = true): string {   // one subject cell
    if ($s['missing']) return $html ? '<span class="miss">—</span>' : '';
    if ($s['absent']) return 'AB';
    return exam_fmt($s['obtained']) . ($s['grace'] > 0 ? '†' : '');
};

if ($ready && $xlsx) {
    $head = ['#', 'Sec', 'Roll', 'School UID', 'Student', 'Father'];
    $band = []; $b = 0;   // every other subject gets a tint, so its columns read as one block
    foreach ($subjects as $s) { $w = exam_subject_code($s); $b = $b === 1 ? 2 : 1; $from = count($head) + 1;
        if ($detail) { $head[] = $w . "\nWritten"; if ($has_project) $head[] = $w . "\nProject"; $head[] = $w . "\nGrace"; }
        $head[] = $w . "\nof " . exam_fmt($s['full']) . "\npass " . exam_fmt($s['pass']);
        for ($c = $from; $c <= count($head); $c++) $band[$c] = $b; }
    array_push($head, "Total\nmarks", "Full\nmarks", '%', 'Grade', 'Result', 'Rank', "Sub.\nfailed");
    $rows = array_merge(exam_xlsx_title('Tabulation Sheet — ' . $title, 'Session ' . exam_session_name($session_id) . '  ·  ' . exam_subject_legend($subjects)), [$head]); $i = 0;
    foreach ($students as $uid => $st) {
        $r = [++$i, $st['section'], $st['roll'], $uid, $st['name'], $st['father']];
        foreach ($subjects as $sid => $s) { $x = $st['subjects'][$sid] ?? null; if ($detail) { $r[] = $x && !$x['missing'] && !$x['absent'] ? exam_fmt($x['written']) : ''; if ($has_project) $r[] = $x && !$x['missing'] && !$x['absent'] ? exam_fmt($x['project']) : ''; $r[] = $x && $x['grace'] > 0 ? exam_fmt($x['grace']) : ''; } $r[] = $x ? $cell($x, false) : 'NA'; }
        array_push($r, exam_fmt($st['total']), exam_fmt($st['full']), exam_fmt($st['pct']), $st['grade'], $st['status'], $st['rank'] ?? '', $st['failed_n']);
        $rows[] = $r;
    }
    SimpleXLSXWriter::download('tabulation_' . preg_replace('/[^A-Za-z0-9]+/', '_', $exam['exam_name'] . '_' . $title) . '.xlsx', $rows, 'Tabulation', exam_xlsx_opts(count($head)) + ['band_cols' => $band]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tabulation Sheet</title>
<?php exam_styles(); ?>
<style>
    .tab { overflow: auto; } .tab table { border-collapse: collapse; font-size: 12px; min-width: 100%; }
    .tab th, .tab td { border: 1px solid #cfd8e3; padding: 4px 6px; text-align: center; white-space: nowrap; } .tab th { background: #f3eef8; color: #3b1d5c; font-size: 11px; } .tab th small { display: block; font-weight: 400; color: #6b7d90; }
    .tab td.l { text-align: left; } .tab td.miss { background: #fff8dc; } .tab .miss { color: #b8860b; } .tab td.f { color: #b71c1c; font-weight: 700; } .tab td.tot { font-weight: 700; }
    .tab tr.ab td { color: #888; } .tab td.name a { color: #222; text-decoration: none; } .tab td.name a:hover { text-decoration: underline; }
    .tab td.sub { border-left: 2px solid #b7a6cc; } .tab th.sub { border-left: 2px solid #b7a6cc; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin: 0 0 10px; } .sum span { padding: 5px 11px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 12.5px; } .sum b { margin-left: 4px; }
    .legend { font-size: 11.5px; color: #6b7d90; margin-top: 8px; }
    <?php if ($print): ?> body { background: #fff; } .page-box { padding: 8px !important; } .tab table { font-size: 10.5px; } .tab th, .tab td { padding: 2px 4px; } @page { size: A4 landscape; margin: 8mm; } <?php endif; ?>
</style>
</head>
<body>
<?php if (!$print) include("../includes/navbar.php"); ?>
<div class="page-box">
    <?php if ($print): ?>
        <?php exam_school_header('Tabulation Sheet — ' . $title, 'Session ' . $exam['session_name'] . ($exam['exam_date_from'] ? ' · ' . date('d M Y', strtotime($exam['exam_date_from'])) . ($exam['exam_date_to'] ? ' – ' . date('d M Y', strtotime($exam['exam_date_to'])) : '') : '')); ?>
        <div class="noprint" style="margin-bottom:8px"><button onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Print</button> <a href="tabulation_sheet.php?<?php echo h($qs); ?>" class="btn btn-secondary">Back</a></div>
    <?php else: ?>
        <?php exam_banner('Tabulation Sheet', 'Marks of every subject of one exam, with total, percentage, grade, result and rank. Click a student to edit their marks.', 'fa-table', $ready ? ["tabulation_sheet.php?$qs&print=1" => '<i class="fas fa-print"></i> Print', "tabulation_sheet.php?$qs&xlsx=1" => '<i class="fas fa-file-excel"></i> Excel'] : []); ?>
        <?php exam_tabs('tabulation_sheet.php', EXAM_PAGES, "section=$section"); ?>
        <?php exam_flash(); ?>
        <form method="get" class="pick card" style="margin-bottom:12px"><input type="hidden" name="section" value="<?php echo h($section); ?>">
            <div><label>Session</label><select name="session_id" onchange="this.form.exam_id.value='';this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
            <div><label>Exam</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? 'Select exam' : 'No exams in this session'); ?></select></div>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='all';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
            <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $section_id ?: 'all'); ?></select></div>
            <div><label>Order</label><select name="sort" onchange="this.form.submit()"><?php echo exam_options(['roll' => 'Roll number', 'merit' => 'Merit (rank)'], $sort); ?></select></div>
            <div><label>&nbsp;</label><label style="text-transform:none;font-weight:400;display:flex;align-items:center;gap:6px;height:38px"><input type="checkbox" name="detail" value="1" <?php echo $detail ? 'checked' : ''; ?> onchange="this.form.submit()" style="min-width:auto;height:auto"> Written / project / grace columns</label></div>
        </form>
    <?php endif; ?>

    <?php if (!$ready): ?><div class="card"><div class="ex-empty"><i class="fas fa-table"></i>Select an exam and a class.</div></div>
    <?php elseif (!$subjects): ?><div class="card"><div class="ex-empty"><i class="fas fa-sliders-h"></i>No full marks set for Class <?php echo h($classes[$class_id]['name']); ?> in <?php echo h($exam['exam_name']); ?> — <a href="exam_subject_marks.php?exam_id=<?php echo $exam_id; ?>&class_id=<?php echo $class_id; ?>">set them</a>.</div></div>
    <?php else: ?>
    <div class="card">
        <?php if (!$print): ?><h2><i class="fas fa-table"></i> <?php echo h($title); ?> <small><?php echo h($exam['session_name']); ?></small></h2><?php endif; ?>
        <div class="sum"><span>Students<b><?php echo $summary['n']; ?></b></span><span>Pass<b><?php echo $summary['PASS']; ?></b></span><span>PUC<b><?php echo $summary['PUC']; ?></b></span><span>Fail<b><?php echo $summary['FAIL']; ?></b></span><span>Absent<b><?php echo $summary['ABSENT']; ?></b></span><?php if ($res['unconfigured']): ?><span class="chip warn">Not in this exam: <?php echo h(implode(', ', array_map(fn($sid) => exam_class_subject_list($session_id, $class_id)[$sid]['name'] ?? $sid, $res['unconfigured']))); ?></span><?php endif; ?><?php if ($res['tl_unassigned']): ?><span class="chip warn"><?php echo $res['tl_unassigned']; ?> without third-language choice</span><?php endif; ?></div>
        <div class="tab"><table>
            <thead><tr><th>#</th><?php if (!$section_id): ?><th>Sec</th><?php endif; ?><th>Roll</th><th style="text-align:left">Student</th><?php if (!$print): ?><th style="text-align:left">Father</th><?php endif; ?>
                <?php foreach ($subjects as $s): ?><?php if ($detail): ?><th class="sub">W<small>/<?php echo exam_fmt($s['written_full']); ?></small></th><?php if ($has_project): ?><th>P<small>/<?php echo exam_fmt($s['project_full']); ?></small></th><?php endif; ?><th>G</th><?php endif; ?><th class="<?php echo $detail ? '' : 'sub'; ?>"><?php echo h($s['name']); ?><small>/<?php echo exam_fmt($s['full']); ?> · pass <?php echo exam_fmt($s['pass']); ?></small></th><?php endforeach; ?>
                <th class="sub">Total<small>/<?php echo exam_fmt(reset($students)['full'] ?? array_sum(array_column($subjects, 'full'))); ?></small></th><th>%</th><th>Grade</th><th>Result</th><th>Rank</th></tr></thead>
            <tbody>
            <?php $i = 0; foreach ($students as $uid => $st): $i++; ?>
            <tr class="<?php echo $st['status'] === 'ABSENT' ? 'ab' : ''; ?>"><td><?php echo $i; ?></td><?php if (!$section_id): ?><td><?php echo h($st['section']); ?></td><?php endif; ?><td><?php echo h($st['roll']); ?></td>
                <td class="l name"><?php echo $print ? h($st['name']) : '<a href="student_marks_edit.php?uid=' . urlencode($uid) . '&exam_id=' . $exam_id . '&section=' . h($section) . '" title="Edit marks">' . h($st['name']) . '</a>'; ?></td><?php if (!$print): ?><td class="l" style="color:#4d6178"><?php echo h($st['father']); ?></td><?php endif; ?>
                <?php foreach ($subjects as $sid => $s): $x = $st['subjects'][$sid] ?? null; if (!$x): ?><?php if ($detail): ?><td class="sub"></td><?php if ($has_project): ?><td></td><?php endif; ?><td></td><?php endif; ?><td class="<?php echo $detail ? '' : 'sub'; ?>" style="color:#aaa">NA</td><?php continue; endif; ?>
                    <?php if ($detail): ?><td class="sub"><?php echo $x['missing'] || $x['absent'] ? '' : exam_fmt($x['written']); ?></td><?php if ($has_project): ?><td><?php echo $x['missing'] || $x['absent'] ? '' : exam_fmt($x['project']); ?></td><?php endif; ?><td><?php echo $x['grace'] > 0 ? exam_fmt($x['grace']) : ''; ?></td><?php endif; ?>
                    <td class="<?php echo $detail ? '' : 'sub'; ?> <?php echo $x['missing'] ? 'miss' : ($x['fail'] ? 'f' : ''); ?>"><?php echo $cell($x); ?></td>
                <?php endforeach; ?>
                <td class="sub tot"><?php echo exam_fmt($st['total']); ?></td><td><?php echo exam_fmt($st['pct']); ?></td><td><?php echo h($st['grade']); ?></td><td><?php echo $print ? h($st['status']) : result_badge($st['status']); ?></td><td class="tot"><?php echo $st['rank'] ?? '—'; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table></div>
        <div class="legend">† includes grace marks · AB absent · — not entered (yellow) · NA subject not taken · red = below pass marks · rank is within the list shown (<?php echo $section_id ? 'this section' : 'whole class'; ?>).</div>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

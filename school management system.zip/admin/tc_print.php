<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");

/** Transfer Certificate — one A4 sheet, printed from the TC record of a student. */
$id = student_id_from_request();
$student = $id !== '' ? db_get_row("SELECT s.*, g.father_name, g.mother_name, g.guardian_name, g.guardian_relation FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id WHERE s.id = ?", 's', $id) : null;
if (!$student) { $_SESSION['error'] = 'Student not found.'; header('Location: tc_students.php'); exit(); }
$tc = db_get_row("SELECT * FROM tc_students WHERE student_id = ? ORDER BY (status = 'Issued') DESC, id DESC LIMIT 1", 's', $id);
if (!$tc) { $_SESSION['error'] = "{$student['student_name']} has no Transfer Certificate on record."; header('Location: ' . student_page_url('view_student.php', $id)); exit(); }
$school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];

$history = db_get_all("SELECT h.*, c.class_name, a.session_name, sec.section_name FROM student_academic_history h
    LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN academic_sessions a ON a.id = h.session_id LEFT JOIN sections sec ON sec.id = h.section_id
    WHERE h.student_id = ? ORDER BY a.session_name, h.id", 's', $id);
$leaving = $history ? end($history) : null;                  // the row closed by the TC
$admitted = $history[0] ?? null;
$admission_class = $student['admission_class_id'] ? (db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $student['admission_class_id'])['class_name'] ?? '') : ($admitted['class_name'] ?? '');

function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmy($d) { return ($d && $d !== '0000-00-00') ? date('d-m-Y', strtotime($d)) : ''; }
function words_num(int $n): string {
    $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    if ($n < 20) return $ones[$n];
    if ($n < 100) return $tens[intdiv($n, 10)] . ($n % 10 ? ' ' . $ones[$n % 10] : '');
    if ($n < 1000) return $ones[intdiv($n, 100)] . ' Hundred' . ($n % 100 ? ' ' . words_num($n % 100) : '');
    return words_num(intdiv($n, 1000)) . ' Thousand' . ($n % 1000 ? ' ' . words_num($n % 1000) : '');
}
function words_ordinal(int $n): string {
    $special = [1 => 'First', 2 => 'Second', 3 => 'Third', 5 => 'Fifth', 8 => 'Eighth', 9 => 'Ninth', 12 => 'Twelfth', 20 => 'Twentieth', 30 => 'Thirtieth'];
    if (isset($special[$n])) return $special[$n];
    if ($n < 20) return words_num($n) . 'th';
    $u = $n % 10;
    return $u === 0 ? $special[$n] : words_num($n - $u) . '-' . words_ordinal($u);
}
function date_words($d) {
    if (!$d || $d === '0000-00-00') return '';
    $t = strtotime($d);
    return words_ordinal((int)date('j', $t)) . ' ' . date('F', $t) . ', ' . words_num((int)date('Y', $t));
}
$rows = [
    ['Name of the student', $student['student_name']],
    ["Father's name", $student['father_name'] ?: '—'],
    ["Mother's name", $student['mother_name'] ?: '—'],
    ['Date of birth', dmy($student['dob']) ?: '—'],
    ['Gender / Religion / Caste', implode(' / ', array_map(fn($v) => $v ?: '—', [$student['gender'], $student['religion'], $student['caste']]))],
    ['Banglar Shiksha ID', $student['banglarshiksha_id'] ?: '—'],
    ['PEN', $student['pen_id'] ?: '—'],
    ['APAAR ID', $student['apaar_id'] ?: '—'],
    ['Date of admission', dmy($student['admission_date']) ?: ($student['admission_year'] ?: '—')],
    ['Class in which admitted', $admission_class ?: '—'],
    ['Class in which studying at the time of leaving', $leaving ? 'Class ' . $leaving['class_name'] . ($leaving['section_name'] ? ' (' . $leaving['section_name'] . ')' : '') . ', Session ' . $leaving['session_name'] : '—'],
    ['Reason for leaving', $tc['reason'] ?: '—'],
    ['Date of leaving', dmy($tc['tc_date'])],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TC <?php echo h($tc['tc_no']); ?> — <?php echo h($id); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    body { background: #dfe6ee; }
    .toolbar { max-width: 210mm; margin: 16px auto 10px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
    .toolbar .spacer { flex: 1; } .toolbar .alert { width: 100%; margin: 0 0 6px; }
    .sheet {
        width: 210mm; height: 297mm; margin: 0 auto 24px; padding: 12mm 14mm 10mm; box-sizing: border-box;
        background: #fff; color: #1a2a3a; box-shadow: 0 6px 24px rgba(20, 40, 70, .18); position: relative;
        --fs: 12pt; font-family: "Times New Roman", Georgia, "Noto Serif Bengali", serif; font-size: var(--fs); line-height: 1.35; display: flex; flex-direction: column;
    }
    .sheet::before { content: ''; position: absolute; inset: 6mm; border: 1.2pt solid #1f4e79; pointer-events: none; }
    .sheet::after  { content: ''; position: absolute; inset: 7.5mm; border: .4pt solid #1f4e79; pointer-events: none; }
    .sch { display: flex; align-items: center; gap: 5mm; padding-bottom: 3mm; border-bottom: 1.5pt solid #1f4e79; }
    .sch img { width: 20mm; height: 20mm; object-fit: contain; }
    .sch .nm { flex: 1; text-align: center; }
    .sch h1 { margin: 0; font-size: 20pt; letter-spacing: .5px; color: #1f4e79; text-transform: uppercase; }
    .sch p { margin: 1mm 0 0; font-size: 10pt; color: #3c4d5f; }
    .sch .gap { width: 20mm; }
    .ttl { text-align: center; margin: 3.5mm 0 2.5mm; }
    .ttl span { display: inline-block; padding: 1.5mm 10mm; border: 1.2pt solid #1f4e79; border-radius: 2mm; font-size: 16pt; font-weight: 700; letter-spacing: 3px; color: #1f4e79; }
    .meta { display: flex; justify-content: space-between; font-size: 11.5pt; margin: 2mm 0 4mm; }
    .meta b { font-family: Arial, sans-serif; }
    .uid { font-family: Arial, sans-serif; font-weight: 700; font-size: 10.5pt; background: #003366; color: #fff; padding: .5mm 4mm; border-radius: 999px; }
    table.tc { width: 100%; border-collapse: collapse; }
    table.tc td { padding: .32em .9em; border-bottom: .4pt dotted #9fb0c0; vertical-align: top; }
    table.tc td.n { width: 8mm; color: #5a6f84; }
    table.tc td.k { width: 62mm; color: #2c3e50; }
    table.tc td.v { font-weight: 700; color: #10253a; }
    .cert { margin-top: 3mm; font-size: .92em; font-style: italic; color: #2c3e50; }
    .sigs { margin-top: auto; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 6mm; }
    .sigs div { text-align: center; width: 34%; font-size: 11pt; }
    .sigs div span { display: block; border-top: 1pt solid #1f4e79; margin-top: 12mm; padding-top: 1.5mm; }
    .sigs .seal { width: 26%; height: 26mm; border: .6pt dashed #9fb0c0; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #9fb0c0; font-size: 9pt; margin: 0 auto 4mm; }
    .qr { display: flex; align-items: center; gap: 3mm; margin-top: 2.5mm; }
    .qr img { width: 20mm; height: 20mm; display: block; }
    .qr small { font-family: Arial, sans-serif; font-size: 7.5pt; color: #5a6f84; line-height: 1.3; }
    .foot { display: flex; justify-content: space-between; font-size: 8.5pt; color: #8a9aab; margin-top: 3mm; font-family: Arial, sans-serif; }
    .cancelled { position: absolute; top: 40%; left: 10%; right: 10%; text-align: center; font-size: 60pt; font-weight: 900; color: rgba(200, 30, 40, .18); transform: rotate(-20deg); letter-spacing: 8px; pointer-events: none; }
    @page { size: A4 portrait; margin: 0; }
    @media print {
        html, body { background: #fff !important; margin: 0 !important; }
        body > *:not(.sheet) { display: none !important; }
        .sheet { margin: 0; box-shadow: none; }
        .sheet, .sheet * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
</style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="toolbar">
    <?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
    <a href="tc_students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> TC list</a>
    <a href="<?php echo h(student_page_url('view_student.php', $id)); ?>" class="btn btn-secondary"><i class="fas fa-eye"></i> Profile</a>
    <span class="spacer"></span>
    <?php if ($tc['status'] === 'Cancelled'): ?><span class="lc-tag" style="color:#9d2630;font-weight:700">This TC was cancelled on <?php echo dmy($tc['cancelled_at']); ?></span><?php endif; ?>
    <button type="button" class="btn btn-success" onclick="window.print()"><i class="fas fa-print"></i> Print (A4)</button>
</div>

<div class="sheet">
    <?php if ($tc['status'] === 'Cancelled'): ?><div class="cancelled">CANCELLED</div><?php endif; ?>
    <header class="sch">
        <?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo rawurlencode($school['logo']); ?>" alt=""><?php else: ?><span class="gap"></span><?php endif; ?>
        <div class="nm">
            <h1><?php echo h($school['school_name'] ?? 'School'); ?></h1>
            <p><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
            <p><?php echo !empty($school['udise_code']) ? 'UDISE: ' . h($school['udise_code']) : ''; ?><?php echo !empty($school['school_code']) ? ' &nbsp;|&nbsp; Index No.: ' . h($school['school_code']) : ''; ?><?php echo !empty($school['phone']) ? ' &nbsp;|&nbsp; Phone: ' . h($school['phone']) : ''; ?></p>
        </div>
        <span class="gap"></span>
    </header>
    <div class="ttl"><span>TRANSFER CERTIFICATE</span></div>
    <div class="meta">
        <div>TC No. <b><?php echo h($tc['tc_no']); ?></b></div>
        <div>Student ID <span class="uid"><?php echo h($id); ?></span></div>
        <div>Date <b><?php echo dmy($tc['tc_date']); ?></b></div>
    </div>
    <table class="tc">
        <?php foreach ($rows as $i => [$k, $v]): ?>
        <tr><td class="n"><?php echo $i + 1; ?>.</td><td class="k"><?php echo h($k); ?></td><td class="v">: &nbsp;<?php echo h($v); ?></td></tr>
        <?php endforeach; ?>
    </table>
    <p class="cert">Certified that the above particulars are in accordance with the admission register and other records of the school. This certificate is issued at the request of the guardian.</p>
    <?php if (!empty($tc['verification_token'])): ?>
    <div class="qr"><img src="tc_qr.php?token=<?php echo h($tc['verification_token']); ?>" alt="QR"><small>Scan to verify<br><?php echo h($tc['tc_no']); ?></small></div>
    <?php endif; ?>
    <div class="sigs">
        <div><span>Class Teacher</span></div>
        <div><div class="seal">School seal</div></div>
        <div><span>Head of the Institution</span></div>
    </div>

    <div class="foot"><span><?php echo h($school['school_name'] ?? ''); ?> · TC <?php echo h($tc['tc_no']); ?> · <?php echo h($id); ?></span><span>Printed <?php echo date('d-m-Y H:i'); ?></span></div>
</div>
<script>
// Fit the certificate on the sheet: shrink the text until the sigs sit inside the border.
(function () {
    var sheet = document.querySelector('.sheet'); if (!sheet) return;
    var fs = 12.5; sheet.style.setProperty('--fs', fs + 'pt');
    while (sheet.scrollHeight > sheet.clientHeight + 1 && fs > 8.5) { fs -= 0.25; sheet.style.setProperty('--fs', fs + 'pt'); }
})();
</script>
</body>
</html>

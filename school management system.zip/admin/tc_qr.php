<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once("../includes/base_url.php");
require_once("../includes/phpqrcode/qrlib.php");

// QR for a Transfer Certificate: encodes the public verify URL for its token.
$token = $_GET['token'] ?? '';
if (!preg_match('/^[a-f0-9]{64}$/', $token)) { http_response_code(400); exit(); }
if (!db_get_row('SELECT id FROM tc_students WHERE verification_token = ? LIMIT 1', 's', $token)) { http_response_code(404); exit(); }

$verify_url = get_site_base_url($conn) . '/tc_verify.php?token=' . $token;
header('Content-Type: image/png');
QRcode::png($verify_url, false, QR_ECLEVEL_M, 6, 2);
exit();

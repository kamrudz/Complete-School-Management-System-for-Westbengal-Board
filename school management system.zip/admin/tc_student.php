<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once "../includes/security.php";

/**
 * Issue a Transfer Certificate. On save the student becomes TC (student_set_status
 * closes their running-session row and writes tc_students) and the admin lands on
 * the printable certificate.
 */
$id = student_id_from_request();
$student = $id !== '' ? db_get_row("SELECT s.*, g.father_name, g.mother_name, g.guardian_name FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id WHERE s.id = ?", 's', $id) : null;
if (!$student) { $_SESSION['error'] = 'Student not found.'; header('Location: students.php'); exit(); }
if ($student['student_status'] !== 'Active') {
    $_SESSION['error'] = "{$student['student_name']} is {$student['student_status']} — a TC can only be issued to an Active student.";
    header('Location: ' . student_page_url('view_student.php', $id)); exit();
}
$academic = db_get_row("SELECT h.*, c.class_name, sec.section_name, a.session_name FROM student_academic_history h
    LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id LEFT JOIN academic_sessions a ON a.id = h.session_id
    WHERE h.student_id = ? AND h.academic_status = 'Current' ORDER BY h.id DESC LIMIT 1", 's', $id);

if (isset($_POST['save_tc'])) {
    verify_csrf_or_die();
    $tc_date = (string)($_POST['tc_date'] ?? '');
    $tc_no = trim((string)($_POST['tc_no'] ?? ''));
    $d = DateTime::createFromFormat('Y-m-d', $tc_date);
    if (!$d || $d->format('Y-m-d') !== $tc_date) {
        $_SESSION['error'] = 'TC date is not valid.';
    } elseif ($tc_date > date('Y-m-d')) {
        $_SESSION['error'] = 'The TC date cannot be in the future.';
    } else {
        $r = student_set_status($conn, $id, 'TC', ['tc_no' => $tc_no, 'tc_date' => $tc_date, 'reason' => trim((string)($_POST['reason'] ?? ''))],
            (int)($_SESSION['admin_id'] ?? 0));
        if ($r['ok']) {
            $_SESSION['success'] = "TC $tc_no issued to {$student['student_name']}. Print it below.";
            header('Location: tc_print.php?uid=' . rawurlencode($id)); exit();
        }
        $_SESSION['error'] = $r['message'];
    }
    header('Location: tc_student.php?uid=' . rawurlencode($id)); exit();
}

// next TC number: last number + 1, keeping its prefix and zero padding
$last = db_get_row('SELECT tc_no FROM tc_students ORDER BY id DESC LIMIT 1');
$next_tc_no = 'TC-' . date('Y') . '-001';
if ($last && preg_match('/^(.*?)(\d+)$/', $last['tc_no'], $m)) $next_tc_no = $m[1] . str_pad((string)((int)$m[2] + 1), strlen($m[2]), '0', STR_PAD_LEFT);
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transfer Certificate — <?php echo h($id); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    .tc-wrap { max-width: 900px; margin: 0 auto; }
    .who { display: flex; gap: 16px; align-items: center; background: linear-gradient(135deg, #eaf2fb, #f6f9fd); border: 1px solid #cfdff0; border-radius: 12px; padding: 14px 16px; margin-bottom: 16px; }
    .who img, .who .noimg { width: 70px; height: 84px; object-fit: cover; border-radius: 8px; border: 1px solid #b8c6d4; background: #f1f5f9; }
    .who .noimg { display: flex; align-items: center; justify-content: center; color: #8aa0b6; font-size: 12px; }
    .who .name { font-size: 20px; font-weight: 800; color: #10253a; }
    .who .uid { display: inline-block; background: #003366; color: #fff; font-weight: 700; padding: 2px 12px; border-radius: 999px; font-size: 13px; margin: 4px 0; }
    .who .line { font-size: 13px; color: #2c3e50; }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 16px; }
    .card h3 { margin: 0 0 12px; font-size: 14px; color: #1f4e79; text-transform: uppercase; letter-spacing: .6px; }
    .grid { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 12px; }
    .f { display: flex; flex-direction: column; }
    .f label { font-size: 12px; font-weight: 700; color: #3b5168; margin-bottom: 5px; }
    .f input, .f select, .f textarea { padding: 8px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; min-height: 38px; }
    .c2 { grid-column: span 2; } .c3 { grid-column: span 3; } .c6 { grid-column: span 6; }
    .req { color: #d9363e; }
    .warn { background: #fff6e5; border: 1px solid #f0c987; border-radius: 10px; padding: 10px 14px; color: #6b4a00; font-size: 13px; margin: 14px 0; }
    .chk { display: flex; align-items: center; gap: 8px; min-height: 38px; font-weight: 600; }
    @media (max-width: 760px) { .grid { grid-template-columns: 1fr 1fr; } .c3, .c6 { grid-column: span 2; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box tc-wrap">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-file-export"></i> Issue Transfer Certificate</div>
        <div>
            <a href="<?php echo h(student_page_url('view_student.php', $id)); ?>" class="btn btn-secondary"><i class="fas fa-eye"></i> Profile</a>
            <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>
    <?php if (!empty($_SESSION['error'])): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

    <div class="who">
        <?php if ($student['photo']): ?><img src="../uploads/students/<?php echo rawurlencode($student['photo']); ?>" alt=""><?php else: ?><div class="noimg">No photo</div><?php endif; ?>
        <div>
            <div class="name"><?php echo h($student['student_name']); ?></div>
            <span class="uid"><?php echo h($id); ?></span>
            <div class="line">Father <b><?php echo h($student['father_name'] ?: '—'); ?></b> · Mother <b><?php echo h($student['mother_name'] ?: '—'); ?></b> · DOB <b><?php echo $student['dob'] ? date('d-m-Y', strtotime($student['dob'])) : '—'; ?></b></div>
            <div class="line"><?php echo $academic ? 'Class <b>' . h($academic['class_name']) . '</b>' . ($academic['section_name'] ? ' · Section <b>' . h($academic['section_name']) . '</b>' : '') . ($academic['roll_no'] ? ' · Roll <b>' . h($academic['roll_no']) . '</b>' : '') . ' · Session <b>' . h($academic['session_name']) . '</b>' : '<span style="color:#9a5a00">Not enrolled in the running session</span>'; ?></div>
            <div class="line">Banglar Shiksha ID <b><?php echo h($student['banglarshiksha_id'] ?: '—'); ?></b> · PEN <b><?php echo h($student['pen_id'] ?: '—'); ?></b> · APAAR <b><?php echo h($student['apaar_id'] ?: '—'); ?></b></div>
        </div>
    </div>

    <form method="post" class="card" autocomplete="off">
        <?php echo csrf_field(); ?>
        <h3>Certificate details</h3>
        <div class="grid">
            <div class="f c2"><label>TC Number <span class="req">*</span></label><input type="text" name="tc_no" value="<?php echo h($next_tc_no); ?>" maxlength="50" required><small style="color:#7a8a9a;margin-top:4px">Next in the register — change if your register says otherwise.</small></div>
            <div class="f c2"><label>Date of issue / leaving <span class="req">*</span></label><input type="date" name="tc_date" value="<?php echo date('Y-m-d'); ?>" max="<?php echo date('Y-m-d'); ?>" required></div>
            <div class="f c2"><label>Reason for leaving</label><input type="text" name="reason" maxlength="255" placeholder="e.g. Guardian's transfer"></div>
        </div>
        <div class="warn"><i class="fas fa-exclamation-triangle"></i> On save the student moves to the <b>TC list</b> and leaves the running session's class list. If they come back, the TC can be cancelled from the TC list — the TC number stays used.</div>
        <div style="display:flex;justify-content:flex-end;gap:10px">
            <a href="students.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" name="save_tc" value="1" class="btn btn-success" onclick="return confirm('Issue the TC and move <?php echo h(addslashes($student['student_name'])); ?> to the TC list?')"><i class="fas fa-file-export"></i> Issue TC &amp; Print</button>
        </div>
    </form>
</div>
</body>
</html>

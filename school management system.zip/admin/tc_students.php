<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Transfer Certificates — every TC issued (and, on request, the cancelled ones).
 * Print opens tc_print.php; "Cancel TC & restore" goes through restore_student.php,
 * which marks the record Cancelled (the number stays used) and re-enrols the student.
 */
$search = trim((string)($_GET['search'] ?? ''));
$show = ($_GET['show'] ?? 'issued') === 'all' ? 'all' : 'issued';
$year = (int)($_GET['year'] ?? 0);
$params = []; $types = '';
$where = $show === 'all' ? '1' : "t.status = 'Issued'";
if ($year) { $where .= ' AND YEAR(t.tc_date) = ?'; $params[] = $year; $types .= 'i'; }
if ($search !== '') {
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%';
    $where .= " AND (s.student_name LIKE ? OR s.id LIKE ? OR s.banglarshiksha_id LIKE ? OR t.tc_no LIKE ? OR g.father_name LIKE ?)";
    array_push($params, $like, $like, $like, $like, $like); $types .= 'sssss';
}
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$rows = db_get_all("
    SELECT t.id AS tc_id, t.tc_no, t.tc_date, t.reason, t.status, t.cancelled_at,
           s.id, s.student_name, s.photo, s.banglarshiksha_id, s.student_status, g.father_name,
           h.session_id AS last_session_id, h.class_id AS last_class_id, h.section_id AS last_section_id, h.roll_no AS last_roll,
           c.class_name, sec.section_name, a.session_name
    FROM tc_students t
    JOIN students s ON s.id = t.student_id
    LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
    LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    LEFT JOIN academic_sessions a ON a.id = h.session_id
    WHERE $where
    ORDER BY t.tc_date DESC, t.id DESC", $types, ...$params);
$years = db_get_all('SELECT DISTINCT YEAR(tc_date) AS y FROM tc_students WHERE tc_date IS NOT NULL ORDER BY y DESC');
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transfer Certificates</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-header">
        <div class="page-title"><i class="fas fa-file-export"></i> Transfer Certificates <span class="count"><?php echo count($rows); ?></span></div>
        <div>
            <a href="deactivated_students.php" class="btn btn-secondary"><i class="fas fa-user-slash"></i> Deactivated</a>
            <a href="deleted_students.php" class="btn btn-secondary"><i class="fas fa-trash-alt"></i> Deleted</a>
            <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Students</a>
        </div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <form method="get" class="lc-filter">
        <div><label>Year</label><select name="year"><option value="">All years</option><?php foreach ($years as $y): ?><option value="<?php echo (int)$y['y']; ?>" <?php echo $year === (int)$y['y'] ? 'selected' : ''; ?>><?php echo (int)$y['y']; ?></option><?php endforeach; ?></select></div>
        <div><label>Show</label><select name="show"><option value="issued" <?php echo $show === 'issued' ? 'selected' : ''; ?>>Issued only</option><option value="all" <?php echo $show === 'all' ? 'selected' : ''; ?>>Issued + cancelled</option></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name, UID, BSID, TC no, father" style="min-width:260px"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
        <?php if ($search !== '' || $year || $show === 'all'): ?><a href="tc_students.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-file-export"></i>No transfer certificates<?php echo ($search !== '' || $year) ? ' match this filter' : ' issued yet'; ?>. Issue one from a student's profile or the Students list.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>TC No</th><th>Date</th><th>Student</th><th>Father</th><th>Class at leaving</th><th>Reason</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $r): $needs = (int)$r['last_session_id'] !== $active_session; ?>
        <tr>
            <td><b><?php echo htmlspecialchars($r['tc_no']); ?></b></td>
            <td><?php echo $r['tc_date'] ? date('d-m-Y', strtotime($r['tc_date'])) : '—'; ?></td>
            <td><?php echo lifecycle_student_cell($r); ?></td>
            <td><?php echo htmlspecialchars($r['father_name'] ?? ''); ?></td>
            <td><?php echo $r['class_name'] ? htmlspecialchars($r['class_name'] . ($r['section_name'] ? '-' . $r['section_name'] : '') . ' · ' . $r['session_name']) : '—'; ?></td>
            <td style="max-width:220px"><?php echo htmlspecialchars($r['reason'] ?: '—'); ?></td>
            <td><?php echo $r['status'] === 'Issued' ? '<span class="lc-tag warn">TC issued</span>' : '<span class="lc-tag muted">Cancelled ' . date('d-m-Y', strtotime($r['cancelled_at'])) . '</span>'; ?></td>
            <td class="lc-actions">
                <a href="tc_print.php?uid=<?php echo rawurlencode($r['id']); ?>" class="btn btn-primary btn-sm" title="Print TC"><i class="fas fa-print"></i></a>
                <a href="<?php echo htmlspecialchars(student_page_url('view_student.php', $r['id'])); ?>" class="btn btn-info btn-sm" title="Profile"><i class="fas fa-eye"></i></a>
                <?php if ($r['status'] === 'Issued' && $r['student_status'] === 'TC'): ?>
                <button type="button" class="btn btn-success btn-sm" title="Cancel this TC and restore the student"
                    onclick="lcRestore(<?php echo htmlspecialchars(json_encode($r['id']), ENT_QUOTES, "UTF-8"); ?>, <?php echo htmlspecialchars(json_encode($r['student_name']), ENT_QUOTES, "UTF-8"); ?>, <?php echo $needs ? 'true' : 'false'; ?>, <?php echo (int)$r['last_class_id']; ?>, <?php echo (int)$r['last_section_id']; ?>, <?php echo htmlspecialchars(json_encode((string)$r['last_roll']), ENT_QUOTES, "UTF-8"); ?>)"><i class="fas fa-undo"></i></button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<?php lifecycle_restore_modal($classes, 'tc'); ?>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Staff attendance — one date, every Active staff member: Present / Absent / On duty / Leave,
 * with Late and Early-departure flags (+ reason). Everyone starts Present. Refused on Sundays,
 * holidays and future dates (same rule as student attendance). Who took it is recorded.
 * provisional_routine.php reads absent / on_duty rows from here to reassign periods.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
const TA_STATUSES = ['present' => 'P', 'absent' => 'A', 'on_duty' => 'OD', 'leave' => 'L'];
$admin_id = (int)($_SESSION['admin_id'] ?? 0);
$date = trim((string)($_POST['attendance_date'] ?? $_GET['attendance_date'] ?? date('Y-m-d')));
if (!DateTime::createFromFormat('Y-m-d', $date)) $date = date('Y-m-d');
$block = attendance_day_block($date);
$staff = db_get_all("SELECT id, employee_id, staff_name, short_code, designation, staff_type, subject_name, photo FROM staff WHERE service_status = 'Active'
    ORDER BY FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher', 'Librarian', 'Clerk', 'Accountant', 'Group D'), staff_name");
$existing = [];
foreach (db_get_all('SELECT * FROM teacher_attendance WHERE attendance_date = ?', 's', $date) as $r) $existing[(int)$r['teacher_id']] = $r;

// ---------- save ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    verify_csrf_or_die();
    $back = 'teacher_attendance.php?attendance_date=' . urlencode($date);
    if ($block !== '') { $_SESSION['error'] = 'Attendance is not taken on this day — ' . $block; header("Location: $back"); exit(); }
    $status = (array)($_POST['status'] ?? []); $late = (array)($_POST['late'] ?? []); $early = (array)($_POST['early'] ?? []);
    $late_r = (array)($_POST['late_reason'] ?? []); $early_r = (array)($_POST['early_reason'] ?? []); $rem = (array)($_POST['remarks'] ?? []);
    $n = ['present' => 0, 'absent' => 0, 'on_duty' => 0, 'leave' => 0, 'late' => 0]; $written = 0;
    db_begin_transaction();
    try {
        foreach ($staff as $s) {
            $id = (int)$s['id'];
            $st = $status[$id] ?? 'present'; if (!isset(TA_STATUSES[$st])) $st = 'present';
            $is_late = $st === 'present' && !empty($late[$id]) ? 1 : 0; $is_early = $st === 'present' && !empty($early[$id]) ? 1 : 0;
            $lr = $is_late ? mb_substr(trim((string)($late_r[$id] ?? '')), 0, 200) : ''; $er = $is_early ? mb_substr(trim((string)($early_r[$id] ?? '')), 0, 200) : '';
            $rm = $st === 'present' ? '' : mb_substr(trim((string)($rem[$id] ?? '')), 0, 200);
            $n[$st]++; if ($is_late) $n['late']++;
            $old = $existing[$id] ?? null;
            if ($old && $old['attendance_status'] === $st && (int)$old['is_late'] === $is_late && (int)$old['is_early_departure'] === $is_early && (string)$old['late_reason'] === $lr && (string)$old['early_reason'] === $er && (string)$old['remarks'] === $rm) continue;
            db_execute('INSERT INTO teacher_attendance (teacher_id, attendance_date, attendance_status, is_late, is_early_departure, late_reason, early_reason, remarks, marked_by) VALUES (?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE attendance_status = VALUES(attendance_status), is_late = VALUES(is_late), is_early_departure = VALUES(is_early_departure), late_reason = VALUES(late_reason), early_reason = VALUES(early_reason), remarks = VALUES(remarks), marked_by = VALUES(marked_by)',
                'issiisssi', $id, $date, $st, $is_late, $is_early, $lr, $er, $rm, $admin_id);
            $written++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('teacher attendance: ' . $e->getMessage()); $_SESSION['error'] = 'Could not save — nothing was changed.'; header("Location: $back"); exit(); }
    log_action($admin_id, $existing ? 'STAFF_ATTENDANCE_UPDATED' : 'STAFF_ATTENDANCE_TAKEN', 'teacher_attendance', $date, null, ['date' => $date] + $n + ['rows_written' => $written]);
    $_SESSION['success'] = 'Staff attendance ' . ($existing ? 'updated' : 'saved') . ' for ' . date('d-m-Y', strtotime($date)) . " — Present {$n['present']}, Absent {$n['absent']}, On duty {$n['on_duty']}, Leave {$n['leave']}" . ($n['late'] ? ", Late {$n['late']}" : '') . '.';
    header("Location: $back"); exit();
}

$taken_by = '';
if ($existing) { $f = reset($existing); $who = $f['marked_by'] ? db_get_row('SELECT full_name, username FROM admins WHERE id = ?', 'i', (int)$f['marked_by']) : null; $taken_by = 'Taken by ' . ($who ? ($who['full_name'] ?: $who['username']) : 'admin') . ' at ' . date('d-m-Y H:i', strtotime($f['updated_at'] ?: $f['marked_at'])); }
// last 7 working days: taken or not
$recent = []; for ($i = 0, $d = new DateTime('today'); count($recent) < 7 && $i < 30; $i++, $d->modify('-1 day')) { $k = $d->format('Y-m-d'); if (attendance_day_block($k) !== '') continue; $recent[$k] = (int)(db_get_row('SELECT COUNT(*) AS c FROM teacher_attendance WHERE attendance_date = ?', 's', $k)['c'] ?? 0); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Attendance</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .ta-banner { background: linear-gradient(135deg, #4d2c8a 0%, #7a4fd0 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(77,44,138,.25); }
    .ta-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .ta-banner h1 { margin: 0; font-size: 21px; } .ta-banner p { margin: 3px 0 0; font-size: 12.5px; color: #e4dbf7; }
    .ta-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .ta-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .ta-banner .links a.solid { background: #fff; color: #4d2c8a; }
    .ta-recent { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; }
    .ta-recent a { border: 1px solid #dfe7ef; border-radius: 9px; padding: 5px 10px; font-size: 12.5px; text-decoration: none; color: #10253a; background: #fff; }
    .ta-recent a.done { border-color: #9fd3b2; background: #f2fbf5; } .ta-recent a.pending { border-color: #f0c987; background: #fffaf0; } .ta-recent a.cur { outline: 2px solid #7a4fd0; }
    .ta-recent a small { display: block; color: #6b7d90; font-size: 10.5px; }
    .at-block { background: #fff6e5; border: 1px solid #f0c987; color: #7a4a00; border-radius: 12px; padding: 12px 16px; margin-bottom: 14px; font-size: 14px; display: flex; gap: 10px; align-items: center; } .at-block i { font-size: 20px; }
    .at-head { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin: 4px 0 10px; } .at-head h3 { margin: 0; font-size: 16px; color: #4d2c8a; }
    .at-head .taken { font-size: 12.5px; color: #6b7d90; background: #f3f6f9; padding: 4px 10px; border-radius: 999px; }
    .at-counts { display: flex; gap: 8px; margin-left: auto; flex-wrap: wrap; } .at-counts span { padding: 5px 12px; border-radius: 999px; font-weight: 700; font-size: 13px; }
    .at-counts .p { background: #d7f3e1; color: #1b7a3d; } .at-counts .a { background: #fde2e4; color: #9d2630; } .at-counts .od { background: #dbeafe; color: #1e40af; } .at-counts .l { background: #fff6e5; color: #9a5a00; } .at-counts .lt { background: #f3f0fb; color: #5b3fa0; }
    .at-tools { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 8px; } .at-tools .btn { padding: 6px 12px; font-size: 13px; }
    .at-list { border: 1px solid #dfe7ef; border-radius: 12px; overflow: hidden; }
    .at-row { display: grid; grid-template-columns: 44px 1fr auto auto; gap: 12px; align-items: center; padding: 7px 10px; border-bottom: 1px solid #eef2f6; background: #fff; }
    .at-row:nth-child(even) { background: #fbfdff; } .at-row.abs { background: #fff3f4; } .at-row.od { background: #eef4fd; } .at-row.lv { background: #fff9ec; }
    .at-row img, .at-row .noimg { width: 44px; height: 44px; border-radius: 10px; object-fit: cover; border: 1px solid #d5dee7; background: #edf2f7; display: flex; align-items: center; justify-content: center; font-size: 12px; color: #4d6178; font-weight: 700; }
    .at-row .who b { display: block; font-size: 14px; color: #10253a; } .at-row .who small { color: #6b7d90; }
    .at-row .who input { margin-top: 4px; width: 100%; max-width: 320px; height: 30px; padding: 4px 8px; border: 1px solid #f0c987; border-radius: 6px; font-size: 12.5px; }
    .flags { display: flex; gap: 10px; align-items: center; font-size: 12.5px; color: #3b5168; }
    .flags label { display: flex; align-items: center; gap: 4px; cursor: pointer; } .flags input[type=checkbox] { width: 16px; height: 16px; accent-color: #5b3fa0; margin: 0; }
    .flags input[type=text] { height: 28px; padding: 3px 7px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 12px; width: 130px; }
    .seg { display: inline-flex; border: 1px solid #c9d6e2; border-radius: 10px; overflow: hidden; } .seg label { padding: 0; margin: 0; } .seg input { position: absolute; opacity: 0; pointer-events: none; }
    .seg span { display: inline-flex; align-items: center; justify-content: center; min-width: 50px; height: 40px; font-weight: 800; font-size: 14px; cursor: pointer; color: #6b7d90; background: #fff; border-right: 1px solid #c9d6e2; user-select: none; } .seg label:last-child span { border-right: 0; }
    .seg input:checked + span.p { background: #1b7a3d; color: #fff; } .seg input:checked + span.a { background: #b0454f; color: #fff; } .seg input:checked + span.od { background: #1e40af; color: #fff; } .seg input:checked + span.l { background: #d08a2a; color: #fff; }
    .at-save { position: sticky; bottom: 0; background: rgba(255,255,255,.96); border-top: 1px solid #e1eaf2; padding: 12px 0; margin-top: 12px; display: flex; gap: 10px; align-items: center; backdrop-filter: blur(4px); } .at-save .spacer { flex: 1; }
    @media (max-width: 800px) { .at-row { grid-template-columns: 1fr auto; } .at-row img, .at-row .noimg { display: none; } .flags { grid-column: 1 / -1; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="ta-banner">
        <div class="ico"><i class="fas fa-user-tie"></i></div>
        <div><h1>Staff Attendance</h1><p><?php echo date('l, d F Y', strtotime($date)); ?> · <?php echo count($staff); ?> active staff · absent / on-duty staff are picked up by the provisional routine</p></div>
        <div class="links"><a href="teacher_attendance_report.php"><i class="fas fa-chart-pie"></i> Reports</a><a href="provisional_routine.php"><i class="fas fa-random"></i> Provisional routine</a><a href="holidays.php" class="solid"><i class="fas fa-calendar-times"></i> Holidays</a></div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <form method="get" class="lc-filter">
        <div><label>Date</label><input type="date" name="attendance_date" value="<?php echo h($date); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Open</button>
    </form>
    <div class="ta-recent"><?php foreach ($recent as $k => $c): ?><a href="?attendance_date=<?php echo $k; ?>" class="<?php echo $c ? 'done' : 'pending'; ?> <?php echo $k === $date ? 'cur' : ''; ?>"><?php echo date('d M', strtotime($k)); ?><small><?php echo $c ? 'taken' : 'pending'; ?></small></a><?php endforeach; ?></div>

    <?php if ($block): ?>
    <div class="at-block"><i class="fas fa-calendar-times"></i><div><b>No attendance on <?php echo date('d-m-Y', strtotime($date)); ?></b> — <?php echo h($block); ?></div></div>
    <?php elseif (!$staff): ?>
    <div class="lc-empty"><i class="fas fa-users"></i>No active staff. <a href="add_staff.php">Add staff</a> first.</div>
    <?php else: ?>
    <form method="post" id="taForm">
        <?php echo csrf_field(); ?><input type="hidden" name="attendance_date" value="<?php echo h($date); ?>">
        <div class="at-head">
            <h3><i class="fas fa-users"></i> <?php echo date('d-m-Y', strtotime($date)); ?></h3>
            <span class="taken"><?php echo $taken_by ? '<i class="fas fa-check-circle" style="color:#1b7a3d"></i> ' . h($taken_by) . ' — editing' : 'not taken yet'; ?></span>
            <div class="at-counts"><span class="p">Present <b id="nP">0</b></span><span class="a">Absent <b id="nA">0</b></span><span class="od">On duty <b id="nOD">0</b></span><span class="l">Leave <b id="nL">0</b></span><span class="lt">Late <b id="nLt">0</b></span></div>
        </div>
        <div class="at-tools"><button type="button" class="btn btn-success" onclick="setAll('present')"><i class="fas fa-check-double"></i> All present</button><span style="font-size:12.5px;color:#6b7d90;align-self:center">P present · A absent · OD on duty (training / exam duty / official work) · L leave. Late / Early only apply to a present member.</span></div>
        <div class="at-list" id="list">
            <?php foreach ($staff as $s): $id = (int)$s['id']; $e = $existing[$id] ?? null; $cur = $e['attendance_status'] ?? 'present'; ?>
            <div class="at-row <?php echo ['absent' => 'abs', 'on_duty' => 'od', 'leave' => 'lv'][$cur] ?? ''; ?>">
                <?php echo $s['photo'] ? '<img src="' . h(staff_photo_url($s['photo'])) . '" alt="">' : '<span class="noimg">' . h($s['short_code']) . '</span>'; ?>
                <div class="who"><b><?php echo h($s['staff_name']); ?></b><small><?php echo h($s['designation']); ?><?php echo $s['subject_name'] ? ' · ' . h($s['subject_name']) : ''; ?> · <?php echo h($s['employee_id']); ?></small>
                    <input type="text" name="remarks[<?php echo $id; ?>]" value="<?php echo h($e['remarks'] ?? ''); ?>" placeholder="note (optional)" maxlength="200" <?php echo $cur === 'present' ? 'hidden' : ''; ?>></div>
                <div class="flags" <?php echo $cur !== 'present' ? 'hidden' : ''; ?>>
                    <label><input type="checkbox" name="late[<?php echo $id; ?>]" value="1" <?php echo !empty($e['is_late']) ? 'checked' : ''; ?>> Late</label><input type="text" name="late_reason[<?php echo $id; ?>]" value="<?php echo h($e['late_reason'] ?? ''); ?>" placeholder="reason" maxlength="200" <?php echo empty($e['is_late']) ? 'hidden' : ''; ?>>
                    <label><input type="checkbox" name="early[<?php echo $id; ?>]" value="1" <?php echo !empty($e['is_early_departure']) ? 'checked' : ''; ?>> Early</label><input type="text" name="early_reason[<?php echo $id; ?>]" value="<?php echo h($e['early_reason'] ?? ''); ?>" placeholder="reason" maxlength="200" <?php echo empty($e['is_early_departure']) ? 'hidden' : ''; ?>>
                </div>
                <div class="seg"><?php foreach (TA_STATUSES as $st => $lab): ?><label><input type="radio" name="status[<?php echo $id; ?>]" value="<?php echo $st; ?>" <?php echo $cur === $st ? 'checked' : ''; ?>><span class="<?php echo str_replace('_', '', strtolower($lab)); ?>"><?php echo $lab; ?></span></label><?php endforeach; ?></div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="at-save"><span style="font-size:13px;color:#6b7d90">Everyone not touched is saved as Present.</span><span class="spacer"></span><button type="submit" name="save_attendance" value="1" class="btn btn-success"><i class="fas fa-save"></i> <?php echo $taken_by ? 'Save changes' : 'Save attendance'; ?></button></div>
    </form>
    <?php endif; ?>
</div>
<script>
(function () {
    var list = document.getElementById('list'); if (!list) return;
    function count() {
        var n = { present: 0, absent: 0, on_duty: 0, leave: 0, late: 0 };
        list.querySelectorAll('.at-row').forEach(function (row) {
            var v = row.querySelector('input[type=radio]:checked'); v = v ? v.value : 'present'; n[v]++;
            row.className = 'at-row ' + ({ absent: 'abs', on_duty: 'od', leave: 'lv' }[v] || '');
            row.querySelector('.who input').hidden = v === 'present';
            var flags = row.querySelector('.flags'); flags.hidden = v !== 'present';
            flags.querySelectorAll('input[type=checkbox]').forEach(function (c) { c.parentElement.nextElementSibling.hidden = !c.checked; if (c.name.indexOf('late[') === 0 && c.checked && v === 'present') n.late++; });
        });
        document.getElementById('nP').textContent = n.present; document.getElementById('nA').textContent = n.absent; document.getElementById('nOD').textContent = n.on_duty; document.getElementById('nL').textContent = n.leave; document.getElementById('nLt').textContent = n.late;
    }
    list.addEventListener('change', count);
    window.setAll = function (v) { list.querySelectorAll('input[type=radio][value="' + v + '"]').forEach(function (r) { r.checked = true; }); count(); };
    count();
})();
</script>
</body>
</html>

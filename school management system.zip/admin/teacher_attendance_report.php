<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/attendance_helper.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Staff attendance reports — counted straight from teacher_attendance (no summary table).
 *   register — one month: staff × days grid (P / A / OD / L, late marker), Sundays + holidays shaded
 *   summary  — a date range: per-staff P / A / OD / L / late / early counts and presence %
 * Excel download for both (?xlsx=1).
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$view = ($_GET['view'] ?? 'register') === 'summary' ? 'summary' : 'register';
$month = (int)($_GET['month'] ?? date('n')); $year = (int)($_GET['year'] ?? date('Y')); if ($month < 1 || $month > 12) $month = (int)date('n'); if ($year < 2000 || $year > 2100) $year = (int)date('Y');
$from = trim((string)($_GET['from'] ?? date('Y-m-01'))); $to = trim((string)($_GET['to'] ?? date('Y-m-d')));
if (!DateTime::createFromFormat('Y-m-d', $from)) $from = date('Y-m-01'); if (!DateTime::createFromFormat('Y-m-d', $to)) $to = date('Y-m-d'); if ($to > date('Y-m-d')) $to = date('Y-m-d'); if ($from > $to) $from = $to;
$type = in_array($_GET['type'] ?? '', ['Teaching', 'Non-teaching'], true) ? $_GET['type'] : '';
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$staff = db_get_all("SELECT id, employee_id, staff_name, short_code, designation, staff_type FROM staff WHERE service_status = 'Active'" . ($type ? " AND staff_type = '" . ($type === 'Teaching' ? 'Teaching' : 'Non-teaching') . "'" : '') . "
    ORDER BY FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher', 'Librarian', 'Clerk', 'Accountant', 'Group D'), staff_name");
$code = ['present' => 'P', 'absent' => 'A', 'on_duty' => 'OD', 'leave' => 'L'];

if ($view === 'register') {
    $days = attendance_working_days($year, $month);
    $first = sprintf('%04d-%02d-01', $year, $month); $last = sprintf('%04d-%02d-%02d', $year, $month, count($days));
    $working = array_keys(array_filter($days, fn($d) => $d['working'] && !$d['future']));
    $marks = []; $taken_days = [];
    foreach (db_get_all('SELECT teacher_id, attendance_date, attendance_status, is_late, is_early_departure FROM teacher_attendance WHERE attendance_date BETWEEN ? AND ?', 'ss', $first, $last) as $r) { $marks[(int)$r['teacher_id']][$r['attendance_date']] = $r; $taken_days[$r['attendance_date']] = true; }
    $taken_n = count(array_intersect($working, array_keys($taken_days)));
    $xlsx = [array_merge(['Employee ID', 'Name', 'Designation'], array_map(fn($d) => (int)substr($d, 8, 2), array_keys($days)), ['P', 'A', 'OD', 'L', 'Late', '%'])];
    $rowsum = [];
    foreach ($staff as $s) {
        $c = ['P' => 0, 'A' => 0, 'OD' => 0, 'L' => 0, 'late' => 0]; $line = [$s['employee_id'], $s['staff_name'], $s['designation']];
        foreach ($days as $d => $info) { $m = $marks[(int)$s['id']][$d] ?? null; $cell = ''; if ($info['holiday'] || $info['sunday']) $cell = 'H'; elseif ($m) { $cell = $code[$m['attendance_status']]; if (in_array($d, $working, true)) { $c[$cell]++; if ($m['is_late']) $c['late']++; } } $line[] = $cell; }
        $den = $c['P'] + $c['A'] + $c['OD'] + $c['L']; $pct = $den ? round(($c['P'] + $c['OD']) / $den * 100) : null; $rowsum[(int)$s['id']] = $c + ['pct' => $pct, 'den' => $den];
        $xlsx[] = array_merge($line, [$c['P'], $c['A'], $c['OD'], $c['L'], $c['late'], $pct ?? '']);
    }
    $title = 'Staff attendance register — ' . date('F Y', strtotime($first));
} else {
    $hol = attendance_holiday_map($from, $to); $working = [];
    for ($d = new DateTime($from); $d <= new DateTime($to); $d->modify('+1 day')) { $k = $d->format('Y-m-d'); if ((int)$d->format('N') !== 7 && !isset($hol[$k])) $working[] = $k; }
    $agg = [];
    foreach (db_get_all('SELECT teacher_id, SUM(attendance_status = \'present\') p, SUM(attendance_status = \'absent\') a, SUM(attendance_status = \'on_duty\') od, SUM(attendance_status = \'leave\') l, SUM(is_late) late, SUM(is_early_departure) early, COUNT(*) n FROM teacher_attendance WHERE attendance_date BETWEEN ? AND ? GROUP BY teacher_id', 'ss', $from, $to) as $r) $agg[(int)$r['teacher_id']] = $r;
    $days_taken = (int)(db_get_row('SELECT COUNT(DISTINCT attendance_date) AS c FROM teacher_attendance WHERE attendance_date BETWEEN ? AND ?', 'ss', $from, $to)['c'] ?? 0);
    $xlsx = [['Employee ID', 'Name', 'Designation', 'Type', 'Days taken', 'Present', 'Absent', 'On duty', 'Leave', 'Late', 'Early', 'Presence %']];
    foreach ($staff as $s) { $a = $agg[(int)$s['id']] ?? ['p' => 0, 'a' => 0, 'od' => 0, 'l' => 0, 'late' => 0, 'early' => 0, 'n' => 0]; $xlsx[] = [$s['employee_id'], $s['staff_name'], $s['designation'], $s['staff_type'], (int)$a['n'], (int)$a['p'], (int)$a['a'], (int)$a['od'], (int)$a['l'], (int)$a['late'], (int)$a['early'], (int)$a['n'] ? round(($a['p'] + $a['od']) / $a['n'] * 100) : '']; }
    $title = 'Staff attendance summary — ' . date('d-m-Y', strtotime($from)) . ' to ' . date('d-m-Y', strtotime($to)) . ' (' . count($working) . ' working days, ' . $days_taken . ' taken)';
}
if (!empty($_GET['xlsx'])) SimpleXLSXWriter::download('staff_attendance_' . $view . '_' . date('Y-m-d') . '.xlsx', $xlsx, 'Staff attendance', ['header_rows' => 1, 'freeze_rows' => 1]);
$q = array_filter(['view' => $view, 'month' => $view === 'register' ? $month : null, 'year' => $view === 'register' ? $year : null, 'from' => $view === 'summary' ? $from : null, 'to' => $view === 'summary' ? $to : null, 'type' => $type ?: null]);
$prev = mktime(0, 0, 0, $month - 1, 1, $year); $next = mktime(0, 0, 0, $month + 1, 1, $year);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Attendance Reports</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .ta-banner { background: linear-gradient(135deg, #4d2c8a 0%, #7a4fd0 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(77,44,138,.25); }
    .ta-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .ta-banner h1 { margin: 0; font-size: 21px; } .ta-banner p { margin: 3px 0 0; font-size: 12.5px; color: #e4dbf7; }
    .ta-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .ta-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .ta-banner .links a.solid { background: #fff; color: #4d2c8a; }
    .rp-tabs { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; }
    .rp-tabs a { padding: 8px 16px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #4d2c8a; text-decoration: none; font-weight: 600; font-size: 13.5px; } .rp-tabs a.on { background: #4d2c8a; color: #fff; border-color: #4d2c8a; }
    .rp-head { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; } .rp-head h3 { margin: 0; font-size: 15px; color: #4d2c8a; }
    .rg-month { display: flex; align-items: center; gap: 8px; margin-left: auto; } .rg-month a { border: 1px solid #c9d6e2; border-radius: 7px; padding: 5px 10px; color: #1f4e79; text-decoration: none; }
    .rg-wrap { overflow: auto; border: 1px solid #dfe7ef; border-radius: 10px; background: #fff; }
    table.rg { border-collapse: collapse; font-size: 12px; min-width: 100%; }
    .rg th, .rg td { border: 1px solid #e6edf3; padding: 3px 4px; text-align: center; white-space: nowrap; }
    .rg th { background: #4d2c8a; color: #fff; font-weight: 700; position: sticky; top: 0; font-size: 11px; } .rg th.d small { display: block; font-weight: 400; font-size: 9px; opacity: .85; }
    .rg th.sun, .rg th.hol { background: #6b7d90; } .rg th.hol { background: #9a5a00; } .rg td.sun, .rg td.hol { background: #eef2f6; color: #b0bec9; } .rg td.fut { background: #fafbfc; } .rg td.nt { background: #fff9ec; color: #d08a2a; }
    .rg .nm { text-align: left; min-width: 200px; position: sticky; left: 0; background: #fff; z-index: 1; } .rg th.nm { z-index: 2; } .rg .nm small { color: #6b7d90; display: block; font-size: 10px; }
    .rg td.P { color: #1b7a3d; font-weight: 700; } .rg td.A { background: #fde2e4; color: #9d2630; font-weight: 800; } .rg td.OD { background: #dbeafe; color: #1e40af; font-weight: 800; } .rg td.L { background: #fff6e5; color: #9a5a00; font-weight: 800; }
    .rg td.late { box-shadow: inset 0 -3px 0 #7a4fd0; } .rg td.tot { font-weight: 700; background: #f8fafc; } .rg td.pct { font-weight: 800; } .rg td.pct.low { background: #fde2e4; color: #9d2630; }
    .rg-legend { display: flex; gap: 14px; flex-wrap: wrap; font-size: 12px; color: #3b5168; margin: 8px 0; } .rg-legend span i { display: inline-block; width: 14px; height: 14px; border-radius: 3px; vertical-align: -2px; margin-right: 4px; border: 1px solid #d5dee7; }
    .lc-table td.num { text-align: right; font-variant-numeric: tabular-nums; } .lc-table td.low { background: #fde2e4; color: #9d2630; font-weight: 800; }
    .bar { display: inline-block; width: 80px; height: 8px; background: #eef2f6; border-radius: 4px; vertical-align: middle; margin-right: 6px; overflow: hidden; } .bar i { display: block; height: 100%; background: #7a4fd0; } .bar.low i { background: #b0454f; }
    .print-head { display: none; }
    @media print { @page { size: A4 landscape; margin: 8mm; } html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; } .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; } .page-box, .page-box * { -webkit-print-color-adjust: exact; print-color-adjust: exact; } .ta-banner, .rp-tabs, .lc-filter, .rg-month, .alert { display: none !important; } .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #4d2c8a; padding-bottom: 6px; margin-bottom: 8px; } .print-head img { width: 44px; height: 44px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #4d2c8a; } .print-head small { color: #444; font-size: 10.5px; } .rg-wrap { border: 0; overflow: visible; } table.rg { font-size: 9.5px; } .rg th, .rg td { padding: 2px 3px; } .rg .nm { min-width: 120px; position: static; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — <?php echo h($title); ?></h2><small>printed <?php echo date('d-m-Y'); ?></small></div></div>
    <div class="ta-banner">
        <div class="ico"><i class="fas fa-chart-pie"></i></div>
        <div><h1>Staff Attendance Reports</h1><p>Counted from the daily register; Sundays and holidays are not working days. Presence % = (present + on duty) ÷ days marked.</p></div>
        <div class="links"><a href="teacher_attendance.php"><i class="fas fa-user-tie"></i> Take attendance</a><a href="#" onclick="window.print(); return false;"><i class="fas fa-print"></i> Print</a><a href="?<?php echo h(http_build_query($q + ['xlsx' => 1])); ?>" class="solid"><i class="fas fa-file-excel"></i> Excel</a></div>
    </div>
    <div class="rp-tabs"><a href="?view=register" class="<?php echo $view === 'register' ? 'on' : ''; ?>"><i class="fas fa-table"></i> Monthly register</a><a href="?view=summary" class="<?php echo $view === 'summary' ? 'on' : ''; ?>"><i class="fas fa-list-ol"></i> Staff-wise summary</a></div>

    <form method="get" class="lc-filter">
        <input type="hidden" name="view" value="<?php echo $view; ?>">
        <?php if ($view === 'register'): ?>
        <div><label>Month</label><select name="month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m === $month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 1)); ?></option><?php endfor; ?></select></div>
        <div><label>Year</label><select name="year"><?php for ($y = (int)date('Y') - 3; $y <= (int)date('Y'); $y++): ?><option value="<?php echo $y; ?>" <?php echo $y === $year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div>
        <?php else: ?>
        <div><label>From</label><input type="date" name="from" value="<?php echo h($from); ?>"></div><div><label>To</label><input type="date" name="to" value="<?php echo h($to); ?>" max="<?php echo date('Y-m-d'); ?>"></div>
        <?php endif; ?>
        <div><label>Type</label><select name="type"><option value="">All staff</option><option value="Teaching" <?php echo $type === 'Teaching' ? 'selected' : ''; ?>>Teaching</option><option value="Non-teaching" <?php echo $type === 'Non-teaching' ? 'selected' : ''; ?>>Non-teaching</option></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>

    <?php if (!$staff): ?><div class="lc-empty"><i class="fas fa-users"></i>No active staff.</div>
    <?php elseif ($view === 'register'): ?>
    <div class="rp-head"><h3><?php echo h($title); ?></h3><span class="lc-tag muted"><?php echo count($working); ?> working days so far · <?php echo $taken_n; ?> taken<?php echo count($working) - $taken_n > 0 ? ' · ' . (count($working) - $taken_n) . ' missing' : ''; ?></span>
        <div class="rg-month"><a href="?<?php echo h(http_build_query($q + ['month' => (int)date('n', $prev), 'year' => (int)date('Y', $prev)])); ?>"><i class="fas fa-chevron-left"></i></a><b><?php echo date('F Y', mktime(0, 0, 0, $month, 1, $year)); ?></b><a href="?<?php echo h(http_build_query($q + ['month' => (int)date('n', $next), 'year' => (int)date('Y', $next)])); ?>"><i class="fas fa-chevron-right"></i></a></div></div>
    <div class="rg-legend"><span><i style="background:#d7f3e1"></i> P present</span><span><i style="background:#fde2e4"></i> A absent</span><span><i style="background:#dbeafe"></i> OD on duty</span><span><i style="background:#fff6e5"></i> L leave</span><span><i style="box-shadow:inset 0 -3px 0 #7a4fd0"></i> late</span><span><i style="background:#fff9ec"></i> not taken</span><span><i style="background:#eef2f6"></i> Sunday / holiday</span></div>
    <div class="rg-wrap"><table class="rg">
        <thead><tr><th class="nm">Staff</th><?php foreach ($days as $d => $info): ?><th class="d <?php echo $info['holiday'] ? 'hol' : ($info['sunday'] ? 'sun' : ''); ?>" title="<?php echo h($info['holiday'] ?? ($info['sunday'] ? 'Sunday' : date('l', strtotime($d)))); ?>"><?php echo (int)substr($d, 8, 2); ?><small><?php echo substr(date('D', strtotime($d)), 0, 2); ?></small></th><?php endforeach; ?><th>P</th><th>A</th><th>OD</th><th>L</th><th>Late</th><th>%</th></tr></thead>
        <tbody><?php foreach ($staff as $s): $c = $rowsum[(int)$s['id']]; ?>
        <tr><td class="nm"><b><?php echo h($s['staff_name']); ?></b><small><?php echo h($s['designation']); ?> · <?php echo h($s['employee_id']); ?></small></td>
            <?php foreach ($days as $d => $info): $m = $marks[(int)$s['id']][$d] ?? null;
                if ($info['holiday'] || $info['sunday']) echo '<td class="' . ($info['holiday'] ? 'hol' : 'sun') . '">·</td>';
                elseif ($info['future']) echo '<td class="fut"></td>';
                elseif (!$m) echo '<td class="' . (isset($taken_days[$d]) ? 'nt' : 'nt') . '">·</td>';
                else echo '<td class="' . $code[$m['attendance_status']] . ($m['is_late'] ? ' late' : '') . '" title="' . ($m['is_late'] ? 'late' : '') . ($m['is_early_departure'] ? ' early' : '') . '">' . $code[$m['attendance_status']] . '</td>';
            endforeach; ?>
            <td class="tot"><?php echo $c['P']; ?></td><td class="tot"><?php echo $c['A']; ?></td><td class="tot"><?php echo $c['OD']; ?></td><td class="tot"><?php echo $c['L']; ?></td><td class="tot"><?php echo $c['late']; ?></td><td class="pct <?php echo $c['pct'] !== null && $c['pct'] < 75 ? 'low' : ''; ?>"><?php echo $c['pct'] === null ? '—' : $c['pct'] . '%'; ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    <?php else: ?>
    <div class="rp-head"><h3><?php echo h($title); ?></h3></div>
    <div style="overflow-x:auto"><table class="lc-table">
        <thead><tr><th>#</th><th>Staff</th><th>Designation</th><th>Days marked</th><th>Present</th><th>Absent</th><th>On duty</th><th>Leave</th><th>Late</th><th>Early</th><th>Presence %</th></tr></thead>
        <tbody><?php $sl = 0; foreach ($staff as $s): $sl++; $a = $agg[(int)$s['id']] ?? ['p' => 0, 'a' => 0, 'od' => 0, 'l' => 0, 'late' => 0, 'early' => 0, 'n' => 0]; $pct = (int)$a['n'] ? round(($a['p'] + $a['od']) / $a['n'] * 100) : null; ?>
        <tr><td><?php echo $sl; ?></td><td><b><?php echo h($s['staff_name']); ?></b><br><small style="color:#6b7d90"><?php echo h($s['employee_id']); ?></small></td><td><?php echo h($s['designation']); ?><br><small style="color:#6b7d90"><?php echo h($s['staff_type']); ?></small></td>
            <td class="num"><?php echo (int)$a['n']; ?> / <?php echo $days_taken; ?></td><td class="num"><?php echo (int)$a['p']; ?></td><td class="num"><?php echo (int)$a['a']; ?></td><td class="num"><?php echo (int)$a['od']; ?></td><td class="num"><?php echo (int)$a['l']; ?></td><td class="num"><?php echo (int)$a['late']; ?></td><td class="num"><?php echo (int)$a['early']; ?></td>
            <td class="num <?php echo $pct !== null && $pct < 75 ? 'low' : ''; ?>"><?php if ($pct !== null): ?><span class="bar <?php echo $pct < 75 ? 'low' : ''; ?>"><i style="width:<?php echo $pct; ?>%"></i></span><?php echo $pct; ?>%<?php else: ?>—<?php endif; ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
</div>
</body>
</html>

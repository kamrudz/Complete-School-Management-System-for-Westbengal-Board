<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
include("../includes/logger.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/login_attempts.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Teacher portal logins — one row per staff member with portal access: SL, name, user id
 * (State Govt ID), password state. The default password (Teacher@<birth year>) is shown in
 * clear while it is still in force; once the teacher sets their own it is never readable.
 * Row actions: reset to default, set a password by hand, generate a temporary one.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$admin_id = (int)($_SESSION['admin_id'] ?? 0);

function tp_temp_password(): string {
    $a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz'; $d = '23456789'; $out = '';
    for ($i = 0; $i < 10; $i++) $out .= ($i % 3 === 2) ? $d[random_int(0, strlen($d) - 1)] : $a[random_int(0, strlen($a) - 1)];
    return $out;
}

// ---------- POST: reset / set / generate for one row ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $id = (int)($_POST['staff_id'] ?? 0);
    $s = $id > 0 ? db_get_row('SELECT id, staff_name, employee_id, state_govt_id, date_of_birth, service_status, can_login, login_password FROM staff WHERE id = ?', 'i', $id) : null;
    $back = 'teacher_passwords.php?' . http_build_query(array_filter(['search' => $_POST['back_search'] ?? '', 'type' => $_POST['back_type'] ?? '']));
    if (!$s || $s['service_status'] !== 'Active' || (int)$s['can_login'] !== 1) { $_SESSION['error'] = 'This staff member has no portal access.'; header("Location: $back"); exit(); }
    if (empty($s['state_govt_id'])) { $_SESSION['error'] = "{$s['staff_name']}: no State Govt ID on record — it is the username. Add it on Edit Staff first."; header("Location: $back"); exit(); }
    $mode = $_POST['mode'] ?? 'default'; $err = ''; $pw = ''; $must = 1;
    if ($mode === 'default') { $pw = (string)staff_default_password($s['date_of_birth']); if ($pw === '') $err = 'No date of birth on record — the default password needs the birth year.'; }
    elseif ($mode === 'generate') { $pw = tp_temp_password(); }
    else {
        $pw = (string)($_POST['new_password'] ?? ''); $must = !empty($_POST['must_change']) ? 1 : 0;
        if (strlen($pw) < 8) $err = 'At least 8 characters.';
        elseif (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/[0-9]/', $pw)) $err = 'Use at least one letter and one digit.';
        elseif (strcasecmp($pw, $s['state_govt_id']) === 0 || strcasecmp($pw, $s['employee_id']) === 0) $err = 'The password cannot be the ID.';
    }
    if ($err) { $_SESSION['error'] = "{$s['staff_name']}: $err"; header("Location: $back"); exit(); }
    db_update('staff', ['login_password' => password_hash($pw, PASSWORD_DEFAULT), 'pw_must_change' => $must, 'pw_changed_at' => date('Y-m-d H:i:s')], ['id' => $id], 'i');
    clear_login_attempts($conn, 'teacher:' . strtoupper($s['state_govt_id']));
    log_action($admin_id, $s['login_password'] ? 'TEACHER_PASSWORD_RESET' : 'TEACHER_PASSWORD_SET', 'staff', (string)$id, null, "{$s['staff_name']} ({$s['employee_id']}): " . ['default' => 'reset to the default password', 'generate' => 'temporary password generated', 'type' => 'password set by admin'][$mode] . ($must ? ', must change at first login' : ''));
    // a typed / generated password is shown once, right after the redirect
    $_SESSION['tp_shown'] = ['id' => $id, 'pw' => $pw, 'name' => $s['staff_name'], 'user' => $s['state_govt_id']];
    $_SESSION['success'] = "{$s['staff_name']}: password " . ($mode === 'default' ? 'reset to the default' : 'set') . ($must ? ' — must be changed at first login.' : '.');
    header("Location: $back"); exit();
}

// ---------- list ----------
$search = trim((string)($_GET['search'] ?? ''));
$type   = in_array($_GET['type'] ?? '', ['Teaching', 'Non-teaching'], true) ? $_GET['type'] : '';
$where = ["service_status = 'Active'", 'can_login = 1']; $params = []; $types = '';
if ($type !== '') { $where[] = 'staff_type = ?'; $params[] = $type; $types .= 's'; }
if ($search !== '') { $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $search) . '%'; $where[] = '(staff_name LIKE ? OR employee_id LIKE ? OR state_govt_id LIKE ? OR mobile LIKE ?)'; array_push($params, $like, $like, $like, $like); $types .= 'ssss'; }
$rows = db_get_all("SELECT id, employee_id, state_govt_id, staff_name, designation, staff_type, photo, date_of_birth, mobile, pw_must_change, pw_changed_at, last_login_at, (login_password IS NOT NULL AND login_password <> '') AS has_pw
    FROM staff WHERE " . implode(' AND ', $where) . " ORDER BY FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher', 'Librarian', 'Clerk', 'Accountant', 'Group D'), staff_name", $types, ...$params);
$stat = ['total' => count($rows), 'default' => 0, 'own' => 0, 'none' => 0, 'noid' => 0];
foreach ($rows as $r) { if (!$r['state_govt_id']) $stat['noid']++; elseif (!$r['has_pw']) $stat['none']++; elseif ($r['pw_must_change']) $stat['default']++; else $stat['own']++; }
$shown = $_SESSION['tp_shown'] ?? null; unset($_SESSION['tp_shown']);
$portal_url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname(dirname($_SERVER['SCRIPT_NAME'])) . '/teacher/login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Passwords</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .tp-banner { background: linear-gradient(135deg, #4d2c8a 0%, #7a4fd0 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(77,44,138,.25); }
    .tp-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .tp-banner h1 { margin: 0; font-size: 21px; } .tp-banner p { margin: 3px 0 0; font-size: 12.5px; color: #e4dbf7; } .tp-banner p code { background: rgba(255,255,255,.18); padding: 1px 6px; border-radius: 5px; color: #fff; }
    .tp-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .tp-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .tp-banner .links a.solid { background: #fff; color: #4d2c8a; }
    .tp-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .tp-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px; }
    .tp-stat i { width: 38px; height: 38px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 16px; flex: 0 0 38px; }
    .tp-stat b { font-size: 22px; display: block; line-height: 1.1; color: #10253a; } .tp-stat small { color: #6b7d90; font-size: 12px; }
    .tp-stat.t1 i { background: #f3f0fb; color: #5b3fa0; } .tp-stat.t2 i { background: #fff6e5; color: #9a5a00; } .tp-stat.t3 i { background: #ecf9f0; color: #1b7a3d; } .tp-stat.t4 i { background: #fdeeef; color: #9d2630; }
    .tp-show { background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 12px; padding: 12px 16px; margin-bottom: 14px; font-size: 13.5px; }
    .tp-show .pw { font-family: Consolas, monospace; font-size: 20px; letter-spacing: 1.5px; color: #065f46; background: #fff; border: 1px dashed #6ee7b7; border-radius: 8px; padding: 4px 12px; user-select: all; }
    .lc-table .user { font-family: Consolas, monospace; font-weight: 700; color: #1f4e79; background: #eaf2fb; padding: 2px 8px; border-radius: 7px; font-size: 13px; }
    .lc-table .pwd { font-family: Consolas, monospace; font-weight: 700; font-size: 13.5px; padding: 2px 8px; border-radius: 7px; }
    .pwd.def { background: #fff6e5; color: #7a4a00; } .pwd.own { background: #ecf9f0; color: #1b7a3d; } .pwd.none { background: #fdeeef; color: #9d2630; } .pwd.noid { background: #f3f6f9; color: #7a8a9a; }
    .lc-table small { color: #6b7d90; display: block; }
    .lc-actions form { display: inline; } .lc-actions .btn { padding: 4px 9px; margin-right: 4px; }
    .dx-dlg .row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 12px; }
    .dx-dlg .stu { background: #f6f9fc; border: 1px solid #e1eaf2; border-radius: 10px; padding: 10px 12px; font-size: 13.5px; } .dx-dlg .stu small { color: #6b7d90; display: block; }
    .dx-dlg h3 { background: linear-gradient(135deg, #4d2c8a, #7a4fd0) !important; }
    .dx-dlg .chk { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 13.5px; } .dx-dlg .chk input { width: 17px; height: 17px; }
    @media (max-width: 900px) { .tp-stats { grid-template-columns: 1fr 1fr; } .dx-dlg .row2 { grid-template-columns: 1fr; } }
    @media print { .tp-banner .links, .lc-actions, .lc-filter, nav, .main-navbar-2tier { display: none !important; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="tp-banner">
        <div class="ico"><i class="fas fa-key"></i></div>
        <div><h1>Teacher Passwords</h1><p>Portal: <code><?php echo h($portal_url); ?></code> · username = State Govt ID · first password = <code>Teacher@&lt;birth year&gt;</code>, changed by the teacher at first login</p></div>
        <div class="links"><a href="#" onclick="window.print(); return false;"><i class="fas fa-print"></i> Print list</a><a href="staff.php" class="solid"><i class="fas fa-arrow-left"></i> Staff list</a></div>
    </div>

    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>
    <?php if ($shown): ?>
    <div class="tp-show"><i class="fas fa-check-circle" style="color:#059669"></i> Hand this to <b><?php echo h($shown['name']); ?></b> — username <b><?php echo h($shown['user']); ?></b>, password <span class="pw"><?php echo h($shown['pw']); ?></span> <small style="color:#047857">(shown once; after they change it nobody can read it)</small></div>
    <?php endif; ?>

    <div class="tp-stats">
        <div class="tp-stat t1"><i class="fas fa-users"></i><div><b><?php echo $stat['total']; ?></b><small>Staff with portal access</small></div></div>
        <div class="tp-stat t2"><i class="fas fa-unlock"></i><div><b><?php echo $stat['default']; ?></b><small>Still on the default password</small></div></div>
        <div class="tp-stat t3"><i class="fas fa-user-lock"></i><div><b><?php echo $stat['own']; ?></b><small>Set their own password</small></div></div>
        <div class="tp-stat t4"><i class="fas fa-exclamation-circle"></i><div><b><?php echo $stat['none'] + $stat['noid']; ?></b><small>Cannot log in yet (no password / no Govt ID)</small></div></div>
    </div>

    <form method="get" class="lc-filter">
        <div><label>Type</label><select name="type"><option value="">All</option><option value="Teaching" <?php echo $type === 'Teaching' ? 'selected' : ''; ?>>Teaching</option><option value="Non-teaching" <?php echo $type === 'Non-teaching' ? 'selected' : ''; ?>>Non-teaching</option></select></div>
        <div><label>Search</label><input type="text" name="search" value="<?php echo h($search); ?>" placeholder="Name, Employee ID, Govt ID, mobile" style="min-width:260px"></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Apply</button>
        <?php if ($type !== '' || $search !== ''): ?><a href="teacher_passwords.php" class="btn btn-secondary">Reset</a><?php endif; ?>
    </form>

    <?php if (!$rows): ?>
    <div class="lc-empty"><i class="fas fa-key"></i>No staff with portal access<?php echo $search !== '' || $type !== '' ? ' match this filter' : ''; ?>.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
    <table class="lc-table">
        <thead><tr><th>SL</th><th>Teacher</th><th>User ID</th><th>Password</th><th>Last login</th><th>Actions</th></tr></thead>
        <tbody>
        <?php $sl = 0; foreach ($rows as $r): $sl++; $def = staff_default_password($r['date_of_birth']);
            if (!$r['state_govt_id']) { $cls = 'noid'; $txt = 'no Govt ID'; $note = 'add the State Govt ID on Edit Staff'; }
            elseif (!$r['has_pw']) { $cls = 'none'; $txt = 'not set'; $note = 'use Reset to default'; }
            elseif ($r['pw_must_change']) { $cls = 'def'; $txt = $def ?: 'temporary'; $note = 'default — must be changed at first login'; }
            else { $cls = 'own'; $txt = '••••••••'; $note = 'own password' . ($r['pw_changed_at'] ? ' since ' . date('d-m-Y', strtotime($r['pw_changed_at'])) : ''); } ?>
        <tr>
            <td><?php echo $sl; ?></td>
            <td><div class="lc-stu"><?php echo $r['photo'] ? '<img src="' . h(staff_photo_url($r['photo'])) . '" alt="">' : '<span class="noimg">' . h(mb_substr($r['staff_name'], 0, 1)) . '</span>'; ?><div><a href="view_staff.php?id=<?php echo (int)$r['id']; ?>"><?php echo h($r['staff_name']); ?></a><small><?php echo h($r['designation']); ?> · <?php echo h($r['employee_id']); ?></small></div></div></td>
            <td><?php echo $r['state_govt_id'] ? '<span class="user">' . h($r['state_govt_id']) . '</span>' : '<span class="pwd noid">—</span>'; ?></td>
            <td><span class="pwd <?php echo $cls; ?>"><?php echo h($txt); ?></span><small><?php echo h($note); ?></small></td>
            <td><?php echo $r['last_login_at'] ? date('d-m-Y H:i', strtotime($r['last_login_at'])) : '<span style="color:#9aa9b8">never</span>'; ?></td>
            <td class="lc-actions">
                <?php if ($r['state_govt_id']): ?>
                <form method="post" onsubmit="return confirm('Reset <?php echo h(addslashes($r['staff_name'])); ?> to the default password <?php echo h($def ?: ''); ?>? They will have to change it at first login.')"><?php echo csrf_field(); ?><input type="hidden" name="staff_id" value="<?php echo (int)$r['id']; ?>"><input type="hidden" name="mode" value="default"><input type="hidden" name="back_search" value="<?php echo h($search); ?>"><input type="hidden" name="back_type" value="<?php echo h($type); ?>"><button type="submit" class="btn btn-warning btn-sm" title="Reset to default" <?php echo $def ? '' : 'disabled'; ?>><i class="fas fa-undo"></i> Default</button></form>
                <button type="button" class="btn btn-primary btn-sm" onclick="tpOpen(<?php echo h(json_encode(['id' => (int)$r['id'], 'name' => $r['staff_name'], 'user' => $r['state_govt_id'], 'desig' => $r['designation']])); ?>)"><i class="fas fa-pen"></i> Set manually</button>
                <?php else: ?><a href="edit_staff.php?id=<?php echo (int)$r['id']; ?>" class="btn btn-secondary btn-sm"><i class="fas fa-edit"></i> Add Govt ID</a><?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <?php endif; ?>
</div>

<div class="lc-modal" id="tpModal">
    <form class="lc-dialog dx-dlg" method="post" autocomplete="off">
        <?php echo csrf_field(); ?><input type="hidden" name="staff_id" id="tpId"><input type="hidden" name="back_search" value="<?php echo h($search); ?>"><input type="hidden" name="back_type" value="<?php echo h($type); ?>">
        <h3><i class="fas fa-key"></i> Set password manually</h3>
        <div class="body">
            <div class="stu"><b id="tpName"></b> <span class="lc-uid" id="tpUser"></span><small id="tpDesig"></small></div>
            <div class="row2">
                <div><label>Password</label><input type="text" name="new_password" id="tpPw" minlength="8" required placeholder="at least 8, a letter and a digit"></div>
                <div><label>&nbsp;</label><button type="button" class="btn btn-secondary" style="width:100%" onclick="tpGen()"><i class="fas fa-random"></i> Suggest one</button></div>
            </div>
            <input type="hidden" name="mode" value="type">
            <label class="chk"><input type="checkbox" name="must_change" value="1" checked> Ask them to change it at first login</label>
            <div class="note">Shown once on the next page after saving. Not the Govt ID / Employee ID.</div>
        </div>
        <div class="foot"><button type="button" class="btn btn-secondary" onclick="document.getElementById('tpModal').classList.remove('open')">Cancel</button><button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Save password</button></div>
    </form>
</div>
<script>
function tpOpen(s) { document.getElementById('tpId').value = s.id; document.getElementById('tpName').textContent = s.name; document.getElementById('tpUser').textContent = s.user; document.getElementById('tpDesig').textContent = s.desig; document.getElementById('tpPw').value = ''; document.getElementById('tpModal').classList.add('open'); document.getElementById('tpPw').focus(); }
function tpGen() { var a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz', d = '23456789', o = ''; for (var i = 0; i < 10; i++) o += (i % 3 === 2) ? d[Math.floor(Math.random() * d.length)] : a[Math.floor(Math.random() * a.length)]; document.getElementById('tpPw').value = o; }
document.getElementById('tpModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/routine_helper.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Teacher routine — one teacher's week (class-section + subject per period) or every teacher
 * as a booklet (one per page).  Weekly count against the designation limit.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$session_id = (int)($_GET['session_id'] ?? ($active['id'] ?? 0));
$session = null; foreach ($sessions as $ss) if ((int)$ss['id'] === $session_id) $session = $ss;
$teacher_id = (int)($_GET['teacher_id'] ?? 0); $all = !empty($_GET['all']);
$teachers = routine_teachers(); $limits = routine_workload_limits(); $s = routine_settings();
if ($teacher_id && !isset($teachers[$teacher_id])) { $t = db_get_row('SELECT id, staff_name, short_code, designation FROM staff WHERE id = ?', 'i', $teacher_id); if ($t) $teachers[$teacher_id] = $t; else $teacher_id = 0; }
$periods = routine_periods(); $sat = $s['saturday_periods'];

// unit label per (class, section) so a pair shows as "V-A + B" and a combined slot lists every section it covers
$unit_label = []; $unit_of = [];
foreach (db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order') as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $unit_label[$k] = $c['class_name'] . '-' . $u['label']; foreach ($u['section_ids'] as $sid) $unit_of[$sid] = $k; }
$rows = db_get_all('SELECT r.teacher_id, r.day_name, r.period_id, r.class_id, r.section_id, r.group_id, r.subject_id, sub.subject_name, c.class_name, s.section_name
                    FROM routine r JOIN classes c ON c.id = r.class_id JOIN sections s ON s.id = r.section_id LEFT JOIN subjects sub ON sub.id = r.subject_id
                    WHERE r.session_id = ? AND r.teacher_id IS NOT NULL' . ($all ? '' : ' AND r.teacher_id = ?') . ' ORDER BY c.sort_order, s.section_name', $all ? 'i' : 'ii', ...($all ? [$session_id] : [$session_id, $teacher_id]));
$week = []; // teacher => day => pid => slotkey => ['subject','units'=>[label...], 'sections'=>[names]]
foreach ($rows as $r) {
    $t = (int)$r['teacher_id']; $k = $r['class_id'] . '|' . $r['subject_id'] . '|' . $r['group_id'];
    $cell = &$week[$t][$r['day_name']][(int)$r['period_id']][$k];
    $cell = $cell ?? ['subject' => $r['subject_name'] ?? '—', 'class' => $r['class_name'], 'units' => [], 'sections' => []];
    $u = $unit_of[(int)$r['section_id']] ?? null; if ($u) $cell['units'][$u] = $unit_label[$u]; $cell['sections'][] = $r['section_name'];
    unset($cell);
}
$list = $all ? $teachers : ($teacher_id ? [$teacher_id => $teachers[$teacher_id]] : []);
function tr_render(array $tw): array {
    $periods = routine_periods(); $sat = routine_settings()['saturday_periods']; $n = 0;
    $o = '<table class="rv"><thead><tr><th class="d">Day</th>';
    foreach ($periods as $p) $o .= '<th>' . h($p['period_name']) . ($p['start_time'] ? '<small>' . h(routine_time($p['start_time']) . '–' . routine_time($p['end_time'])) . '</small>' : '') . '</th>';
    $o .= '</tr></thead><tbody>';
    foreach (routine_days() as $day) {
        $o .= '<tr><td class="d">' . routine_day_short($day) . '</td>';
        foreach ($periods as $i => $p) {
            $pid = (int)$p['id'];
            if ($day === 'Saturday' && $i >= $sat) { $o .= '<td class="off"></td>'; continue; }
            $slots = $tw[$day][$pid] ?? [];
            if (!$slots) { $o .= '<td class="e"></td>'; continue; }
            $n++; $parts = [];
            foreach ($slots as $c) { $where = $c['units'] ? implode(', ', $c['units']) : $c['class'] . '-' . implode(',', array_unique($c['sections'])); $parts[] = '<b>' . h($where) . '</b><span>' . h($c['subject']) . '</span>'; }
            $o .= '<td class="' . (count($slots) > 1 ? 'c' : '') . '">' . implode('', $parts) . '</td>';
        }
        $o .= '</tr>';
    }
    return [$o . '</tbody></table>', $n];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Routine</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); echo routine_view_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #0b3d5c; }
    .blk { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 14px 16px; margin-bottom: 16px; }
    .blk .hd { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 8px; } .blk .hd h2 { margin: 0; font-size: 16px; color: #0b3d5c; } .blk .hd small { color: #6b7d90; }
    .blk .hd .load { margin-left: auto; font-weight: 800; font-size: 13px; padding: 4px 12px; border-radius: 999px; background: #eef6fc; color: #0b3d5c; border: 1px solid #b7d7ee; } .blk .hd .load.over { background: #fff6e5; color: #7a4a00; border-color: #f0c987; } .blk .hd .load.zero { background: #f3f6f9; color: #8a9aab; border-color: #dfe7ef; }
    .rv td b { font-size: 12px; }
    .tlist { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 12px; } .tlist a { border: 1px solid #dfe7ef; border-radius: 999px; padding: 4px 11px; font-size: 12.5px; text-decoration: none; color: #10253a; background: #fff; } .tlist a.on { background: #0b3d5c; color: #fff; border-color: #0b3d5c; } .tlist a small { color: #6b7d90; margin-left: 4px; } .tlist a.on small { color: #d6e8f5; }
    .print-head { display: none; }
    @media print {
        @page { size: A4 landscape; margin: 9mm; }
        html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; }
        .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; }
        .rt-banner, .lc-filter, .tlist, .lc-empty { display: none !important; }
        .blk { border: 0; padding: 0; margin: 0; page-break-after: always; break-after: page; } .blk:last-child { page-break-after: auto; }
        .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #0b3d5c; padding-bottom: 5px; margin-bottom: 8px; } .print-head img { width: 42px; height: 42px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #0b3d5c; } .print-head small { color: #444; font-size: 10.5px; }
    }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-chalkboard-teacher"></i></div>
        <div><h1>Teacher Routine</h1><p>Session <?php echo h($session['session_name'] ?? ''); ?> · each cell: class-section and subject; the weekly count is checked against the designation limit.</p></div>
        <div class="links"><a href="class_routine.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-table"></i> Class routines</a><a href="teacher_workload_report.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-balance-scale"></i> Workload</a><?php if ($list): ?><a href="#" class="solid" onclick="window.print();return false;"><i class="fas fa-print"></i> Print<?php echo count($list) > 1 ? ' (' . count($list) . ' pages)' : ''; ?></a><?php endif; ?></div>
    </div>
    <form method="get" class="lc-filter">
        <div><label>Session</label><select name="session_id" onchange="this.form.submit()"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div>
        <div><label>Teacher</label><select name="teacher_id" onchange="this.form.submit()"><option value="">— choose —</option><?php foreach ($teachers as $id => $t): ?><option value="<?php echo $id; ?>" <?php echo $id === $teacher_id && !$all ? 'selected' : ''; ?>><?php echo h(($t['short_code'] ? $t['short_code'] . ' — ' : '') . $t['staff_name']); ?></option><?php endforeach; ?></select></div>
        <button type="submit" class="btn btn-primary"><i class="fas fa-eye"></i> Show</button>
        <a href="?session_id=<?php echo $session_id; ?>&all=1" class="btn btn-secondary"><i class="fas fa-book"></i> All teachers</a>
    </form>
    <?php if (!$all): ?><div class="tlist"><?php foreach ($teachers as $id => $t): $n = 0; foreach ($week[$id] ?? [] as $d) foreach ($d as $pp) $n++; ?><a href="?session_id=<?php echo $session_id; ?>&teacher_id=<?php echo $id; ?>" class="<?php echo $id === $teacher_id ? 'on' : ''; ?>"><?php echo h($t['short_code'] ?: $t['staff_name']); ?></a><?php endforeach; ?></div><?php endif; ?>

    <?php if (!$list): ?><div class="lc-empty"><i class="fas fa-hand-pointer"></i>Choose a teacher, or "All teachers" for the booklet.</div><?php endif; ?>
    <?php foreach ($list as $id => $t): [$html, $n] = tr_render($week[$id] ?? []); $lim = (int)($limits[$t['designation']] ?? 0); ?>
    <div class="blk">
        <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?></h2><small>Teacher routine · session <?php echo h($session['session_name'] ?? ''); ?> · printed <?php echo date('d-m-Y'); ?></small></div></div>
        <div class="hd"><h2><i class="fas fa-user-tie"></i> <?php echo h($t['staff_name']); ?><?php echo $t['short_code'] ? ' (' . h($t['short_code']) . ')' : ''; ?></h2><small><?php echo h($t['designation']); ?></small><span class="load <?php echo !$n ? 'zero' : ($lim && $n > $lim ? 'over' : ''); ?>"><?php echo $n; ?><?php echo $lim ? ' / ' . $lim : ''; ?> periods a week<?php echo $lim && $n > $lim ? ' — over the limit' : ''; ?></span></div>
        <?php echo $html; ?>
    </div>
    <?php endforeach; ?>
</div>
</body>
</html>

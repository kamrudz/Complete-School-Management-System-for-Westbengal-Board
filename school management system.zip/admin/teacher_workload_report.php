<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/routine_helper.php';
require_once '../includes/simple_xlsx_writer.php';
require_once '../includes/lifecycle_ui.php';

/**
 * Teacher workload:  weekly (from the routine: periods per class, total, weighted, against the
 * designation limit) · monthly (actual periods per day = own − closed + substitutions).  Excel.
 */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$active = db_get_row("SELECT id, session_name FROM academic_sessions WHERE status = 'Active' LIMIT 1") ?: [];
$sessions = db_get_all('SELECT id, session_name, status FROM academic_sessions ORDER BY id DESC');
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$session_id = (int)($_GET['session_id'] ?? ($active['id'] ?? 0));
$view = ($_GET['view'] ?? 'week') === 'month' ? 'month' : 'week';
$month = (int)($_GET['month'] ?? date('n')); $year = (int)($_GET['year'] ?? date('Y')); if ($month < 1 || $month > 12) $month = (int)date('n'); if ($year < 2000 || $year > 2100) $year = (int)date('Y');
$teachers = routine_teachers(); $limits = routine_workload_limits(); $s = routine_settings(); $w = $s['hs_period_weight'];
$classes = db_get_all('SELECT id, class_name FROM classes ORDER BY sort_order');

if ($view === 'week') {
    $rows = db_get_all("SELECT r.teacher_id, r.class_id, r.day_name, r.period_id, r.subject_id, c.class_name FROM routine r JOIN classes c ON c.id = r.class_id WHERE r.session_id = ? AND r.teacher_id IS NOT NULL GROUP BY r.teacher_id, r.day_name, r.period_id, r.class_id, r.subject_id", 'i', $session_id);
    $sat = $s['saturday_periods']; $sat_ok = array_slice(array_map(fn($p) => (int)$p['id'], routine_periods()), 0, $sat);
    $per = []; $tot = []; $wt = []; $days = [];
    foreach ($rows as $r) { if ($r['day_name'] === 'Saturday' && !in_array((int)$r['period_id'], $sat_ok, true)) continue; $t = (int)$r['teacher_id']; $per[$t][(int)$r['class_id']] = ($per[$t][(int)$r['class_id']] ?? 0) + 1; $tot[$t] = ($tot[$t] ?? 0) + 1; $wt[$t] = ($wt[$t] ?? 0) + (in_array($r['class_name'], ['XI', 'XII'], true) ? $w : 1); $days[$t][$r['day_name']] = ($days[$t][$r['day_name']] ?? 0) + 1; }
    $xlsx = [array_merge(['Teacher', 'Designation'], array_map(fn($c) => $c['class_name'], $classes), ['Total', 'Weighted', 'Limit', 'Over by'])];
    foreach ($teachers as $id => $t) { $lim = (int)($limits[$t['designation']] ?? 0); $line = [$t['staff_name'], $t['designation']]; foreach ($classes as $c) $line[] = $per[$id][(int)$c['id']] ?? ''; $line[] = (int)($tot[$id] ?? 0); $line[] = round($wt[$id] ?? 0, 2); $line[] = $lim ?: ''; $line[] = $lim && ($tot[$id] ?? 0) > $lim ? ($tot[$id] - $lim) : ''; $xlsx[] = $line; }
    $title = 'Weekly workload — session ' . ($active['session_name'] ?? '');
    $busiest = []; foreach (routine_days() as $d) { $busiest[$d] = 0; foreach ($days as $t => $dd) $busiest[$d] += $dd[$d] ?? 0; }
} else {
    $first = sprintf('%04d-%02d-01', $year, $month); $last = date('Y-m-t', strtotime($first)); if ($last > date('Y-m-d')) $last = date('Y-m-d');
    $dl = routine_daily_load($session_id, $first, $last); $dates = array_keys($dl['days']);
    $cell = []; $tot = [];
    foreach ($dl['load'] as $d => $per) foreach ($per as $t => $l) { $away = in_array($l['status'], ['absent', 'leave', 'on_duty'], true); $n = $away ? $l['subs'] : $l['regular'] - $l['lost'] + $l['subs']; $cell[$t][$d] = ['n' => $n, 'subs' => $l['subs'], 'closed' => $l['closed'], 'away' => $away ? $l['status'] : null]; $tot[$t] = ($tot[$t] ?? 0) + $n; }
    $xlsx = [array_merge(['Teacher'], array_map(fn($d) => (int)substr($d, 8, 2), $dates), ['Total'])];
    foreach ($teachers as $id => $t) { $line = [$t['staff_name']]; foreach ($dates as $d) { $c = $cell[$id][$d] ?? null; $line[] = $c ? ($c['away'] ? ($c['n'] ?: 'A') : $c['n']) : ''; } $line[] = (int)($tot[$id] ?? 0); $xlsx[] = $line; }
    $title = 'Actual workload — ' . date('F Y', strtotime($first));
}
if (!empty($_GET['xlsx'])) SimpleXLSXWriter::download('workload_' . $view . '_' . date('Y-m-d') . '.xlsx', $xlsx, 'Workload', ['header_rows' => 1, 'freeze_rows' => 1]);
$q = array_filter(['view' => $view, 'session_id' => $session_id, 'month' => $view === 'month' ? $month : null, 'year' => $view === 'month' ? $year : null]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Workload</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<?php lifecycle_styles(); ?>
<style>
    .rt-banner { background: linear-gradient(135deg, #0b3d5c 0%, #1a6fa3 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(11,61,92,.25); }
    .rt-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .rt-banner h1 { margin: 0; font-size: 21px; } .rt-banner p { margin: 3px 0 0; font-size: 12.5px; color: #d6e8f5; }
    .rt-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .rt-banner .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; } .rt-banner .links a.solid { background: #fff; color: #0b3d5c; }
    .tabs { display: flex; gap: 6px; margin-bottom: 12px; flex-wrap: wrap; } .tabs a { padding: 8px 16px; border-radius: 999px; border: 1px solid #c9d6e2; background: #fff; color: #0b3d5c; text-decoration: none; font-weight: 600; font-size: 13.5px; } .tabs a.on { background: #0b3d5c; color: #fff; border-color: #0b3d5c; }
    .hd { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 10px; } .hd h3 { margin: 0; font-size: 15px; color: #0b3d5c; }
    .lc-table td.num { text-align: center; font-variant-numeric: tabular-nums; } .lc-table td.tot { font-weight: 800; background: #f8fafc; } .lc-table td.over { background: #fff6e5; color: #7a4a00; font-weight: 800; } .lc-table td.zero { color: #b0bec9; }
    .bar { display: inline-block; width: 90px; height: 8px; background: #eef2f6; border-radius: 4px; vertical-align: middle; margin-right: 6px; overflow: hidden; } .bar i { display: block; height: 100%; background: #1a6fa3; } .bar.over i { background: #d08a2a; }
    .side { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; font-size: 12.5px; } .side span { background: #f3f6f9; border-radius: 999px; padding: 4px 11px; }
    .rg-wrap { overflow: auto; border: 1px solid #dfe7ef; border-radius: 10px; background: #fff; } table.rg { border-collapse: collapse; font-size: 12px; min-width: 100%; } .rg th, .rg td { border: 1px solid #e6edf3; padding: 3px 4px; text-align: center; white-space: nowrap; } .rg th { background: #0b3d5c; color: #fff; font-size: 11px; position: sticky; top: 0; } .rg th small { display: block; font-weight: 400; font-size: 9px; opacity: .85; } .rg th.off { background: #6b7d90; } .rg td.off { background: #eef2f6; } .rg .nm { text-align: left; min-width: 160px; position: sticky; left: 0; background: #fff; } .rg th.nm { z-index: 2; } .rg td.away { background: #fde2e4; color: #9d2630; font-weight: 700; } .rg td.sub { box-shadow: inset 0 -3px 0 #b0632a; } .rg td.tot { font-weight: 800; background: #f8fafc; }
    .legend { display: flex; gap: 14px; flex-wrap: wrap; font-size: 12px; color: #3b5168; margin: 8px 0; } .legend i { display: inline-block; width: 12px; height: 12px; border-radius: 3px; vertical-align: -1px; margin-right: 4px; border: 1px solid #d5dee7; }
    .print-head { display: none; }
    @media print { @page { size: A4 landscape; margin: 8mm; } html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; } body > *:not(.page-box) { display: none !important; } .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; } .rt-banner, .tabs, .lc-filter { display: none !important; } .print-head { display: flex; align-items: center; gap: 10px; border-bottom: 2px solid #0b3d5c; padding-bottom: 6px; margin-bottom: 8px; } .print-head img { width: 44px; height: 44px; object-fit: contain; } .print-head h2 { margin: 0; font-size: 15px; color: #0b3d5c; } .print-head small { color: #444; font-size: 10.5px; } .rg-wrap { border: 0; overflow: visible; } .rg .nm { position: static; } .bar { display: none; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?> — <?php echo h($title); ?></h2><small>printed <?php echo date('d-m-Y'); ?></small></div></div>
    <div class="rt-banner">
        <div class="ico"><i class="fas fa-balance-scale"></i></div>
        <div><h1>Teacher Workload</h1><p>Weekly: periods per class from the routine against the designation limit (XI/XII weighted ×<?php echo h(rtrim(rtrim(number_format($w, 2), '0'), '.')); ?>). Monthly: what was actually taken — own periods, minus closed, plus substitutions.</p></div>
        <div class="links"><a href="teacher_routine.php?session_id=<?php echo $session_id; ?>"><i class="fas fa-chalkboard-teacher"></i> Teacher routines</a><a href="routine_settings.php#general"><i class="fas fa-sliders-h"></i> Limits</a><a href="#" onclick="window.print();return false;"><i class="fas fa-print"></i> Print</a><a href="?<?php echo h(http_build_query($q + ['xlsx' => 1])); ?>" class="solid"><i class="fas fa-file-excel"></i> Excel</a></div>
    </div>
    <div class="tabs"><a href="?view=week&session_id=<?php echo $session_id; ?>" class="<?php echo $view === 'week' ? 'on' : ''; ?>"><i class="fas fa-calendar-week"></i> Weekly (routine)</a><a href="?view=month&session_id=<?php echo $session_id; ?>" class="<?php echo $view === 'month' ? 'on' : ''; ?>"><i class="fas fa-calendar-alt"></i> Monthly (actual)</a></div>
    <form method="get" class="lc-filter">
        <input type="hidden" name="view" value="<?php echo $view; ?>">
        <div><label>Session</label><select name="session_id"><?php foreach ($sessions as $ss): ?><option value="<?php echo (int)$ss['id']; ?>" <?php echo (int)$ss['id'] === $session_id ? 'selected' : ''; ?>><?php echo h($ss['session_name']); ?><?php echo $ss['status'] === 'Active' ? ' (Active)' : ''; ?></option><?php endforeach; ?></select></div>
        <?php if ($view === 'month'): ?><div><label>Month</label><select name="month"><?php for ($m = 1; $m <= 12; $m++): ?><option value="<?php echo $m; ?>" <?php echo $m === $month ? 'selected' : ''; ?>><?php echo date('F', mktime(0, 0, 0, $m, 1)); ?></option><?php endfor; ?></select></div><div><label>Year</label><select name="year"><?php for ($y = (int)date('Y') - 3; $y <= (int)date('Y'); $y++): ?><option value="<?php echo $y; ?>" <?php echo $y === $year ? 'selected' : ''; ?>><?php echo $y; ?></option><?php endfor; ?></select></div><?php endif; ?>
        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Show</button>
    </form>
    <div class="hd"><h3><?php echo h($title); ?></h3></div>

    <?php if (!$teachers): ?><div class="lc-empty"><i class="fas fa-user-slash"></i>No active teaching staff.</div>
    <?php elseif ($view === 'week'): ?>
        <div class="side"><span><?php echo array_sum($tot); ?> periods a week in the routine</span><?php foreach ($busiest as $d => $n) echo '<span>' . routine_day_short($d) . ' ' . $n . '</span>'; ?></div>
        <div style="overflow-x:auto"><table class="lc-table"><thead><tr><th>Teacher</th><?php foreach ($classes as $c): ?><th style="text-align:center"><?php echo h($c['class_name']); ?></th><?php endforeach; ?><th style="text-align:center">Total</th><?php if ($w != 1.0): ?><th style="text-align:center">Weighted</th><?php endif; ?><th>Against limit</th></tr></thead><tbody>
        <?php foreach ($teachers as $id => $t): $n = (int)($tot[$id] ?? 0); $lim = (int)($limits[$t['designation']] ?? 0); $pct = $lim ? min(100, round($n / $lim * 100)) : 0; $over = $lim && $n > $lim; ?>
        <tr><td><b><?php echo h($t['staff_name']); ?></b><br><small style="color:#6b7d90"><?php echo h(($t['short_code'] ? $t['short_code'] . ' · ' : '') . $t['designation']); ?></small></td>
            <?php foreach ($classes as $c): $v = $per[$id][(int)$c['id']] ?? 0; ?><td class="num <?php echo $v ? '' : 'zero'; ?>"><?php echo $v ?: '·'; ?></td><?php endforeach; ?>
            <td class="num tot <?php echo $over ? 'over' : ''; ?>"><?php echo $n; ?></td><?php if ($w != 1.0): ?><td class="num"><?php echo rtrim(rtrim(number_format($wt[$id] ?? 0, 2), '0'), '.'); ?></td><?php endif; ?>
            <td><?php if ($lim): ?><span class="bar <?php echo $over ? 'over' : ''; ?>"><i style="width:<?php echo $pct; ?>%"></i></span><?php echo $n; ?> / <?php echo $lim; ?><?php echo $over ? ' <b style="color:#7a4a00">+' . ($n - $lim) . ' over</b>' : ''; ?><?php else: ?><span style="color:#8a9aab">no limit set</span><?php endif; ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
    <?php else: ?>
        <div class="legend"><span><i style="background:#fde2e4"></i> away (absent / leave / on duty) — only substitutions count</span><span><i style="box-shadow:inset 0 -3px 0 #b0632a"></i> includes substitution</span><span><i style="background:#eef2f6"></i> Sunday / holiday</span></div>
        <div class="rg-wrap"><table class="rg"><thead><tr><th class="nm">Teacher</th><?php foreach ($dates as $d): $i = $dl['days'][$d]; ?><th class="<?php echo $i['sunday'] || $i['holiday'] ? 'off' : ''; ?>" title="<?php echo h($i['holiday'] ?? ($i['sunday'] ? 'Sunday' : date('l', strtotime($d)))); ?>"><?php echo (int)substr($d, 8, 2); ?><small><?php echo substr(date('D', strtotime($d)), 0, 2); ?></small></th><?php endforeach; ?><th>Total</th></tr></thead><tbody>
        <?php foreach ($teachers as $id => $t): ?><tr><td class="nm"><b><?php echo h($t['staff_name']); ?></b><br><small style="color:#6b7d90"><?php echo h($t['designation']); ?></small></td>
            <?php foreach ($dates as $d): $i = $dl['days'][$d]; $c = $cell[$id][$d] ?? null; if ($i['sunday'] || $i['holiday']) { echo '<td class="off"></td>'; continue; } if (!$c) { echo '<td></td>'; continue; } ?><td class="<?php echo $c['away'] ? 'away' : ''; ?><?php echo $c['subs'] ? ' sub' : ''; ?>" title="<?php echo $c['away'] ? h(ucfirst(str_replace('_', ' ', $c['away']))) . ' · ' : ''; ?>own <?php echo $c['n'] - $c['subs']; ?>, subs <?php echo $c['subs']; ?>, closed <?php echo $c['closed']; ?>"><?php echo $c['n'] ?: ($c['away'] ? 'A' : '0'); ?></td><?php endforeach; ?>
            <td class="tot"><?php echo (int)($tot[$id] ?? 0); ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
/**
 * admin/user_access.php — User Access Control
 * Admin decides which pages/features students & teachers can access, and which
 * profile fields students may edit themselves (checkbox based).
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/user_access.php';
require_once '../includes/logger.php';

ua_ensure_table($conn);

$success = '';
$error   = '';

// ===== SAVE STUDENT FEATURES =====
if (isset($_POST['save_student'])) {
    verify_csrf_or_die();
    $posted = $_POST['access'] ?? [];
    $all_keys = array_merge(array_keys(ua_all_keys()['student']), array_keys(ua_student_edit_fields()));
    $stmt = mysqli_prepare($conn, "UPDATE `user_access_permissions` SET `is_allowed`=? WHERE `user_type`='student' AND `access_key`=?");
    foreach ($all_keys as $key) {
        $val = isset($posted[$key]) && (int)$posted[$key] === 1 ? 1 : 0;
        mysqli_stmt_bind_param($stmt, 'is', $val, $key);
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
    try {
        log_action($_SESSION['admin_id'] ?? 0, 'USER_ACCESS_STUDENT_UPDATED', 'user_access_permissions', null, null, json_encode(array_map(fn($k) => isset($posted[$k]) ? 1 : 0, $all_keys), JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) { error_log("Access log failed: " . $e->getMessage()); }
    $success = "Student access settings saved!";
}

// ===== SAVE TEACHER FEATURES =====
if (isset($_POST['save_teacher'])) {
    verify_csrf_or_die();
    $posted = $_POST['access'] ?? [];
    $stmt = mysqli_prepare($conn, "UPDATE `user_access_permissions` SET `is_allowed`=? WHERE `user_type`='teacher' AND `access_key`=?");
    foreach (array_keys(ua_all_keys()['teacher']) as $key) {
        $val = isset($posted[$key]) && (int)$posted[$key] === 1 ? 1 : 0;
        mysqli_stmt_bind_param($stmt, 'is', $val, $key);
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);
    try {
        log_action($_SESSION['admin_id'] ?? 0, 'USER_ACCESS_TEACHER_UPDATED', 'user_access_permissions', null, null, json_encode(array_map(fn($k) => isset($posted[$k]) ? 1 : 0, array_keys(ua_all_keys()['teacher'])), JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) { error_log("Access log failed: " . $e->getMessage()); }
    $success = "Teacher access settings saved!";
}

$map = ua_access_map($conn);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Access</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .access-card { background:#fff; border:1px solid #e4edf6; border-radius:12px; padding:20px; margin-bottom:22px; }
        .access-card h3 { margin:0 0 4px; color:#003366; font-size:16px; }
        .access-card .sub { color:#6b7f92; font-size:12px; margin-bottom:16px; }
        .access-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:12px; }
        .access-item { border:1px solid #e4edf6; border-radius:10px; padding:12px 14px; background:#fafcfe; }
        .access-item .label-row { display:flex; align-items:center; justify-content:space-between; gap:10px; }
        .access-item .label-row b { font-size:13.5px; color:#1a3b55; }
        .access-item .hint { font-size:11.5px; color:#8a97a5; margin-top:3px; }
        .switch { position:relative; display:inline-block; width:42px; height:24px; flex-shrink:0; }
        .switch input { opacity:0; width:0; height:0; }
        .slider { position:absolute; cursor:pointer; inset:0; background:#cbd5e0; transition:.25s; border-radius:24px; }
        .slider:before { content:""; position:absolute; height:18px; width:18px; left:3px; bottom:3px; background:#fff; transition:.25s; border-radius:50%; box-shadow:0 1px 3px rgba(0,0,0,.25); }
        .switch input:checked + .slider { background:#16a34a; }
        .switch input:checked + .slider:before { transform:translateX(18px); }
        .section-sub { margin:18px 0 10px; padding-top:14px; border-top:2px dashed #e4edf6; font-weight:800; color:#0f4c81; font-size:13.5px; display:flex; align-items:center; gap:8px; }
        .btn-save { padding:9px 22px; background:#003366; color:#fff; border:none; border-radius:8px; font-weight:700; cursor:pointer; }
        .btn-save:hover { background:#0f4c81; }
        .alert-success { background:#d4edda; color:#155724; padding:10px 16px; border-radius:8px; margin-bottom:16px; font-weight:600; }
        .alert-error { background:#f8d7da; color:#721c24; padding:10px 16px; border-radius:8px; margin-bottom:16px; font-weight:600; }
        .badge-master { background:#fff3cd; color:#856404; font-size:10.5px; font-weight:700; padding:2px 8px; border-radius:10px; }
        .readonly-note { background:#f0f4f9; border:1px solid #e4edf6; border-radius:8px; padding:10px 14px; font-size:12px; color:#5a6b7a; margin-top:12px; }
    </style>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-title" style="margin-bottom:18px;"><i class="fas fa-user-shield"></i> User Access Control</div>
    <div style="font-size:13px; color:#6b7f92; margin-bottom:16px;">
        Checkbox <b>ON</b> holo sei feature/user er jonno <b>access thakbe</b>. Bandon korle oi link hide + direct URL o block hobe.
    </div>
    <?php if ($success): ?><div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- ===================== STUDENT PORTAL ===================== -->
    <form method="post" class="access-card">
        <?php echo csrf_field(); ?>
        <h3><i class="fas fa-user-graduate"></i> Student Portal Access</h3>
        <div class="sub">Student login e kon kon section access pabe.</div>

        <div class="access-grid">
            <?php foreach (ua_all_keys()['student'] as $key => $meta): ?>
                <?php if (strpos($key, 'edit_') === 0) continue; ?>
                <div class="access-item">
                    <div class="label-row">
                        <b><?php echo htmlspecialchars($meta[0]); ?></b>
                        <label class="switch">
                            <input type="checkbox" name="access[<?php echo $key; ?>]" value="1" <?php echo !empty($map['student'][$key]) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="hint"><?php echo htmlspecialchars($meta[1] ?? ''); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="section-sub"><i class="fas fa-edit"></i> Student Self-Edit Fields <span class="badge-master">eigulo sudhu feature_edit_profile ON thakle kaj korbe</span></div>
        <div class="access-grid">
            <?php foreach (ua_student_edit_fields() as $key => $block): ?>
                <div class="access-item">
                    <div class="label-row">
                        <b><?php echo htmlspecialchars($block['label']); ?></b>
                        <label class="switch">
                            <input type="checkbox" name="access[<?php echo $key; ?>]" value="1" <?php echo !empty($map['student'][$key]) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="hint"><?php echo htmlspecialchars($block['hint'] ?? ''); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div style="margin-top:18px;">
            <button type="submit" name="save_student" class="btn-save"><i class="fas fa-save"></i> Save Student Access</button>
        </div>
    </form>

    <!-- ===================== TEACHER PORTAL ===================== -->
    <form method="post" class="access-card">
        <?php echo csrf_field(); ?>
        <h3><i class="fas fa-chalkboard-teacher"></i> Teacher Portal Access</h3>
        <div class="sub">Teacher login e kon kon section access pabe (navbar hide + direct URL block).</div>

        <div class="access-grid">
            <?php foreach (ua_all_keys()['teacher'] as $key => $meta): ?>
                <div class="access-item">
                    <div class="label-row">
                        <b><?php echo htmlspecialchars($meta[0]); ?></b>
                        <label class="switch">
                            <input type="checkbox" name="access[<?php echo $key; ?>]" value="1" <?php echo !empty($map['teacher'][$key]) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    <div class="hint"><?php echo htmlspecialchars($meta[1] ?? ''); ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div style="margin-top:18px;">
            <button type="submit" name="save_teacher" class="btn-save"><i class="fas fa-save"></i> Save Teacher Access</button>
        </div>
    </form>

    <div class="readonly-note">
        <i class="fas fa-info-circle"></i> <b>Note:</b> Direct URL access block hoye jabe. Student/teacher
        oi section-e jete chaile "Access denied" dekhbe. Kono poriborton admin activity log-e save hoy.
    </div>
</div>
</body>
</html>

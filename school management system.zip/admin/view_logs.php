<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
include("../includes/logger.php");

$limit = 100;
$offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
$admin_id = isset($_GET['admin_id']) ? (int)$_GET['admin_id'] : null;
$action = isset($_GET['action']) ? $_GET['action'] : null;

$logs = get_logs($limit, $offset, $admin_id, $action);
$total = count_logs($admin_id, $action);

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Activity Logs</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .log-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .log-table th {
            background: #003366;
            color: #fff;
            padding: 10px;
            text-align: left;
        }
        .log-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #e4edf6;
        }
        .log-table tr:hover {
            background: #f8f9fa;
        }
        .action-badge {
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .action-badge.added { background: #d4edda; color: #155724; }
        .action-badge.updated { background: #fff3cd; color: #856404; }
        .action-badge.deleted { background: #f8d7da; color: #721c24; }
        .action-badge.login { background: #cce5ff; color: #004085; }
        .action-badge.logout { background: #e2e3e5; color: #383d41; }
        .action-badge.fee { background: #d1ecf1; color: #0c5460; }
        .action-badge.other { background: #e8f4ff; color: #003366; }
        .filter-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
            border: 1px solid #e4edf6;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: end;
        }
        .filter-box select, .filter-box input {
            padding: 8px 12px;
            border: 2px solid #e4edf6;
            border-radius: 8px;
            min-width: 140px;
        }
        .pagination {
            display: flex;
            gap: 5px;
            margin-top: 15px;
            justify-content: center;
        }
        .pagination a {
            padding: 6px 12px;
            background: #e4edf6;
            border-radius: 4px;
            text-decoration: none;
            color: #003366;
        }
        .pagination a.active {
            background: #003366;
            color: #fff;
        }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="page-header">
        <div class="page-title">
            <i class="fas fa-history"></i> Admin Activity Logs
            <span style="font-size:14px; font-weight:400; color:#6c7a8a;">(<?php echo $total; ?> records)</span>
        </div>
        <a href="dashboard.php" class="btn btn-primary">
            <i class="fas fa-arrow-left"></i> Dashboard
        </a>
    </div>

    <!-- Filter -->
    <div class="filter-box">
        <form method="GET" style="display:flex; flex-wrap:wrap; gap:10px; width:100%;">
            <select name="admin_id">
                <option value="">All Admins</option>
                <?php
                $admins = mysqli_query($conn, "SELECT id, username FROM admins");
                while($a = mysqli_fetch_assoc($admins)):
                ?>
                <option value="<?php echo $a['id']; ?>" <?php echo ($admin_id == $a['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($a['username']); ?>
                </option>
                <?php endwhile; ?>
            </select>
            <select name="action">
                <option value="">All Actions</option>
                <option value="STUDENT_ADDED" <?php echo ($action == 'STUDENT_ADDED') ? 'selected' : ''; ?>>Student Added</option>
                <option value="STUDENT_UPDATED" <?php echo ($action == 'STUDENT_UPDATED') ? 'selected' : ''; ?>>Student Updated</option>
                <option value="STUDENT_DELETED" <?php echo ($action == 'STUDENT_DELETED') ? 'selected' : ''; ?>>Student Deleted</option>
                <option value="STUDENT_RESTORED" <?php echo ($action == 'STUDENT_RESTORED') ? 'selected' : ''; ?>>Student Restored</option>
                <option value="STUDENT_TC" <?php echo ($action == 'STUDENT_TC') ? 'selected' : ''; ?>>Student TC</option>
                <option value="STAFF_ADDED" <?php echo ($action == 'STAFF_ADDED') ? 'selected' : ''; ?>>Staff Added</option>
                <option value="STAFF_UPDATED" <?php echo ($action == 'STAFF_UPDATED') ? 'selected' : ''; ?>>Staff Updated</option>
                <option value="STAFF_DELETED" <?php echo ($action == 'STAFF_DELETED') ? 'selected' : ''; ?>>Staff Deleted</option>
                <option value="EXAM_ADDED" <?php echo ($action == 'EXAM_ADDED') ? 'selected' : ''; ?>>Exam Added</option>
                <option value="EXAM_UPDATED" <?php echo ($action == 'EXAM_UPDATED') ? 'selected' : ''; ?>>Exam Updated</option>
                <option value="EXAM_DELETED" <?php echo ($action == 'EXAM_DELETED') ? 'selected' : ''; ?>>Exam Deleted</option>
                <option value="CLASS_ADDED" <?php echo ($action == 'CLASS_ADDED') ? 'selected' : ''; ?>>Class Added</option>
                <option value="CLASS_UPDATED" <?php echo ($action == 'CLASS_UPDATED') ? 'selected' : ''; ?>>Class Updated</option>
                <option value="CLASS_DELETED" <?php echo ($action == 'CLASS_DELETED') ? 'selected' : ''; ?>>Class Deleted</option>
                <option value="SESSION_ACTIVATED" <?php echo ($action == 'SESSION_ACTIVATED') ? 'selected' : ''; ?>>Session Activated</option>
                <option value="FEE_COLLECTED" <?php echo ($action == 'FEE_COLLECTED') ? 'selected' : ''; ?>>Fee Collected</option>
                <option value="LOGIN" <?php echo ($action == 'LOGIN') ? 'selected' : ''; ?>>Login</option>
                <option value="LOGOUT" <?php echo ($action == 'LOGOUT') ? 'selected' : ''; ?>>Logout</option>
            </select>
            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
            <a href="view_logs.php" class="btn btn-danger">Clear</a>
        </form>
    </div>

    <!-- Log Table -->
    <div class="table-responsive">
        <table class="log-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Admin</th>
                    <th>Action</th>
                    <th>Table</th>
                    <th>Record ID</th>
                    <th>Details</th>
                    <th>IP Address</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($logs) > 0): ?>
                    <?php $sl = $offset + 1; while($row = mysqli_fetch_assoc($logs)): 
                        $action_class = 'other';
                        if(strpos($row['action'], 'ADDED') !== false) $action_class = 'added';
                        elseif(strpos($row['action'], 'UPDATED') !== false) $action_class = 'updated';
                        elseif(strpos($row['action'], 'DELETED') !== false) $action_class = 'deleted';
                        elseif($row['action'] == 'LOGIN') $action_class = 'login';
                        elseif($row['action'] == 'LOGOUT') $action_class = 'logout';
                        elseif(strpos($row['action'], 'FEE') !== false) $action_class = 'fee';
                    ?>
                    <tr>
                        <td><?php echo $sl++; ?></td>
                        <td><strong><?php echo htmlspecialchars($row['username'] ?? 'Unknown'); ?></strong></td>
                        <td><span class="action-badge <?php echo $action_class; ?>"><?php echo htmlspecialchars($row['action']); ?></span></td>
                        <td><?php echo htmlspecialchars($row['table_name'] ?? '-'); ?></td>
                        <td><?php echo $row['record_id'] ?? '-'; ?></td>
                        <td style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
                            <?php 
                            if($row['new_data']) {
                                $data = json_decode($row['new_data'], true);
                                if(is_array($data)) {
                                    echo htmlspecialchars(implode(', ', array_slice($data, 0, 3)));
                                } else {
                                    echo htmlspecialchars(substr($row['new_data'], 0, 50));
                                }
                            } else {
                                echo '-';
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['ip_address'] ?? '-'); ?></td>
                        <td><?php echo date('d M Y h:i A', strtotime($row['created_at'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align:center; padding:20px; color:#6c7a8a;">
                            <i class="fas fa-info-circle"></i> No logs found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if($total > $limit): ?>
    <div class="pagination">
        <?php for($i = 0; $i < ceil($total / $limit); $i++): ?>
            <a href="?offset=<?php echo $i * $limit; ?>&admin_id=<?php echo $admin_id; ?>&action=<?php echo $action; ?>" 
               class="<?php echo ($offset == $i * $limit) ? 'active' : ''; ?>">
                <?php echo $i + 1; ?>
            </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>

</div>
</body>
</html>
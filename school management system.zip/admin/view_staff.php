<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';

/** Staff profile — every field in read-only blocks (blank shows as —), printable on one A4 sheet. */
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmy($v) { return $v ? date('d-m-Y', strtotime($v)) : ''; }
$id = (int)($_GET['id'] ?? 0);
$s = $id > 0 ? staff_get_by_id($id) : null;
if (!$s) { $_SESSION['error'] = 'Staff member not found.'; header('Location: staff.php'); exit(); }
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
$age = $s['date_of_birth'] ? (new DateTime($s['date_of_birth']))->diff(new DateTime('today'))->y : null;
$service = $s['date_of_joining'] ? (new DateTime($s['date_of_joining']))->diff(new DateTime('today')) : null;
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$periods = (int)(db_get_row('SELECT COUNT(*) AS c FROM routine WHERE teacher_id = ? AND session_id = ?', 'ii', $id, $active_session)['c'] ?? 0);
$deps = staff_dependency_counts($id);
$pw_state = !$s['can_login'] ? '' : (!$s['state_govt_id'] ? 'Cannot log in (no Govt ID)' : (empty($s['login_password']) ? 'Not set' : ((int)$s['pw_must_change'] ? 'Default ' . (staff_default_password($s['date_of_birth']) ?: '') . ' — must change at first login' : 'Own password' . ($s['pw_changed_at'] ? ' since ' . dmy($s['pw_changed_at']) : ''))));
$badge = ['Active' => 'ok', 'Transferred' => 'info', 'Retired' => 'muted', 'Deceased' => 'bad'][$s['service_status']] ?? 'muted';
$mask = fn($v) => $v ? str_repeat('X', max(0, strlen($v) - 4)) . substr($v, -4) : '';
function cell(string $label, $value, string $extra = ''): string {
    $v = trim((string)$value);
    return '<div class="cell' . ($extra ? " $extra" : '') . '"><small>' . h($label) . '</small><b' . ($v === '' ? ' class="empty"' : '') . '>' . ($v === '' ? '—' : h($v)) . '</b></div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($s['staff_name']); ?> — Staff</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    .vs-top { background: linear-gradient(135deg, #1f4e79 0%, #2b78b6 100%); color: #fff; border-radius: 14px; padding: 18px 22px; display: flex; align-items: center; gap: 18px; flex-wrap: wrap; margin-bottom: 14px; box-shadow: 0 8px 24px rgba(31,78,121,.25); }
    .vs-top img, .vs-top .noimg { width: 92px; height: 92px; border-radius: 14px; object-fit: cover; border: 3px solid rgba(255,255,255,.6); background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 30px; }
    .vs-top h1 { margin: 0 0 4px; font-size: 22px; }
    .vs-top .ids { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 6px; }
    .vs-top .ids span { background: rgba(255,255,255,.16); border: 1px solid rgba(255,255,255,.35); padding: 3px 10px; border-radius: 999px; font-size: 12px; }
    .vs-top .ids span b { color: #fff; }
    .vs-top .tag { display: inline-block; padding: 3px 11px; border-radius: 999px; font-size: 12px; font-weight: 700; margin-left: 6px; vertical-align: middle; }
    .tag.ok { background: #d7f3e1; color: #1b7a3d; } .tag.info { background: #dbeafe; color: #1e40af; } .tag.muted { background: #e6edf3; color: #4d6178; } .tag.bad { background: #fde2e4; color: #9d2630; }
    .vs-top .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; }
    .vs-top .links a { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; }
    .vs-top .links a.solid { background: #fff; color: #1f4e79; }
    .vs-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 14px; }
    .vs-stat { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; padding: 10px 14px; } .vs-stat b { display: block; font-size: 18px; color: #10253a; } .vs-stat small { color: #6b7d90; font-size: 12px; }
    .blk { background: #fff; border: 1px solid #dfe7ef; border-radius: 12px; margin-bottom: 12px; overflow: hidden; }
    .blk h3 { margin: 0; padding: 9px 14px; font-size: 13.5px; color: #fff; display: flex; align-items: center; gap: 8px; background: linear-gradient(135deg, var(--a1), var(--a2)); }
    .blk.post { --a1: #145da0; --a2: #1f7ac2; } .blk.personal { --a1: #6a3fb5; --a2: #8757d6; } .blk.service { --a1: #c77b18; --a2: #e49a2e; } .blk.contact { --a1: #138a72; --a2: #20a486; } .blk.bank { --a1: #28708a; --a2: #338eaa; } .blk.other { --a1: #4d6178; --a2: #667d96; }
    .cells { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; }
    .cell { padding: 8px 14px; border-bottom: 1px solid #eef2f6; border-right: 1px solid #eef2f6; min-width: 0; }
    .cell small { display: block; color: #6b7d90; font-size: 10.5px; text-transform: uppercase; letter-spacing: .4px; }
    .cell b { display: block; font-size: 13.5px; color: #10253a; word-break: break-word; } .cell b.empty { color: #b0bec9; font-weight: 400; }
    .cell.wide { grid-column: span 2; } .cell.full { grid-column: span 4; }
    @media (max-width: 900px) { .cells, .vs-stats { grid-template-columns: 1fr 1fr; } .cell.full { grid-column: span 2; } }
    .print-head { display: none; }
    @media print {
        @page { size: A4 portrait; margin: 10mm; }
        html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; }
        body > *:not(.page-box) { display: none !important; }
        .page-box { box-shadow: none !important; padding: 0 !important; margin: 0 !important; max-width: none !important; width: 100% !important; border: 0 !important; }
        .page-box, .page-box * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        .vs-top .links, .alert { display: none !important; }
        .print-head { display: flex; align-items: center; gap: 12px; border-bottom: 2px solid #1f4e79; padding-bottom: 8px; margin-bottom: 10px; }
        .print-head img { width: 54px; height: 54px; object-fit: contain; }
        .print-head h2 { margin: 0; font-size: 17px; color: #1f4e79; } .print-head small { color: #555; font-size: 11px; }
        .vs-top { padding: 10px 14px; margin-bottom: 8px; border-radius: 8px; box-shadow: none; }
        .vs-top img, .vs-top .noimg { width: 70px; height: 70px; } .vs-top h1 { font-size: 17px; }
        .vs-stats { margin-bottom: 8px; gap: 6px; grid-template-columns: repeat(4, 1fr) !important; } .vs-stat { padding: 6px 10px; } .vs-stat b { font-size: 14px; } .vs-stat small { font-size: 10px; }
        .cells { grid-template-columns: repeat(4, 1fr) !important; } .cell.wide { grid-column: span 2 !important; } .cell.full { grid-column: span 4 !important; }
        .blk { margin-bottom: 6px; break-inside: avoid; border-radius: 6px; } .blk h3 { padding: 5px 10px; font-size: 11.5px; }
        .cell { padding: 4px 10px; } .cell small { font-size: 8.5px; } .cell b { font-size: 11px; }
        .print-foot { display: flex !important; margin-top: 18px; justify-content: space-between; font-size: 10px; color: #555; }
        .print-foot .sign { text-align: center; padding-top: 22px; border-top: 1px solid #333; width: 45%; }
    }
    .print-foot { display: none; }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>
<div class="page-box">
    <div class="print-head"><?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><div><h2><?php echo h($school['school_name'] ?? ''); ?></h2><small>Staff profile · Employee ID <?php echo h($s['employee_id']); ?> · printed <?php echo date('d-m-Y'); ?></small></div></div>
    <?php foreach (['success' => 'alert-success', 'error' => 'alert-danger'] as $k => $cls): if (!empty($_SESSION[$k])): ?>
    <div class="alert <?php echo $cls; ?>"><i class="fas fa-info-circle"></i> <?php echo h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
    <?php endif; endforeach; ?>

    <div class="vs-top">
        <?php if ($s['photo']): ?><img src="<?php echo h(staff_photo_url($s['photo'])); ?>" alt=""><?php else: ?><div class="noimg"><i class="fas fa-user"></i></div><?php endif; ?>
        <div>
            <h1><?php echo h($s['staff_name']); ?> <span class="tag <?php echo $badge; ?>"><?php echo h($s['service_status']); ?></span></h1>
            <div><?php echo h($s['designation']); ?><?php echo $s['subject_name'] ? ' · ' . h($s['subject_name']) : ''; ?><?php echo $s['academic_section'] ? ' · ' . h($s['academic_section']) : ''; ?> · <?php echo h($s['staff_type']); ?></div>
            <div class="ids"><span>Employee ID <b><?php echo h($s['employee_id']); ?></b></span><span>Short code <b><?php echo h($s['short_code']); ?></b></span><?php if ($s['state_govt_id']): ?><span>State Govt ID <b><?php echo h($s['state_govt_id']); ?></b></span><?php endif; ?><?php if ($s['national_code']): ?><span>National code <b><?php echo h($s['national_code']); ?></b></span><?php endif; ?></div>
        </div>
        <div class="links">
            <a href="edit_staff.php?id=<?php echo $id; ?>"><i class="fas fa-edit"></i> Edit</a>
            <?php if ($s['can_login'] && $s['service_status'] === 'Active'): ?><a href="teacher_passwords.php?search=<?php echo rawurlencode($s['employee_id']); ?>"><i class="fas fa-key"></i> Password</a><?php endif; ?>
            <a href="#" onclick="window.print(); return false;"><i class="fas fa-print"></i> Print</a>
            <?php if (!$deps): ?><a href="#" onclick="document.getElementById('rmModal').classList.add('open'); return false;" style="border-color:#f1b3b8;color:#ffd9dc"><i class="fas fa-trash"></i> Remove record</a><?php endif; ?>
            <a href="staff.php" class="solid"><i class="fas fa-arrow-left"></i> Staff list</a>
        </div>
    </div>

    <div class="vs-stats">
        <div class="vs-stat"><b><?php echo $age !== null ? $age . ' yrs' : '—'; ?></b><small>Age<?php echo $s['date_of_birth'] ? ' · born ' . dmy($s['date_of_birth']) : ''; ?></small></div>
        <div class="vs-stat"><b><?php echo $service ? $service->y . ' yrs ' . $service->m . ' mo' : '—'; ?></b><small>Service<?php echo $s['date_of_joining'] ? ' · joined ' . dmy($s['date_of_joining']) : ''; ?></small></div>
        <div class="vs-stat"><b><?php echo $s['retirement_date'] ? dmy($s['retirement_date']) : '—'; ?></b><small>Retirement date</small></div>
        <div class="vs-stat"><b><?php echo $s['staff_type'] === 'Teaching' ? $periods . ' periods' : '—'; ?></b><small><?php echo $s['staff_type'] === 'Teaching' ? 'On the routine this session' : 'Non-teaching'; ?><?php echo $s['can_login'] ? ' · portal ' . ($s['login_password'] ? ((int)$s['pw_must_change'] ? 'default password' : 'ready') : 'no password') : ' · no portal login'; ?></small></div>
    </div>

    <div class="blk post"><h3><i class="fas fa-id-badge"></i> Identity &amp; post</h3><div class="cells">
        <?php echo cell('Employee ID', $s['employee_id']), cell('State Govt ID (iOSMS / eHRMS)', $s['state_govt_id']), cell('National code (UDISE+)', $s['national_code']), cell('Short code', $s['short_code']),
            cell('Designation', $s['designation']), cell('Staff type', $s['staff_type']), cell('Subject', $s['subject_name']), cell('Academic section', $s['academic_section']),
            cell('Post type', $s['vacancy_status']), cell('Qualification', $s['qualification']), cell('Portal username', $s['can_login'] ? ($s['state_govt_id'] ?: 'needs State Govt ID') : 'No portal login'), cell('Portal password', $pw_state); ?>
    </div></div>
    <div class="blk personal"><h3><i class="fas fa-user"></i> Personal</h3><div class="cells">
        <?php echo cell('Date of birth', dmy($s['date_of_birth'])), cell('Gender', $s['gender']), cell('Blood group', $s['blood_group']), cell('Religion', $s['religion']),
            cell('Caste', $s['caste']), cell('Mother tongue', $s['mother_tongue']), cell('Marital status', $s['marital_status']), cell("Spouse's name", $s['spouse_name']),
            cell("Father's name", $s['father_name'], 'wide'), cell("Mother's name", $s['mother_name'], 'wide'); ?>
    </div></div>
    <div class="blk service"><h3><i class="fas fa-briefcase"></i> Service</h3><div class="cells">
        <?php echo cell('Date of joining (school)', dmy($s['date_of_joining'])), cell('Joining date (present post)', dmy($s['joining_date_present_post'])), cell('Retirement date', dmy($s['retirement_date'])), cell('Approval number', $s['approval_number']),
            cell('Date of approval', dmy($s['date_of_approval'])), cell('Service status', $s['service_status'] . ($s['status_date'] ? ' since ' . dmy($s['status_date']) : '')), cell('Record created', dmy($s['created_at'])), cell('Last updated', $s['updated_at'] ? dmy($s['updated_at']) : ''); ?>
    </div></div>
    <div class="blk contact"><h3><i class="fas fa-address-book"></i> Contact &amp; identity documents</h3><div class="cells">
        <?php echo cell('Mobile', $s['mobile']), cell('Email', $s['email']), cell('Aadhaar', $mask($s['aadhar_number'])), cell('Voter ID', $s['voter_number']),
            cell('PAN', $s['pan_number']), cell('Present address', $s['present_address'], 'wide'), cell('Permanent address', $s['permanent_address'] === $s['present_address'] && $s['present_address'] ? 'Same as present' : $s['permanent_address']); ?>
    </div></div>
    <div class="blk bank"><h3><i class="fas fa-university"></i> Bank</h3><div class="cells">
        <?php echo cell('Bank', $s['bank_name']), cell('Branch', $s['branch_name']), cell('Account number', $mask($s['account_number'])), cell('IFSC', $s['ifsc_code']); ?>
    </div></div>
    <?php if ($deps): ?><div class="blk other"><h3><i class="fas fa-link"></i> Linked records</h3><div class="cells"><?php foreach ($deps as $k => $n) echo cell($k, $n); ?></div></div><?php endif; ?>
    <?php if ($s['remarks']): ?><div class="blk other"><h3><i class="fas fa-sticky-note"></i> Remarks</h3><div class="cells"><?php echo cell('Remarks', $s['remarks'], 'full'); ?></div></div><?php endif; ?>
    <div class="print-foot"><div class="sign">Signature of the staff member</div><div class="sign">Head of the Institution</div></div>
</div>
<div class="lc-modal" id="rmModal" style="position:fixed;inset:0;background:rgba(16,37,58,.55);display:none;align-items:center;justify-content:center;z-index:1000;padding:16px">
    <form method="post" action="delete_staff.php" autocomplete="off" style="background:#fff;border-radius:14px;width:100%;max-width:480px;overflow:hidden">
        <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo $id; ?>"><input type="hidden" name="permanent" value="1">
        <h3 style="margin:0;padding:14px 18px;background:linear-gradient(135deg,#b0454f,#d3646e);color:#fff;font-size:15px"><i class="fas fa-exclamation-triangle"></i> Remove this staff record</h3>
        <div style="padding:16px 18px;font-size:13.5px"><p style="margin:0 0 10px">For a wrong entry only. <b><?php echo h($s['staff_name']); ?></b> has no routine, attendance or exam-duty rows, so the record can be removed. Someone who has served should be marked <b>Transferred / Retired</b> instead.</p>
            <label style="font-weight:700;font-size:12.5px">Type the Employee ID <span style="font-family:monospace;color:#9d2630"><?php echo h($s['employee_id']); ?></span> to confirm</label><input type="text" name="confirm_id" required style="width:100%;box-sizing:border-box;height:38px;padding:6px 10px;border:1px solid #c9d6e2;border-radius:7px;margin-top:6px;text-transform:uppercase"></div>
        <div style="display:flex;justify-content:flex-end;gap:8px;padding:12px 18px;background:#f5f9fc;border-top:1px solid #e1eaf2"><button type="button" class="btn btn-secondary" onclick="document.getElementById('rmModal').classList.remove('open')">Cancel</button><button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i> Remove</button></div>
    </form>
</div>
<style>#rmModal.open { display: flex !important; } .btn-secondary { background: #e6edf3; color: #1f4e79; }</style>
<script>document.getElementById('rmModal').addEventListener('click', function (e) { if (e.target === this) this.classList.remove('open'); });</script>
</body>
</html>

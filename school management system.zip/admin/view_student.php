<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once("../includes/sibling_helper.php");
require_once '../includes/student_helper.php';
require_once '../includes/fee_helper.php';

/**
 * Student Profile — one A4 sheet. Only fields that hold a value are printed,
 * and a small script scales the body text so the sheet is filled whether
 * the student has 20 fields or 60 (see fitSheet() at the bottom).
 */
$id = student_id_from_request();
if ($id === '') { $_SESSION['error'] = 'No student selected.'; header('Location: students.php'); exit(); }

$school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];

$row = db_get_row("
    SELECT s.*, g.father_name, g.father_aadhaar, g.father_voter_id, g.father_mobile, g.father_occupation,
           g.father_qualification, g.annual_income,
           g.mother_name, g.mother_aadhaar, g.mother_voter_id, g.mother_occupation,
           g.guardian_name, g.guardian_relation, g.guardian_contact, g.guardian_email
    FROM students s
    LEFT JOIN guardians g ON s.guardian_id = g.guardian_id
    WHERE s.id = ?", 's', $id);
if (!$row) {
    $_SESSION['error'] = 'Student not found.';
    header('Location: students.php');
    exit();
}

$history = db_get_all("
    SELECT h.*, a.session_name, c.class_name, sec.section_name
    FROM student_academic_history h
    LEFT JOIN academic_sessions a ON a.id = h.session_id
    LEFT JOIN classes c ON c.id = h.class_id
    LEFT JOIN sections sec ON sec.id = h.section_id
    WHERE h.student_id = ?
    ORDER BY h.id DESC", 's', $id);
$current = null;
foreach ($history as $h) if ($h['academic_status'] === 'Current') { $current = $h; break; }
$current = $current ?: ($history[0] ?? null);
$first_history = $history ? end($history) : null;   // oldest row → previous school
$admission_class = $row['admission_class_id'] ? db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $row['admission_class_id']) : null;

$siblings = find_sibling_matches($conn, $id, 3);

$mp_marks = db_get_row('SELECT * FROM hs_student_mp_marks WHERE student_id = ? LIMIT 1', 's', $id);
$mp_subjects = $mp_marks ? db_get_all('SELECT subject_name, full_marks, marks_obtained FROM hs_student_mp_subject_marks WHERE mp_marks_id = ? ORDER BY id', 'i', $mp_marks['id']) : [];

// ---------- small formatting helpers ----------
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmy($d) { return ($d && $d !== '0000-00-00') ? date('d-m-Y', strtotime($d)) : ''; }
function num($v) { return ($v === null || $v === '') ? '' : rtrim(rtrim(number_format((float)$v, 2, '.', ','), '0'), '.'); }
/** One label/value tile; a blank value prints as a muted dash so the profile reads as a complete form. */
function cell($label, $value, $wide = false) {
    $value = trim((string)$value);
    return '<div class="kv' . ($wide ? ' wide' : '') . ($value === '' ? ' empty' : '') . '"><span class="k">' . h($label) . '</span><span class="v">' . ($value === '' ? '&mdash;' : h($value)) . '</span></div>';
}
/** A titled block of tiles. */
function block($title, array $cells, $cls = 'c-blue') {
    return '<section class="blk ' . $cls . '"><h3>' . h($title) . '</h3><div class="kvs">' . implode('', $cells) . '</div></section>';
}
function age_on($dob, $on = 'today') {
    if (!$dob || $dob === '0000-00-00') return '';
    $d = (new DateTime($dob))->diff(new DateTime($on));
    return $d->y . ' y ' . $d->m . ' m';
}

$disability = $row['disability'] === 'Yes'
    ? 'Yes' . ($row['disability_type'] ? ' — ' . $row['disability_type'] : '') . ($row['disability_percentage'] !== null ? ' (' . num($row['disability_percentage']) . '%)' : '')
    : ($row['disability'] ?: '');
$status_class = ['Active' => 'ok', 'TC' => 'warn', 'Passed' => 'info', 'Deactivated' => 'muted', 'Deleted' => 'bad'][$row['student_status']] ?? 'muted';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Profile — <?php echo h($row['id']); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    /* ---------- screen ---------- */
    body { background: #dfe6ee; }
    .toolbar {
        max-width: 210mm; margin: 16px auto 10px; display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
    }
    .toolbar .spacer { flex: 1; }
    .toolbar .alert { width: 100%; margin: 0 0 6px; }

    /* ---------- the A4 sheet (same box on screen and on paper) ---------- */
    .sheet {
        --fs: 11pt;                          /* body text size; fitSheet() tunes this */
        width: 210mm; height: 297mm; margin: 0 auto 24px; padding: 9mm 10mm 8mm;
        background: #fff; color: #1a2a3a; box-shadow: 0 6px 24px rgba(20, 40, 70, .18);
        display: flex; flex-direction: column; overflow: hidden;
        font-family: "Segoe UI", Arial, "Noto Sans Bengali", sans-serif;
        font-size: var(--fs); line-height: 1.32;
        box-sizing: border-box;
    }
    .sheet *, .sheet *::before, .sheet *::after { box-sizing: border-box; }

    /* header: school */
    .sheet::before { content: ''; display: block; height: 2.2mm; margin: -9mm -10mm 3mm; background: linear-gradient(90deg, #145da0, #2f7ab8 40%, #6a3fb5 70%, #d3646e); }
    .sch { display: flex; align-items: center; gap: 4mm; padding-bottom: 2.5mm; border-bottom: 2px solid #1f4e79; }
    .sch img { width: 17mm; height: 17mm; object-fit: contain; }
    .sch .nm { flex: 1; text-align: center; }
    .sch h1 { margin: 0; font-size: 1.55em; letter-spacing: .3px; color: #1f4e79; text-transform: uppercase; }
    .sch p  { margin: .1em 0 0; font-size: .82em; color: #3c4d5f; }
    .sch .gap { width: 17mm; }
    .ttl { text-align: center; margin: 2mm 0 2.5mm; }
    .ttl span {
        display: inline-block; padding: .25em 1.6em; border-radius: 999px; background: linear-gradient(90deg, #145da0, #2f7ab8); color: #fff;
        font-weight: 700; letter-spacing: 1.5px; font-size: .85em; text-transform: uppercase;
    }

    /* identity strip */
    .idn { display: flex; gap: 4mm; align-items: stretch; margin-bottom: 2mm; padding: 2mm 3mm; background: linear-gradient(135deg, #eaf2fb, #f6f9fd); border: 1px solid #cfdff0; border-radius: 3mm; }
    .idn .photo {
        width: 24mm; height: 29mm; flex: 0 0 24mm; border: 1px solid #b8c6d4; border-radius: 2mm; overflow: hidden;
        background: #f1f5f9; display: flex; align-items: center; justify-content: center; color: #8aa0b6; font-size: .8em;
    }
    .idn .photo img { width: 100%; height: 100%; object-fit: cover; }
    .idn .who { flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center; gap: .35em; }
    .idn .name { font-size: 1.5em; font-weight: 800; color: #10253a; line-height: 1.15; }
    .idn .uid  { display: inline-block; background: linear-gradient(90deg, #003366, #145da0); color: #fff; font-weight: 700; padding: .15em .9em; border-radius: 999px; letter-spacing: .6px; font-size: .95em; }
    .idn .line { font-size: .92em; color: #2c3e50; }
    .idn .line b { color: #10253a; }
    .idn .tags { display: flex; gap: .5em; flex-wrap: wrap; font-size: .8em; }
    .tag { padding: .12em .7em; border-radius: 999px; border: 1px solid; font-weight: 700; }
    .tag.ok { color: #1b7a3d; border-color: #9fd3b2; background: #ecf9f0; }
    .tag.warn { color: #9a5a00; border-color: #f0c987; background: #fff6e5; }
    .tag.info { color: #145da0; border-color: #a9c9ea; background: #eaf3fc; }
    .tag.muted, .tag.bad { color: #6b7d90; border-color: #cfd8e1; background: #f3f6f9; }
    .idn .sig { flex: 0 0 34mm; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: .2em; }
    .idn .sig img { max-width: 34mm; max-height: 12mm; border-bottom: 1px solid #7f93a6; padding-bottom: 1mm; }
    .idn .sig small { font-size: .72em; color: #6b7d90; }

    /* body: sections that fitSheet() scales */
    .body { flex: 1 1 auto; min-height: 0; overflow: hidden; }
    .blk { --a1: #1f4e79; --a2: #2f7ab8; --tint: #eef4fa; break-inside: avoid; margin-bottom: 1.6mm; }
    .c-blue   { --a1: #145da0; --a2: #2f7ab8; --tint: #eaf2fb; }
    .c-orange { --a1: #c46a12; --a2: #e6902c; --tint: #fff3e6; }
    .c-purple { --a1: #6a3fb5; --a2: #8a5fd6; --tint: #f2ecfb; }
    .c-green  { --a1: #138a72; --a2: #21a98a; --tint: #e7f7f2; }
    .c-teal   { --a1: #22708c; --a2: #3392b0; --tint: #e8f3f7; }
    .c-red    { --a1: #b0454f; --a2: #d3646e; --tint: #fbeced; }
    .c-slate  { --a1: #4d6178; --a2: #6a8098; --tint: #eef1f5; }
    .c-pink   { --a1: #b0397a; --a2: #d05a9a; --tint: #fbebf4; }
    .c-indigo { --a1: #3b3f9e; --a2: #5a5fc9; --tint: #eeeffb; }
    .blk h3 {
        margin: 0 0 .32em; padding: .2em .9em; font-size: .82em; font-weight: 800; letter-spacing: 1px; text-transform: uppercase;
        color: #fff; background: linear-gradient(90deg, var(--a1), var(--a2)); border-radius: 4px;
    }
    .kvs { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); gap: .3em .4em; }
    .kv.wide { grid-column: 1 / -1; }
    .kv.empty .v { color: #a3b1bf; font-weight: 500; }
    .kv {
        display: flex; flex-direction: column; min-width: 0; padding: .18em .5em .22em;
        background: var(--tint); border-left: 3px solid var(--a2); border-radius: 0 4px 4px 0;
    }
    .kv .k { font-size: .7em; font-weight: 700; letter-spacing: .5px; text-transform: uppercase; color: var(--a1); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .kv .v { font-weight: 700; color: #10253a; line-height: 1.25; overflow-wrap: break-word; }
    table.grid { width: 100%; border-collapse: collapse; font-size: .9em; margin-top: .2em; }
    table.grid th, table.grid td { border: 1px solid #cdd7e1; padding: .22em .6em; text-align: left; }
    table.grid th { background: var(--tint); color: var(--a1); font-size: .9em; text-transform: uppercase; letter-spacing: .4px; }
    table.grid td.n { text-align: right; }
    .two { display: grid; grid-template-columns: 1fr 1fr; gap: 0 4mm; }

    /* dense mode — fitSheet() switches this on when a full record does not fit at the smallest text size */
    .dense .kvs { grid-template-columns: repeat(6, minmax(0, 1fr)); gap: .2em .3em; }
    .dense .kv { padding: .12em .45em .18em; }
    .dense .blk { margin-bottom: 1.2mm; }
    .dense .blk h3 { margin-bottom: .3em; padding: .18em .8em; }
    .dense .sch img { width: 13mm; height: 13mm; }
    .dense .sch { padding-bottom: 1.5mm; }
    .dense .ttl { margin: 1.2mm 0 1.5mm; }
    .dense .idn { padding: 1.5mm 2.5mm; margin-bottom: 1.5mm; }
    .dense .idn .photo { width: 21mm; height: 26mm; flex-basis: 21mm; }
    .dense .idn .who { gap: .2em; }
    .dense .sigs div span { margin-top: 5mm; }
    .dense table.grid th, .dense table.grid td { padding: .12em .5em; }

    /* footer: signatures */
    .sigs { display: flex; justify-content: space-between; padding-top: 3mm; margin-top: 2mm; }
    .sigs div { width: 30%; text-align: center; font-size: .82em; color: #3c4d5f; }
    .sigs div span { display: block; border-top: 1.5px solid #1f4e79; padding-top: .4em; margin-top: 8mm; }
    .foot { display: flex; justify-content: space-between; font-size: .68em; color: #8a9aab; margin-top: 1.5mm; }

    @media (max-width: 860px) {
        .sheet { transform-origin: top left; }
    }

    /* ---------- paper ---------- */
    @page { size: A4 portrait; margin: 0; }
    @media print {
        html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; }
        body > *:not(.sheet) { display: none !important; }
        .sheet { margin: 0; box-shadow: none; width: 210mm; height: 297mm; transform: none !important; page-break-after: avoid; }
        .sheet, .sheet * { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
</style>
</head>
<body>

<?php include("../includes/navbar.php"); ?>

<div class="toolbar">
    <?php if (!empty($_SESSION['success'])): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo h($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>
    <?php if (!empty($_SESSION['error'])): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php endif; ?>
    <a href="students.php" class="btn btn-primary"><i class="fas fa-arrow-left"></i> Students</a>
    <a href="<?php echo h(student_page_url('edit_student.php', $id)); ?>" class="btn btn-warning"><i class="fas fa-edit"></i> Edit</a>
    <?php $fee_owing = (fee_owing(fee_student_session($id), [$id])[$id] ?? 0) / 100; ?>
    <a href="<?php echo h('fee_ledger.php?uid=' . rawurlencode($id)); ?>" class="btn btn-success"><i class="fas fa-rupee-sign"></i> Fees<?php echo $fee_owing > 0 ? ' · owes ₹' . h(number_format($fee_owing, 2)) : ''; ?></a>
    <?php if ($row['birth_certificate']): ?>
    <a href="<?php echo h(student_doc_url($id, 'birth')); ?>" target="_blank" class="btn btn-info"><i class="fas fa-file-image"></i> Birth Certificate</a>
    <?php endif; ?>
    <?php if ($row['student_aadhaar_image']): ?>
    <a href="<?php echo h(student_doc_url($id, 'aadhaar')); ?>" target="_blank" class="btn btn-info"><i class="fas fa-id-card"></i> Aadhaar Card</a>
    <?php endif; ?>
    <?php if ($row['student_status'] === 'Active'): ?>
    <a href="tc_student.php?uid=<?php echo rawurlencode($id); ?>" class="btn btn-secondary"><i class="fas fa-file-export"></i> Issue TC</a>
    <a href="certificate_add.php?id=<?php echo rawurlencode($id); ?>" class="btn btn-secondary"><i class="fas fa-certificate"></i> Certificate</a>
    <?php elseif ($row['student_status'] === 'TC'): ?>
    <a href="tc_print.php?uid=<?php echo rawurlencode($id); ?>" class="btn btn-secondary"><i class="fas fa-print"></i> Print TC</a>
    <?php endif; ?>
    <span class="spacer"></span>
    <button type="button" class="btn btn-success" onclick="window.print()"><i class="fas fa-print"></i> Print (A4)</button>
</div>

<div class="sheet" id="sheet">
    <header class="sch">
        <?php if (!empty($school['logo'])): ?><img src="../uploads/<?php echo rawurlencode($school['logo']); ?>" alt=""><?php else: ?><span class="gap"></span><?php endif; ?>
        <div class="nm">
            <h1><?php echo h($school['school_name'] ?? 'School'); ?></h1>
            <p><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
            <p>
                <?php if (!empty($school['udise_code'])): ?>UDISE: <?php echo h($school['udise_code']); ?><?php endif; ?>
                <?php if (!empty($school['phone'])): ?> &nbsp;|&nbsp; Phone: <?php echo h($school['phone']); ?><?php endif; ?>
                <?php if (!empty($school['email'])): ?> &nbsp;|&nbsp; <?php echo h($school['email']); ?><?php endif; ?>
            </p>
        </div>
        <span class="gap"></span>
    </header>
    <div class="ttl"><span>Student Profile</span></div>

    <div class="idn">
        <div class="photo"><?php if ($row['photo']): ?><img src="../uploads/students/<?php echo rawurlencode($row['photo']); ?>" alt=""><?php else: ?>No photo<?php endif; ?></div>
        <div class="who">
            <div class="name"><?php echo h($row['student_name']); ?></div>
            <div><span class="uid"><?php echo h($row['id']); ?></span></div>
            <?php if ($current): ?>
            <div class="line">
                <b>Class <?php echo h($current['class_name']); ?></b><?php if ($current['section_name']): ?> &nbsp;·&nbsp; Section <b><?php echo h($current['section_name']); ?></b><?php endif; ?>
                <?php if ($current['roll_no']): ?> &nbsp;·&nbsp; Roll <b><?php echo h($current['roll_no']); ?></b><?php endif; ?>
                &nbsp;·&nbsp; Session <b><?php echo h($current['session_name']); ?></b>
            </div>
            <?php endif; ?>
            <div class="tags">
                <span class="tag <?php echo $status_class; ?>"><?php echo h($row['student_status']); ?></span>
                <?php if ($row['gender']): ?><span class="tag muted"><?php echo h($row['gender']); ?></span><?php endif; ?>
                <?php if ($row['dob']): ?><span class="tag muted">DOB <?php echo h(dmy($row['dob'])); ?></span><?php endif; ?>
                <?php if ($row['blood_group']): ?><span class="tag muted"><?php echo h($row['blood_group']); ?></span><?php endif; ?>
            </div>
        </div>
        <?php if ($row['signature']): ?>
        <div class="sig"><img src="../uploads/students/signatures/<?php echo rawurlencode($row['signature']); ?>" alt=""><small>Student's signature</small></div>
        <?php endif; ?>
    </div>

    <div class="body" id="sheetBody">
        <?php
        echo block('Identification', [
            cell('Banglar Shiksha ID', $row['banglarshiksha_id']),
            cell('PEN', $row['pen_id']),
            cell('APAAR ID', $row['apaar_id']),
            cell('Student Aadhaar', $row['student_aadhaar']),
            cell('Birth Registration No', $row['birth_registration_number']),
        ], 'c-indigo');
        echo block('Personal Details', [
            cell('Name as per Aadhaar', $row['name_as_per_aadhaar']),
            cell('Date of Birth', dmy($row['dob'])),
            cell('Age (today)', age_on($row['dob'])),
            cell('Gender', $row['gender']),
            cell('Religion', $row['religion']),
            cell('Caste', $row['caste']),
            cell('Sub Caste', $row['sub_caste']),
            cell('Blood Group', $row['blood_group']),
            cell('Nationality', $row['nationality']),
            cell('Mother Tongue', $row['mother_tongue']),
            cell('Disability', $disability),
            cell('House', (string)(db_get_row('SELECT name FROM houses WHERE id = ?', 'i', (int)$row['house_id'])['name'] ?? '')),
            cell('Student Mobile', $row['mobile']),
            cell('Email', $row['email']),
        ], 'c-blue');
        echo block('Parents & Guardian', [
            cell('Father', $row['father_name']),
            cell('Father Aadhaar', $row['father_aadhaar']),
            cell('Father Voter ID', $row['father_voter_id']),
            cell('Father Mobile', $row['father_mobile']),
            cell('Father Occupation', $row['father_occupation']),
            cell('Father Qualification', $row['father_qualification']),
            cell('Mother', $row['mother_name']),
            cell('Mother Aadhaar', $row['mother_aadhaar']),
            cell('Mother Voter ID', $row['mother_voter_id']),
            cell('Mother Occupation', $row['mother_occupation']),
            cell('Annual Income', $row['annual_income'] !== null ? '₹ ' . num($row['annual_income']) : ''),
            cell('Guardian', $row['guardian_name']),
            cell('Guardian Relation', $row['guardian_relation']),
            cell('Guardian Contact', $row['guardian_contact']),
            cell('Guardian Email', $row['guardian_email']),
        ], 'c-purple');
        echo block('Address & Contact', [
            cell('Village / Town', $row['village']),
            cell('Post Office', $row['post_office']),
            cell('Police Station', $row['police_station']),
            cell('District', $row['district']),
            cell('State', $row['state']),
            cell('PIN Code', $row['pin_code']),
        ], 'c-green');
        echo block('Bank Details', [
            cell('Bank', $row['bank_name']),
            cell('Branch', $row['branch_name']),
            cell('Account Number', $row['account_number']),
            cell('IFSC', $row['ifsc_code']),
        ], 'c-teal');
        ?>

        <?php if ($mp_marks): ?>
        <section class="blk c-red">
            <h3>Madhyamik (Class X Board) Result</h3>
            <div class="kvs">
                <?php echo cell('Board', $mp_marks['mp_board']), cell('Year of Passing', $mp_marks['mp_year']), cell('Roll No', $mp_marks['mp_roll_no']),
                    cell('Total', num($mp_marks['mp_total_marks']) . ' / ' . num($mp_marks['mp_total_full_marks']) . '  (' . num($mp_marks['mp_percentage']) . '%)'); ?>
                <?php foreach ($mp_subjects as $ms): ?>
                <div class="kv"><span class="k"><?php echo h($ms['subject_name']); ?></span><span class="v"><?php echo h(num($ms['marks_obtained'])); ?> <small style="font-weight:500;color:#6b7d90">/ <?php echo h(num($ms['full_marks'])); ?></small></span></div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <?php
        // admission sits right above the year-by-year history it starts
        echo block('Admission', [
            cell('Admission Date', dmy($row['admission_date'])),
            cell('Admission Year', $row['admission_year']),
            cell('Admission Register No', $row['admission_no']),
            cell('Admitted to Class', $admission_class['class_name'] ?? ''),
            cell('Previous School', $first_history['previous_school'] ?? ''),
            cell('Record created', dmy($row['created_at'])),
            cell('Documents on file', implode(' · ', array_filter([$row['photo'] ? 'Photo' : null, $row['signature'] ? 'Signature' : null, $row['birth_certificate'] ? 'Birth certificate' : null, $row['student_aadhaar_image'] ? 'Aadhaar' : null])) ?: 'None'),
        ], 'c-orange');
        ?>
        <?php if ($history): ?>
        <section class="blk c-slate">
            <h3>Academic History</h3>
            <?php
            // V to XII is eight rows; beyond four we lay the table out in two columns so the sheet stays one page
            $hist_rows = $history;
            usort($hist_rows, fn($x, $y) => strcmp((string)$x['session_name'], (string)$y['session_name']) ?: ($x['id'] <=> $y['id']));   // oldest session first
            $cols = count($hist_rows) > 4 ? array_chunk($hist_rows, (int)ceil(count($hist_rows) / 2)) : [$hist_rows];
            ?>
            <div class="<?php echo count($cols) > 1 ? 'two' : ''; ?>">
                <?php foreach ($cols as $chunk): ?>
                <table class="grid">
                    <tr><th>Session</th><th>Class</th><th>Sec</th><th>Roll</th><th>Result</th><th>Status</th></tr>
                    <?php foreach ($chunk as $hr): ?>
                    <tr>
                        <td><?php echo h($hr['session_name']); ?></td><td><?php echo h($hr['class_name']); ?></td><td><?php echo h($hr['section_name']); ?></td>
                        <td><?php echo h($hr['roll_no']); ?></td><td><?php echo h($hr['promotion_status']); ?></td>
                        <td><?php echo $hr['academic_status'] === 'Current' ? '<b>Current</b>' : h($hr['student_status']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <section class="blk c-pink">
            <h3>Siblings in this School</h3>
            <div class="kvs">
                <?php if (!$siblings) echo cell('Siblings', 'None on record'); ?>
                <?php foreach ($siblings as $sib): ?>
                <div class="kv"><span class="k"><?php echo h($sib['class_name'] ?? ''); ?><?php echo !empty($sib['section_name']) ? ' ' . h($sib['section_name']) : ''; ?><?php echo !empty($sib['roll_no']) ? ' · Roll ' . h($sib['roll_no']) : ''; ?></span><span class="v"><?php echo h($sib['student_name'] ?? ''); ?></span></div>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="blk c-slate"><h3>Remarks</h3><div class="kvs"><?php echo cell('Remarks', $row['remarks'], true); ?></div></section>
    </div>

    <footer>
        <div class="sigs">
            <div><span>Parent / Guardian</span></div>
            <div><span>Class Teacher</span></div>
            <div><span>Head of the Institution</span></div>
        </div>
        <div class="foot">
            <span><?php echo h($school['school_name'] ?? ''); ?> · Student Profile · <?php echo h($row['id']); ?></span>
            <span>Printed <?php echo date('d-m-Y H:i'); ?></span>
        </div>
    </footer>
</div>

<script>
// Fill the A4 sheet: grow the body text while it still fits, shrink it when it overflows.
function fitSheet() {
    var body = document.getElementById('sheetBody'), sheet = document.getElementById('sheet');
    var MIN = 7, MAX = 15;                                   // pt
    function fits() { return body.scrollHeight <= body.clientHeight + 1; }
    function search() {                                      // largest size that fits, or null if even MIN overflows
        sheet.style.setProperty('--fs', MIN + 'pt');
        if (!fits()) return null;
        var lo = MIN, hi = MAX, best = MIN;
        for (var i = 0; i < 12; i++) {
            var mid = (lo + hi) / 2;
            sheet.style.setProperty('--fs', mid + 'pt');
            if (fits()) { best = mid; lo = mid; } else { hi = mid; }
        }
        return best;
    }
    sheet.classList.remove('dense');
    var best = search();
    if (best === null) { sheet.classList.add('dense'); best = search(); }   // a very full record: 4 tiles per row
    sheet.style.setProperty('--fs', (best === null ? MIN : best) + 'pt');
}
// On a narrow screen, scale the whole sheet down to the viewport width (print stays 1:1).
function scaleSheet() {
    var sheet = document.getElementById('sheet'), w = sheet.offsetWidth, avail = document.documentElement.clientWidth - 16;
    if (avail < w) { var s = avail / w; sheet.style.transform = 'scale(' + s + ')'; sheet.style.marginBottom = (-(1 - s) * sheet.offsetHeight + 24) + 'px'; }
    else { sheet.style.transform = ''; sheet.style.marginBottom = ''; }
}
window.addEventListener('load', function () { fitSheet(); scaleSheet(); });
window.addEventListener('resize', scaleSheet);
window.addEventListener('beforeprint', function () { document.getElementById('sheet').style.transform = ''; fitSheet(); });
window.addEventListener('afterprint', scaleSheet);
</script>
</body>
</html>

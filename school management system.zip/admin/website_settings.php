<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/auth.php';
require_admin_login();
include '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/misc_helper.php';
require_once '../includes/admission_helper.php';
require_once '../includes/exam_ui.php';

/**
 * What the public website says. One row, id 1 — website_settings() makes it if it is not there, because
 * the page used to update a row that did not exist and quietly lost every save.
 *
 * Whether admission is open is not here: that belongs to Admission Settings alone, so the website and the
 * form can never disagree. This page only shows what that one switch currently says.
 */
const WEB_TEXT = [
    'hero_title'         => ['Banner heading', 255],
    'hero_subtitle'      => ['Banner line under it', 255],
    'hoi_name'           => ['Head of the institution', 150],
    'contact_phone'      => ['Phone', 20],
    'meta_title'         => ['Title in a search result', 255],
    'footer_text'        => ['Footer line', 255],
    'footer_copyright'   => ['Copyright line', 255],
];
const WEB_LONG = [
    'headmaster_message' => "The head's message",
    'about_school'       => 'About the school',
    'contact_address'    => 'Address',
    'meta_description'   => 'Description in a search result',
    'meta_keywords'      => 'Search words',
];
const WEB_URLS = [
    'contact_map_url' => 'Map link',
    'facebook_url'    => 'Facebook',
    'twitter_url'     => 'X (Twitter)',
    'instagram_url'   => 'Instagram',
    'youtube_url'     => 'YouTube',
    'linkedin_url'    => 'LinkedIn',
];
const WEB_IMAGES = [
    'hero_image'  => ['Banner picture', 'hero_'],
    'hoi_photo'   => ["The head's photograph", 'hoi_'],
    'about_image' => ['Picture beside "About the school"', 'about_'],
];

$website = website_settings();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_website'])) {
    verify_csrf_or_die();
    $set = [];
    foreach (WEB_TEXT as $field => [$label, $max]) $set[$field] = mb_substr(trim((string)($_POST[$field] ?? '')), 0, $max);
    foreach (WEB_LONG as $field => $label) $set[$field] = trim((string)($_POST[$field] ?? ''));
    $set['motto'] = mb_substr(trim((string)($_POST['motto'] ?? '')), 0, 150);

    $error = '';
    $email = app_safe_email_or_empty($_POST['contact_email'] ?? '');
    if ($email === false) $error = 'That contact email is not an email address.';
    else $set['contact_email'] = $email;
    foreach (WEB_URLS as $field => $label) {
        if ($error !== '') break;
        $url = app_safe_url_or_empty($_POST[$field] ?? '');
        if ($url === false) $error = $label . ' must be a full web address beginning with http:// or https://';
        else $set[$field] = $url;
    }

    $new_files = [];
    if ($error === '') {
        foreach (WEB_IMAGES as $field => [$label, $prefix]) {
            if (empty($_FILES[$field]['name'])) continue;
            $upload = safe_uploaded_file($_FILES[$field], '../uploads/', ['jpg', 'jpeg', 'png', 'webp'],
                ['image/jpeg', 'image/png', 'image/webp'], $prefix, 5 * 1024 * 1024);
            if (!$upload['ok']) { $error = $label . ': ' . $upload['error']; break; }
            $new_files[$field] = $upload['filename'];
            $set[$field] = $upload['filename'];
        }
    }

    if ($error !== '') {
        foreach ($new_files as $name) app_unlink_upload('../uploads/', $name);
        $_SESSION['error'] = $error;
    } else {
        $cols = [];
        $types = '';
        $params = [];
        foreach ($set as $field => $value) { $cols[] = "`$field` = ?"; $types .= 's'; $params[] = $value; }
        $done = db_execute('UPDATE website_settings SET ' . implode(', ', $cols) . ' WHERE id = 1', $types, ...$params);
        if ($done === false) {
            foreach ($new_files as $name) app_unlink_upload('../uploads/', $name);
            $_SESSION['error'] = 'Nothing could be saved. Try again.';
        } else {
            foreach ($new_files as $field => $name) if (!empty($website[$field])) app_unlink_upload('../uploads/', $website[$field]);
            $_SESSION['success'] = 'Saved. The website shows it now.' . ($new_files ? ' ' . count($new_files) . ' picture(s) replaced.' : '');
        }
    }
    header('Location: website_settings.php');
    exit();
}

$adm = adm_settings();
$closed = adm_closed_reason($adm);
$counts = db_get_row("SELECT (SELECT COUNT(*) FROM notices WHERE " . NOTICE_LIVE . ") notices,
    (SELECT COUNT(*) FROM gallery) photos,
    (SELECT COUNT(*) FROM contact_queries WHERE status = 'New') unread") ?: [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Website</title>
<?php exam_styles('web'); ?>
<style>
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb a { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 9px 12px; text-decoration: none; display: block; }
    .sb b { display: block; font-size: 21px; font-weight: 800; color: var(--ex-dark); line-height: 1.15; }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .pf textarea { height: auto; min-height: 90px; font-family: inherit; line-height: 1.6; }
    .pf .two { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    @media (max-width: 760px) { .pf .two { grid-template-columns: 1fr; } }
    .pic { display: flex; gap: 12px; align-items: flex-start; border: 1px solid #e3e9f0; border-radius: 10px; padding: 10px 12px; margin-top: 10px; }
    .pic img { width: 110px; height: 72px; object-fit: cover; border-radius: 7px; background: #eef2f6; }
    .pic .grow { flex: 1; min-width: 0; }
</style>
</head>
<body>
<?php include '../includes/navbar.php'; ?>
<div class="page-box">
    <?php exam_banner('Website', 'What people see when they come to the school online', 'fa-globe',
        ['../index.php' => '<i class="fas fa-external-link-alt"></i> See the live site']); ?>
    <?php exam_tabs('website_settings.php', WEB_PAGES); exam_flash(); ?>

    <div class="sb">
        <a href="notices.php"><b><?php echo (int)($counts['notices'] ?? 0); ?></b><span>Notices showing</span></a>
        <a href="gallery.php"><b><?php echo (int)($counts['photos'] ?? 0); ?></b><span>Photographs</span></a>
        <a href="contact_queries.php"><b><?php echo (int)($counts['unread'] ?? 0); ?></b><span>Unread messages</span></a>
        <a href="admission_settings.php"><b style="font-size:14px;padding-top:4px"><?php echo $closed === '' ? 'Open' : 'Closed'; ?></b><span>Admission</span></a>
    </div>

    <div class="ex-guard noprint" style="background:#f2f8f5;border-color:#bfe0d1;color:#1d5c46">
        <i class="fas fa-circle-info big"></i>
        <div><b>Admission is <?php echo $closed === '' ? 'open' : 'closed'; ?> — <?php echo h($closed ?: 'the form is taking applications'); ?></b>
            The website reads this straight from <a href="admission_settings.php">Admission Settings</a>, so there is nothing to set twice and the two can never disagree.</div>
    </div>

    <form method="post" enctype="multipart/form-data" autocomplete="off">
        <?php echo csrf_field(); ?>

        <div class="card pf">
            <h2><i class="fas fa-image"></i> The banner</h2>
            <div class="two">
                <div><label>Heading</label><input type="text" name="hero_title" maxlength="255" value="<?php echo h($website['hero_title'] ?? ''); ?>" placeholder="Left blank, the school's name is shown"></div>
                <div><label>Line under it</label><input type="text" name="hero_subtitle" maxlength="255" value="<?php echo h($website['hero_subtitle'] ?? ''); ?>" placeholder="Left blank, the motto is shown"></div>
                <div><label>Motto</label><input type="text" name="motto" maxlength="150" value="<?php echo h($website['motto'] ?? ''); ?>" placeholder="e.g. Tamaso ma jyotirgamaya"></div>
            </div>
            <div class="pic">
                <?php if (!empty($website['hero_image'])): ?><img src="<?php echo h('../uploads/' . $website['hero_image']); ?>" alt=""><?php endif; ?>
                <div class="grow"><label style="margin-top:0">Banner picture</label><input type="file" name="hero_image" accept=".jpg,.jpeg,.png,.webp">
                    <p class="note">A wide photograph of the school works best. Up to 5 MB. The one it replaces is removed. Without one, the banner shows the school's seal on its own colours.</p></div>
            </div>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-user-tie"></i> The head of the institution</h2>
            <label>Name</label><input type="text" name="hoi_name" maxlength="150" value="<?php echo h($website['hoi_name'] ?? ''); ?>">
            <label>Message</label><textarea name="headmaster_message" rows="4" placeholder="A few words to parents and students."><?php echo h($website['headmaster_message'] ?? ''); ?></textarea>
            <div class="pic">
                <img src="<?php echo h(!empty($website['hoi_photo']) ? '../uploads/' . $website['hoi_photo'] : '../assets/image/logo.png'); ?>" alt="">
                <div class="grow"><label style="margin-top:0">Photograph</label><input type="file" name="hoi_photo" accept=".jpg,.jpeg,.png,.webp"></div>
            </div>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-school"></i> About the school</h2>
            <textarea name="about_school" rows="5" placeholder="When the school began, what it stands for, what it offers."><?php echo h($website['about_school'] ?? ''); ?></textarea>
            <div class="pic">
                <img src="<?php echo h(!empty($website['about_image']) ? '../uploads/' . $website['about_image'] : '../assets/image/school.jpeg'); ?>" alt="">
                <div class="grow"><label style="margin-top:0">Picture beside it</label><input type="file" name="about_image" accept=".jpg,.jpeg,.png,.webp"></div>
            </div>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-location-dot"></i> How to reach the school</h2>
            <label>Address</label><textarea name="contact_address" rows="2"><?php echo h($website['contact_address'] ?? ''); ?></textarea>
            <div class="two">
                <div><label>Phone</label><input type="text" name="contact_phone" maxlength="20" value="<?php echo h($website['contact_phone'] ?? ''); ?>"></div>
                <div><label>Email</label><input type="email" name="contact_email" maxlength="100" value="<?php echo h($website['contact_email'] ?? ''); ?>"></div>
            </div>
            <label>Map link</label><input type="url" name="contact_map_url" value="<?php echo h($website['contact_map_url'] ?? ''); ?>" placeholder="https://maps.google.com/…">
            <p class="note">Left blank, the website falls back to the address and phone in School Settings.</p>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-share-nodes"></i> Where else the school is</h2>
            <div class="two">
                <?php foreach (WEB_URLS as $field => $label): if ($field === 'contact_map_url') continue; ?>
                <div><label><?php echo h($label); ?></label><input type="url" name="<?php echo h($field); ?>" value="<?php echo h($website[$field] ?? ''); ?>" placeholder="https://"></div>
                <?php endforeach; ?>
            </div>
            <p class="note">A link left blank is simply not shown.</p>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-magnifying-glass"></i> How the school looks in a search</h2>
            <label>Title</label><input type="text" name="meta_title" maxlength="255" value="<?php echo h($website['meta_title'] ?? ''); ?>">
            <label>Description</label><textarea name="meta_description" rows="2"><?php echo h($website['meta_description'] ?? ''); ?></textarea>
            <label>Search words</label><textarea name="meta_keywords" rows="2" placeholder="school, higher secondary, Malda"><?php echo h($website['meta_keywords'] ?? ''); ?></textarea>
        </div>

        <div class="card pf">
            <h2><i class="fas fa-shoe-prints"></i> The foot of every page</h2>
            <label>Line</label><input type="text" name="footer_text" maxlength="255" value="<?php echo h($website['footer_text'] ?? ''); ?>">
            <label>Copyright</label><input type="text" name="footer_copyright" maxlength="255" value="<?php echo h($website['footer_copyright'] ?? ''); ?>" placeholder="© <?php echo date('Y'); ?> …">
            <div class="acts">
                <button type="submit" name="update_website" class="btn btn-success"><i class="fas fa-save"></i> Save everything</button>
                <a href="../index.php" target="_blank" class="btn btn-info"><i class="fas fa-external-link-alt"></i> See the site</a>
            </div>
        </div>
    </form>
</div>
</body>
</html>

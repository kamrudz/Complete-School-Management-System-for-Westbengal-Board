<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once '../includes/auth.php';
require_admin_login();

include("../includes/db.php");
require_once '../includes/security.php';

// ===== CSRF TOKEN (not used for destructive action here, kept for consistency) =====
if(!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ===== DEFAULT SESSION =====
if(isset($_GET['session_id'])) {
    $selected_session_id = ($_GET['session_id'] !== '') ? (int)$_GET['session_id'] : 0;
} else {
    $active_session_row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' ORDER BY id DESC LIMIT 1"));
    $selected_session_id = $active_session_row ? (int)$active_session_row['id'] : 0;
}

$selected_class_id   = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
$selected_section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$search               = isset($_GET['search']) ? trim($_GET['search']) : '';

// ===== BUILD WHERE =====
$where = " WHERE s.student_status='Active' ";

if($selected_session_id > 0) {
    $history_join = " INNER JOIN student_academic_history h ON h.student_id = s.id AND h.session_id='$selected_session_id' ";
} else {
    $history_join = " LEFT JOIN student_academic_history h ON h.id = (
        SELECT h2.id FROM student_academic_history h2
        WHERE h2.student_id = s.id
        ORDER BY h2.id DESC LIMIT 1
    ) ";
}

if($selected_class_id > 0) {
    $where .= " AND h.class_id='$selected_class_id' ";
}
if($selected_section_id > 0) {
    $where .= " AND h.section_id='$selected_section_id' ";
}
if($search !== '') {
    $search_safe = mysqli_real_escape_string($conn, $search);
    $where .= " AND (s.student_name LIKE '%$search_safe%' OR s.mobile LIKE '%$search_safe%' OR s.banglarshiksha_id LIKE '%$search_safe%') ";
}

// Only students who have SOME contact number (own mobile or guardian contact)
$where .= " AND (s.mobile IS NOT NULL AND s.mobile != '' OR g.guardian_contact IS NOT NULL AND g.guardian_contact != '' OR g.father_mobile IS NOT NULL AND g.father_mobile != '') ";

$query = mysqli_query($conn, "
    SELECT s.id, s.student_name, s.mobile, h.roll_no, c.class_name, sec.section_name,
           g.guardian_contact, g.father_mobile, g.guardian_name, g.father_name
    FROM students s
    $history_join
    LEFT JOIN classes c ON h.class_id = c.id
    LEFT JOIN sections sec ON h.section_id = sec.id
    LEFT JOIN guardians g ON s.guardian_id = g.guardian_id
    $where
    ORDER BY c.sort_order ASC, CAST(h.roll_no AS UNSIGNED) ASC, s.student_name ASC
");
$total_found = mysqli_num_rows($query);

// ===== SESSIONS & CLASSES FOR FILTER =====
$sessions = mysqli_query($conn, "SELECT * FROM academic_sessions ORDER BY id DESC");
$classes  = mysqli_query($conn, "SELECT * FROM classes ORDER BY sort_order");


// ===== Phone formatter (India default, +91) =====
function format_wa_number($num) {
    $num = preg_replace('/[^0-9]/', '', (string)$num);
    if ($num === '') return '';
    if (strlen($num) === 10) return '91' . $num;
    if (strlen($num) === 11 && $num[0] === '0') return '91' . substr($num, 1);
    if (strlen($num) === 12 && substr($num, 0, 2) === '91') return $num;
    if (strlen($num) > 12) return $num; // already has some country code, leave as-is
    return $num;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WhatsApp Send (Free) - Students</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .filter-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
            border: 1px solid #e4edf6;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: end;
        }
        .filter-box select, .filter-box input {
            padding: 8px 12px;
            border: 2px solid #e4edf6;
            border-radius: 8px;
            min-width: 140px;
            background: #fff;
        }
        .filter-box select:focus, .filter-box input:focus {
            outline: none;
            border-color: #1f5b8a;
        }
        .msg-box {
            background: #fff;
            border: 1px solid #e4edf6;
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .msg-box textarea {
            width: 100%;
            min-height: 100px;
            padding: 10px;
            border: 2px solid #e4edf6;
            border-radius: 8px;
            font-size: 14px;
            resize: vertical;
        }
        .placeholder-tags span {
            display: inline-block;
            background: #e9f3ff;
            color: #1f5b8a;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 12px;
            margin: 4px 4px 0 0;
            cursor: pointer;
            border: 1px solid #cfe4f7;
        }
        .placeholder-tags span:hover { background: #d5eaff; }
        table.wa-table { width: 100%; border-collapse: collapse; }
        table.wa-table th, table.wa-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #eef2f6;
            font-size: 13px;
            text-align: left;
        }
        table.wa-table th { background: #f4f7fa; }
        .wa-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #25D366;
            color: #fff !important;
            padding: 5px 12px;
            border-radius: 8px;
            font-size: 12px;
            text-decoration: none;
            font-weight: 600;
        }
        .wa-btn:hover { background: #1ebc59; }
        .wa-btn.disabled { background: #ccc; pointer-events: none; }
        .no-number { color: #b02a37; font-size: 12px; font-weight: 600; }
        #queuePanel {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 320px;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.2);
            border: 1px solid #e4edf6;
            padding: 16px;
            z-index: 999;
        }
        #queuePanel h4 { margin: 0 0 8px 0; color: #1a3b55; }
        #queuePanel .qname { font-weight: 700; font-size: 15px; color: #1f5b8a; }
        #queuePanel .qmeta { font-size: 12px; color: #6c7a8a; margin-bottom: 10px; }
        #queuePanel .qbtns { display: flex; gap: 8px; margin-top: 10px; }
        #queuePanel .qbtns .btn { flex: 1; text-align: center; }
        #queuePanel .close-panel {
            position: absolute; top: 8px; right: 10px; cursor: pointer; color: #999; font-size: 16px;
        }
        @media (max-width: 768px) {
            .filter-box { flex-direction: column; }
            .filter-box select, .filter-box input { width: 100%; }
            #queuePanel { left: 10px; right: 10px; width: auto; }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/global-responsive.css">
    <script src="../assets/js/global-responsive.js" defer></script>
</head>
<body>
<?php include("../includes/navbar.php"); ?>

<div class="page-box">
    <div class="page-header">
        <div class="page-title">
            <i class="fab fa-whatsapp"></i> WhatsApp Send (Free - Testing)
            <span>(<?php echo $total_found; ?> Student<?php echo ($total_found == 1) ? '' : 's'; ?> found)</span>
        </div>
    </div>

    <div style="background:#fff3cd; color:#856404; padding:10px 15px; border-radius:8px; margin-bottom:15px; font-size:13px;">
        <i class="fas fa-info-circle"></i> This uses WhatsApp's free click-to-chat links (<code>wa.me</code>). Each message must be opened and pressed <b>Send</b> manually one by one &mdash; WhatsApp does not allow true automated bulk sending for free. Good for small batches / testing.
    </div>

    <!-- ===== FILTERS ===== -->
    <div class="filter-box">
        <form method="GET" style="display:flex; flex-wrap:wrap; gap:10px; align-items:end; width:100%;">
            <select name="session_id">
                <option value="" <?php echo ($selected_session_id == 0) ? 'selected' : ''; ?>>All Sessions</option>
                <?php while($s = mysqli_fetch_assoc($sessions)): ?>
                <option value="<?php echo $s['id']; ?>" <?php echo ($selected_session_id == $s['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($s['session_name']); ?>
                </option>
                <?php endwhile; ?>
            </select>

            <select name="class_id" id="filter_class_id">
                <option value="">All Classes</option>
                <?php while($c = mysqli_fetch_assoc($classes)): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo ($selected_class_id == $c['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($c['class_name']); ?>
                </option>
                <?php endwhile; ?>
            </select>

            <select name="section_id" id="filter_section_id">
                <option value="">All Sections</option>
                <?php
                if($selected_class_id > 0 && $selected_session_id > 0) {
                    $sec_q = mysqli_query($conn, "SELECT id, section_name FROM sections WHERE class_id='$selected_class_id' AND session_id='$selected_session_id' ORDER BY section_name");
                    while($sec = mysqli_fetch_assoc($sec_q)) {
                        $sel = ($selected_section_id == $sec['id']) ? 'selected' : '';
                        echo '<option value="'.$sec['id'].'" '.$sel.'>'.htmlspecialchars($sec['section_name']).'</option>';
                    }
                }
                ?>
            </select>

            <input type="text" name="search" placeholder="Search Name / Mobile / BS ID..." value="<?php echo htmlspecialchars($search); ?>">

            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Filter</button>
            <a href="whatsapp_send.php" class="btn btn-danger"><i class="fas fa-times"></i> Reset</a>
        </form>
    </div>

    <!-- ===== MESSAGE COMPOSER ===== -->
    <div class="msg-box">
        <label style="font-weight:600; color:#1a3b55; display:block; margin-bottom:6px;">Message Template</label>
        <textarea id="msgTemplate" placeholder="e.g. Dear Parent, this is a reminder from School regarding {name} (Class {class}-{section}, Roll {roll})...">Dear Parent/Guardian,

This is regarding your ward {name} (Class {class} - {section}, Roll {roll}).

Regards,
School Administration</textarea>
        <div class="placeholder-tags">
            Insert:
            <span onclick="insertTag('{name}')">{name}</span>
            <span onclick="insertTag('{class}')">{class}</span>
            <span onclick="insertTag('{section}')">{section}</span>
            <span onclick="insertTag('{roll}')">{roll}</span>
        </div>
    </div>

    <!-- ===== STUDENT LIST ===== -->
    <div class="table-responsive">
        <table class="wa-table">
            <thead>
                <tr>
                    <th style="width:30px;"><input type="checkbox" id="checkAll"></th>
                    <th>#</th>
                    <th>Student</th>
                    <th>Class</th>
                    <th>Sec</th>
                    <th>Roll</th>
                    <th>Number Used</th>
                    <th>Preview / Send</th>
                </tr>
            </thead>
            <tbody>
            <?php if($total_found > 0): $sl = 1; while($row = mysqli_fetch_assoc($query)):
                $number = '';
                $source = '';
                if(!empty($row['mobile'])) { $number = $row['mobile']; $source = 'Student'; }
                elseif(!empty($row['guardian_contact'])) { $number = $row['guardian_contact']; $source = 'Guardian'; }
                elseif(!empty($row['father_mobile'])) { $number = $row['father_mobile']; $source = 'Father'; }

                $wa_number = format_wa_number($number);
            ?>
                <tr data-name="<?php echo htmlspecialchars($row['student_name']); ?>"
                    data-class="<?php echo htmlspecialchars($row['class_name']); ?>"
                    data-section="<?php echo htmlspecialchars($row['section_name']); ?>"
                    data-roll="<?php echo htmlspecialchars($row['roll_no']); ?>"
                    data-number="<?php echo htmlspecialchars($wa_number); ?>">
                    <td>
                        <?php if($wa_number !== ''): ?>
                        <input type="checkbox" class="rowCheck">
                        <?php endif; ?>
                    </td>
                    <td><?php echo $sl++; ?></td>
                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['class_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['section_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['roll_no']); ?></td>
                    <td>
                        <?php if($wa_number !== ''): ?>
                            +<?php echo htmlspecialchars($wa_number); ?> <span style="color:#999;">(<?php echo $source; ?>)</span>
                        <?php else: ?>
                            <span class="no-number">No number</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($wa_number !== ''): ?>
                        <a href="#" class="wa-btn singleSendBtn"><i class="fab fa-whatsapp"></i> Send</a>
                        <?php else: ?>
                        <span class="wa-btn disabled"><i class="fab fa-whatsapp"></i> N/A</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; else: ?>
                <tr><td colspan="8" style="text-align:center; padding:30px; color:#999;">No students found for the selected filter.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($total_found > 0): ?>
    <div style="margin-top:15px;">
        <button type="button" id="startQueueBtn" class="btn btn-success"><i class="fab fa-whatsapp"></i> Send to Selected (One by One)</button>
        <span id="selCount" style="margin-left:10px; font-size:13px; color:#6c7a8a;">0 selected</span>
    </div>
    <?php endif; ?>
</div>

<!-- ===== QUEUE PANEL (sequential one-by-one send) ===== -->
<div id="queuePanel">
    <span class="close-panel" onclick="closeQueue()">&times;</span>
    <h4><i class="fab fa-whatsapp"></i> Sending Queue</h4>
    <div class="qmeta"><span id="qProgress">0 / 0</span></div>
    <div class="qname" id="qName">-</div>
    <div class="qmeta" id="qDetails">-</div>

    <div style="display:flex; align-items:center; gap:8px; margin-top:8px;">
        <label style="font-size:12px; color:#6c7a8a;">Gap (sec):</label>
        <input type="number" id="gapSeconds" value="10" min="3" max="60" style="width:60px; padding:4px 6px; border:1px solid #e4edf6; border-radius:6px;">
        <span id="autoStatus" style="font-size:12px; color:#6c7a8a; margin-left:auto;"></span>
    </div>

    <div class="qbtns">
        <a href="#" id="qSendBtn" target="_blank" class="btn btn-success wa-btn" style="justify-content:center;"><i class="fab fa-whatsapp"></i> Open Now</a>
        <button type="button" class="btn btn-primary" onclick="nextInQueue()">Next <i class="fas fa-arrow-right"></i></button>
    </div>
    <div class="qbtns">
        <button type="button" id="autoStartBtn" class="btn btn-success" style="flex:1;" onclick="startAutoSend()"><i class="fas fa-play"></i> Start Auto (Gap)</button>
        <button type="button" id="autoStopBtn" class="btn btn-danger" style="flex:1; display:none;" onclick="stopAutoSend()"><i class="fas fa-pause"></i> Stop</button>
    </div>
    <div style="font-size:11px; color:#b02a37; margin-top:6px;">
        <i class="fas fa-triangle-exclamation"></i> ব্রাউজার popup ব্লক করলে address bar-এ "Always allow popups from this site" অন করে দিন, নইলে auto-open কাজ করবে না।
    </div>
</div>

<script>
// ===== class -> section dependent dropdown =====
document.getElementById('filter_class_id').addEventListener('change', function(){
    var class_id = this.value;
    var session_id = document.querySelector('select[name="session_id"]').value;
    var sectionSelect = document.getElementById('filter_section_id');

    if(class_id == '') {
        sectionSelect.innerHTML = '<option value="">All Sections</option>';
        return;
    }
    if(session_id == '' || session_id == 0) {
        sectionSelect.innerHTML = '<option value="">Select session first</option>';
        return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'get_sections.php?class_id=' + class_id + '&session_id=' + session_id, true);
    xhr.onload = function(){
        if(xhr.status == 200) sectionSelect.innerHTML = xhr.responseText;
    };
    xhr.send();
});

document.querySelector('select[name="session_id"]').addEventListener('change', function(){
    var classSelect = document.getElementById('filter_class_id');
    if(classSelect && classSelect.value) classSelect.dispatchEvent(new Event('change'));
});

// ===== message placeholder insert =====
function insertTag(tag) {
    var ta = document.getElementById('msgTemplate');
    var start = ta.selectionStart, end = ta.selectionEnd;
    ta.value = ta.value.substring(0, start) + tag + ta.value.substring(end);
    ta.focus();
    ta.selectionStart = ta.selectionEnd = start + tag.length;
}

function buildMessage(tr) {
    var tpl = document.getElementById('msgTemplate').value;
    return tpl
        .replaceAll('{name}', tr.dataset.name || '')
        .replaceAll('{class}', tr.dataset.class || '')
        .replaceAll('{section}', tr.dataset.section || '')
        .replaceAll('{roll}', tr.dataset.roll || '');
}

function waLink(tr) {
    var msg = buildMessage(tr);
    return 'https://wa.me/' + tr.dataset.number + '?text=' + encodeURIComponent(msg);
}

// ===== single row send button =====
document.querySelectorAll('.singleSendBtn').forEach(function(btn){
    btn.addEventListener('click', function(e){
        e.preventDefault();
        var tr = btn.closest('tr');
        window.open(waLink(tr), '_blank');
    });
});

// ===== select all =====
document.getElementById('checkAll') && document.getElementById('checkAll').addEventListener('change', function(){
    document.querySelectorAll('.rowCheck').forEach(function(cb){ cb.checked = document.getElementById('checkAll').checked; });
    updateSelCount();
});
document.querySelectorAll('.rowCheck').forEach(function(cb){
    cb.addEventListener('change', updateSelCount);
});
function updateSelCount() {
    var n = document.querySelectorAll('.rowCheck:checked').length;
    var el = document.getElementById('selCount');
    if(el) el.textContent = n + ' selected';
}

// ===== sequential queue (one-by-one, avoids popup blocking) =====
var queue = [];
var qIndex = 0;

document.getElementById('startQueueBtn') && document.getElementById('startQueueBtn').addEventListener('click', function(){
    queue = [];
    document.querySelectorAll('.rowCheck:checked').forEach(function(cb){
        queue.push(cb.closest('tr'));
    });
    if(queue.length === 0) { alert('কোনো student select করেননি।'); return; }
    qIndex = 0;
    document.getElementById('queuePanel').style.display = 'block';
    showQueueItem();
});

function showQueueItem() {
    if(qIndex >= queue.length) {
        document.getElementById('qName').textContent = 'Done!';
        document.getElementById('qDetails').textContent = 'All selected messages processed.';
        document.getElementById('qProgress').textContent = queue.length + ' / ' + queue.length;
        document.getElementById('qSendBtn').style.pointerEvents = 'none';
        document.getElementById('qSendBtn').classList.add('disabled');
        return;
    }
    var tr = queue[qIndex];
    document.getElementById('qProgress').textContent = (qIndex + 1) + ' / ' + queue.length;
    document.getElementById('qName').textContent = tr.dataset.name;
    document.getElementById('qDetails').textContent = 'Class ' + tr.dataset.class + ' - ' + tr.dataset.section + ' | Roll ' + tr.dataset.roll + ' | +' + tr.dataset.number;
    var sendBtn = document.getElementById('qSendBtn');
    sendBtn.href = waLink(tr);
    sendBtn.classList.remove('disabled');
    sendBtn.style.pointerEvents = 'auto';
}

function nextInQueue() {
    stopAutoSend();
    qIndex++;
    showQueueItem();
}

function closeQueue() {
    stopAutoSend();
    document.getElementById('queuePanel').style.display = 'none';
}

// ===== auto-send with gap =====
var autoTimer = null;
var autoCountdown = 0;

function startAutoSend() {
    if(queue.length === 0) return;
    document.getElementById('autoStartBtn').style.display = 'none';
    document.getElementById('autoStopBtn').style.display = 'block';

    // open the current item immediately, then advance on a gap
    openCurrentAndScheduleNext();
}

function openCurrentAndScheduleNext() {
    if(qIndex >= queue.length) {
        document.getElementById('autoStatus').textContent = 'সব পাঠানো শেষ!';
        stopAutoSend();
        showQueueItem();
        return;
    }
    showQueueItem();
    var tr = queue[qIndex];
    window.open(waLink(tr), '_blank');

    var gap = parseInt(document.getElementById('gapSeconds').value, 10) || 10;
    autoCountdown = gap;
    document.getElementById('autoStatus').textContent = 'Next in ' + autoCountdown + 's...';

    clearInterval(autoTimer);
    autoTimer = setInterval(function(){
        autoCountdown--;
        if(autoCountdown <= 0) {
            clearInterval(autoTimer);
            qIndex++;
            openCurrentAndScheduleNext();
        } else {
            document.getElementById('autoStatus').textContent = 'Next in ' + autoCountdown + 's...';
        }
    }, 1000);
}

function stopAutoSend() {
    clearInterval(autoTimer);
    autoTimer = null;
    document.getElementById('autoStartBtn').style.display = 'block';
    document.getElementById('autoStopBtn').style.display = 'none';
    document.getElementById('autoStatus').textContent = '';
}
</script>

</body>
</html>
<?php
/**
 * admission.php (PUBLIC, project root)
 * Online admission application. The form asks what the chosen class's stage needs — Primary, Upper Primary, Secondary
 * or Higher Secondary — and Admission Settings decides which of those must be filled in. Documents go into the locked
 * uploads/admission/docs/. No money is taken here; the fee is collected at school.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
session_start();
include 'includes/db.php';
require_once 'includes/security.php';
require_once 'includes/admission_helper.php';
require_once 'includes/misc_helper.php';
require_once 'includes/site.php';
require_once 'includes/centre_helper.php';

$school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];
$settings = adm_settings();
$session_id = (int)$settings['admission_session_id'];
$closed = adm_closed_reason($settings);
$mode = adm_mode();
$centre = centre_current();

$step = 'form';
$error = '';
$done = null;
$old = [];

$edit_app = null;
$editing = isset($_GET['edit']) || ($_POST['editing'] ?? '') === '1';
$edit_id = $editing ? (int)($_SESSION['adm_edit_id'] ?? 0) : 0;
if ($edit_id > 0) {
    $edit_app = db_get_row("SELECT * FROM admission_applications WHERE id = ? AND application_status = 'Pending'", 'i', $edit_id);
    if (!$edit_app) { unset($_SESSION['adm_edit_id']); $edit_id = 0; }
}
// while applications go through centres, only the centre that made one may change it
if ($edit_app && $mode === 'centres' && (!$centre || (int)$edit_app['centre_id'] !== (int)$centre['id'])) {
    $edit_app = null;
    unset($_SESSION['adm_edit_id']);
}
$gated = $mode === 'centres' && !$centre && !$edit_app;
if ($edit_app) {
    $session_id = (int)$edit_app['session_id'];
    $closed = '';
    $old = $edit_app;
}

$open_classes = $session_id ? adm_open_classes($session_id) : [];
$villages = $session_id ? adm_allowed_villages($session_id) : [];
$class_id = (int)($_POST['class_id'] ?? $old['class_id'] ?? 0);
if (!isset($open_classes[$class_id])) $class_id = 0;
$stage = $class_id ? $open_classes[$class_id]['stage'] : '';
$need = $class_id ? adm_requirements($session_id, $stage) : [];
$is_hs = $stage === 'higher_secondary';
$xi_subjects = $is_hs ? adm_xi_subjects($session_id, $class_id) : [];
$xi_by_class = [];   // every open Higher Secondary class's subjects, so the browser can fill the choice when the class is picked
foreach ($open_classes as $cid => $c) {
    if ($c['stage'] !== 'higher_secondary') continue;
    foreach (adm_xi_subjects($session_id, (int)$cid) as $sid => $sname) $xi_by_class[(int)$cid][] = [(int)$sid, $sname];
}
$third_languages = $class_id && !$is_hs ? adm_third_languages($session_id, $class_id) : [];

$stage_items = [];
foreach ($open_classes as $cid => $c) {
    $stage_items[$cid] = ['stage' => $c['stage'], 'need' => array_keys(array_filter(adm_requirements($session_id, $c['stage']))),
        'ask' => array_keys(adm_requirements($session_id, $c['stage']))];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['submit_application'] ?? '') === '1') {
    $p = fn(string $k) => app_caps_value_if($k, (string)($_POST[$k] ?? ''));
    $mobile = $p('guardian_mobile');
    try {
        if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) throw new RuntimeException('This page was open for a long time. Please reload it and try again.');
        if ($p('website') !== '') throw new RuntimeException('The application could not be accepted.');
        if ($gated) throw new RuntimeException("Applications are made through the school's approved centres.");
        if (!$edit_app && $closed !== '') throw new RuntimeException($closed);
        if (!$class_id) throw new RuntimeException('Please choose the class you are applying for.');
        if ($villages && !adm_village_allowed($p('village'), $villages)) throw new RuntimeException('This year admission is open only to students from these villages: ' . implode(', ', $villages) . '.');
        // a centre sends many a day from one address, so it is counted by the centre, not by the address
        $limit_key = $centre ? 'centre:' . (int)$centre['id'] : 'ip:' . adm_client_ip();
        $limit_max = $centre ? CENTRE_DAILY_LIMIT : 10;
        if (!$edit_app && adm_limit_reached($limit_key, $limit_max, 1440)) throw new RuntimeException('Too many applications have been sent from here today. Please try tomorrow, or contact the school.');

        $name = $p('student_name');
        if ($name === '' || mb_strlen($name) > 100) throw new RuntimeException("Please give the student's name.");
        if (!preg_match('/^[6-9]\d{9}$/', $mobile)) throw new RuntimeException("Please give the guardian's 10-digit mobile number.");

        $missing = [];
        foreach ($need as $item => $required) {
            if (!$required) continue;
            if (isset(ADM_DOCS[$item])) {
                $has = !empty($_FILES[$item]['name']) || ($edit_app && !empty($edit_app[$item]));
                if (!$has) $missing[] = ADM_ITEMS[$item][0];
                continue;
            }
            if ($item === 'father_aadhaar' && !empty($_POST['father_aadhaar_na'])) continue;
            if ($item === 'mother_aadhaar' && !empty($_POST['mother_aadhaar_na'])) continue;
            if ($p($item) === '') $missing[] = ADM_ITEMS[$item][0];
        }
        if ($missing) throw new RuntimeException('Please give these: ' . implode(', ', $missing) . '.');

        $dob = $p('dob');
        if ($dob !== '') {
            $d = DateTime::createFromFormat('!Y-m-d', $dob);
            if (!$d || $d->format('Y-m-d') !== $dob || $dob > date('Y-m-d')) throw new RuntimeException('Please give a correct date of birth.');
        }
        foreach (['student_aadhaar' => "The student's", 'father_aadhaar' => "The father's", 'mother_aadhaar' => "The mother's"] as $k => $whose) {
            if ($k !== 'student_aadhaar' && !empty($_POST[$k . '_na'])) continue;
            if ($p($k) !== '' && !preg_match('/^\d{12}$/', $p($k))) throw new RuntimeException("$whose Aadhaar number must be 12 digits.");
        }
        if ($p('pin_code') !== '' && !preg_match('/^\d{6}$/', $p('pin_code'))) throw new RuntimeException('PIN code must be 6 digits.');

        $third = (int)($_POST['third_language_id'] ?? 0);
        if ($third && !isset($third_languages[$third])) throw new RuntimeException('Please choose the third language from the list.');

        $mp = ['board' => '', 'year' => '', 'roll' => '', 'reg' => '', 'json' => '', 'got' => null, 'full' => null, 'pct' => null];
        $xi = ['main_1' => 0, 'main_2' => 0, 'main_3' => 0, 'additional' => 0];
        if ($is_hs) {
            $mp = ['board' => $p('mp_board'), 'year' => $p('mp_year'), 'roll' => $p('mp_roll_no'), 'reg' => $p('mp_registration_no'),
                'json' => '', 'got' => null, 'full' => null, 'pct' => null];
            if ($mp['board'] === '' || !preg_match('/^(19|20)\d{2}$/', $mp['year']) || $mp['roll'] === '') throw new RuntimeException('Please give the Madhyamik board, year and roll number.');
            $rows = json_decode((string)($_POST['mp_subjects_json'] ?? ''), true);
            $subjects = [];
            foreach (is_array($rows) ? $rows : [] as $r) {
                $sname = trim((string)($r['subject'] ?? ''));
                $full = (float)($r['full_marks'] ?? 0);
                $got = (float)($r['marks_obtained'] ?? 0);
                if ($sname === '') continue;
                if ($full <= 0 || $got < 0 || $got > $full) throw new RuntimeException("The Madhyamik marks are not right: {$sname}.");
                $subjects[] = ['subject' => mb_substr($sname, 0, 60), 'full_marks' => $full, 'marks_obtained' => $got];
            }
            if (!$subjects) throw new RuntimeException('Please give the Madhyamik subjects and marks.');
            $mp['full'] = array_sum(array_column($subjects, 'full_marks'));
            $mp['got'] = array_sum(array_column($subjects, 'marks_obtained'));
            $mp['pct'] = $mp['full'] > 0 ? round($mp['got'] * 100 / $mp['full'], 2) : 0;
            $mp['json'] = json_encode($subjects, JSON_UNESCAPED_UNICODE);
            foreach ($xi as $k => $_) {
                $xi[$k] = (int)($_POST['xi_' . $k] ?? 0);
                if (!isset($xi_subjects[$xi[$k]])) throw new RuntimeException('Please choose 3 main subjects and 1 additional subject for Class XI.');
            }
            if (count(array_unique($xi)) < 4) throw new RuntimeException('The same subject cannot be chosen more than once.');
            $min = $open_classes[$class_id]['min_percent'];
            if ($min !== null && $mp['pct'] < (float)$min) throw new RuntimeException('This class needs at least ' . rtrim(rtrim($min, '0'), '.') . '% in the Madhyamik.');
        }

        if (!$edit_app) {
            $dup = find_duplicate_admission_application($conn, $session_id, $name, $dob, $mobile, $p('student_aadhaar'));
            if ($dup) throw new RuntimeException("An application for this student has already been sent (Application No. $dup). One student can apply only once — check the status, or edit it if you need to.");
        }

        $docs = [];
        foreach (ADM_DOCS as $field => [$label, $kb]) {
            if (!isset($need[$field])) continue;
            $err = null;
            $stored = handle_admission_upload($field, $kb, $err);
            if ($err) throw new RuntimeException("$label: $err");
            $docs[$field] = $stored ?: ($edit_app[$field] ?? null);
            if ($stored && $edit_app && !empty($edit_app[$field])) { $old_path = admission_doc_path($edit_app[$field]); if ($old_path) @unlink($old_path); }
        }

        $na = fn(string $k) => !empty($_POST[$k . '_na']) ? 1 : 0;
        $data = [
            'session_id' => ['v' => $session_id, 't' => 'i'], 'class_id' => ['v' => $class_id, 't' => 'i'],
            'student_name' => ['v' => $name, 't' => 's'], 'dob' => ['v' => $dob ?: null, 't' => 's'], 'gender' => ['v' => $p('gender') ?: null, 't' => 's'],
            'name_as_per_aadhaar' => ['v' => $p('name_as_per_aadhaar'), 't' => 's'], 'blood_group' => ['v' => $p('blood_group'), 't' => 's'],
            'religion' => ['v' => $p('religion'), 't' => 's'], 'caste' => ['v' => $p('caste'), 't' => 's'], 'sub_caste' => ['v' => $p('sub_caste'), 't' => 's'],
            'disability' => ['v' => $p('disability'), 't' => 's'], 'disability_type' => ['v' => $p('disability') === 'Yes' ? $p('disability_type') : '', 't' => 's'],
            'birth_registration_number' => ['v' => $p('birth_registration_number'), 't' => 's'], 'student_aadhaar' => ['v' => $p('student_aadhaar'), 't' => 's'],
            'student_mobile' => ['v' => $p('student_mobile'), 't' => 's'], 'student_email' => ['v' => $p('student_email'), 't' => 's'],
            'banglarshiksha_id' => ['v' => $p('banglarshiksha_id'), 't' => 's'], 'pen_id' => ['v' => $p('pen_id'), 't' => 's'], 'apaar_id' => ['v' => $p('apaar_id'), 't' => 's'],
            'previous_school' => ['v' => $p('previous_school'), 't' => 's'], 'previous_class' => ['v' => $p('previous_class'), 't' => 's'],
            'previous_result' => ['v' => $p('previous_result'), 't' => 's'], 'tc_no' => ['v' => $p('tc_no'), 't' => 's'],
            'third_language_id' => ['v' => $third ?: null, 't' => 'i'],
            'is_same_school_student' => ['v' => ($_POST['is_same_school_student'] ?? '') === '1' ? 1 : 0, 't' => 'i'],
            'previous_student_id' => ['v' => student_uid_clean($_POST['previous_student_id'] ?? '') ?: null, 't' => 's'],
            'mp_board' => ['v' => $mp['board'], 't' => 's'], 'mp_year' => ['v' => $mp['year'], 't' => 's'], 'mp_roll_no' => ['v' => $mp['roll'], 't' => 's'],
            'mp_registration_no' => ['v' => $mp['reg'], 't' => 's'], 'mp_subjects_json' => ['v' => $mp['json'], 't' => 's'],
            'mp_total_marks' => ['v' => $mp['got'], 't' => 'd'], 'mp_total_full_marks' => ['v' => $mp['full'], 't' => 'd'], 'mp_percentage' => ['v' => $mp['pct'], 't' => 'd'],
            'xi_main_subject_1' => ['v' => $xi['main_1'] ?: null, 't' => 'i'], 'xi_main_subject_2' => ['v' => $xi['main_2'] ?: null, 't' => 'i'],
            'xi_main_subject_3' => ['v' => $xi['main_3'] ?: null, 't' => 'i'], 'xi_additional_subject' => ['v' => $xi['additional'] ?: null, 't' => 'i'],
            'father_name' => ['v' => $p('father_name'), 't' => 's'], 'father_aadhaar' => ['v' => $na('father_aadhaar') ? '' : $p('father_aadhaar'), 't' => 's'],
            'father_aadhaar_not_available' => ['v' => $na('father_aadhaar'), 't' => 'i'], 'father_voter_id' => ['v' => $p('father_voter_id'), 't' => 's'],
            'father_mobile' => ['v' => $p('father_mobile'), 't' => 's'], 'father_occupation' => ['v' => $p('father_occupation'), 't' => 's'],
            'father_qualification' => ['v' => $p('father_qualification'), 't' => 's'], 'annual_income' => ['v' => $p('annual_income') !== '' ? (float)$p('annual_income') : 0, 't' => 'd'],
            'mother_name' => ['v' => $p('mother_name'), 't' => 's'], 'mother_aadhaar' => ['v' => $na('mother_aadhaar') ? '' : $p('mother_aadhaar'), 't' => 's'],
            'mother_aadhaar_not_available' => ['v' => $na('mother_aadhaar'), 't' => 'i'], 'mother_voter_id' => ['v' => $p('mother_voter_id'), 't' => 's'],
            'mother_occupation' => ['v' => $p('mother_occupation'), 't' => 's'],
            'guardian_name' => ['v' => $p('guardian_name'), 't' => 's'], 'guardian_relation' => ['v' => $p('guardian_relation'), 't' => 's'],
            'guardian_mobile' => ['v' => $mobile, 't' => 's'], 'guardian_email' => ['v' => $p('guardian_email'), 't' => 's'],
            'village' => ['v' => $villages ? adm_village_match($p('village'), $villages) : $p('village'), 't' => 's'], 'post_office' => ['v' => $p('post_office'), 't' => 's'],
            'police_station' => ['v' => $p('police_station'), 't' => 's'], 'district' => ['v' => $p('district'), 't' => 's'],
            'state' => ['v' => $p('state') ?: 'West Bengal', 't' => 's'], 'pin_code' => ['v' => $p('pin_code'), 't' => 's'],
            'bank_name' => ['v' => $p('bank_name'), 't' => 's'], 'branch_name' => ['v' => $p('branch_name'), 't' => 's'],
            'account_number' => ['v' => $p('account_number'), 't' => 's'], 'ifsc_code' => ['v' => $p('ifsc_code'), 't' => 's'],
        ];
        foreach ($docs as $field => $stored) $data[$field] = ['v' => $stored, 't' => 's'];

        if ($edit_app) {
            if (!db_update_assoc($conn, 'admission_applications', $data, 'id', (int)$edit_app['id'])) throw new RuntimeException('The application could not be updated. Please try again.');
            $done = ['ref' => $edit_app['application_ref'], 'edited' => true];
        } else {
            $data['application_ref'] = ['v' => generate_application_ref($conn), 't' => 's'];
            $data['payment_status'] = ['v' => 'NotRequired', 't' => 's'];
            $data['centre_id'] = ['v' => $centre ? (int)$centre['id'] : null, 't' => 'i'];
            $new_id = db_insert_assoc($conn, 'admission_applications', $data);
            if ($new_id === false) throw new RuntimeException('The application could not be saved. Please try again, or contact the school.');
            adm_limit_hit($limit_key, $limit_max, 1440);
            $done = ['ref' => $data['application_ref']['v'], 'edited' => false];
        }
        $_SESSION['adm_app_id'] = (int)($edit_app['id'] ?? $new_id);
        unset($_SESSION['adm_edit_id']);
        $step = 'done';
    } catch (RuntimeException $e) {
        $error = $e->getMessage();
        $old = $_POST;
    }
}

$v = fn(string $k, string $d = '') => h((string)($old[$k] ?? $d));
$sel = fn(string $k, string $val) => (string)($old[$k] ?? '') === $val ? ' selected' : '';
$req = fn(string $k) => !empty($need[$k]) ? ' required' : '';
$star = fn(string $k) => !empty($need[$k]) ? ' <span class="req">*</span>' : '';
$ask = fn(string $k) => $class_id === 0 || isset($need[$k]);
$doc_note = fn(string $k) => 'Up to ' . ADM_DOCS[$k][1] . ' KB' . ($k === 'birth_certificate' || $k === 'tc_doc' || $k === 'marksheet_doc' ? ' (JPG/PNG/PDF)' : ' (the picture is made smaller for you)');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Online Admission — <?php echo h($school['school_name'] ?? 'School'); ?></title>
<?php site_chrome_links(); ?>
<style>
    :root { --dark: #2a2886; --light: #3e3cb8; --soft: #f1f0fb; --border: #d9d8f0; --text: #17163f; }
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f6f6fb; margin: 0; color: var(--text); font-size: 14px; }
    .wrap { max-width: 980px; margin: 0 auto; }
    .top { background: linear-gradient(135deg, var(--dark), var(--light)); color: #fff; padding: 20px 24px; border-radius: 14px 14px 0 0; display: flex; align-items: center; gap: 14px; }
    .top i { font-size: 28px; }
    .top h1 { margin: 0; font-size: 19px; }
    .top p { margin: 3px 0 0; font-size: 12.5px; opacity: .85; }
    .card { background: #fff; border-radius: 0 0 14px 14px; box-shadow: 0 4px 18px rgba(0,0,0,.07); overflow: hidden; }
    .strip { background: var(--soft); color: #3a3880; font-size: 13px; padding: 11px 22px; border-bottom: 1px solid var(--border); line-height: 1.6; }
    .strip.warn { background: #fdecea; color: #8e1b1b; font-weight: 600; }
    .sec { background: var(--soft); color: var(--dark); font-size: 13px; font-weight: 700; padding: 10px 22px; border-top: 1px solid var(--border); border-bottom: 1px solid var(--border); }
    .sec i { margin-right: 7px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 14px; padding: 18px 22px; }
    .f label { display: block; font-size: 12px; font-weight: 700; margin-bottom: 5px; color: #2f3150; }
    .f label .req { color: #c62828; }
    .f input, .f select, .f textarea { width: 100%; padding: 9px 11px; border: 1px solid #d4d5e6; border-radius: 8px; font-size: 14px; font-family: inherit; background: #fff; }
    .f input:focus, .f select:focus, .f textarea:focus { outline: none; border-color: var(--light); box-shadow: 0 0 0 3px rgba(62,60,184,.15); }
    .f input[type=file] { padding: 7px; font-size: 12.5px; }
    .f .hint { font-size: 11.5px; color: #8b8ea6; margin-top: 4px; }
    .f.wide { grid-column: 1 / -1; }
    .na { display: flex; align-items: center; gap: 6px; font-size: 11.5px; color: #5d6079; margin-top: 5px; }
    .na input { width: auto; }
    .hp { position: absolute; left: -5000px; }
    .mp { padding: 0 22px 18px; }
    .mp table { width: 100%; border-collapse: collapse; }
    .mp th { background: var(--soft); font-size: 11.5px; text-align: left; padding: 8px 9px; border-bottom: 2px solid var(--border); text-transform: uppercase; }
    .mp td { padding: 6px 7px; border-bottom: 1px solid #ececf5; }
    .mp input { width: 100%; padding: 7px 9px; border: 1px solid #d4d5e6; border-radius: 7px; font-size: 13px; }
    .mp .num { max-width: 110px; }
    .mp .kill { background: #fdecea; color: #8e1b1b; border: 0; border-radius: 7px; padding: 7px 10px; cursor: pointer; }
    .mp .add { margin-top: 10px; background: var(--dark); color: #fff; border: 0; padding: 8px 16px; border-radius: 8px; font-size: 12.5px; cursor: pointer; }
    .mp .tot { margin-top: 12px; background: var(--soft); color: var(--dark); font-weight: 700; padding: 10px 16px; border-radius: 9px; display: inline-block; }
    .pick2 { display: flex; gap: 8px 22px; flex-wrap: wrap; }
    .pick2 label { display: flex; align-items: center; gap: 7px; font-weight: 700; font-size: 13.5px; color: #2f3150; margin: 0; cursor: pointer; }
    .pick2 input { width: auto; }
    .find { margin: 0 22px 16px; background: #fff8e8; border: 1px solid var(--border); border-radius: 10px; padding: 14px 16px; font-size: 13px; line-height: 1.7; }
    .find .grid { padding: 0; }
    .findgo { background: var(--dark); color: #fff; border: 0; padding: 10px 22px; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 700; width: 100%; }
    .ok-box { background: #e9f7ee; border: 1px solid #b6e2c2; color: #1b5e33; border-radius: 10px; padding: 12px 15px; margin: 0 22px 16px; font-size: 13px; line-height: 1.7; }
    .foot { padding: 20px 22px 26px; text-align: center; background: #fcfaf8; }
    .go { padding: 13px 44px; background: var(--dark); color: #fff; border: 0; border-radius: 30px; font-weight: 700; font-size: 15px; cursor: pointer; }
    .go:disabled { background: #b7a799; cursor: not-allowed; }
    .err { background: #fdecea; color: #8e1b1b; padding: 12px 18px; margin: 16px 22px 0; border-radius: 10px; font-size: 13.5px; line-height: 1.7; }
    .middle { text-align: center; padding: 46px 22px; }
    .middle i { font-size: 52px; }
    .ref { display: inline-block; background: var(--dark); color: #fff; padding: 11px 26px; border-radius: 11px; font-size: 21px; font-weight: 800; letter-spacing: 1px; margin: 16px 0; }
    .links { margin-top: 18px; font-size: 13.5px; }
    .links a { color: var(--dark); font-weight: 700; margin: 0 8px; }
    @media (max-width: 600px) { body { padding: 14px 10px 40px; } .grid { padding: 14px; gap: 12px; } }
</style>
</head>
<body>
<?php site_header('admission.php'); ?>
<div class="form-page" id="main" style="padding:26px 4vw 50px">
<div class="wrap">
    <div class="top">
        <i class="fas fa-graduation-cap"></i>
        <div><h1><?php echo h($school['school_name'] ?? 'School'); ?></h1><p>Online admission application<?php echo $session_id ? ' — session ' . h(adm_session_name($session_id)) : ''; ?></p></div>
    </div>
    <div class="card">
<?php if ($step === 'done'): ?>
    <div class="middle">
        <i class="fas fa-check-circle" style="color:#1b7a3a"></i>
        <h2 style="margin:14px 0 4px"><?php echo $done['edited'] ? 'Your application has been updated' : 'Your application has been received'; ?></h2>
        <p style="color:#5d6079;margin:0">Please write down the Application No. below — you will need it to check the status and whenever you contact the school.</p>
        <div class="ref"><?php echo h($done['ref']); ?></div>
        <p style="color:#5d6079;max-width:520px;margin:0 auto;line-height:1.8">The school will check your documents and let you know. The admission fee is paid at the school — nothing is paid here.</p>
        <div class="links"><?php if ($centre): ?><a href="admission_copy_print_public.php" target="_blank"><i class="fas fa-print"></i> Print the copy</a><a href="admission.php"><i class="fas fa-plus"></i> Next application</a><a href="centre/index.php"><i class="fas fa-list"></i> This centre's applications</a><?php else: ?><a href="admission_status.php"><i class="fas fa-search"></i> Check status and print a copy</a><a href="index.php"><i class="fas fa-home"></i> School home</a><?php endif; ?></div>
    </div>
<?php elseif ($gated): $centres = centre_public_list(); ?>
    <div class="middle">
        <i class="fas fa-store" style="color:var(--dark)"></i>
        <h2 style="margin:14px 0 6px">Apply at one of our approved centres</h2>
        <p style="color:#5d6079;margin:0 auto;max-width:560px">This year the school takes applications only through the centres below. Take the student's documents there and the centre will fill in the form for you<?php echo $closed === '' ? '' : ' — ' . h(lcfirst($closed)); ?></p>
        <?php if ($centres): ?>
        <table style="margin:22px auto 0;border-collapse:collapse;text-align:left;font-size:14px;min-width:min(520px,100%)">
            <thead><tr><th style="padding:8px 12px;border-bottom:2px solid var(--border)">Centre</th><th style="padding:8px 12px;border-bottom:2px solid var(--border)">Where</th><th style="padding:8px 12px;border-bottom:2px solid var(--border)">Phone</th></tr></thead>
            <tbody><?php foreach ($centres as $c): ?><tr><td style="padding:8px 12px;border-bottom:1px solid #ececf5"><b><?php echo h($c['name']); ?></b></td><td style="padding:8px 12px;border-bottom:1px solid #ececf5"><?php echo h($c['place'] ?: '—'); ?></td><td style="padding:8px 12px;border-bottom:1px solid #ececf5"><?php echo $c['phone'] ? '<a href="tel:' . h($c['phone']) . '">' . h($c['phone']) . '</a>' : '—'; ?></td></tr><?php endforeach; ?></tbody>
        </table>
        <?php else: ?>
        <p style="margin-top:16px;font-weight:600">The list of centres will be put up soon. Please contact the school office.</p>
        <?php endif; ?>
        <div class="links"><a href="admission_status.php"><i class="fas fa-search"></i> Status of an earlier application</a><a href="centre/login.php"><i class="fas fa-store"></i> Centre login</a></div>
    </div>
<?php elseif ($closed !== '' && !$edit_app): ?>
    <div class="middle">
        <i class="fas fa-door-closed" style="color:#c62828;opacity:.6"></i>
        <h2 style="margin:14px 0 6px">Applications are not being taken now</h2>
        <p style="color:#5d6079;margin:0"><?php echo h($closed); ?></p>
        <div class="links"><a href="admission_status.php"><i class="fas fa-search"></i> Status of an earlier application</a><a href="index.php"><i class="fas fa-home"></i> School home</a></div>
    </div>
<?php elseif (!$open_classes): ?>
    <div class="middle">
        <i class="fas fa-chalkboard" style="color:#c62828;opacity:.6"></i>
        <h2 style="margin:14px 0 6px">No class is open for admission</h2>
        <p style="color:#5d6079;margin:0">This will be announced soon.</p>
    </div>
<?php else: ?>
    <?php if ($edit_app): ?>
    <div class="strip warn"><i class="fas fa-pen"></i> You are changing an application already sent (Application No. <?php echo h($edit_app['application_ref']); ?>). It can be changed until the school starts checking it.</div>
    <?php endif; ?>
    <?php if ($centre): ?>
    <div class="strip"><i class="fas fa-store"></i> Applying as <b><?php echo h($centre['name']); ?></b> — the application will be marked as made at this centre. <a href="centre/index.php" style="font-weight:700">This centre's applications</a></div>
    <?php endif; ?>
    <?php if (trim((string)$settings['admission_notice']) !== ''): ?>
    <div class="strip"><i class="fas fa-info-circle"></i> <?php echo nl2br(h($settings['admission_notice'])); ?></div>
    <?php endif; ?>
    <?php if ($villages): ?><div class="strip"><i class="fas fa-map-location-dot"></i> This year admission is open only to students from: <b><?php echo h(implode(', ', $villages)); ?></b>.</div><?php endif; ?>
    <div class="strip">Applying costs nothing. <?php echo !empty($settings['admission_end']) ? 'Last date to apply: <b>' . h(date('d-m-Y', strtotime($settings['admission_end']))) . '</b>. ' : ''; ?>The starred (<span style="color:#c62828">*</span>) marked boxes must be filled in.</div>
    <?php if ($error !== ''): ?><div class="err"><i class="fas fa-exclamation-circle"></i> <?php echo h($error); ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data" id="admForm" autocomplete="off">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="submit_application" value="1">
        <?php if ($edit_app): ?><input type="hidden" name="editing" value="1"><?php endif; ?>
        <input type="hidden" name="is_same_school_student" id="is_same" value="<?php echo (int)($old['is_same_school_student'] ?? 0); ?>">
        <input type="hidden" name="previous_student_id" id="prev_uid" value="<?php echo $v('previous_student_id'); ?>">
        <input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">

        <div class="sec"><i class="fas fa-id-card"></i> Step 1 — Has the student studied in this school before?</div>
        <div class="grid" style="padding-bottom:6px">
            <div class="f wide">
                <div class="pick2">
                    <label><input type="radio" name="was_here" value="1" id="wasYes"<?php echo !empty($old['is_same_school_student']) ? ' checked' : ''; ?>> Yes, in this school</label>
                    <label><input type="radio" name="was_here" value="0" id="wasNo"<?php echo empty($old['is_same_school_student']) ? ' checked' : ''; ?>> No, a new admission</label>
                </div>
                <div class="hint">If the student studied here before, finding them fills the rest of the form for you.</div>
            </div>
        </div>
        <div id="findBox" style="display:none">
            <div class="find">
                <div><i class="fas fa-search"></i> Give <b>any one</b> of these and the <b>date of birth</b>:</div>
                <div class="grid" style="padding:12px 0 0">
                    <div class="f"><label>Aadhaar number</label><input type="text" id="find_aadhaar" maxlength="12" inputmode="numeric" placeholder="12 digits" oninput="this.value=this.value.replace(/\D/g,'').slice(0,12)"></div>
                    <div class="f"><label>Banglar Shiksha ID</label><input type="text" id="find_bsid" maxlength="50"></div>
                    <div class="f"><label>PEN</label><input type="text" id="find_pen" maxlength="50"></div>
                    <div class="f"><label>School UID <small style="text-transform:none;font-weight:400">if you remember it</small></label><input type="text" id="find_uid" placeholder="ULPHS-2021-0050"></div>
                    <div class="f"><label>Date of birth <span class="req">*</span></label><input type="date" id="find_dob" max="<?php echo date('Y-m-d'); ?>"></div>
                    <div class="f" style="display:flex;align-items:flex-end"><button type="button" id="findBtn" class="findgo"><i class="fas fa-search"></i> Find</button></div>
                </div>
                <div class="hint" style="margin-top:8px"><i class="fas fa-shield-halved"></i> Nothing is shown unless the date of birth matches.</div>
                <div id="findMsg" style="margin-top:8px;font-weight:700"></div>
            </div>
            <div class="ok-box" id="matchBox" style="display:none"></div>
        </div>

        <div class="sec"><i class="fas fa-chalkboard"></i> Class applied for</div>
        <div class="grid">
            <div class="f"><label>Class <span class="req">*</span></label>
                <select name="class_id" id="class_id" required>
                    <option value="">Choose…</option>
                    <?php foreach ($open_classes as $cid => $c): ?><option value="<?php echo (int)$cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?>
                </select>
                <div class="hint" id="stageHint"></div>
            </div>
            <div class="f"><label>Guardian mobile <span class="req">*</span></label>
                <input type="text" name="guardian_mobile" inputmode="numeric" maxlength="10" required value="<?php echo $v('guardian_mobile'); ?>" oninput="this.value=this.value.replace(/\D/g,'').slice(0,10)">
                <div class="hint">This number is needed to check the status later</div>
            </div>
        </div>

        <div class="sec"><i class="fas fa-child"></i> Student details</div>
        <div class="grid">
            <div class="f"><label>Full name <span class="req">*</span></label><input type="text" name="student_name" maxlength="100" required value="<?php echo $v('student_name'); ?>"></div>
            <div class="f"><label>Name as per Aadhaar</label><input type="text" name="name_as_per_aadhaar" maxlength="150" value="<?php echo $v('name_as_per_aadhaar'); ?>"></div>
            <div class="f" data-item="dob"><label>Date of birth<?php echo $star('dob'); ?></label><input type="date" name="dob" max="<?php echo date('Y-m-d'); ?>"<?php echo $req('dob'); ?> value="<?php echo $v('dob'); ?>"></div>
            <div class="f" data-item="gender"><label>Gender<?php echo $star('gender'); ?></label>
                <select name="gender"<?php echo $req('gender'); ?>><option value="">Choose</option>
                    <option value="Male"<?php echo $sel('gender', 'Male'); ?>>Male</option><option value="Female"<?php echo $sel('gender', 'Female'); ?>>Female</option><option value="Other"<?php echo $sel('gender', 'Other'); ?>>Other</option></select></div>
            <div class="f" data-item="blood_group"><label>Blood group<?php echo $star('blood_group'); ?></label>
                <select name="blood_group"<?php echo $req('blood_group'); ?>><option value="">Choose</option><?php foreach (['A+','A-','B+','B-','AB+','AB-','O+','O-'] as $bg): ?><option value="<?php echo $bg; ?>"<?php echo $sel('blood_group', $bg); ?>><?php echo $bg; ?></option><?php endforeach; ?></select></div>
            <div class="f" data-item="religion"><label>Religion<?php echo $star('religion'); ?></label>
                <select name="religion"<?php echo $req('religion'); ?>><option value="">Choose</option><?php foreach (['Hindu','Muslim','Christian','Sikh','Buddhist','Jain','Others'] as $r): ?><option value="<?php echo $r; ?>"<?php echo $sel('religion', $r); ?>><?php echo $r; ?></option><?php endforeach; ?></select></div>
            <div class="f" data-item="caste"><label>Caste<?php echo $star('caste'); ?></label>
                <select name="caste"<?php echo $req('caste'); ?>><option value="">Choose</option><?php foreach (student_castes() as $c): ?><option value="<?php echo $c; ?>"<?php echo $sel('caste', $c); ?>><?php echo $c; ?></option><?php endforeach; ?></select></div>
            <div class="f"><label>Sub caste</label><input type="text" name="sub_caste" maxlength="50" value="<?php echo $v('sub_caste'); ?>"></div>
            <div class="f"><label>Disability</label>
                <select name="disability" id="disability"><option value="">None</option><option value="Yes"<?php echo $sel('disability', 'Yes'); ?>>Yes</option></select></div>
            <div class="f"><label>Type of disability</label><input type="text" name="disability_type" id="disability_type" maxlength="100" value="<?php echo $v('disability_type'); ?>"></div>
            <div class="f" data-item="birth_registration_number"><label>Birth registration no.<?php echo $star('birth_registration_number'); ?></label><input type="text" name="birth_registration_number" maxlength="50"<?php echo $req('birth_registration_number'); ?> value="<?php echo $v('birth_registration_number'); ?>"></div>
            <div class="f" data-item="student_aadhaar"><label>Student's Aadhaar number<?php echo $star('student_aadhaar'); ?></label><input type="text" name="student_aadhaar" id="stu_aadhaar" maxlength="12" inputmode="numeric"<?php echo $req('student_aadhaar'); ?> value="<?php echo $v('student_aadhaar'); ?>" oninput="this.value=this.value.replace(/\D/g,'').slice(0,12)"></div>
            <div class="f" data-item="banglarshiksha_id"><label>Banglar Shiksha ID<?php echo $star('banglarshiksha_id'); ?></label><input type="text" name="banglarshiksha_id" id="bsid" maxlength="50"<?php echo $req('banglarshiksha_id'); ?> value="<?php echo $v('banglarshiksha_id'); ?>"></div>
            <div class="f" data-item="pen_id"><label>PEN<?php echo $star('pen_id'); ?></label><input type="text" name="pen_id" id="pen" maxlength="50"<?php echo $req('pen_id'); ?> value="<?php echo $v('pen_id'); ?>"></div>
            <div class="f" data-item="apaar_id"><label>APAAR ID<?php echo $star('apaar_id'); ?></label><input type="text" name="apaar_id" maxlength="100"<?php echo $req('apaar_id'); ?> value="<?php echo $v('apaar_id'); ?>"></div>
            <div class="f"><label>Student's mobile</label><input type="text" name="student_mobile" maxlength="15" value="<?php echo $v('student_mobile'); ?>"></div>
            <div class="f"><label>Student's email</label><input type="email" name="student_email" maxlength="100" value="<?php echo $v('student_email'); ?>"></div>
        </div>

        <div class="sec"><i class="fas fa-users"></i> Parents and guardian</div>
        <div class="grid">
            <div class="f" data-item="father_name"><label>Father's name<?php echo $star('father_name'); ?></label><input type="text" name="father_name" maxlength="150"<?php echo $req('father_name'); ?> value="<?php echo $v('father_name'); ?>"></div>
            <div class="f" data-item="father_aadhaar"><label>Father's Aadhaar<?php echo $star('father_aadhaar'); ?></label>
                <input type="text" name="father_aadhaar" id="fa_aadhaar" maxlength="12" inputmode="numeric" value="<?php echo $v('father_aadhaar'); ?>" oninput="this.value=this.value.replace(/\D/g,'').slice(0,12)"<?php echo !empty($old['father_aadhaar_not_available']) ? ' disabled' : ''; ?>>
                <label class="na"><input type="checkbox" name="father_aadhaar_na" id="fa_na"<?php echo !empty($old['father_aadhaar_not_available']) ? ' checked' : ''; ?>> No Aadhaar</label></div>
            <div class="f"><label>Father's voter ID</label><input type="text" name="father_voter_id" maxlength="20" value="<?php echo $v('father_voter_id'); ?>"></div>
            <div class="f"><label>Father's mobile</label><input type="text" name="father_mobile" maxlength="15" value="<?php echo $v('father_mobile'); ?>"></div>
            <div class="f"><label>Father's occupation</label><input type="text" name="father_occupation" maxlength="100" value="<?php echo $v('father_occupation'); ?>"></div>
            <div class="f"><label>Father's education</label><input type="text" name="father_qualification" maxlength="100" value="<?php echo $v('father_qualification'); ?>"></div>
            <div class="f"><label>Family yearly income (₹)</label><input type="number" name="annual_income" min="0" step="1" value="<?php echo $v('annual_income'); ?>"></div>
            <div class="f" data-item="mother_name"><label>Mother's name<?php echo $star('mother_name'); ?></label><input type="text" name="mother_name" maxlength="150"<?php echo $req('mother_name'); ?> value="<?php echo $v('mother_name'); ?>"></div>
            <div class="f" data-item="mother_aadhaar"><label>Mother's Aadhaar<?php echo $star('mother_aadhaar'); ?></label>
                <input type="text" name="mother_aadhaar" id="ma_aadhaar" maxlength="12" inputmode="numeric" value="<?php echo $v('mother_aadhaar'); ?>" oninput="this.value=this.value.replace(/\D/g,'').slice(0,12)"<?php echo !empty($old['mother_aadhaar_not_available']) ? ' disabled' : ''; ?>>
                <label class="na"><input type="checkbox" name="mother_aadhaar_na" id="ma_na"<?php echo !empty($old['mother_aadhaar_not_available']) ? ' checked' : ''; ?>> No Aadhaar</label></div>
            <div class="f"><label>Mother's voter ID</label><input type="text" name="mother_voter_id" maxlength="20" value="<?php echo $v('mother_voter_id'); ?>"></div>
            <div class="f"><label>Mother's occupation</label><input type="text" name="mother_occupation" maxlength="100" value="<?php echo $v('mother_occupation'); ?>"></div>
            <div class="f"><label>Guardian's name</label><input type="text" name="guardian_name" maxlength="150" value="<?php echo $v('guardian_name'); ?>"></div>
            <div class="f"><label>Relation</label>
                <select name="guardian_relation"><?php foreach (['Father','Mother','Grandfather','Grandmother','Uncle','Aunt','Elder Brother','Elder Sister','Legal Guardian','Others'] as $g): ?><option value="<?php echo $g; ?>"<?php echo (string)($old['guardian_relation'] ?? 'Father') === $g ? ' selected' : ''; ?>><?php echo $g; ?></option><?php endforeach; ?></select></div>
            <div class="f"><label>Guardian's email</label><input type="email" name="guardian_email" maxlength="100" value="<?php echo $v('guardian_email'); ?>"></div>
        </div>

        <div class="sec"><i class="fas fa-map-marker-alt"></i> Address and bank</div>
        <div class="grid">
            <div class="f" data-item="village"><label>Village / street<?php echo $star('village'); ?></label><?php if ($villages): ?><select name="village" required><option value="">Choose</option><?php foreach ($villages as $vn): ?><option value="<?php echo h($vn); ?>"<?php echo mb_strtolower(trim((string)($old['village'] ?? ''))) === mb_strtolower($vn) ? ' selected' : ''; ?>><?php echo h($vn); ?></option><?php endforeach; ?></select><div class="hint">Only these villages may apply this year.</div><?php else: ?><input type="text" name="village" maxlength="100"<?php echo $req('village'); ?> value="<?php echo $v('village'); ?>"><?php endif; ?></div>
            <div class="f" data-item="post_office"><label>Post office<?php echo $star('post_office'); ?></label><input type="text" name="post_office" maxlength="100"<?php echo $req('post_office'); ?> value="<?php echo $v('post_office'); ?>"></div>
            <div class="f" data-item="police_station"><label>Police station<?php echo $star('police_station'); ?></label><input type="text" name="police_station" maxlength="100"<?php echo $req('police_station'); ?> value="<?php echo $v('police_station'); ?>"></div>
            <div class="f" data-item="district"><label>District<?php echo $star('district'); ?></label><input type="text" name="district" maxlength="100"<?php echo $req('district'); ?> value="<?php echo $v('district'); ?>"></div>
            <div class="f"><label>State</label><input type="text" name="state" maxlength="100" value="<?php echo $v('state', 'West Bengal'); ?>"></div>
            <div class="f" data-item="pin_code"><label>PIN code<?php echo $star('pin_code'); ?></label><input type="text" name="pin_code" maxlength="6" inputmode="numeric"<?php echo $req('pin_code'); ?> value="<?php echo $v('pin_code'); ?>" oninput="this.value=this.value.replace(/\D/g,'').slice(0,6)"></div>
            <div class="f" data-item="account_number"><label>Bank account number<?php echo $star('account_number'); ?></label><input type="text" name="account_number" maxlength="30"<?php echo $req('account_number'); ?> value="<?php echo $v('account_number'); ?>"></div>
            <div class="f" data-item="account_number"><label>IFSC code</label><input type="text" name="ifsc_code" id="ifsc" maxlength="11" value="<?php echo $v('ifsc_code'); ?>">
                <div class="hint" id="ifscMsg">The bank and branch fill in on their own</div></div>
            <div class="f" data-item="account_number"><label>Bank name</label><input type="text" name="bank_name" id="bank_name" maxlength="100" value="<?php echo $v('bank_name'); ?>"></div>
            <div class="f" data-item="account_number"><label>Branch</label><input type="text" name="branch_name" id="branch_name" maxlength="100" value="<?php echo $v('branch_name'); ?>"></div>
        </div>

        <div id="prevBlock" style="display:<?php echo $ask('previous_school') || $ask('previous_class') ? 'block' : 'none'; ?>">
            <div class="sec"><i class="fas fa-school"></i> Previous school</div>
            <div class="grid">
                <div class="f wide" data-item="previous_school"><label>Name of the previous school<?php echo $star('previous_school'); ?></label><input type="text" name="previous_school" maxlength="200"<?php echo $req('previous_school'); ?> value="<?php echo $v('previous_school'); ?>"></div>
                <div class="f" data-item="previous_class"><label>Last class studied<?php echo $star('previous_class'); ?></label><input type="text" name="previous_class" maxlength="20"<?php echo $req('previous_class'); ?> value="<?php echo $v('previous_class'); ?>" placeholder="e.g. VIII"></div>
                <div class="f" data-item="previous_class"><label>Result / marks</label><input type="text" name="previous_result" maxlength="100" value="<?php echo $v('previous_result'); ?>" placeholder="e.g. 68%"></div>
                <div class="f" data-item="tc_no"><label>TC number<?php echo $star('tc_no'); ?></label><input type="text" name="tc_no" maxlength="50"<?php echo $req('tc_no'); ?> value="<?php echo $v('tc_no'); ?>"></div>
                <?php if ($third_languages): ?>
                <div class="f"><label>Third language</label>
                    <select name="third_language_id"><option value="">Choose</option><?php foreach ($third_languages as $sid => $sname): ?><option value="<?php echo (int)$sid; ?>"<?php echo (int)($old['third_language_id'] ?? 0) === (int)$sid ? ' selected' : ''; ?>><?php echo h($sname); ?></option><?php endforeach; ?></select></div>
                <?php endif; ?>
            </div>
        </div>

        <div id="hsBlock" style="display:<?php echo $is_hs ? 'block' : 'none'; ?>">
            <div class="sec"><i class="fas fa-book"></i> Madhyamik result</div>
            <div class="grid">
                <div class="f"><label>Board <span class="req">*</span></label>
                    <select name="mp_board" class="hs-need"><option value="">Choose</option><?php foreach (['WBBSE','CBSE','ICSE','Other'] as $b): ?><option value="<?php echo $b; ?>"<?php echo $sel('mp_board', $b); ?>><?php echo $b; ?></option><?php endforeach; ?></select></div>
                <div class="f"><label>Year of passing <span class="req">*</span></label><input type="text" name="mp_year" class="hs-need" maxlength="4" inputmode="numeric" value="<?php echo $v('mp_year'); ?>" placeholder="<?php echo date('Y'); ?>"></div>
                <div class="f"><label>Madhyamik roll number <span class="req">*</span></label><input type="text" name="mp_roll_no" class="hs-need" maxlength="30" value="<?php echo $v('mp_roll_no'); ?>"></div>
                <div class="f"><label>Registration number</label><input type="text" name="mp_registration_no" maxlength="50" value="<?php echo $v('mp_registration_no'); ?>"></div>
            </div>
            <div class="mp">
                <table><thead><tr><th>Subject</th><th>Full marks</th><th>Marks obtained</th><th></th></tr></thead><tbody id="mpBody"></tbody></table>
                <button type="button" class="add" id="mpAdd"><i class="fas fa-plus"></i> Add a subject</button>
                <div class="tot" id="mpTotal">Total: 0 / 0 | Percentage: 0%</div>
                <input type="hidden" name="mp_subjects_json" id="mp_json">
            </div>
            <div id="xiChoice" style="display:<?php echo !$is_hs || $xi_subjects ? 'block' : 'none'; ?>">
            <div class="sec"><i class="fas fa-list-ol"></i> Class XI subject choice</div>
            <div class="grid">
                <?php foreach (['main_1' => 'Main subject 1', 'main_2' => 'Main subject 2', 'main_3' => 'Main subject 3', 'additional' => 'Additional subject'] as $k => $label): ?>
                <div class="f"><label><?php echo $label; ?> <span class="req">*</span></label>
                    <select name="xi_<?php echo $k; ?>" class="xi hs-need"><option value="">Choose</option>
                        <?php foreach ($xi_subjects as $sid => $sname): ?><option value="<?php echo (int)$sid; ?>"<?php echo (int)($old['xi_' . $k] ?? $old['xi_main_subject_' . substr($k, -1)] ?? 0) === (int)$sid ? ' selected' : ''; ?>><?php echo h($sname); ?></option><?php endforeach; ?>
                    </select></div>
                <?php endforeach; ?>
                <div class="f wide"><div class="hint">Bengali and English are compulsory for everyone, so they are not chosen here.</div></div>
            </div>
            </div>
            <div class="err" id="xiNone" style="display:<?php echo $is_hs && !$xi_subjects ? 'block' : 'none'; ?>">No subject has been set for this class yet. Please contact the school.</div>
        </div>

        <div class="sec"><i class="fas fa-file-upload"></i> Documents</div>
        <div class="grid">
            <?php foreach (ADM_DOCS as $field => [$label, $kb]): ?>
            <div class="f" data-item="<?php echo h($field); ?>" style="display:<?php echo $ask($field) ? 'block' : 'none'; ?>">
                <label><?php echo h(ADM_ITEMS[$field][0]); ?><?php echo $star($field); ?></label>
                <input type="file" name="<?php echo h($field); ?>" accept="<?php echo in_array($field, ['photo', 'signature'], true) ? '.jpg,.jpeg,.png' : '.jpg,.jpeg,.png,.pdf'; ?>" data-kb="<?php echo (int)$kb; ?>">
                <div class="hint"><?php echo h($doc_note($field)); ?><?php echo $edit_app && !empty($edit_app[$field]) ? ' · one is already there; it stays unless you give a new one' : ''; ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="foot">
            <button type="submit" class="go" id="goBtn"><i class="fas fa-paper-plane"></i> <?php echo $edit_app ? 'Send the changes' : 'Send the application'; ?></button>
            <p style="margin-top:14px;font-size:13px"><a href="admission_status.php" style="color:var(--dark);font-weight:700">Check the status of an earlier application</a></p>
        </div>
    </form>
<?php endif; ?>
    </div>
</div>
<script>
(function () {
    var STAGES = <?php echo json_encode($stage_items, JSON_UNESCAPED_UNICODE); ?>;
    var NAMES = <?php echo json_encode(array_map(fn($s) => $s, ADM_STAGES), JSON_UNESCAPED_UNICODE); ?>;
    var XI = <?php echo json_encode($xi_by_class, JSON_UNESCAPED_UNICODE); ?>;
    var cls = document.getElementById('class_id');
    if (!cls) return;

    function layout() {
        var s = STAGES[cls.value];
        document.getElementById('stageHint').textContent = s ? NAMES[s.stage] : '';
        var ask = s ? s.ask : [], need = s ? s.need : [];
        Array.prototype.forEach.call(document.querySelectorAll('[data-item]'), function (el) {
            var item = el.dataset.item, shown = !s || ask.indexOf(item) >= 0;
            el.style.display = shown ? '' : 'none';
            var star = el.querySelector('.req'), input = el.querySelector('input, select');
            var must = shown && need.indexOf(item) >= 0;
            if (input && input.type !== 'file') input.required = must;
            if (star) star.style.display = must ? '' : 'none';
            else if (must) { var lab = el.querySelector('label'); if (lab) lab.insertAdjacentHTML('beforeend', ' <span class="req">*</span>'); }
        });
        var hs = s && s.stage === 'higher_secondary';
        document.getElementById('hsBlock').style.display = hs ? 'block' : 'none';
        var subjects = hs ? (XI[cls.value] || []) : [];
        Array.prototype.forEach.call(document.querySelectorAll('.xi'), function (sel) {   // the chosen class's own subjects
            var keep = sel.value;
            sel.innerHTML = '<option value="">Choose</option>';
            subjects.forEach(function (x) { var o = document.createElement('option'); o.value = x[0]; o.textContent = x[1]; if (String(x[0]) === keep) o.selected = true; sel.appendChild(o); });
        });
        document.getElementById('xiChoice').style.display = hs && subjects.length ? 'block' : 'none';
        document.getElementById('xiNone').style.display = hs && !subjects.length ? 'block' : 'none';
        Array.prototype.forEach.call(document.querySelectorAll('.hs-need'), function (i) { i.required = !!hs && (!i.classList.contains('xi') || subjects.length > 0); });
        if (typeof xiOnce === 'function') xiOnce();
        var prev = document.getElementById('prevBlock');
        prev.style.display = Array.prototype.some.call(prev.querySelectorAll('[data-item]'), function (el) { return el.style.display !== 'none'; }) || !s ? 'block' : 'none';
        if (hs && document.getElementById('mpBody').children.length === 0) {
            ['Bengali', 'English', 'Mathematics', 'Physical Science', 'Life Science', 'Geography', 'History'].forEach(function (n) { mpRow(n, 100, ''); });
        }
    }
    cls.addEventListener('change', layout);

    var dis = document.getElementById('disability'), disType = document.getElementById('disability_type');
    function disability() { disType.disabled = dis.value !== 'Yes'; if (disType.disabled) disType.value = ''; }
    dis.addEventListener('change', disability);
    ['fa', 'ma'].forEach(function (k) {
        var box = document.getElementById(k + '_na'), input = document.getElementById(k + '_aadhaar');
        box.addEventListener('change', function () { input.disabled = box.checked; if (box.checked) input.value = ''; });
    });

    function mpRow(name, full, got) {
        var tr = document.createElement('tr');
        tr.innerHTML = '<td><input type="text" class="sname" placeholder="Subject"></td><td><input type="number" class="num full" min="1" value="' + (full || 100) + '"></td>' +
            '<td><input type="number" class="num got" min="0" value="' + (got || '') + '" placeholder="0"></td><td><button type="button" class="kill"><i class="fas fa-times"></i></button></td>';
        tr.querySelector('.sname').value = name || '';
        tr.querySelector('.kill').addEventListener('click', function () { tr.remove(); mpTotals(); });
        Array.prototype.forEach.call(tr.querySelectorAll('input'), function (i) { i.addEventListener('input', mpTotals); });
        document.getElementById('mpBody').appendChild(tr);
        mpTotals();
    }
    function mpRows() {
        var out = [];
        Array.prototype.forEach.call(document.querySelectorAll('#mpBody tr'), function (tr) {
            var n = tr.querySelector('.sname').value.trim();
            if (n !== '') out.push({ subject: n, full_marks: +tr.querySelector('.full').value || 0, marks_obtained: +tr.querySelector('.got').value || 0 });
        });
        return out;
    }
    function mpTotals() {
        var rows = mpRows(), full = 0, got = 0;
        rows.forEach(function (r) { full += r.full_marks; got += r.marks_obtained; });
        document.getElementById('mpTotal').textContent = 'Total: ' + got + ' / ' + full + ' | Percentage: ' + (full > 0 ? (got / full * 100).toFixed(2) : 0) + '%';
    }
    var add = document.getElementById('mpAdd');
    if (add) add.addEventListener('click', function () { mpRow('', 100, ''); });
<?php if ($is_hs && !empty($old['mp_subjects_json'])): ?>
    (JSON.parse(<?php echo json_encode((string)$old['mp_subjects_json'], JSON_UNESCAPED_UNICODE); ?>) || []).forEach(function (r) { mpRow(r.subject, r.full_marks, r.marks_obtained); });
<?php endif; ?>

    function xiOnce() {
        var picks = Array.prototype.map.call(document.querySelectorAll('.xi'), function (s) { return s.value; }).filter(Boolean);
        Array.prototype.forEach.call(document.querySelectorAll('.xi'), function (s) {
            Array.prototype.forEach.call(s.options, function (o) { if (o.value) o.disabled = picks.indexOf(o.value) >= 0 && s.value !== o.value; });
        });
    }
    Array.prototype.forEach.call(document.querySelectorAll('.xi'), function (s) { s.addEventListener('change', xiOnce); });

    Array.prototype.forEach.call(document.querySelectorAll('input[type=file]'), function (i) {
        i.addEventListener('change', function () {
            var f = i.files && i.files[0];
            if (!f) return;
            var pdf = f.type === 'application/pdf' || /\.pdf$/i.test(f.name);
            if (pdf && f.size > i.dataset.kb * 1024) { alert('This PDF is larger than ' + i.dataset.kb + ' KB. Please give a smaller file (a PDF is not made smaller for you).'); i.value = ''; }
            else if (f.size > 10 * 1024 * 1024) { alert('That file is too large.'); i.value = ''; }
        });
    });

    var ifsc = document.getElementById('ifsc');
    if (ifsc) ifsc.addEventListener('input', function () {
        ifsc.value = ifsc.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 11);
        if (ifsc.value.length !== 11) return;
        fetch('https://ifsc.razorpay.com/' + ifsc.value).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (d) {
            document.getElementById('bank_name').value = d.BANK || '';
            document.getElementById('branch_name').value = d.BRANCH || '';
            document.getElementById('ifscMsg').textContent = (d.BANK || '') + ' — ' + (d.BRANCH || '');
        }).catch(function () { document.getElementById('ifscMsg').textContent = 'That IFSC was not found — please type the bank and branch yourself.'; });
    });

    var findBox = document.getElementById('findBox'), match = document.getElementById('matchBox'), msg = document.getElementById('findMsg');
    var wasYes = document.getElementById('wasYes'), wasNo = document.getElementById('wasNo');
    function wasToggle() { findBox.style.display = wasYes.checked ? 'block' : 'none'; }
    wasYes.addEventListener('change', wasToggle);
    wasNo.addEventListener('change', function () {
        wasToggle();
        document.getElementById('is_same').value = '0';
        document.getElementById('prev_uid').value = '';
        match.style.display = 'none';
    });

    var set = function (name, val) {
        var el = document.querySelector('[name="' + name + '"]');
        if (!el || !val) return;
        if (el.tagName === 'SELECT') {   // a list chosen from — match the option whatever the letter case
            var want = String(val).trim().toLowerCase();
            Array.prototype.forEach.call(el.options, function (o) { if (o.value.toLowerCase() === want) el.value = o.value; });
        } else el.value = val;
    };
    document.getElementById('findBtn').addEventListener('click', function () {
        var ids = { student_aadhaar: 'find_aadhaar', banglarshiksha_id: 'find_bsid', pen_id: 'find_pen', school_uid: 'find_uid' };
        var query = [], any = false;
        Object.keys(ids).forEach(function (k) {
            var val = document.getElementById(ids[k]).value.trim();
            if (val !== '') any = true;
            query.push(k + '=' + encodeURIComponent(val));
        });
        var dob = document.getElementById('find_dob').value;
        msg.style.color = '#c62828';
        if (!any) { msg.textContent = 'Give any one of these: Aadhaar number, Banglar Shiksha ID, PEN or School UID.'; return; }
        if (!dob) { msg.textContent = 'Please give the date of birth.'; return; }
        query.push('dob=' + encodeURIComponent(dob));
        msg.style.color = '#5d6079';
        msg.textContent = 'Looking…';
        fetch('check_previous_student.php?' + query.join('&')).then(function (r) { return r.json(); }).then(function (d) {
            if (!d.found) { msg.style.color = '#c62828'; msg.textContent = d.message || 'Not found.'; match.style.display = 'none'; return; }
            var s = d.student || {}, g = d.guardian || {};
            msg.textContent = '';
            document.getElementById('is_same').value = '1';
            document.getElementById('prev_uid').value = d.student_id;
            match.style.display = 'block';
            match.innerHTML = '<i class="fas fa-check-circle"></i> Found — <b>' + (s.student_name || '') + '</b>' + (d.last_class ? ', last in ' + d.last_class : '') +
                ' · School UID <b>' + d.student_id + '</b><br>The details below have been filled in — change anything that is out of date. <b>The photo and signature must be uploaded again.</b>';
            ['student_name', 'name_as_per_aadhaar', 'dob', 'gender', 'blood_group', 'religion', 'caste', 'sub_caste', 'birth_registration_number',
             'student_aadhaar', 'banglarshiksha_id', 'pen_id', 'apaar_id', 'village', 'post_office', 'police_station', 'district', 'state', 'pin_code',
             'bank_name', 'branch_name', 'account_number', 'ifsc_code'].forEach(function (k) { set(k, s[k]); });
            set('student_mobile', s.mobile); set('student_email', s.email);
            ['father_name', 'father_voter_id', 'father_mobile', 'father_occupation', 'father_qualification', 'annual_income',
             'mother_name', 'mother_voter_id', 'mother_occupation', 'guardian_name', 'guardian_relation', 'guardian_email'].forEach(function (k) { set(k, g[k]); });
            set('guardian_mobile', g.guardian_contact || g.father_mobile);
            [['father', g.father_aadhaar_not_available, g.father_aadhaar], ['mother', g.mother_aadhaar_not_available, g.mother_aadhaar]].forEach(function (x) {
                var na = document.getElementById(x[0].slice(0, 1) + 'a_na');
                if (+x[1] === 1) { na.checked = true; na.dispatchEvent(new Event('change')); } else set(x[0] + '_aadhaar', x[2]);
            });
            if (s.disability) { set('disability', s.disability); dis.dispatchEvent(new Event('change')); set('disability_type', s.disability_type); }
            layout();
            match.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }).catch(function () { msg.style.color = '#c62828'; msg.textContent = 'Something went wrong on the server. Please try again.'; });
    });
    wasToggle();

    document.getElementById('admForm').addEventListener('submit', function () {
        document.getElementById('mp_json').value = JSON.stringify(mpRows());
        document.getElementById('goBtn').disabled = true;
        setTimeout(function () { document.getElementById('goBtn').disabled = false; }, 8000);
    });
    disability();
    layout();
    xiOnce();
})();
</script>
</div>
<?php site_footer_block(); ?>
</body>
</html>

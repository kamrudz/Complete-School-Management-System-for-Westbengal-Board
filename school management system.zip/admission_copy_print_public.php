<?php
/**
 * admission_copy_print_public.php (PUBLIC, root)
 * The applicant's copy of the admission application, on one A4 sheet. Reached from admission_status.php (after
 * the Application No., mobile and date of birth matched) or from a centre's own list — never from the URL alone.
 * ID numbers are printed with all but the last four digits hidden: the office keeps the full record.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
session_start();
include 'includes/db.php';
require_once 'includes/admission_helper.php';

$app_id = (int)($_SESSION['adm_app_id'] ?? 0);
$app = $app_id ? db_get_row('SELECT aa.*, c.class_name, c.stage, s.session_name FROM admission_applications aa
    JOIN classes c ON c.id = aa.class_id LEFT JOIN academic_sessions s ON s.id = aa.session_id WHERE aa.id = ? LIMIT 1', 'i', $app_id) : null;
if (!$app) { http_response_code(403); exit('Find your application on the status page first, then print a copy.'); }
require_once 'includes/admission_copy.php';
adm_copy_render($app);

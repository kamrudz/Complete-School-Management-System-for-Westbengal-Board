<?php
/**
 * admission_status.php (PUBLIC, root)
 * An applicant looks up their own application with the Application No., the guardian's mobile and the date of birth —
 * all three, so an Application No. alone shows nobody anything. Five wrong tries lock the lookup for 15 minutes.
 * From here they can print the acknowledgement, and edit the application while it is still Pending.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
session_start();
include 'includes/db.php';
require_once 'includes/security.php';
require_once 'includes/admission_helper.php';
require_once 'includes/site.php';
require_once 'includes/centre_helper.php';
$mode = adm_mode();

$school = db_get_row('SELECT school_name FROM school_settings WHERE id = 1') ?: [];
$app = null;
$error = '';
$ref = '';
csrf_token();   // the page carries one whichever view it shows, so a lookup never fails on a missing token

if (isset($_GET['out'])) { unset($_SESSION['adm_app_id'], $_SESSION['adm_edit_id']); header('Location: admission_status.php'); exit(); }

if (isset($_GET['edit']) && !empty($_SESSION['adm_app_id']) && $mode !== 'centres') {
    $row = db_get_row("SELECT id FROM admission_applications WHERE id = ? AND application_status = 'Pending'", 'i', (int)$_SESSION['adm_app_id']);
    if ($row) { $_SESSION['adm_edit_id'] = (int)$row['id']; header('Location: admission.php?edit=1'); exit(); }
    $error = 'The school has started checking this application, so it can no longer be changed.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ref = trim((string)($_POST['application_ref'] ?? ''));
    $mobile = trim((string)($_POST['guardian_mobile'] ?? ''));
    $dob = trim((string)($_POST['dob'] ?? ''));
    $key = 'find:' . adm_client_ip();
    if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) $error = 'Please reload the page and try again.';
    elseif (adm_limit_reached($key, 5, 15)) $error = 'Too many wrong tries. Please try again in 15 minutes.';
    elseif ($ref === '' || $mobile === '' || $dob === '') $error = 'Please give all three: Application No., mobile number and date of birth.';
    else {
        $app = db_get_row('SELECT aa.*, c.class_name FROM admission_applications aa JOIN classes c ON c.id = aa.class_id
            WHERE aa.application_ref = ? AND aa.guardian_mobile = ? AND aa.dob = ? LIMIT 1', 'sss', $ref, $mobile, $dob);
        if ($app) {
            adm_limit_clear($key);
            $_SESSION['adm_app_id'] = (int)$app['id'];
        } else {
            adm_limit_hit($key, 5, 15);
            $error = 'No application matches. Please check the Application No., mobile number and date of birth.';
        }
    }
}
if (!$app && !empty($_SESSION['adm_app_id'])) {
    $app = db_get_row('SELECT aa.*, c.class_name FROM admission_applications aa JOIN classes c ON c.id = aa.class_id WHERE aa.id = ? LIMIT 1', 'i', (int)$_SESSION['adm_app_id']);
}
[$status_label, $status_class] = ADM_STATUS[$app['application_status'] ?? ''] ?? ['', 'off'];
$status_says = [
    'Pending' => 'Your application has been received. The school will check the documents and let you know.',
    'Admitted' => 'Congratulations — your child has been selected. Please come to the school with the original documents to complete the admission and pay the fee.',
    'Waitlisted' => 'Your application is on the waiting list. The school will let you know if a seat becomes free.',
    'Rejected' => 'Sorry, this application was not accepted.',
    'Enrolled' => 'The admission is complete. The school will give you the School UID and the rest of the details.',
][$app['application_status'] ?? ''] ?? '';
$made_at = ($app ?? null) && !empty($app['centre_id']) ? db_get_row('SELECT name, place, phone FROM admission_centres WHERE id = ?', 'i', (int)$app['centre_id']) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application status — <?php echo h($school['school_name'] ?? 'School'); ?></title>
<?php site_chrome_links(); ?>
<style>
    :root { --dark: #2a2886; --light: #3e3cb8; --soft: #f1f0fb; --border: #d9d8f0; }
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #f6f6fb; margin: 0; color: #17163f; font-size: 14px; }
    .wrap { max-width: 640px; margin: 0 auto; }
    .top { background: linear-gradient(135deg, var(--dark), var(--light)); color: #fff; padding: 20px 24px; border-radius: 14px 14px 0 0; }
    .top h1 { margin: 0; font-size: 19px; } .top p { margin: 3px 0 0; font-size: 12.5px; opacity: .85; }
    .card { background: #fff; border-radius: 0 0 14px 14px; box-shadow: 0 4px 18px rgba(0,0,0,.07); padding: 22px; }
    label { display: block; font-size: 12px; font-weight: 700; margin: 12px 0 5px; }
    input { width: 100%; padding: 10px 12px; border: 1px solid #d4d5e6; border-radius: 8px; font-size: 14px; font-family: inherit; }
    input:focus { outline: none; border-color: var(--light); box-shadow: 0 0 0 3px rgba(62,60,184,.15); }
    .go { margin-top: 16px; width: 100%; padding: 12px; background: var(--dark); color: #fff; border: 0; border-radius: 9px; font-weight: 700; font-size: 15px; cursor: pointer; }
    .err { background: #fdecea; color: #8e1b1b; padding: 11px 15px; border-radius: 9px; margin-bottom: 14px; line-height: 1.7; }
    .chip { display: inline-block; padding: 4px 14px; border-radius: 999px; font-size: 12.5px; font-weight: 700; }
    .chip.ok { background: #e9f7ee; color: #1b5e33; } .chip.warn { background: #fff6e5; color: #3a3880; }
    .chip.bad { background: #fdecea; color: #8e1b1b; } .chip.off { background: #eef1f4; color: #55677a; }
    table.sum { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13.5px; }
    table.sum td { padding: 9px 4px; border-bottom: 1px solid #ececf5; }
    table.sum td.k { color: #5d6079; width: 44%; }
    table.sum td.v { font-weight: 700; }
    .says { background: var(--soft); border: 1px solid var(--border); border-radius: 10px; padding: 12px 15px; margin-top: 16px; line-height: 1.8; }
    .acts { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 18px; }
    .acts a { flex: 1 1 150px; text-align: center; padding: 11px; border-radius: 9px; text-decoration: none; font-weight: 700; font-size: 13.5px; border: 1px solid var(--border); color: var(--dark); background: var(--soft); }
    .acts a.main { background: var(--dark); color: #fff; border-color: var(--dark); }
    .hint { font-size: 12.5px; color: #8b8ea6; margin-top: 14px; line-height: 1.7; }
</style>
</head>
<body>
<?php site_header(''); ?>
<div class="form-page" id="main" style="padding:28px 4vw 50px">
<div class="wrap">
    <div class="top"><h1><?php echo h($school['school_name'] ?? 'School'); ?></h1><p>Admission application status</p></div>
    <div class="card">
    <?php if ($error !== ''): ?><div class="err"><i class="fas fa-exclamation-circle"></i> <?php echo h($error); ?></div><?php endif; ?>
    <?php if ($app): ?>
        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <b style="font-size:17px"><?php echo h($app['application_ref']); ?></b>
            <span class="chip <?php echo h($status_class); ?>"><?php echo h($status_label); ?></span>
        </div>
        <table class="sum">
            <tr><td class="k">Student name</td><td class="v"><?php echo h($app['student_name']); ?></td></tr>
            <tr><td class="k">Class</td><td class="v">Class <?php echo h($app['class_name']); ?></td></tr>
            <tr><td class="k">Applied on</td><td class="v"><?php echo h(date('d-m-Y', strtotime($app['created_at']))); ?></td></tr>
            <?php if ($made_at): ?><tr><td class="k">Made at</td><td class="v"><?php echo h($made_at['name'] . ($made_at['place'] ? ', ' . $made_at['place'] : '')); ?><?php echo $made_at['phone'] ? ' · ' . h($made_at['phone']) : ''; ?></td></tr><?php endif; ?>
            <?php if ($app['application_status'] === 'Rejected' && $app['reject_reason']): ?>
            <tr><td class="k">Reason</td><td class="v"><?php echo h($app['reject_reason']); ?></td></tr>
            <?php endif; ?>
        </table>
        <div class="says"><?php echo h($status_says); ?></div>
        <?php if ($app['application_status'] === 'Pending' && $mode === 'centres'): ?><p style="font-size:13px;color:#5d6079">To change anything, go back to <?php echo $made_at ? h($made_at['name']) : 'the centre that made the application'; ?>.</p><?php endif; ?>
        <div class="acts">
            <a class="main" href="admission_copy_print_public.php" target="_blank"><i class="fas fa-print"></i> Print a copy</a>
            <?php if ($app['application_status'] === 'Pending' && $mode !== 'centres'): ?><a href="admission_status.php?edit=1"><i class="fas fa-pen"></i> Edit</a><?php endif; ?>
            <a href="admission_status.php?out=1"><i class="fas fa-times"></i> Close</a>
        </div>
    <?php else: ?>
        <form method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <label>Application No.</label><input type="text" name="application_ref" required value="<?php echo h($ref); ?>" placeholder="e.g. ADM2026-0012">
            <label>Guardian mobile</label><input type="text" name="guardian_mobile" required inputmode="numeric" maxlength="10" oninput="this.value=this.value.replace(/\D/g,'').slice(0,10)">
            <label>Student's date of birth</label><input type="date" name="dob" required max="<?php echo date('Y-m-d'); ?>">
            <button type="submit" class="go"><i class="fas fa-search"></i> Check status</button>
        </form>
        <div class="hint"><i class="fas fa-shield-halved"></i> All three must match, to keep your details safe. For a new application go <a href="admission.php" style="color:var(--dark);font-weight:700">here</a>.</div>
    <?php endif; ?>
    </div>
</div>
</div>
<?php site_footer_block(); ?>
</body>
</html>

/**
 * Auto-save for the board page's tables (includes/board_registration_page.php, includes/board_exam_steps.php):
 *   regno   Reg. No and Year                                  (step 3)
 *   admit   an admit's Roll and No. (HS: one step per semester)
 *   result  the result and % (HS: and each semester's marks)
 * Each row is saved on its own the moment one of its boxes is left — a small POST to the page itself (autosave=1,
 * kind, the form's hidden fields, uid, rid, and every box by its data-f name) answered in JSON:
 * {ok, values, cleared} with the values as the server keeps them, or {ok: false, error}.
 *
 * The table: form#rf[data-kind] (and data-bar: its progress bar, when not the kind's — HS: sem3, sem4), rows
 * tr[data-uid] (and data-rid) with boxes [data-f] and a td.sv for the state.
 * data-saved holds what the server has, as {field: value}; data-done is 1 while the row is complete (the page's
 * "Only not done" filter reads it); data-b is the row's own search text. #svSum tells how many rows are not saved
 * yet; #cnt-<bar> / #bar-<bar> (data-total) and the step's hint show how many are done. Enter or ↓ goes to the next
 * row, ↑ to the one before. window.boardAutosave.saveRows(rows) saves filled rows three at a time (Continuation,
 * "Mark PASS").
 */
(function () {
    var form = document.getElementById('rf');
    if (!form || !window.fetch || !window.FormData) return;   // without them nothing is typed here that could be lost
    var kind = form.dataset.kind || 'regno';
    var rows = Array.prototype.slice.call(form.querySelectorAll('tr[data-uid]'));
    var bid = form.dataset.bar || kind;
    var sum = document.getElementById('svSum'), cnt = document.getElementById('cnt-' + bid), bar = document.getElementById('bar-' + bid);
    var hint = document.querySelector('.ex-steps a.on small');
    var label = { saving: '…', saved: '✓ Saved', cleared: '✓ Cleared' };
    var retry = { failed: 1, bad: 1, offline: 1 };   // states that are not saved even when the boxes did not change
    var year = new Date().getFullYear();
    function up(v) { return String(v || '').replace(/\s+/g, '').toUpperCase(); }
    function str(v) { return String(v == null ? '' : v).trim(); }
    function num(v) { return v === '' || isNaN(+v) ? v : String(+v); }   // 62.50 is 62.5
    function marks(v) { return Object.keys(v).filter(function (f) { return /^sem\d_marks$/.test(f); }).sort(); }
    var K = {
        regno: {
            clean: function (v) { v.reg_no = up(v.reg_no); v.reg_year = str(v.reg_year); return v; },
            key: function (v) { return v.reg_no === '' ? '' : v.reg_no + '|' + v.reg_year; },   // a blank number keeps no year
            done: function (v) { return v.reg_no !== ''; },
            check: function (v) {
                if (v.reg_no === '') return '';
                if (!/^[A-Z0-9\/-]{3,30}$/.test(v.reg_no)) return 'letters, digits, / or - (3 to 30)';
                return /^\d{4}$/.test(v.reg_year) && +v.reg_year >= 2000 && +v.reg_year <= year + 1 ? '' : 'Year: 2000 to ' + (year + 1);
            },
            sticky: { reg_year: 1 }   // a cleared number leaves the year box as it is
        },
        admit: {
            clean: function (v) { v.roll = up(v.roll); v.no = up(v.no); return v; },
            key: function (v) { return v.roll === '' && v.no === '' ? '' : v.roll + '|' + v.no; },
            done: function (v) { return v.roll !== '' && v.no !== ''; },
            check: function (v) {
                if (v.roll !== '' && !/^[A-Z0-9\/-]{2,15}$/.test(v.roll)) return 'Roll: capitals and digits (like 1610N)';
                return v.no !== '' && !/^\d{1,6}$/.test(v.no) ? 'No.: digits only' : '';
            },
            sticky: {}
        },
        result: {   // HS rows also carry each semester's marks (sem3_marks, sem4_marks), which may come before the result
            clean: function (v) {
                v.status = str(v.status); v.pct = str(v.pct);
                if (v.status === '' || v.status === 'ABSENT') v.pct = '';
                marks(v).forEach(function (f) { v[f] = str(v[f]); });
                return v;
            },
            key: function (v) {
                var k = [v.status, num(v.pct)].concat(marks(v).map(function (f) { return num(v[f]); }));
                return k.join('') === '' ? '' : k.join('|');
            },
            done: function (v) { return v.status !== ''; },
            check: function (v) {
                if (v.pct !== '' && (isNaN(+v.pct) || +v.pct < 0 || +v.pct > 100)) return '%: a number from 0 to 100';
                var bad = marks(v).filter(function (f) { return v[f] !== '' && (isNaN(+v[f]) || +v[f] < 0 || +v[f] > 9999); })[0];
                return bad ? 'Sem ' + bad.charAt(3) + ' marks: a number from 0 to 9999' : '';
            },
            sticky: {}
        }
    }[kind];
    if (!K) return;

    function boxes(tr) { return Array.prototype.slice.call(tr.querySelectorAll('[data-f]')); }
    function values(tr) { var v = {}; boxes(tr).forEach(function (b) { v[b.dataset.f] = b.value; }); return K.clean(v); }
    function saved(tr) { try { return K.clean(JSON.parse(tr.dataset.saved || '{}')); } catch (e) { return {}; } }
    function waiting(tr) { return tr.dataset.sv === 'saving' || retry[tr.dataset.sv] || K.key(values(tr)) !== K.key(saved(tr)); }
    function count() {
        var busy = rows.some(function (tr) { return tr.dataset.sv === 'saving'; });
        var left = rows.filter(function (tr) { return tr.dataset.sv !== 'saving' && waiting(tr); }).length;
        if (sum) {
            sum.textContent = busy ? 'Saving…' : (left ? left + ' row(s) not saved' : 'All saved ✓');
            sum.className = 'sv-sum ' + (left && !busy ? 'sv-left' : 'sv-ok');
        }
        var total = bar ? +bar.dataset.total : rows.length;
        var done = rows.filter(function (tr) { return K.done(saved(tr)); }).length;
        if (cnt) cnt.textContent = done + ' of ' + total;
        if (bar) { bar.querySelector('i').style.width = (total ? Math.round(done / total * 100) : 0) + '%'; bar.classList.toggle('full', total > 0 && done === total); }
        if (hint) hint.textContent = total - done ? (total - done) + ' to go' : 'all done';
    }
    function show(tr, state, msg) {
        tr.dataset.sv = state;
        var td = tr.querySelector('td.sv');
        if (td) {
            td.className = 'sv sv-' + (state === 'bad' ? 'failed' : state);
            td.textContent = label[state] || '✗ ' + (msg || 'not saved');
            td.title = msg || '';
        }
        count();
        if (state === 'saved' || state === 'cleared') document.dispatchEvent(new CustomEvent('board:saved', { detail: { row: tr } }));
    }
    function save(tr) {
        if (tr.busy) { tr.again = true; return tr.busy; }
        var v = values(tr);
        if (K.key(v) === K.key(saved(tr)) && !retry[tr.dataset.sv]) return Promise.resolve();
        var why = K.check(v);
        if (why) { show(tr, 'bad', why); return Promise.resolve(); }
        var data = new FormData();
        Array.prototype.forEach.call(form.querySelectorAll('input[type=hidden]'), function (i) { data.append(i.name, i.value); });
        data.append('autosave', '1'); data.append('kind', kind); data.append('uid', tr.dataset.uid);
        if (tr.dataset.rid) data.append('rid', tr.dataset.rid);
        Object.keys(v).forEach(function (f) { data.append(f, v[f]); });
        var sent = K.key(v);
        show(tr, 'saving');
        tr.busy = fetch(location.href, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (r) { return r.json(); })   // a login page or an error page is not JSON: counted as not saved
            .then(function (res) {
                if (!res || !res.ok) { show(tr, 'failed', res && res.error); return; }
                var got = res.values || {};
                if (K.key(values(tr)) === sent) {   // as the server keeps it (capitals, no spaces) — unless typed on meanwhile
                    boxes(tr).forEach(function (b) { var x = got[b.dataset.f]; if (x !== undefined && (x !== '' || !K.sticky[b.dataset.f])) b.value = x; });
                }
                tr.dataset.saved = JSON.stringify(got);
                tr.dataset.done = K.done(K.clean(Object.assign({}, got))) ? '1' : '0';
                if (tr.dataset.b !== undefined) tr.dataset.s = tr.dataset.b + ' ' + Object.keys(got).map(function (f) { return got[f]; }).join(' ').toLowerCase();
                show(tr, res.cleared ? 'cleared' : 'saved');
            })
            .catch(function () { show(tr, 'offline', 'no connection, or logged out — tried again on the next entry'); })
            .then(function () {
                tr.busy = null;
                if (tr.again) { tr.again = false; return save(tr); }
            });
        return tr.busy;
    }
    // many rows at once (Continuation, Mark PASS): three at a time
    function saveRows(list) {
        var todo = list.slice(), i = 0;
        function next() { return i < todo.length ? save(todo[i++]).then(next) : null; }
        count();
        return Promise.all([next(), next(), next()]);
    }
    function move(tr, box, step) {   // to the same box of the next / previous row the filter shows
        var i = rows.indexOf(tr) + step;
        while (rows[i] && rows[i].style.display === 'none') i += step;
        if (!rows[i]) return;
        var to = rows[i].querySelector('[data-f="' + box.dataset.f + '"]');
        if (to) { to.focus(); if (to.select) to.select(); }
    }

    rows.forEach(function (tr) {
        boxes(tr).forEach(function (b) {
            b.addEventListener('change', function () {
                save(tr);
                // a row the connection lost is tried again whenever the next one is entered
                rows.forEach(function (o) { if (o !== tr && o.dataset.sv === 'offline') save(o); });
            });
            b.addEventListener('input', count);
            b.addEventListener('keydown', function (e) {
                if (e.key === 'Enter') { e.preventDefault(); if (b.tagName === 'SELECT') b.dispatchEvent(new Event('change')); move(tr, b, 1); }
                else if (b.tagName !== 'SELECT' && e.key === 'ArrowDown') { e.preventDefault(); move(tr, b, 1); }
                else if (b.tagName !== 'SELECT' && e.key === 'ArrowUp') { e.preventDefault(); move(tr, b, -1); }
            });
        });
    });
    window.addEventListener('beforeunload', function (e) {
        if (rows.some(waiting)) { e.preventDefault(); e.returnValue = ''; }
    });
    window.boardAutosave = { saveRows: saveRows };
    count();
})();

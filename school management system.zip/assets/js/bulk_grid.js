/* Bulk Update grid — one section's students as a spreadsheet.
 * State lives in three Maps; the table is re-rendered from them, so toggling
 * columns never loses edits. Only changed cells are posted (bulk_update_save.php).
 * Files (photo / signature / birth certificate) upload one at a time through
 * student_photo_upload.php or the photo booth (window.PhotoBooth, photo_booth.js).
 */
(function () {
    'use strict';
    const D = JSON.parse(document.getElementById('grid-data').textContent);
    const F = D.fields;
    const table = document.getElementById('grid');
    const thead = table.querySelector('thead'), tbody = table.querySelector('tbody');
    const orig = new Map(D.students.map(s => [s.uid, Object.assign({}, s)]));   // server truth
    const dirty = new Map();   // "uid\tfield" -> value
    const errs = new Map();    // "uid\tfield" -> message
    const FIXED = ['roll_no', 'student_name'];                                    // always visible, sticky
    const LS = 'bulk_cols_v1';
    let cols = [];
    try { cols = JSON.parse(localStorage.getItem(LS) || '[]').filter(c => F[c] && !FIXED.includes(c)); } catch (e) { cols = []; }
    if (!cols.length) cols = ['mobile', 'guardian_contact'];

    const key = (uid, f) => uid + '\t' + f;
    const val = (uid, f) => dirty.has(key(uid, f)) ? dirty.get(key(uid, f)) : (orig.get(uid)[f] ?? '');
    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

    // ---------- column picker ----------
    const picker = document.getElementById('picker');
    picker.querySelectorAll('input[type=checkbox]').forEach(cb => {
        cb.checked = cols.includes(cb.value) || FIXED.includes(cb.value);
        if (FIXED.includes(cb.value)) cb.disabled = true;
        cb.addEventListener('change', () => {
            cols = [...picker.querySelectorAll('input:checked')].map(x => x.value).filter(c => !FIXED.includes(c));
            try { localStorage.setItem(LS, JSON.stringify(cols)); } catch (e) {}
            render();
        });
    });
    document.getElementById('clearCols').addEventListener('click', () => {
        picker.querySelectorAll('input:not(:disabled)').forEach(cb => cb.checked = false);
        cols = []; try { localStorage.setItem(LS, '[]'); } catch (e) {} render();
    });

    // ---------- rendering ----------
    function optionsFor(f, uid) {
        const d = F[f];
        if (d.type === 'class') return D.classes.map(c => [String(c.id), c.name]);
        if (d.type === 'section') { const cid = +val(uid, 'class_id'); return D.sections.filter(s => s.class_id === cid).map(s => [String(s.id), s.name]); }
        return (d.options || []).map(o => [o, o]);
    }
    function cellHtml(uid, f) {
        const d = F[f], k = key(uid, f), v = val(uid, f);
        const cls = (dirty.has(k) ? ' dirty' : '') + (errs.has(k) ? ' err' : '');
        let inner;
        if (d.type === 'file') {
            const name = orig.get(uid)[f];
            // photo / signature are plain files; birth certificate and Aadhaar are locked and come through student_doc.php
            const src = f === 'photo' ? '../uploads/students/' + encodeURIComponent(name) : f === 'signature' ? '../uploads/students/signatures/' + encodeURIComponent(name)
                : 'student_doc.php?uid=' + encodeURIComponent(uid) + '&type=' + (f === 'birth_certificate' ? 'birth' : 'aadhaar') + '&v=' + encodeURIComponent(name);
            inner = '<div class="fcell">' + (name ? '<img src="' + src + '" alt="">' : '<span class="none">none</span>') +
                (f === 'photo' ? '<button type="button" data-act="camera" title="Camera / photo booth"><i class="fas fa-camera"></i></button>' : '') +
                '<button type="button" data-act="file" title="Choose a file"><i class="fas fa-upload"></i></button>' +
                '<input type="file" accept="image/*" hidden' + (f === 'photo' ? ' capture="environment"' : '') + '></div>';
            return '<td class="file" data-uid="' + esc(uid) + '" data-field="' + f + '">' + inner + '</td>';
        }
        if (d.type === 'select' || d.type === 'class' || d.type === 'section') {
            inner = '<select class="cell"><option value="">—</option>' + optionsFor(f, uid).map(([ov, ol]) => '<option value="' + esc(ov) + '"' + (String(ov) === String(v) ? ' selected' : '') + '>' + esc(ol) + '</option>').join('') + '</select>';
        } else {
            inner = '<input class="cell" type="' + (d.type === 'date' ? 'date' : d.type === 'number' ? 'number' : 'text') + '" value="' + esc(v) + '"' + (d.max ? ' maxlength="' + d.max + '"' : '') + (d.type === 'number' ? ' step="any" min="0"' : '') + '>';
        }
        return '<td class="' + cls.trim() + '" data-uid="' + esc(uid) + '" data-field="' + f + '">' + inner + (errs.has(k) ? '<small class="errmsg">' + esc(errs.get(k)) + '</small>' : '') + '</td>';
    }
    function render() {
        thead.innerHTML = '<tr><th class="sticky c-sl">#</th><th class="sticky c-roll">Roll</th><th class="sticky c-name">Student</th>' +
            cols.map(f => '<th>' + esc(F[f].label) + '</th>').join('') + '</tr>';
        let i = 0, html = '';
        for (const uid of orig.keys()) {
            i++;
            html += '<tr data-uid="' + esc(uid) + '"><td class="fixed sticky c-sl">' + i + '</td>' +
                cellHtml(uid, 'roll_no').replace('<td class="', '<td class="sticky c-roll ') +
                cellHtml(uid, 'student_name').replace('<td class="', '<td class="sticky c-name ').replace('</td>', '<span class="uid">' + esc(uid) + '</span></td>') +
                cols.map(f => cellHtml(uid, f)).join('') + '</tr>';
        }
        tbody.innerHTML = html;
        updateBar();
    }
    function rerenderCell(uid, f) {
        const td = tbody.querySelector('td[data-uid="' + CSS.escape(uid) + '"][data-field="' + f + '"]');
        if (!td) return;
        const tmp = document.createElement('tr'); tmp.innerHTML = cellHtml(uid, f);
        const fresh = tmp.firstElementChild; fresh.className = td.className.replace(/\b(dirty|err|ok-flash)\b/g, '').trim() + ' ' + fresh.className;
        td.replaceWith(fresh);
        return fresh;
    }
    function updateBar() {
        const n = dirty.size;
        const dc = document.getElementById('dirtyCount'); dc.hidden = !n; dc.textContent = n + (n === 1 ? ' change' : ' changes');
        document.getElementById('saveBtn').disabled = !n;
        document.getElementById('revertAll').disabled = !n;
    }
    window.addEventListener('beforeunload', e => { if (dirty.size) { e.preventDefault(); e.returnValue = ''; } });

    // ---------- editing ----------
    function setCell(uid, f, v, silent) {
        v = String(v ?? '').trim();
        const k = key(uid, f);
        if (v === String(orig.get(uid)[f] ?? '')) dirty.delete(k); else dirty.set(k, v);
        errs.delete(k);
        if (f === 'class_id') { const sk = key(uid, 'section_id'); dirty.set(sk, ''); errs.delete(sk); if (!silent) rerenderCell(uid, 'section_id'); }
        if (!silent) { const td = tbody.querySelector('td[data-uid="' + CSS.escape(uid) + '"][data-field="' + f + '"]'); if (td) { td.classList.toggle('dirty', dirty.has(k)); td.classList.remove('err'); td.querySelector('.errmsg')?.remove(); } }
        updateBar();
    }
    table.addEventListener('input', e => { const el = e.target; if (!el.classList.contains('cell') || el.tagName === 'SELECT') return; const td = el.closest('td'); setCell(td.dataset.uid, td.dataset.field, el.value); });
    table.addEventListener('change', e => { const el = e.target; if (!el.classList.contains('cell')) return; const td = el.closest('td'); setCell(td.dataset.uid, td.dataset.field, el.value); });

    // keyboard: Enter / arrows move within the column, Ctrl+D fill down, Esc revert
    function cellAt(rowIdx, colIdx) { const tr = tbody.rows[rowIdx]; if (!tr) return null; const tds = [...tr.querySelectorAll('td[data-field]')]; return tds[colIdx] || null; }
    function pos(td) { const tr = td.parentElement; return [tr.rowIndex - 1, [...tr.querySelectorAll('td[data-field]')].indexOf(td)]; }
    function focusCell(td) { const el = td && td.querySelector('.cell'); if (el) { el.focus(); if (el.select) el.select(); } }
    table.addEventListener('keydown', e => {
        const el = e.target; if (!el.classList.contains('cell')) return;
        const td = el.closest('td'), [r, c] = pos(td);
        const isText = el.tagName === 'INPUT' && el.type !== 'date';
        if (e.key === 'Enter' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            if (el.tagName === 'SELECT' && e.key !== 'Enter') return;                    // let the select change its value
            e.preventDefault(); focusCell(cellAt(r + ((e.key === 'ArrowUp' || (e.key === 'Enter' && e.shiftKey)) ? -1 : 1), c));
        } else if (e.key === 'ArrowLeft' && (!isText || el.selectionStart === 0)) { e.preventDefault(); focusCell(cellAt(r, c - 1)); }
        else if (e.key === 'ArrowRight' && (!isText || el.selectionEnd === el.value.length)) { e.preventDefault(); focusCell(cellAt(r, c + 1)); }
        else if (e.key === 'Escape') { e.preventDefault(); setCell(td.dataset.uid, td.dataset.field, orig.get(td.dataset.uid)[td.dataset.field], true); rerenderCell(td.dataset.uid, td.dataset.field); focusCell(cellAt(r, c)); }
        else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') { e.preventDefault(); fillDown(td); }
    });
    function fillDown(td) {
        const [r, c] = pos(td), f = td.dataset.field, v = val(td.dataset.uid, f);
        const n = tbody.rows.length - r - 1; if (n < 1) return;
        if (!confirm('Fill "' + (F[f].label) + '" = "' + v + '" into the ' + n + ' row(s) below?')) return;
        for (let i = r + 1; i < tbody.rows.length; i++) { const t = cellAt(i, c); setCell(t.dataset.uid, f, v, true); }
        render();
    }
    // paste: tab / newline separated block from Excel, starting at the focused cell
    table.addEventListener('paste', e => {
        const el = e.target; if (!el.classList.contains('cell')) return;
        const text = (e.clipboardData || window.clipboardData).getData('text/plain');
        if (!/[\t\n]/.test(text)) return;                                             // single value: native paste
        e.preventDefault();
        const [r0, c0] = pos(el.closest('td'));
        const lines = text.replace(/\r/g, '').split('\n'); while (lines.length && lines[lines.length - 1] === '') lines.pop();
        lines.forEach((line, i) => line.split('\t').forEach((cellText, j) => {
            const td = cellAt(r0 + i, c0 + j); if (!td || td.classList.contains('file')) return;
            const f = td.dataset.field, d = F[f]; let v = cellText.trim();
            if (d.type === 'select' || d.type === 'class' || d.type === 'section') {
                const hit = optionsFor(f, td.dataset.uid).find(([ov, ol]) => ov.toLowerCase() === v.toLowerCase() || ol.toLowerCase() === v.toLowerCase());
                if (hit) v = hit[0]; else if (v !== '') { setCell(td.dataset.uid, f, v, true); errs.set(key(td.dataset.uid, f), 'Not one of the allowed values'); return; }
            }
            if (d.type === 'date') { const m = v.match(/^(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})$/); if (m) v = m[3] + '-' + m[2].padStart(2, '0') + '-' + m[1].padStart(2, '0'); }
            setCell(td.dataset.uid, f, v, true);
        }));
        render();
    });
    document.getElementById('revertAll').addEventListener('click', () => { if (dirty.size && confirm('Discard all ' + dirty.size + ' unsaved change(s)?')) { dirty.clear(); errs.clear(); render(); } });

    // ---------- save ----------
    function toast(msg, ms) { const t = document.getElementById('toast'); t.textContent = msg; t.hidden = false; clearTimeout(t._t); t._t = setTimeout(() => t.hidden = true, ms || 3500); }
    document.getElementById('saveBtn').addEventListener('click', async () => {
        const btn = document.getElementById('saveBtn'); if (!dirty.size) return;
        const changes = [...dirty].map(([k, value]) => { const [uid, field] = k.split('\t'); return { uid, field, value }; });
        btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
        try {
            const res = await fetch('bulk_update_save.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ csrf: D.csrf, session_id: D.session_id, changes }) });
            const j = await res.json();
            if (!j.ok) { toast(j.error || 'Save failed', 6000); return; }
            errs.clear();
            const okCells = [];
            for (const c of j.cells) {
                const k = key(c.uid, c.field);
                if (c.ok) { orig.get(c.uid)[c.field] = c.value; dirty.delete(k); okCells.push(k); }
                else errs.set(k, c.error);
            }
            const rowErr = document.getElementById('rowErrors'), rk = Object.keys(j.rows || {});
            rowErr.hidden = !rk.length; rowErr.innerHTML = rk.map(u => '<b>' + esc(orig.get(u)?.student_name || u) + '</b>: ' + esc(j.rows[u])).join('<br>');
            render();
            okCells.forEach(k => { const [u, f] = k.split('\t'); tbody.querySelector('td[data-uid="' + CSS.escape(u) + '"][data-field="' + f + '"]')?.classList.add('ok-flash'); });
            toast(j.saved_students + ' student(s) saved' + (j.failed_students ? ', ' + j.failed_students + ' need fixing (red cells)' : ''), j.failed_students ? 7000 : 3500);
        } catch (e) { toast('Network error — nothing saved', 6000); }
        finally { btn.innerHTML = '<i class="fas fa-save"></i> Save changes'; updateBar(); }
    });

    // ---------- files ----------
    table.addEventListener('click', e => {
        const b = e.target.closest('button[data-act]'); if (!b) return;
        const td = b.closest('td'), uid = td.dataset.uid, f = td.dataset.field;
        if (b.dataset.act === 'file') td.querySelector('input[type=file]').click();
        else if (b.dataset.act === 'camera') {
            if (!window.PhotoBooth) { toast('Photo booth is still loading…'); return; }
            const s = orig.get(uid);
            window.PhotoBooth.open({ csrf: D.csrf, single: true, students: [{ uid, roll_no: s.roll_no, student_name: s.student_name, photo: s.photo }], onSaved: (u, url, name) => { orig.get(u).photo = name; rerenderCell(u, 'photo'); } });
        }
    });
    table.addEventListener('change', async e => {
        const inp = e.target; if (inp.type !== 'file' || !inp.files[0]) return;
        const td = inp.closest('td'), uid = td.dataset.uid, f = td.dataset.field, file = inp.files[0]; inp.value = '';
        if (f === 'photo' && window.PhotoBooth && window.PhotoBooth.processFile) {
            // same pipeline as the booth: white background, 3:4, ≤ 10 KB — then upload
            const s = orig.get(uid);
            window.PhotoBooth.open({ csrf: D.csrf, single: true, file, students: [{ uid, roll_no: s.roll_no, student_name: s.student_name, photo: s.photo }], onSaved: (u, url, name) => { orig.get(u).photo = name; rerenderCell(u, 'photo'); } });
            return;
        }
        const busy = document.createElement('span'); busy.className = 'busy'; busy.textContent = 'uploading…'; td.querySelector('.fcell').appendChild(busy);
        const fd = new FormData(); fd.append('csrf_token', D.csrf); fd.append('uid', uid); fd.append('kind', f); fd.append('file', file);
        try {
            const j = await (await fetch('student_photo_upload.php', { method: 'POST', body: fd })).json();
            if (!j.ok) { toast(j.error || 'Upload failed', 6000); busy.remove(); return; }
            orig.get(uid)[f] = j.name || j.url.split('/').pop(); rerenderCell(uid, f)?.classList.add('ok-flash'); toast(F[f].label + ' saved (' + Math.round(j.size / 1024) + ' KB)');
        } catch (err) { toast('Network error', 5000); busy.remove(); }
    });

    render();
})();

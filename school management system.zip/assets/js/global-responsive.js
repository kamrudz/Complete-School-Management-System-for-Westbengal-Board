/* =====================================================================
   GLOBAL-RESPONSIVE.JS
   Loaded on every admin page. Its only job: find any <table> that isn't
   already inside a scrollable wrapper (.table-responsive) and wrap it
   in one (.auto-table-scroll), so wide tables scroll horizontally on
   small screens instead of breaking the page layout — without editing
   each page's PHP/HTML by hand.
   ===================================================================== */
(function () {
    function wrapTables() {
        document.querySelectorAll('table').forEach(function (table) {
            var parent = table.parentElement;
            if (!parent) return;

            if (parent.classList.contains('table-responsive') ||
                parent.classList.contains('auto-table-scroll')) {
                return;
            }
            if (table.closest('.table-responsive') || table.closest('.auto-table-scroll')) {
                return;
            }

            var wrapper = document.createElement('div');
            wrapper.className = 'auto-table-scroll';
            parent.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', wrapTables);
    } else {
        wrapTables();
    }
})();

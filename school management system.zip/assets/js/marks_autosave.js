/**
 * Auto-save for a marks grid (Summative Marks Entry: admin and teacher). Each student's row is saved on its own the
 * moment one of its boxes is left or Absent is ticked — a small POST to the page itself (autosave=1, the form's
 * hidden fields, uid, written, project, absent) answered in JSON: {ok, cleared} or {ok: false, error}.
 * So nothing waits for a Save button, and a whole class never goes in one request (PHP keeps only the first 1000
 * fields of a form).
 *
 * The grid: form#mf, rows tr[data-uid] with input.w, input.p (optional), input.abx and a td.sv for the state.
 * data-saved on a row holds what the server has, as ["written","project",absent]. The page marks a box it knows is
 * wrong with the class "bad"; such a row is not sent. #svSum shows how many rows are not saved yet. Submitting the
 * form (the Save button, Ctrl+S) sends every row that is not saved.
 */
(function () {
    var form = document.getElementById('mf');
    if (!form || !window.fetch || !window.FormData) return;   // without them the form's own Save still works
    var rows = Array.prototype.slice.call(form.querySelectorAll('tr[data-uid]'));
    var sum = document.getElementById('svSum');
    var label = { saving: '…', saved: '✓', cleared: '✓ cleared', bad: '✗ check the number' };
    var retry = { failed: 1, bad: 1, offline: 1 };   // states that are not saved even when the boxes did not change

    function snap(tr) {
        var w = tr.querySelector('input.w'), p = tr.querySelector('input.p'), ab = tr.querySelector('input.abx');
        return JSON.stringify([w ? w.value.trim() : '', p ? p.value.trim() : '', ab && ab.checked ? 1 : 0]);
    }
    function waiting(tr) { return tr.dataset.sv === 'saving' || retry[tr.dataset.sv] || snap(tr) !== tr.dataset.saved; }
    function count() {
        if (!sum) return;
        var busy = rows.some(function (tr) { return tr.dataset.sv === 'saving'; });
        var left = rows.filter(function (tr) { return tr.dataset.sv !== 'saving' && waiting(tr); }).length;
        sum.textContent = busy ? 'Saving…' : (left ? left + ' row(s) not saved' : 'All saved ✓');
        sum.className = left && !busy ? 'sv-left' : 'sv-ok';
    }
    function show(tr, state, msg) {
        tr.dataset.sv = state;
        var td = tr.querySelector('td.sv');
        if (td) {
            td.className = 'sv sv-' + state;
            td.textContent = state === 'failed' || state === 'offline' ? '✗ ' + (msg || 'not saved') : (label[state] || '');
            td.title = msg || '';
        }
        count();
    }
    function save(tr) {
        if (tr.busy) { tr.again = true; return tr.busy; }
        var now = snap(tr);
        if (now === tr.dataset.saved && !retry[tr.dataset.sv]) return Promise.resolve();
        if (tr.querySelector('input.bad:not(:disabled)')) { show(tr, 'bad'); return Promise.resolve(); }
        var v = JSON.parse(now), data = new FormData();
        Array.prototype.forEach.call(form.querySelectorAll('input[type=hidden]'), function (i) { data.append(i.name, i.value); });
        data.append('autosave', '1'); data.append('uid', tr.dataset.uid); data.append('written', v[0]); data.append('project', v[1]);
        if (v[2]) data.append('absent', '1');
        show(tr, 'saving');
        tr.busy = fetch(location.href, { method: 'POST', body: data, credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
            .then(function (r) { return r.json(); })   // a login page or an error page is not JSON: counted as not saved
            .then(function (res) {
                if (res && res.ok) { tr.dataset.saved = now; show(tr, res.cleared ? 'cleared' : 'saved'); }
                else show(tr, 'failed', res && res.error);
            })
            .catch(function () { show(tr, 'offline', 'no connection, or logged out — tried again on the next entry'); })
            .then(function () {
                tr.busy = null;
                if (tr.again) { tr.again = false; return save(tr); }
            });
        return tr.busy;
    }
    // everything not saved yet, three at a time
    function saveAll() {
        var todo = rows.filter(waiting), i = 0;
        function next() { return i < todo.length ? save(todo[i++]).then(next) : null; }
        return Promise.all([next(), next(), next()]);
    }

    rows.forEach(function (tr) {
        if (tr.dataset.saved === undefined) tr.dataset.saved = snap(tr);
        Array.prototype.forEach.call(tr.querySelectorAll('input.w, input.p, input.abx'), function (i) {
            i.addEventListener('change', function () {
                save(tr);
                // a row the connection lost is tried again whenever the next one is entered
                rows.forEach(function (o) { if (o !== tr && o.dataset.sv === 'offline') save(o); });
            });
        });
    });
    form.addEventListener('submit', function (e) { e.preventDefault(); saveAll(); });
    window.addEventListener('beforeunload', function (e) {
        if (rows.some(waiting)) { e.preventDefault(); e.returnValue = ''; }
    });
    count();
})();

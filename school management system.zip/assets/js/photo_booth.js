/* Photo booth — student photos from the phone camera or a chosen file.
 *
 * Pipeline (all in the browser): capture → MediaPipe selfie segmentation
 * (self-hosted, no internet) → person on pure white → 3:4 crop centred on the
 * head/torso → 240×320 → JPEG ≤ 10 KB → upload to student_photo_upload.php,
 * which re-checks and re-compresses on the server.
 *
 *   PhotoBooth.open({csrf, students:[{uid, roll_no, student_name, photo}], single, file, onSaved})
 *     single:true  = one student, close after save (grid camera button / file button)
 *     file         = skip the camera, process this File straight away
 *     queue mode   = many students; after each save jumps to the next one without a photo
 *
 * Live camera needs a secure context (https:// or localhost). On the LAN over
 * plain http the "Take photo" button falls back to the phone's own camera app
 * via <input type=file capture="environment"> — same result, one extra tap.
 */
import { FilesetResolver, ImageSegmenter } from '../vendor/mediapipe/vision_bundle.mjs';   // relative to this module file

const VENDOR = new URL('../vendor/mediapipe', import.meta.url).href;                       // absolute, page-independent
const OUT_W = 240, OUT_H = 320, LIMIT = 10240;
let segmenter = null, segLoading = null, segError = '';

async function loadSegmenter() {
    if (segmenter || segError) return segmenter;
    if (segLoading) return segLoading;
    segLoading = (async () => {
        try {
            const files = await FilesetResolver.forVisionTasks(VENDOR + '/wasm');
            for (const delegate of ['GPU', 'CPU']) {
                try {
                    segmenter = await ImageSegmenter.createFromOptions(files, {
                        baseOptions: { modelAssetPath: VENDOR + '/selfie_segmenter.tflite', delegate },
                        runningMode: 'IMAGE', outputCategoryMask: false, outputConfidenceMasks: true,
                    });
                    break;
                } catch (e) { console.warn('segmenter ' + delegate + ' failed', e); }
            }
            if (!segmenter) segError = 'Background removal unavailable on this device — the photo will be uploaded as taken.';
        } catch (e) { console.warn('MediaPipe load failed', e); segError = 'Background removal unavailable — the photo will be uploaded as taken.'; }
        return segmenter;
    })();
    return segLoading;
}

/** Draw any image source upright into a canvas whose longer side is ≤ max. */
function toCanvas(src, max) {
    const w = src.videoWidth || src.width, h = src.videoHeight || src.height;
    const r = Math.min(1, max / Math.max(w, h));
    const c = document.createElement('canvas'); c.width = Math.round(w * r); c.height = Math.round(h * r);
    const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high'; ctx.drawImage(src, 0, 0, c.width, c.height);
    return c;
}
async function fileToCanvas(file) {
    try { const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); const c = toCanvas(bmp, 1024); bmp.close(); return c; }
    catch (e) {
        return new Promise((res, rej) => { const img = new Image(); img.onload = () => { URL.revokeObjectURL(img.src); res(toCanvas(img, 1024)); }; img.onerror = rej; img.src = URL.createObjectURL(file); });
    }
}

/** Person mask (Float32Array w*h, 1 = person) from the segmenter, or null. */
function personMask(canvas) {
    if (!segmenter) return null;
    const res = segmenter.segment(canvas);
    try {
        const masks = res.confidenceMasks; if (!masks || !masks.length) return null;
        const w = canvas.width, h = canvas.height;
        let m = masks[masks.length - 1].getAsFloat32Array();
        // self-check: the centre should score higher than the border for the person channel
        let cSum = 0, cN = 0, bSum = 0, bN = 0;
        for (let y = 0; y < h; y += 4) for (let x = 0; x < w; x += 4) {
            const v = m[y * w + x];
            if (x > w * 0.4 && x < w * 0.6 && y > h * 0.4 && y < h * 0.6) { cSum += v; cN++; }
            else if (x < w * 0.05 || x > w * 0.95 || y < h * 0.05) { bSum += v; bN++; }
        }
        if (cN && bN && bSum / bN > cSum / cN) { if (masks.length > 1) m = masks[0].getAsFloat32Array(); else m = m.map(v => 1 - v); }
        return Float32Array.from(m);
    } finally { res.close && res.close(); }
}

/** White background + 3:4 crop around the person → 240×320 canvas. */
function composePortrait(src, mask) {
    const w = src.width, h = src.height;
    const out = document.createElement('canvas'); out.width = OUT_W; out.height = OUT_H;
    const octx = out.getContext('2d'); octx.fillStyle = '#fff'; octx.fillRect(0, 0, OUT_W, OUT_H); octx.imageSmoothingQuality = 'high';
    let sx = 0, sy = 0, sw = w, sh = h, work = src;
    if (mask) {
        const ctx = src.getContext('2d'), img = ctx.getImageData(0, 0, w, h), d = img.data;
        let minX = w, maxX = -1, minY = h, maxY = -1, n = 0;
        for (let i = 0, p = 0; i < mask.length; i++, p += 4) {
            const a = Math.min(1, Math.max(0, (mask[i] - 0.35) / 0.3));
            d[p] = d[p] * a + 255 * (1 - a); d[p + 1] = d[p + 1] * a + 255 * (1 - a); d[p + 2] = d[p + 2] * a + 255 * (1 - a);
            if (mask[i] > 0.5) { n++; const x = i % w, y = (i / w) | 0; if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
        }
        if (n < mask.length * 0.02) return null;                                         // nobody in the frame
        work = document.createElement('canvas'); work.width = w; work.height = h; work.getContext('2d').putImageData(img, 0, 0);
        // crop: person width × 1.5, 3:4, head near the top, never wider than the frame
        sw = Math.min(w, (maxX - minX) * 1.5); sh = sw * 4 / 3;
        if (sh > h) { sh = h; sw = sh * 3 / 4; }
        sx = (minX + maxX) / 2 - sw / 2; sy = minY - 0.10 * sh;
        sx = Math.max(0, Math.min(w - sw, sx)); sy = Math.max(0, Math.min(h - sh, sy));
    } else {
        // no mask: centre crop to 3:4
        if (w / h > 3 / 4) { sw = h * 3 / 4; sx = (w - sw) / 2; } else { sh = w * 4 / 3; sy = (h - sh) / 2; }
    }
    octx.drawImage(work, sx, sy, sw, sh, 0, 0, OUT_W, OUT_H);
    return out;
}

async function toJpegUnder(canvas, limit) {
    let last = null;
    for (const [w, h] of [[OUT_W, OUT_H], [210, 280], [180, 240]]) {
        let c = canvas;
        if (w !== canvas.width) { c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(canvas, 0, 0, w, h); }
        for (let q = 0.86; q >= 0.4; q -= 0.07) {
            const b = await new Promise(r => c.toBlob(r, 'image/jpeg', q));
            last = b; if (b && b.size <= limit) return b;
        }
    }
    return last;   // the server loop finishes the job
}

// ---------------------------------------------------------------- UI
const PhotoBooth = {
    open(opts) { return new Booth(opts); },
    processFile: true,
};
class Booth {
    constructor(o) {
        this.o = o; this.students = o.students || []; this.i = 0; this.stream = null; this.result = null;
        if (!o.single) { const first = this.students.findIndex(s => !s.photo); this.i = first >= 0 ? first : 0; }
        this.el = document.createElement('div'); this.el.className = 'pb';
        this.el.innerHTML =
            '<div class="pb-top"><div class="who"><b></b><small></small></div><span class="count"></span><button type="button" data-a="close"><i class="fas fa-times"></i> Close</button></div>' +
            '<div class="pb-stage"><video playsinline autoplay muted hidden></video><img class="preview" alt="" hidden>' +
            '<div class="frame" hidden><div class="box"><div class="oval"></div><small>Head inside the oval · plain background behind</small></div></div><div class="pb-msg" hidden></div>' +
            '<div class="pb-list" hidden></div></div>' +
            '<div class="pb-bottom"></div>';
        document.body.appendChild(this.el);
        this.el.querySelector('[data-a=close]').addEventListener('click', () => this.close());
        this.video = this.el.querySelector('video'); this.preview = this.el.querySelector('img.preview'); this.frame = this.el.querySelector('.frame');
        this.msg = this.el.querySelector('.pb-msg'); this.bottom = this.el.querySelector('.pb-bottom'); this.list = this.el.querySelector('.pb-list');
        loadSegmenter().then(() => { if (segError) this.say(segError, true); });
        if (o.file) { this.show(); this.process(o.file); } else this.show();
    }
    cur() { return this.students[this.i]; }
    say(t, warn) { this.msg.hidden = !t; this.msg.textContent = t || ''; this.msg.className = 'pb-msg' + (warn === 'err' ? ' err' : ''); }
    show() {
        const s = this.cur(); if (!s) { this.close(); return; }
        this.el.querySelector('.who b').textContent = (s.roll_no ? 'Roll ' + s.roll_no + ' — ' : '') + s.student_name;
        this.el.querySelector('.who small').textContent = s.uid + (s.photo ? ' · has a photo (will be replaced)' : ' · no photo yet');
        const done = this.students.filter(x => x.photo).length;
        this.el.querySelector('.count').textContent = this.o.single ? 'Photo' : done + ' / ' + this.students.length + ' have photos';
        if (!this.o.single) {
            this.list.hidden = false;
            this.list.innerHTML = this.students.map((x, k) => '<div class="' + (k === this.i ? 'cur' : '') + (x.photo ? ' done' : '') + '" data-k="' + k + '"><span>' + (x.roll_no ? x.roll_no + '. ' : '') + x.student_name.replace(/[<>&]/g, '') + '</span><span>' + (x.photo ? '✓' : '') + '</span></div>').join('');
            this.list.onclick = e => { const d = e.target.closest('[data-k]'); if (d) { this.i = +d.dataset.k; this.result = null; this.show(); } };
        }
        this.result = null; this.preview.hidden = true; this.video.hidden = true; this.frame.hidden = true;
        this.bottom.innerHTML = '<button type="button" class="cap" data-a="cam"><i class="fas fa-camera"></i> Take photo</button>' +
            '<label class="btnlike alt"><i class="fas fa-image"></i> Choose file<input type="file" accept="image/*"></label>' +
            (this.o.single ? '' : '<button type="button" class="alt" data-a="skip"><i class="fas fa-forward"></i> Skip</button>');
        this.bottom.querySelector('input[type=file]').addEventListener('change', e => { if (e.target.files[0]) this.process(e.target.files[0]); });
        this.bottom.querySelector('[data-a=cam]').addEventListener('click', () => this.camera());
        this.bottom.querySelector('[data-a=skip]')?.addEventListener('click', () => this.next());
        if (this.stream) this.camera();
    }
    async camera() {
        const secure = window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;
        if (!secure) {
            // http on the LAN: the browser will not open a live camera — use the phone's camera app
            const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.setAttribute('capture', 'environment');
            inp.onchange = () => { if (inp.files[0]) this.process(inp.files[0]); };
            this.say('Live camera needs https:// — opening the phone camera app instead.'); inp.click(); return;
        }
        try {
            if (!this.stream) this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 960 } }, audio: false });
            this.video.srcObject = this.stream; this.video.hidden = false; this.frame.hidden = false; this.preview.hidden = true; this.say('');
            this.bottom.innerHTML = '<button type="button" class="cap" data-a="snap"><i class="fas fa-circle"></i> Capture</button><button type="button" class="alt" data-a="flip"><i class="fas fa-sync"></i> Flip</button><button type="button" class="alt" data-a="stop">Cancel</button>';
            this.bottom.querySelector('[data-a=snap]').addEventListener('click', () => { const c = toCanvas(this.video, 1024); this.processCanvas(c); });
            this.bottom.querySelector('[data-a=flip]').addEventListener('click', async () => { this.facing = this.facing === 'user' ? 'environment' : 'user'; this.stopStream(); this.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: this.facing } }, audio: false }); this.video.srcObject = this.stream; });
            this.bottom.querySelector('[data-a=stop]').addEventListener('click', () => { this.stopStream(); this.show(); });
        } catch (e) { this.say('Camera not available (' + (e.name || e) + ') — choose a file instead.', 'err'); }
    }
    stopStream() { if (this.stream) { this.stream.getTracks().forEach(t => t.stop()); this.stream = null; } this.video.srcObject = null; this.video.hidden = true; this.frame.hidden = true; }
    async process(file) { this.say('Reading photo…'); try { this.processCanvas(await fileToCanvas(file)); } catch (e) { this.say('Could not read that file.', 'err'); } }
    async processCanvas(src) {
        this.video.hidden = true; this.frame.hidden = true; this.say('Removing background…');
        await loadSegmenter();
        let mask = null;
        try { mask = personMask(src); } catch (e) { console.warn('segment failed', e); }
        const portrait = composePortrait(src, mask);
        if (!portrait) { this.say('No person found in the photo — take it again with the head inside the oval.', 'err'); return; }
        const blob = await toJpegUnder(portrait, LIMIT);
        this.result = blob;
        this.preview.src = URL.createObjectURL(blob); this.preview.hidden = false;
        this.say(segmenter ? '' : segError, true);
        this.bottom.innerHTML = '<button type="button" class="save" data-a="save"><i class="fas fa-check"></i> Save</button><button type="button" class="alt" data-a="retake"><i class="fas fa-redo"></i> Retake</button><span class="size">' + OUT_W + '×' + OUT_H + ' · ' + (blob.size / 1024).toFixed(1) + ' KB' + (mask ? ' · background removed' : '') + '</span>';
        this.bottom.querySelector('[data-a=save]').addEventListener('click', () => this.save());
        this.bottom.querySelector('[data-a=retake]').addEventListener('click', () => this.show());
    }
    async save() {
        const s = this.cur(), b = this.bottom.querySelector('[data-a=save]'); b.disabled = true; b.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
        const fd = new FormData(); fd.append('csrf_token', this.o.csrf); fd.append('uid', s.uid); fd.append('kind', 'photo'); fd.append('file', this.result, 'photo.jpg');
        try {
            const j = await (await fetch('student_photo_upload.php', { method: 'POST', body: fd })).json();
            if (!j.ok) { this.say(j.error || 'Upload failed', 'err'); b.disabled = false; b.innerHTML = '<i class="fas fa-check"></i> Save'; return; }
            const name = j.url.split('/').pop(); s.photo = name;
            if (this.o.onSaved) this.o.onSaved(s.uid, j.url, name);
            this.say('Saved ' + (j.size / 1024).toFixed(1) + ' KB ✓');
            if (this.o.single) { setTimeout(() => this.close(), 600); } else { setTimeout(() => this.next(true), 500); }
        } catch (e) { this.say('Network error — not saved', 'err'); b.disabled = false; b.innerHTML = '<i class="fas fa-check"></i> Save'; }
    }
    next(afterSave) {
        // the next student without a photo, else the next one in the list
        let k = this.students.findIndex((x, idx) => idx > this.i && !x.photo);
        if (k < 0) k = this.students.findIndex(x => !x.photo);
        if (k < 0) { if (afterSave) { this.say('All students in this section have a photo ✓'); this.i = Math.min(this.i + 1, this.students.length - 1); } else this.i = (this.i + 1) % this.students.length; }
        else this.i = k;
        this.show();
    }
    goto(uid) { const k = this.students.findIndex(s => s.uid === uid); if (k >= 0) { this.i = k; this.show(); } }
    close() { this.stopStream(); this.el.remove(); if (this.o.onClose) this.o.onClose(); }
}
window.PhotoBooth = PhotoBooth;
loadSegmenter();
export default PhotoBooth;

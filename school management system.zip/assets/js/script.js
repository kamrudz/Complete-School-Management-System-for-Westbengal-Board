document.addEventListener("DOMContentLoaded", function () {
    const lightbox = document.getElementById("lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const closeBtn = document.querySelector(".close");

    document.querySelectorAll(".slider img").forEach(function (img) {
        img.addEventListener("click", function () {
            if (!lightbox || !lightboxImg) return;
            lightbox.style.display = "flex";
            lightboxImg.src = this.src;
        });
    });

    if (closeBtn && lightbox) {
        closeBtn.addEventListener("click", function () {
            lightbox.style.display = "none";
        });
    }

    if (lightbox) {
        lightbox.addEventListener("click", function (e) {
            if (e.target === lightbox) {
                lightbox.style.display = "none";
            }
        });
    }

    const slider = document.querySelector(".slider");
    const prevBtn = document.querySelector(".prev");
    const nextBtn = document.querySelector(".next");

    if (slider && prevBtn && nextBtn) {
        const scrollSlider = function (direction) {
            slider.scrollLeft += direction * 320;
        };

        prevBtn.addEventListener("click", function () {
            scrollSlider(-1);
        });

        nextBtn.addEventListener("click", function () {
            scrollSlider(1);
        });
    }

    document.querySelectorAll('nav a[href^="#"]').forEach(function (anchor) {
        anchor.addEventListener("click", function (e) {
            const target = document.querySelector(this.getAttribute("href"));
            if (!target) return;
            e.preventDefault();
            target.scrollIntoView({ behavior: "smooth", block: "start" });
        });
    });
});

// The public website: the phone menu, the login list, the photo viewer, and sections easing in as they scroll up.
(function () {
    var burger = document.querySelector('.burger'), nav = document.querySelector('.nav');
    if (burger && nav) {
        burger.addEventListener('click', function () {
            var open = nav.classList.toggle('open');
            burger.setAttribute('aria-expanded', open ? 'true' : 'false');
            burger.innerHTML = open ? '<i class="fas fa-xmark"></i>' : '<i class="fas fa-bars"></i>';
        });
    }

    document.querySelectorAll('.drop > button').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var drop = btn.parentElement, open = !drop.classList.contains('open');
            document.querySelectorAll('.drop.open').forEach(function (d) { d.classList.remove('open'); });
            drop.classList.toggle('open', open);
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    });
    document.addEventListener('click', function () {
        document.querySelectorAll('.drop.open').forEach(function (d) { d.classList.remove('open'); });
    });

    var box = document.querySelector('.lightbox');
    if (box) {
        var img = box.querySelector('img'), cap = box.querySelector('.cap'), items = [], at = 0;
        document.querySelectorAll('[data-light]').forEach(function (a, i) {
            items.push({ src: a.getAttribute('href'), title: a.getAttribute('data-title') || '' });
            a.addEventListener('click', function (e) { e.preventDefault(); show(i); });
        });
        function show(i) {
            if (!items.length) return;
            at = (i + items.length) % items.length;
            img.src = items[at].src; img.alt = items[at].title; cap.textContent = items[at].title;
            box.classList.add('open'); document.body.style.overflow = 'hidden';
        }
        function hide() { box.classList.remove('open'); document.body.style.overflow = ''; img.src = ''; }
        box.querySelector('.x').addEventListener('click', hide);
        box.querySelector('.prev').addEventListener('click', function (e) { e.stopPropagation(); show(at - 1); });
        box.querySelector('.next').addEventListener('click', function (e) { e.stopPropagation(); show(at + 1); });
        box.addEventListener('click', function (e) { if (e.target === box) hide(); });
        document.addEventListener('keydown', function (e) {
            if (!box.classList.contains('open')) return;
            if (e.key === 'Escape') hide();
            if (e.key === 'ArrowLeft') show(at - 1);
            if (e.key === 'ArrowRight') show(at + 1);
        });
    }

    var filter = document.querySelector('[data-filter]');
    if (filter) {
        var cards = document.querySelectorAll('[data-find]'), groups = document.querySelectorAll('[data-group]'), none = document.querySelector('[data-none]');
        filter.addEventListener('input', function () {
            var q = filter.value.trim().toLowerCase(), shown = 0;
            cards.forEach(function (c) {
                var hit = !q || c.getAttribute('data-find').indexOf(q) !== -1;
                c.style.display = hit ? '' : 'none';
                if (hit) shown++;
            });
            groups.forEach(function (g) {
                g.style.display = g.querySelectorAll('[data-find]:not([style*="none"])').length ? '' : 'none';
            });
            if (none) none.style.display = shown ? 'none' : '';
        });
    }

    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('seen'); io.unobserve(en.target); } });
        }, { rootMargin: '0px 0px -40px 0px' });
        document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
    } else {
        document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('seen'); });
    }
})();

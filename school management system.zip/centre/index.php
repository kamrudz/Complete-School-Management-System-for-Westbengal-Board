<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/db.php';
require_once '../includes/centre_helper.php';
centre_session();
require_once '../includes/security.php';
require_once '../includes/admission_helper.php';
require_once '../includes/exam_ui.php';

/**
 * A centre's own page: the applications it has made, a copy of each to print, and a change to one still
 * Pending. Nothing of another centre's is ever read here — every query is bound to this centre's id.
 */
$centre = centre_current();
if (!$centre) { header('Location: login.php'); exit(); }
$cid = (int)$centre['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'logout') { centre_logout(); header('Location: login.php'); exit(); }
    $id = (int)($_POST['id'] ?? 0);
    $app = $id ? db_get_row('SELECT id, application_status FROM admission_applications WHERE id = ? AND centre_id = ?', 'ii', $id, $cid) : null;
    if (!$app) { $_SESSION['error'] = 'That application is not one of this centre\'s.'; header('Location: index.php'); exit(); }
    if ($act === 'print') {
        $_SESSION['adm_app_id'] = (int)$app['id'];
        header('Location: ../admission_copy_print_public.php');
        exit();
    }
    if ($act === 'edit') {
        if ($app['application_status'] !== 'Pending') { $_SESSION['error'] = 'Only a Pending application can still be changed — the school has already looked at this one.'; header('Location: index.php'); exit(); }
        $_SESSION['adm_edit_id'] = (int)$app['id'];
        header('Location: ../admission.php?edit=1');
        exit();
    }
    header('Location: index.php');
    exit();
}

$settings = adm_settings();
$closed = adm_closed_reason($settings);
$session_id = (int)$settings['admission_session_id'];
$search = trim((string)($_GET['q'] ?? ''));
$per = 25;
$page = max(1, (int)($_GET['page'] ?? 1));

$counts = db_get_row("SELECT COUNT(*) total, SUM(DATE(created_at) = CURDATE()) today,
    SUM(application_status = 'Pending') pending, SUM(application_status IN ('Admitted','Enrolled')) taken
    FROM admission_applications WHERE centre_id = ?", 'i', $cid) ?: [];
$where = 'a.centre_id = ?';
$types = 'i';
$params = [$cid];
if ($search !== '') {
    $where .= ' AND (a.application_ref LIKE ? OR a.student_name LIKE ? OR a.guardian_mobile LIKE ?)';
    $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
    $types .= 'sss';
    array_push($params, $like, $like, $like);
}
$total = (int)(db_get_row("SELECT COUNT(*) n FROM admission_applications a WHERE $where", $types, ...$params)['n'] ?? 0);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) $page = $pages;
$rows = db_get_all("SELECT a.id, a.application_ref, a.student_name, a.guardian_mobile, a.application_status, a.created_at, c.class_name, s.session_name
    FROM admission_applications a LEFT JOIN classes c ON c.id = a.class_id LEFT JOIN academic_sessions s ON s.id = a.session_id
    WHERE $where ORDER BY a.id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $types, ...$params);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($centre['name']); ?> — Application centre</title>
<?php exam_styles('site'); ?>
<style>
    body { background: #f6f6fb; }
    .page-box { max-width: 1180px; margin: 0 auto; padding: 22px 16px 40px; }
    .sb { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .sb div { background: #fff; border: 1px solid #dfe7ef; border-left: 4px solid var(--ex-light); border-radius: 10px; padding: 10px 13px; }
    .sb b { display: block; font-size: 22px; font-weight: 800; color: var(--ex-dark); }
    .sb span { font-size: 11px; color: #6b7d90; text-transform: uppercase; letter-spacing: .3px; }
    .acts { display: flex; gap: 6px; flex-wrap: wrap; }
    .acts form { display: inline; }
    .ref { font-weight: 800; letter-spacing: .5px; color: var(--ex-dark); }
    .pager { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 12px; font-size: 13px; }
    .pager a, .pager span { padding: 5px 10px; border: 1px solid #d5dde5; border-radius: 7px; text-decoration: none; color: #3b5168; }
    .pager .on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); }
    .ex-banner .links form { display: inline; }
</style>
</head>
<body>
<div class="page-box">
    <?php exam_banner($centre['name'], 'Application centre' . ($centre['place'] ? ' · ' . $centre['place'] : '') . ' · logged in as ' . $centre['username'], 'fa-store'); ?>
    <?php exam_flash(); ?>

    <div class="card" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <?php if ($closed === ''): ?>
            <a href="../admission.php" class="btn btn-success"><i class="fas fa-plus"></i> New application</a>
            <span class="note" style="margin:0">Admission is open<?php echo $session_id ? ' for ' . h(adm_session_name($session_id)) : ''; ?><?php echo !empty($settings['admission_end']) ? ' · last date ' . h(date('d M Y', strtotime($settings['admission_end']))) : ''; ?>. Everything you send is marked as made at this centre.</span>
        <?php else: ?>
            <span class="chip off"><?php echo h($closed); ?></span>
            <span class="note" style="margin:0">You can still print a copy of the applications already made.</span>
        <?php endif; ?>
        <form method="post" style="margin-left:auto">
            <?php echo csrf_field(); ?><input type="hidden" name="act" value="logout">
            <button type="submit" class="btn btn-secondary"><i class="fas fa-right-from-bracket"></i> Log out</button>
        </form>
    </div>

    <div class="sb">
        <div><b><?php echo (int)($counts['today'] ?? 0); ?></b><span>Made today</span></div>
        <div><b><?php echo (int)($counts['total'] ?? 0); ?></b><span>Made in all</span></div>
        <div><b><?php echo (int)($counts['pending'] ?? 0); ?></b><span>Waiting for the school</span></div>
        <div><b><?php echo (int)($counts['taken'] ?? 0); ?></b><span>Selected</span></div>
    </div>

    <form method="get" class="card pick">
        <div><label>Find</label><input type="search" name="q" value="<?php echo h($search); ?>" placeholder="Application No., student or mobile" style="min-width:260px"></div>
        <div><button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Find</button></div>
        <?php if ($search !== ''): ?><div><a href="index.php" class="btn btn-secondary">Show all</a></div><?php endif; ?>
    </form>

    <div class="card">
        <h2><i class="fas fa-list"></i> Applications made here <small><?php echo number_format($total); ?></small></h2>
        <?php if (!$rows): ?>
            <div class="ex-empty"><i class="fas fa-file-pen"></i><?php echo $search !== '' ? 'Nothing matches "' . h($search) . '".' : 'No application yet. Start one with "New application".'; ?></div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="ex-table">
            <thead><tr><th>Application No.</th><th>Student</th><th>Class</th><th>Mobile</th><th>Sent</th><th>Where it stands</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): [$label, $chip] = ADM_STATUS[$r['application_status']] ?? [$r['application_status'], 'off']; ?>
                <tr>
                    <td class="ref"><?php echo h($r['application_ref']); ?></td>
                    <td><b><?php echo h($r['student_name']); ?></b></td>
                    <td><?php echo h(trim('Class ' . ($r['class_name'] ?? '') . ($r['session_name'] ? ' · ' . $r['session_name'] : ''))); ?></td>
                    <td><?php echo h($r['guardian_mobile']); ?></td>
                    <td><?php echo h(date('d M Y, g:i a', strtotime($r['created_at']))); ?></td>
                    <td><span class="chip <?php echo h($chip); ?>"><?php echo h($label); ?></span></td>
                    <td>
                        <div class="acts">
                            <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="act" value="print"><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-info btn-sm" title="Print the copy"><i class="fas fa-print"></i> Copy</button></form>
                            <?php if ($r['application_status'] === 'Pending' && $closed === ''): ?>
                            <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="act" value="edit"><input type="hidden" name="id" value="<?php echo (int)$r['id']; ?>">
                                <button type="submit" class="btn btn-warning btn-sm" title="Change it"><i class="fas fa-pen"></i> Change</button></form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php if ($pages > 1): ?>
        <div class="pager">
            <?php for ($p = 1; $p <= $pages; $p++): ?>
                <?php if ($p === $page): ?><span class="on"><?php echo $p; ?></span><?php else: ?><a href="<?php echo h('index.php?' . http_build_query(array_filter(['q' => $search, 'page' => $p]))); ?>"><?php echo $p; ?></a><?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <p class="note">A copy can be printed at any time. A change is possible only while the school has not yet looked at the application.</p>
    </div>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once '../includes/db.php';
require_once '../includes/centre_helper.php';
centre_session();
require_once '../includes/security.php';

/** Login for an application centre. Five wrong passwords lock the username for fifteen minutes. */
if (centre_current()) { header('Location: index.php'); exit(); }

$error = '';
$username = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $username = strtolower(trim((string)($_POST['username'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    if ($username === '' || $password === '') $error = 'Give the centre\'s username and password.';
    else {
        [$ok, $result] = centre_login($username, $password);
        if ($ok) { header('Location: index.php'); exit(); }
        $error = $result;
    }
}
$school = db_get_row('SELECT school_name, logo FROM school_settings WHERE id = 1') ?: [];
if (!function_exists('h')) { function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Application centre — <?php echo h($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600;9..144,700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
    :root { --ink: #17163f; --brand: #2a2886; --brand-2: #3e3cb8; --gold: #f4c20d; --line: #e4e4f0; --muted: #5d6079; }
    * { box-sizing: border-box; }
    body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px 16px;
           font-family: Inter, 'Segoe UI', sans-serif; color: var(--ink);
           background: repeating-conic-gradient(from 0deg at 50% 120%, rgba(255,255,255,.04) 0deg 6deg, transparent 6deg 14deg), linear-gradient(135deg, #17163f, #2a2886 70%, #3e3cb8); }
    .box { width: 100%; max-width: 410px; background: #fff; border-radius: 18px; padding: 30px 28px 26px; box-shadow: 0 30px 80px rgba(0,0,0,.35); }
    .seal { width: 76px; height: 76px; border-radius: 50%; margin: 0 auto 14px; display: block; box-shadow: 0 0 0 4px #fff, 0 0 0 7px var(--gold); object-fit: contain; background: #fff; }
    h1 { font-family: Fraunces, Georgia, serif; font-size: 23px; text-align: center; margin: 0 0 4px; }
    .sub { text-align: center; color: var(--muted); font-size: 14px; margin: 0 0 22px; }
    label { display: block; font-size: 13px; font-weight: 700; margin: 14px 0 6px; }
    input { width: 100%; height: 48px; border: 1px solid var(--line); border-radius: 11px; padding: 0 14px; font: 15px Inter, sans-serif; }
    input:focus { outline: none; border-color: var(--brand); box-shadow: 0 0 0 4px #eceafb; }
    button { width: 100%; height: 50px; margin-top: 20px; border: 0; border-radius: 11px; background: var(--brand); color: #fff; font: 700 15px Inter, sans-serif; cursor: pointer; }
    button:hover { background: var(--brand-2); }
    .err { background: #fdecea; color: #b42318; border-radius: 10px; padding: 11px 13px; font-size: 14px; font-weight: 600; margin-bottom: 6px; }
    .foot { text-align: center; margin-top: 18px; font-size: 13px; color: var(--muted); }
    .foot a { color: var(--brand); font-weight: 600; text-decoration: none; }
</style>
</head>
<body>
<main class="box">
    <?php if (!empty($school['logo'])): ?><img class="seal" src="<?php echo h('../uploads/' . $school['logo']); ?>" alt=""><?php endif; ?>
    <h1>Application centre</h1>
    <p class="sub"><?php echo h($school['school_name'] ?? ''); ?></p>
    <?php if ($error !== ''): ?><div class="err" role="alert"><i class="fas fa-circle-exclamation"></i> <?php echo h($error); ?></div><?php endif; ?>
    <form method="post" autocomplete="on">
        <?php echo csrf_field(); ?>
        <label for="u">Username</label>
        <input id="u" type="text" name="username" value="<?php echo h($username); ?>" required autocomplete="username" autocapitalize="none" spellcheck="false">
        <label for="p">Password</label>
        <input id="p" type="password" name="password" required autocomplete="current-password">
        <button type="submit"><i class="fas fa-right-to-bracket"></i> Log in</button>
    </form>
    <p class="foot">A centre account is given by the school office.<br><a href="../index.php">Back to the school's website</a></p>
</main>
</body>
</html>

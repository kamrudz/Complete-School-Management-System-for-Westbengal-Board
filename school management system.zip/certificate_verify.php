<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
// ===== NO LOGIN CHECK - this is a public page for anyone with the QR/link =====
include("includes/db.php");
require_once __DIR__ . '/includes/card_document_helper.php';

$token = $_GET['token'] ?? '';
$valid_token_format = preg_match('/^[a-f0-9]{64}$/', $token);

$cert = null;
if($valid_token_format) {
    $stmt = mysqli_prepare($conn, "
        SELECT c.*, s.student_name, s.admission_no, s.photo, s.banglarshiksha_id, s.pen_id,
               g.father_name,
               cl.class_name, sec.section_name, ss.session_name
        FROM certificates c
        LEFT JOIN students s ON s.id = c.student_id
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN student_academic_history h ON h.student_id = c.student_id AND h.academic_status='Current'
        LEFT JOIN classes cl ON cl.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN academic_sessions ss ON ss.id = h.session_id
        WHERE c.verification_token = ?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $cert = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$school = document_get_school_settings($conn, 'verify_basic');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Certificate Verification</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: linear-gradient(135deg,#f0f4f8,#dbe7f0); min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; padding: 20px; }
.card { background: #fff; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); max-width: 480px; width: 100%; padding: 30px; text-align: center; }
.card img.logo { height: 60px; margin-bottom: 10px; }
.card h2 { color: #003366; margin: 5px 0 20px 0; font-size: 18px; }
.status-icon { font-size: 55px; margin-bottom: 10px; }
.status-valid { color: #198754; }
.status-invalid { color: #dc3545; }
.status-revoked { color: #dc3545; }
.status-title { font-size: 20px; font-weight: 700; margin-bottom: 20px; }
.detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; font-size: 14px; text-align: left; }
.detail-row span:first-child { color: #6c7a8a; }
.detail-row span:last-child { font-weight: 600; color: #1a3b55; }
.footer-note { margin-top: 20px; font-size: 11px; color: #999; }
</style>
</head>
<body>
<div class="card">
    <?php if(!empty($school['logo'])): ?>
        <img src="uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo">
    <?php endif; ?>
    <h2><?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></h2>

    <?php if(!$cert): ?>
        <div class="status-icon status-invalid"><i class="fas fa-times-circle"></i></div>
        <div class="status-title" style="color:#dc3545;">Invalid Certificate</div>
        <p style="color:#555; font-size:14px;">এই লিঙ্কটির সাথে কোনো বৈধ certificate পাওয়া যায়নি। দয়া করে QR code / link টা আবার চেক করুন।</p>

    <?php elseif($cert['is_revoked']): ?>
        <div class="status-icon status-revoked"><i class="fas fa-ban"></i></div>
        <div class="status-title" style="color:#dc3545;">This Certificate Has Been Revoked</div>
        <div class="detail-row"><span>Certificate No</span><span><?php echo htmlspecialchars($cert['certificate_no']); ?></span></div>
        <div class="detail-row"><span>Student Name</span><span><?php echo htmlspecialchars($cert['student_name']); ?></span></div>
        <p style="color:#a4161a; font-size:13px; margin-top:15px;">এই certificate টি স্কুল কর্তৃপক্ষ বাতিল করেছে।</p>

    <?php else: ?>
        <div class="status-icon status-valid"><i class="fas fa-check-circle"></i></div>
        <div class="status-title" style="color:#198754;">Valid Certificate</div>
        <div class="detail-row"><span>Certificate Type</span><span><?php echo htmlspecialchars($cert['certificate_type']); ?></span></div>
        <div class="detail-row"><span>Certificate No</span><span><?php echo htmlspecialchars($cert['certificate_no']); ?></span></div>
        <div class="detail-row"><span>Student Name</span><span><?php echo htmlspecialchars($cert['student_name']); ?></span></div>
        <div class="detail-row"><span>Father's Name</span><span><?php echo htmlspecialchars($cert['father_name'] ?? '-'); ?></span></div>
        <div class="detail-row"><span>Banglarshiksha ID</span><span><?php echo htmlspecialchars($cert['banglarshiksha_id'] ?? '-'); ?></span></div>
        <div class="detail-row"><span>PEN ID</span><span><?php echo htmlspecialchars($cert['pen_id'] ?? '-'); ?></span></div>
        <?php if(!empty($cert['class_name'])): ?>
        <div class="detail-row"><span>Class</span><span><?php echo htmlspecialchars($cert['class_name']); ?><?php echo !empty($cert['section_name']) ? ' - '.htmlspecialchars($cert['section_name']) : ''; ?></span></div>
        <?php endif; ?>
        <div class="detail-row"><span>Issue Date</span><span><?php echo date('d-m-Y', strtotime($cert['issue_date'])); ?></span></div>
    <?php endif; ?>

    <div class="footer-note">This is an automated verification page. For any dispute, please contact the school office directly.</div>
</div>
</body>
</html>

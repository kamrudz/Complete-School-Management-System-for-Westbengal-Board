<?php
/**
 * check_previous_student.php (PUBLIC, root)
 *
 * The admission form asks this whether the applicant is already a student of this school — a Class X student of ours
 * coming into XI, say — so the form can fill itself in instead of making the family type everything again.
 *
 * ONE STEP, TWO THINGS TOGETHER. The caller sends any one of the student's identifiers and the date of birth:
 *   Input : student_aadhaar, banglarshiksha_id, pen_id, apaar_id and/or school_uid — plus dob (YYYY-MM-DD)
 *   Output: { found: true, ...the student and guardian record... }   both matched
 *           { found: false, message: '...' }                         anything else
 *
 * Nothing is ever said about an identifier on its own: without the right date of birth the answer is the same whether
 * the student exists or not, so nobody can ask "is this Aadhaar number a student here?".
 *
 * An identifier that belongs to more than one student (two rows carrying the same Aadhaar, say) finds nobody, and
 * identifiers that point at different students find nobody either.
 *
 * Tries are counted per address in the database — ten an hour — so clearing the browser does not start them over.
 *
 * Photo and signature come back only as preview pictures: the family still uploads fresh copies.
 *
 * Madhyamik (Class X board) marks for a Class XI application are not filled in yet — the secondary_registration marks
 * module is still being built — so 'madhyamik' is null. admission.php already has a hook waiting for it.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
session_start();
header('Content-Type: application/json');
header('Cache-Control: private, no-store, max-age=0');
include 'includes/db.php';
require_once 'includes/admission_helper.php';

$no = function (string $message = 'No student of this school matches. Please check the Aadhaar number or other ID and the date of birth.') {
    echo json_encode(['found' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit();
};

$ids = [
    'student_aadhaar'   => preg_replace('/\D/', '', (string)($_GET['student_aadhaar'] ?? '')),
    'banglarshiksha_id' => (string)student_normalize_bsid(trim((string)($_GET['banglarshiksha_id'] ?? ''))),
    'pen_id'            => trim((string)($_GET['pen_id'] ?? '')),
    'apaar_id'          => trim((string)($_GET['apaar_id'] ?? '')),
    'id'                => student_uid_clean($_GET['school_uid'] ?? ''),
];
$ids = array_filter($ids, fn($v) => $v !== '');
$dob = trim((string)($_GET['dob'] ?? ''));

if (!$ids) $no('Give any one of these: Aadhaar number, Banglar Shiksha ID, PEN or School UID.');
$d = DateTime::createFromFormat('!Y-m-d', $dob);
if (!$d || $d->format('Y-m-d') !== $dob) $no('Please give the date of birth.');

$key = 'find-student:' . adm_client_ip();
if (adm_limit_reached($key, 10, 60)) $no('Too many tries. Please come back in an hour, or contact the school office.');
adm_limit_hit($key, 10, 60);

/** The one student every identifier given points to; nobody when they disagree, or when one of them is on two students. */
$found = [];
foreach ($ids as $col => $value) {
    foreach (db_get_all('SELECT id FROM students WHERE ' . db_identifier($col) . " = ? AND student_status <> 'Deleted'", 's', $value) as $r) $found[$r['id']] = true;
    if (count($found) > 1) $no();
}
if (count($found) !== 1) $no();

$student = db_get_row('SELECT * FROM students WHERE id = ?', 's', (string)array_key_first($found));
// an identifier shared by two students points at nobody, so one wrongly typed number cannot open someone else's record
foreach ($ids as $col => $value) {
    if ((int)db_get_row('SELECT COUNT(*) n FROM students WHERE ' . db_identifier($col) . " = ? AND student_status <> 'Deleted'", 's', $value)['n'] !== 1) $no();
}
if (empty($student['dob']) || (string)$student['dob'] !== $dob) $no();

adm_limit_clear($key);

$guardian = !empty($student['guardian_id']) ? db_get_row('SELECT * FROM guardians WHERE guardian_id = ?', 'i', (int)$student['guardian_id']) : null;
$acad = db_get_row('SELECT c.class_name, sec.section_name, ss.session_name FROM student_academic_history h
    LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id LEFT JOIN academic_sessions ss ON ss.id = h.session_id
    WHERE h.student_id = ? ORDER BY h.id DESC LIMIT 1', 's', $student['id']);
$last_class = '';
if ($acad) {
    $last_class = trim(($acad['class_name'] ?? '') . ($acad['section_name'] ? '-' . $acad['section_name'] : ''));
    if (!empty($acad['session_name'])) $last_class .= ' (' . $acad['session_name'] . ')';
}
$picture = function (?string $file, string $dir) {
    $name = basename((string)$file);
    return $name !== '' && is_file($dir . $name) ? $dir . rawurlencode($name) : null;
};

$keep = ['student_name', 'name_as_per_aadhaar', 'dob', 'gender', 'blood_group', 'religion', 'caste', 'sub_caste', 'disability', 'disability_type',
    'birth_registration_number', 'student_aadhaar', 'banglarshiksha_id', 'pen_id', 'apaar_id', 'village', 'post_office', 'police_station',
    'district', 'state', 'pin_code', 'bank_name', 'branch_name', 'account_number', 'ifsc_code'];
$out = [];
foreach ($keep as $k) $out[$k] = (string)($student[$k] ?? '');
$out['mobile'] = (string)$student['mobile'];
$out['email'] = (string)$student['email'];

$g_keep = ['father_name', 'father_aadhaar', 'father_voter_id', 'father_mobile', 'father_occupation', 'father_qualification', 'annual_income',
    'mother_name', 'mother_aadhaar', 'mother_voter_id', 'mother_occupation', 'guardian_name', 'guardian_relation', 'guardian_contact', 'guardian_email'];
$g_out = null;
if ($guardian) {
    $g_out = [];
    foreach ($g_keep as $k) $g_out[$k] = (string)($guardian[$k] ?? '');
    $g_out['father_aadhaar_not_available'] = (int)$guardian['father_aadhaar_not_available'];
    $g_out['mother_aadhaar_not_available'] = (int)$guardian['mother_aadhaar_not_available'];
}

echo json_encode([
    'found' => true,
    'student_id' => $student['id'],
    'last_class' => $last_class,
    'student' => $out,
    'guardian' => $g_out,
    'photo_url' => $picture($student['photo'], 'uploads/students/'),
    'signature_url' => $picture($student['signature'], 'uploads/students/signatures/'),
    'madhyamik' => null,
], JSON_UNESCAPED_UNICODE);

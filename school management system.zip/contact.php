<?php
require_once __DIR__ . '/includes/site.php';

/**
 * Writing to the school. The form carries the page's token and a field only robots fill in, and one address
 * may send three messages in five minutes. Messages land in the office's Messages page.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_query'])) {
    $back = function (string $why): void { header('Location: contact.php?sent=' . $why . '#write'); exit(); };
    if (!empty($_POST['website']) || !csrf_check((string)($_POST['csrf_token'] ?? ''))) $back('error');

    $name = trim((string)($_POST['query_name'] ?? ''));
    $email = trim((string)($_POST['query_email'] ?? ''));
    $subject = mb_substr(trim((string)($_POST['query_subject'] ?? '')), 0, 255);
    $message = mb_substr(trim((string)($_POST['query_message'] ?? '')), 0, 5000);
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');

    if ($name === '' || mb_strlen($name) > 150 || $email === '' || mb_strlen($email) > 150
        || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') $back('error');

    $recent = $ip !== '' ? (int)(db_get_row('SELECT COUNT(*) n FROM contact_queries WHERE ip_address = ? AND created_at > (NOW() - INTERVAL 5 MINUTE)', 's', $ip)['n'] ?? 0) : 0;
    if ($recent >= 3) $back('limit');

    db_execute('INSERT INTO contact_queries (name, email, subject, message, ip_address) VALUES (?, ?, ?, ?, ?)', 'sssss', $name, $email, $subject, $message, $ip);
    $back('1');
}

$d = site_data();
$sent = (string)($_GET['sent'] ?? '');

site_page('Contact', 'contact.php');
site_band('Contact the school', 'Write to the office, call, or come and see us.');
?>
<section class="sec">
    <div class="wrap split" style="align-items:start">
        <div class="reveal">
            <span class="kick">Reach us</span>
            <h2>The school office</h2>
            <div class="contact-cards">
                <?php if ($d['address'] !== ''): ?><div class="ccard"><i class="fas fa-location-dot"></i><div><b>Address</b><span><?php echo h($d['address']); ?></span></div></div><?php endif; ?>
                <?php if ($d['phone'] !== ''): ?><div class="ccard"><i class="fas fa-phone"></i><div><b>Phone</b><a href="tel:<?php echo h(preg_replace('/[^0-9+]/', '', $d['phone'])); ?>"><?php echo h($d['phone']); ?></a></div></div><?php endif; ?>
                <?php if ($d['email'] !== ''): ?><div class="ccard"><i class="fas fa-envelope"></i><div><b>Email</b><a href="mailto:<?php echo h($d['email']); ?>"><?php echo h($d['email']); ?></a></div></div><?php endif; ?>
                <?php if ($d['udise'] !== ''): ?><div class="ccard"><i class="fas fa-hashtag"></i><div><b>UDISE code</b><span><?php echo h($d['udise']); ?></span></div></div><?php endif; ?>
            </div>
            <?php if ($d['map'] !== ''): ?><p style="margin-top:16px"><a class="btn btn-line" href="<?php echo h($d['map']); ?>" target="_blank" rel="noopener"><i class="fas fa-map-location-dot"></i> Open the map</a></p><?php endif; ?>
        </div>
        <div class="panel reveal" id="write" style="padding:26px">
            <h3 style="font-size:22px;margin-bottom:6px">Write to us</h3>
            <p style="color:var(--muted);margin-bottom:18px">The office reads every message and answers by email.</p>
            <?php if ($sent === '1'): ?><div class="note-ok" style="margin-bottom:14px"><i class="fas fa-circle-check"></i> Thank you — your message has been sent successfully.</div>
            <?php elseif ($sent === 'error'): ?><div class="note-bad" style="margin-bottom:14px">Please give your name, a working email and your message.</div>
            <?php elseif ($sent === 'limit'): ?><div class="note-bad" style="margin-bottom:14px">Too many messages sent recently. Please try again in a few minutes.</div><?php endif; ?>
            <form class="form" method="post" action="contact.php#write">
                <?php echo csrf_field(); ?>
                <input type="text" name="website" value="" class="trap" tabindex="-1" autocomplete="off" aria-hidden="true">
                <div class="two">
                    <div><label for="q_name">Your name</label><input id="q_name" type="text" name="query_name" maxlength="150" required autocomplete="name"></div>
                    <div><label for="q_email">Your email</label><input id="q_email" type="email" name="query_email" maxlength="150" required autocomplete="email"></div>
                </div>
                <div><label for="q_subject">About</label><input id="q_subject" type="text" name="query_subject" maxlength="255" placeholder="e.g. Admission to Class XI"></div>
                <div><label for="q_message">Your message</label><textarea id="q_message" name="query_message" maxlength="5000" required></textarea></div>
                <button type="submit" name="send_query" class="btn btn-brand" style="justify-self:start"><i class="fas fa-paper-plane"></i> Send the message</button>
            </form>
        </div>
    </div>
</section>
<?php site_footer();

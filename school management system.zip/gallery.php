<?php
require_once __DIR__ . '/includes/site.php';

$per = 24;
$page = max(1, (int)($_GET['page'] ?? 1));
[$photos, $total] = site_gallery($per, ($page - 1) * $per);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) { $page = $pages; [$photos] = site_gallery($per, ($page - 1) * $per); }

site_page('Gallery', 'gallery.php');
site_band('Gallery', $total ? $total . ' photographs of school life — click one to see it large.' : 'Photographs of school life.');
?>
<section class="sec">
    <div class="wrap">
        <?php if (!$photos): ?>
            <div class="panel"><div class="empty"><i class="fas fa-images"></i>No photograph has been put up yet.</div></div>
        <?php else: ?>
        <div class="gal big">
            <?php foreach ($photos as $p): ?>
            <a href="<?php echo h('uploads/gallery/' . $p['photo']); ?>" data-light data-title="<?php echo h($p['title'] ?? ''); ?>">
                <img src="<?php echo h('uploads/gallery/' . $p['photo']); ?>" alt="<?php echo h($p['title'] ?? ''); ?>" loading="lazy">
                <span><?php echo h($p['title'] ?? ''); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php echo site_pager($page, $pages, fn($p) => 'gallery.php?page=' . $p); ?>
        <?php endif; ?>
    </div>
</section>
<?php site_footer();

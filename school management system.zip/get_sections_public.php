<?php
/** Public: section names of a class in a session (for the result checker). JSON [{id, name}]. No student data. */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("includes/db.php");
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$session_id = (int)($_GET['session_id'] ?? 0); $class_id = (int)($_GET['class_id'] ?? 0);
$out = [];
if ($session_id > 0 && $class_id > 0) foreach (db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id) as $r) $out[] = ['id' => (int)$r['id'], 'name' => $r['section_name']];
echo json_encode($out);

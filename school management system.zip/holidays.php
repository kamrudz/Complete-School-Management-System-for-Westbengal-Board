<?php
require_once __DIR__ . '/includes/site.php';

/** The holiday list, one calendar year at a time — the same list attendance is kept by. */
$years = holiday_years();
$year = (int)($_GET['year'] ?? date('Y'));
if (!isset($years[$year])) $year = (int)date('Y');
$rows = holidays_of_year($year);
$today = date('Y-m-d');
$lost = 0;
foreach ($rows as $r) $lost += holiday_working_days($r);

site_page('Holidays ' . $year, '');
site_band('Holiday list ' . $year, count($rows) ? count($rows) . ' holidays — the school is closed on these days.' : 'The days the school is closed.');
?>
<section class="sec">
    <div class="wrap" style="max-width:960px">
        <?php if (count($years) > 1): ?>
        <div class="chips" style="margin-bottom:22px">
            <?php foreach ($years as $y): ?><a href="<?php echo h('holidays.php?year=' . $y); ?>" class="<?php echo $y === $year ? 'on' : ''; ?>"><?php echo (int)$y; ?></a><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if (!$rows): ?>
            <div class="panel"><div class="empty"><i class="fas fa-calendar-days"></i>The holiday list for <?php echo $year; ?> has not been put up yet.</div></div>
        <?php else: ?>
        <div style="overflow-x:auto">
        <table class="table">
            <thead><tr><th>Holiday</th><th>Date</th><th>Day</th><th>Days</th></tr></thead>
            <tbody>
            <?php foreach ($rows as $r): [$from, $to] = holiday_span($r); [$kind] = HOLIDAY_TYPES[$r['holiday_type']] ?? ['Holiday']; ?>
                <tr class="<?php echo $to && $to < $today ? 'past' : ''; ?>">
                    <td><b><?php echo h($r['holiday_name']); ?></b><br><span class="pill <?php echo $r['holiday_type'] === 'public' ? 'green' : 'gold'; ?>" style="margin-top:4px"><?php echo h($kind); ?></span></td>
                    <td><?php echo $from ? h(date('d M Y', strtotime($from)) . ($to !== $from ? ' – ' . date('d M Y', strtotime($to)) : '')) : '—'; ?></td>
                    <td><?php echo $from ? h(date('l', strtotime($from))) : '—'; ?></td>
                    <td><?php echo holiday_working_days($r); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <p style="color:var(--muted);font-size:14px;margin-top:14px"><?php echo $lost; ?> working days in all. Sundays inside a holiday are not counted, and holidays already over are shown faint.</p>
        <?php endif; ?>
    </div>
</section>
<?php site_footer();

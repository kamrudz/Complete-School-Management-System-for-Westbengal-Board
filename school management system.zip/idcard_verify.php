<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
// ===== NO LOGIN CHECK - public page, only accessible via unguessable token =====
include("includes/db.php");
require_once __DIR__ . '/includes/card_document_helper.php';

$token = $_GET['token'] ?? '';
$valid_format = preg_match('/^[a-f0-9]{64}$/', $token);

$card = null;
if($valid_format) {
    $stmt = mysqli_prepare($conn, "
        SELECT ic.*, s.student_name, s.admission_no, s.photo, s.blood_group,
               cl.class_name, sec.section_name, ss.session_name,
               h.academic_status
        FROM student_id_cards ic
        LEFT JOIN students s ON s.id = ic.student_id
        LEFT JOIN student_academic_history h ON h.student_id = ic.student_id AND h.session_id = ic.session_id
        LEFT JOIN classes cl ON cl.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN academic_sessions ss ON ss.id = ic.session_id
        WHERE ic.verification_token = ?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $card = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

$school = document_get_school_settings($conn, 'verify_phone');

// A student is considered "Active" only if not revoked and their academic
// record for that session is still Current (not TC'd / passed out / dropped)
$is_actually_active = $card && !empty($card['is_active']) && ($card['academic_status'] ?? '') === 'Current';
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ID Card Verification</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: linear-gradient(135deg,#f0f4f8,#dbe7f0); min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; padding: 20px; }
.card { background: #fff; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); max-width: 420px; width: 100%; padding: 30px; text-align: center; }
.card img.logo { height: 55px; margin-bottom: 8px; }
.card img.stu-photo { width: 90px; height: 90px; object-fit: cover; border-radius: 10px; border: 3px solid #003366; margin: 10px auto; display: block; }
.card h2 { color: #003366; margin: 5px 0 15px 0; font-size: 17px; }
.status-icon { font-size: 50px; margin-bottom: 8px; }
.status-valid { color: #198754; }
.status-invalid { color: #dc3545; }
.status-title { font-size: 19px; font-weight: 700; margin-bottom: 18px; }
.detail-row { display: flex; justify-content: space-between; padding: 9px 0; border-bottom: 1px solid #eee; font-size: 14px; text-align: left; }
.detail-row span:first-child { color: #6c7a8a; }
.detail-row span:last-child { font-weight: 600; color: #1a3b55; }
.footer-note { margin-top: 18px; font-size: 11px; color: #999; }
.contact-box { margin-top: 15px; background: #f5f8fb; border-radius: 8px; padding: 12px; font-size: 13px; color: #1a3b55; }
</style>
</head>
<body>
<div class="card">
    <?php if(!empty($school['logo'])): ?><img src="uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo"><?php endif; ?>
    <h2><?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></h2>

    <?php if(!$card): ?>
        <div class="status-icon status-invalid"><i class="fas fa-times-circle"></i></div>
        <div class="status-title" style="color:#dc3545;">Invalid ID Card</div>
        <p style="color:#555; font-size:14px;">এই লিঙ্কের সাথে কোনো বৈধ ID Card পাওয়া যায়নি।</p>

    <?php elseif(!$is_actually_active): ?>
        <div class="status-icon status-invalid"><i class="fas fa-ban"></i></div>
        <div class="status-title" style="color:#dc3545;">This ID Card Is Not Active</div>
        <div class="detail-row"><span>Student Name</span><span><?php echo htmlspecialchars($card['student_name']); ?></span></div>
        <p style="color:#a4161a; font-size:13px; margin-top:12px;">এই student বর্তমানে এই স্কুলে সক্রিয় নেই (TC / Pass Out / বাতিল হয়েছে)।</p>

    <?php else: ?>
        <?php if(!empty($card['photo'])): ?>
            <img src="uploads/students/<?php echo htmlspecialchars($card['photo']); ?>" class="stu-photo">
        <?php endif; ?>
        <div class="status-icon status-valid"><i class="fas fa-check-circle"></i></div>
        <div class="status-title" style="color:#198754;">Active Student</div>
        <div class="detail-row"><span>Student Name</span><span><?php echo htmlspecialchars($card['student_name']); ?></span></div>
        <div class="detail-row"><span>Class</span><span><?php echo htmlspecialchars($card['class_name'] ?? '-'); ?><?php echo !empty($card['section_name']) ? ' - '.htmlspecialchars($card['section_name']) : ''; ?></span></div>
        <div class="detail-row"><span>Admission No</span><span><?php echo htmlspecialchars($card['admission_no'] ?? '-'); ?></span></div>
        <div class="detail-row"><span>Blood Group</span><span><?php echo htmlspecialchars($card['blood_group'] ?? '-'); ?></span></div>
        <div class="detail-row"><span>Session</span><span><?php echo htmlspecialchars($card['session_name'] ?? '-'); ?></span></div>

        <div class="contact-box">
            <i class="fas fa-phone"></i> এই কার্ড কুড়িয়ে পেয়েছেন? স্কুলে যোগাযোগ করুন:
            <b><?php echo htmlspecialchars($school['phone'] ?? '-'); ?></b>
        </div>
    <?php endif; ?>

    <div class="footer-note">This is an automated verification page. For any dispute, please contact the school office directly.</div>
</div>
</body>
</html>

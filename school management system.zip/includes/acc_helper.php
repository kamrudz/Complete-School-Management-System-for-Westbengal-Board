<?php
/**
 * Accounts: the school's accounts (each holds cash in hand and money in the bank), income and expense heads, and every
 * movement of money (acc_entries) — fee receipts posted by head, other income, expenses, deposits, withdrawals and
 * transfers. Money is counted in paise. An entry is cancelled with a reason, never deleted. Reports run over any dates:
 * an academic session or a financial year (April–March).
 */
require_once __DIR__ . '/fee_helper.php';

const ACC_TYPES = [
    'school_fund' => ['School Fund', 'fa-school', 'Students\' fees — admission, development, identity card'],
    'fine'        => ['Fine', 'fa-gavel', 'Fines; duplicate certificates, marksheets and pay slips'],
    'board_fees'  => ['Board Fees', 'fa-landmark', 'Registration and form fill-up money, sent on to the Board'],
    'mdm'         => ['Mid-Day Meal', 'fa-utensils', 'Cooking cost from the government; bazar, fuel, cooks'],
    'grant'       => ['Grant', 'fa-hand-holding-usd', 'Composite school grant and other grants'],
    'festival'    => ['Festival', 'fa-star', 'Puja and Jalsa money and what they cost'],
    'other'       => ['Other', 'fa-wallet', 'Donations, bank interest and anything else'],
];
const ACC_KINDS = ['fee' => 'Fee', 'income' => 'Income', 'expense' => 'Expense', 'deposit' => 'Deposit', 'withdraw' => 'Withdrawal', 'transfer' => 'Transfer'];
const ACC_MODES = ['cash' => 'Cash', 'bank' => 'Bank'];
const ACC_PAGES = [
    'acc_entry.php'    => ['New Entry', 'fa-pen'],
    'acc_vouchers.php' => ['Vouchers', 'fa-file-invoice-dollar'],
    'acc_cashbook.php' => ['Cash Book', 'fa-book'],
    'acc_report.php'   => ['Reports', 'fa-chart-line'],
    'acc_settings.php' => ['Account Settings', 'fa-sliders-h'],
];

function acc_tabs(string $active): void { exam_tabs($active, ACC_PAGES); }

function acc_log(int $admin_id, string $action, string $table, $id, $old = null, $new = null): void {
    if (function_exists('log_action')) log_action($admin_id, $action, $table, $id, $old, $new);
}

/** Rupees typed in a form → paise, or null when it is not an amount (up to ₹99,99,99,999.99). */
function acc_amount_in($v): ?int {
    $v = trim(str_replace(',', '', (string)$v));
    return preg_match('/^\d{1,9}(\.\d{1,2})?$/', $v) ? fee_paise($v) : null;
}

/** Where an account's money is kept, for a list: "SBI, Malda · A/c ••••1234". */
function acc_bank_line(array $a): string {
    $no = preg_replace('/\s+/', '', (string)$a['account_no']);
    return implode(' · ', array_filter([trim(implode(', ', array_filter([(string)$a['bank_name'], (string)$a['branch']]))), $no !== '' ? 'A/c ••••' . substr($no, -4) : '']));
}

function acc_settings(bool $fresh = false): array {
    static $s = null;
    if ($s === null || $fresh) $s = db_get_row('SELECT * FROM acc_settings WHERE id = 1') ?: ['fee_account_id' => null, 'lock_date' => null, 'signatures' => 'Prepared by|Headmaster / TIC|Secretary / President'];
    return $s;
}

/** Accounts in order: id => row. */
function acc_accounts(bool $active_only = false): array {
    $out = [];
    foreach (db_get_all('SELECT * FROM acc_accounts' . ($active_only ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order, name') as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/** Heads in order: id => row; $kind 'income' or 'expense'; $for_type narrows to the heads an account of that type may use. */
function acc_heads(string $kind = '', ?string $for_type = null, bool $active_only = false): array {
    $where = []; $types = ''; $params = [];
    if ($kind !== '') { $where[] = 'kind = ?'; $types .= 's'; $params[] = $kind; }
    if ($for_type !== null) { $where[] = '(for_type IS NULL OR for_type = ?)'; $types .= 's'; $params[] = $for_type; }
    if ($active_only) $where[] = 'is_active = 1';
    $out = [];
    foreach (db_get_all('SELECT * FROM acc_heads' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY kind, sort_order, name', $types, ...$params) as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/** The financial year (April–March) of a date: '2026-27'. */
function acc_fy(string $date): string {
    $y = (int)substr($date, 0, 4);
    if ((int)substr($date, 5, 2) < 4) $y--;
    return $y . '-' . substr((string)($y + 1), -2);
}
/** First and last day of a financial year '2026-27'. */
function acc_fy_range(string $fy): array {
    $y = (int)substr($fy, 0, 4);
    return ["$y-04-01", ($y + 1) . '-03-31'];
}
/** First and last day of an academic session, by its months (2026: January–December; 2025-26: April–March). */
function acc_session_range(int $session_id): array {
    $months = array_keys(fee_session_months($session_id));
    if (!$months) return [];
    return [$months[0] . '-01', date('Y-m-t', strtotime(end($months) . '-01'))];
}

/**
 * Ready-made periods for the report pickers: key => [label, from, to]. Financial years from the first account's
 * opening date to the current one, then the academic sessions.
 */
function acc_periods(): array {
    $out = [];
    $first = (string)(db_get_row('SELECT MIN(opening_date) AS d FROM acc_accounts')['d'] ?? '') ?: date('Y-m-d');
    $fy = acc_fy(date('Y-m-d'));
    for ($y = (int)substr($fy, 0, 4); $y >= (int)substr(acc_fy($first), 0, 4); $y--) {
        $f = $y . '-' . substr((string)($y + 1), -2);
        [$a, $b] = acc_fy_range($f);
        $out["fy:$f"] = ["FY $f (April–March)", $a, $b];
    }
    foreach (exam_sessions() as $sid => $name) {
        $r = acc_session_range((int)$sid);
        if ($r) $out["s:$sid"] = ["Session $name", $r[0], $r[1]];
    }
    return $out;
}

/** Is this date on or before the lock date (books closed)? */
function acc_locked(string $date): bool {
    $lock = (string)(acc_settings()['lock_date'] ?? '');
    return $lock !== '' && $date <= $lock;
}

/**
 * Cash and bank balance of every account at the end of $upto (or now): id => ['cash' => paise, 'bank' => paise].
 * $before = true gives the balance at the start of that day instead. An account's opening balance is what it held
 * when its opening date began. Cancelled entries do not count.
 */
function acc_balances(?string $upto = null, bool $before = false): array {
    $out = [];
    foreach (acc_accounts() as $id => $a) {
        $open = $upto === null || $a['opening_date'] <= $upto;
        $out[$id] = ['cash' => $open ? fee_paise($a['opening_cash']) : 0, 'bank' => $open ? fee_paise($a['opening_bank']) : 0];
    }
    $sql = "SELECT account_id, mode, SUM(IF(direction = 'in', amount, -amount)) AS net FROM acc_entries WHERE status = 'valid'";
    $types = ''; $params = [];
    if ($upto !== null) { $sql .= $before ? ' AND entry_date < ?' : ' AND entry_date <= ?'; $types = 's'; $params[] = $upto; }
    foreach (db_get_all($sql . ' GROUP BY account_id, mode', $types, ...$params) as $r) {
        if (isset($out[(int)$r['account_id']])) $out[(int)$r['account_id']][$r['mode']] += fee_paise($r['net']);
    }
    return $out;
}
function acc_balance(int $account_id, ?string $upto = null, bool $before = false): array {
    return acc_balances($upto, $before)[$account_id] ?? ['cash' => 0, 'bank' => 0];
}

/** The next voucher number of a series in a financial year, under a lock (inside the caller's transaction): [seq, 'PV/2026-27/0001']. */
function acc_next_voucher(string $series, string $fy): array {
    $seq = (int)db_get_row('SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM acc_entries WHERE series = ? AND fy = ? FOR UPDATE', 'ss', $series, $fy)['n'];
    return [$seq, sprintf('%s/%s/%04d', $series, $fy, $seq)];
}

/** The account a fee head's money goes to: its own, else the default fee account; 0 when neither is set. */
function acc_fee_account(array $fee_head): int {
    return (int)$fee_head['account_id'] ?: (int)(acc_settings()['fee_account_id'] ?? 0);
}

/**
 * Share a payment on a bill out over the bill's heads in proportion to what each head has still to receive, so a
 * payment never gives a head more than it is owed and the last one fills every head exactly.
 * $items = fee head => net paise of the bill; $got = fee head => paise received already. Returns fee head => paise.
 */
function acc_fee_shares(array $items, array $got, int $amount): array {
    $rem = [];
    foreach ($items as $fid => $net) $rem[$fid] = max(0, $net - ($got[$fid] ?? 0));
    $total = array_sum($rem);
    if ($total <= 0 || $amount <= 0) return [];
    $amount = min($amount, $total);
    $share = []; $frac = [];
    foreach ($rem as $fid => $r) { $share[$fid] = intdiv($amount * $r, $total); $frac[$fid] = ($amount * $r) % $total; }
    $left = $amount - array_sum($share);
    arsort($frac);
    foreach (array_keys($frac) as $fid) {
        if ($left <= 0) break;
        if ($share[$fid] < $rem[$fid]) { $share[$fid]++; $left--; }
    }
    return array_filter($share, fn($p) => $p > 0);
}

/**
 * Put a fee receipt in the accounts (inside the caller's transaction): every line is shared out over its bill's heads
 * and each share goes to the head's account, as cash or bank by how the receipt was paid. Nothing is posted while some
 * head has no account and there is no default — the receipt waits to be posted later — nor for a receipt older than its
 * account's opening date, whose money is in the opening balance. Returns the entries made.
 */
function acc_post_fee_receipt(int $receipt_id): int {
    $r = db_get_row('SELECT r.*, s.student_name FROM fee_receipts r JOIN students s ON s.id = r.student_id WHERE r.id = ?', 'i', $receipt_id);
    if (!$r || $r['status'] !== 'valid' || db_get_row('SELECT 1 FROM acc_entries WHERE fee_receipt_id = ? LIMIT 1', 'i', $receipt_id)) return 0;
    $heads = fee_heads();
    $rows = [];
    foreach (db_get_all('SELECT invoice_id, amount FROM fee_transactions WHERE receipt_id = ? ORDER BY id', 'i', $receipt_id) as $l) {
        $bill = (int)$l['invoice_id'];
        $items = $got = [];
        foreach (db_get_all('SELECT fee_type_id, net FROM fee_invoice_items WHERE invoice_id = ? ORDER BY id', 'i', $bill) as $it) $items[(int)$it['fee_type_id']] = ($items[(int)$it['fee_type_id']] ?? 0) + fee_paise($it['net']);
        foreach (db_get_all("SELECT fee_type_id, SUM(amount) AS a FROM acc_entries WHERE fee_invoice_id = ? AND kind = 'fee' AND status = 'valid' GROUP BY fee_type_id", 'i', $bill) as $g) $got[(int)$g['fee_type_id']] = fee_paise($g['a']);
        foreach (acc_fee_shares($items, $got, fee_paise($l['amount'])) as $fid => $p) {
            $acc = isset($heads[$fid]) ? acc_fee_account($heads[$fid]) : (int)(acc_settings()['fee_account_id'] ?? 0);
            if (!$acc) return 0;
            $rows[] = [$acc, $bill, $fid, $p];
        }
    }
    if (!$rows) return 0;
    $accounts = acc_accounts();
    foreach ($rows as [$acc]) if (!isset($accounts[$acc]) || $r['receipt_date'] < $accounts[$acc]['opening_date']) return 0;
    if (acc_locked($r['receipt_date'])) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . ' — give a payment date after that.');
    foreach ($rows as [$acc, $bill, $fid, $p]) {
        db_insert('acc_entries', ['account_id' => $acc, 'entry_date' => $r['receipt_date'], 'kind' => 'fee', 'direction' => 'in', 'mode' => $r['method'] === 'cash' ? 'cash' : 'bank',
            'amount' => fee_rupees($p), 'fee_type_id' => $fid, 'fee_receipt_id' => $receipt_id, 'fee_invoice_id' => $bill, 'fy' => acc_fy($r['receipt_date']),
            'party' => mb_substr((string)$r['student_name'], 0, 150), 'reference' => $r['receipt_no'], 'description' => mb_substr((string)($heads[$fid]['type_name'] ?? 'Fee'), 0, 255),
            'created_by' => $r['received_by']]);
    }
    return count($rows);
}

/** Take a cancelled fee receipt out of the accounts (inside the caller's transaction). */
function acc_unpost_fee_receipt(int $receipt_id, string $reason, int $admin_id): void {
    $first = db_get_row("SELECT MIN(entry_date) AS d FROM acc_entries WHERE fee_receipt_id = ? AND status = 'valid'", 'i', $receipt_id)['d'] ?? null;
    if ($first && acc_locked($first)) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . ' — this receipt is in them and cannot be cancelled now.');
    db_execute("UPDATE acc_entries SET status = 'cancelled', cancelled_at = NOW(), cancelled_by = ?, cancel_reason = ? WHERE fee_receipt_id = ? AND status = 'valid'", 'isi', $admin_id ?: null, $reason, $receipt_id);
}

/** Valid fee receipts not in the accounts yet, from the day the accounts begin, in the order they were taken: id => row. */
function acc_fee_receipts_pending(): array {
    $out = [];
    foreach (db_get_all("SELECT r.id, r.receipt_no, r.receipt_date, r.amount FROM fee_receipts r
        WHERE r.status = 'valid' AND r.receipt_date >= (SELECT MIN(opening_date) FROM acc_accounts) AND NOT EXISTS (SELECT 1 FROM acc_entries e WHERE e.fee_receipt_id = r.id)
        ORDER BY r.receipt_date, r.session_id, r.seq") as $r) $out[(int)$r['id']] = $r;
    return $out;
}
/** Fee receipts from before the accounts begin — their money is in the opening balances: ['n', 'amount', 'from' => the first opening date]. */
function acc_fee_receipts_before_books(): array {
    $first = (string)(db_get_row('SELECT MIN(opening_date) AS d FROM acc_accounts')['d'] ?? '');
    if ($first === '') return ['n' => 0, 'amount' => 0, 'from' => ''];
    $r = db_get_row("SELECT COUNT(*) AS n, COALESCE(SUM(amount), 0) AS a FROM fee_receipts r WHERE r.status = 'valid' AND r.receipt_date < ? AND NOT EXISTS (SELECT 1 FROM acc_entries e WHERE e.fee_receipt_id = r.id)", 's', $first);
    return ['n' => (int)$r['n'], 'amount' => fee_paise($r['a']), 'from' => $first];
}

/** Put the fee receipts that are not in the accounts yet into them, oldest first: [posted, left out]. */
function acc_post_pending_fee_receipts(int $admin_id): array {
    $pending = acc_fee_receipts_pending();
    $posted = 0;
    db_begin_transaction();
    try {
        foreach ($pending as $id => $r) if (!acc_locked($r['receipt_date']) && acc_post_fee_receipt($id)) $posted++;
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        throw new RuntimeException('The fee receipts could not be put in the accounts: ' . $e->getMessage());
    }
    if ($posted) acc_log($admin_id, 'ACC_FEE_RECEIPTS_POSTED', 'acc_entries', null, null, "$posted fee receipt(s) put in the accounts");
    return [$posted, count($pending) - $posted];
}

const ACC_WAYS = ['cash' => 'Cash', 'cheque' => 'Cheque', 'transfer' => 'Bank transfer', 'upi' => 'UPI'];
const ACC_SERIES = ['expense' => 'PV', 'income' => 'RV', 'deposit' => 'CV', 'withdraw' => 'CV', 'transfer' => 'CV'];

/** Folder for scanned bills: Apache never serves it (.htaccess); admin/acc_bill.php shows a file to a logged-in admin. */
function acc_bills_dir(): string {
    $dir = dirname(__DIR__) . '/uploads/accounts/';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_file($dir . '.htaccess')) @file_put_contents($dir . '.htaccess', "# Bills: never served directly — see admin/acc_bill.php\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
    if (!is_file($dir . 'index.html')) @file_put_contents($dir . 'index.html', '');
    return $dir;
}
/** Keep an uploaded bill (photo or PDF, up to 3 MB): ['ok', 'filename', 'error']. */
function acc_bill_store(array $file): array {
    require_once __DIR__ . '/security.php';
    return safe_uploaded_file($file, acc_bills_dir(), ['jpg', 'jpeg', 'png', 'webp', 'pdf'], ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'], 'bill_', 3 * 1024 * 1024);
}

/** The lowest cash or bank balance an account has at the end of any day from $from on — what an outgoing entry on $from may take at most. */
function acc_low_point(int $account_id, string $mode, string $from): int {
    $bal = acc_balance($account_id, $from)[$mode];
    $low = $bal;
    foreach (db_get_all("SELECT entry_date, SUM(IF(direction = 'in', amount, -amount)) AS net FROM acc_entries
        WHERE account_id = ? AND mode = ? AND status = 'valid' AND entry_date > ? GROUP BY entry_date ORDER BY entry_date", 'iss', $account_id, $mode, $from) as $d) {
        $bal += fee_paise($d['net']);
        $low = min($low, $bal);
    }
    return $low;
}

/**
 * Save an income, expense, deposit, withdrawal or transfer in one transaction with its own voucher number.
 * $e: kind, account_id, to_account_id (transfer), date, amount (paise), head_id (income/expense), way (cash/cheque/
 * transfer/upi, for income/expense), from_mode and to_mode (transfer), reference, party, bill_no, bill_date,
 * description, attachment. A deposit moves cash to the bank and a withdrawal the bank to cash, in one account.
 * Nothing may leave an account that it does not hold, on that day or any day after. Returns [entry id, voucher number].
 */
function acc_entry_create(array $e, int $admin_id): array {
    $kind = (string)($e['kind'] ?? '');
    if (!isset(ACC_SERIES[$kind])) throw new RuntimeException('Choose what kind of entry this is.');
    $accounts = acc_accounts();
    $a = $accounts[(int)($e['account_id'] ?? 0)] ?? null;
    if (!$a || !$a['is_active']) throw new RuntimeException('Choose an account that is on.');
    $to = null;
    if ($kind === 'transfer') {
        $to = $accounts[(int)($e['to_account_id'] ?? 0)] ?? null;
        if (!$to || !$to['is_active']) throw new RuntimeException('Choose the account the money goes to.');
        if ((int)$to['id'] === (int)$a['id']) throw new RuntimeException('Choose two different accounts — to move money between cash and bank in one account, use Deposit / Withdraw.');
    }
    $date = (string)($e['date'] ?? '');
    if (!fee_valid_date($date) || $date > date('Y-m-d')) throw new RuntimeException('Give a date that is not in the future.');
    foreach (array_filter([$a, $to]) as $x) if ($date < $x['opening_date']) throw new RuntimeException("{$x['name']} starts on " . date('d M Y', strtotime($x['opening_date'])) . ' — give that date or a later one.');
    if (acc_locked($date)) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . ' — give a later date.');
    $amount = (int)($e['amount'] ?? 0);
    if ($amount <= 0 || $amount > 99999999999) throw new RuntimeException('Give the amount.');
    $party = mb_substr(trim((string)($e['party'] ?? '')), 0, 150);
    $reference = mb_substr(trim((string)($e['reference'] ?? '')), 0, 100);
    $description = mb_substr(trim((string)($e['description'] ?? '')), 0, 255);
    $head = null;
    $legs = [];
    if ($kind === 'income' || $kind === 'expense') {
        $head = acc_heads($kind)[(int)($e['head_id'] ?? 0)] ?? null;
        if (!$head || !$head['is_active'] || ($head['for_type'] !== null && $head['for_type'] !== $a['type'])) throw new RuntimeException('Choose ' . ($kind === 'income' ? 'an income' : 'an expense') . ' head for ' . $a['name'] . '.');
        $way = (string)($e['way'] ?? '');
        if (!isset(ACC_WAYS[$way])) throw new RuntimeException('Choose how the money was ' . ($kind === 'income' ? 'received.' : 'paid.'));
        if ($way !== 'cash' && $reference === '') throw new RuntimeException('Give the ' . ACC_WAYS[$way] . ' number.');
        if ($party === '') throw new RuntimeException($kind === 'income' ? 'Say who the money came from.' : 'Say who was paid.');
        if ($way !== 'cash') $reference = mb_substr(ACC_WAYS[$way] . ' ' . $reference, 0, 100);
        $legs[] = [(int)$a['id'], $kind === 'income' ? 'in' : 'out', $way === 'cash' ? 'cash' : 'bank'];
    } elseif ($kind === 'deposit' || $kind === 'withdraw') {
        $legs[] = [(int)$a['id'], 'out', $kind === 'deposit' ? 'cash' : 'bank'];
        $legs[] = [(int)$a['id'], 'in', $kind === 'deposit' ? 'bank' : 'cash'];
    } else {
        $from_mode = (string)($e['from_mode'] ?? ''); $to_mode = (string)($e['to_mode'] ?? '');
        if (!isset(ACC_MODES[$from_mode]) || !isset(ACC_MODES[$to_mode])) throw new RuntimeException('Say whether the money leaves and arrives as cash or through the bank.');
        $legs[] = [(int)$a['id'], 'out', $from_mode];
        $legs[] = [(int)$to['id'], 'in', $to_mode];
    }
    $bill_date = trim((string)($e['bill_date'] ?? ''));
    if ($bill_date !== '' && (!fee_valid_date($bill_date) || $bill_date > date('Y-m-d'))) throw new RuntimeException('The bill date is not a date before tomorrow.');
    $fy = acc_fy($date);
    db_begin_transaction();
    try {
        $ids = array_values(array_unique(array_column($legs, 0)));
        sort($ids);
        db_get_all('SELECT id FROM acc_accounts WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id FOR UPDATE', str_repeat('i', count($ids)), ...$ids);
        foreach ($legs as [$acc, $dir, $mode]) {
            if ($dir !== 'out') continue;
            $low = acc_low_point($acc, $mode, $date);
            if ($low < $amount) throw new RuntimeException($accounts[$acc]['name'] . ' has only ' . fee_money_p(max(0, $low)) . ' in ' . ($mode === 'cash' ? 'cash' : 'the bank') . ' on ' . date('d M Y', strtotime($date)) . ($low < acc_balance($acc, $date)[$mode] ? ' or a day after' : '') . ' — that is the most this entry can take.');
        }
        [$seq, $no] = acc_next_voucher(ACC_SERIES[$kind], $fy);
        $made = [];
        foreach ($legs as [$acc, $dir, $mode]) {
            $made[] = (int)db_insert('acc_entries', ['account_id' => $acc, 'entry_date' => $date, 'kind' => $kind, 'direction' => $dir, 'mode' => $mode, 'amount' => fee_rupees($amount),
                'head_id' => $head['id'] ?? null, 'fy' => $fy, 'series' => ACC_SERIES[$kind], 'seq' => $seq, 'voucher_no' => $no, 'party' => $party !== '' ? $party : null,
                'reference' => $reference !== '' ? $reference : null, 'bill_no' => mb_substr(trim((string)($e['bill_no'] ?? '')), 0, 50) ?: null, 'bill_date' => $bill_date !== '' ? $bill_date : null,
                'description' => $description !== '' ? $description : null, 'attachment' => $e['attachment'] ?? null, 'created_by' => $admin_id ?: null]);
        }
        if (count($made) === 2) {
            db_execute('UPDATE acc_entries SET pair_id = ? WHERE id = ?', 'ii', $made[1], $made[0]);
            db_execute('UPDATE acc_entries SET pair_id = ? WHERE id = ?', 'ii', $made[0], $made[1]);
        }
        db_commit();
    } catch (Throwable $ex) {
        db_rollback();
        if (!($ex instanceof mysqli_sql_exception) && $ex instanceof RuntimeException) throw $ex;
        throw new RuntimeException((int)$ex->getCode() === 1062 ? 'Two vouchers were numbered at the same moment — nothing was saved; save again.' : 'The entry could not be saved: ' . $ex->getMessage());
    }
    acc_log($admin_id, 'ACC_ENTRY_ADDED', 'acc_entries', $made[0], null, ['voucher' => $no, 'kind' => $kind, 'amount' => fee_rupees($amount), 'accounts' => array_column($legs, 0), 'head' => $head['name'] ?? null, 'party' => $party]);
    return [$made[0], $no];
}

/**
 * Cancel an entry (and the other half of a deposit, withdrawal or transfer) with a reason. A fee entry is cancelled
 * through its fee receipt; nothing in the closed books changes; money that has been spent cannot be taken back out.
 * Returns the voucher number.
 */
function acc_cancel_entry(int $id, string $reason, int $admin_id): string {
    $reason = mb_substr(trim($reason), 0, 255);
    if ($reason === '') throw new RuntimeException('Give the reason for cancelling.');
    db_begin_transaction();
    try {
        $e = db_get_row('SELECT * FROM acc_entries WHERE id = ? FOR UPDATE', 'i', $id);
        if (!$e) throw new RuntimeException('Entry not found.');
        if ($e['kind'] === 'fee') throw new RuntimeException("This came from fee receipt {$e['reference']} — cancel the receipt in Fees → Receipts and its money leaves the accounts with it.");
        if ($e['status'] === 'cancelled') throw new RuntimeException("{$e['voucher_no']} is already cancelled.");
        if (acc_locked($e['entry_date'])) throw new RuntimeException('The books are closed up to ' . date('d M Y', strtotime(acc_settings()['lock_date'])) . " — {$e['voucher_no']} is in them.");
        $rows = [$e];
        if ($e['pair_id']) $rows[] = db_get_row('SELECT * FROM acc_entries WHERE id = ? FOR UPDATE', 'i', (int)$e['pair_id']);
        $ids = array_values(array_unique(array_map(fn($r) => (int)$r['account_id'], $rows)));
        sort($ids);
        db_get_all('SELECT id FROM acc_accounts WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id FOR UPDATE', str_repeat('i', count($ids)), ...$ids);
        foreach ($rows as $r) {
            if ($r['direction'] !== 'in') continue;
            if (acc_low_point((int)$r['account_id'], $r['mode'], $r['entry_date']) < fee_paise($r['amount'])) {
                throw new RuntimeException('This money has been spent — taking it back would leave ' . acc_accounts()[(int)$r['account_id']]['name'] . ' with less than nothing in ' . ($r['mode'] === 'cash' ? 'cash' : 'the bank') . '. Cancel what was paid from it first.');
            }
        }
        foreach ($rows as $r) db_execute("UPDATE acc_entries SET status = 'cancelled', cancelled_at = NOW(), cancelled_by = ?, cancel_reason = ? WHERE id = ?", 'isi', $admin_id ?: null, $reason, (int)$r['id']);
        db_commit();
    } catch (Throwable $ex) {
        db_rollback();
        if (!($ex instanceof mysqli_sql_exception) && $ex instanceof RuntimeException) throw $ex;
        throw new RuntimeException('The entry could not be cancelled: ' . $ex->getMessage());
    }
    acc_log($admin_id, 'ACC_ENTRY_CANCELLED', 'acc_entries', $id, ['status' => 'valid'], ['voucher' => $e['voucher_no'], 'amount' => $e['amount'], 'reason' => $reason]);
    return (string)$e['voucher_no'];
}

/**
 * The lines of the books for a period, in date order, for the accounts in view (all when $ids is empty): a day's fee
 * entries in one line per account, cash or bank and fee head; both halves of a deposit, withdrawal or transfer in one
 * line when both are in view; and the opening balance of an account that opens after the period begins, on its opening date.
 * A line: date, voucher, account, text, sub, cash_in, cash_out, bank_in, bank_out (paise).
 */
function acc_book_lines(string $from, string $to, array $ids = []): array {
    $all = acc_accounts();
    $ids = $ids ? array_values(array_intersect(array_map('intval', $ids), array_keys($all))) : array_keys($all);
    if (!$ids) return [];
    $view = array_flip($ids);
    $blank = ['voucher' => '', 'sub' => '', 'cash_in' => 0, 'cash_out' => 0, 'bank_in' => 0, 'bank_out' => 0];
    $lines = [];
    foreach ($ids as $id) {
        $a = $all[$id];
        if ($a['opening_date'] <= $from || $a['opening_date'] > $to || (!fee_paise($a['opening_cash']) && !fee_paise($a['opening_bank']))) continue;
        $lines[] = ['date' => $a['opening_date'], 'order' => 0, 'account' => $a['name'], 'text' => 'Opening balance', 'cash_in' => fee_paise($a['opening_cash']), 'bank_in' => fee_paise($a['opening_bank'])] + $blank;
    }
    $rows = [];
    foreach (db_get_all('SELECT e.*, hd.name AS head_name FROM acc_entries e LEFT JOIN acc_heads hd ON hd.id = e.head_id
        WHERE e.status = \'valid\' AND e.entry_date BETWEEN ? AND ? AND e.account_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY e.entry_date, e.id',
        'ss' . str_repeat('i', count($ids)), $from, $to, ...$ids) as $r) $rows[(int)$r['id']] = $r;
    $pairs = [];
    $missing = array_values(array_filter(array_map(fn($r) => (int)$r['pair_id'], $rows), fn($p) => $p && !isset($rows[$p])));
    if ($missing) foreach (db_get_all('SELECT id, account_id FROM acc_entries WHERE id IN (' . implode(',', array_fill(0, count($missing), '?')) . ')', str_repeat('i', count($missing)), ...$missing) as $p) $pairs[(int)$p['id']] = (int)$p['account_id'];
    $fees = []; $done = [];
    foreach ($rows as $id => $r) {
        if (isset($done[$id])) continue;
        $col = $r['mode'] . '_' . $r['direction'];
        $amt = fee_paise($r['amount']);
        $name = $all[(int)$r['account_id']]['name'];
        if ($r['kind'] === 'fee') {
            $k = $r['entry_date'] . '|' . $r['account_id'] . '|' . $r['mode'] . '|' . $r['description'];
            if (!isset($fees[$k])) { $fees[$k] = count($lines); $lines[] = ['date' => $r['entry_date'], 'order' => 1, 'account' => $name, 'text' => 'Fees — ' . $r['description'], 'nos' => []] + $blank; }
            $lines[$fees[$k]][$col] += $amt;
            $lines[$fees[$k]]['nos'][(string)$r['reference']] = true;
            continue;
        }
        $line = ['date' => $r['entry_date'], 'order' => 2, 'voucher' => (string)$r['voucher_no'], 'account' => $name] + $blank;
        $line[$col] += $amt;
        $pair = $r['pair_id'] ? ($rows[(int)$r['pair_id']] ?? null) : null;
        if ($pair) { $line[$pair['mode'] . '_' . $pair['direction']] += fee_paise($pair['amount']); $done[(int)$pair['id']] = true; }
        $other = $pair ? (int)$pair['account_id'] : ($pairs[(int)$r['pair_id']] ?? 0);
        $sub = array_filter([(string)$r['party'], (string)$r['description'], (string)$r['reference'], $r['bill_no'] ? 'Bill ' . $r['bill_no'] : '']);
        if ($r['kind'] === 'income' || $r['kind'] === 'expense') $line['text'] = (string)$r['head_name'];
        elseif ($r['kind'] === 'deposit') $line['text'] = 'Cash deposited in the bank';
        elseif ($r['kind'] === 'withdraw') $line['text'] = 'Cash drawn from the bank';
        elseif ($pair) { $from_acc = $r['direction'] === 'out' ? $r : $pair; $to_acc = $r['direction'] === 'out' ? $pair : $r;
            $line['text'] = 'Transfer'; $line['account'] = $all[(int)$from_acc['account_id']]['name'] . ' → ' . $all[(int)$to_acc['account_id']]['name']; }
        else $line['text'] = ($r['direction'] === 'out' ? 'Transfer to ' : 'Transfer from ') . ($all[$other]['name'] ?? 'another account');
        $line['sub'] = implode(' · ', $sub);
        $lines[] = $line;
    }
    foreach ($fees as $i) {
        $nos = array_keys($lines[$i]['nos']);
        sort($nos);
        $lines[$i]['sub'] = count($nos) . (count($nos) > 1 ? ' receipts · ' . $nos[0] . ' to ' . end($nos) : ' receipt · ' . $nos[0]);
        unset($lines[$i]['nos']);
    }
    usort($lines, fn($a, $b) => [$a['date'], $a['order']] <=> [$b['date'], $b['order']]);
    return $lines;
}

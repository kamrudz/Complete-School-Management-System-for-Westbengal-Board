<?php
/**
 * The admission application on one A4 sheet — the applicant's copy and the office copy alike.
 * $app is an admission_applications row joined with class_name, stage and session_name. $base is the way to the
 * site root from the page that prints ("" or "../"). The office copy shows ID numbers in full; the applicant's
 * copy hides all but the last four digits.
 */
require_once __DIR__ . '/admission_helper.php';

function adm_copy_render(array $app, string $base = '', bool $office = false, string $back = 'javascript:history.back()'): void
{
$school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];
$centre = !empty($app['centre_id']) ? db_get_row('SELECT name, place, phone FROM admission_centres WHERE id = ?', 'i', (int)$app['centre_id']) : null;

$xi = [];
foreach (['xi_main_subject_1' => 'Main 1', 'xi_main_subject_2' => 'Main 2', 'xi_main_subject_3' => 'Main 3', 'xi_additional_subject' => 'Additional'] as $k => $label) {
    if (empty($app[$k])) continue;
    $xi[$label] = (string)(db_get_row('SELECT subject_name FROM subjects WHERE id = ?', 'i', (int)$app[$k])['subject_name'] ?? '');
}
$mp = json_decode((string)($app['mp_subjects_json'] ?? '[]'), true) ?: [];

/** A document from the locked folder, inside the page itself — never as a link anyone could follow. */
$inline = function (?string $stored): string {
    $path = admission_doc_path($stored ?? '');
    if (!$path || filesize($path) > 2097152) return '';
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
    return in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true) ? 'data:' . $mime . ';base64,' . base64_encode((string)file_get_contents($path)) : '';
};
$photo = $inline($app['photo'] ?? '');
$sign = $inline($app['signature'] ?? '');
$logo = !empty($school['logo']) && is_file(__DIR__ . '/../uploads/' . basename($school['logo'])) ? $base . 'uploads/' . rawurlencode(basename($school['logo'])) : '';

/** All but the last four digits hidden. */
$mask = function ($v) use ($office): string {
    $d = preg_replace('/\s+/', '', (string)$v);
    if ($office) return $d;
    return $d === '' ? '' : str_repeat('X', max(0, strlen($d) - 4)) . substr($d, -4);
};
$date = fn($d) => $d ? date('d-m-Y', strtotime($d)) : '';
$e = fn($v) => htmlspecialchars(trim((string)$v), ENT_QUOTES, 'UTF-8');

/** The fields of one section that hold something: [label, value]. */
$fields = fn(array $pairs) => array_values(array_filter($pairs, fn($p) => trim((string)$p[1]) !== ''));
$student = $fields([
    ['Student name', $app['student_name']], ['Name as in Aadhaar', $app['name_as_per_aadhaar']], ['Date of birth', $date($app['dob'])],
    ['Gender', $app['gender']], ['Religion', $app['religion']], ['Caste', trim($app['caste'] . ($app['sub_caste'] ? ' (' . $app['sub_caste'] . ')' : ''))],
    ['Blood group', $app['blood_group']], ['Disability', $app['disability'] && $app['disability'] !== 'No' ? $app['disability'] . ($app['disability_type'] ? ' — ' . $app['disability_type'] : '') : ''],
    ['Aadhaar', $mask($app['student_aadhaar'])], ['Banglar Shiksha ID', $app['banglarshiksha_id']], ['PEN', $app['pen_id']], ['APAAR', $app['apaar_id']],
    ['Birth reg. no.', $app['birth_registration_number']], ['Mobile', $app['student_mobile']],
]);
$family = $fields([
    ['Father', $app['father_name']], ['Father\'s mobile', $app['father_mobile']], ['Father\'s occupation', $app['father_occupation']],
    ['Father\'s Aadhaar', !empty($app['father_aadhaar_not_available']) ? 'Not available' : $mask($app['father_aadhaar'])],
    ['Mother', $app['mother_name']], ['Mother\'s occupation', $app['mother_occupation']],
    ['Mother\'s Aadhaar', !empty($app['mother_aadhaar_not_available']) ? 'Not available' : $mask($app['mother_aadhaar'])],
    ['Guardian', $app['guardian_name'] ? $app['guardian_name'] . ($app['guardian_relation'] ? ' (' . $app['guardian_relation'] . ')' : '') : ''],
    ['Guardian\'s mobile', $app['guardian_mobile']], ['Annual income', $app['annual_income'] ? '₹ ' . number_format((float)$app['annual_income']) : ''],
]);
$address = trim(implode(', ', array_filter(array_map('trim', [$app['village'], $app['post_office'] ? 'P.O. ' . $app['post_office'] : '', $app['police_station'] ? 'P.S. ' . $app['police_station'] : '',
    $app['district'], $app['state'], $app['pin_code'] ? 'PIN ' . $app['pin_code'] : '']))));
$previous = $fields([
    ['Previous school', $app['previous_school']], ['Last class', $app['previous_class']], ['Result', $app['previous_result']], ['TC no.', $app['tc_no']],
]);
$bank = $fields([['Bank', trim($app['bank_name'] . ($app['branch_name'] ? ', ' . $app['branch_name'] : ''))], ['Account', $mask($app['account_number'])], ['IFSC', $app['ifsc_code']]]);
$docs = [];
foreach (ADM_DOCS as $k => [$label]) if (!empty($app[$k])) $docs[] = $label;

$status = ['Pending' => 'Under review', 'Admitted' => 'Selected', 'Waitlisted' => 'On the waiting list', 'Rejected' => 'Not selected', 'Enrolled' => 'Admitted'][$app['application_status']] ?? $app['application_status'];
$grid = function (array $rows, string $cols = ''): void {
    echo '<div class="grid' . ($cols !== '' ? ' ' . $cols : '') . '">';
    foreach ($rows as [$l, $v]) echo '<div><span>' . htmlspecialchars($l) . '</span><b>' . htmlspecialchars((string)$v) . '</b></div>';
    echo '</div>';
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application <?php echo $e($app['application_ref']); ?> — <?php echo $e($app['student_name']); ?></title>
<style>
    @page { size: A4 portrait; margin: 8mm 9mm; }
    :root { --ink: #17163f; --brand: #2a2886; --line: #c9c9df; --soft: #f1f0fb; --muted: #5d6079; }
    * { box-sizing: border-box; }
    html, body { margin: 0; background: #e9e9f2; color: var(--ink); font-family: 'Segoe UI', Arial, sans-serif; font-size: 9.3pt; line-height: 1.25; }
    .bar { max-width: 190mm; margin: 14px auto; display: flex; gap: 8px; justify-content: flex-end; }
    .bar a, .bar button { font: 600 13px 'Segoe UI', sans-serif; padding: 8px 14px; border-radius: 8px; border: 1px solid var(--line); background: #fff; color: var(--ink); text-decoration: none; cursor: pointer; }
    .bar button { background: var(--brand); color: #fff; border-color: var(--brand); }
    .sheet { width: 190mm; margin: 0 auto 30px; background: #fff; padding: 7mm 8mm; box-shadow: 0 6px 30px rgba(0,0,0,.15); position: relative; }
    .head { display: flex; align-items: center; gap: 4mm; border-bottom: 2px solid var(--brand); padding-bottom: 3mm; }
    .head img { width: 16mm; height: 16mm; object-fit: contain; }
    .head .name { flex: 1; text-align: center; }
    .head h1 { margin: 0; font-size: 15pt; letter-spacing: .3px; color: var(--brand); }
    .head p { margin: 1px 0 0; font-size: 8.3pt; color: var(--muted); }
    .title { text-align: center; margin: 2mm 0 2mm; font-size: 11pt; font-weight: 800; letter-spacing: 1.5px; }
    .title small { display: block; font-size: 8pt; font-weight: 600; letter-spacing: .5px; color: var(--muted); }
    .meta { display: grid; grid-template-columns: 1.3fr 1fr 1fr 1fr; border: 1.5px solid var(--brand); border-radius: 2mm; overflow: hidden; margin-bottom: 3mm; }
    .meta div { padding: 1.8mm 2.5mm; border-left: 1px solid var(--line); }
    .meta div:first-child { border-left: 0; background: var(--soft); }
    .meta span { display: block; font-size: 7pt; text-transform: uppercase; letter-spacing: .4px; color: var(--muted); }
    .meta b { font-size: 10pt; }
    .meta .ref b { font-size: 13pt; letter-spacing: 1px; color: var(--brand); }
    .body { display: grid; grid-template-columns: 1fr 34mm; gap: 4mm; }
    .side { display: flex; flex-direction: column; gap: 3mm; }
    .box { border: 1px solid var(--line); border-radius: 1.5mm; display: flex; align-items: center; justify-content: center; text-align: center; color: var(--muted); font-size: 7.5pt; overflow: hidden; background: #fff; }
    .box.photo { width: 34mm; height: 42mm; }
    .box.sign { width: 34mm; height: 13mm; }
    .box img { width: 100%; height: 100%; object-fit: cover; }
    .box.sign img { object-fit: contain; }
    .side .cap { font-size: 7pt; text-align: center; color: var(--muted); margin-top: -2mm; }
    h2 { font-size: 8.3pt; margin: 2mm 0 1mm; padding: 1mm 2mm; background: var(--soft); border-left: 3px solid var(--brand); text-transform: uppercase; letter-spacing: .6px; }
    h2:first-child { margin-top: 0; }
    .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: .7mm 3mm; }
    .grid.six { grid-template-columns: repeat(6, 1fr); }
    .grid.three { grid-template-columns: 2.4fr 1fr 1fr; }
    .grid div { border-bottom: 1px dotted var(--line); padding-bottom: .3mm; min-width: 0; }
    .grid span { display: block; font-size: 7pt; color: var(--muted); }
    .grid b { font-weight: 600; word-break: break-word; }
    .line { border-bottom: 1px dotted var(--line); padding-bottom: .6mm; }
    table { width: 100%; border-collapse: collapse; font-size: 8.3pt; }
    th, td { border: 1px solid var(--line); padding: .8mm 1.2mm; text-align: center; }
    th { background: var(--soft); font-weight: 600; }
    td.l, th.l { text-align: left; }
    .chips span { display: inline-block; border: 1px solid var(--brand); color: var(--brand); border-radius: 10mm; padding: .4mm 2.5mm; margin: 0 1.5mm 1mm 0; font-weight: 600; }
    .chips small { color: var(--muted); font-weight: 400; }
    .decl { margin-top: 2.5mm; font-size: 8pt; color: #333; border-top: 1px solid var(--line); padding-top: 2mm; }
    .signs { display: grid; grid-template-columns: repeat(<?php echo $centre ? 3 : 2; ?>, 1fr); gap: 8mm; margin-top: 8mm; }
    .signs div { border-top: 1px solid var(--ink); text-align: center; padding-top: 1mm; font-size: 8pt; }
    .note { margin-top: 2.5mm; padding: 1.5mm 2.5mm; background: var(--soft); border-radius: 1.5mm; font-size: 8pt; }
    .foot { margin-top: 2mm; display: flex; justify-content: space-between; font-size: 7pt; color: var(--muted); }
    .reject { margin-top: 2mm; padding: 1.5mm 2.5mm; border: 1px solid #e5a4a0; background: #fdecea; color: #8e1b1b; }
    @media print {
        html, body { background: #fff; }
        .bar { display: none; }
        .sheet { width: auto; margin: 0; padding: 0; box-shadow: none; }
        h2, .meta, .note, .chips span, th { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        table, .grid, .signs { break-inside: avoid; }
    }
    @media screen and (max-width: 760px) { .sheet { width: auto; margin: 0 8px 20px; } .grid { grid-template-columns: 1fr 1fr; } .body { grid-template-columns: 1fr; } .side { flex-direction: row; } }
</style>
</head>
<body>
<div class="bar">
    <a href="<?php echo $e($back); ?>">Back</a>
    <button type="button" onclick="window.print()">Print</button>
</div>
<div class="sheet">
    <div class="head">
        <?php if ($logo): ?><img src="<?php echo $e($logo); ?>" alt=""><?php endif; ?>
        <div class="name">
            <h1><?php echo $e($school['school_name'] ?? ''); ?></h1>
            <p><?php echo $e($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
            <p><?php echo $e(implode('  ·  ', array_filter([!empty($school['udise_code']) ? 'UDISE ' . $school['udise_code'] : '', !empty($school['school_code']) ? 'Index No. ' . $school['school_code'] : '', $school['phone'] ?? '', $school['email'] ?? '']))); ?></p>
        </div>
        <?php if ($logo): ?><div style="width:16mm"></div><?php endif; ?>
    </div>

    <div class="title">ADMISSION APPLICATION<small><?php echo $office ? 'Office copy' : 'Copy for the applicant'; ?></small></div>

    <div class="meta">
        <div class="ref"><span>Application No.</span><b><?php echo $e($app['application_ref']); ?></b></div>
        <div><span>Class · Session</span><b>Class <?php echo $e($app['class_name']); ?><?php echo $app['session_name'] ? ' · ' . $e($app['session_name']) : ''; ?></b></div>
        <div><span>Applied on</span><b><?php echo $e(date('d-m-Y, h:i A', strtotime($app['created_at']))); ?></b></div>
        <div><span>Status</span><b><?php echo $e($status); ?></b></div>
    </div>

    <div class="body">
        <div>
            <h2>Student</h2>
            <?php $grid($student); ?>

            <h2>Parents and guardian</h2>
            <?php $grid($family); ?>

            <?php if ($address !== ''): ?>
            <h2>Address</h2>
            <div class="line"><b style="font-weight:600"><?php echo $e($address); ?></b></div>
            <?php endif; ?>

            <?php if ($previous): ?>
            <h2>Previous school</h2>
            <?php $grid($previous); ?>
            <?php endif; ?>
        </div>
        <div class="side">
            <div class="box photo"><?php echo $photo !== '' ? '<img src="' . $photo . '" alt="Photo">' : 'Paste a recent<br>passport-size<br>photograph'; ?></div>
            <div class="box sign"><?php echo $sign !== '' ? '<img src="' . $sign . '" alt="Signature">' : ''; ?></div>
            <div class="cap">Applicant's signature</div>
        </div>
    </div>

    <?php if (!empty($app['mp_board']) || $mp): ?>
    <h2>Madhyamik (Class X) result</h2>
    <?php $grid($fields([['Board', $app['mp_board']], ['Year', $app['mp_year']], ['Roll no.', $app['mp_roll_no']], ['Registration no.', $app['mp_registration_no']],
        ['Total', $app['mp_total_marks'] !== null ? rtrim(rtrim((string)$app['mp_total_marks'], '0'), '.') . ' / ' . rtrim(rtrim((string)$app['mp_total_full_marks'], '0'), '.') : ''],
        ['Percentage', $app['mp_percentage'] !== null ? rtrim(rtrim((string)$app['mp_percentage'], '0'), '.') . '%' : '']]), 'six'); ?>
    <?php if ($mp): ?>
    <table style="margin-top:1.5mm">
        <tr><th class="l">Subject</th><?php foreach ($mp as $m): ?><th><?php echo $e($m['subject'] ?? ''); ?></th><?php endforeach; ?></tr>
        <tr><td class="l">Marks</td><?php foreach ($mp as $m): ?><td><b><?php echo $e($m['marks_obtained'] ?? ''); ?></b> / <?php echo $e($m['full_marks'] ?? ''); ?></td><?php endforeach; ?></tr>
    </table>
    <?php endif; ?>
    <?php endif; ?>

    <?php if ($xi): ?>
    <h2>Class XI subjects chosen</h2>
    <div class="chips"><?php foreach ($xi as $label => $name): ?><span><small><?php echo $e($label); ?>:</small> <?php echo $e($name); ?></span><?php endforeach; ?>
        <span style="border-color:var(--line);color:var(--muted)">Bengali and English for everyone</span></div>
    <?php endif; ?>

    <?php if ($bank): ?>
    <h2>Bank account</h2>
    <?php $grid($bank, 'three'); ?>
    <?php endif; ?>

    <h2>Documents given with the application</h2>
    <div class="line"><?php echo $docs ? $e(implode('  ·  ', $docs)) : 'None'; ?><?php echo $centre ? '<span style="float:right;color:var(--muted)">Made at ' . $e($centre['name'] . ($centre['place'] ? ', ' . $centre['place'] : '')) . '</span>' : ''; ?></div>

    <?php if ($app['application_status'] === 'Rejected' && !empty($app['reject_reason'])): ?>
    <div class="reject"><b>Reason:</b> <?php echo $e($app['reject_reason']); ?></div>
    <?php endif; ?>

    <div class="decl">I declare that the information given here is true. I understand the admission may be cancelled if any of it is found to be false.</div>
    <div class="signs">
        <div>Signature of the guardian</div>
        <?php if ($centre): ?><div>Centre: <?php echo $e($centre['name']); ?></div><?php endif; ?>
        <div>Received by the school office</div>
    </div>

    <div class="note"><b>Keep this copy</b> and bring it with the original documents when the school calls. Applying costs nothing — the admission fee is paid at the school.</div>
    <div class="foot"><span>Application <?php echo $e($app['application_ref']); ?><?php echo $office ? '' : ' · ID numbers show their last four digits only'; ?></span><span>Printed <?php echo date('d-m-Y, h:i A'); ?></span></div>
</div>
</body>
</html>
<?php
}

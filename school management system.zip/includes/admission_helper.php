<?php
/**
 * admission_helper.php
 * Shared helper functions for the Online Admission module.
 */

const ADM_STAGES = ['primary' => 'Primary (I–IV)', 'upper_primary' => 'Upper Primary (V–VIII)', 'secondary' => 'Secondary (IX–X)', 'higher_secondary' => 'Higher Secondary (XI–XII)'];
const ADM_ALL = ['primary', 'upper_primary', 'secondary', 'higher_secondary'];
/**
 * What a stage can be asked to give: item => [label, group, stages it is asked in, stages where it is required unless
 * Admission Settings say otherwise]. The student's name and the guardian's mobile are always required.
 */
const ADM_ITEMS = [
    'dob'                       => ['Date of birth', 'Student', ADM_ALL, ADM_ALL],
    'gender'                    => ['Gender', 'Student', ADM_ALL, ADM_ALL],
    'student_aadhaar'           => ['Aadhaar number', 'Student', ADM_ALL, []],
    'birth_registration_number' => ['Birth registration no.', 'Student', ADM_ALL, ['primary']],
    'banglarshiksha_id'         => ['Banglar Shiksha ID', 'Student', ADM_ALL, []],
    'pen_id'                    => ['PEN', 'Student', ADM_ALL, []],
    'apaar_id'                  => ['APAAR ID', 'Student', ADM_ALL, []],
    'religion'                  => ['Religion', 'Student', ADM_ALL, []],
    'caste'                     => ['Caste', 'Student', ADM_ALL, []],
    'blood_group'               => ['Blood group', 'Student', ADM_ALL, []],
    'father_name'               => ["Father's name", 'Parents', ADM_ALL, ADM_ALL],
    'mother_name'               => ["Mother's name", 'Parents', ADM_ALL, ADM_ALL],
    'father_aadhaar'            => ["Father's Aadhaar", 'Parents', ADM_ALL, []],
    'mother_aadhaar'            => ["Mother's Aadhaar", 'Parents', ADM_ALL, []],
    'village'                   => ['Village / street', 'Address', ADM_ALL, ADM_ALL],
    'post_office'               => ['Post office', 'Address', ADM_ALL, ADM_ALL],
    'police_station'            => ['Police station', 'Address', ADM_ALL, ADM_ALL],
    'district'                  => ['District', 'Address', ADM_ALL, ADM_ALL],
    'pin_code'                  => ['PIN code', 'Address', ADM_ALL, ADM_ALL],
    'account_number'            => ['Bank account and IFSC', 'Address', ADM_ALL, []],
    'previous_school'           => ['Previous school', 'Previous school', ADM_ALL, ['upper_primary', 'secondary', 'higher_secondary']],
    'previous_class'            => ['Last class and result', 'Previous school', ['primary', 'upper_primary', 'secondary'], ['upper_primary', 'secondary']],
    'tc_no'                     => ['TC number', 'Previous school', ['primary', 'upper_primary', 'secondary'], []],
    'photo'                     => ['Photo', 'Documents', ADM_ALL, ADM_ALL],
    'signature'                 => ['Signature', 'Documents', ADM_ALL, ['secondary', 'higher_secondary']],
    'birth_certificate'         => ['Birth certificate', 'Documents', ADM_ALL, ['primary', 'upper_primary']],
    'student_aadhaar_image'     => ['Aadhaar card', 'Documents', ADM_ALL, []],
    'tc_doc'                    => ['TC copy', 'Documents', ['primary', 'upper_primary', 'secondary'], []],
    'marksheet_doc'             => ['Last mark sheet', 'Documents', ADM_ALL, ['higher_secondary']],
];
/** The documents an application can carry: column => [label, size limit in KB once stored]. */
const ADM_DOCS = ['photo' => ['Photo', 15], 'signature' => ['Signature', 10], 'birth_certificate' => ['Birth certificate', 100],
    'student_aadhaar_image' => ['Aadhaar card', 50], 'tc_doc' => ['TC copy', 100], 'marksheet_doc' => ['Mark sheet', 100]];

const ADM_PAGES = [
    'admission_applications.php' => ['Applications', 'fa-list'],
    'admission_merit.php'        => ['Merit List', 'fa-ranking-star'],
    'admission_centres.php'      => ['Application Centres', 'fa-store'],
    'admission_settings.php'     => ['Admission Settings', 'fa-sliders-h'],
];
function adm_tabs(string $active): void { require_once __DIR__ . '/exam_ui.php'; exam_tabs($active, ADM_PAGES); }
function adm_log(int $admin_id, string $action, $id, $old = null, $new = null): void {
    if (function_exists('log_action')) log_action($admin_id, $action, 'admission_applications', $id, $old, $new);
}
const ADM_STATUS = ['Pending' => ['Pending', 'off'], 'Admitted' => ['Selected', 'ok'], 'Waitlisted' => ['Waiting', 'warn'], 'Rejected' => ['Rejected', 'bad'], 'Enrolled' => ['Enrolled', 'ok']];

/** The locked folder for applicants' documents (with trailing slash); never served directly — see admin/admission_doc.php. */
function admission_docs_dir(): string {
    $dir = dirname(__DIR__) . '/uploads/admission/docs/';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_file($dir . '.htaccess')) @file_put_contents($dir . '.htaccess', "# Applicants' documents: never served directly — see admin/admission_doc.php\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
    if (!is_file($dir . 'index.html')) @file_put_contents($dir . 'index.html', '');
    return $dir;
}
/** The full path of a stored document, or null when the name is not one the upload made or the file is gone. */
function admission_doc_path(?string $name): ?string {
    $name = (string)$name;
    if (!preg_match('/^adm_[0-9a-f]{13,32}_[a-z]+\.(jpg|jpeg|png|webp|pdf)$/', $name)) return null;
    $path = admission_docs_dir() . $name;
    return is_file($path) ? $path : null;
}

/** Count one more use of $key; true once it is over $max within $minutes (the count starts again after that). */
function adm_limit_hit(string $key, int $max, int $minutes): bool {
    $id = mb_substr('adm:' . $key, 0, 100);
    db_execute('INSERT INTO login_attempts (identifier, attempt_count, first_attempt_at) VALUES (?, 1, NOW())
        ON DUPLICATE KEY UPDATE attempt_count = IF(first_attempt_at < NOW() - INTERVAL ? MINUTE, 1, attempt_count + 1),
                                first_attempt_at = IF(first_attempt_at < NOW() - INTERVAL ? MINUTE, NOW(), first_attempt_at)', 'sii', $id, $minutes, $minutes);
    return (int)(db_get_row('SELECT attempt_count FROM login_attempts WHERE identifier = ?', 's', $id)['attempt_count'] ?? 0) > $max;
}
/** Is $key over $max within $minutes already (without counting)? */
function adm_limit_reached(string $key, int $max, int $minutes): bool {
    return (bool)db_get_row('SELECT 1 FROM login_attempts WHERE identifier = ? AND attempt_count >= ? AND first_attempt_at >= NOW() - INTERVAL ? MINUTE',
        'sii', mb_substr('adm:' . $key, 0, 100), $max, $minutes);
}
function adm_limit_clear(string $key): void { db_execute('DELETE FROM login_attempts WHERE identifier = ?', 's', mb_substr('adm:' . $key, 0, 100)); }
function adm_client_ip(): string { return (string)($_SERVER['REMOTE_ADDR'] ?? ''); }

if (!function_exists('h')) { function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

/** A session's name — the public pages have no exam UI loaded. */
function adm_session_name(int $session_id): string {
    return (string)(db_get_row('SELECT session_name FROM academic_sessions WHERE id = ?', 'i', $session_id)['session_name'] ?? '');
}

function adm_active_session_id(): int {
    return (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
}

/** The admission settings: open, session, start and last date, notice. */
function adm_settings(): array {
    return (db_get_row('SELECT admission_open, admission_session_id, admission_start, admission_end, admission_notice FROM school_settings WHERE id = 1') ?: [])
        + ['admission_open' => 0, 'admission_session_id' => 0, 'admission_start' => null, 'admission_end' => null, 'admission_notice' => ''];
}
/** Is the form taking applications today? '' when it is, else why not. */
function adm_closed_reason(array $s): string {
    $today = date('Y-m-d');
    if (empty($s['admission_open']) || !(int)$s['admission_session_id']) return 'Admission is closed now.';
    if (!empty($s['admission_start']) && $today < $s['admission_start']) return 'Admission opens on ' . date('d M Y', strtotime($s['admission_start'])) . '.';
    if (!empty($s['admission_end']) && $today > $s['admission_end']) return 'The last date was ' . date('d M Y', strtotime($s['admission_end'])) . '.';
    return '';
}
/** The classes open for admission in a session, in class order: id => class row + seats and min_percent. */
function adm_open_classes(int $session_id): array {
    $seats = [];
    foreach (db_get_all('SELECT class_id, seats, min_percent FROM class_admission_seats WHERE session_id = ?', 'i', $session_id) as $r) $seats[(int)$r['class_id']] = $r;
    $out = [];
    foreach (class_rows() as $id => $c) if (isset($seats[$id])) $out[$id] = $c + ['seats' => $seats[$id]['seats'] !== null ? (int)$seats[$id]['seats'] : null, 'min_percent' => $seats[$id]['min_percent']];
    return $out;
}
/** The seats for each Class XI subject in a session: subject id => seats. */
function adm_subject_seats(int $session_id): array {
    return array_map('intval', array_column(db_get_all('SELECT subject_id, seats FROM admission_subject_seats WHERE session_id = ?', 'i', $session_id), 'seats', 'subject_id'));
}
/** The elective subjects Class XI offers in a session (Bengali and English are compulsory): id => name. */
function adm_xi_subjects(int $session_id, int $class_id): array {
    require_once __DIR__ . '/hs_helper.php';
    $skip = array_keys(hs_compulsory_subjects());
    $out = [];
    foreach (db_get_all('SELECT s.id, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id
        WHERE cs.session_id = ? AND cs.class_id = ? AND s.is_active = 1 ORDER BY s.subject_name', 'ii', $session_id, $class_id) as $r) {
        if (!in_array((int)$r['id'], $skip, true)) $out[(int)$r['id']] = $r['subject_name'];
    }
    return $out;
}
/** The third languages a class offers in a session: id => name (two or more make the choice; none means no choice). */
function adm_third_languages(int $session_id, int $class_id): array {
    $rows = db_get_all('SELECT s.id, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id
        WHERE cs.session_id = ? AND cs.class_id = ? AND cs.is_third_language = 1 AND s.is_active = 1 ORDER BY s.subject_name', 'ii', $session_id, $class_id);
    return count($rows) >= 2 ? array_column($rows, 'subject_name', 'id') : [];
}

/** Which items a stage must give in a session: item => required. Settings saved for the session win over the defaults. */
function adm_requirements(int $session_id, string $stage): array {
    $saved = [];
    foreach (db_get_all('SELECT item, required FROM admission_requirements WHERE session_id = ? AND stage = ?', 'is', $session_id, $stage) as $r) $saved[$r['item']] = (int)$r['required'];
    $out = [];
    foreach (ADM_ITEMS as $item => [, , $asked, $default]) if (in_array($stage, $asked, true)) $out[$item] = $saved ? (bool)($saved[$item] ?? 0) : in_array($stage, $default, true);
    return $out;
}

if (!function_exists('db_insert_assoc')) {
    /**
     * Generic INSERT helper for wide tables - avoids manually counting bind_param
     * type strings (which is error-prone with 30-40+ columns).
     *
     * $data format: ['column_name' => ['v' => $value, 't' => 's'], ...]
     *   't' is the mysqli bind type: 's' string, 'i' integer, 'd' double.
     *
     * Returns the new insert id on success, or false on failure.
     */
    function db_insert_assoc($conn, $table, $data) {
        $columns = array_keys($data);
        $types = '';
        $values = [];
        foreach ($data as $spec) {
            $types .= $spec['t'];
            $values[] = $spec['v'];
        }
        $placeholders = implode(',', array_fill(0, count($columns), '?'));
        $sql = "INSERT INTO `$table` (`" . implode('`,`', $columns) . "`) VALUES ($placeholders)";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) { error_log("db_insert_assoc prepare failed for $table: " . mysqli_error($conn)); return false; }

        $bind_args = [$stmt, $types];
        for ($i = 0; $i < count($values); $i++) { $bind_args[] = &$values[$i]; }
        call_user_func_array('mysqli_stmt_bind_param', $bind_args);

        $ok = mysqli_stmt_execute($stmt);
        if (!$ok) { error_log("db_insert_assoc execute failed for $table: " . mysqli_stmt_error($stmt)); }
        $insert_id = $ok ? mysqli_insert_id($conn) : false;
        mysqli_stmt_close($stmt);
        return $insert_id;
    }
}

if (!function_exists('db_update_assoc')) {
    /**
     * Generic UPDATE helper matching db_insert_assoc's $data format.
     * Updates the row where `$where_col` = `$where_val` (id column by default).
     * Returns true on success, false on failure.
     */
    function db_update_assoc($conn, $table, $data, $where_col, $where_val) {
        $sets = [];
        $types = '';
        $values = [];
        foreach ($data as $col => $spec) {
            $sets[] = "`$col` = ?";
            $types .= $spec['t'];
            $values[] = $spec['v'];
        }
        $types .= 'i';
        $values[] = $where_val;
        $sql = "UPDATE `$table` SET " . implode(',', $sets) . " WHERE `$where_col` = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) { error_log("db_update_assoc prepare failed for $table: " . mysqli_error($conn)); return false; }

        $bind_args = [$stmt, $types];
        for ($i = 0; $i < count($values); $i++) { $bind_args[] = &$values[$i]; }
        call_user_func_array('mysqli_stmt_bind_param', $bind_args);

        $ok = mysqli_stmt_execute($stmt);
        if (!$ok) { error_log("db_update_assoc execute failed for $table: " . mysqli_stmt_error($stmt)); }
        mysqli_stmt_close($stmt);
        return $ok;
    }
}

if (!function_exists('find_duplicate_admission_application')) {
    /**
     * Checks whether the same student already has a live application in this
     * session (Pending / Admitted / Enrolled - Rejected ones don't block a
     * fresh re-apply). Matches on Student Aadhaar (if given) OR the
     * combination of Guardian Mobile + Student Name + DOB.
     * Returns the existing application_ref on a match, or null.
     */
    function find_duplicate_admission_application($conn, $session_id, $student_name, $dob, $guardian_mobile, $student_aadhaar) {
        $session_id = (int)$session_id;
        $student_aadhaar = trim($student_aadhaar);

        if ($student_aadhaar !== '') {
            $stmt = mysqli_prepare($conn, "
                SELECT application_ref FROM admission_applications
                WHERE session_id = ? AND student_aadhaar = ? AND application_status IN ('Pending','Admitted','Enrolled')
                LIMIT 1
            ");
            mysqli_stmt_bind_param($stmt, 'is', $session_id, $student_aadhaar);
            mysqli_stmt_execute($stmt);
            $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
            mysqli_stmt_close($stmt);
            if ($row) { return $row['application_ref']; }
        }

        $stmt = mysqli_prepare($conn, "
            SELECT application_ref FROM admission_applications
            WHERE session_id = ? AND guardian_mobile = ? AND LOWER(TRIM(student_name)) = LOWER(TRIM(?))
                  AND (dob = ? OR (dob IS NULL AND ? = ''))
                  AND application_status IN ('Pending','Admitted','Enrolled')
            LIMIT 1
        ");
        mysqli_stmt_bind_param($stmt, 'issss', $session_id, $guardian_mobile, $student_name, $dob, $dob);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        return $row ? $row['application_ref'] : null;
    }
}

if (!function_exists('get_admission_settings')) {
    function get_admission_settings($conn) {
        $stmt = mysqli_prepare($conn, "SELECT admission_open, admission_session_id, razorpay_key_id, razorpay_key_secret FROM school_settings WHERE id=? LIMIT 1");
        if (!$stmt) return [];
        $id = 1;
        mysqli_stmt_bind_param($stmt, 'i', $id);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        return $row ?: [];
    }
}


if (!function_exists('get_admission_field_settings')) {
    /**
     * Returns compulsory-field flags for one admission session.
     * Missing rows are treated as NOT compulsory.
     */
    function get_admission_field_settings($conn, $session_id) {
        $flags = [];
        $session_id = (int)$session_id;
        if ($session_id <= 0) return $flags;

        $stmt = mysqli_prepare($conn, "SELECT field_name, is_compulsory FROM admission_field_settings WHERE session_id=?");
        if (!$stmt) return $flags;
        mysqli_stmt_bind_param($stmt, 'i', $session_id);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($res)) {
            $flags[$row['field_name']] = (int)$row['is_compulsory'];
        }
        mysqli_stmt_close($stmt);
        return $flags;
    }
}

if (!function_exists('admission_field_is_required')) {
    function admission_field_is_required($field_settings, $field_name) {
        return !empty($field_settings[$field_name]);
    }
}

if (!function_exists('admission_required_attr')) {
    function admission_required_attr($field_settings, $field_name) {
        return admission_field_is_required($field_settings, $field_name) ? ' required' : '';
    }
}

if (!function_exists('generate_application_ref')) {
    /** Generates a unique reference like ADM2026-0042 */
    function generate_application_ref($conn) {
        $year = date('Y');
        $prefix = "ADM{$year}-";

        // Next number = 1 + the highest existing serial for this year's prefix.
        $start_pos = strlen($prefix) + 1;
        $like = $prefix . '%';
        $stmt = mysqli_prepare($conn, "SELECT MAX(CAST(SUBSTRING(application_ref, ?) AS UNSIGNED)) AS max_no FROM admission_applications WHERE application_ref LIKE ?");
        if (!$stmt) return null;
        mysqli_stmt_bind_param($stmt, 'is', $start_pos, $like);
        mysqli_stmt_execute($stmt);
        $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
        mysqli_stmt_close($stmt);
        $next = (int)($row['max_no'] ?? 0) + 1;

        $check_stmt = mysqli_prepare($conn, "SELECT id FROM admission_applications WHERE application_ref=? LIMIT 1");
        if (!$check_stmt) return null;
        do {
            $ref = $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
            mysqli_stmt_bind_param($check_stmt, 's', $ref);
            mysqli_stmt_execute($check_stmt);
            $exists = (bool)mysqli_fetch_assoc(mysqli_stmt_get_result($check_stmt));
            $next++;
        } while ($exists);
        mysqli_stmt_close($check_stmt);
        return $ref;
    }
}

if (!function_exists('get_class_admission_info')) {
    /**
     * Returns whether admission is enabled for a session + class.
     * Class selection is controlled only by the presence of a row in
     * class_admission_seats; there is no seat-limit or admission-fee logic.
     */
    function get_class_admission_info($conn, $session_id, $class_id) {
        $session_id = (int)$session_id;
        $class_id = (int)$class_id;

        $stmt = mysqli_prepare($conn, "
            SELECT id FROM class_admission_seats
            WHERE session_id=? AND class_id=? LIMIT 1
        ");
        mysqli_stmt_bind_param($stmt, 'ii', $session_id, $class_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $enabled = (bool)mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        return ['enabled' => $enabled];
    }
}

if (!function_exists('resize_image_under_kb')) {
    /**
     * Re-saves an image as JPEG, reducing quality then dimensions until it's
     * under $max_kb. Works for jpg/png/webp input. Returns true on success,
     * false if the file isn't a supported image (caller should then just copy it).
     */
    function resize_image_under_kb($source_path, $target_path, $max_kb = 100) {
        $info = @getimagesize($source_path);
        if (!$info) return false;

        switch ($info['mime']) {
            case 'image/jpeg':
                $img = @imagecreatefromjpeg($source_path);
                break;
            case 'image/png':
                $src = @imagecreatefrompng($source_path);
                if (!$src) return false;
                // Flatten transparency onto white background (JPEG has no alpha channel).
                $img = imagecreatetruecolor(imagesx($src), imagesy($src));
                imagefill($img, 0, 0, imagecolorallocate($img, 255, 255, 255));
                imagecopy($img, $src, 0, 0, 0, 0, imagesx($src), imagesy($src));
                imagedestroy($src);
                break;
            case 'image/webp':
                $img = @imagecreatefromwebp($source_path);
                break;
            default:
                return false; // unsupported type (e.g. PDF) - caller should just copy as-is
        }
        if (!$img) return false;

        $max_bytes = $max_kb * 1024;
        $quality = 85;
        $attempts = 0;

        do {
            imagejpeg($img, $target_path, $quality);
            clearstatcache();
            $size = filesize($target_path);
            $attempts++;
            if ($size <= $max_bytes) break;

            if ($quality > 30) {
                $quality -= 15;
            } else {
                $w = (int)(imagesx($img) * 0.85);
                $h = (int)(imagesy($img) * 0.85);
                if ($w < 150 || $h < 150) break; // don't shrink below a usable size
                $resized = imagecreatetruecolor($w, $h);
                imagecopyresampled($resized, $img, 0, 0, 0, 0, $w, $h, imagesx($img), imagesy($img));
                imagedestroy($img);
                $img = $resized;
                $quality = 75;
            }
        } while ($attempts < 15);

        imagedestroy($img);
        return true;
    }
}

if (!function_exists('handle_admission_upload')) {
    /**
     * Handles one $_FILES[$field] upload: saves into $upload_dir with a unique name.
     * If it's a jpg/png/webp, auto-resizes to <=$max_kb (default 100KB).
     * PDFs (e.g. birth certificate) can't be auto-compressed, so they're rejected
     * outright if bigger than $max_kb (caller should check $error and show it).
     * Returns the stored filename, or null if no file was uploaded / upload error / too big.
     */
    function handle_admission_upload($field, $max_kb = 100, &$error = null) {
        $upload_dir = admission_docs_dir();
        if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        // Hard cap on the raw upload before any processing (DoS / memory-abuse guard).
        // Final on-disk size is still enforced separately below (images get compressed
        // down to $max_kb; PDFs are rejected outright if they exceed it).
        $HARD_MAX_BYTES = 10 * 1024 * 1024; // 10MB
        if ($_FILES[$field]['size'] > $HARD_MAX_BYTES) {
            $error = "The file is too large. Please upload a smaller one.";
            return null;
        }

        $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
        if (!in_array($ext, $allowed, true)) return null;

        // Verify the actual file content matches an allowed type — the extension
        // alone can be spoofed (e.g. a renamed .php or .html file).
        $allowed_mime = [
            'image/jpeg' => ['jpg', 'jpeg'],
            'image/png'  => ['png'],
            'image/webp' => ['webp'],
            'application/pdf' => ['pdf'],
        ];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $_FILES[$field]['tmp_name']) : '';
        if ($finfo) { finfo_close($finfo); }

        if (!isset($allowed_mime[$mime]) || !in_array($ext, $allowed_mime[$mime], true)) {
            $error = "That file type is not allowed. Upload a JPG, PNG, WEBP or PDF.";
            return null;
        }

        $is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'webp'], true);
        $filename = 'adm_' . bin2hex(random_bytes(12)) . '_' . strtolower(preg_replace('/[^a-z]/i', '', $field)) . '.' . ($is_image ? 'jpg' : 'pdf');
        $target = $upload_dir . $filename;

        if ($is_image) {
            if (!resize_image_under_kb($_FILES[$field]['tmp_name'], $target, $max_kb)) {
                // resize failed (e.g. GD not available) - fall back to plain copy
                move_uploaded_file($_FILES[$field]['tmp_name'], $target);
            }
        } else {
            // PDFs aren't auto-compressed - enforce the size limit directly.
            if ($_FILES[$field]['size'] > $max_kb * 1024) {
                $error = "The file cannot be larger than {$max_kb}KB.";
                return null;
            }
            move_uploaded_file($_FILES[$field]['tmp_name'], $target);
        }
        return $filename;
    }
}

if (!function_exists('razorpay_create_order')) {
    /**
     * Creates a Razorpay Order. Amount must be in RUPEES (converted to paise internally).
     * Returns ['ok'=>bool, 'order_id'=>string|null, 'response'=>raw json string]
     */
    function razorpay_create_order($conn, $amount_rupees, $receipt) {
        $settings = get_admission_settings($conn);
        $key_id     = $settings['razorpay_key_id'] ?? '';
        $key_secret = $settings['razorpay_key_secret'] ?? '';

        if (empty($key_id) || empty($key_secret)) {
            return ['ok' => false, 'order_id' => null, 'response' => 'Razorpay keys not configured.'];
        }

        $payload = [
            'amount'   => (int)round($amount_rupees * 100), // paise
            'currency' => 'INR',
            'receipt'  => $receipt,
        ];

        $ch = curl_init('https://api.razorpay.com/v1/orders');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_USERPWD        => $key_id . ':' . $key_secret,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_TIMEOUT        => 20,
        ]);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);
        if ($http_code >= 200 && $http_code < 300 && !empty($data['id'])) {
            return ['ok' => true, 'order_id' => $data['id'], 'response' => $response];
        }
        return ['ok' => false, 'order_id' => null, 'response' => $response];
    }
}

if (!function_exists('razorpay_verify_signature')) {
    /**
     * Verifies the signature Razorpay sends back after a successful checkout,
     * so nobody can fake a "payment successful" callback.
     */
    function razorpay_verify_signature($conn, $order_id, $payment_id, $signature) {
        $settings = get_admission_settings($conn);
        $key_secret = $settings['razorpay_key_secret'] ?? '';
        if (empty($key_secret)) return false;

        $generated_signature = hash_hmac('sha256', $order_id . '|' . $payment_id, $key_secret);
        return hash_equals($generated_signature, $signature);
    }
}

if (!function_exists('admission_same_school')) {
    /**
     * The student of this school an application belongs to — an own Class X student coming into XI, say. Looked up
     * by the School UID it names and by its Banglar Shiksha ID, PEN and APAAR, and never trusted on one of them alone:
     *   ['student' => row, 'by' => [labels]]  they all point to one student with the same date of birth
     *   ['conflict' => message]               they point to different students, or the date of birth differs
     *   []                                    nobody — a new student
     * $v: previous_student_id, banglarshiksha_id, pen_id, apaar_id, dob (Y-m-d).
     */
    function admission_same_school(array $v): array {
        $found = [];   // student id => the IDs that found them
        $uid = student_uid_clean($v['previous_student_id'] ?? '');
        if ($uid !== '' && db_get_row('SELECT id FROM students WHERE id = ?', 's', $uid)) $found[$uid][] = 'School UID';
        foreach (['banglarshiksha_id' => 'Banglar Shiksha ID', 'pen_id' => 'PEN', 'apaar_id' => 'APAAR'] as $col => $label) {
            $val = trim((string)($v[$col] ?? ''));
            if ($col === 'banglarshiksha_id') $val = (string)student_normalize_bsid($val);
            if ($val === '') continue;
            foreach (db_get_all('SELECT id FROM students WHERE ' . db_identifier($col) . ' = ?', 's', $val) as $r) $found[$r['id']][] = $label;
        }
        if (!$found) return [];
        $who = fn(string $id) => $id . ' ' . (db_get_row('SELECT student_name FROM students WHERE id = ?', 's', $id)['student_name'] ?? '');
        if (count($found) > 1) {
            return ['conflict' => 'The IDs of this application belong to different students: '
                . implode('; ', array_map(fn($id, $by) => $who((string)$id) . ' (' . implode(', ', $by) . ')', array_keys($found), $found)) . '. Correct them before finalizing.'];
        }
        $id = (string)array_key_first($found);
        $st = db_get_row('SELECT s.*, g.father_name FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id WHERE s.id = ?', 's', $id);
        $by = implode(', ', $found[$id]);
        if ((string)$st['dob'] === '') return ['conflict' => "The $by of this application belong to {$who($id)}, who has no date of birth on record — add it on Edit Student, then finalize."];
        if ((string)$st['dob'] !== trim((string)($v['dob'] ?? ''))) return ['conflict' => "The $by of this application belong to {$who($id)}, but the date of birth differs — check the documents and correct the ID or the date of birth."];
        return ['student' => $st, 'by' => $found[$id]];
    }
}

if (!function_exists('admission_continue_problem')) {
    /** Why an existing student cannot be continued into $session_id now ('' when they can). */
    function admission_continue_problem(array $student, int $session_id): string {
        $name = "{$student['id']} {$student['student_name']}";
        if ($student['student_status'] === 'Deleted') return "$name is a deleted student — restore them from Deleted Students first.";
        $cur = db_get_row("SELECT c.class_name, a.session_name FROM student_academic_history h JOIN classes c ON c.id = h.class_id JOIN academic_sessions a ON a.id = h.session_id
                           WHERE h.student_id = ? AND h.academic_status = 'Current' LIMIT 1", 's', $student['id']);
        if ($cur) return "$name is still in Class {$cur['class_name']} ({$cur['session_name']}) — pass them out first (Pass Out), then finalize.";
        if (db_get_row('SELECT id FROM student_academic_history WHERE student_id = ? AND session_id = ? LIMIT 1', 'si', $student['id'], $session_id)) return "$name already has a class in this session.";
        return '';
    }
}

/**
 * Admission by village. 'all': anyone may apply. 'listed': only students from the villages listed for the
 * admission session — the form then offers those villages to choose from instead of a box to type in.
 */
function adm_village_rule(): string
{
    return (string)(db_get_row('SELECT admission_village_rule r FROM school_settings WHERE id = 1')['r'] ?? 'all') === 'listed' ? 'listed' : 'all';
}
/** The villages listed for a session, in order: id => name. */
function adm_villages(int $session_id): array
{
    return array_column(db_get_all('SELECT id, name FROM admission_villages WHERE session_id = ? ORDER BY name', 'i', $session_id), 'name', 'id');
}
/** The villages a form must keep to — [] when anyone may apply. */
function adm_allowed_villages(int $session_id): array
{
    return adm_village_rule() === 'listed' ? adm_villages($session_id) : [];
}
/** The listed spelling of a village, or '' when it is not on the list. Spaces and letter case do not matter. */
function adm_village_match(string $village, array $allowed): string
{
    $norm = fn(string $s) => mb_strtolower(preg_replace('/\s+/', ' ', trim($s)));
    foreach ($allowed as $a) if ($norm($a) === $norm($village)) return $a;
    return '';
}
/** Is this village on the list? Always, when there is no list. */
function adm_village_allowed(string $village, array $allowed): bool
{
    return !$allowed || adm_village_match($village, $allowed) !== '';
}

<?php
/**
 * Returns the student_admit_cards row for a student+exam, creating one
 * (with a fresh random verification token) if it doesn't exist yet.
 * One card per student per exam — regenerating the page reuses the same
 * token/QR unless explicitly revoked.
 */
function ensure_admit_card($conn, $student_id, $exam_source, $exam_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM student_admit_cards WHERE student_id=? AND exam_source=? AND exam_id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "ssi", $student_id, $exam_source, $exam_id);
    mysqli_stmt_execute($stmt);
    $card = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if ($card) {
        return $card;
    }

    $token = bin2hex(random_bytes(32));
    $today = date('Y-m-d');
    $created_by = $_SESSION['admin_id'] ?? null;

    $stmt = mysqli_prepare($conn, "INSERT INTO student_admit_cards (student_id, exam_source, exam_id, verification_token, issued_date, created_by) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssissi", $student_id, $exam_source, $exam_id, $token, $today, $created_by);
    mysqli_stmt_execute($stmt);

    $stmt = mysqli_prepare($conn, "SELECT * FROM student_admit_cards WHERE student_id=? AND exam_source=? AND exam_id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "ssi", $student_id, $exam_source, $exam_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

/**
 * Fetches this student's exam_routine rows (subject/date/time/marks) plus
 * their seating assignment (room/seat) for a given V-X exam+class.
 * Returns ['routine' => [...], 'seat' => [...] or null].
 */
function get_admit_card_data($conn, $exam_source, $exam_id, $student_id, $class_id) {
    $routine = [];
    if ($exam_source === 'v-x') {
        $stmt = mysqli_prepare($conn, "
            SELECT r.exam_date, r.start_time, r.end_time, sub.subject_name,
                   es.shift_name, esm.written_full_marks AS full_marks
            FROM exam_routine r
            LEFT JOIN subjects sub ON r.subject_id = sub.id
            LEFT JOIN exam_shifts es ON es.id = r.shift_id
            LEFT JOIN exam_subject_marks esm ON esm.exam_id=r.exam_id AND esm.class_id=r.class_id AND esm.subject_id=r.subject_id
            WHERE r.exam_source='v-x' AND r.exam_id=? AND r.class_id=?
            ORDER BY r.exam_date ASC
        ");
        mysqli_stmt_bind_param($stmt, "ii", $exam_id, $class_id);
    } else {
        $stmt = mysqli_prepare($conn, "
            SELECT r.exam_date, r.start_time, r.end_time, sub.subject_name,
                   es.shift_name, hesm.theory_full_marks AS full_marks
            FROM exam_routine r
            LEFT JOIN subjects sub ON r.subject_id = sub.id
            LEFT JOIN exam_shifts es ON es.id = r.shift_id
            LEFT JOIN hs_exam_subject_marks hesm ON hesm.hs_exam_id=r.exam_id AND hesm.class_id=r.class_id AND hesm.subject_id=r.subject_id
            WHERE r.exam_source='hs' AND r.exam_id=? AND r.class_id=?
            ORDER BY r.exam_date ASC
        ");
        mysqli_stmt_bind_param($stmt, "ii", $exam_id, $class_id);
    }
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($res)) { $routine[] = $row; }

    $stmt = mysqli_prepare($conn, "
        SELECT sp.seat_no, rm.room_name, rm.location
        FROM exam_seating_plan sp
        LEFT JOIN exam_rooms rm ON rm.id = sp.room_id
        WHERE sp.exam_source=? AND sp.exam_id=? AND sp.student_id=?
        LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "sis", $exam_source, $exam_id, $student_id);
    mysqli_stmt_execute($stmt);
    $seat = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    return ['routine' => $routine, 'seat' => $seat];
}

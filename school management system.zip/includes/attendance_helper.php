<?php
/**
 * Student attendance — shared rules.
 *   One row per student per day (Present / Absent / Leave). No attendance on a Sunday or on
 *   any day in the holiday list (single-day holidays and start–end vacations alike), and none
 *   for a future date. Who took it is recorded (marked_by_type / marked_by / marked_at).
 */
require_once __DIR__ . '/db.php';

const ATTENDANCE_STATUSES = ['Present', 'Absent', 'Leave'];

/** Holidays that cover a date range, as [ 'Y-m-d' => name ] for every day in the range. */
function attendance_holiday_map(string $from, string $to): array {
    $map = [];
    $rows = db_get_all("SELECT holiday_name, holiday_date, start_date, end_date, is_long_vacation FROM holidays
        WHERE (holiday_date BETWEEN ? AND ?) OR (start_date IS NOT NULL AND end_date IS NOT NULL AND start_date <= ? AND end_date >= ?)", 'ssss', $from, $to, $to, $from);
    foreach ($rows as $h) {
        if ($h['start_date'] && $h['end_date'] && $h['end_date'] >= $h['start_date']) {
            for ($d = new DateTime($h['start_date']); $d <= new DateTime($h['end_date']); $d->modify('+1 day')) { $k = $d->format('Y-m-d'); if ($k >= $from && $k <= $to) $map[$k] = $h['holiday_name']; }
        } elseif ($h['holiday_date']) $map[$h['holiday_date']] = $h['holiday_name'];
    }
    return $map;
}

/** Why attendance cannot be taken on this date — '' when it is a working day. */
function attendance_day_block(string $date): string {
    $dt = DateTime::createFromFormat('Y-m-d', $date);
    if (!$dt || $dt->format('Y-m-d') !== $date) return 'Invalid date.';
    if ($date > date('Y-m-d')) return 'That date is in the future.';
    if ((int)$dt->format('N') === 7) return 'Sunday — weekly holiday.';
    $h = attendance_holiday_map($date, $date);
    if (isset($h[$date])) return 'Holiday: ' . $h[$date] . '.';
    return '';
}

/** Working days of a month = all days minus Sundays and holidays (up to today for the current month). */
function attendance_working_days(int $year, int $month): array {
    $days = (int)date('t', mktime(0, 0, 0, $month, 1, $year));
    $from = sprintf('%04d-%02d-01', $year, $month); $to = sprintf('%04d-%02d-%02d', $year, $month, $days);
    $hol = attendance_holiday_map($from, $to); $out = [];
    for ($i = 1; $i <= $days; $i++) {
        $d = sprintf('%04d-%02d-%02d', $year, $month, $i);
        $dow = (int)date('N', strtotime($d));
        $out[$d] = ['sunday' => $dow === 7, 'holiday' => $hol[$d] ?? null, 'future' => $d > date('Y-m-d'), 'working' => $dow !== 7 && !isset($hol[$d])];
    }
    return $out;
}

/** Active students of a section in a session, roll order. */
function attendance_section_students(int $session_id, int $class_id, int $section_id): array {
    return db_get_all("SELECT s.id, s.student_name, s.photo, s.gender, g.father_name, g.guardian_contact, s.mobile, h.roll_no
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.academic_status = 'Current'
        ORDER BY CAST(h.roll_no AS UNSIGNED), s.student_name", 'iii', $session_id, $class_id, $section_id);
}

/** Existing rows for one section-day keyed by student id. */
function attendance_existing(int $session_id, int $class_id, int $section_id, string $date): array {
    $out = [];
    foreach (db_get_all('SELECT * FROM student_attendance WHERE session_id = ? AND class_id = ? AND section_id = ? AND attendance_date = ?', 'iiis', $session_id, $class_id, $section_id, $date) as $r) $out[$r['student_id']] = $r;
    return $out;
}

/** "Taken by <name> at 10:32" for a section-day, or '' when not taken. */
function attendance_taken_by(array $existing): string {
    if (!$existing) return '';
    $first = reset($existing); $name = '';
    if ($first['marked_by_type'] === 'admin' && $first['marked_by']) $name = db_get_row('SELECT full_name, username FROM admins WHERE id = ?', 'i', (int)$first['marked_by']);
    elseif ($first['marked_by_type'] === 'staff' && $first['marked_by']) $name = db_get_row('SELECT staff_name AS full_name FROM staff WHERE id = ?', 'i', (int)$first['marked_by']);
    $who = $name ? ($name['full_name'] ?: ($name['username'] ?? 'admin')) : 'admin';
    $when = $first['updated_at'] ?: $first['marked_at'];
    return 'Taken by ' . $who . ' at ' . date('d-m-Y H:i', strtotime($when));
}

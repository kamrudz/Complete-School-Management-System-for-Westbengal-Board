<?php
/** Central session and admin authentication helper. */

if (!defined('APP_TIMEZONE_SET')) {
    date_default_timezone_set('Asia/Kolkata');
    define('APP_TIMEZONE_SET', true);
}

function schoolms_start_session() {
    if (session_status() === PHP_SESSION_ACTIVE) return;

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    ini_set('session.gc_maxlifetime', '7200');
    ini_set('session.use_strict_mode', '1');
    session_start();
}

schoolms_start_session();

define('SCHOOLMS_SESSION_TIMEOUT', 7200);

function schoolms_login_url() {
    $script = str_replace('\\', '/', $_SERVER['PHP_SELF'] ?? '');
    return (strpos($script, '/admin/') !== false) ? 'login.php' : 'admin/login.php';
}

function schoolms_destroy_session() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

if (!empty($_SESSION['admin_login'])) {
    $last = (int)($_SESSION['last_activity'] ?? 0);
    if ($last && (time() - $last) > SCHOOLMS_SESSION_TIMEOUT) {
        schoolms_destroy_session();
        header('Location: ' . schoolms_login_url() . '?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

function require_admin_login() {
    if (empty($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
        header('Location: ' . schoolms_login_url());
        exit;
    }
}

function redirect_if_logged_in() {
    if (!empty($_SESSION['admin_login']) && $_SESSION['admin_login'] === true) {
        header('Location: dashboard.php');
        exit;
    }
}

function secure_login($admin) {
    session_regenerate_id(true);
    $_SESSION['admin_login'] = true;
    $_SESSION['admin_id'] = (int)$admin['id'];
    $_SESSION['username'] = (string)$admin['username'];
    $_SESSION['admin_name'] = $admin['full_name'] ?? $admin['username'];
    $_SESSION['last_activity'] = time();
    $_SESSION['login_time'] = time();
    $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? '';
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
}

function verify_session_integrity() {
    return !empty($_SESSION['admin_login']) && $_SESSION['admin_login'] === true;
}

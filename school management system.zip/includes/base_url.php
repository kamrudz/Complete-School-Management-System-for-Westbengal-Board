<?php
/**
 * The site's public address, no trailing slash: School Settings' Site Base URL, else a guess from this request.
 * QR codes on printed cards carry it, so it must be set before cards are printed.
 */
function get_site_base_url($conn) {
    $row = db_get_row('SELECT site_base_url FROM school_settings WHERE id = 1');
    if (!empty($row['site_base_url'])) return rtrim($row['site_base_url'], '/');

    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = preg_replace('/[^A-Za-z0-9.:-]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    $root = preg_replace('#/admin$#', '', dirname($_SERVER['SCRIPT_NAME']));   // pages live in /admin/, the site one level up
    return $protocol . $host . $root;
}

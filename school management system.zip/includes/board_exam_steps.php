<?php
/**
 * The board-exam steps of the board page (includes/board_registration_page.php), for the exam class and one exam year:
 *   Madhyamik (Class X):  4 Sent up & form · 5 Admit · 6 Result
 *   HS (Class XII):       4 Sent up & form · 5 Sem 3 admit · 6 Sem 4 admit · 7 Result
 *   Sent up & form   who may sit — Madhyamik: the year's result of Class X (1st + 2nd + 3rd Summative; PASS or PUC);
 *                    HS: Class XI's year result (Semester 1 + 2; PASS). A tick can be changed by hand; re-appearing
 *                    (CC) candidates are added here; then the form fill-up sheet and slips for those sent up
 *   Admit            an admit's Roll and No., in Reg. No order: Continuation gives a fixed Roll and No.s one after
 *                    another; each row saves itself (assets/js/board_autosave.js); or by Excel. HS has one per semester.
 *   Result           PASS / FAIL / ABSENT / COMPARTMENT and % (HS: and each semester's marks); or by Excel; then Pass Out
 * The attempts live in the board's table (BOARD_EXAMS in includes/board_helper.php). $c is the page's context (board,
 * session, class, section, show, step, exam year, links, form helpers).
 */

/** What the exam steps show: the exam class of the list, the year's attempts of the list, and on step 4 the sent-up list. */
function board_exam_data(array $c): array {
    $board = $c['board'];
    $d = ['x' => board_students($board, $c['session_id'], $c['class_id'], $c['section_id'], $c['gender']),
          'rows' => board_exam_rows($board, $c['myear'], $c['class_id'], $c['section_id'], $c['gender'])];
    if ($c['step'] === 'sentup') {
        [$d['list'], $d['warnings']] = board_sentup_list($board, $c['session_id'], $c['class_id'], $c['section_id'], $c['gender'], $c['myear']);
        $d['cc'] = board_cc_candidates($board, $c['myear'], $d['list'], $c['gender']);
        // this session's exam class recorded for another exam year (a wrong year, changed later)
        $X = BOARD_EXAMS[$board];
        $d['other_years'] = !board_exam_ready($board) ? [] : array_column(db_get_all("SELECT e.exam_year, COUNT(*) AS n FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
            WHERE e.exam_year <> ? AND e.exam_year > ? AND r.student_id IN (SELECT h.student_id FROM student_academic_history h WHERE h.session_id = ? AND h.class_id = ?)
            GROUP BY e.exam_year ORDER BY e.exam_year", 'iiii', $c['myear'], $c['year'], $c['session_id'], $c['class_id']), 'n', 'exam_year');
    }
    return $d;
}

/** Is an admit of a row complete (both Roll and No.)? */
function board_admit_done(string $board, array $r, int $sem): bool {
    [, , $rc, $nc] = board_admit_cols($board, $sem);
    return trim((string)$r[$rc]) !== '' && trim((string)$r[$nc]) !== '';
}

/** The progress bars and the step hints of the exam steps: [bars, hints]. */
function board_exam_progress(array $c, array $d): array {
    $board = $c['board'];
    $X = BOARD_EXAMS[$board];
    $rows = $d['rows'];
    $n = count($rows);
    $sent = count(array_intersect_key($rows, $d['x']));
    $res = count(array_filter($rows, fn($r) => trim((string)$r['result_status']) !== ''));
    $pass = count(array_filter($rows, fn($r) => $r['result_status'] === 'PASS'));
    $togo = fn($done) => $n ? ($n - $done ? ($n - $done) . ' to go' : 'all done') : '';
    $bars = [board_bar("Sent up for {$X['exam']} {$c['myear']}", $sent, count($d['x']), '', $n > $sent ? '+ ' . ($n - $sent) . ' re-appearing (CC)' : '')];
    $hints = ['sentup' => [$sent ? "$sent sent up" : 'from the result', $sent > 0]];
    foreach (array_keys($X['admits']) as $sem) {
        $step = board_admit_step($sem);
        $done = count(array_filter($rows, fn($r) => board_admit_done($board, $r, $sem)));
        $bars[] = board_bar($sem ? "Sem $sem admit: Roll & No." : 'Admit: Roll & No.', $done, $n, $step);
        $hints[$step] = [$togo($done), $n > 0 && $done === $n];
    }
    $bars[] = board_bar('Result', $res, $n, 'result', $res ? "PASS $pass of $res" : '');
    $hints['result'] = [$togo($res), $n > 0 && $res === $n];
    return [$bars, $hints];
}

/**
 * An uploaded admit sheet (one semester's, for HS) against the list's attempts: one line per sheet row — new,
 * changed, same, blank (left as it is), error (why) or outside. Matched on the School UID, else the Reg. No. The
 * Roll + No.s are checked as they will stand after the save, so two students swapping numbers is fine and a number
 * given twice is not.
 */
function board_admit_plan(string $board, array $rows, array $sheet, int $myear, int $sem): array {
    $X = BOARD_EXAMS[$board];
    [$rh, $nh, $rc, $nc] = board_admit_cols($board, $sem);
    $rh = strtolower($rh); $nh = strtolower($nh);
    $by_reg = []; $final = []; $names = [];
    foreach ($rows as $uid => $r) {
        $by_reg[strtoupper((string)$r['registration_no'])] = $uid;
        $final[$uid] = [(string)$r[$rc], (string)$r[$nc]];
        $names[$uid] = $r['student_name'];
    }
    $plan = [];
    foreach ($sheet as $s) {
        $uid = student_uid_clean($s['school uid'] ?? '');
        if (!isset($rows[$uid])) $uid = $by_reg[board_regno_clean($s['reg. no'] ?? '')] ?? '';
        if ($uid === '') { $plan[] = ['status' => 'outside', 'uid' => (string)($s['school uid'] ?? ''), 'name' => (string)($s['student name'] ?? ''), 'why' => "Not sent up for {$X['exam']} $myear, or not in this list."]; continue; }
        $r = $rows[$uid];
        $roll = board_roll_clean($s[$rh] ?? '');
        $no = board_no_clean($s[$nh] ?? '');
        $line = ['uid' => $uid, 'name' => $r['student_name'], 'rid' => (int)$r['rid'], 'old' => trim($r[$rc] . ' ' . $r[$nc]), 'roll' => $roll, 'no' => $no, 'new' => trim("$roll $no")];
        if ($roll === '' && $no === '') { $plan[] = $line + ['status' => 'blank', 'why' => '']; continue; }
        $why = board_admit_error($roll, $no);
        if (!$why) $final[$uid] = [$roll, $no];
        $same = (string)$r[$rc] === $roll && (string)$r[$nc] === $no;
        $plan[] = $line + ['status' => $why ? 'error' : ($same ? 'same' : ($line['old'] === '' ? 'new' : 'changed')), 'why' => $why];
    }
    // who will hold each Roll + No.: this list as it will stand, the year's other attempts as they are
    $key = fn($roll, $no) => $roll !== '' && $no !== '' ? strtoupper($roll) . '#' . ltrim($no, '0') : '';
    $holders = [];
    foreach ($final as $uid => [$roll, $no]) if ($k = $key($roll, $no)) $holders[$k][] = $uid;
    $others = !board_exam_ready($board) ? [] : db_get_all("SELECT r.student_id, s.student_name, e.$rc AS roll, e.$nc AS no FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
            JOIN students s ON s.id = r.student_id WHERE e.exam_year = ? AND e.$rc <> '' AND e.$nc <> ''", 'i', $myear);
    foreach ($others as $o) {
        if (isset($rows[$o['student_id']])) continue;
        $names[$o['student_id']] = $o['student_name'];
        if ($k = $key($o['roll'], $o['no'])) $holders[$k][] = $o['student_id'];
    }
    foreach ($plan as &$l) {
        if (!in_array($l['status'], ['new', 'changed'], true)) continue;
        $others = array_values(array_diff($holders[$key($l['roll'], $l['no'])] ?? [], [$l['uid']]));
        if ($others) { $l['status'] = 'error'; $l['why'] = "Roll {$l['roll']} No. {$l['no']} would also be {$names[$others[0]]}'s ({$others[0]})."; }
    }
    unset($l);
    return $plan;
}

/**
 * An uploaded result sheet against the list's attempts. Matched on an admit's Roll + No. (as the board's result list
 * has them; HS: Semester 4's, then Semester 3's), else the School UID, else the Reg. No. Result words may be short
 * (P, F, AB …); HS rows also carry each semester's marks.
 */
function board_result_plan(string $board, array $rows, array $sheet, int $myear): array {
    $X = BOARD_EXAMS[$board];
    $admits = array_reverse(array_keys($X['admits']));   // the last admit first
    $by_admit = []; $by_reg = [];
    foreach ($rows as $uid => $r) {
        foreach ($admits as $sem) {
            [, , $rc, $nc] = board_admit_cols($board, $sem);
            if (trim((string)$r[$rc]) !== '' && trim((string)$r[$nc]) !== '') $by_admit[$sem][strtoupper($r[$rc]) . '#' . ltrim($r[$nc], '0')] = $uid;
        }
        $by_reg[strtoupper((string)$r['registration_no'])] = $uid;
    }
    $marks_now = fn($r) => implode(' · ', array_filter(array_map(fn($m) => $r[$m[1]] !== null ? "Sem " . substr($m[1], 3, 1) . ' ' . board_pct($r[$m[1]]) : '', $X['marks'])));
    $plan = [];
    foreach ($sheet as $s) {
        $uid = '';
        foreach ($admits as $sem) {
            [$rh, $nh] = board_admit_cols($board, $sem);
            $roll = board_roll_clean($s[strtolower($rh)] ?? ''); $no = board_no_clean($s[strtolower($nh)] ?? '');
            if ($roll !== '' && $no !== '' && ($uid = $by_admit[$sem][$roll . '#' . ltrim($no, '0')] ?? '') !== '') break;
        }
        if ($uid === '') { $u = student_uid_clean($s['school uid'] ?? ''); $uid = isset($rows[$u]) ? $u : ($by_reg[board_regno_clean($s['reg. no'] ?? '')] ?? ''); }
        if ($uid === '') { $plan[] = ['status' => 'outside', 'uid' => (string)($s['school uid'] ?? ''), 'name' => (string)($s['student name'] ?? ''), 'why' => "Not sent up for {$X['exam']} $myear, or not in this list."]; continue; }
        $r = $rows[$uid];
        $raw = trim((string)($s['result'] ?? ''));
        $status = board_result_word($raw);
        $pct = $status === 'ABSENT' ? '' : trim(board_cell($s['%'] ?? ''));
        $marks = []; $why = '';
        foreach ($X['marks'] as $sem => [$head, $col]) {
            $m = trim(board_cell($s[strtolower($head)] ?? ''));
            if ($m === '') continue;
            $marks[$sem] = $m;
            if ($e = board_marks_error($m)) $why = "Sem $sem " . lcfirst($e);
        }
        $old = trim(($r['result_status'] ?? '') . ($r['percentage'] !== null && $r['result_status'] !== null ? ' ' . board_pct($r['percentage']) . '%' : '') . ($X['marks'] ? ' ' . $marks_now($r) : ''));
        $new = trim(($status !== '' ? $status : $raw) . ($pct !== '' ? " $pct%" : '') . ($marks ? ' ' . implode(' · ', array_map(fn($sem, $m) => "Sem $sem $m", array_keys($marks), $marks)) : ''));
        $line = ['uid' => $uid, 'name' => $r['student_name'], 'rid' => (int)$r['rid'], 'old' => $old, 'result' => $status, 'pct' => $pct, 'marks' => $marks, 'new' => $new];
        if ($raw === '' && !$marks) { $plan[] = $line + ['status' => 'blank', 'why' => '']; continue; }
        if ($raw !== '' && $status === '') $why = 'Result: PASS, FAIL, ABSENT or COMPARTMENT.';
        $why = $why ?: board_result_error($status, $pct);
        if ($raw === '') { $line['result'] = (string)$r['result_status']; $line['pct'] = board_pct($r['percentage']); }   // marks only: the result stays
        $same = (string)$r['result_status'] === $line['result'] && board_pct($r['percentage']) === board_pct($line['pct'] === '' ? null : $line['pct']);
        foreach ($marks as $sem => $m) if (board_pct($r[$X['marks'][$sem][1]]) !== board_pct($m)) $same = false;
        $was_empty = trim((string)$r['result_status']) === '' && !array_filter($X['marks'], fn($mm) => $r[$mm[1]] !== null);
        $plan[] = $line + ['status' => $why ? 'error' : ($same ? 'same' : ($was_empty ? 'new' : 'changed')), 'why' => $why];
    }
    return $plan;
}

/** The exam steps' own forms: the sent-up list, an exam year moved, a sheet saved from its preview. */
function board_exam_post(array $c): void {
    $board = $c['board'];
    $X = BOARD_EXAMS[$board];
    $myear = $c['myear'];
    $back = ($c['url'])();
    if (isset($_POST['save_sentup'])) {
        [$list] = board_sentup_list($board, $c['session_id'], $c['class_id'], $c['section_id'], $c['gender'], $myear);
        $picked = fn(string $k) => array_flip(array_filter(array_map('student_uid_clean', (array)($_POST[$k] ?? []))));
        [$a1, $r1, $p1] = board_save_sentup($board, $list, $picked('sent'), $myear);
        [$a2, $r2, $p2] = board_save_sentup($board, board_cc_candidates($board, $myear, $list, $c['gender']), $picked('cc'), $myear);
        $_SESSION['success'] = "{$X['exam']} $myear: " . ($a1 + $a2) . ' student(s) sent up, ' . ($r1 + $r2) . ' taken back.';
        if ($p = array_merge($p1, $p2)) $_SESSION['error'] = count($p) . ' not changed — ' . implode(' · ', array_slice($p, 0, 5)) . (count($p) > 5 ? ' …' : '');
        board_go($back);
    }
    if (isset($_POST['move_year'])) {
        $from = (int)($_POST['from_year'] ?? 0);
        if (board_exam_ready($board) && board_exam_year_ok($from) && $from !== $myear) {
            // only attempts with nothing on them yet, and never a second attempt in the same year
            $ids = [];
            foreach (db_get_all("SELECT e.* FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
                WHERE e.exam_year = ? AND r.student_id IN (SELECT h.student_id FROM student_academic_history h WHERE h.session_id = ? AND h.class_id = ?)
                  AND NOT EXISTS (SELECT 1 FROM {$X['table']} t WHERE t.registration_id = e.registration_id AND t.exam_year = ?)",
                'iiii', $from, $c['session_id'], $c['class_id'], $myear) as $row) if (!board_exam_has_content($board, $row)) $ids[] = (int)$row['id'];
            foreach ($ids as $id) db_execute("UPDATE {$X['table']} SET exam_year = ? WHERE id = ?", 'ii', $myear, $id);
            if (function_exists('log_action') && $ids) log_action((int)($_SESSION['admin_id'] ?? 0), 'BOARD_YEAR_MOVED', $X['table'], null, ['year' => $from], ['year' => $myear, 'attempts' => count($ids)]);
            $_SESSION['success'] = count($ids) . " sent-up student(s) moved from {$X['exam']} $from to $myear.";
        }
        board_go($back);
    }
    $kind = $c['step'];
    if (isset($_POST['confirm_admit']) || isset($_POST['confirm_result'])) {
        $p = board_pending($board, $kind, $c['ctx']);
        if (!$p) { $_SESSION['error'] = 'That upload is gone — upload the sheet again.'; board_go($back); }
        try { $sheet = board_sheet_rows($p['path']); } catch (Throwable $e) { $_SESSION['error'] = 'Could not read the file: ' . $e->getMessage(); board_drop_upload(); board_go($back); }
        $rows = board_exam_rows($board, $myear, $c['class_id'], $c['section_id'], $c['gender']);
        $sem = board_step_sem($kind);
        $plan = $sem !== null ? board_admit_plan($board, $rows, $sheet, $myear, $sem) : board_result_plan($board, $rows, $sheet, $myear);
        $todo = array_filter($plan, fn($l) => in_array($l['status'], ['new', 'changed'], true));
        $saved = 0; $bad = [];
        if ($sem !== null) {
            [, , $rc, $nc] = board_admit_cols($board, $sem);
            db_begin_transaction();
            try {
                foreach ($todo as $l) db_update($X['table'], [$rc => null, $nc => null], ['id' => $l['rid']], 'i');   // freed first, so two may swap
                foreach ($todo as $l) {
                    $r = board_save_admit($board, $l['rid'], $myear, $sem, $l['roll'], $l['no']);
                    if (!$r['ok']) throw new RuntimeException("{$l['name']}: {$r['error']}");
                    $saved++;
                }
                db_commit();
            } catch (Throwable $e) { db_rollback(); $saved = 0; $bad[] = $e->getMessage() . ' — nothing from the sheet was saved.'; }
        } else {
            foreach ($todo as $l) {
                $r = board_save_result($board, $l['rid'], $myear, $l['result'], $l['pct'], $l['marks']);
                if ($r['ok']) $saved++; else $bad[] = "{$l['name']}: {$r['error']}";
            }
        }
        board_drop_upload();
        $_SESSION['success'] = $saved . ($sem !== null ? ' Roll / No.(s)' : ' result(s)') . ' saved from the sheet.';
        if ($bad) $_SESSION['error'] = implode(' · ', array_slice($bad, 0, 5)) . (count($bad) > 5 ? ' …' : '');
        board_go($back);
    }
}

/** The exam steps' Excel sheets: form fill-up, an admit (Roll / No.), the result. */
function board_exam_download(array $c, string $kind): void {
    $board = $c['board'];
    $X = BOARD_EXAMS[$board];
    $myear = $c['myear'];
    $exam = "{$X['exam']} $myear";
    $rows = board_exam_rows($board, $myear, $c['class_id'], $c['section_id'], $c['gender']);
    if ($kind === 'form') {
        $sent = array_intersect_key(board_students($board, $c['session_id'], $c['class_id'], $c['section_id'], $c['gender']), $rows);
        if (!$sent) return;
        $head = ['SL', 'School UID', 'Student Name', 'Father Name', 'Mother Name', 'Date of Birth', 'Gender', 'Religion', 'Caste', 'Nationality', 'Aadhaar', 'Mobile',
                 'Village / Town', 'Post Office', 'Police Station', 'District', 'State', 'PIN Code', 'Banglar Shiksha ID', 'Section', 'Roll'];
        if ($board === 'wbchse') array_push($head, 'Madhyamik Board', 'Madhyamik Year', 'Madhyamik Roll', 'HS Subjects');
        array_push($head, 'Reg. No', 'Reg. Year', "{$X['exam']} Year", 'Still missing');
        $out = exam_xlsx_title("$exam — form fill-up · {$c['where']}", 'The students sent up, with every detail the form asks for. Re-appearing (CC) candidates are not in this sheet.');
        $out[] = $head;
        $n = 0;
        foreach ($sent as $uid => $st) {
            $row = [++$n, (string)$uid, $st['student_name'], $st['father_name'], $st['mother_name'], board_date($st['dob']), $st['gender'], $st['religion'], $st['caste'], $st['nationality'],
                    $st['student_aadhaar'], board_mobile($st), $st['village'], $st['post_office'], $st['police_station'], $st['district'], $st['state'], $st['pin_code'],
                    $st['banglarshiksha_id'], $st['section_name'], $st['roll_no']];
            if ($board === 'wbchse') array_push($row, $st['mp_board'], $st['mp_year'], $st['mp_roll_no'], $st['subject_names']);
            array_push($row, $st['registration_no'], $st['registration_year'], $myear, implode(', ', array_map(fn($m) => $m[0], board_missing($st, $board))));
            $out[] = array_map(fn($v) => is_int($v) ? $v : trim((string)$v), $row);
        }
        SimpleXLSXWriter::download("{$c['file_where']}_form_fill_up.xlsx", $out, 'Form fill-up', exam_xlsx_opts(count($head), 24));
    }
    $sem = board_step_sem($kind);
    if ($sem !== null && isset($X['admits'][$sem]) && $rows) {
        [$rh, $nh, $rc, $nc] = board_admit_cols($board, $sem);
        $what = $sem ? "Semester $sem admit" : 'admit';
        $out = exam_xlsx_title("$exam — $what Roll and No. · {$c['where']}", "Type the Roll and No. from the $what cards, then upload this file on its step. Blank Roll and No. are left as they are.");
        $out[] = ['School UID', 'Student Name', 'Gender', 'Section', 'Reg. No', 'Type', $rh, $nh];
        foreach ($rows as $uid => $r) {
            $out[] = [(string)$uid, (string)$r['student_name'], (string)$r['gender'], (string)$r['section_name'], (string)$r['registration_no'], $r['cc'] ? 'CC' : 'Regular', (string)$r[$rc], (string)$r[$nc]];
        }
        SimpleXLSXWriter::download("{$c['file_where']}_" . ($sem ? "sem{$sem}_" : '') . 'admit.xlsx', $out, 'Admit', exam_xlsx_opts(8, 24) + ['protect' => true, 'unlocked_cols' => [7, 8]]);
    }
    if ($kind === 'result' && $rows) {
        $head = ['School UID', 'Student Name', 'Reg. No'];
        foreach (array_keys($X['admits']) as $s) { [$rh, $nh] = board_admit_cols($board, $s); array_push($head, $rh, $nh); }
        $first = count($head) + 1;
        foreach ($X['marks'] as [$mh]) $head[] = $mh;
        array_push($head, 'Result', '%');
        $out = exam_xlsx_title("$exam — result · {$c['where']}", 'Result: PASS, FAIL, ABSENT or COMPARTMENT; % is optional' . ($X['marks'] ? '; each semester\'s marks as the board gives them' : '') . '. Rows are matched on Roll + No., then School UID.');
        $out[] = $head;
        foreach ($rows as $uid => $r) {
            $row = [(string)$uid, (string)$r['student_name'], (string)$r['registration_no']];
            foreach (array_keys($X['admits']) as $s) { [, , $rc, $nc] = board_admit_cols($board, $s); array_push($row, (string)$r[$rc], (string)$r[$nc]); }
            foreach ($X['marks'] as [, $mc]) $row[] = board_pct($r[$mc]);
            array_push($row, (string)$r['result_status'], board_pct($r['percentage']));
            $out[] = $row;
        }
        SimpleXLSXWriter::download("{$c['file_where']}_result.xlsx", $out, 'Result', exam_xlsx_opts(count($head), 24) + ['protect' => true, 'unlocked_cols' => range($first, count($head))]);
    }
}

/** The exam step on screen. */
function board_exam_view(array $c): void {
    $d = $c['data'];
    $X = BOARD_EXAMS[$c['board']];
    if ($c['step'] === 'sentup') { board_view_sentup($c, $d); return; }
    if (!$d['rows']) {
        exam_guard("Nobody here is sent up for {$X['exam']} {$c['myear']} yet", ' Tick the students on step 4 and save the list first.', ($c['link'])('sentup'), 'Sent up & form');
        return;
    }
    if ($c['pending']) { board_view_exam_preview($c, $d); return; }
    $sem = board_step_sem($c['step']);
    $sem !== null ? board_view_admit($c, $d, $sem) : board_view_result($c, $d);
}

/** A chip for a result (PASS, PUC, FAIL, ABSENT or none yet). */
function board_result_chip(string $status, $pct): string {
    $cls = ['PASS' => 'ok', 'PUC' => 'warn', 'FAIL' => 'bad', 'COMPARTMENT' => 'warn'][$status] ?? 'off';
    $label = $status === '' ? 'no result' : $status;
    return '<span class="chip ' . $cls . '" title="' . h($status === 'PUC' ? 'Promoted Under Consideration' : $label) . '">' . h($label) . '</span>'
         . ($pct !== null && $pct !== '' && in_array($status, ['PASS', 'PUC', 'FAIL', 'COMPARTMENT'], true) ? ' <small class="dim">' . h(board_pct($pct)) . '%</small>' : '');
}

function board_view_sentup(array $c, array $d): void {
    $board = $c['board'];
    $X = BOARD_EXAMS[$board];
    $list = $d['list']; $cc = $d['cc']; $myear = $c['myear']; $link = $c['link'];
    $class = 'Class ' . board_classes($board)[$c['class_id']];
    $hs = $X['sentup'] === 'xi';
    if (!$list && !$cc) { echo '<div class="ex-empty"><i class="fas fa-user-slash"></i>No Active students in ' . h($c['where']) . '.</div>'; return; }
    $reg_x = $link('regno', ['class_id' => $c['class_id'], 'section_id' => $c['section_id'] ?: null]);
    $no_reg = count(array_filter($list, fn($s) => !$s['reg_id']));
    // a lot (boys or girls of a section) is decided once any of it is sent up: from then on its ticks are what was
    // saved; a lot not saved yet shows what the result says
    $decided = [];
    foreach ($list as $s) if ($s['exam']) $decided[$s['gender'] . '|' . $s['section_id']] = true;
    $is_decided = fn($s) => isset($decided[$s['gender'] . '|' . $s['section_id']]);
    $undecided = count(array_filter($list, fn($s) => !$is_decided($s)));
    $has_result = (bool)array_filter($list, fn($s) => in_array($s['result'], ['PASS', 'PUC', 'FAIL'], true));
    $sent = count(array_filter($list, fn($s) => $s['exam']));
    $ticked = fn($s) => $is_decided($s) ? (bool)$s['exam'] : ($s['suggest'] && $s['reg_id']);
    $by_hand = fn($s) => $is_decided($s) && (bool)$s['exam'] !== $s['suggest'];
    $sends = $hs ? 'PASS' : 'PASS or PUC';
    if ($list && $no_reg === count($list)) {
        exam_guard('No Reg. No yet', " None of $class here has a registration number in the system, so nobody can be sent up. Enter them first — for $class, by hand or by Excel.", $reg_x, "Reg. No — $class");
    } elseif ($no_reg) {
        exam_guard("$no_reg without a Reg. No", ' They cannot be sent up until their registration number is entered.', $reg_x, "Reg. No — $class");
    }
    if ($d['warnings'] || !$has_result) {
        [$href, $label] = $hs ? ['hs_tabulation.php', 'HS Tabulation'] : ['annual_result.php?' . http_build_query(['session_id' => $c['session_id'], 'class_id' => $c['class_id']]), 'Annual Result'];
        exam_guard($hs ? 'The Class XI result is not complete' : "The $class result is not complete", ' ' . ($d['warnings'] ? implode('; ', $d['warnings']) . '.' : 'No marks yet.') . ' A tick follows the result only as far as it goes — tick by hand where needed' . ($hs ? '.' : ', or finish the marks first.'), $href, $label);
    }
    foreach ($d['other_years'] as $y => $n): ?>
        <div class="ex-guard"><i class="fas fa-calendar-alt big"></i><div><b><?php echo (int)$n; ?> of this <?php echo h($class); ?> are sent up for <?php echo h($X['exam']); ?> <?php echo (int)$y; ?></b>
            <a href="<?php echo h($link('sentup', ['myear' => (int)$y])); ?>">Show <?php echo (int)$y; ?></a> ·
            <form method="post" style="display:inline"><?php echo ($c['hidden'])(['from_year' => (int)$y]); ?><button type="submit" name="move_year" value="1" class="btn btn-sm btn-secondary" onclick="return confirm('Move them to <?php echo h($X['exam']); ?> <?php echo $myear; ?>? (Ones that already have a Roll, No., marks or result stay.)')">Move them to <?php echo $myear; ?></button></form></div></div>
    <?php endforeach; ?>
    <?php if ($undecided): ?><p class="note" style="margin:0 0 10px"><i class="fas fa-info-circle"></i> <?php echo $undecided === count($list) ? 'Not saved yet' : "$undecided not saved yet"; ?> — their ticks follow <?php echo $hs ? 'the Class XI result' : "the year's result"; ?> (<?php echo $sends; ?>). Check them, change any by hand, and press <b>Save sent-up list</b>.</p><?php endif; ?>
    <form method="post" id="sf">
        <?php echo ($c['hidden'])(); ?>
        <div class="card">
            <div class="tools noprint">
                <input type="search" id="q" placeholder="Search name, School UID or Reg. No">
                <span class="shown" id="shown"></span>
                <button type="button" class="btn btn-sm btn-secondary" data-tick="result" title="<?php echo $sends; ?> ticked, the rest not">Tick as the result says</button>
                <button type="button" class="btn btn-sm btn-secondary" data-tick="all">Tick all</button>
                <button type="button" class="btn btn-sm btn-secondary" data-tick="none">Untick all</button>
                <span class="right"><span class="sv-sum" id="sfSum"></span><button type="submit" name="save_sentup" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save sent-up list</button></span>
            </div>
            <div class="table-responsive"><table class="ex-table" id="list">
                <thead><tr><th class="tk"></th><th class="num">#</th><th>Student</th><th>Section · Roll</th><th>Reg. No</th><th><?php echo $hs ? 'Class XI result' : "Year's result"; ?></th><th>Form data</th></tr></thead>
                <tbody>
                <?php $n = 0; foreach ($list as $uid => $st): $m = board_missing($st, $board); $on = $ticked($st); $no = trim((string)$st['registration_no']); ?>
                    <tr data-s="<?php echo h(mb_strtolower($st['student_name'] . ' ' . $uid . ' ' . $no)); ?>" data-done="<?php echo $st['exam'] ? 1 : 0; ?>" data-suggest="<?php echo $st['suggest'] ? 1 : 0; ?>" data-orig="<?php echo $st['exam'] ? 1 : 0; ?>">
                        <td class="tk"><input type="checkbox" name="sent[]" value="<?php echo h($uid); ?>"<?php echo $on ? ' checked' : ''; ?><?php echo $st['reg_id'] ? '' : ' disabled'; ?> aria-label="Send up <?php echo h($st['student_name']); ?>"></td>
                        <td class="num"><?php echo ++$n; ?></td>
                        <td><?php echo board_student_cell($st); ?></td>
                        <td><?php echo h(($st['section_name'] ?? '—') . ' · ' . ($st['roll_no'] ?? '—')); ?></td>
                        <td><?php echo $no !== '' ? h($no) : '<span class="chip bad">no Reg. No</span>'; ?></td>
                        <td><?php echo board_result_chip($st['result'], $st['result_pct']); ?><?php if ($by_hand($st)): ?> <span class="chip hand" title="<?php echo $st['exam'] ? 'Sent up although the result does not' : 'Held back although the result sends up'; ?>">by hand</span><?php endif; ?></td>
                        <td><?php if (!$m): ?><span class="chip ok">Ready</span><?php else: ?><a class="chip warn fix" target="_blank" href="<?php echo h($link('check', ['class_id' => $c['class_id']])); ?>" title="<?php echo h(implode(', ', array_map(fn($x) => $x[0], $m))); ?>"><?php echo count($m); ?> missing</a><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
            <?php if ($cc): ?>
            <h3 class="sub"><i class="fas fa-redo"></i> Re-appearing (CC) candidates <small class="dim">— did not pass an earlier <?php echo h($X['exam']); ?>; tick to send them up for <?php echo $myear; ?></small></h3>
            <div class="table-responsive"><table class="ex-table">
                <thead><tr><th class="tk"></th><th>Student</th><th>Reg. No</th><th>Last attempt</th></tr></thead>
                <tbody>
                <?php foreach ($cc as $uid => $st): ?>
                    <tr data-orig="<?php echo $st['exam'] ? 1 : 0; ?>">
                        <td class="tk"><input type="checkbox" name="cc[]" value="<?php echo h($uid); ?>"<?php echo $st['exam'] ? ' checked' : ''; ?>></td>
                        <td><?php echo board_student_cell($st); ?></td>
                        <td><?php echo h($st['registration_no']); ?></td>
                        <td><?php echo h($X['exam']); ?> <?php echo (int)$st['last_year']; ?> · <?php echo board_result_chip((string)$st['last_result'], null); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
            <?php endif; ?>
        </div>
    </form>
    <div class="acts">
        <div class="act">
            <h3><i class="fas fa-file-excel"></i> Form fill-up sheet</h3>
            <p>Everyone sent up, with every detail the board's form asks for, the Reg. No and the <?php echo h($X['exam']); ?> year — and what is still missing.</p>
            <div class="btns"><?php if ($sent): ?><a class="btn btn-success" href="<?php echo h(($c['url'])(['download' => 'form'])); ?>"><i class="fas fa-file-excel"></i> Download (<?php echo $sent; ?>)</a><?php else: ?><span class="dim">Save the sent-up list first.</span><?php endif; ?></div>
        </div>
        <div class="act">
            <h3><i class="fas fa-print"></i> Verification slips</h3>
            <p>One A4 page per student sent up, for the guardian to check and sign before the form fill-up.</p>
            <div class="btns"><?php if ($sent): ?><a class="btn btn-primary" target="_blank" href="<?php echo h(($c['print'])('slips', ['scope' => 'sentup', 'myear' => $myear])); ?>"><i class="fas fa-print"></i> Print slips (<?php echo $sent; ?>)</a><?php else: ?><span class="dim">Save the sent-up list first.</span><?php endif; ?></div>
        </div>
    </div>
    <script>
    (function () {   // the ticks: as the result says, all, none; what is not saved yet is counted, and leaving asks first
        var form = document.getElementById('sf'); if (!form) return;
        var boxes = Array.prototype.slice.call(form.querySelectorAll('input[type=checkbox]:not(:disabled)'));
        var sum = document.getElementById('sfSum'), dirty = false;
        function count() {
            var n = boxes.filter(function (b) { return b.checked; }).length;
            var changed = boxes.filter(function (b) { return b.checked !== (b.closest('tr').dataset.orig === '1'); }).length;
            sum.textContent = n + ' ticked' + (changed ? ' · ' + changed + ' change(s) not saved' : ' · saved');
            sum.className = 'sv-sum ' + (changed ? 'sv-left' : 'sv-ok');
            dirty = changed > 0;
        }
        Array.prototype.forEach.call(form.querySelectorAll('[data-tick]'), function (btn) {
            btn.addEventListener('click', function () {
                boxes.forEach(function (b) {
                    var tr = b.closest('tr');
                    if (b.name !== 'sent[]' || tr.style.display === 'none') return;   // only the rows the search shows
                    b.checked = btn.dataset.tick === 'all' ? true : btn.dataset.tick === 'none' ? false : tr.dataset.suggest === '1';
                });
                count();
            });
        });
        boxes.forEach(function (b) { b.addEventListener('change', count); });
        form.addEventListener('submit', function () { dirty = false; });
        window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
        count();
    })();
    </script>
<?php }

/** The search / "only not done" / type tools of the admit and result steps. */
function board_exam_tools(array $c, array $rows, int $done, string $kind, string $extra = ''): void {
    $cc = count(array_filter($rows, fn($r) => (int)$r['cc'] === 1)); ?>
    <div class="tools noprint">
        <input type="search" id="q" placeholder="Search name, UID, Reg. No or Roll">
        <label class="tog"><input type="checkbox" id="only"<?php echo $done < count($rows) ? ' checked' : ''; ?>> Only not done</label>
        <?php if ($cc): ?><select id="tp" aria-label="Regular or CC"><option value="">Regular and CC</option><option value="regular">Regular (<?php echo count($rows) - $cc; ?>)</option><option value="cc">CC (<?php echo $cc; ?>)</option></select><?php endif; ?>
        <span class="shown" id="shown"></span>
        <span class="sv-sum" id="svSum"></span>
        <span class="right">
            <?php echo $extra; ?>
            <a class="btn btn-sm btn-success" href="<?php echo h(($c['url'])(['download' => $kind])); ?>"><i class="fas fa-file-excel"></i> Download sheet</a>
            <?php ($c['upload_form'])($kind, 'Upload filled sheet'); ?>
        </span>
    </div>
<?php }

function board_view_admit(array $c, array $d, int $sem): void {
    $board = $c['board'];
    $rows = $d['rows'];
    [, , $rc, $nc] = board_admit_cols($board, $sem);
    $step = board_admit_step($sem);
    $done = count(array_filter($rows, fn($r) => board_admit_done($board, $r, $sem)));
    board_exam_tools($c, $rows, $done, $step, '<a class="btn btn-sm btn-secondary" target="_blank" href="' . h(($c['print'])('admit', ['myear' => $c['myear'], 'sem' => $sem ?: null])) . '"><i class="fas fa-print"></i> Print admit register</a>'); ?>
    <?php if ($sem): ?><p class="note" style="margin:0 0 10px"><i class="fas fa-info-circle"></i> The Semester <?php echo $sem; ?> admit has its own Roll and No. — they are kept apart from Semester <?php echo $sem === 3 ? 4 : 3; ?>'s.</p><?php endif; ?>
    <div class="cont noprint" id="cont" data-used="<?php echo h(json_encode((object)board_used_nos($board, $c['myear'], $sem))); ?>">
        <b><i class="fas fa-sort-numeric-down"></i> Continuation</b>
        <label>Roll <input id="cRoll" maxlength="15" autocomplete="off" placeholder="1610N"></label>
        <label>First No. <input id="cFirst" maxlength="6" inputmode="numeric" autocomplete="off"></label>
        <button type="button" class="btn btn-sm btn-primary" id="cFill" disabled>Fill</button>
        <small id="cInfo">In Reg. No order, small to large: the Roll stays the same and the No. goes up by one — only for the rows shown that have no No. yet. Pick Show: Boys or Girls (and Regular or CC — their Roll is different) first.</small>
    </div>
    <form id="rf" data-kind="admit" data-bar="<?php echo $step; ?>" onsubmit="return false">
        <?php echo ($c['hidden'])(); ?>
        <div class="table-responsive"><table class="ex-table" id="list">
            <thead><tr><th class="num">#</th><th>Student</th><th>Reg. No</th><th>Section · Roll</th><th><?php echo $sem ? "Sem $sem " : ''; ?>Roll</th><th><?php echo $sem ? "Sem $sem " : ''; ?>No.</th><th></th></tr></thead>
            <tbody>
            <?php $n = 0; foreach ($rows as $uid => $r): $roll = (string)$r[$rc]; $no = (string)$r[$nc]; $base = mb_strtolower($r['student_name'] . ' ' . $uid . ' ' . $r['registration_no']); ?>
                <tr data-uid="<?php echo h($uid); ?>" data-rid="<?php echo (int)$r['rid']; ?>" data-cc="<?php echo (int)$r['cc']; ?>" data-b="<?php echo h($base); ?>" data-s="<?php echo h($base . ' ' . mb_strtolower("$roll $no")); ?>"
                    data-done="<?php echo $roll !== '' && $no !== '' ? 1 : 0; ?>" data-saved="<?php echo h(json_encode(['roll' => $roll, 'no' => $no])); ?>">
                    <td class="num"><?php echo ++$n; ?></td>
                    <td><?php echo board_student_cell($r); ?><?php if ($r['cc']): ?> <span class="chip warn" title="Re-appearing: their Roll is different">CC</span><?php endif; ?></td>
                    <td><?php echo h($r['registration_no']); ?></td>
                    <td><?php echo h(($r['section_name'] ?? '—') . ' · ' . ($r['class_roll'] ?? '—')); ?></td>
                    <td><input type="text" class="bx rl" data-f="roll" value="<?php echo h($roll); ?>" maxlength="15" autocomplete="off" aria-label="Roll of <?php echo h($r['student_name']); ?>"></td>
                    <td><input type="text" class="bx no" data-f="no" value="<?php echo h($no); ?>" maxlength="6" inputmode="numeric" autocomplete="off" aria-label="No."></td>
                    <td class="sv"></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </form>
    <div class="ex-empty" id="none" hidden><i class="fas fa-check-circle"></i>Every student here has a Roll and No.</div>
    <script>
    (function () {   // Continuation: a fixed Roll and No.s one after another, down the rows shown that have no No. yet
        var bar = document.getElementById('cont'), form = document.getElementById('rf');
        if (!bar || !form) return;
        var used = JSON.parse(bar.dataset.used || '{}');   // Roll => {No.: uid} — the whole year, saved
        var rollIn = document.getElementById('cRoll'), firstIn = document.getElementById('cFirst'), btn = document.getElementById('cFill');
        var rows = Array.prototype.slice.call(form.querySelectorAll('tr[data-uid]'));
        function up(v) { return v.replace(/\s+/g, '').toUpperCase(); }
        function box(tr, f) { return tr.querySelector('[data-f="' + f + '"]'); }
        function targets() { return rows.filter(function (tr) { return tr.style.display !== 'none' && box(tr, 'no').value.trim() === ''; }); }
        function taken(roll) {   // saved in the year, and typed on this page
            var t = {}, k;
            for (k in (used[roll] || {})) t[+k] = used[roll][k];
            rows.forEach(function (tr) { var n = box(tr, 'no').value.trim(); if (up(box(tr, 'roll').value) === roll && /^\d+$/.test(n)) t[+n] = tr.dataset.uid; });
            return t;
        }
        function next(roll) { var t = taken(roll), max = 0, k; for (k in t) max = Math.max(max, +k); return max + 1; }
        function refresh() {
            var roll = up(rollIn.value), n = targets().length;
            firstIn.placeholder = roll ? String(next(roll)) : '';
            btn.textContent = n ? 'Fill the ' + n + ' row(s) shown without a No.' : 'Every row shown has a No.';
            btn.disabled = !roll || !n;
        }
        btn.addEventListener('click', function () {
            var roll = up(rollIn.value), first = firstIn.value.trim() || String(next(roll)), list = targets();
            if (!/^[A-Z0-9\/-]{2,15}$/.test(roll)) { alert('Roll: capitals and digits only (like 1610N).'); return; }
            if (!/^\d{1,6}$/.test(first)) { alert('First No.: digits only (like 1233).'); return; }
            if (!confirm('Give Roll ' + roll + ' and No. ' + first + ' onwards to the ' + list.length + ' row(s) shown without a No., in Reg. No order?')) return;
            var t = taken(roll), n = +first, width = first.charAt(0) === '0' ? first.length : 0;
            list.forEach(function (tr) {
                while (t[n]) n++;   // a No. already given is skipped, never given twice
                var s = String(n); while (s.length < width) s = '0' + s;
                box(tr, 'roll').value = roll; box(tr, 'no').value = s; t[n] = tr.dataset.uid; n++;
            });
            if (window.boardAutosave) window.boardAutosave.saveRows(list);
            firstIn.value = ''; refresh();
        });
        rollIn.addEventListener('input', refresh);
        form.addEventListener('input', refresh);
        document.addEventListener('board:filtered', refresh);
        refresh();
    })();
    </script>
<?php }

function board_view_result(array $c, array $d): void {
    $board = $c['board'];
    $X = BOARD_EXAMS[$board];
    $rows = $d['rows'];
    $cnt = array_count_values(array_map(fn($r) => (string)$r['result_status'], $rows));
    $done = count($rows) - ($cnt[''] ?? 0);
    $last = max(array_keys($X['admits']));   // the admit the result list is read by
    [, , $lrc, $lnc] = board_admit_cols($board, $last);
    $passout = 'pass_out_students.php?' . http_build_query(['session_id' => $c['session_id'], 'class_id' => $c['class_id']]); ?>
    <div class="stats" id="resStats">
        <?php foreach (BOARD_RESULTS as $k => $label): ?><span><b data-k="<?php echo $k; ?>"><?php echo $cnt[$k] ?? 0; ?></b><?php echo h($label); ?></span><?php endforeach; ?>
        <span class="<?php echo !empty($cnt['']) ? 'bad' : ''; ?>"><b data-k=""><?php echo $cnt[''] ?? 0; ?></b>not entered</span>
    </div>
    <?php board_exam_tools($c, $rows, $done, 'result', '<button type="button" class="btn btn-sm btn-secondary" id="markPass" title="Only rows shown that have no result yet">Mark the shown rows PASS</button>'
        . ' <a class="btn btn-sm btn-primary" href="' . h($passout) . '"><i class="fas fa-graduation-cap"></i> Pass Out the passed →</a>'); ?>
    <p class="note" style="margin:0 0 10px">Type or pick and move on — every row saves by itself. % is optional (none for ABSENT).
        <?php echo $X['marks'] ? 'Each semester\'s marks can go in as soon as they come; the result is the two together.' : 'The passed students then leave Class X through Pass Out and join XI through Admission; their Madhyamik year and Roll-No. go with them.'; ?></p>
    <form id="rf" data-kind="result" onsubmit="return false">
        <?php echo ($c['hidden'])(); ?>
        <div class="table-responsive"><table class="ex-table" id="list">
            <thead><tr><th class="num">#</th><th>Student</th><th>Reg. No</th><th><?php echo $last ? "Sem $last " : ''; ?>Roll · No.</th>
                <?php foreach ($X['marks'] as [$mh]): ?><th><?php echo h($mh); ?></th><?php endforeach; ?><th>Result</th><th>%</th><th></th></tr></thead>
            <tbody>
            <?php $n = 0; foreach ($rows as $uid => $r): $st = (string)$r['result_status']; $pct = board_pct($r['percentage']);
                $saved = ['status' => $st, 'pct' => $pct];
                foreach ($X['marks'] as [, $mc]) $saved[$mc] = board_pct($r[$mc]);
                $base = mb_strtolower($r['student_name'] . ' ' . $uid . ' ' . $r['registration_no'] . ' ' . $r[$lrc] . ' ' . $r[$lnc]); ?>
                <tr data-uid="<?php echo h($uid); ?>" data-rid="<?php echo (int)$r['rid']; ?>" data-cc="<?php echo (int)$r['cc']; ?>" data-b="<?php echo h($base); ?>" data-s="<?php echo h($base . ' ' . mb_strtolower($st)); ?>"
                    data-done="<?php echo $st !== '' ? 1 : 0; ?>" data-saved="<?php echo h(json_encode($saved)); ?>">
                    <td class="num"><?php echo ++$n; ?></td>
                    <td><?php echo board_student_cell($r); ?><?php if ($r['cc']): ?> <span class="chip warn">CC</span><?php endif; ?></td>
                    <td><?php echo h($r['registration_no']); ?></td>
                    <td><?php echo trim($r[$lrc] . $r[$lnc]) !== '' ? h($r[$lrc] . ' · ' . $r[$lnc]) : '<span class="dim">—</span>'; ?></td>
                    <?php foreach ($X['marks'] as [$mh, $mc]): ?><td><input type="text" class="bx pc" data-f="<?php echo h($mc); ?>" value="<?php echo h($saved[$mc]); ?>" maxlength="7" inputmode="decimal" autocomplete="off" aria-label="<?php echo h($mh); ?>"></td><?php endforeach; ?>
                    <td><select class="bx" data-f="status" aria-label="Result of <?php echo h($r['student_name']); ?>"><option value="">—</option><?php foreach (BOARD_RESULTS as $k => $label): ?><option value="<?php echo $k; ?>"<?php echo $st === $k ? ' selected' : ''; ?>><?php echo h($label); ?></option><?php endforeach; ?></select></td>
                    <td><input type="text" class="bx pc" data-f="pct" value="<?php echo h($pct); ?>" maxlength="6" inputmode="decimal" autocomplete="off" aria-label="%"></td>
                    <td class="sv"></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
    </form>
    <div class="ex-empty" id="none" hidden><i class="fas fa-check-circle"></i>Every student here has a result.</div>
    <script>
    (function () {   // PASS for the rows shown that have no result yet — each still changeable; the counts follow every save
        var btn = document.getElementById('markPass'), form = document.getElementById('rf'), stats = document.getElementById('resStats');
        if (!btn || !form) return;
        document.addEventListener('board:saved', function () {
            var n = {};
            Array.prototype.forEach.call(form.querySelectorAll('tr[data-uid]'), function (tr) {
                var s = ''; try { s = JSON.parse(tr.dataset.saved || '{}').status || ''; } catch (e) {}
                n[s] = (n[s] || 0) + 1;
            });
            Array.prototype.forEach.call(stats.querySelectorAll('b[data-k]'), function (b) { b.textContent = n[b.dataset.k] || 0; });
            stats.querySelector('b[data-k=""]').parentNode.className = n[''] ? 'bad' : '';
        });
        btn.addEventListener('click', function () {
            var list = Array.prototype.filter.call(form.querySelectorAll('tr[data-uid]'), function (tr) { return tr.style.display !== 'none' && tr.querySelector('[data-f=status]').value === ''; });
            if (!list.length) { alert('Every row shown has a result already.'); return; }
            if (!confirm('Mark the ' + list.length + ' row(s) shown without a result as PASS?')) return;
            list.forEach(function (tr) { tr.querySelector('[data-f=status]').value = 'PASS'; });
            if (window.boardAutosave) window.boardAutosave.saveRows(list);
        });
    })();
    </script>
<?php }

/** An uploaded admit or result sheet: what it would change, then Save or Cancel. */
function board_view_exam_preview(array $c, array $d): void {
    $board = $c['board'];
    $sem = board_step_sem($c['step']);
    $plan = $sem !== null ? board_admit_plan($board, $d['rows'], $c['sheet'], $c['myear'], $sem) : board_result_plan($board, $d['rows'], $c['sheet'], $c['myear']);
    $cnt = array_count_values(array_column($plan, 'status'));
    $todo = ($cnt['new'] ?? 0) + ($cnt['changed'] ?? 0);
    $shown = array_filter($plan, fn($l) => !in_array($l['status'], ['same', 'blank'], true)); ?>
    <div class="card">
        <h2>Check the <?php echo $sem !== null ? ($sem ? "Semester $sem " : '') . 'Roll and No.s' : 'results'; ?> before saving <small>from <?php echo h($c['pending']['name']); ?></small></h2>
        <div class="stats">
            <span><b><?php echo $cnt['new'] ?? 0; ?></b>new</span>
            <span><b><?php echo $cnt['changed'] ?? 0; ?></b>changed</span>
            <span><b><?php echo $cnt['same'] ?? 0; ?></b>already saved</span>
            <span><b><?php echo $cnt['blank'] ?? 0; ?></b>blank (left as it is)</span>
            <span class="<?php echo !empty($cnt['error']) ? 'bad' : ''; ?>"><b><?php echo $cnt['error'] ?? 0; ?></b>with a problem (not saved)</span>
            <?php if (!empty($cnt['outside'])): ?><span class="bad"><b><?php echo $cnt['outside']; ?></b>not in this list</span><?php endif; ?>
        </div>
        <?php if ($shown): ?>
        <div class="table-responsive"><table class="ex-table">
            <thead><tr><th>Student</th><th>Now</th><th>From the sheet</th><th>Result</th></tr></thead>
            <tbody>
            <?php foreach ($shown as $l): $bad = in_array($l['status'], ['error', 'outside'], true); ?>
                <tr>
                    <td><b><?php echo h($l['name'] !== '' ? $l['name'] : '—'); ?></b><br><small class="dim"><?php echo h($l['uid']); ?></small></td>
                    <td><?php echo ($l['old'] ?? '') !== '' ? h($l['old']) : '<span class="dim">none</span>'; ?></td>
                    <td><?php echo isset($l['new']) ? '<b>' . h($l['new']) . '</b>' : '—'; ?></td>
                    <td class="res <?php echo $bad ? 'bad' : 'ok'; ?>"><?php echo $bad ? '✗ ' . h($l['why']) : ($l['status'] === 'new' ? 'New' : 'Changed'); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php else: ?><div class="ex-empty"><i class="fas fa-check-circle"></i>Nothing in the sheet differs from what is saved.</div><?php endif; ?>
        <form method="post" class="tools" style="margin-top:14px"><?php echo ($c['hidden'])(); ?>
            <?php if ($todo): ?><button type="submit" name="confirm_<?php echo $sem !== null ? 'admit' : 'result'; ?>" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save <?php echo $todo; ?> <?php echo $sem !== null ? 'Roll / No.(s)' : 'result(s)'; ?></button><?php endif; ?>
            <button type="submit" name="cancel" value="1" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</button>
        </form>
    </div>
<?php }

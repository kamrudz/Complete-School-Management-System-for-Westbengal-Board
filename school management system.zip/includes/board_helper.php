<?php
/**
 * Board exams — Madhyamik (WBBSE, registered in Class IX, sat from Class X) and Higher Secondary (WBCHSE,
 * registered in XI, sat in Class XII as Semester 3 and Semester 4). Who is ready for the board's registration
 * portal, what is still missing, the registration number the board gives back, who is sent up, the admits' Roll
 * and No., and the result.
 * The pages: includes/board_registration_page.php and includes/board_exam_steps.php (behind
 * admin/secondary_registration.php and admin/hs_registration.php) and admin/board_print.php. Saves are logged when
 * the page has loaded logger.php (it has no include guard, so this file does not load it).
 */
require_once __DIR__ . '/student_fields.php';
require_once __DIR__ . '/simple_xlsx_reader.php';
require_once __DIR__ . '/result_helper.php';      // the year's result of Class X decides who sits Madhyamik
require_once __DIR__ . '/hs_result_helper.php';   // and Class XI's year result who sits the HS exam

/** The two boards: their name, the table that keeps the registration number, their classes, the exam colours. */
const BOARDS = [
    'wbbse'  => ['name' => 'Madhyamik', 'board' => 'WBBSE', 'table' => 'secondary_registration', 'classes' => ['IX', 'X'], 'theme' => 'vx', 'page' => 'secondary_registration.php'],
    'wbchse' => ['name' => 'Higher Secondary', 'board' => 'WBCHSE', 'table' => 'hs_registration', 'classes' => ['XI', 'XII'], 'theme' => 'hs', 'page' => 'hs_registration.php'],
];

/**
 * What the board's registration form needs: key => [label, fields]. A check passes when one of its fields is
 * filled in and valid — fields are keys of student_bulk_fields(), or photo, signature, madhyamik (board, year
 * and roll of the Madhyamik result) and subjects (the HS subject combination). The first field is the one the
 * missing-data sheet offers. This list is the place to change when the portal form changes.
 */
function board_checks(string $board): array {
    $c = [
        'student_name'      => ['Name', ['student_name']],
        'father_name'       => ['Father', ['father_name']],
        'mother_name'       => ['Mother', ['mother_name']],
        'dob'               => ['Date of birth', ['dob']],
        'gender'            => ['Gender', ['gender']],
        'religion'          => ['Religion', ['religion']],
        'caste'             => ['Caste', ['caste']],
        'nationality'       => ['Nationality', ['nationality']],
        'student_aadhaar'   => ['Aadhaar', ['student_aadhaar']],
        'mobile'            => ['Mobile', ['mobile', 'father_mobile', 'guardian_contact']],
        'village'           => ['Village', ['village']],
        'post_office'       => ['Post office', ['post_office']],
        'police_station'    => ['Police station', ['police_station']],
        'district'          => ['District', ['district']],
        'pin_code'          => ['PIN', ['pin_code']],
        'banglarshiksha_id' => ['Banglar Shiksha ID', ['banglarshiksha_id']],
        'photo'             => ['Photo', ['photo']],
        'signature'         => ['Signature', ['signature']],
    ];
    if ($board === 'wbchse') $c += ['madhyamik' => ['Madhyamik details', ['madhyamik']], 'subjects' => ['HS subjects', ['subjects']]];
    return $c;
}

/** The ids of a board's classes, in class order: class id => name. */
function board_classes(string $board): array {
    $out = [];
    foreach (class_rows() as $id => $c) if (in_array($c['name'], BOARDS[$board]['classes'], true)) $out[$id] = $c['name'];
    return $out;
}
/** The class a board registers in (IX / XI) and the class that sits its exam (X / XII). */
function board_reg_class(string $board): int { return (int)array_key_first(board_classes($board)); }
function board_exam_class(string $board): int { return (int)array_key_last(board_classes($board)); }

/** The Show filter — the board sends boys' and girls' registration numbers in separate lots. */
const BOARD_SHOW = ['' => 'All', 'M' => 'Boys', 'F' => 'Girls'];
function board_gender(string $show): string { return ['M' => 'Male', 'F' => 'Female'][$show] ?? ''; }

/** The four-digit year of a session name ("2026", "2025-26" → 2025), for the registration year. */
function board_session_year(int $session_id): int {
    $name = (string)(db_get_row('SELECT session_name FROM academic_sessions WHERE id = ?', 'i', $session_id)['session_name'] ?? '');
    return preg_match('/(\d{4})/', $name, $m) ? (int)$m[1] : (int)date('Y');
}

/**
 * The Active students of a class in a session (one section, or all; boys, girls or both), with everything the board
 * asks for, their registration row and — for WBCHSE — the Madhyamik result and HS subjects. uid => row, in section
 * and roll order.
 */
function board_students(string $board, int $session_id, int $class_id, int $section_id = 0, string $gender = ''): array {
    $t = BOARDS[$board]['table'];
    $hs = $board === 'wbchse'
        ? ", mp.mp_board, mp.mp_year, mp.mp_roll_no,
           (SELECT COUNT(*) FROM hs_student_subjects x WHERE x.student_id = s.id AND x.session_id = h.session_id AND x.class_id = h.class_id) AS subject_count,
           (SELECT GROUP_CONCAT(sub.subject_name ORDER BY FIELD(x.slot, 'compulsory', 'elective', 'additional'), sub.subject_name SEPARATOR ', ')
              FROM hs_student_subjects x JOIN subjects sub ON sub.id = x.subject_id
             WHERE x.student_id = s.id AND x.session_id = h.session_id AND x.class_id = h.class_id) AS subject_names"
        : '';
    $mp = $board === 'wbchse' ? 'LEFT JOIN hs_student_mp_marks mp ON mp.id = (SELECT MAX(id) FROM hs_student_mp_marks WHERE student_id = s.id)' : '';
    $rows = db_get_all("SELECT s.id AS uid, s.student_name, s.name_as_per_aadhaar, s.gender, s.dob, s.religion, s.caste, s.nationality, s.mother_tongue, s.student_aadhaar, s.mobile,
            s.village, s.post_office, s.police_station, s.district, s.state, s.pin_code, s.banglarshiksha_id, s.pen_id, s.apaar_id,
            s.photo, s.signature, g.father_name, g.mother_name, g.father_mobile, g.guardian_name, g.guardian_contact,
            h.section_id, sec.section_name, h.roll_no, r.id AS reg_id, r.registration_no, r.registration_year $hs
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN $t r ON r.id = (SELECT MAX(id) FROM $t WHERE student_id = s.id)
        $mp
        WHERE h.session_id = ? AND h.class_id = ? AND h.academic_status = 'Current'" . ($section_id ? ' AND h.section_id = ?' : '') . ($gender !== '' ? ' AND s.gender = ?' : '') . "
        ORDER BY sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name",
        'ii' . ($section_id ? 'i' : '') . ($gender !== '' ? 's' : ''),
        ...array_merge([$session_id, $class_id], $section_id ? [$section_id] : [], $gender !== '' ? [$gender] : []));
    $out = [];
    foreach ($rows as $r) $out[$r['uid']] = $r;
    return $out;
}

/** Why a filled-in value will not do for the board ('' when it will). */
function board_value_error(string $field, string $v): string {
    static $fields = null;
    $fields ??= student_bulk_fields();
    $m = match ($field) {
        'student_name' => student_v_name($v, 'Name'),
        'father_name' => student_v_name($v, 'Father'),
        'mother_name' => student_v_name($v, 'Mother'),
        'dob' => student_v_dob($v),
        'student_aadhaar' => student_v_aadhaar($v),
        'mobile', 'father_mobile', 'guardian_contact' => student_v_mobile($v),
        'pin_code' => student_v_pin($v),
        'banglarshiksha_id' => student_v_banglarshiksha($v),
        default => null,
    };
    if ($m === null && ($fields[$field]['type'] ?? '') === 'select'   // ISLAM is Islam, as Bulk Update takes it
            && !array_filter($fields[$field]['options'], fn($o) => strcasecmp($o, $v) === 0)) $m = 'not one of the allowed values';
    return (string)$m;
}

/**
 * What stops a student from being ready for the board: check key => [label, why], why = '' when it is missing,
 * else what is wrong with the value there. An empty array means the student is ready.
 */
function board_missing(array $st, string $board): array {
    $out = [];
    foreach (board_checks($board) as $key => [$label, $fields]) {
        $why = null;   // null: nothing filled in yet
        foreach ($fields as $f) {
            if ($f === 'photo' || $f === 'signature') { if (trim((string)($st[$f] ?? '')) !== '') { $why = false; break; } continue; }
            if ($f === 'madhyamik') { if (trim((string)($st['mp_board'] ?? '')) !== '' && trim((string)($st['mp_year'] ?? '')) !== '' && trim((string)($st['mp_roll_no'] ?? '')) !== '') { $why = false; break; } continue; }
            if ($f === 'subjects') { if ((int)($st['subject_count'] ?? 0) > 0) { $why = false; break; } continue; }
            $v = trim((string)($st[$f] ?? ''));
            if ($v === '') continue;
            $err = board_value_error($f, $v);
            if ($err === '') { $why = false; break; }
            $why = $err;   // filled in, but not valid — another field of the check may still do
        }
        if ($why !== false) $out[$key] = [$label, (string)$why];
    }
    return $out;
}

/** How far a list of students is: total, ready (nothing missing), registered (a registration number). */
function board_counts(array $students, string $board): array {
    $c = ['total' => count($students), 'ready' => 0, 'registered' => 0];
    foreach ($students as $st) {
        if (!board_missing($st, $board)) $c['ready']++;
        if (trim((string)$st['registration_no']) !== '') $c['registered']++;
    }
    return $c;
}

/** Is this student Active and Current in the class in that session? (Saves never touch anyone else.) */
function board_student_in(int $session_id, int $class_id, string $uid): bool {
    return (bool)db_get_row("SELECT h.id FROM student_academic_history h JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        WHERE h.student_id = ? AND h.session_id = ? AND h.class_id = ? AND h.academic_status = 'Current' LIMIT 1", 'sii', $uid, $session_id, $class_id);
}

/** A registration number as it is kept: no spaces, capitals. */
function board_regno_clean(string $v): string {
    return strtoupper(preg_replace('/\s+/', '', trim(board_cell($v))));
}

/** Why a registration number or year will not do ('' when it will). */
function board_regno_error(string $no): string {
    return $no === '' || preg_match('~^[A-Z0-9/-]{3,30}$~', $no) ? '' : 'Reg. No: use letters, digits, / or - (3 to 30 characters).';
}
function board_year_error(string $y): string {
    $max = (int)date('Y') + 1;
    return preg_match('/^\d{4}$/', $y) && (int)$y >= 2000 && (int)$y <= $max ? '' : "Year must be a 4-digit year from 2000 to $max.";
}

/**
 * Save a student's registration number and year. A blank number clears it — unless (Madhyamik) a roll, number or
 * result already hangs on that registration. One row per student: the latest is updated. Another student
 * holding the same number is refused by name. Returns [ok, error | no, year, cleared].
 */
function board_save_regno(string $board, string $uid, string $no, string $year): array {
    $t = BOARDS[$board]['table'];
    $no = board_regno_clean($no);
    $year = trim(board_cell($year));
    if ($e = board_regno_error($no)) return ['ok' => false, 'error' => $e];
    $row = db_get_row("SELECT id, registration_no, registration_year" . ($board === 'wbbse' ? ', madhyamik_roll, madhyamik_number' : '') . " FROM $t WHERE student_id = ? ORDER BY id DESC LIMIT 1", 's', $uid);
    $log = fn(string $action, $id, $old, $new) => function_exists('log_action') ? log_action((int)($_SESSION['admin_id'] ?? 0), $action, $t, $id, $old, $new) : null;
    if ($no === '') {
        if (!$row) return ['ok' => true, 'no' => '', 'year' => '', 'cleared' => true];
        if ($board === 'wbbse' && (trim((string)$row['madhyamik_roll']) !== '' || trim((string)$row['madhyamik_number']) !== ''
                || db_get_row('SELECT id FROM secondary_exam WHERE registration_id = ? LIMIT 1', 'i', (int)$row['id']))) {
            return ['ok' => false, 'error' => 'This registration already has a Madhyamik roll or result, so it cannot be cleared here.'];
        }
        // the HS attempts hang on the registration (their foreign key would take them along)
        if ($board === 'wbchse' && board_exam_ready($board) && db_get_row('SELECT id FROM hs_board_exam WHERE registration_id = ? LIMIT 1', 'i', (int)$row['id'])) {
            return ['ok' => false, 'error' => 'This student is sent up for the HS exam — take them off the sent-up list first.'];
        }
        db_execute("DELETE FROM $t WHERE id = ?", 'i', (int)$row['id']);
        $log('BOARD_REG_CLEARED', (int)$row['id'], ['student' => $uid, 'no' => $row['registration_no'], 'year' => $row['registration_year']], null);
        return ['ok' => true, 'no' => '', 'year' => '', 'cleared' => true];
    }
    if ($e = board_year_error($year)) return ['ok' => false, 'error' => $e];
    $owner = db_get_row("SELECT r.student_id, s.student_name FROM $t r JOIN students s ON s.id = r.student_id WHERE r.registration_no = ? AND r.student_id <> ? LIMIT 1", 'ss', $no, $uid);
    if ($owner) return ['ok' => false, 'error' => "$no is already given to {$owner['student_name']} ({$owner['student_id']})."];
    if ($row && (string)$row['registration_no'] === $no && (string)$row['registration_year'] === $year) return ['ok' => true, 'no' => $no, 'year' => $year];
    try {
        if ($row) db_update($t, ['registration_no' => $no, 'registration_year' => $year], ['id' => (int)$row['id']], 'i');
        else db_insert($t, ['student_id' => $uid, 'board_type' => BOARDS[$board]['board'], 'registration_no' => $no, 'registration_year' => $year]);
    } catch (mysqli_sql_exception $e) {
        return ['ok' => false, 'error' => $e->getCode() === 1062 ? "$no is already given to another student." : 'Could not save: ' . $e->getMessage()];
    }
    $log('BOARD_REG_SAVED', $row ? (int)$row['id'] : null, $row ? ['no' => $row['registration_no'], 'year' => $row['registration_year']] : null, ['student' => $uid, 'no' => $no, 'year' => $year]);
    return ['ok' => true, 'no' => $no, 'year' => $year];
}

/**
 * The Madhyamik board, year and roll of a student (WBCHSE registration asks for them) — only the ones given;
 * subject marks already recorded stay as they are. Returns '' or what is wrong.
 */
function board_mp_save(string $uid, array $mp): string {
    $mp = array_filter(array_intersect_key($mp, array_flip(['mp_board', 'mp_year', 'mp_roll_no'])), fn($v) => $v !== '');
    if (!$mp) return '';
    foreach ($mp as $f => $v) if ($e = board_mp_error($f, $v)) return $e;
    if (isset($mp['mp_board'])) $mp['mp_board'] = board_mp_board($mp['mp_board']);
    $id = (int)(db_get_row('SELECT MAX(id) AS id FROM hs_student_mp_marks WHERE student_id = ?', 's', $uid)['id'] ?? 0);
    if ($id) db_update('hs_student_mp_marks', $mp, ['id' => $id], 'i');
    else db_insert('hs_student_mp_marks', ['student_id' => $uid, 'mp_total_marks' => 0, 'mp_total_full_marks' => 0, 'mp_percentage' => 0] + $mp);
    if (function_exists('log_action')) log_action((int)($_SESSION['admin_id'] ?? 0), 'BOARD_MP_SAVED', 'hs_student_mp_marks', $id ?: null, null, ['student' => $uid] + $mp);
    return '';
}

/** A Madhyamik board as the list spells it ("wbbse" → WBBSE), or null when it is not one of them. */
function board_mp_board(string $v): ?string {
    foreach (student_mp_boards() as $b) if (strcasecmp($b, trim($v)) === 0) return $b;
    return null;
}

/** Why a Madhyamik board / year / roll will not do ('' when it will). */
function board_mp_error(string $field, string $v): string {
    return match ($field) {
        'mp_board' => board_mp_board($v) === null ? 'Madhyamik Board must be one of ' . implode(', ', student_mp_boards()) . '.' : '',
        'mp_year' => preg_match('/^(19|20)\d\d$/', $v) ? '' : 'Madhyamik Year must be a 4-digit year.',
        'mp_roll_no' => mb_strlen($v) > 30 ? 'Madhyamik Roll is at most 30 characters.' : '',
        default => '',
    };
}

/**
 * A cell from an uploaded sheet as the person meant it: Excel turns a long number into 2.34567890123E+11 or
 * 234567890123.0, and those come back as the digits.
 */
function board_cell($v): string {
    $v = trim((string)$v);
    if (preg_match('/^\d+\.0+$/', $v)) return preg_replace('/\.0+$/', '', $v);
    if (preg_match('/^\d(\.\d+)?E\+\d+$/i', $v)) return number_format((float)$v, 0, '', '');
    return $v;
}

/** A date from a sheet — an Excel date number, dd/mm/yyyy, dd-mm-yyyy or yyyy-mm-dd — as yyyy-mm-dd ('' if none). */
function board_cell_date(string $v): string {
    $v = trim($v);
    if ($v === '') return '';
    if (preg_match('/^\d{4,5}(\.\d+)?$/', $v)) return SimpleXLSXReader::excelSerialToDate($v);
    if (preg_match('~^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$~', $v, $m)) return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    return $v;
}

/** dd-mm-yyyy for people ('' for none). */
function board_date(?string $ymd): string {
    return $ymd && preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $ymd, $m) ? "$m[3]-$m[2]-$m[1]" : '';
}

/**
 * The editable columns of the missing-data sheet: header => field (keys of student_bulk_fields(), or the
 * Madhyamik mp_* columns for WBCHSE). The name, photo and signature are not in it — they are fixed in Edit Student.
 */
function board_fix_columns(string $board): array {
    $fields = student_bulk_fields();
    $label = ['father_name' => 'Father Name', 'mother_name' => 'Mother Name', 'mobile' => 'Student Mobile'];
    $out = [];
    foreach (board_checks($board) as [, $fs]) {
        $f = $fs[0];
        if ($f === 'student_name' || !isset($fields[$f]) || $fields[$f]['type'] === 'file') continue;
        $out[$label[$f] ?? $fields[$f]['label']] = $f;
    }
    if ($board === 'wbchse') $out += ['Madhyamik Board' => 'mp_board', 'Madhyamik Year' => 'mp_year', 'Madhyamik Roll' => 'mp_roll_no'];
    return $out;
}

/** The value a field of the missing-data sheet shows for a student (a date as dd/mm/yyyy). */
function board_fix_value(array $st, string $field): string {
    $v = trim((string)($st[$field] ?? ''));
    return $field === 'dob' && $v !== '' ? str_replace('-', '/', board_date($v)) : $v;
}

/* ───────────── The board exam: sent up → admit (Roll and No.) → result ─────────────
 * One row per student per exam year in the board's table, from the moment the student is sent up:
 *   Madhyamik (secondary_exam)  exam_year = the Madhyamik year (Class X of session 2026 sits in 2027), roll_no = the
 *                               admit's Roll (e.g. 1610N), index_no = its No. (e.g. 1233), result_status, percentage.
 *   HS (hs_board_exam)          exam_year = the HS year (Class XII of session 2026 → 2027, for Semester 3, Semester 4
 *                               and the result); each semester's admit has its own Roll and No., each semester its
 *                               marks; the result is the two together.
 * A student whose earlier attempt was not a pass is a re-appearing (CC) candidate: their Roll series is different. */

/**
 * Per board: the exam's name, its table, the registration table, the admits (semester => [sheet heading, Roll
 * column, No. column]; 0 is Madhyamik's one admit), the marks kept per semester (semester => [heading, column]) and
 * where the sent-up ticks come from — 'x': the year's result of Class X; 'xi': Class XI's year result, a session back.
 */
const BOARD_EXAMS = [
    'wbbse'  => ['exam' => 'Madhyamik', 'table' => 'secondary_exam', 'reg_table' => 'secondary_registration',
                 'admits' => [0 => ['', 'roll_no', 'index_no']], 'marks' => [], 'sentup' => 'x'],
    'wbchse' => ['exam' => 'HS', 'table' => 'hs_board_exam', 'reg_table' => 'hs_registration',
                 'admits' => [3 => ['Sem 3', 'sem3_roll', 'sem3_no'], 4 => ['Sem 4', 'sem4_roll', 'sem4_no']],
                 'marks' => [3 => ['Sem 3 Marks', 'sem3_marks'], 4 => ['Sem 4 Marks', 'sem4_marks']], 'sentup' => 'xi'],
];

const BOARD_RESULTS = ['PASS' => 'Pass', 'FAIL' => 'Fail', 'ABSENT' => 'Absent', 'COMPARTMENT' => 'Compartment'];

/** The HS board-exam table. The code makes it the first time a student is sent up; db/schema.sql has the same. */
const BOARD_HS_TABLE_SQL = "CREATE TABLE IF NOT EXISTS `hs_board_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_id` int(11) NOT NULL COMMENT 'hs_registration.id',
  `exam_year` year(4) NOT NULL COMMENT 'HS year: Class XII of session 2026 -> 2027 (Sem 3, Sem 4 and the result)',
  `sem3_roll` varchar(20) DEFAULT NULL,
  `sem3_no` varchar(20) DEFAULT NULL,
  `sem3_marks` decimal(6,2) DEFAULT NULL,
  `sem4_roll` varchar(20) DEFAULT NULL,
  `sem4_no` varchar(20) DEFAULT NULL,
  `sem4_marks` decimal(6,2) DEFAULT NULL,
  `result_status` enum('PASS','FAIL','ABSENT','COMPARTMENT') DEFAULT NULL,
  `percentage` decimal(5,2) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hs_board_attempt` (`registration_id`,`exam_year`),
  CONSTRAINT `fk_hs_board_exam_registration` FOREIGN KEY (`registration_id`) REFERENCES `hs_registration` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='WBCHSE board exam of a student: Sem 3 and Sem 4 admits and marks, the result'";

/** Is the board's exam table there? The HS one is not until the first student is sent up. */
function board_exam_ready(string $board, bool $recheck = false): bool {
    static $ready = [];
    if ($board !== 'wbchse') return true;
    if ($recheck || !isset($ready[$board])) $ready[$board] = (bool)db_get_row("SHOW TABLES LIKE 'hs_board_exam'");
    return $ready[$board];
}
/** Make the HS table if it is not there yet (the way includes/user_access.php makes its table). */
function board_exam_ensure(string $board): void {
    if (board_exam_ready($board)) return;
    global $conn;
    mysqli_query($conn, BOARD_HS_TABLE_SQL);
    board_exam_ready($board, true);
}

/** The step of an admit (Madhyamik: admit; HS: sem3, sem4), and back. */
function board_admit_step(int $sem): string { return $sem ? "sem$sem" : 'admit'; }
function board_step_sem(string $step): ?int { return $step === 'admit' ? 0 : (preg_match('/^sem([34])$/', $step, $m) ? (int)$m[1] : null); }
/** An admit's sheet headings and columns: [Roll heading, No. heading, Roll column, No. column]. */
function board_admit_cols(string $board, int $sem): array {
    [$pre, $rc, $nc] = BOARD_EXAMS[$board]['admits'][$sem];
    return [trim("$pre Roll"), trim("$pre No."), $rc, $nc];
}

/** Exam years a person may pick: from 2000 to two years ahead. */
function board_exam_year_ok(int $y): bool { return $y >= 2000 && $y <= (int)date('Y') + 2; }

/**
 * The exam year of a session's exam class: the year most of their attempts are recorded for (later than the
 * session), else the session's year + 1 (Class X of 2026 → Madhyamik 2027; Class XII of 2026 → HS 2027).
 */
function board_exam_year_default(string $board, int $session_id, int $class_id): int {
    $session_year = board_session_year($session_id);
    if (!board_exam_ready($board)) return $session_year + 1;
    $X = BOARD_EXAMS[$board];
    $r = db_get_row("SELECT e.exam_year, COUNT(*) AS n FROM {$X['table']} e
            JOIN {$X['reg_table']} r ON r.id = e.registration_id
            JOIN student_academic_history h ON h.student_id = r.student_id AND h.session_id = ? AND h.class_id = ?
        WHERE e.exam_year > ? GROUP BY e.exam_year ORDER BY n DESC, e.exam_year DESC LIMIT 1", 'iii', $session_id, $class_id, $session_year);
    return $r ? (int)$r['exam_year'] : $session_year + 1;
}

/** The session a year before (by name: 2025 before 2026), or 0. */
function board_prev_session(int $session_id): int {
    $want = board_session_year($session_id) - 1;
    foreach (db_get_all('SELECT id, session_name FROM academic_sessions') as $s) {
        if (preg_match('/(\d{4})/', (string)$s['session_name'], $m) && (int)$m[1] === $want) return (int)$s['id'];
    }
    return 0;
}

/**
 * The attempts of one exam year with the student, the registration and the section / roll of the student's exam
 * class (their latest row of it, so a student already passed out still shows). uid => row (the table's own columns,
 * plus rid, cc …), in Reg. No order, small to large. cc = 1 for a re-appearing candidate.
 */
function board_exam_rows(string $board, int $myear, int $class_id, int $section_id = 0, string $gender = ''): array {
    if (!board_exam_ready($board)) return [];
    $X = BOARD_EXAMS[$board];
    $sql = "SELECT e.*, e.id AS rid, r.id AS reg_id, r.registration_no, r.registration_year, r.board_type,
                s.id AS uid, s.student_name, s.gender, s.photo, g.father_name,
                h.section_id, sec.section_name, h.roll_no AS class_roll,
                EXISTS (SELECT 1 FROM {$X['table']} p WHERE p.registration_id = r.id AND p.exam_year < e.exam_year
                        AND (p.result_status IS NULL OR p.result_status <> 'PASS')) AS cc
            FROM {$X['table']} e
            JOIN {$X['reg_table']} r ON r.id = e.registration_id
            JOIN students s ON s.id = r.student_id
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN student_academic_history h ON h.id = (SELECT MAX(x.id) FROM student_academic_history x WHERE x.student_id = s.id AND x.class_id = ?)
            LEFT JOIN sections sec ON sec.id = h.section_id
            WHERE e.exam_year = ?" . ($section_id ? ' AND h.section_id = ?' : '') . ($gender !== '' ? ' AND s.gender = ?' : '');
    $rows = db_get_all($sql, 'ii' . ($section_id ? 'i' : '') . ($gender !== '' ? 's' : ''),
        ...array_merge([$class_id, $myear], $section_id ? [$section_id] : [], $gender !== '' ? [$gender] : []));
    usort($rows, fn($a, $b) => strnatcasecmp((string)$a['registration_no'], (string)$b['registration_no']) ?: strcmp($a['uid'], $b['uid']));
    $out = [];
    foreach ($rows as $r) $out[$r['uid']] = $r;
    return $out;
}

/** One attempt of that exam year with its student, or null. */
function board_exam_row(string $board, int $rid, int $myear): ?array {
    if (!board_exam_ready($board)) return null;
    $X = BOARD_EXAMS[$board];
    return db_get_row("SELECT e.*, r.student_id, s.student_name FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
        JOIN students s ON s.id = r.student_id WHERE e.id = ? AND e.exam_year = ?", 'ii', $rid, $myear) ?: null;
}

/** Has an attempt anything on it yet — a Roll or No., marks, a result? */
function board_exam_has_content(string $board, array $row): bool {
    foreach (BOARD_EXAMS[$board]['admits'] as [, $rc, $nc]) if (trim((string)($row[$rc] ?? '')) !== '' || trim((string)($row[$nc] ?? '')) !== '') return true;
    foreach (BOARD_EXAMS[$board]['marks'] as [, $mc]) if (($row[$mc] ?? null) !== null && $row[$mc] !== '') return true;
    return trim((string)($row['result_status'] ?? '')) !== '';
}

/**
 * The exam class of a session for an exam year: every student with the result that decides who is sent up —
 * Madhyamik: the year's result of Class X (result_annual(); PASS, or PUC under the Pass/Fail settings); HS: the year
 * result of Class XI a session back (hs_result_year(); PASS) — the registration, and their attempt when sent up.
 * Returns [students, warnings]; a warning says why the result is missing or not complete.
 */
function board_sentup_list(string $board, int $session_id, int $class_id, int $section_id, string $gender, int $myear): array {
    $students = board_students($board, $session_id, $class_id, $section_id, $gender);
    if (BOARD_EXAMS[$board]['sentup'] === 'x') {
        $res = result_annual($session_id, $class_id, $section_id ?: null);
        $warnings = $res['warnings'];
        $sends = ['PASS', 'PUC'];
    } else {   // Class XI a session back, as the class was at the end of that year (those promoted to XII included)
        $prev = board_prev_session($session_id);
        $res = $prev ? hs_result_year($prev, board_reg_class($board), null, true) : ['students' => []];
        $warnings = $prev ? array_map(fn($w) => 'Class XI ' . board_session_year($prev) . ": $w", $res['warnings'])
                          : ['The Class XI result of ' . (board_session_year($session_id) - 1) . ' is not in the system'];
        $sends = ['PASS'];
    }
    $rows = board_exam_rows($board, $myear, $class_id);
    foreach ($students as $uid => &$st) {
        $r = $res['students'][$uid] ?? null;
        $st['result'] = (string)($r['status'] ?? '');
        $st['result_pct'] = $r['pct'] ?? null;
        $st['suggest'] = in_array($st['result'], $sends, true);
        $st['exam'] = $rows[$uid] ?? null;
    }
    unset($st);
    return [$students, $warnings];
}

/**
 * Re-appearing (CC) candidates who could sit this exam year: a registration whose latest earlier attempt was not a
 * pass, of a student not in $skip (the exam class's list). uid => row, exam = ['rid' => …] once added.
 */
function board_cc_candidates(string $board, int $myear, array $skip, string $gender = ''): array {
    if (!board_exam_ready($board)) return [];
    $X = BOARD_EXAMS[$board];
    $rows = db_get_all("SELECT r.id AS reg_id, r.registration_no, s.id AS uid, s.student_name, s.gender, s.photo,
            p.exam_year AS last_year, p.result_status AS last_result, e.id AS rid
        FROM {$X['reg_table']} r
        JOIN students s ON s.id = r.student_id
        JOIN {$X['table']} p ON p.id = (SELECT q.id FROM {$X['table']} q WHERE q.registration_id = r.id AND q.exam_year < ? ORDER BY q.exam_year DESC, q.id DESC LIMIT 1)
        LEFT JOIN {$X['table']} e ON e.registration_id = r.id AND e.exam_year = ?
        WHERE (p.result_status IS NULL OR p.result_status <> 'PASS')" . ($gender !== '' ? ' AND s.gender = ?' : ''),
        'ii' . ($gender !== '' ? 's' : ''), ...array_merge([$myear, $myear], $gender !== '' ? [$gender] : []));
    usort($rows, fn($a, $b) => strnatcasecmp((string)$a['registration_no'], (string)$b['registration_no']));
    $out = [];
    foreach ($rows as $r) {
        if (isset($skip[$r['uid']])) continue;
        $r['exam'] = $r['rid'] ? ['rid' => $r['rid']] : null;
        $out[$r['uid']] = $r;
    }
    return $out;
}

/**
 * Send up the ticked students of a list for an exam year and take the others back. A student without a Reg. No
 * cannot be sent up; one whose attempt already has a Roll, No., marks or result is not taken back. Returns
 * [added, removed, problems].
 */
function board_save_sentup(string $board, array $students, array $ticked, int $myear): array {
    $X = BOARD_EXAMS[$board];
    $added = 0; $removed = 0; $problems = [];
    $log = fn(string $action, int $id, array $data) => function_exists('log_action') ? log_action((int)($_SESSION['admin_id'] ?? 0), $action, $X['table'], $id, null, $data) : null;
    if (array_intersect_key($ticked, $students)) board_exam_ensure($board);
    foreach ($students as $uid => $st) {
        $want = isset($ticked[$uid]);
        $has = $st['exam'] ?? null;
        if ($want && !$has) {
            if (empty($st['reg_id'])) { $problems[] = "{$st['student_name']}: no Reg. No yet"; continue; }
            if (db_get_row("SELECT id FROM {$X['table']} WHERE registration_id = ? AND exam_year = ?", 'ii', (int)$st['reg_id'], $myear)) continue;   // sent up a moment ago
            $id = (int)db_insert($X['table'], ['registration_id' => (int)$st['reg_id'], 'exam_year' => $myear]);
            if ($id) { $added++; $log('BOARD_SENT_UP', $id, ['student' => $uid, 'exam' => $X['exam'], 'year' => $myear]); }
        } elseif (!$want && $has) {
            $row = board_exam_row($board, (int)$has['rid'], $myear);
            if (!$row) continue;
            if (board_exam_has_content($board, $row)) {
                $problems[] = "{$st['student_name']}: already has an admit Roll / No., marks or a result — clear those first";
                continue;
            }
            db_execute("DELETE FROM {$X['table']} WHERE id = ?", 'i', (int)$has['rid']);
            $removed++;
            $log('BOARD_SENT_UP_REMOVED', (int)$has['rid'], ['student' => $uid, 'exam' => $X['exam'], 'year' => $myear]);
        }
    }
    return [$added, $removed, $problems];
}

/** A Roll as the admit prints it (capitals, no spaces) and a No. (digits). */
function board_roll_clean(string $v): string { return strtoupper(preg_replace('/\s+/', '', board_cell($v))); }
function board_no_clean(string $v): string { return preg_replace('/\s+/', '', board_cell($v)); }
/** Why a Roll / No. will not do ('' when it will). */
function board_admit_error(string $roll, string $no): string {
    if ($roll !== '' && !preg_match('~^[A-Z0-9/-]{2,15}$~', $roll)) return 'Roll: capitals and digits only (like 1610N).';
    if ($no !== '' && !preg_match('/^\d{1,6}$/', $no)) return 'No.: digits only (like 1233).';
    return '';
}
/** Who else holds this Roll + No. on the same admit of the exam year (0012 is 12), or null. */
function board_admit_owner(string $board, int $myear, int $sem, string $roll, string $no, int $not_rid): ?array {
    $X = BOARD_EXAMS[$board];
    [, , $rc, $nc] = board_admit_cols($board, $sem);
    return db_get_row("SELECT r.student_id, s.student_name FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
        JOIN students s ON s.id = r.student_id
        WHERE e.exam_year = ? AND UPPER(e.$rc) = ? AND TRIM(LEADING '0' FROM e.$nc) = ? AND e.id <> ? LIMIT 1",
        'issi', $myear, $roll, ltrim($no, '0'), $not_rid) ?: null;
}

/**
 * Save an admit's Roll and No. of an attempt (Madhyamik: semester 0; HS: 3 or 4); both blank clears them. The same
 * Roll + No. on another student's admit of that year is refused by name. Returns [ok, error | values, cleared].
 */
function board_save_admit(string $board, int $rid, int $myear, int $sem, string $roll, string $no): array {
    $X = BOARD_EXAMS[$board];
    if (!isset($X['admits'][$sem])) return ['ok' => false, 'error' => 'No such admit.'];
    $row = board_exam_row($board, $rid, $myear);
    if (!$row) return ['ok' => false, 'error' => "Not sent up for {$X['exam']} $myear."];
    [, , $rc, $nc] = board_admit_cols($board, $sem);
    $roll = board_roll_clean($roll);
    $no = board_no_clean($no);
    if ($e = board_admit_error($roll, $no)) return ['ok' => false, 'error' => $e];
    if ($roll !== '' && $no !== '' && ($o = board_admit_owner($board, $myear, $sem, $roll, $no, $rid))) {
        return ['ok' => false, 'error' => "Roll $roll No. $no is already given to {$o['student_name']} ({$o['student_id']})."];
    }
    $out = ['ok' => true, 'values' => ['roll' => $roll, 'no' => $no], 'cleared' => $roll === '' && $no === ''];
    if ((string)$row[$rc] === $roll && (string)$row[$nc] === $no) return $out;
    db_update($X['table'], [$rc => $roll !== '' ? $roll : null, $nc => $no !== '' ? $no : null], ['id' => $rid], 'i');
    if (function_exists('log_action')) log_action((int)($_SESSION['admin_id'] ?? 0), 'BOARD_ADMIT_SAVED', $X['table'], $rid,
        ['roll' => $row[$rc], 'no' => $row[$nc]], ['student' => $row['student_id'], 'admit' => $sem ?: $X['exam'], 'roll' => $roll, 'no' => $no]);
    return $out;
}

/** A result word as the list spells it (P / Pass / passed → PASS, AB → ABSENT …), or '' when it is none of them. */
function board_result_word(string $v): string {
    $v = strtoupper(trim($v));
    return match (true) {
        in_array($v, ['P', 'PASS', 'PASSED'], true) => 'PASS',
        in_array($v, ['F', 'FAIL', 'FAILED'], true) => 'FAIL',
        in_array($v, ['A', 'AB', 'ABS', 'ABSENT'], true) => 'ABSENT',
        in_array($v, ['C', 'COMP', 'COMPARTMENT', 'COMPARTMENTAL'], true) => 'COMPARTMENT',
        default => '',
    };
}
/** A number for people: 62.50 → 62.5 ('' for none). */
function board_pct($v): string { return $v === null || $v === '' ? '' : rtrim(rtrim(number_format((float)$v, 2, '.', ''), '0'), '.'); }
/** Why a result will not do ('' when it will). */
function board_result_error(string $status, string $pct): string {
    if ($status !== '' && !isset(BOARD_RESULTS[$status])) return 'Result: PASS, FAIL, ABSENT or COMPARTMENT.';
    if ($pct !== '' && (!is_numeric($pct) || (float)$pct < 0 || (float)$pct > 100)) return '%: a number from 0 to 100.';
    return '';
}
/** Why a semester's marks will not do ('' when they will). */
function board_marks_error(string $v): string {
    return $v === '' || (is_numeric($v) && (float)$v >= 0 && (float)$v <= 9999) ? '' : 'Marks: a number from 0 to 9999.';
}

/**
 * Save the result of an attempt — and, for HS, each semester's marks ($marks: semester => marks). A blank result
 * clears it; ABSENT keeps no %. Returns [ok, error | values, cleared].
 */
function board_save_result(string $board, int $rid, int $myear, string $status, string $pct, array $marks = []): array {
    $X = BOARD_EXAMS[$board];
    $row = board_exam_row($board, $rid, $myear);
    if (!$row) return ['ok' => false, 'error' => "Not sent up for {$X['exam']} $myear."];
    $status = board_result_word($status) ?: strtoupper(trim($status));
    $pct = trim(board_cell($pct));
    if ($status === '' || $status === 'ABSENT') $pct = '';
    if ($e = board_result_error($status, $pct)) return ['ok' => false, 'error' => $e];
    $set = ['result_status' => $status !== '' ? $status : null, 'percentage' => $pct === '' ? null : round((float)$pct, 2)];
    $values = ['status' => $status, 'pct' => board_pct($set['percentage'])];
    foreach ($X['marks'] as $sem => [, $col]) {
        $m = trim(board_cell((string)($marks[$sem] ?? board_pct($row[$col]))));
        if ($e = board_marks_error($m)) return ['ok' => false, 'error' => "Sem $sem " . lcfirst($e)];
        $set[$col] = $m === '' ? null : round((float)$m, 2);
        $values[$col] = board_pct($set[$col]);
    }
    $out = ['ok' => true, 'values' => $values, 'cleared' => !array_filter($values, fn($v) => $v !== '')];
    $same = (string)$row['result_status'] === (string)$set['result_status'];   // a word, the rest are numbers
    foreach ($set as $col => $v) if ($col !== 'result_status' && board_pct($row[$col]) !== board_pct($v)) $same = false;
    if ($same) return $out;
    db_update($X['table'], $set, ['id' => $rid], 'i');
    if (function_exists('log_action')) log_action((int)($_SESSION['admin_id'] ?? 0), 'BOARD_RESULT_SAVED', $X['table'], $rid,
        array_intersect_key($row, $set), ['student' => $row['student_id']] + $set);
    return $out;
}

/** The No.s already given on one admit of an exam year: Roll => [No. as a number => uid] (for Continuation). */
function board_used_nos(string $board, int $myear, int $sem): array {
    if (!board_exam_ready($board) || !isset(BOARD_EXAMS[$board]['admits'][$sem])) return [];
    $X = BOARD_EXAMS[$board];
    [, , $rc, $nc] = board_admit_cols($board, $sem);
    $out = [];
    foreach (db_get_all("SELECT e.$rc AS roll, e.$nc AS no, r.student_id FROM {$X['table']} e JOIN {$X['reg_table']} r ON r.id = e.registration_id
            WHERE e.exam_year = ? AND e.$rc <> '' AND e.$nc <> ''", 'i', $myear) as $r) {
        $out[strtoupper($r['roll'])][(int)$r['no']] = $r['student_id'];
    }
    return $out;
}
/** The next No. of a Roll after the highest one given (1 for a new Roll). */
function board_next_no(array $used, string $roll): int { return isset($used[$roll]) ? max(array_keys($used[$roll])) + 1 : 1; }

/**
 * Our own Madhyamik passes of some students, for their HS registration: uid => [mp_board, mp_year, mp_roll_no] from
 * the latest PASS attempt, the roll as "Roll No." (e.g. "1610N 1233").
 */
function board_own_madhyamik(array $uids): array {
    $uids = array_values(array_filter(array_map('strval', $uids)));
    if (!$uids) return [];
    $out = [];
    foreach (db_get_all("SELECT r.student_id, r.board_type, e.exam_year, e.roll_no, e.index_no FROM secondary_exam e
            JOIN secondary_registration r ON r.id = e.registration_id
            WHERE e.result_status = 'PASS' AND r.student_id IN (" . implode(',', array_fill(0, count($uids), '?')) . ")
            ORDER BY e.exam_year, e.id", str_repeat('s', count($uids)), ...$uids) as $r) {
        $out[$r['student_id']] = ['mp_board' => board_mp_board((string)$r['board_type']) ?? 'Other', 'mp_year' => (string)$r['exam_year'],
                                  'mp_roll_no' => trim($r['roll_no'] . ' ' . $r['index_no'])];
    }
    return $out;
}

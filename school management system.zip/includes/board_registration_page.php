<?php
/**
 * The board page — one for each board: Madhyamik (admin/secondary_registration.php) and Higher Secondary
 * (admin/hs_registration.php). Its steps follow the student through the board's years:
 *   Registration (Class IX / XI)
 *     1 Check data    who is ready for the board's portal, and what is missing — each item opens Edit Student
 *     2 Slip & Excel  verification slips for the guardians, and the sheet for entering the portal
 *     3 Reg. No       the number the board gives — the boys' and the girls' lots come apart — typed (it saves
 *                     itself, assets/js/board_autosave.js) or by Excel; the certificate register
 *   The board exam — includes/board_exam_steps.php
 *     Madhyamik (Class X):  4 Sent up & form, 5 Admit: Roll & No., 6 Result
 *     HS (Class XII):       4 Sent up & form, 5 Sem 3 admit, 6 Sem 4 admit, 7 Result
 * Filters: Session · Class (registration steps) · Section · Show (all, boys, girls) · the exam year (exam steps).
 * Every step has an Excel download; the ones that take data also take the filled sheet back — a preview first, then
 * Save. Missing data is saved through Bulk Update's endpoint, so it is checked exactly like Edit Student.
 */
require_once __DIR__ . '/board_helper.php';
require_once __DIR__ . '/exam_ui.php';
require_once __DIR__ . '/simple_xlsx_writer.php';
require_once __DIR__ . '/logger.php';
require_once __DIR__ . '/board_exam_steps.php';

/** The steps of a board in their groups: the registration class, then the class that sits the board's exam. */
function board_step_groups(string $board): array {
    $exam = ['sentup' => 'Sent up & form'];
    foreach (array_keys(BOARD_EXAMS[$board]['admits']) as $sem) $exam[board_admit_step($sem)] = $sem ? "Sem $sem admit" : 'Admit: Roll & No.';
    return ['reg' => ['check' => 'Check data', 'slip' => 'Slip & Excel', 'regno' => 'Reg. No'], 'exam' => $exam + ['result' => 'Result']];
}

function board_json(array $out): void {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($out, JSON_UNESCAPED_UNICODE);
    exit();
}

function board_go(string $to): void { header("Location: $to"); exit(); }

/** Why an uploaded file is refused ('' when it is fine) — the same rules as the marks upload. */
function board_upload_error($f): string {
    if (!is_array($f) || (int)($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) return 'Choose the .xlsx file to upload.';
    if ($f['size'] > 2 * 1024 * 1024) return 'The file is larger than 2 MB.';
    $mime = ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'];
    if (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'xlsx' || !in_array(mime_content_type($f['tmp_name']), $mime, true)) return 'Only .xlsx files are accepted (save it as an Excel Workbook).';
    return '';
}

/** The upload waiting for its preview / save, when it belongs to this board, kind and list. */
function board_pending(string $board, string $kind, array $ctx): ?array {
    $p = $_SESSION['board_upload'] ?? null;
    return $p && $p['board'] === $board && $p['kind'] === $kind && $p['ctx'] === $ctx && is_file($p['path']) ? $p : null;
}
function board_drop_upload(): void {
    $p = $_SESSION['board_upload'] ?? null;
    if ($p && is_file($p['path'])) @unlink($p['path']);
    unset($_SESSION['board_upload']);
}

/** The rows of an uploaded sheet below its "School UID" heading, as lower-case heading => cell. */
function board_sheet_rows(string $path): array {
    $head = null; $out = [];
    foreach (SimpleXLSXReader::readFirstSheet($path) as $r) {
        if ($head === null) {
            if (strcasecmp(trim((string)($r[0] ?? '')), 'School UID') === 0) $head = array_map(fn($x) => strtolower(trim((string)$x)), $r);
            continue;
        }
        if (!array_filter($r, fn($v) => trim((string)$v) !== '')) continue;
        $row = [];
        foreach ($head as $i => $x) if ($x !== '') $row[$x] = board_cell($r[$i] ?? '');
        $out[] = $row;
    }
    if ($head === null) throw new RuntimeException('This is not a sheet from this page — its "School UID" heading was not found.');
    return $out;
}

/**
 * An uploaded Reg. No sheet against the list: one line per sheet row with its status — new, changed, same, blank
 * (left as it is), error (with why) or outside (not in this list). Matched on the School UID, else on the Banglar
 * Shiksha ID.
 */
function board_regno_plan(string $board, array $students, array $rows, int $year): array {
    $by_bsid = [];
    foreach ($students as $uid => $st) if (($b = student_normalize_bsid($st['banglarshiksha_id'])) !== null) $by_bsid[$b] = $uid;
    $plan = []; $seen = [];
    foreach ($rows as $r) {
        $uid = student_uid_clean($r['school uid'] ?? '');
        if (!isset($students[$uid])) $uid = $by_bsid[student_normalize_bsid($r['banglar shiksha id'] ?? '') ?? ''] ?? '';
        if ($uid === '') { $plan[] = ['status' => 'outside', 'uid' => (string)($r['school uid'] ?? ''), 'name' => (string)($r['student name'] ?? ''), 'why' => 'Not in this list — check the Class and Show (boys / girls).']; continue; }
        $st = $students[$uid];
        $no = board_regno_clean($r['reg. no'] ?? '');
        $y = trim($r['year'] ?? '') !== '' ? trim($r['year']) : (string)$year;
        $line = ['uid' => $uid, 'name' => $st['student_name'], 'old' => trim((string)$st['registration_no']), 'old_year' => (string)$st['registration_year'], 'no' => $no, 'year' => $y];
        if ($no === '') { $plan[] = $line + ['status' => 'blank']; continue; }
        $why = board_regno_error($no) ?: board_year_error($y);
        if (!$why && isset($seen[$no])) $why = "The same number is on another row of the sheet ({$seen[$no]}).";
        if (!$why && ($o = db_get_row('SELECT r.student_id, s.student_name FROM ' . BOARDS[$board]['table'] . ' r JOIN students s ON s.id = r.student_id WHERE r.registration_no = ? AND r.student_id <> ? LIMIT 1', 'ss', $no, $uid))) {
            $why = "$no is already given to {$o['student_name']} ({$o['student_id']}).";
        }
        $seen[$no] = $st['student_name'];
        $status = $why ? 'error' : ($line['old'] === '' ? 'new' : ($line['old'] === $no && $line['old_year'] === $y ? 'same' : 'changed'));
        $plan[] = $line + ['status' => $status, 'why' => $why];
    }
    return $plan;
}

/**
 * An uploaded missing-data sheet against the list: changes (a filled cell that differs from what is saved), each
 * checked the way the board check does. Blank cells are left as they are. Returns [lines, changes, mp, outside]:
 * changes go to Bulk Update's endpoint, mp (Madhyamik board / year / roll) to this page.
 */
function board_fix_plan(string $board, array $students, array $rows): array {
    $cols = board_fix_columns($board);
    $select = array_merge(array_keys(array_filter(student_bulk_fields(), fn($d) => $d['type'] === 'select')), ['mp_board']);   // ISLAM is Islam
    $lines = []; $changes = []; $mp = []; $outside = 0;
    foreach ($rows as $r) {
        $uid = student_uid_clean($r['school uid'] ?? '');
        if (!isset($students[$uid])) { $outside++; continue; }
        $st = $students[$uid]; $mine = [];
        foreach ($cols as $label => $f) {
            $v = trim((string)($r[strtolower($label)] ?? ''));
            if ($v === '') continue;
            if ($f === 'dob') $v = board_cell_date($v);
            if ($f === 'banglarshiksha_id') $v = (string)student_normalize_bsid($v);
            if ($f === 'mp_board') $v = board_mp_board($v) ?? $v;   // wbbse → WBBSE
            $old = trim((string)($st[$f] ?? ''));
            if ($f === 'banglarshiksha_id') $old = (string)student_normalize_bsid($old);
            if ($old === $v || (in_array($f, $select, true) && strcasecmp($old, $v) === 0)) continue;
            $why = str_starts_with($f, 'mp_') ? board_mp_error($f, $v) : board_value_error($f, $v);
            $lines[] = ['uid' => $uid, 'name' => $st['student_name'], 'field' => $f, 'label' => $label,
                        'old' => board_fix_value($st, $f), 'new' => $f === 'dob' ? str_replace('-', '/', board_date($v) ?: $v) : $v, 'why' => $why];
            if ($why !== '') continue;
            if (str_starts_with($f, 'mp_')) $mine[$f] = $v; else $changes[] = ['uid' => $uid, 'field' => $f, 'value' => $v];
        }
        if ($mine) $mp[] = ['uid' => $uid, 'mp' => $mine];
    }
    return [$lines, $changes, $mp, $outside];
}

/** Photo, name and School UID. */
function board_student_cell(array $st): string {
    $img = trim((string)($st['photo'] ?? '')) !== ''
        ? '<img src="../uploads/students/' . rawurlencode($st['photo']) . '" alt="">'
        : '<span class="ph">' . h(mb_substr((string)$st['student_name'], 0, 1)) . '</span>';
    return '<div class="stu">' . $img . '<div><b>' . h($st['student_name']) . '</b><small>' . h($st['uid']) . '</small></div></div>';
}

/** One progress bar: label, done of total; with an id, assets/js/board_autosave.js moves it as rows are saved. */
function board_bar(string $label, int $done, int $total, string $id = '', string $note = ''): string {
    $pct = $total ? round($done / $total * 100) : 0;
    return '<div><div class="lbl"><span>' . h($label) . '</span><b' . ($id !== '' ? ' id="cnt-' . $id . '"' : '') . '>' . $done . ' of ' . $total . '</b></div>'
        . '<div class="bar' . ($total && $done === $total ? ' full' : '') . '"' . ($id !== '' ? ' id="bar-' . $id . '" data-total="' . $total . '"' : '') . '><i style="width:' . $pct . '%"></i></div>'
        . ($note !== '' ? '<div class="sub">' . h($note) . '</div>' : '') . '</div>';
}

/** The Excel downloads of the registration steps. */
function board_download(string $kind, string $board, array $students, string $where, string $file_where, int $year): void {
    $B = BOARDS[$board];
    $sec = fn($st) => (string)$st['section_name'];
    if ($kind === 'fix' || $kind === 'fix_all') {
        $cols = board_fix_columns($board);
        $rows = exam_xlsx_title("{$B['name']} registration — student details · $where", 'Fill in or correct the details, then upload this file on the Check data step. A blank cell is left as it is.');
        $rows[] = array_merge(['School UID', 'Student Name', 'Section', 'Roll'], array_keys($cols));
        foreach ($students as $uid => $st) {
            if ($kind === 'fix' && !board_fixable($st, $board)) continue;
            $rows[] = array_merge([(string)$uid, (string)$st['student_name'], $sec($st), (string)$st['roll_no']], array_map(fn($f) => board_fix_value($st, $f), array_values($cols)));
        }
        SimpleXLSXWriter::download("{$B['name']}_Registration_{$file_where}_details.xlsx", $rows, 'Student details',
            exam_xlsx_opts(4 + count($cols), 22) + ['protect' => true, 'unlocked_cols' => range(5, 4 + count($cols))]);
    }
    if ($kind === 'portal') {
        $head = ['SL', 'School UID', 'Student Name', 'Father Name', 'Mother Name', 'Date of Birth', 'Gender', 'Religion', 'Caste', 'Nationality',
                 'Aadhaar', 'Mobile', 'Village / Town', 'Post Office', 'Police Station', 'District', 'State', 'PIN Code', 'Banglar Shiksha ID', 'PEN', 'APAAR ID', 'Section', 'Roll'];
        if ($board === 'wbchse') array_push($head, 'Madhyamik Board', 'Madhyamik Year', 'Madhyamik Roll', 'HS Subjects');
        $head[] = 'Still missing';
        $rows = exam_xlsx_title("{$B['name']} registration — details for the {$B['board']} portal · $where");
        $rows[] = $head;
        $n = 0;
        foreach ($students as $uid => $st) {
            $row = [++$n, (string)$uid, $st['student_name'], $st['father_name'], $st['mother_name'], board_date($st['dob']), $st['gender'], $st['religion'], $st['caste'], $st['nationality'],
                    $st['student_aadhaar'], board_mobile($st), $st['village'], $st['post_office'], $st['police_station'], $st['district'], $st['state'], $st['pin_code'],
                    $st['banglarshiksha_id'], $st['pen_id'], $st['apaar_id'], $sec($st), $st['roll_no']];
            if ($board === 'wbchse') array_push($row, $st['mp_board'], $st['mp_year'], $st['mp_roll_no'], $st['subject_names']);
            $row[] = implode(', ', array_map(fn($m) => $m[0], board_missing($st, $board)));
            $rows[] = array_map(fn($v) => is_int($v) ? $v : trim((string)$v), $row);
        }
        SimpleXLSXWriter::download("{$B['name']}_Registration_{$file_where}_portal.xlsx", $rows, 'Portal', exam_xlsx_opts(count($head), 24));
    }
    if ($kind === 'regno') {
        $rows = exam_xlsx_title("{$B['name']} registration numbers · $where", 'Type the Reg. No (and Year) the board gave, then upload this file on the Reg. No step. A blank Reg. No is left as it is.');
        $rows[] = ['School UID', 'Student Name', 'Section', 'Roll', 'Banglar Shiksha ID', 'Reg. No', 'Year'];
        foreach ($students as $uid => $st) {
            $rows[] = [(string)$uid, (string)$st['student_name'], $sec($st), (string)$st['roll_no'], (string)$st['banglarshiksha_id'],
                       (string)$st['registration_no'], (string)($st['registration_year'] ?: $year)];
        }
        SimpleXLSXWriter::download("{$B['name']}_Registration_{$file_where}_numbers.xlsx", $rows, 'Reg No', exam_xlsx_opts(7, 22) + ['protect' => true, 'unlocked_cols' => [6, 7]]);
    }
    if ($kind === 'register') {
        $rows = exam_xlsx_title("{$B['name']} registration certificates — distribution register · $where");
        $rows[] = ['#', 'School UID', 'Student Name', 'Father Name', 'Section', 'Roll', 'Reg. No', 'Year', 'Date received', 'Signature'];
        $n = 0;
        foreach ($students as $uid => $st) {
            $rows[] = [++$n, (string)$uid, (string)$st['student_name'], (string)$st['father_name'], $sec($st), (string)$st['roll_no'], (string)$st['registration_no'], (string)$st['registration_year'], '', ''];
        }
        SimpleXLSXWriter::download("{$B['name']}_Registration_{$file_where}_register.xlsx", $rows, 'Register', exam_xlsx_opts(10, 24));
    }
}

/** The student's own mobile, else the father's, else the guardian's. */
function board_mobile(array $st): string {
    return trim((string)$st['mobile']) ?: (trim((string)$st['father_mobile']) ?: trim((string)$st['guardian_contact']));
}

/** Has the student something missing that the student-details sheet can fill in? */
function board_fixable(array $st, string $board): bool {
    $in_sheet = array_values(board_fix_columns($board));
    foreach (board_missing($st, $board) as $key => $m) {
        $first = board_checks($board)[$key][1][0];
        if (in_array($first, $in_sheet, true) || $first === 'madhyamik') return true;
    }
    return false;
}

function board_registration_page(string $board, string $self): void {
    $B = BOARDS[$board];
    $in = fn(string $k) => $_POST[$k] ?? $_GET[$k] ?? null;   // a form posts the same context the address carries
    $groups = board_step_groups($board);
    $step = (string)($in('step') ?? 'check');
    if ($step === 'cert') $step = 'regno';   // the certificate register now lives on Reg. No
    $group = isset($groups['exam'][$step]) ? 'exam' : 'reg';
    if (!isset($groups[$group][$step])) $step = 'check';
    $sessions = exam_sessions();
    $session_id = (int)$in('session_id');
    if (!isset($sessions[$session_id])) $session_id = (int)array_key_first($sessions);
    $classes = board_classes($board);
    $reg_class = board_reg_class($board);
    $exam_class = board_exam_class($board);
    $class_id = $group === 'exam' ? $exam_class : (int)$in('class_id');
    if (!isset($classes[$class_id])) $class_id = $reg_class;
    $sections = $class_id ? array_column(db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id), 'section_name', 'id') : [];
    $section_id = (int)$in('section_id');
    if (!isset($sections[$section_id])) $section_id = 0;
    $show = (string)($in('g') ?? '');
    if (!isset(BOARD_SHOW[$show])) $show = '';
    $gender = board_gender($show);
    $myear = 0;
    if (isset($groups['exam']) && $exam_class) {
        $y = (int)$in('myear');
        $myear = board_exam_year_ok($y) ? $y : board_exam_year_default($board, $session_id, $exam_class);
    }
    $order = $step === 'regno' && in_array($in('order'), ['name', 'regno'], true) ? (string)$in('order') : '';
    $year = board_session_year($session_id);
    $ctx = [$session_id, $class_id, $section_id, $show, $group === 'exam' ? $myear : 0];
    // the address of a step: the context travels along; the class and section only while the class stays the same
    $link = function (string $s, array $p = []) use ($self, $groups, $group, $session_id, $show, $class_id, $reg_class, $exam_class, $section_id, $myear): string {
        $exam = isset($groups['exam'][$s]);
        $to_class = $exam ? $exam_class : ($group === 'reg' ? $class_id : $reg_class);
        $q = ['session_id' => $session_id, 'class_id' => $exam ? null : $to_class, 'section_id' => $to_class === $class_id && $section_id ? $section_id : null,
              'g' => $show !== '' ? $show : null, 'step' => $s, 'myear' => $exam ? $myear : null];
        return $self . '?' . http_build_query(array_merge($q, $p));
    };
    $url = fn(array $p = []) => $link($step, ($order !== '' ? ['order' => $order] : []) + $p);
    // the context as hidden fields, for every form of the page
    $hidden = function (array $extra = []) use ($session_id, $section_id, $show, $step, $group, $myear, $class_id, $order): string {
        $f = ['session_id' => $session_id, 'section_id' => $section_id ?: '', 'g' => $show, 'step' => $step]
           + ($group === 'exam' ? ['myear' => $myear] : ['class_id' => $class_id]) + ($order !== '' ? ['order' => $order] : []) + $extra;
        $s = csrf_field();
        foreach ($f as $k => $v) $s .= '<input type="hidden" name="' . h($k) . '" value="' . h((string)$v) . '">';
        return $s;
    };
    $upload_form = function (string $kind, string $label) use ($hidden) { ?>
        <form method="post" enctype="multipart/form-data" class="up">
            <?php echo $hidden(); ?>
            <input type="file" name="file" accept=".xlsx" required>
            <button type="submit" name="upload" value="<?php echo h($kind); ?>" class="btn btn-sm btn-primary"><i class="fas fa-upload"></i> <?php echo h($label); ?></button>
        </form>
    <?php };
    $print = fn(string $what, array $p = []) => 'board_print.php?' . http_build_query(array_merge(['board' => $board, 'what' => $what, 'session_id' => $session_id,
        'class_id' => $class_id, 'section_id' => $section_id ?: null, 'g' => $show !== '' ? $show : null], $p));
    $where = 'Class ' . ($classes[$class_id] ?? '') . ($section_id ? '-' . $sections[$section_id] : '') . ($show !== '' ? ' · ' . BOARD_SHOW[$show] : '')
           . ' · ' . exam_session_name($session_id) . ($group === 'exam' ? ' · ' . BOARD_EXAMS[$board]['exam'] . ' ' . $myear : '');
    $file_where = trim(preg_replace('/[^A-Za-z0-9]+/', '_', ($classes[$class_id] ?? '') . ($section_id ? '_' . $sections[$section_id] : '') . ($show !== '' ? '_' . BOARD_SHOW[$show] : '')
                . '_' . ($group === 'exam' ? BOARD_EXAMS[$board]['exam'] . '_' . $myear : exam_session_name($session_id))), '_');
    $bp = compact('board', 'B', 'self', 'session_id', 'class_id', 'section_id', 'show', 'gender', 'step', 'myear', 'year', 'where', 'file_where', 'ctx',
                 'link', 'url', 'hidden', 'upload_form', 'print', 'exam_class');

    // ---- the JSON endpoints: one row saved by board_autosave.js, and the Madhyamik details of an HS sheet ----
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['autosave']) || isset($_POST['mp_save']))) {
        if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) board_json(['ok' => false, 'error' => 'This page is too old — reload it.']);
        if (isset($_POST['autosave'])) {
            $kind = (string)($_POST['kind'] ?? 'regno');
            if ($kind === 'admit' || $kind === 'result') {
                if (!$myear) board_json(['ok' => false, 'error' => 'This page has no exam steps.']);
                $rid = (int)($_POST['rid'] ?? 0);
                $sem = board_step_sem($step);
                if ($kind === 'admit') board_json($sem === null ? ['ok' => false, 'error' => 'Not an admit step.']
                    : board_save_admit($board, $rid, $myear, $sem, (string)($_POST['roll'] ?? ''), (string)($_POST['no'] ?? '')));
                $marks = [];   // only the semesters posted; the others stay as they are
                foreach (BOARD_EXAMS[$board]['marks'] as $m => [, $col]) if (isset($_POST[$col])) $marks[$m] = (string)$_POST[$col];
                board_json(board_save_result($board, $rid, $myear, (string)($_POST['status'] ?? ''), (string)($_POST['pct'] ?? ''), $marks));
            }
            $uid = student_uid_clean($_POST['uid'] ?? '');
            if ($uid === '' || !board_student_in($session_id, $class_id, $uid)) board_json(['ok' => false, 'error' => 'Not a student of this class.']);
            $r = board_save_regno($board, $uid, (string)($_POST['reg_no'] ?? ''), (string)($_POST['reg_year'] ?? ''));
            board_json($r['ok'] ? ['ok' => true, 'values' => ['reg_no' => $r['no'], 'reg_year' => $r['year']], 'cleared' => !empty($r['cleared'])] : $r);
        }
        $results = [];
        foreach ((array)(json_decode((string)($_POST['rows'] ?? ''), true) ?: []) as $r) {
            $uid = student_uid_clean(is_array($r) ? ($r['uid'] ?? '') : '');
            if ($uid === '') continue;
            $mp = array_map(fn($v) => is_scalar($v) ? trim((string)$v) : '', (array)($r['mp'] ?? []));
            $results[$uid] = board_student_in($session_id, $class_id, $uid) ? board_mp_save($uid, $mp) : 'Not a student of this class.';
        }
        board_json(['ok' => true, 'results' => $results]);
    }

    // ---- forms: uploads (kept for their preview), saves from a preview, the exam steps' own forms ----
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        verify_csrf_or_die();
        if (isset($_POST['cancel'])) { board_drop_upload(); board_go($url()); }
        if (isset($_POST['upload'])) {
            $up = (string)$_POST['upload'];   // a step that takes a sheet: Reg. No, this board's admits, the result
            $kind = $up === 'regno' || ($up !== 'sentup' && isset($groups['exam'][$up])) ? $up : 'fix';
            $back = $link($kind === 'fix' ? 'check' : $kind, $order !== '' ? ['order' => $order] : []);
            if ($e = board_upload_error($_FILES['file'] ?? null)) { $_SESSION['error'] = $e; board_go($back); }
            board_drop_upload();
            $dest = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'board_' . bin2hex(random_bytes(12)) . '.xlsx';
            if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) { $_SESSION['error'] = 'The file could not be kept for the preview — try again.'; board_go($back); }
            $_SESSION['board_upload'] = ['board' => $board, 'kind' => $kind, 'ctx' => $ctx, 'path' => $dest, 'name' => basename((string)$_FILES['file']['name'])];
            board_go($back . '&preview=1');
        }
        if (isset($_POST['confirm_regno'])) {
            $p = board_pending($board, 'regno', $ctx);
            if (!$p) { $_SESSION['error'] = 'That upload is gone — upload the sheet again.'; board_go($url()); }
            try {
                $plan = board_regno_plan($board, board_students($board, $session_id, $class_id, $section_id, $gender), board_sheet_rows($p['path']), $year);
            } catch (Throwable $e) { $_SESSION['error'] = 'Could not read the file: ' . $e->getMessage(); board_drop_upload(); board_go($url()); }
            $saved = 0; $bad = [];
            foreach ($plan as $l) {
                if (!in_array($l['status'], ['new', 'changed'], true)) continue;
                $r = board_save_regno($board, $l['uid'], $l['no'], $l['year']);
                if ($r['ok']) $saved++; else $bad[] = "{$l['name']}: {$r['error']}";
            }
            board_drop_upload();
            $_SESSION['success'] = "$saved registration number(s) saved from the sheet.";
            if ($bad) $_SESSION['error'] = count($bad) . ' not saved — ' . implode(' · ', array_slice($bad, 0, 5)) . (count($bad) > 5 ? ' …' : '');
            board_go($url());
        }
        if (isset($_POST['mp_fill']) && $board === 'wbchse') {   // our own Madhyamik passes into the HS form
            $students = board_students($board, $session_id, $class_id, $section_id, $gender);
            $filled = 0; $bad = [];
            foreach (board_own_madhyamik(array_keys($students)) as $uid => $mp) {
                $blank = array_filter($mp, fn($v, $f) => trim((string)($students[$uid][$f] ?? '')) === '', ARRAY_FILTER_USE_BOTH);
                if (!$blank) continue;
                $e = board_mp_save($uid, $blank);
                if ($e === '') $filled++; else $bad[] = "{$students[$uid]['student_name']}: $e";
            }
            $_SESSION['success'] = "Madhyamik details filled in for $filled student(s) from our own records.";
            if ($bad) $_SESSION['error'] = implode(' · ', array_slice($bad, 0, 5));
            board_go($url());
        }
        if ($group === 'exam') board_exam_post($bp);   // it answers its own forms with a redirect
        board_go($url());
    }

    // ---- the list, the downloads ----
    $students = [];
    if ($group === 'reg' && $class_id) {
        $students = board_students($board, $session_id, $class_id, $section_id, $gender);
        if ($order === 'name') uasort($students, fn($a, $b) => strcasecmp($a['student_name'], $b['student_name']));
        if ($order === 'regno') uasort($students, fn($a, $b) => (trim((string)$a['registration_no']) === '') <=> (trim((string)$b['registration_no']) === '')
                                                               ?: strnatcasecmp((string)$a['registration_no'], (string)$b['registration_no']));
    }
    if (isset($_GET['download'])) {
        $kind = (string)$_GET['download'];
        if ($group === 'reg' && $students && in_array($kind, ['fix', 'portal', 'regno', 'register'], true)) {
            board_download($kind === 'fix' && !empty($_GET['all']) ? 'fix_all' : $kind, $board, $students, $where, $file_where, $year);
        }
        if ($group === 'exam') board_exam_download($bp, $kind);
    }

    // ---- what the page shows ----
    $pending = !empty($_GET['preview']) ? board_pending($board, $step === 'check' ? 'fix' : $step, $ctx) : null;
    $preview_error = '';
    $sheet = [];
    if ($pending) {
        try {
            $sheet = board_sheet_rows($pending['path']);
            $cols = array_keys($sheet[0] ?? []);
            $sem = board_step_sem($step);
            $admit = $sem !== null ? array_map('strtolower', array_slice(board_admit_cols($board, $sem), 0, 2)) : [];   // its Roll and No. headings
            $wrong = match (true) {
                $step === 'check' => in_array('reg. no', $cols, true) || !array_intersect(array_map('strtolower', array_keys(board_fix_columns($board))), $cols),
                // every sheet has a Roll (the class roll, or an admit's): the Reg. No sheet is told by its Year, an admit
                // sheet by its own headings (HS: "Sem 3 Roll" is not "Sem 4 Roll")
                $step === 'regno' => !in_array('reg. no', $cols, true) || !in_array('year', $cols, true) || in_array('no.', $cols, true),
                $step === 'result' => !in_array('result', $cols, true),
                (bool)$admit => (bool)array_diff($admit, $cols) || in_array('result', $cols, true),
                default => false,
            };
            if ($sheet && $wrong) {
                throw new RuntimeException(match (true) {
                    $step === 'check' && in_array('reg. no', $cols, true) => 'this is not the student-details sheet. Upload it on its own step.',
                    $step === 'check' => 'it has none of the student-detail columns. Upload the sheet from this step\'s Download missing details button.',
                    default => 'it is not the sheet of this step. Upload the one from this step\'s Download sheet button.',
                });
            }
        } catch (Throwable $e) { $preview_error = 'Could not use the file: ' . $e->getMessage(); $pending = null; board_drop_upload(); }
    }
    $bp += compact('pending', 'sheet');
    $bars = []; $hints = [];
    $missing = []; $total = $ready = $registered = $fixable = 0; $own = [];
    if ($group === 'reg') {
        foreach ($students as $uid => $st) $missing[$uid] = board_missing($st, $board);
        $total = count($students);
        $ready = count(array_filter($missing, fn($m) => !$m));
        $registered = count(array_filter($students, fn($st) => trim((string)$st['registration_no']) !== ''));
        $fixable = count(array_filter($students, fn($st) => board_fixable($st, $board)));
        $lots = '';
        if ($show === '' && $total) {
            $by = ['Male' => [0, 0], 'Female' => [0, 0]];
            foreach ($students as $st) if (isset($by[$st['gender']])) { $by[$st['gender']][0]++; if (trim((string)$st['registration_no']) !== '') $by[$st['gender']][1]++; }
            $lots = "Boys {$by['Male'][1]} of {$by['Male'][0]} · Girls {$by['Female'][1]} of {$by['Female'][0]}";
        }
        $bars = [board_bar('Ready for the portal', $ready, $total), board_bar('Registered (Reg. No given)', $registered, $total, 'regno', $lots)];
        $hints = ['check' => [$total - $ready ? ($total - $ready) . ' to fix' : ($total ? 'all ready' : ''), $total > 0 && $ready === $total],
                  'slip' => ['print · portal sheet', false],
                  'regno' => [$total - $registered ? ($total - $registered) . ' to go' : ($total ? 'all done' : ''), $total > 0 && $registered === $total]];
        if ($board === 'wbchse' && $step === 'check') $own = board_own_madhyamik(array_keys(array_filter($missing, fn($m) => isset($m['madhyamik']))));
    } else {
        $d = board_exam_data($bp);
        [$bars, $hints] = board_exam_progress($bp, $d);
        $bp['data'] = $d;
    }
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($B['name']); ?> (<?php echo h($B['board']); ?>)</title>
<?php exam_styles($B['theme']); ?>
<style>
    .prog { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 12px 26px; }
    .prog .lbl { display: flex; justify-content: space-between; align-items: baseline; font-size: 13px; color: #3b5168; margin-bottom: 6px; } .prog .lbl b { color: var(--ex-dark); font-size: 16px; }
    .prog .sub { font-size: 11.5px; color: #6b7d90; margin-top: 5px; }
    .bar { height: 10px; background: #edf1f5; border-radius: 99px; overflow: hidden; } .bar i { display: block; height: 100%; background: var(--ex-light); border-radius: 99px; transition: width .3s; } .bar.full i { background: #2e9e57; }
    .ex-steps .grp { align-self: center; font-size: 10.5px; font-weight: 800; letter-spacing: .5px; text-transform: uppercase; color: #6b7d90; margin: 0 2px 0 6px; }
    .ex-steps .grp:first-child { margin-left: 0; }
    .pick .fixed { height: 38px; display: flex; align-items: center; padding: 0 12px; border: 1px dashed #c9d6e2; border-radius: 7px; font-size: 13.5px; color: #3b5168; background: #f8fafc; }
    .pick input[type=number] { min-width: 0; width: 120px; }
    .tools { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; margin-bottom: 10px; }
    .tools input[type=search] { height: 36px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 8px; min-width: 230px; font-size: 13.5px; }
    .tools select { height: 36px; padding: 4px 8px; border: 1px solid #c9d6e2; border-radius: 8px; font-size: 13px; background: #fff; }
    .tools .tog { display: inline-flex; gap: 6px; align-items: center; font-size: 13px; color: #3b5168; cursor: pointer; }
    .tools .right { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
    .up { display: inline-flex; gap: 6px; align-items: center; border: 1px dashed var(--ex-border); border-radius: 9px; padding: 4px 6px; background: var(--ex-soft); margin: 0; }
    .up input[type=file] { font-size: 12px; max-width: 210px; }
    .stu { display: flex; align-items: center; gap: 10px; } .stu img, .stu .ph { width: 34px; height: 40px; border-radius: 6px; object-fit: cover; flex: none; background: var(--ex-soft); border: 1px solid var(--ex-border); display: inline-flex; align-items: center; justify-content: center; font-weight: 700; color: var(--ex-dark); }
    .stu b { display: block; font-size: 13px; } .stu small { color: #7a8a9a; font-size: 11px; }
    .ex-table .chip { margin: 2px 4px 2px 0; text-decoration: none; display: inline-block; } .why { color: #7a4a00; font-size: 11px; margin-right: 8px; }
    .ex-table input.bx { height: 34px; padding: 4px 8px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 14px; letter-spacing: .4px; }
    .ex-table input.rn { width: 180px; } .ex-table input.ry { width: 72px; text-align: center; } .ex-table input.rl { width: 110px; text-transform: uppercase; } .ex-table input.no { width: 90px; } .ex-table input.pc { width: 76px; text-align: center; }
    .ex-table select.bx { height: 34px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 13.5px; padding: 2px 6px; background: #fff; }
    .ex-table .bx:focus { outline: 2px solid var(--ex-light); border-color: var(--ex-light); }
    td.sv { font-size: 12px; white-space: nowrap; min-width: 90px; } .sv-saved, .sv-cleared, td.res.ok { color: #1b7a3a; font-weight: 600; } .sv-saving { color: #7a8a9a; } .sv-failed, .sv-offline, td.res.bad { color: #b71c1c; font-weight: 600; }
    .sv-sum { font-weight: 700; font-size: 13px; } .sv-left { color: #b71c1c; } .sv-ok { color: #1b7a3a; }
    .shown { font-size: 12.5px; color: #6b7d90; }
    .stats { display: flex; gap: 8px; flex-wrap: wrap; margin: 6px 0 12px; } .stats span { padding: 6px 12px; border-radius: 9px; background: var(--ex-soft); border: 1px solid var(--ex-border); font-size: 12.5px; } .stats b { font-size: 17px; display: block; color: var(--ex-dark); } .stats .bad b { color: #b71c1c; }
    .acts { display: grid; grid-template-columns: repeat(auto-fit, minmax(270px, 1fr)); gap: 14px; }
    .act { border: 1px solid #dfe7ef; border-radius: 14px; padding: 16px 18px; background: #fff; } .act h3 { margin: 0 0 6px; font-size: 15px; color: var(--ex-dark); } .act p { font-size: 12.5px; color: #5b6b7c; margin: 0 0 12px; line-height: 1.55; } .act .btns { display: flex; gap: 8px; flex-wrap: wrap; }
    tr.todo td { background: #fffaf0; } .dim { color: #8a98a8; }
    .cont { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; background: var(--ex-soft); border: 1px solid var(--ex-border); border-radius: 12px; padding: 10px 12px; margin-bottom: 10px; }
    .cont b { color: var(--ex-dark); font-size: 13.5px; } .cont label { font-size: 12px; font-weight: 700; color: #3b5168; display: inline-flex; gap: 6px; align-items: center; }
    .cont input { height: 34px; padding: 4px 8px; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 14px; width: 110px; } .cont small { color: #5b6b7c; font-size: 11.5px; flex-basis: 100%; }
    td.tk { width: 34px; text-align: center; } td.tk input { width: 18px; height: 18px; cursor: pointer; }
    .chip.hand { background: #eef0ff; color: #3a3f9a; border: 1px solid #c9ccf5; }
    h3.sub { font-size: 14px; color: var(--ex-dark); margin: 16px 0 8px; }
    @media (max-width: 700px) { .tools .right { margin-left: 0; } .tools input[type=search] { min-width: 0; width: 100%; } .ex-table input.rn { width: 130px; } }
</style>
</head>
<body>
<?php global $conn; include __DIR__ . '/navbar.php';   // the menu reads the connection as a page-level variable ?>
<div class="page-box">
    <?php exam_banner($B['name'] . ' (' . $B['board'] . ')', $where, 'fa-id-badge'); ?>
    <?php exam_flash(); ?>
    <?php if ($preview_error): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo h($preview_error); ?></div><?php endif; ?>

    <form method="get" class="card noprint"><div class="pick">
        <input type="hidden" name="step" value="<?php echo h($step); ?>">
        <?php if ($order !== ''): ?><input type="hidden" name="order" value="<?php echo h($order); ?>"><?php endif; ?>
        <div><label>Session</label><select name="session_id" onchange="if(this.form.myear)this.form.myear.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <?php if ($group === 'reg'): ?>
            <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($n) => "Class $n", $classes), $class_id); ?></select></div>
        <?php else: ?>
            <div><label>Class</label><div class="fixed">Class <?php echo h($classes[$exam_class]); ?></div></div>
        <?php endif; ?>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()"><?php echo exam_options($sections, $section_id, 'All sections'); ?></select></div>
        <div><label>Show</label><select name="g" onchange="this.form.submit()"><?php echo exam_options(BOARD_SHOW, $show); ?></select></div>
        <?php if ($group === 'exam'): ?>
            <div><label><?php echo h(BOARD_EXAMS[$board]['exam']); ?> year</label><input type="number" name="myear" value="<?php echo $myear; ?>" min="2000" max="<?php echo (int)date('Y') + 2; ?>" onchange="this.form.submit()" title="The year of the <?php echo h(BOARD_EXAMS[$board]['exam']); ?> exam — not the session"></div>
        <?php elseif ($step === 'regno'): ?>
            <div><label>Order</label><select name="order" onchange="this.form.submit()"><?php echo exam_options(['' => 'Section · Roll', 'name' => 'Name', 'regno' => 'Reg. No'], $order); ?></select></div>
        <?php endif; ?>
    </div></form>

    <?php if (!$class_id): ?>
        <?php exam_guard('No class to register', 'Classes ' . implode(' and ', $B['classes']) . ' are not set up yet.', 'classes.php', 'Classes'); ?>
    <?php else: ?>

    <div class="card prog"><?php echo implode('', $bars); ?></div>

    <div class="ex-steps">
        <?php $i = 0; foreach ($groups as $gk => $list): ?>
            <span class="grp"><?php echo h($gk === 'reg' ? 'Class ' . $classes[$reg_class] . ' · Registration' : 'Class ' . $classes[$exam_class] . ' · ' . BOARD_EXAMS[$board]['exam'] . ' ' . $myear); ?></span>
            <?php foreach ($list as $k => $label): $i++; [$hint, $done] = $hints[$k] ?? ['', false]; ?>
                <a href="<?php echo h($link($k)); ?>" class="<?php echo $k === $step ? 'on' : ($done ? 'ok' : ''); ?>" title="<?php echo h($hint); ?>"><b><?php echo $done && $k !== $step ? '&#10003;' : $i; ?></b> <?php echo h($label); ?><?php if ($hint !== ''): ?> <small><?php echo h($hint); ?></small><?php endif; ?></a>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </div>

    <?php if ($group === 'exam'): ?>
        <?php board_exam_view($bp); ?>

    <?php elseif (!$total): ?>
        <div class="ex-empty"><i class="fas fa-user-slash"></i>No Active students in <?php echo h($where); ?>.</div>

    <?php elseif ($step === 'check' && $pending): [$lines, $changes, $mp, $outside] = board_fix_plan($board, $students, $sheet); $problems = count(array_filter($lines, fn($l) => $l['why'] !== '')); ?>
    <div class="card">
        <h2>Check the changes before saving <small>from <?php echo h($pending['name']); ?></small></h2>
        <div class="stats">
            <span><b><?php echo count($lines) - $problems; ?></b>changes to save</span>
            <span><b><?php echo count(array_unique(array_column($lines, 'uid'))); ?></b>students</span>
            <span class="<?php echo $problems ? 'bad' : ''; ?>"><b><?php echo $problems; ?></b>with a problem (not saved)</span>
            <?php if ($outside): ?><span class="bad"><b><?php echo $outside; ?></b>rows not in this list (skipped)</span><?php endif; ?>
        </div>
        <?php if (!$lines): ?>
            <div class="ex-empty"><i class="fas fa-check-circle"></i>Nothing in the sheet differs from what is saved.</div>
        <?php else: ?>
        <div class="table-responsive"><table class="ex-table" id="fixTable">
            <thead><tr><th>Student</th><th>Detail</th><th>Now</th><th>New</th><th>Result</th></tr></thead>
            <tbody>
            <?php foreach ($lines as $l): ?>
                <tr data-uid="<?php echo h($l['uid']); ?>" data-field="<?php echo h($l['field']); ?>">
                    <td><b><?php echo h($l['name']); ?></b><br><small class="dim"><?php echo h($l['uid']); ?></small></td>
                    <td><?php echo h($l['label']); ?></td>
                    <td><?php echo $l['old'] !== '' ? h($l['old']) : '<span class="dim">blank</span>'; ?></td>
                    <td><b><?php echo h($l['new']); ?></b></td>
                    <td class="res<?php echo $l['why'] !== '' ? ' bad' : ''; ?>"><?php echo $l['why'] !== '' ? '✗ ' . h(ucfirst($l['why'])) : 'Ready to save'; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php endif; ?>
        <div class="tools" style="margin-top:14px">
            <?php if ($lines && count($lines) > $problems): ?><button type="button" class="btn btn-success" id="saveFix"><i class="fas fa-save"></i> Save <?php echo count($lines) - $problems; ?> change(s)</button><?php endif; ?>
            <span id="fixOut" class="sv-sum"></span>
            <form method="post" class="right" style="margin:0"><?php echo $hidden(); ?>
                <button type="submit" name="cancel" value="1" class="btn btn-secondary" id="fixFinish"><i class="fas fa-arrow-left"></i> Back to Check data</button>
            </form>
        </div>
    </div>
    <script>
    (function () {   // student details go to Bulk Update's endpoint (≤ 250 students a request), Madhyamik details to this page
        var D = <?php echo json_encode(['csrf' => csrf_token(), 'session_id' => $session_id, 'class_id' => $class_id, 'changes' => $changes, 'mp' => $mp], JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE); ?>;
        var btn = document.getElementById('saveFix'), out = document.getElementById('fixOut');
        if (!btn) return;
        var saved = 0, failed = 0;
        function mark(uid, field, ok, msg) {
            Array.prototype.forEach.call(document.querySelectorAll('#fixTable tr[data-uid="' + CSS.escape(uid) + '"][data-field="' + CSS.escape(field) + '"] td.res'), function (td) {
                td.className = 'res ' + (ok ? 'ok' : 'bad'); td.textContent = ok ? '✓ Saved' : '✗ ' + (msg || 'Not saved');
            });
            if (ok) saved++; else failed++;
        }
        btn.addEventListener('click', function () {
            btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving…';
            var by = {}, chunks = [];
            D.changes.forEach(function (c) { (by[c.uid] = by[c.uid] || []).push(c); });
            var uids = Object.keys(by);
            for (var i = 0; i < uids.length; i += 250) chunks.push([].concat.apply([], uids.slice(i, i + 250).map(function (u) { return by[u]; })));
            chunks.reduce(function (p, chunk) {
                return p.then(function () {
                    return fetch('bulk_update_save.php', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ csrf: D.csrf, session_id: D.session_id, changes: chunk }) })
                        .then(function (r) { return r.json(); })
                        .then(function (res) {
                            if (!res.ok) { chunk.forEach(function (c) { mark(c.uid, c.field, false, res.error); }); return; }
                            res.cells.forEach(function (c) { mark(c.uid, c.field, c.ok, c.error); });
                        });
                });
            }, Promise.resolve()).then(function () {
                if (!D.mp.length) return;
                var fd = new FormData();
                fd.append('mp_save', '1'); fd.append('csrf_token', D.csrf); fd.append('session_id', D.session_id); fd.append('class_id', D.class_id); fd.append('rows', JSON.stringify(D.mp));
                return fetch(location.pathname, { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (res) {
                        D.mp.forEach(function (m) {
                            var e = res && res.results ? res.results[m.uid] : (res && res.error) || 'Not saved';
                            Object.keys(m.mp).forEach(function (f) { mark(m.uid, f, e === '', e); });
                        });
                    });
            }).catch(function () {
                failed++; out.textContent = 'The connection was lost — upload the sheet again to see what is still to save.';
            }).then(function () {
                btn.innerHTML = '<i class="fas fa-check"></i> Done';
                if (!out.textContent) out.textContent = saved + ' change(s) saved' + (failed ? ' · ' + failed + ' not saved (see the list)' : '') + '.';
                out.className = 'sv-sum ' + (failed ? 'sv-left' : 'sv-ok');
            });
        });
    })();
    </script>

    <?php elseif ($step === 'check'): ?>
    <div class="card">
        <div class="tools noprint">
            <input type="search" id="q" placeholder="Search name or School UID">
            <label class="tog"><input type="checkbox" id="only"<?php echo $ready < $total ? ' checked' : ''; ?>> Only not ready</label>
            <span class="shown" id="shown"></span>
            <span class="right">
                <?php if ($own): ?><form method="post" style="margin:0"><?php echo $hidden(); ?><button type="submit" name="mp_fill" value="1" class="btn btn-sm btn-primary" title="Madhyamik board, year and Roll-No. of the ones who passed from this school"><i class="fas fa-magic"></i> Fill Madhyamik details from our records (<?php echo count($own); ?>)</button></form><?php endif; ?>
                <?php if ($fixable): ?><a class="btn btn-sm btn-success" href="<?php echo h($url(['download' => 'fix'])); ?>"><i class="fas fa-file-excel"></i> Download missing details (<?php echo $fixable; ?>)</a><?php endif; ?>
                <a class="btn btn-sm btn-secondary" href="<?php echo h($url(['download' => 'fix', 'all' => 1])); ?>"><i class="fas fa-file-excel"></i> All students</a>
                <?php $upload_form('fix', 'Upload filled sheet'); ?>
            </span>
        </div>
        <p class="note" style="margin:0 0 10px"><span class="chip bad">Red</span> is missing, <span class="chip warn">amber</span> is filled in but will not do. Click one to fix it in Edit Student (a new tab) — this list checks again when you come back. Photos and signatures for a whole section: <a href="<?php echo h('student_bulk_update.php?' . http_build_query(['session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $section_id ?: null])); ?>" target="_blank" class="fix">Bulk Update → Photo Booth</a>.</p>
        <div class="table-responsive"><table class="ex-table" id="list">
            <thead><tr><th class="num">#</th><th>Student</th><th>Section · Roll</th><th>What the board still needs</th><th></th></tr></thead>
            <tbody>
            <?php $n = 0; foreach ($students as $uid => $st): $m = $missing[$uid]; $edit = student_page_url('edit_student.php', $uid); ?>
                <tr data-s="<?php echo h(mb_strtolower($st['student_name'] . ' ' . $uid)); ?>" data-done="<?php echo $m ? 0 : 1; ?>">
                    <td class="num"><?php echo ++$n; ?></td>
                    <td><?php echo board_student_cell($st); ?></td>
                    <td><?php echo h(($st['section_name'] ?? '—') . ' · ' . ($st['roll_no'] ?? '—')); ?></td>
                    <td><?php if (!$m): ?><span class="chip ok"><i class="fas fa-check"></i> Ready</span>
                        <?php else: foreach ($m as [$label, $why]): ?><a class="chip <?php echo $why === '' ? 'bad' : 'warn'; ?> fix" target="_blank" href="<?php echo h($edit); ?>" title="<?php echo h($why === '' ? "$label is missing" : "$label: $why"); ?>"><?php echo h($label); ?></a><?php if ($why !== ''): ?><span class="why"><?php echo h($why); ?></span><?php endif; ?><?php endforeach; endif; ?></td>
                    <td><a class="btn btn-sm btn-secondary fix" target="_blank" href="<?php echo h($edit); ?>"><i class="fas fa-pen"></i> Edit</a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <div class="ex-empty" id="none" hidden><i class="fas fa-check-circle"></i>Everyone here is ready for the portal.</div>
    </div>

    <?php elseif ($step === 'slip'): ?>
    <div class="acts">
        <div class="act">
            <h3><i class="fas fa-print"></i> Verification slips</h3>
            <p>One A4 page per student with the photo, the signature and every detail the board asks for, and lines for the student, the guardian and the class teacher to sign. The guardian checks it, writes any correction on it and signs — before anything goes into the portal. A blank line is something still missing.</p>
            <div class="btns">
                <a class="btn btn-primary" target="_blank" href="<?php echo h($print('slips')); ?>"><i class="fas fa-print"></i> All students (<?php echo $total; ?>)</a>
                <?php if ($ready && $ready < $total): ?><a class="btn btn-secondary" target="_blank" href="<?php echo h($print('slips', ['only' => 'ready'])); ?>">Only ready (<?php echo $ready; ?>)</a><?php endif; ?>
                <?php if ($ready < $total): ?><a class="btn btn-secondary" target="_blank" href="<?php echo h($print('slips', ['only' => 'notready'])); ?>">Only not ready (<?php echo $total - $ready; ?>)</a><?php endif; ?>
            </div>
        </div>
        <div class="act">
            <h3><i class="fas fa-file-excel"></i> Sheet for the <?php echo h($B['board']); ?> portal</h3>
            <p>Every student's details in one Excel sheet, in the order the portal asks for them, with a last column saying what is still missing — keep it open beside the portal while entering.</p>
            <div class="btns"><a class="btn btn-success" href="<?php echo h($url(['download' => 'portal'])); ?>"><i class="fas fa-file-excel"></i> Download portal sheet (<?php echo $total; ?>)</a></div>
        </div>
    </div>

    <?php elseif ($step === 'regno' && $pending): $plan = board_regno_plan($board, $students, $sheet, $year); $cnt = array_count_values(array_column($plan, 'status')); $todo = ($cnt['new'] ?? 0) + ($cnt['changed'] ?? 0); ?>
    <div class="card">
        <h2>Check the numbers before saving <small>from <?php echo h($pending['name']); ?></small></h2>
        <div class="stats">
            <span><b><?php echo $cnt['new'] ?? 0; ?></b>new</span>
            <span><b><?php echo $cnt['changed'] ?? 0; ?></b>changed</span>
            <span><b><?php echo $cnt['same'] ?? 0; ?></b>already saved</span>
            <span><b><?php echo $cnt['blank'] ?? 0; ?></b>blank (left as it is)</span>
            <span class="<?php echo !empty($cnt['error']) ? 'bad' : ''; ?>"><b><?php echo $cnt['error'] ?? 0; ?></b>with a problem (not saved)</span>
            <?php if (!empty($cnt['outside'])): ?><span class="bad"><b><?php echo $cnt['outside']; ?></b>not in this list</span><?php endif; ?>
        </div>
        <?php $shown_plan = array_filter($plan, fn($l) => !in_array($l['status'], ['same', 'blank'], true)); ?>
        <?php if ($shown_plan): ?>
        <div class="table-responsive"><table class="ex-table">
            <thead><tr><th>Student</th><th>Now</th><th>From the sheet</th><th>Result</th></tr></thead>
            <tbody>
            <?php foreach ($shown_plan as $l): ?>
                <tr>
                    <td><b><?php echo h($l['name'] !== '' ? $l['name'] : '—'); ?></b><br><small class="dim"><?php echo h($l['uid']); ?></small></td>
                    <td><?php echo !empty($l['old']) ? h($l['old'] . ' · ' . $l['old_year']) : '<span class="dim">none</span>'; ?></td>
                    <td><?php echo isset($l['no']) ? '<b>' . h($l['no'] . ' · ' . $l['year']) . '</b>' : '—'; ?></td>
                    <td class="res <?php echo in_array($l['status'], ['error', 'outside'], true) ? 'bad' : 'ok'; ?>"><?php echo in_array($l['status'], ['error', 'outside'], true) ? '✗ ' . h($l['why']) : ($l['status'] === 'new' ? 'New' : 'Changed'); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php else: ?><div class="ex-empty"><i class="fas fa-check-circle"></i>Nothing in the sheet differs from what is saved.</div><?php endif; ?>
        <form method="post" class="tools" style="margin-top:14px"><?php echo $hidden(); ?>
            <?php if ($todo): ?><button type="submit" name="confirm_regno" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save <?php echo $todo; ?> number(s)</button><?php endif; ?>
            <button type="submit" name="cancel" value="1" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</button>
        </form>
    </div>

    <?php else: /* regno */ ?>
    <?php if ($class_id !== $reg_class): ?><div class="ex-guard"><i class="fas fa-info-circle big"></i><div><b>Class <?php echo h($classes[$class_id]); ?> — late registration</b>Numbers entered here count for the <?php echo h(BOARD_EXAMS[$board]['exam']); ?> steps too: a Class <?php echo h($classes[$class_id]); ?> student needs a Reg. No to be sent up.</div></div><?php endif; ?>
    <div class="card">
        <div class="tools noprint">
            <input type="search" id="q" placeholder="Search name, School UID or Reg. No">
            <label class="tog"><input type="checkbox" id="only"<?php echo $registered < $total ? ' checked' : ''; ?>> Only not done</label>
            <span class="shown" id="shown"></span>
            <span class="sv-sum" id="svSum"></span>
            <span class="right">
                <a class="btn btn-sm btn-success" href="<?php echo h($url(['download' => 'regno'])); ?>"><i class="fas fa-file-excel"></i> Download sheet<?php echo $show !== '' ? ' (' . h(BOARD_SHOW[$show]) . ')' : ''; ?></a>
                <?php $upload_form('regno', 'Upload filled sheet'); ?>
            </span>
        </div>
        <p class="note" style="margin:0 0 10px">The board sends the boys' and the girls' numbers apart — pick <b>Show: Boys</b> or <b>Girls</b> above to do one lot, by hand or with its own sheet. Type the number and move on — it saves by itself. The Year is filled in with <?php echo $year; ?>; change it if the board's is different. Clearing a number removes it.</p>
        <form id="rf" data-kind="regno" onsubmit="return false">
            <?php echo $hidden(); ?>
            <div class="table-responsive"><table class="ex-table" id="list">
                <thead><tr><th class="num">#</th><th>Student</th><th>Section · Roll</th><th>Reg. No</th><th>Year</th><th></th></tr></thead>
                <tbody>
                <?php $n = 0; foreach ($students as $uid => $st): $no = trim((string)$st['registration_no']); $y = (string)($st['registration_year'] ?: $year); ?>
                    <tr data-uid="<?php echo h($uid); ?>" data-b="<?php echo h(mb_strtolower($st['student_name'] . ' ' . $uid)); ?>" data-s="<?php echo h(mb_strtolower($st['student_name'] . ' ' . $uid . ' ' . $no)); ?>" data-done="<?php echo $no !== '' ? 1 : 0; ?>" data-saved="<?php echo h(json_encode(['reg_no' => $no, 'reg_year' => $y])); ?>">
                        <td class="num"><?php echo ++$n; ?></td>
                        <td><?php echo board_student_cell($st); ?></td>
                        <td><?php echo h(($st['section_name'] ?? '—') . ' · ' . ($st['roll_no'] ?? '—')); ?></td>
                        <td><input type="text" class="bx rn" data-f="reg_no" value="<?php echo h($no); ?>" maxlength="30" autocomplete="off" aria-label="Reg. No of <?php echo h($st['student_name']); ?>"></td>
                        <td><input type="text" class="bx ry" data-f="reg_year" value="<?php echo h($y); ?>" maxlength="4" inputmode="numeric" autocomplete="off" aria-label="Year"></td>
                        <td class="sv"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table></div>
        </form>
        <div class="ex-empty" id="none" hidden><i class="fas fa-check-circle"></i>Every student here has a registration number.</div>
        <div class="tools" style="margin:14px 0 0">
            <span class="dim" style="font-size:12.5px"><i class="fas fa-clipboard-list"></i> When the registration certificates arrive, hand them out against the register — each student or guardian writes the date and signs.</span>
            <span class="right">
                <a class="btn btn-sm btn-primary" target="_blank" href="<?php echo h($print('register')); ?>"><i class="fas fa-print"></i> Print certificate register</a>
                <a class="btn btn-sm btn-secondary" href="<?php echo h($url(['download' => 'register'])); ?>"><i class="fas fa-file-excel"></i> Download register</a>
            </span>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<script>
(function () {   // search, "only not done" and the CC / regular choice filter the list in place; a fix made in another tab is seen on return
    var q = document.getElementById('q'), only = document.getElementById('only'), tp = document.getElementById('tp'), shown = document.getElementById('shown'), none = document.getElementById('none');
    var rows = Array.prototype.slice.call(document.querySelectorAll('#list tbody tr'));
    function apply() {
        var t = q ? q.value.trim().toLowerCase() : '', o = only && only.checked, k = tp ? tp.value : '', n = 0, more = 0;
        rows.forEach(function (tr) {
            var hit = (!t || tr.dataset.s.indexOf(t) !== -1) && (!k || (k === 'cc') === (tr.dataset.cc === '1')), show = hit && (!o || tr.dataset.done !== '1');
            tr.style.display = show ? '' : 'none';
            if (show) n++; else if (hit && t) more++;
        });
        // a search also finds the ones the tick hides — say so, or a student who is done looks lost
        if (shown) shown.textContent = 'Showing ' + n + ' of ' + rows.length + (more ? ' · ' + more + ' more if “' + only.parentNode.textContent.trim() + '” is off' : '');
        if (none) none.hidden = n > 0 || !o || !!t;
        document.dispatchEvent(new CustomEvent('board:filtered'));
    }
    if (q) q.addEventListener('input', apply);
    if (only) only.addEventListener('change', apply);
    if (tp) tp.addEventListener('change', apply);
    if (rows.length) apply();
    var away = false;
    Array.prototype.forEach.call(document.querySelectorAll('a.fix'), function (a) { a.addEventListener('click', function () { away = true; }); });
    window.addEventListener('focus', function () { if (away) location.reload(); });
})();
</script>
<?php if (($step === 'regno' || $step === 'result' || board_step_sem($step) !== null) && !$pending): ?><script src="../assets/js/board_autosave.js"></script><?php endif; ?>
</body>
</html>
<?php }

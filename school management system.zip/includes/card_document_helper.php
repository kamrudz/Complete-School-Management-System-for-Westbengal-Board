<?php
/** Shared read/validation helpers for ID cards, admit cards and certificates. */

function document_get_school_settings($conn, $fields = '*') {
    // $fields is internal-only; whitelist the supported projections.
    $allowed = [
        '*' => '*',
        'verify_basic' => 'school_name, logo',
        'verify_phone' => 'school_name, logo, phone',
    ];
    $projection = $allowed[$fields] ?? '*';
    $stmt = mysqli_prepare($conn, "SELECT {$projection} FROM school_settings WHERE id=? LIMIT 1");
    $id = 1;
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: [];
}

function document_get_active_session_id($conn) {
    $stmt = mysqli_prepare($conn, "SELECT id FROM academic_sessions WHERE status=? ORDER BY id DESC LIMIT 1");
    $status = 'Active';
    mysqli_stmt_bind_param($stmt, 's', $status);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row ? (int)$row['id'] : 0;
}

function document_get_class_name($conn, $class_id) {
    $stmt = mysqli_prepare($conn, "SELECT class_name FROM classes WHERE id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $class_id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    return $row['class_name'] ?? '';
}

function document_get_exam($conn, $exam_source, $exam_id) {
    if ($exam_source === 'hs') {
        $stmt = mysqli_prepare($conn, "SELECT e.*, e.academic_year AS session_name FROM hs_exam e WHERE e.id=? LIMIT 1");
    } else {
        $stmt = mysqli_prepare($conn, "SELECT e.*, s.session_name FROM exams e LEFT JOIN academic_sessions s ON e.session_id=s.id WHERE e.id=? LIMIT 1");
    }
    mysqli_stmt_bind_param($stmt, 'i', $exam_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: null;
}

function document_get_student_academic($conn, $student_id, $session_id) {
    $stmt = mysqli_prepare($conn, "SELECT h.*, c.class_name, sec.section_name, ss.session_name
        FROM student_academic_history h
        LEFT JOIN classes c ON h.class_id=c.id
        LEFT JOIN sections sec ON h.section_id=sec.id
        LEFT JOIN academic_sessions ss ON h.session_id=ss.id
        WHERE h.student_id=? AND h.session_id=?
        ORDER BY h.id DESC LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'si', $student_id, $session_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)) ?: null;
}

function document_get_students_for_class($conn, $session_id, $class_id, $section_id = 0) {
    $sql = "SELECT s.id, s.student_name, s.admission_no, s.photo, h.roll_no, sec.section_name
            FROM student_academic_history h
            JOIN students s ON s.id=h.student_id
            LEFT JOIN sections sec ON sec.id=h.section_id
            WHERE h.session_id=? AND h.class_id=? AND h.academic_status='Current'";
    if ($section_id > 0) {
        $sql .= " AND h.section_id=?";
        $stmt = mysqli_prepare($conn, $sql . " ORDER BY CAST(h.roll_no AS UNSIGNED) ASC");
        mysqli_stmt_bind_param($stmt, 'iii', $session_id, $class_id, $section_id);
    } else {
        $stmt = mysqli_prepare($conn, $sql . " ORDER BY CAST(h.roll_no AS UNSIGNED) ASC");
        mysqli_stmt_bind_param($stmt, 'ii', $session_id, $class_id);
    }
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}

function document_get_selected_students($conn, $session_id, array $student_ids, $class_id = 0) {
    $student_ids = array_values(array_unique(array_filter(array_map('student_uid_clean', $student_ids))));
    if (!$student_ids) return false;
    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $sql = "SELECT s.*, h.roll_no, h.class_id, h.section_id, cl.class_name, sec.section_name, ss.session_name
            FROM students s
            JOIN student_academic_history h ON h.student_id=s.id AND h.session_id=?
            LEFT JOIN classes cl ON cl.id=h.class_id
            LEFT JOIN sections sec ON sec.id=h.section_id
            LEFT JOIN academic_sessions ss ON ss.id=h.session_id
            WHERE s.id IN ($placeholders) AND h.academic_status='Current'";
    $params = [$session_id, ...$student_ids];
    $types = 'i' . str_repeat('s', count($student_ids));
    if ($class_id > 0) {
        $sql .= " AND h.class_id=?";
        $params[] = $class_id;
        $types .= 'i';
    }
    $sql .= " ORDER BY CAST(h.roll_no AS UNSIGNED) ASC";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}

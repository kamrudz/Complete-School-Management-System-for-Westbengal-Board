<?php
/**
 * Application centres — the cyber cafés the school allows to make admission applications.
 *
 * Admission Settings says who may apply: 'public' (anyone, from the website) or 'centres' (only a centre that
 * has logged in). Every application a logged-in centre makes carries its centre_id, a centre sees only its own,
 * and a centre switched off is logged out on its very next click.
 *
 * Passwords are kept as password_hash(); wrong ones lock the username, and the address, the way the teacher
 * login does (includes/login_attempts.php).
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/login_attempts.php';

const CENTRE_DAILY_LIMIT = 300;     // applications one centre may send in a day — a café, unlike a home, sends many
const CENTRE_MAX_TRIES = 5;         // wrong passwords before a username is locked
const CENTRE_LOCK_MINUTES = 15;

const ADM_MODES = [
    'public'  => ['Anyone, from the website', 'Parents fill the form themselves, from any phone or computer.'],
    'centres' => ['Only through approved centres', 'The form opens only for a centre that has logged in. Parents are shown the list of centres.'],
];

/** The session a centre lives in — the same one the admission form reads, with a cookie scripts cannot touch. */
function centre_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
    ini_set('session.use_strict_mode', '1');
    session_start();
}

/** Who may apply right now: 'public' or 'centres'. */
function adm_mode(): string
{
    $m = (string)(db_get_row('SELECT admission_mode FROM school_settings WHERE id = 1')['admission_mode'] ?? 'public');
    return isset(ADM_MODES[$m]) ? $m : 'public';
}

/** The centre logged in on this browser, or null. A centre switched off since it logged in is logged out here. */
function centre_current(): ?array
{
    centre_session();
    $id = (int)($_SESSION['centre_id'] ?? 0);
    if (!$id) return null;
    $row = db_get_row('SELECT id, name, owner_name, place, phone, username, is_active FROM admission_centres WHERE id = ?', 'i', $id);
    if (!$row || !(int)$row['is_active']) { centre_logout(); return null; }
    return $row;
}

/** Try a username and password. Returns [true, centre] or [false, the reason to show]. */
function centre_login(string $username, string $password): array
{
    global $conn;
    $username = strtolower(trim($username));
    $key_user = 'centre:' . $username;
    $key_ip = 'centre-ip:' . (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $locked = max(login_locked_minutes($conn, $key_user), login_locked_minutes($conn, $key_ip));
    if ($locked > 0) return [false, "Too many wrong tries. Try again in $locked minute(s)."];

    $row = $username !== '' ? db_get_row('SELECT * FROM admission_centres WHERE username = ?', 's', $username) : null;
    $ok = $row && (int)$row['is_active'] === 1 && password_verify($password, (string)$row['password_hash']);
    if (!$ok) {
        if ($username !== '') register_failed_attempt($conn, $key_user, CENTRE_MAX_TRIES, CENTRE_LOCK_MINUTES);
        register_failed_attempt($conn, $key_ip, CENTRE_MAX_TRIES * 4, CENTRE_LOCK_MINUTES);
        return [false, 'That username and password do not match an active centre.'];
    }
    clear_login_attempts($conn, $key_user);
    centre_session();
    session_regenerate_id(true);
    $_SESSION['centre_id'] = (int)$row['id'];
    $_SESSION['centre_since'] = time();
    db_execute('UPDATE admission_centres SET last_login_at = NOW() WHERE id = ?', 'i', (int)$row['id']);
    if (password_needs_rehash((string)$row['password_hash'], PASSWORD_DEFAULT)) {
        db_execute('UPDATE admission_centres SET password_hash = ? WHERE id = ?', 'si', password_hash($password, PASSWORD_DEFAULT), (int)$row['id']);
    }
    return [true, $row];
}

/** Forget the centre on this browser, leaving anything else in the session alone. */
function centre_logout(): void
{
    centre_session();
    unset($_SESSION['centre_id'], $_SESSION['centre_since'], $_SESSION['adm_edit_id'], $_SESSION['adm_app_id']);
}

/** The centres a parent can be sent to: only the ones switched on. */
function centre_public_list(): array
{
    return db_get_all('SELECT name, place, phone FROM admission_centres WHERE is_active = 1 ORDER BY place, name');
}

/** A username: letters, digits, dot, dash and underscore, 4 to 40 long. */
function centre_username_ok(string $u): bool
{
    return (bool)preg_match('/^[a-z0-9._-]{4,40}$/', $u);
}

/** A password worth having: at least 8 characters with a letter and a digit. '' when fine, else why not. */
function centre_password_problem(string $p): string
{
    if (strlen($p) < 8) return 'The password needs at least 8 characters.';
    if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) return 'The password needs letters and at least one digit.';
    return '';
}

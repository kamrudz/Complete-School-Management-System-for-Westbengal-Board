<?php
/**
 * Classes are named with the Roman numerals I–XII and kept across sessions. What a class is — its stage —
 * is stored on the class: primary (I–IV) · upper_primary (V–VIII) · secondary (IX–X) · higher_secondary
 * (XI–XII), plus board_exam when the board, not the school, holds its examination (Class XII). The stage
 * decides grade bands, project and formative columns and which module owns the class.
 */

/** Canonical names in order; the index + 1 is the class number. */
function class_roman_list(): array {
    return ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
}

function class_name_normalise($name): string {
    return strtoupper(trim((string)$name));
}

/** Null when acceptable, otherwise the message to show. */
function class_name_error(string $name): ?string {
    if ($name === '') return 'Please choose a class.';
    if (!in_array($name, class_roman_list(), true)) return 'Class must be a Roman numeral from I to XII.';
    return null;
}

/** The four stages in order: key => [label, which classes, short label]. */
function class_stages(): array {
    return [
        'primary'          => ['label' => 'Primary',          'classes' => 'I–IV',   'short' => 'Primary'],
        'upper_primary'    => ['label' => 'Upper Primary',    'classes' => 'V–VIII', 'short' => 'Upper Pr.'],
        'secondary'        => ['label' => 'Secondary',        'classes' => 'IX–X',   'short' => 'Secondary'],
        'higher_secondary' => ['label' => 'Higher Secondary', 'classes' => 'XI–XII', 'short' => 'H.S.'],
    ];
}
function class_stage_valid(string $stage): bool { return isset(class_stages()[$stage]); }
function class_stage_label(string $stage): string { return class_stages()[$stage]['label'] ?? $stage; }

/** Every class: id => ['id', 'name', 'stage', 'board_exam', 'sort_order']. Cached per request. */
function class_rows(): array {
    static $rows = null;
    if ($rows === null) {
        $rows = [];
        foreach (db_get_all('SELECT id, class_name, stage, board_exam, sort_order FROM classes ORDER BY sort_order, id') as $r) {
            $rows[(int)$r['id']] = ['id' => (int)$r['id'], 'name' => $r['class_name'], 'stage' => (string)$r['stage'],
                'board_exam' => (int)$r['board_exam'] === 1, 'sort_order' => (int)$r['sort_order']];
        }
    }
    return $rows;
}

/** The stage of a class, '' when the class is unknown. */
function class_stage(int $class_id): string { return class_rows()[$class_id]['stage'] ?? ''; }

/** The usual stage of a numeral — only to pre-fill the Add Class form. */
function class_stage_of_name(string $name): string {
    $n = strtoupper(trim($name));
    if (in_array($n, ['I', 'II', 'III', 'IV'], true)) return 'primary';
    if (in_array($n, ['V', 'VI', 'VII', 'VIII'], true)) return 'upper_primary';
    if (in_array($n, ['IX', 'X'], true)) return 'secondary';
    if (in_array($n, ['XI', 'XII'], true)) return 'higher_secondary';
    return 'upper_primary';
}

/** Sort order follows the numeral: V = 5, XII = 12. */
function class_sort_order(string $name): int {
    $i = array_search($name, class_roman_list(), true);
    return $i === false ? 0 : $i + 1;
}

/** Numerals no class uses yet. */
function class_roman_available(): array {
    return array_values(array_diff(class_roman_list(), array_column(db_get_all('SELECT class_name FROM classes'), 'class_name')));
}

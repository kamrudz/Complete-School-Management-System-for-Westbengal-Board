<?php
/**
 * SchoolMS database bootstrap and shared mysqli helpers.
 */

if (!defined('APP_TIMEZONE_SET')) {
    date_default_timezone_set('Asia/Kolkata');
    define('APP_TIMEZONE_SET', true);
}

$config = [
    'host' => getenv('DB_HOST') ?: 'localhost',
    'user' => getenv('DB_USER') ?: 'root',
    'pass' => getenv('DB_PASS') ?: '',
    'name' => getenv('DB_NAME') ?: 'schooltest_db',
];

$host = $config['host'];
$user = $config['user'];
$password = $config['pass'];
$database = $config['name'];

$conn = @mysqli_connect($host, $user, $password, $database);
if (!$conn) {
    error_log('Database connection failed: ' . mysqli_connect_error());
    http_response_code(500);
    exit('We are experiencing technical difficulties. Please try again later.');
}

if (!mysqli_set_charset($conn, 'utf8mb4')) {
    error_log('Failed to set database charset: ' . mysqli_error($conn));
}

function db_identifier($identifier) {
    if (!is_string($identifier) || !preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $identifier)) {
        throw new InvalidArgumentException('Invalid database identifier.');
    }
    return '`' . $identifier . '`';
}

function db_prepare_and_execute($sql, $types = '', array $params = []) {
    global $conn;

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log('SQL prepare error: ' . mysqli_error($conn));
        return false;
    }

    if ($params) {
        if (strlen($types) !== count($params)) {
            mysqli_stmt_close($stmt);
            throw new InvalidArgumentException('Parameter type count does not match parameter count.');
        }
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    if (!mysqli_stmt_execute($stmt)) {
        error_log('SQL execute error: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return false;
    }

    return $stmt;
}

/** Execute a prepared query and return a result set for SELECT statements. */
function db_query($sql, $types = '', ...$params) {
    $stmt = db_prepare_and_execute($sql, $types, $params);
    if ($stmt === false) return false;

    $result = mysqli_stmt_get_result($stmt);
    mysqli_stmt_close($stmt);
    return $result;
}

function db_get_row($sql, $types = '', ...$params) {
    $result = db_query($sql, $types, ...$params);
    return ($result instanceof mysqli_result) ? mysqli_fetch_assoc($result) : null;
}

function db_get_all($sql, $types = '', ...$params) {
    $result = db_query($sql, $types, ...$params);
    return ($result instanceof mysqli_result) ? mysqli_fetch_all($result, MYSQLI_ASSOC) : [];
}

function db_execute($sql, $types = '', ...$params) {
    $stmt = db_prepare_and_execute($sql, $types, $params);
    if ($stmt === false) return false;

    $affected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
    return $affected;
}

function db_insert($table, $data) {
    global $conn;
    if (!$data) return false;

    try {
        $columns = array_keys($data);
        $quoted = array_map('db_identifier', $columns);
        $values = array_values($data);
        $types = str_repeat('s', count($values));
        $sql = 'INSERT INTO ' . db_identifier($table) . ' (' . implode(', ', $quoted) . ') VALUES ('
             . implode(', ', array_fill(0, count($values), '?')) . ')';
    } catch (InvalidArgumentException $e) {
        error_log($e->getMessage());
        return false;
    }

    $stmt = db_prepare_and_execute($sql, $types, $values);
    if ($stmt === false) return false;

    $id = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);
    return $id;
}

/**
 * Update rows safely. $where_types may be a type string matching where values
 * (e.g. 'ii') or omitted to treat all values as strings.
 */
function db_update($table, $data, $where, $where_types = '') {
    if (!$data || !$where) return false;

    try {
        $set_parts = [];
        foreach (array_keys($data) as $column) {
            $set_parts[] = db_identifier($column) . ' = ?';
        }

        $where_parts = [];
        foreach (array_keys($where) as $column) {
            $where_parts[] = db_identifier($column) . ' = ?';
        }

        if ($where_types === '') $where_types = str_repeat('s', count($where));
        if (strlen($where_types) !== count($where)) {
            throw new InvalidArgumentException('WHERE type count does not match WHERE values.');
        }

        $sql = 'UPDATE ' . db_identifier($table)
             . ' SET ' . implode(', ', $set_parts)
             . ' WHERE ' . implode(' AND ', $where_parts);
    } catch (InvalidArgumentException $e) {
        error_log($e->getMessage());
        return false;
    }

    $types = str_repeat('s', count($data)) . $where_types;
    return db_execute($sql, $types, ...array_merge(array_values($data), array_values($where)));
}

function db_begin_transaction() {
    global $conn;
    return mysqli_begin_transaction($conn);
}

function db_commit() {
    global $conn;
    return mysqli_commit($conn);
}

function db_rollback() {
    global $conn;
    return mysqli_rollback($conn);
}

/** Every (table, column) with a foreign key to $table — read from the schema, so a table added later is included. */
function db_references(string $table): array {
    static $cache = [];
    return $cache[$table] ??= db_get_all('SELECT DISTINCT TABLE_NAME, COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = DATABASE() AND REFERENCED_TABLE_NAME = ?', 's', $table);
}

/** Tables that still hold rows pointing at row $id of $table: table => rows. A delete would cascade into them. */
function db_dependents(string $table, int|string $id): array {
    $found = [];
    $type = is_int($id) ? 'i' : 's';   // students are keyed by a UID string; a string bound as 'i' would match every row
    foreach (db_references($table) as $r) {
        $n = (int)(db_get_row('SELECT COUNT(*) AS n FROM ' . db_identifier($r['TABLE_NAME']) . ' WHERE ' . db_identifier($r['COLUMN_NAME']) . ' = ?', $type, $id)['n'] ?? 0);
        if ($n > 0) $found[$r['TABLE_NAME']] = ($found[$r['TABLE_NAME']] ?? 0) + $n;
    }
    return $found;
}

/** Every id of $table that some row elsewhere still points at: id => true (one query per referencing table). */
function db_referenced_ids(string $table): array {
    $ids = [];
    foreach (db_references($table) as $r) {
        $col = db_identifier($r['COLUMN_NAME']);
        foreach (db_get_all("SELECT DISTINCT $col AS id FROM " . db_identifier($r['TABLE_NAME']) . " WHERE $col IS NOT NULL") as $row) $ids[$row['id']] = true;
    }
    return $ids;
}

/** "student_academic_history (48), routine (30)" — the largest first, for messages. */
function db_dependents_text(array $deps): string {
    arsort($deps);
    return implode(', ', array_map(fn($t, $n) => "$t ($n)", array_keys($deps), $deps));
}

/**
 * Keep the admin panel behind a completed School Settings page.
 *
 * This lives here because every admin page includes db.php, so one call
 * covers all of admin/ instead of editing 215 files. It is a no-op outside
 * /admin/, so the public site and the student and teacher portals are
 * untouched. See includes/setup_gate.php for the field list and the rules.
 */
require_once __DIR__ . '/setup_gate.php';
schoolms_require_school_settings($conn);

// Student identity helpers (School UID validation, lookup, URLs) — the UID is the
// students primary key, so almost every page needs these; loaded once here.
require_once __DIR__ . '/student_helper.php';

// Class helpers — a class carries its STAGE (primary / upper primary / secondary / higher secondary),
// which decides grade bands, project and formative columns and which module owns the class. Every
// module asks for it, so it is loaded here rather than in each page.
require_once __DIR__ . '/class_helper.php';

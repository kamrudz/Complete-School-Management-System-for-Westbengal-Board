<?php
/**
 * document_helper.php
 * ---------------------------------------------------------------
 * Generic image upload + auto-compress helper, used for Student
 * Signature and Birth Certificate uploads (in addition to the
 * existing photo_helper.php which handles the profile Photo).
 *
 * Put this file in: ../includes/document_helper.php
 * (i.e. same folder as photo_helper.php)
 * ---------------------------------------------------------------
 *
 * Usage:
 *   $result = process_student_document(
 *       $_FILES['signature'] ?? [],
 *       "../uploads/students/signatures/",
 *       10,           // target size in KB
 *       'sig'         // filename prefix
 *   );
 *   if (!$result['ok']) { back_with_error($result['error']); }
 *   $signature_filename = $result['filename']; // null if no file uploaded
 */

if (!function_exists('process_student_document')) {

    function process_student_document($file, $upload_dir, $target_kb = 30, $prefix = 'doc') {

        // ---------- No file uploaded: not an error ----------
        if (empty($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
            return ['ok' => true, 'error' => null, 'filename' => null];
        }

        // ---------- Upload errors ----------
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['ok' => false, 'error' => 'File upload failed (error code ' . $file['error'] . ').', 'filename' => null];
        }

        // ---------- Validate upload source / size ----------
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['ok' => false, 'error' => 'Invalid upload source.', 'filename' => null];
        }
        $max_bytes = 10 * 1024 * 1024;
        if (!empty($file['size']) && (int)$file['size'] > $max_bytes) {
            return ['ok' => false, 'error' => 'Image is too large. Maximum allowed size is 10 MB.', 'filename' => null];
        }

        // ---------- Validate it's a real image ----------
        $info = @getimagesize($file['tmp_name']);
        if ($info === false) {
            return ['ok' => false, 'error' => 'Uploaded file is not a valid image.', 'filename' => null];
        }

        $mime = $info['mime'];
        switch ($mime) {
            case 'image/jpeg':
                $src = @imagecreatefromjpeg($file['tmp_name']);
                break;
            case 'image/png':
                $src = @imagecreatefrompng($file['tmp_name']);
                break;
            case 'image/webp':
                $src = @imagecreatefromwebp($file['tmp_name']);
                break;
            default:
                return ['ok' => false, 'error' => 'Only JPG, PNG or WEBP images are allowed.', 'filename' => null];
        }

        if (!$src) {
            return ['ok' => false, 'error' => 'Could not read the uploaded image.', 'filename' => null];
        }

        // ---------- Flatten transparency onto white (for PNG) ----------
        $width  = imagesx($src);
        $height = imagesy($src);
        $flat = imagecreatetruecolor($width, $height);
        imagefill($flat, 0, 0, imagecolorallocate($flat, 255, 255, 255));
        imagealphablending($flat, true);
        imagecopy($flat, $src, 0, 0, 0, 0, $width, $height);
        imagedestroy($src);
        $src = $flat;

        // ---------- Ensure upload directory exists ----------
        if (!is_dir($upload_dir)) {
            @mkdir($upload_dir, 0755, true);
        }

        $target_bytes = $target_kb * 1024;
        $filename = $prefix . '_' . time() . '_' . mt_rand(1000, 9999) . '.jpg';
        $full_path = rtrim($upload_dir, '/') . '/' . $filename;

        // ---------- Iteratively shrink dimensions + quality until under target ----------
        $work = $src;
        $cur_w = $width;
        $cur_h = $height;
        $quality = 80;
        $saved = false;

        for ($attempt = 0; $attempt < 12; $attempt++) {
            ob_start();
            imagejpeg($work, null, $quality);
            $data = ob_get_clean();

            if (strlen($data) <= $target_bytes || ($cur_w <= 100 && $quality <= 30)) {
                file_put_contents($full_path, $data);
                $saved = true;
                break;
            }

            // Reduce quality first; once quality is low, start shrinking dimensions too
            if ($quality > 35) {
                $quality -= 10;
            } else {
                $cur_w = (int)($cur_w * 0.85);
                $cur_h = (int)($cur_h * 0.85);
                $resized = imagecreatetruecolor($cur_w, $cur_h);
                imagefill($resized, 0, 0, imagecolorallocate($resized, 255, 255, 255));
                imagecopyresampled($resized, $work, 0, 0, 0, 0, $cur_w, $cur_h, imagesx($work), imagesy($work));
                if ($work !== $src) imagedestroy($work);
                $work = $resized;
            }
        }

        if (!$saved) {
            // Last resort: save whatever we have at lowest settings
            imagejpeg($work, $full_path, 30);
        }

        if ($work !== $src) imagedestroy($work);
        imagedestroy($src);

        return ['ok' => true, 'error' => null, 'filename' => $filename];
    }

}

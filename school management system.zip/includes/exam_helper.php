<?php
/**
 * Exam helpers (classes V–X): exam list, full/pass marks config, eligible students, marks upsert.
 *
 * Exams live in `exams` with exam_type 'v-x' (HS exams share the table with exam_type 'hs' — not handled here).
 * Full/pass marks are configured per exam × class × subject in `exam_subject_marks` (UNIQUE on session+exam+class+subject).
 * A student's marks for one exam × subject is ONE ROW in `marks` (UNIQUE student+session+exam+subject); section_id and
 * class_id are refreshed on every save, grace_marks is kept apart from the marks obtained.
 * Third-language subjects (class_subjects.is_third_language) apply only to the students who chose that language
 * (student_third_language); a student with no choice is not eligible for any of them.
 * Formative marks (Primary & Upper Primary) are read from hprc_formative — entered on the HPRC formative page, shown on the report card only.
 */

const EXAM_NAME_PRESETS = ['1st Summative', '2nd Summative', '3rd Summative', 'Test', 'Selection Test', 'Pre-Test'];

/** The stages this module examines — Higher Secondary has its own module (hs_*). */
const EXAM_STAGES = ['primary', 'upper_primary', 'secondary'];
/** The menu sections: a section is one or more stages shown together. */
const EXAM_SECTIONS = [
    'pup' => ['label' => 'Primary & Upper Primary', 'classes' => 'I–VIII', 'stages' => ['primary', 'upper_primary']],
    'sec' => ['label' => 'Secondary', 'classes' => 'IX–X', 'stages' => ['secondary']],
];

/**
 * Classes this module examines: id => ['name', 'group' (= the stage), 'stage'] in order.
 * $section limits them to one menu section ('pup' | 'sec'); anything else returns them all.
 */
function exam_classes(string $section = ''): array {
    static $all = null;
    if ($all === null) {
        $all = [];
        foreach (class_rows() as $id => $c) {
            if (!in_array($c['stage'], EXAM_STAGES, true)) continue;   // Higher Secondary belongs to the HS module
            $all[$id] = ['name' => $c['name'], 'group' => $c['stage'], 'stage' => $c['stage']];
        }
    }
    if ($section === '' || !isset(EXAM_SECTIONS[$section])) return $all;
    $stages = EXAM_SECTIONS[$section]['stages'];
    return array_filter($all, fn($c) => in_array($c['stage'], $stages, true));
}
/** The menu section a stage belongs to, '' when the stage is not examined here. */
function exam_section_of_stage(string $stage): string {
    foreach (EXAM_SECTIONS as $k => $s) if (in_array($stage, $s['stages'], true)) return $k;
    return '';
}
function exam_section_of_class(int $class_id): string { return exam_section_of_stage(class_stage($class_id)); }
/** A section key from a request: falls back to the section of $class_id, else the first section. */
function exam_section_clean($raw, int $class_id = 0): string {
    $s = is_string($raw) ? trim($raw) : '';
    if (isset(EXAM_SECTIONS[$s])) return $s;
    $byClass = $class_id ? exam_section_of_class($class_id) : '';
    return $byClass !== '' ? $byClass : (string)array_key_first(EXAM_SECTIONS);
}
function exam_section_label(string $section): string { return EXAM_SECTIONS[$section]['label'] ?? ''; }

/** The stage of a class — what the grade bands and the rules are keyed by. Null for an unknown class. */
function exam_class_group(int $class_id): ?string {
    $s = class_stage($class_id);
    return $s !== '' ? $s : null;
}
/** Kept for callers that only hold a name (the public result page); the stored stage wins. */
function exam_class_group_of_name(string $name): ?string {
    $n = strtoupper(trim($name));
    foreach (class_rows() as $c) if (strtoupper($c['name']) === $n) return $c['stage'];
    return class_stage_of_name($n);
}
function exam_class_name(int $class_id): string {
    return (string)(class_rows()[$class_id]['name'] ?? db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $class_id)['class_name'] ?? '');
}
/** Secondary carries a project component; primary and upper primary carry formative (HPRC) marks. */
function exam_class_has_project(int $class_id): bool { return class_stage($class_id) === 'secondary'; }
function exam_class_has_formative(int $class_id): bool { return in_array(class_stage($class_id), ['primary', 'upper_primary'], true); }

function exam_active_session_id(): int {
    static $id = null;
    if ($id === null) $id = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
    return $id;
}

/** V–X exams of a session in order, each with config/marks counts. */
/**
 * Exams of a session with how far each one has got. $class_ids narrows the counts to one section's
 * classes, so "3 / 4 classes configured" means that section's four classes, not every class V–X.
 */
function exam_list(int $session_id, array $class_ids = []): array {
    $scope = '';
    if ($class_ids) {   // ints only, so this cannot carry anything but numbers into the SQL
        $ids = implode(',', array_map('intval', $class_ids));
        $scope = " AND class_id IN ($ids)";
    }
    return db_get_all("
        SELECT e.*, s.session_name,
               (SELECT COUNT(DISTINCT class_id) FROM exam_subject_marks WHERE exam_id = e.id$scope) AS classes_configured,
               (SELECT COUNT(DISTINCT CONCAT(class_id, '-', subject_id)) FROM marks WHERE exam_id = e.id$scope) AS subjects_with_marks,
               (SELECT COUNT(*) FROM marks WHERE exam_id = e.id$scope) AS marks_rows
        FROM exams e JOIN academic_sessions s ON s.id = e.session_id
        WHERE e.session_id = ? AND e.exam_type = 'v-x'
        ORDER BY e.exam_order, e.id", 'i', $session_id);
}
function exam_get(int $exam_id): ?array {
    return db_get_row("SELECT e.*, s.session_name FROM exams e JOIN academic_sessions s ON s.id = e.session_id WHERE e.id = ? AND e.exam_type = 'v-x'", 'i', $exam_id) ?: null;
}
/** Rows that hang off an exam (delete guard). */
function exam_dependencies(int $exam_id): array {
    $d = [];
    foreach (['marks' => 'Marks', 'exam_subject_marks' => 'Full/pass marks config', 'hprc_learning' => 'HPRC learning', 'hprc_behavior' => 'HPRC behavior'] as $t => $label) {
        $n = (int)(db_get_row("SELECT COUNT(*) AS n FROM $t WHERE exam_id = ?", 'i', $exam_id)['n'] ?? 0);
        if ($n) $d[$label] = $n;
    }
    foreach (['exam_routine' => 'Exam routine', 'exam_seating_plan' => 'Seating plan', 'exam_duty_roster' => 'Duty roster'] as $t => $label) {
        $r = db_get_row("SELECT COUNT(*) AS n FROM $t WHERE exam_id = ? AND exam_source = 'v-x'", 'i', $exam_id);
        if ($r && (int)$r['n']) $d[$label] = (int)$r['n'];
    }
    return $d;
}

/** Subjects a class sits (class_subjects has_exam=1): id => [name, code, tl]. */
function exam_class_subject_list(int $session_id, int $class_id): array {
    $out = [];
    foreach (db_get_all('SELECT s.id, s.subject_name, s.subject_code, cs.is_third_language
        FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id
        WHERE cs.session_id = ? AND cs.class_id = ? AND cs.has_exam = 1 ORDER BY cs.is_third_language, s.subject_name', 'ii', $session_id, $class_id) as $r) {
        $out[(int)$r['id']] = ['id' => (int)$r['id'], 'name' => $r['subject_name'], 'code' => (string)$r['subject_code'], 'tl' => (int)$r['is_third_language'] === 1];
    }
    return $out;
}

/**
 * Subjects of an exam for a class = class subjects ∩ exam_subject_marks config, with full/pass marks.
 * Subjects without a config row are returned with 'configured' => false (full marks 0) so callers can warn.
 */
function exam_subjects(int $session_id, int $exam_id, int $class_id): array {
    $subs = exam_class_subject_list($session_id, $class_id);
    $cfg = [];
    foreach (db_get_all('SELECT * FROM exam_subject_marks WHERE session_id = ? AND exam_id = ? AND class_id = ?', 'iii', $session_id, $exam_id, $class_id) as $r) $cfg[(int)$r['subject_id']] = $r;
    foreach ($subs as $sid => &$s) {
        $c = $cfg[$sid] ?? null;
        $s['configured'] = (bool)$c;
        $s['written_full'] = (float)($c['written_full_marks'] ?? 0); $s['written_pass'] = (float)($c['written_pass_marks'] ?? 0);
        $s['project_full'] = (float)($c['project_full_marks'] ?? 0); $s['project_pass'] = (float)($c['project_pass_marks'] ?? 0);
        $s['full'] = (float)($c['total_full_marks'] ?? 0); $s['pass'] = (float)($c['total_pass_marks'] ?? 0);
    }
    return $subs;
}

/** Save full/pass marks for one exam × class: rows = subject_id => [written_full, project_full, pass]. Pass marks are on the TOTAL (written + project, however split). */
function exam_config_save(int $session_id, int $exam_id, int $class_id, array $rows, int $admin_id): array {
    $subs = exam_class_subject_list($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $sid => $r) {
        $sid = (int)$sid; if (!isset($subs[$sid])) continue;
        $v = [];
        foreach (['written_full', 'project_full', 'pass'] as $k) {
            $x = trim((string)($r[$k] ?? ''));
            if ($x === '') $x = '0';
            if (!preg_match('/^\d{1,3}(\.\d{1,2})?$/', $x)) { $errors[$sid] = 'Invalid number'; continue 2; }
            $v[$k] = (float)$x;
        }
        if (!exam_class_has_project($class_id)) $v['project_full'] = 0;
        if ($v['pass'] > $v['written_full'] + $v['project_full']) { $errors[$sid] = 'Pass marks cannot exceed full marks'; continue; }
        if ($v['written_full'] <= 0 && $v['project_full'] <= 0) continue;   // blank row = not configured
        $clean[$sid] = $v;
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    db_begin_transaction();
    try {
        db_execute('DELETE FROM exam_subject_marks WHERE session_id = ? AND exam_id = ? AND class_id = ?', 'iii', $session_id, $exam_id, $class_id);
        foreach ($clean as $sid => $v) {
            db_execute('INSERT INTO exam_subject_marks (session_id, exam_id, class_id, subject_id, written_full_marks, written_pass_marks, project_full_marks, project_pass_marks, total_full_marks, total_pass_marks) VALUES (?,?,?,?,?,?,?,?,?,?)',
                'iiiidddddd', $session_id, $exam_id, $class_id, $sid, $v['written_full'], 0, $v['project_full'], 0, $v['written_full'] + $v['project_full'], $v['pass']);
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); return ['ok' => false, 'errors' => ['_' => 'Save failed']]; }
    log_action($admin_id, 'EXAM_CONFIG_SAVED', 'exam_subject_marks', $exam_id, null, ['class_id' => $class_id, 'subjects' => count($clean)]);
    return ['ok' => true, 'saved' => count($clean)];
}

/**
 * Students of a class in roll order: uid => row. Section optional.
 * Each row: uid, name, father, gender, dob, bsid, pen, section_id, section, roll, tl (subject_id chosen, 0 = none).
 * By default the class as it is now (Active, Current) — what marks entry works on. With $as_of_exam the class as it
 * was for that exam, for its reports: also those who have moved on since at the year end (promoted, detained,
 * passed out) and those who left later (TC, deactivated) but sat that exam. Deleted students never.
 */
function exam_students(int $session_id, int $class_id, ?int $section_id = null, int $as_of_exam = 0): array {
    $who = $as_of_exam
        ? '(sah.academic_status = "Current" AND s.student_status = "Active") OR sah.promotion_status IN ("Promoted", "Detained")
           OR EXISTS (SELECT 1 FROM marks m WHERE m.student_id = sah.student_id AND m.exam_id = ? AND m.class_id = sah.class_id)'
        : 'sah.academic_status = "Current" AND s.student_status = "Active"';
    $sql = 'SELECT s.id, s.student_name, s.gender, s.dob, s.banglarshiksha_id, s.pen_id, g.father_name, sah.section_id, sec.section_name, sah.roll_no, stl.subject_id AS tl
        FROM student_academic_history sah
        JOIN students s ON s.id = sah.student_id AND s.student_status <> "Deleted"
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = sah.section_id
        LEFT JOIN student_third_language stl ON stl.student_id = s.id
        WHERE sah.session_id = ? AND sah.class_id = ? AND (' . $who . ')';
    $types = 'ii'; $params = [$session_id, $class_id];
    if ($as_of_exam) { $types .= 'i'; $params[] = $as_of_exam; }
    if ($section_id) { $sql .= ' AND sah.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
    $sql .= ' ORDER BY sec.section_name, CAST(sah.roll_no AS UNSIGNED), sah.roll_no, s.student_name';
    $out = [];
    foreach (db_get_all($sql, $types, ...$params) as $r) {
        $out[$r['id']] = ['uid' => $r['id'], 'name' => $r['student_name'], 'father' => (string)$r['father_name'], 'gender' => (string)$r['gender'], 'dob' => $r['dob'],
            'bsid' => (string)$r['banglarshiksha_id'], 'pen' => (string)$r['pen_id'],
            'section_id' => (int)$r['section_id'], 'section' => (string)$r['section_name'], 'roll' => (string)$r['roll_no'], 'tl' => (int)$r['tl']];
    }
    return $out;
}
/**
 * Find a student by whatever number is at hand, the way the office looks one up:
 *   a School UID (it has letters: ULPHS-2022-0001) · a Banglar Shiksha ID (14 digits, 13 is padded) ·
 *   a PEN (11 digits) · a roll number (1–4 digits — only within a class, since every class has a roll 1).
 * Only Active students on the session's current roll. Returns
 *   ['kind' => uid|bsid|pen|roll|'', 'need_class' => bool, 'hits' => [uid => row]]
 * with row = uid, name, father, class_id, class, stage, section_id, section, roll.
 */
function exam_find_students(int $session_id, string $q, int $class_id = 0, ?int $section_id = null): array {
    $q = trim($q);
    $out = ['kind' => '', 'need_class' => false, 'hits' => []];
    if ($q === '' || mb_strlen($q) > 40) return $out;
    $sql = 'SELECT s.id, s.student_name, g.father_name, sah.class_id, c.class_name, c.stage, sah.section_id, sec.section_name, sah.roll_no
        FROM student_academic_history sah
        JOIN students s ON s.id = sah.student_id AND s.student_status = "Active"
        JOIN classes c ON c.id = sah.class_id
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = sah.section_id
        WHERE sah.session_id = ? AND sah.academic_status = "Current" AND ';
    $types = 'i'; $params = [$session_id];
    $digits = preg_replace('/\s+/', '', $q);
    if (preg_match('/[A-Za-z]/', $q)) {                                   // School UID
        $uid = student_uid_clean($q);
        if ($uid === '') return $out;
        $out['kind'] = 'uid'; $sql .= 's.id = ?'; $types .= 's'; $params[] = $uid;
    } elseif (preg_match('/^\d{13,14}$/', $digits)) {                     // Banglar Shiksha ID
        $out['kind'] = 'bsid'; $sql .= 's.banglarshiksha_id = ?'; $types .= 's'; $params[] = str_pad($digits, 14, '0', STR_PAD_LEFT);
    } elseif (preg_match('/^\d{11}$/', $digits)) {                        // PEN
        $out['kind'] = 'pen'; $sql .= 's.pen_id = ?'; $types .= 's'; $params[] = $digits;
    } elseif (preg_match('/^\d{1,4}$/', $digits)) {                       // roll number — within a class only
        $out['kind'] = 'roll';
        if (!$class_id) { $out['need_class'] = true; return $out; }
        $sql .= 'sah.class_id = ? AND sah.roll_no = ?'; $types .= 'is'; $params[] = $class_id; $params[] = ltrim($digits, '0') === '' ? '0' : ltrim($digits, '0');
        if ($section_id) { $sql .= ' AND sah.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
    } else {
        return $out;
    }
    $sql .= ' ORDER BY c.sort_order, sec.section_name, CAST(sah.roll_no AS UNSIGNED) LIMIT 20';
    foreach (db_get_all($sql, $types, ...$params) as $r) {
        $out['hits'][$r['id']] = ['uid' => $r['id'], 'name' => $r['student_name'], 'father' => (string)$r['father_name'],
            'class_id' => (int)$r['class_id'], 'class' => $r['class_name'], 'stage' => (string)$r['stage'],
            'section_id' => (int)$r['section_id'], 'section' => (string)$r['section_name'], 'roll' => (string)$r['roll_no']];
    }
    return $out;
}

/** Does this student sit this subject? (third language: only the chosen one) */
function exam_student_takes(array $student, array $subject): bool { return !$subject['tl'] || $student['tl'] === $subject['id']; }
/** Sections of a class: id => name. */
function exam_sections(int $session_id, int $class_id): array {
    $o = [];
    foreach (db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id) as $r) $o[(int)$r['id']] = $r['section_name'];
    return $o;
}

/** Existing marks rows of exam × class (all subjects, or one): uid => subject_id => row. */
function exam_marks(int $session_id, int $exam_id, int $class_id, int $subject_id = 0, ?int $section_id = null): array {
    $sql = 'SELECT m.*, a.username AS entered_by_name FROM marks m LEFT JOIN admins a ON a.id = m.entered_by WHERE m.session_id = ? AND m.exam_id = ? AND m.class_id = ?';
    $t = 'iii'; $p = [$session_id, $exam_id, $class_id];
    if ($subject_id) { $sql .= ' AND m.subject_id = ?'; $t .= 'i'; $p[] = $subject_id; }
    if ($section_id) { $sql .= ' AND m.section_id = ?'; $t .= 'i'; $p[] = $section_id; }
    $out = [];
    foreach (db_get_all($sql, $t, ...$p) as $r) $out[$r['student_id']][(int)$r['subject_id']] = $r;
    return $out;
}

/** Entry progress of exam × class: subject_id => ['done' => n, 'total' => eligible students]. */
function exam_entry_status(int $session_id, int $exam_id, int $class_id): array {
    $subs = exam_subjects($session_id, $exam_id, $class_id);
    $students = exam_students($session_id, $class_id);
    $done = [];
    foreach (db_get_all('SELECT subject_id, COUNT(*) AS n FROM marks WHERE session_id = ? AND exam_id = ? AND class_id = ? GROUP BY subject_id', 'iii', $session_id, $exam_id, $class_id) as $r) $done[(int)$r['subject_id']] = (int)$r['n'];
    $out = [];
    foreach ($subs as $sid => $s) {
        $n = 0; foreach ($students as $st) if (exam_student_takes($st, $s)) $n++;
        $out[$sid] = ['done' => $done[$sid] ?? 0, 'total' => $n, 'configured' => $s['configured']];
    }
    return $out;
}

/** Parse a marks value: '' => null, else float with ≤ 2 decimals within [0, max]. Returns [value, error]. */
function exam_parse_mark(string $v, float $max): array {
    $v = trim($v);
    if ($v === '') return [null, null];
    if (!preg_match('/^\d{1,3}(\.\d{1,2})?$/', $v)) return [null, 'not a number'];
    $f = (float)$v;
    if ($f > $max) return [null, "exceeds full marks ($max)"];
    return [$f, null];
}

/**
 * Save marks of one exam × class × subject. $rows = uid => ['written' => '', 'project' => '', 'absent' => bool].
 * Blank written+project and not absent = not entered → any existing row is deleted (unless it carries grace marks).
 * All rows are validated first; nothing is written when any row fails. Grace marks are never touched here.
 * $admin_id 0 = a teacher (entered_by stays empty). $log false = the caller writes its own, more precise log line.
 */
function marks_save_rows(int $session_id, int $exam_id, int $class_id, int $subject_id, array $rows, int $admin_id, bool $log = true): array {
    $subs = exam_subjects($session_id, $exam_id, $class_id);
    $sub = $subs[$subject_id] ?? null;
    if (!$sub) return ['ok' => false, 'errors' => ['_' => 'Subject is not part of this class']];
    if (!$sub['configured']) return ['ok' => false, 'errors' => ['_' => 'Full marks are not set for this subject — set them under Full & Pass Marks first']];
    $students = exam_students($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $uid => $r) {
        $uid = student_uid_clean($uid);
        $st = $students[$uid] ?? null;
        if (!$st) { $errors[$uid] = 'not a current student of this class'; continue; }
        if (!exam_student_takes($st, $sub)) { $errors[$uid] = 'does not take this subject'; continue; }
        $absent = !empty($r['absent']);
        [$w, $e1] = exam_parse_mark((string)($r['written'] ?? ''), $sub['written_full']);
        [$p, $e2] = exam_parse_mark((string)($r['project'] ?? ''), $sub['project_full']);
        if ($e1) { $errors[$uid] = 'Written: ' . $e1; continue; }
        if ($e2) { $errors[$uid] = 'Project: ' . $e2; continue; }
        if ($sub['project_full'] <= 0) $p = null;
        if ($absent) $clean[$uid] = ['w' => 0.0, 'p' => 0.0, 'absent' => 1, 'section' => $st['section_id']];
        elseif ($w === null && $p === null) $clean[$uid] = null;   // clear
        else $clean[$uid] = ['w' => $w ?? 0.0, 'p' => $p ?? 0.0, 'absent' => 0, 'section' => $st['section_id']];
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $saved = 0; $deleted = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $v) {
            if ($v === null) {
                $deleted += (int)db_execute('DELETE FROM marks WHERE student_id = ? AND session_id = ? AND exam_id = ? AND subject_id = ? AND grace_marks = 0', 'siii', $uid, $session_id, $exam_id, $subject_id);
                continue;
            }
            $ok = db_execute('INSERT INTO marks (student_id, session_id, class_id, section_id, exam_id, subject_id, written_marks, project_marks, marks, is_absent, entered_by)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE class_id = VALUES(class_id), section_id = VALUES(section_id), written_marks = VALUES(written_marks), project_marks = VALUES(project_marks),
                    marks = VALUES(marks), is_absent = VALUES(is_absent), entered_by = VALUES(entered_by)',
                'siiiiidddii', $uid, $session_id, $class_id, $v['section'] ?: null, $exam_id, $subject_id, $v['w'], $v['p'], $v['w'] + $v['p'], $v['absent'], $admin_id ?: null);
            if ($ok === false) throw new RuntimeException('marks upsert failed');
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('marks_save_rows: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    if ($log) log_action($admin_id, 'MARKS_SAVED', 'marks', $exam_id, null, ['class_id' => $class_id, 'subject_id' => $subject_id, 'saved' => $saved, 'cleared' => $deleted]);
    return ['ok' => true, 'saved' => $saved, 'cleared' => $deleted];
}

/** Grace marks: $rows = uid => ['grace' => '', 'reason' => '']. Only rows that already have marks; obtained marks untouched. */
function marks_save_grace(int $session_id, int $exam_id, int $class_id, int $subject_id, array $rows, int $admin_id, float $max_grace = 10): array {
    $errors = []; $clean = [];
    foreach ($rows as $uid => $r) {
        $uid = student_uid_clean($uid);
        [$g, $e] = exam_parse_mark((string)($r['grace'] ?? ''), $max_grace);
        if ($e) { $errors[$uid] = 'Grace: ' . $e; continue; }
        $reason = mb_substr(trim((string)($r['reason'] ?? '')), 0, 120);
        if (($g ?? 0) > 0 && $reason === '') { $errors[$uid] = 'a reason is needed for grace marks'; continue; }
        $clean[$uid] = ['g' => $g ?? 0.0, 'reason' => $reason];
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $n = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $v) {
            $n += (int)db_execute('UPDATE marks SET grace_marks = ?, grace_reason = ? WHERE student_id = ? AND session_id = ? AND exam_id = ? AND subject_id = ?', 'dssiii', $v['g'], $v['g'] > 0 ? $v['reason'] : null, $uid, $session_id, $exam_id, $subject_id);
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); return ['ok' => false, 'errors' => ['_' => 'Save failed']]; }
    log_action($admin_id, 'GRACE_MARKS_SAVED', 'marks', $exam_id, null, ['class_id' => $class_id, 'subject_id' => $subject_id, 'rows' => $n]);
    return ['ok' => true, 'saved' => $n];
}

/**
 * Formative marks obtained (Σ nine parts) from hprc_formative: uid => subject_id => ['total' => x, 'parts' => [f1 => , f2 => , f3 => ]].
 * A part not yet entered is NULL and counts as 0 here. Formative has no full marks and is shown on the
 * report card only — nothing adds it to a total.
 */
function exam_formative_marks(int $session_id, int $class_id, ?int $section_id = null): array {
    $sql = 'SELECT student_id, subject_id,
                   COALESCE(f1a, 0) + COALESCE(f1b, 0) + COALESCE(f1c, 0) AS f1,
                   COALESCE(f2a, 0) + COALESCE(f2b, 0) + COALESCE(f2c, 0) AS f2,
                   COALESCE(f3a, 0) + COALESCE(f3b, 0) + COALESCE(f3c, 0) AS f3
            FROM hprc_formative WHERE session_id = ? AND class_id = ?';
    $t = 'ii'; $p = [$session_id, $class_id];
    if ($section_id) { $sql .= ' AND section_id = ?'; $t .= 'i'; $p[] = $section_id; }
    $o = [];
    foreach (db_get_all($sql, $t, ...$p) as $r) $o[$r['student_id']][(int)$r['subject_id']] = ['total' => (float)$r['f1'] + (float)$r['f2'] + (float)$r['f3'], 'parts' => [(float)$r['f1'], (float)$r['f2'], (float)$r['f3']]];
    return $o;
}

/** Number formatting for marks: 45 → "45", 45.5 → "45.5". */
function exam_fmt($n): string { if ($n === null) return ''; $n = (float)$n; return rtrim(rtrim(number_format($n, 2, '.', ''), '0'), '.'); }

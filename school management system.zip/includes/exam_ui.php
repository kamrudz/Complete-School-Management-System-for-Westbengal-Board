<?php
/**
 * Shared look of the exam pages: banner, tab strip, workflow steps, flash messages, tables, Excel headings.
 *
 * One shell, two palettes. exam_styles('vx') paints the V–X pages purple, exam_styles('hs') paints the
 * Higher Secondary pages teal, so nobody enters XI–XII marks believing they are on a V–X page. Every colour
 * is a CSS variable on :root, so a page only picks a theme — it never repeats a colour.
 */
if (!function_exists('h')) { function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

const EXAM_PAGES = [
    'exams.php' => ['Exams', 'fa-clipboard-list'],
    'exam_subject_marks.php' => ['Full & Pass Marks', 'fa-sliders-h'],
    'marks_entry.php' => ['Marks Entry', 'fa-edit'],
    'bulk_marks_upload.php' => ['Bulk Upload', 'fa-file-excel'],
    'bulk_grace_marks.php' => ['Grace Marks', 'fa-hand-holding-heart'],
    'tabulation_sheet.php' => ['Tabulation', 'fa-table'],
    'annual_result.php' => ['Annual Result', 'fa-award'],
    'report_card.php' => ['Report Card', 'fa-id-card'],
    'student_merit_ranks.php' => ['Merit List', 'fa-trophy'],
    'pass_fail_settings.php' => ['Rules & Grades', 'fa-cog'],
];

/** Palette per theme: dark, light, soft background, border, group background, muted, banner subtitle. */
const EXAM_THEMES = [
    'vx' => ['#3b1d5c', '#7a3fa3', '#f3eef8', '#d9c9ea', '#e9e1f2', '#b7a6cc', '#e6d9f3', '59,29,92'],
    'hs' => ['#0f4c5c', '#1e88a8', '#eaf4f7', '#c4dfe6', '#dbeef4', '#8fc2d2', '#d7edf4', '15,76,92'],
    'fee' => ['#14532d', '#1f8a4c', '#ecf7f0', '#c3e6cf', '#dcf1e3', '#9fcfb0', '#d3f0dd', '20,83,45'],
    'acc' => ['#1e3a8a', '#2f62d6', '#eef3fe', '#c8d6f7', '#dfe7fb', '#9fb4e6', '#d5e1fb', '30,58,138'],
    'adm' => ['#7c2d12', '#c2630f', '#fdf3ea', '#f3d5b5', '#f8e6d2', '#dfb98a', '#f7dfc4', '124,45,18'],
    'rpt' => ['#263548', '#4d7396', '#eff2f6', '#ccd7e3', '#dfe6ee', '#a6b6c6', '#dde5ed', '38,53,72'],
    'site' => ['#2a2886', '#3e3cb8', '#f1f0fb', '#d9d8f0', '#e6e5f7', '#a9a8d8', '#dedcf7', '42,40,134'],
    'web' => ['#0f3d33', '#1f8f70', '#edf7f3', '#c4e4d8', '#dcefe7', '#9ccdb9', '#d2ece2', '15,61,51'],
];

function exam_styles(string $theme = 'vx'): void {
    [$dark, $light, $soft, $border, $group, $muted, $sub, $rgb] = EXAM_THEMES[$theme] ?? EXAM_THEMES['vx']; ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    :root { --ex-dark: <?php echo $dark; ?>; --ex-light: <?php echo $light; ?>; --ex-soft: <?php echo $soft; ?>; --ex-border: <?php echo $border; ?>; --ex-group: <?php echo $group; ?>; --ex-muted: <?php echo $muted; ?>; --ex-sub: <?php echo $sub; ?>; --ex-rgb: <?php echo $rgb; ?>; }
    .ex-banner { background: linear-gradient(135deg, var(--ex-dark) 0%, var(--ex-light) 100%); color: #fff; border-radius: 14px; padding: 16px 22px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 12px; box-shadow: 0 8px 24px rgba(var(--ex-rgb), .25); }
    .ex-banner .ico { width: 50px; height: 50px; border-radius: 14px; background: rgba(255,255,255,.15); display: flex; align-items: center; justify-content: center; font-size: 22px; }
    .ex-banner h1 { margin: 0; font-size: 21px; } .ex-banner p { margin: 3px 0 0; font-size: 12.5px; color: var(--ex-sub); }
    .ex-banner .links { margin-left: auto; display: flex; gap: 8px; flex-wrap: wrap; } .ex-banner .links a, .ex-banner .links button { background: rgba(255,255,255,.14); color: #fff; border: 1px solid rgba(255,255,255,.35); padding: 7px 13px; border-radius: 9px; text-decoration: none; font-size: 13px; font-weight: 600; white-space: nowrap; cursor: pointer; }
    .ex-tabs { display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 14px; } .ex-tabs a { padding: 6px 11px; border-radius: 8px; background: var(--ex-soft); border: 1px solid var(--ex-border); font-size: 12px; font-weight: 600; color: var(--ex-dark); text-decoration: none; } .ex-tabs a.on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); } .ex-tabs a i { margin-right: 4px; }
    .card { background: #fff; border: 1px solid #dfe7ef; border-radius: 14px; padding: 16px 18px; margin-bottom: 14px; } .card h2 { margin: 0 0 10px; font-size: 15px; color: var(--ex-dark); } .card h2 small { font-weight: 400; color: #6b7d90; font-size: 12px; }
    .pick { display: flex; gap: 10px; flex-wrap: wrap; align-items: flex-end; } .pick label { display: block; font-size: 11px; font-weight: 700; color: #3b5168; margin: 0 0 4px; text-transform: uppercase; } .pick select, .pick input { height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; min-width: 150px; background: #fff; }
    .pf label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin: 10px 0 4px; text-transform: uppercase; } .pf input, .pf select, .pf textarea { width: 100%; height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; font-size: 13.5px; background: #fff; } .pf .row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; } .pf .acts { margin-top: 14px; display: flex; gap: 8px; } .pf .chk { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 13px; } .pf .chk input { width: auto; height: auto; }
    .ex-table { width: 100%; border-collapse: collapse; font-size: 13px; } .ex-table th { background: var(--ex-soft); color: var(--ex-dark); text-align: left; padding: 8px 9px; font-size: 11.5px; text-transform: uppercase; letter-spacing: .3px; border-bottom: 2px solid var(--ex-border); } .ex-table td { padding: 7px 9px; border-bottom: 1px solid #edf1f5; vertical-align: middle; } .ex-table tr:hover td { background: var(--ex-soft); }
    .ex-table td.num, .ex-table th.num { text-align: center; font-variant-numeric: tabular-nums; } .ex-table input.m { width: 64px; height: 32px; text-align: center; border: 1px solid #c9d6e2; border-radius: 6px; font-size: 13px; } .ex-table input.m.bad { border-color: #d32f2f; background: #fff2f2; } .ex-table input.m:disabled { background: #f2f2f2; color: #999; }
    .ex-empty { padding: 26px; text-align: center; color: #7a8a9a; background: #fafbfc; border: 1px dashed #d5dde5; border-radius: 10px; font-size: 13.5px; } .ex-empty i { display: block; font-size: 26px; margin-bottom: 6px; color: var(--ex-muted); }
    .chip { display: inline-block; padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 700; } .chip.ok { background: #e6f5ea; color: #1b7a3a; border: 1px solid #b6e2c2; } .chip.warn { background: #fff6e5; color: #7a4a00; border: 1px solid #f0c987; } .chip.off { background: #eef1f4; color: #55677a; border: 1px solid #d5dde5; } .chip.bad { background: #fdecea; color: #b71c1c; border: 1px solid #f5b5b0; }
    .strip { display: flex; gap: 6px; flex-wrap: wrap; margin: 8px 0 12px; } .strip a, .strip span { padding: 5px 9px; border-radius: 8px; font-size: 12px; text-decoration: none; border: 1px solid #d5dde5; color: #3b5168; background: #fff; } .strip .done { background: #e6f5ea; border-color: #b6e2c2; color: #1b7a3a; } .strip .part { background: #fff6e5; border-color: #f0c987; color: #7a4a00; } .strip .on { outline: 2px solid var(--ex-light); } .strip .nocfg { opacity: .55; }
    .btn { padding: 8px 14px; font-size: 13px; } .btn-sm { padding: 5px 9px; font-size: 12px; }
    .note { font-size: 12.5px; color: #6b7d90; margin: 8px 0 0; }
    .modal { position: fixed; inset: 0; background: rgba(0,0,0,.45); display: none; align-items: center; justify-content: center; z-index: 1000; } .modal.open { display: flex; } .modal .box { background: #fff; border-radius: 14px; padding: 18px 20px; width: min(520px, 94vw); max-height: 92vh; overflow: auto; }
    /* Workflow bar: the six steps of the module, with a tick on the ones already done. */
    .ex-steps { display: flex; gap: 6px; flex-wrap: wrap; margin: 0 0 14px; }
    .ex-steps a { display: inline-flex; align-items: center; gap: 7px; padding: 7px 13px; border-radius: 999px; border: 1px solid var(--ex-border); background: #fff; color: var(--ex-dark); text-decoration: none; font-size: 12.5px; font-weight: 600; }
    .ex-steps a b { background: var(--ex-soft); color: var(--ex-dark); border-radius: 50%; width: 21px; height: 21px; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; }
    .ex-steps a small { font-weight: 400; opacity: .75; font-size: 11px; }
    .ex-steps a.on { background: var(--ex-dark); color: #fff; border-color: var(--ex-dark); } .ex-steps a.on b { background: rgba(255,255,255,.25); color: #fff; }
    .ex-steps a.ok b { background: #1b7a3a; color: #fff; }
    /* Guard card: what is missing before this page can be used. */
    .ex-guard { display: flex; gap: 12px; align-items: flex-start; background: #fff8e8; border: 1px solid #f0c987; border-radius: 12px; padding: 14px 16px; margin-bottom: 14px; font-size: 13px; color: #6b4a00; }
    .ex-guard i.big { font-size: 20px; margin-top: 2px; } .ex-guard b { display: block; margin-bottom: 2px; color: #7a4a00; } .ex-guard a { font-weight: 700; }
    @media print { .navbar, .ex-banner .links, .ex-tabs, .ex-steps, .noprint { display: none !important; } .page-box { padding: 0 !important; } .card { border: 0; padding: 0; } }
</style>
<link rel="stylesheet" href="../assets/css/global-responsive.css">
<script src="../assets/js/global-responsive.js" defer></script>
<?php }

function exam_banner(string $title, string $sub, string $icon = 'fa-clipboard-list', array $links = []): void { ?>
<div class="ex-banner">
    <div class="ico"><i class="fas <?php echo h($icon); ?>"></i></div>
    <div><h1><?php echo h($title); ?></h1><p><?php echo h($sub); ?></p></div>
    <?php if ($links): ?><div class="links"><?php foreach ($links as $href => $label) echo '<a href="' . h($href) . '">' . $label . '</a>'; ?></div><?php endif; ?>
</div>
<?php }

/**
 * The module's page strip. $qs travels with every link — the exam pages are shared by the sections
 * (Primary & Upper Primary, Secondary), so "section=..." has to survive a move between them.
 */
function exam_tabs(string $active, array $pages = EXAM_PAGES, string $qs = ''): void {
    $q = $qs !== '' ? '?' . ltrim($qs, '?&') : '';
    echo '<div class="ex-tabs">';
    foreach ($pages as $file => [$label, $icon]) {
        if (!exam_page_exists($file)) continue;   // a page of the module that is not built yet is not offered
        echo '<a href="' . h($file . $q) . '" class="' . ($file === $active ? 'on' : '') . '"><i class="fas ' . h($icon) . '"></i>' . h($label) . '</a>';
    }
    echo '</div>';
}

/** Is this admin page actually present? Keeps tab strips and workflow bars free of links that would 404. */
function exam_page_exists(string $file): bool {
    static $seen = [];
    if (!isset($seen[$file])) $seen[$file] = is_file(dirname(__DIR__) . '/admin/' . basename(strstr($file, '?', true) ?: $file));   // a tab may carry a query
    return $seen[$file];
}

/**
 * Workflow bar. $steps = [file => [label, hint, done]] — 'done' draws a green tick, the active page is filled in.
 * Query string (session/class) is carried to every step so a click never loses the context.
 */
function exam_steps(array $steps, string $active, string $qs = ''): void {
    echo '<div class="ex-steps">';
    $i = 0;
    foreach ($steps as $file => [$label, $hint, $done]) {
        if (!exam_page_exists($file)) continue;   // a step whose page is not built yet is left out
        $i++;
        $cls = $file === $active ? 'on' : ($done ? 'ok' : '');
        echo '<a href="' . h($file) . ($qs !== '' ? '?' . h($qs) : '') . '" class="' . $cls . '" title="' . h($hint) . '"><b>' . ($done && $file !== $active ? '&#10003;' : $i) . '</b> ' . h($label) . ($hint !== '' ? ' <small>' . h($hint) . '</small>' : '') . '</a>';
    }
    echo '</div>';
}

/** Guard card: this page needs something from an earlier step. */
function exam_guard(string $title, string $detail, string $href = '', string $link_label = ''): void {
    echo '<div class="ex-guard"><i class="fas fa-exclamation-triangle big"></i><div><b>' . h($title) . '</b>' . h($detail);
    if ($href !== '') echo ' <a href="' . h($href) . '">' . h($link_label ?: 'Open') . ' &rarr;</a>';
    echo '</div></div>';
}

function exam_flash(): void {
    if (isset($_SESSION['success'])) { echo '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . h($_SESSION['success']) . '</div>'; unset($_SESSION['success']); }
    if (isset($_SESSION['error'])) { echo '<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> ' . h($_SESSION['error']) . '</div>'; unset($_SESSION['error']); }
}

/** Sessions for a dropdown: id => name (Active first). */
function exam_sessions(): array {
    $o = [];
    foreach (db_get_all("SELECT id, session_name, status FROM academic_sessions ORDER BY status = 'Active' DESC, session_name DESC") as $r) $o[(int)$r['id']] = $r['session_name'] . ((string)$r['status'] === 'Active' ? ' (Active)' : '');
    return $o;
}
/** <option> list. */
function exam_options(array $items, $selected, string $placeholder = ''): string {
    $s = $placeholder !== '' ? '<option value="">' . h($placeholder) . '</option>' : '';
    foreach ($items as $v => $label) $s .= '<option value="' . h($v) . '"' . ((string)$v === (string)$selected ? ' selected' : '') . '>' . h($label) . '</option>';
    return $s;
}
/** School header block for print views. */
function exam_school_header(string $title, string $sub = '', bool $logo = true, bool $address = true): void {
    $s = db_get_row('SELECT school_name, school_address, udise_code, established_year, logo FROM school_settings WHERE id = 1') ?: [];
    echo '<div class="school-head" style="text-align:center;border-bottom:2px solid #333;padding-bottom:6px;margin-bottom:10px">';
    if ($logo && !empty($s['logo'])) echo '<img src="../uploads/' . h($s['logo']) . '" alt="" style="height:54px;float:left">';
    echo '<div style="font-size:19px;font-weight:800;letter-spacing:.5px">' . h($s['school_name'] ?? '') . '</div>';
    if ($address) echo '<div style="font-size:11.5px">' . h($s['school_address'] ?? '') . (!empty($s['udise_code']) ? ' · UDISE ' . h($s['udise_code']) : '') . (!empty($s['established_year']) ? ' · Estd. ' . (int)$s['established_year'] : '') . '</div>';
    echo '<div style="font-size:14px;font-weight:700;margin-top:4px">' . h($title) . '</div>' . ($sub !== '' ? '<div style="font-size:12px">' . h($sub) . '</div>' : '') . '<div style="clear:both"></div></div>';
}
/** Plain session name (no "(Active)" suffix) for print views. */
function exam_session_name(int $session_id): string { return (string)(db_get_row('SELECT session_name FROM academic_sessions WHERE id = ?', 'i', $session_id)['session_name'] ?? ''); }

/**
 * Title rows for an Excel export: school name, what the sheet is, and when it was made.
 * Use together with exam_xlsx_opts() so the three rows are merged across the sheet.
 */
function exam_xlsx_title(string $subtitle, string $note = ''): array {
    $school = (string)(db_get_row('SELECT school_name FROM school_settings WHERE id = 1')['school_name'] ?? '');
    return [[$school], [$subtitle], [($note !== '' ? $note . '  ·  ' : '') . 'Generated ' . date('d M Y, g:i a')]];
}
/** Writer options for an export with three merged title rows and compact columns. */
function exam_xlsx_opts(int $width, int $max_col_width = 16): array {
    $last = SimpleXLSXWriter::columnName(max(1, $width));
    return ['title_rows' => 3, 'header_rows' => 1, 'max_col_width' => $max_col_width,
        'merge_cells' => ['A1:' . $last . '1', 'A2:' . $last . '2', 'A3:' . $last . '3']];
}
/**
 * A whole number written out, the way a board mark sheet prints the grand total:
 * 458 → "Four Hundred Fifty Eight". Indian reading, up to a few lakh — more than any total needs.
 */
function exam_words(int $n): string {
    if ($n === 0) return 'Zero';
    if ($n < 0) return 'Minus ' . exam_words(-$n);
    $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve',
        'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    $under100 = function (int $x) use ($ones, $tens): string {
        if ($x < 20) return $ones[$x];
        return trim($tens[intdiv($x, 10)] . ' ' . $ones[$x % 10]);
    };
    $out = '';
    foreach ([10000000 => 'Crore', 100000 => 'Lakh', 1000 => 'Thousand', 100 => 'Hundred'] as $unit => $name) {
        if ($n >= $unit) { $out .= exam_words(intdiv($n, $unit)) . ' ' . $name . ' '; $n %= $unit; }
    }
    return trim($out . $under100($n));
}

/** Long subject names over two lines so the column stays narrow. */
function exam_xlsx_wrap(string $name, int $max = 11): string { return mb_strlen($name) > $max ? str_replace(' ', "\n", $name) : $name; }

/** Short code for a subject in an Excel heading: the subject's own code, else initials (Physical Education → PE) or the first 4 letters. */
function exam_subject_code(array $s): string {
    $code = strtoupper(trim((string)($s['code'] ?? '')));
    if ($code !== '') return mb_substr($code, 0, 6);   // the subject's own code always wins
    $name = trim((string)($s['name'] ?? ''));
    $words = preg_split('/\s+/', $name, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    if (count($words) > 1) return mb_strtoupper(implode('', array_map(fn($w) => mb_substr($w, 0, 1), array_slice($words, 0, 4))));   // Physical Education → PE
    return mb_strtoupper(mb_substr($name, 0, 4));
}
/** "BENG Bengali · ENG English · …" for the note row of an export. */
function exam_subject_legend(array $subjects): string {
    $p = [];
    foreach ($subjects as $s) { $c = exam_subject_code($s); if ($c !== mb_strtoupper($s['name'])) $p[] = $c . ' ' . $s['name']; }
    return $p ? 'Subjects: ' . implode('  ·  ', $p) : '';
}

/* ───────────────────────── Higher Secondary (XI–XII) ───────────────────────── */

const HS_PAGES = [
    'hs_exams.php' => ['Semester Exams', 'fa-clipboard-list'],
    'hs_exam_subject_marks.php' => ['Full & Pass Marks', 'fa-sliders-h'],
    'hs_subjects.php' => ['Subject Combination', 'fa-book-open'],
    'hs_marks_entry.php' => ['Marks Entry', 'fa-edit'],
    'hs_bulk_marks_upload.php' => ['Bulk Upload', 'fa-file-excel'],
    'hs_tabulation.php' => ['Tabulation', 'fa-table'],
    'hs_report_card.php' => ['Report Card', 'fa-id-card'],
    'student_merit_ranks.php?section=hs' => ['Merit List', 'fa-trophy'],
    'hs_registration.php' => ['WBCHSE Registration', 'fa-id-badge'],
];
function hs_tabs(string $active): void { exam_tabs($active, HS_PAGES); }

/**
 * The six steps of the HS module with their live state, for exam_steps().
 * Counts are cheap (COUNT(*) on indexed columns) and tell the user what is still missing.
 */
function hs_workflow(int $session_id, int $class_id): array {
    $ex = $class_id ? (int)(db_get_row('SELECT COUNT(*) n FROM hs_exam WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
    $cfg = $class_id ? (int)(db_get_row('SELECT COUNT(*) n FROM hs_exam_subject_marks WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
    $comb = $class_id ? (int)(db_get_row('SELECT COUNT(DISTINCT student_id) n FROM hs_student_subjects WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
    $marks = $class_id ? (int)(db_get_row('SELECT COUNT(*) n FROM hs_marks m JOIN hs_exam e ON e.id = m.hs_exam_id WHERE e.session_id = ? AND e.class_id = ?', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
    $published = $class_id ? (int)(db_get_row('SELECT COUNT(*) n FROM hs_exam WHERE session_id = ? AND class_id = ? AND is_published = 1', 'ii', $session_id, $class_id)['n'] ?? 0) : 0;
    return [
        'hs_exams.php' => ['Semester Exams', $ex ? $ex . ' created' : 'none yet', $ex > 0],
        'hs_exam_subject_marks.php' => ['Full & Pass Marks', $cfg ? $cfg . ' subjects' : 'not set', $cfg > 0],
        'hs_subjects.php' => ['Subject Combination', $comb ? $comb . ' students' : 'none yet', $comb > 0],
        'hs_marks_entry.php' => ['Marks Entry', $marks ? $marks . ' marks' : 'none yet', $marks > 0],
        'hs_tabulation.php' => ['Tabulation', $marks ? 'ready' : 'waiting', $marks > 0],
        'hs_report_card.php' => ['Result & Report', $published ? $published . ' published' : 'not published', $published > 0],
    ];
}

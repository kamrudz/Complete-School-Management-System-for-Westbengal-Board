<?php
/** Shared look of the Export pages (students, staff): filter bar, presets, field groups, preview, download bar. */
function export_styles(): void { ?>
<style>
    .ex-filter { display: flex; gap: 10px; flex-wrap: wrap; align-items: end; background: #f5f9fc; border: 1px solid #e1eaf2; border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; }
    .ex-filter label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin-bottom: 4px; text-transform: uppercase; letter-spacing: .4px; }
    .ex-filter input, .ex-filter select { height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; background: #fff; font-size: 13.5px; min-width: 140px; }
    .ex-count { display: inline-flex; align-items: center; gap: 8px; background: #003366; color: #fff; padding: 8px 14px; border-radius: 999px; font-weight: 700; }
    .ex-presets { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; margin: 14px 0 10px; }
    .ex-presets .p { border: 1px solid #c9d6e2; background: #fff; border-radius: 999px; padding: 6px 14px; cursor: pointer; font-size: 13px; font-weight: 600; color: #1f4e79; }
    .ex-presets .p:hover { background: #eaf2fb; }
    .ex-groups { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; }
    .ex-group { border: 1px solid #dfe7ef; border-radius: 12px; overflow: hidden; background: #fff; }
    .ex-group h4 { margin: 0; padding: 9px 12px; background: linear-gradient(90deg, #145da0, #2f7ab8); color: #fff; font-size: 13px; display: flex; align-items: center; gap: 8px; }
    .ex-group h4 .mini { margin-left: auto; font-size: 11px; font-weight: 500; opacity: .9; cursor: pointer; }
    .ex-group .body { padding: 8px 12px; display: grid; grid-template-columns: 1fr 1fr; gap: 3px 10px; }
    .ex-group label { font-size: 13px; display: flex; align-items: center; gap: 6px; padding: 3px 0; cursor: pointer; }
    .ex-prev-head { margin: 16px 0 6px; color: #1f4e79; display: flex; gap: 10px; align-items: baseline; } .ex-prev-head span { color: #6b7d90; font-size: 12.5px; }
    .ex-prev { overflow: auto; max-height: 420px; border: 1px solid #dfe7ef; border-radius: 10px; background: #fff; }
    .ex-prev table { border-collapse: collapse; font-size: 12.5px; min-width: 100%; }
    .ex-prev th { position: sticky; top: 0; background: #1f4e79; color: #fff; padding: 7px 10px; text-align: left; white-space: nowrap; font-size: 11.5px; }
    .ex-prev td { padding: 5px 10px; border-bottom: 1px solid #eef2f6; white-space: nowrap; }
    .ex-prev tr:nth-child(even) td { background: #f8fafc; }
    .ex-bar { position: sticky; bottom: 0; background: rgba(255,255,255,.96); border: 1px solid #dfe7ef; border-radius: 12px; padding: 12px 16px; margin-top: 14px; display: flex; align-items: center; gap: 12px; box-shadow: 0 -2px 10px rgba(20,50,80,.06); }
    .ex-bar .spacer { flex: 1; } .ex-bar .sel { color: #6b7d90; font-size: 13px; }
</style>
<?php }

<?php
/**
 * Fees: the fees the school collects (fee_types) and what each class pays (fee_structures); a bill for each fee a
 * student pays (fee_invoices + fee_invoice_items), made when the money is taken; money receipts in two books — with a
 * slip and without (fee_receipts) — and the receipt lines that pay the bills (fee_transactions). Money is counted in
 * paise. A bill or a receipt is cancelled with a reason, never deleted.
 */
require_once __DIR__ . '/exam_ui.php';

const FEE_METHODS = ['cash' => 'Cash', 'upi' => 'UPI', 'bank' => 'Bank transfer', 'cheque' => 'Cheque'];
const FEE_CHARGES = ['session' => 'By class, once a session', 'any' => 'Any amount, written when collected'];
const FEE_WHO_PAYS = ['everyone' => 'Everyone', 'some' => 'Some students', 'new' => 'New admissions only', 'continuing' => 'Continuing students only', 'sentup' => 'Sent-up students only (X, XII)'];
/** The two receipt books: fees given a slip, and cash kept without one. Each is numbered on its own. */
const FEE_BOOKS = ['main' => 'With slip', 'cash' => 'No slip (cash)'];
/** What a slip can show besides its number, date, student, lines and total: group => key => [label, on by default]. */
const FEE_SLIP_FIELDS = [
    'School'  => ['logo' => ['School logo', true], 'address' => ['Address and UDISE', true], 'session' => ['Session', true]],
    'Student' => ['uid' => ['School UID', true], 'bsid' => ['Banglar Shiksha ID', false], 'class' => ['Class, section and roll', true], 'father' => ["Father's name", true], 'mobile' => ['Mobile number', false]],
    'Payment' => ['items' => ['Heads and discount', true], 'balance' => ['Balance left after it', true], 'words' => ['Amount in words', true], 'method' => ['Paid by and reference', true], 'remarks' => ['Remarks', true]],
    'Bottom'  => ['received' => ['Received by (name)', true], 'signature' => ['Signature line', true], 'note' => ['Receipt note', true]],
];
const FEE_PAGES = [
    'collect_fee.php'       => ['Collect', 'fa-cash-register'],
    'fee_receipts.php'      => ['Receipts', 'fa-receipt'],
    'fee_report.php'        => ['Reports', 'fa-chart-bar'],
    'fee_settings.php'      => ['Fee Settings', 'fa-sliders-h'],
    'student_discounts.php' => ['Discounts', 'fa-percent'],
];

function fee_tabs(string $active): void { exam_tabs($active, FEE_PAGES); }

function fee_log(int $admin_id, string $action, string $table, $id, $old = null, $new = null): void {
    if (function_exists('log_action')) log_action($admin_id, $action, $table, $id, $old, $new);
}

function fee_paise($rupees): int { return (int)round((float)$rupees * 100); }
function fee_rupees(int $paise): string { return number_format($paise / 100, 2, '.', ''); }
function fee_money($rupees): string { return fee_money_p(fee_paise($rupees)); }
/** ₹12,34,567.50 */
function fee_money_p(int $paise): string {
    $sign = $paise < 0 ? '-' : '';
    $paise = abs($paise);
    $r = (string)intdiv($paise, 100);
    if (strlen($r) > 3) $r = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', substr($r, 0, -3)) . ',' . substr($r, -3);
    return $sign . '₹' . $r . '.' . sprintf('%02d', $paise % 100);
}
/** 12,34,567.50 — the same without the ₹, for columns that say ₹ in their heading. */
function fee_num_p(int $paise): string { return str_replace('₹', '', fee_money_p($paise)); }
function fee_words(int $paise): string {
    $r = intdiv($paise, 100); $p = $paise % 100;
    return 'Rupees ' . exam_words($r) . ($p ? ' and ' . exam_words($p) . ' Paise' : '') . ' Only';
}
/** A typed amount in paise (up to two decimals, commas allowed), or null. */
function fee_amount_in($v): ?int {
    $v = trim(str_replace(',', '', (string)$v));
    return preg_match('/^\d{1,7}(\.\d{1,2})?$/', $v) ? fee_paise($v) : null;
}
function fee_valid_date(string $v): bool {
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    return $d && $d->format('Y-m-d') === $v;
}

function fee_settings(bool $fresh = false): array {
    static $s = null;
    if ($s === null || $fresh) $s = (db_get_row('SELECT * FROM fee_settings WHERE id = 1') ?: [])
        + ['receipt_prefix' => 'R', 'cash_prefix' => 'C', 'receipt_copies' => 2, 'slip_title' => 'MONEY RECEIPT', 'slip_fields' => null, 'monthly_enabled' => 0, 'receipt_note' => ''];
    return $s;
}
/** What the slip shows: key => on. Saved as a list of the keys that are on; nothing saved means the defaults. */
function fee_slip_fields(): array {
    $saved = json_decode((string)(fee_settings()['slip_fields'] ?? ''), true);
    $out = [];
    foreach (FEE_SLIP_FIELDS as $fields) foreach ($fields as $k => [, $on]) $out[$k] = is_array($saved) ? in_array($k, $saved, true) : $on;
    return $out;
}
function fee_book_prefix(string $book): string {
    return trim((string)fee_settings()[$book === 'cash' ? 'cash_prefix' : 'receipt_prefix']);
}
/** "V–X ₹240 · XI–XII ₹500" from class id => paise, runs of classes in their order; "All classes ₹60" when every class pays the same. */
function fee_amount_summary(array $by_class, array $classes): string {
    if (!$by_class) return '';
    $runs = [];
    foreach ($classes as $cid => $c) {
        $p = $by_class[$cid] ?? 0;
        $last = $runs ? count($runs) - 1 : -1;
        if ($p && $last >= 0 && $runs[$last]['p'] === $p && $runs[$last]['open']) { $runs[$last]['to'] = $c['name']; continue; }
        if ($last >= 0) $runs[$last]['open'] = false;
        if ($p) $runs[] = ['from' => $c['name'], 'to' => $c['name'], 'p' => $p, 'open' => true];
    }
    $money = fn(int $p) => preg_replace('/\.00$/', '', fee_money_p($p));
    if (count($runs) === 1 && count(array_filter($by_class)) === count($classes)) return 'All classes ' . $money($runs[0]['p']);
    return implode(' · ', array_map(fn($r) => ($r['from'] === $r['to'] ? $r['from'] : $r['from'] . '–' . $r['to']) . ' ' . $money($r['p']), $runs));
}

function fee_active_session_id(): int {
    return (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
}
/** The session a student studies in now — the active one when they are in it, else their latest; the active session when none. */
function fee_student_session(string $uid): int {
    return (int)(db_get_row("SELECT h.session_id FROM student_academic_history h JOIN academic_sessions se ON se.id = h.session_id WHERE h.student_id = ? AND h.academic_status = 'Current'
        ORDER BY se.status = 'Active' DESC, se.session_name DESC LIMIT 1", 's', $uid)['session_id'] ?? 0) ?: fee_active_session_id();
}
/** The months of a session: 'YYYY-MM' => 'April 2026'. "2026" runs January to December, "2025-26" April to March. */
function fee_session_months(int $session_id): array {
    $name = exam_session_name($session_id);
    if (preg_match('/^(\d{4})\s*[-\/]\s*\d{2,4}$/', $name, $m)) $start = "$m[1]-04-01";
    elseif (preg_match('/(\d{4})/', $name, $m)) $start = "$m[1]-01-01";
    else return [];
    $d = new DateTime($start);
    $out = [];
    for ($i = 0; $i < 12; $i++, $d->modify('+1 month')) $out[$d->format('Y-m')] = $d->format('F Y');
    return $out;
}

/** Fees in their order: id => row. */
function fee_heads(bool $active_only = false): array {
    $out = [];
    foreach (db_get_all('SELECT * FROM fee_types' . ($active_only ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order, type_name') as $r) $out[(int)$r['id']] = $r;
    return $out;
}
/** Has a head class amounts or bill lines? Then how it is charged stays as it is. */
function fee_head_used(int $id): bool {
    return (bool)db_get_row('SELECT 1 FROM fee_structures WHERE fee_type_id = ? UNION ALL SELECT 1 FROM fee_invoice_items WHERE fee_type_id = ? LIMIT 1', 'ii', $id, $id);
}
/** Is a head on a bill? Then it can only be switched off, never deleted. */
function fee_head_billed(int $id): bool {
    return (bool)db_get_row('SELECT 1 FROM fee_invoice_items WHERE fee_type_id = ? LIMIT 1', 'i', $id);
}

/** The amounts of a session: class id => head id => ['amount' => paise, 'due_date' => ?string]. */
function fee_class_amounts(int $session_id, array $class_ids = []): array {
    $sql = 'SELECT class_id, fee_type_id, amount, due_date FROM fee_structures WHERE session_id = ? AND amount > 0';
    $types = 'i'; $params = [$session_id];
    if ($class_ids) {
        $sql .= ' AND class_id IN (' . implode(',', array_fill(0, count($class_ids), '?')) . ')';
        $types .= str_repeat('i', count($class_ids));
        array_push($params, ...array_values($class_ids));
    }
    $out = [];
    foreach (db_get_all($sql, $types, ...$params) as $r) $out[(int)$r['class_id']][(int)$r['fee_type_id']] = ['amount' => fee_paise($r['amount']), 'due_date' => $r['due_date']];
    return $out;
}

/**
 * Students a class bill can go to — Current and Active in the session (one section or all; $only: just these UIDs),
 * in class, section and roll order: uid => row with continuing = 1 when they studied here in an earlier session.
 */
function fee_class_students(int $session_id, array $class_ids, int $section_id = 0, array $only = []): array {
    $class_ids = array_values(array_filter(array_map('intval', $class_ids)));
    if (!$class_ids) return [];
    $sql = "SELECT s.id AS uid, s.student_name, s.gender, s.photo, s.mobile, g.father_name, g.father_mobile, g.guardian_contact,
                   h.class_id, c.class_name, h.section_id, sec.section_name, h.roll_no,
                   EXISTS (SELECT 1 FROM student_academic_history p JOIN academic_sessions ps ON ps.id = p.session_id
                           WHERE p.student_id = s.id AND ps.session_name < se.session_name) AS continuing
            FROM student_academic_history h
            JOIN academic_sessions se ON se.id = h.session_id
            JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN classes c ON c.id = h.class_id
            LEFT JOIN sections sec ON sec.id = h.section_id
            WHERE h.session_id = ? AND h.academic_status = 'Current' AND h.class_id IN (" . implode(',', array_fill(0, count($class_ids), '?')) . ')';
    $types = 'i' . str_repeat('i', count($class_ids));
    $params = array_merge([$session_id], $class_ids);
    if ($section_id) { $sql .= ' AND h.section_id = ?'; $types .= 'i'; $params[] = $section_id; }
    if ($only) {
        $only = array_values(array_map('strval', $only));
        $sql .= ' AND s.id IN (' . implode(',', array_fill(0, count($only), '?')) . ')';
        $types .= str_repeat('s', count($only));
        array_push($params, ...$only);
    }
    $sql .= ' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name';
    $out = [];
    foreach (db_get_all($sql, $types, ...$params) as $r) {
        $r['phone'] = trim((string)$r['mobile']) ?: (trim((string)$r['father_mobile']) ?: trim((string)$r['guardian_contact']));
        $r['continuing'] = (int)$r['continuing'];
        $out[$r['uid']] = $r;
    }
    return $out;
}

/** The active discounts of a session: uid => row. */
function fee_discounts(int $session_id, array $uids): array {
    $uids = array_values(array_map('strval', $uids));
    if (!$uids) return [];
    $out = [];
    foreach (db_get_all('SELECT student_id, discount_type, discount_value, discount_reason FROM student_discounts WHERE session_id = ? AND is_active = 1 AND student_id IN (' . implode(',', array_fill(0, count($uids), '?')) . ')',
        'i' . str_repeat('s', count($uids)), $session_id, ...$uids) as $r) $out[$r['student_id']] = $r;
    return $out;
}

/** Fees charged by class once a session, in their order — switched on only, unless $all. */
function fee_session_heads(bool $all = false): array {
    return array_filter(fee_heads(!$all), fn($h) => $h['charge'] === 'session');
}
/** Fees of any amount that are switched on — fines and the like, written in when collected. */
function fee_charge_heads(): array {
    return array_filter(fee_heads(true), fn($h) => $h['charge'] === 'any');
}

/** Students sent up for this session's board exams, among these classes: uid => true. */
function fee_sentup_uids(int $session_id, array $class_ids): array {
    require_once __DIR__ . '/board_helper.php';
    $out = [];
    foreach (array_keys(BOARD_EXAMS) as $board) {
        $ec = board_exam_class($board);
        if (!in_array($ec, $class_ids, true)) continue;
        foreach (array_keys(board_exam_rows($board, board_exam_year_default($board, $session_id, $ec), $ec)) as $uid) $out[(string)$uid] = true;
    }
    return $out;
}

/**
 * Where each student stands with each fee of the session: uid => fee id => cell. 'state' is paid, part or due (on a
 * bill), todo (not billed yet), zero (nothing to pay after the discount) or na (not this student's fee); 'owe' is what is
 * still to pay. A todo cell also has 'gross', 'off' (the discount its bill gets) and 'due'; a billed one has 'bill' (id,
 * title, total, paid, last date, and how many fees it holds). A discount comes off the fees that take one: a percentage off each, or
 * a fixed amount once a session — less what earlier bills took — over the fees in their order.
 */
function fee_standing(int $session_id, array $students, array $heads): array {
    if (!$students || !$heads) return [];
    $uids = array_map('strval', array_keys($students));
    $class_ids = array_values(array_unique(array_map(fn($s) => (int)$s['class_id'], $students)));
    $amounts = fee_class_amounts($session_id, $class_ids);
    $discounts = fee_discounts($session_id, $uids);
    $billed = []; $taken = []; $holds = [];
    foreach (db_get_all("SELECT i.id, i.student_id, i.title, i.total, i.paid_amount, i.discount_amount, i.due_date, it.fee_type_id FROM fee_invoices i JOIN fee_invoice_items it ON it.invoice_id = i.id
        WHERE i.session_id = ? AND i.status <> 'cancelled' AND i.student_id IN (" . implode(',', array_fill(0, count($uids), '?')) . ') ORDER BY i.id, it.id',
        'i' . str_repeat('s', count($uids)), $session_id, ...$uids) as $b) {
        $billed[$b['student_id']][(int)$b['fee_type_id']] ??= $b;
        $taken[$b['student_id']][(int)$b['id']] = fee_paise($b['discount_amount']);
        $holds[(int)$b['id']][(int)$b['fee_type_id']] = true;
    }
    $sentup = array_filter($heads, fn($h) => $h['who_pays'] === 'sentup') ? fee_sentup_uids($session_id, $class_ids) : [];
    $out = [];
    foreach ($students as $uid => $st) {
        $uid = (string)$uid;
        $d = $discounts[$uid] ?? null;
        $budget = $d && $d['discount_type'] === 'fixed' ? max(0, fee_paise($d['discount_value']) - array_sum($taken[$uid] ?? [])) : 0;
        foreach ($heads as $hid => $h) {
            if ($b = $billed[$uid][$hid] ?? null) {
                $total = fee_paise($b['total']); $paid = fee_paise($b['paid_amount']);
                $out[$uid][$hid] = ['state' => $paid >= $total ? 'paid' : ($paid > 0 ? 'part' : 'due'), 'owe' => max(0, $total - $paid),
                    'bill' => ['id' => (int)$b['id'], 'title' => $b['title'], 'total' => $total, 'paid' => $paid, 'fees' => count($holds[(int)$b['id']]), 'due' => $b['due_date']]];
                continue;
            }
            $a = $amounts[(int)$st['class_id']][$hid] ?? null;
            $mine = $a && match ($h['who_pays']) { 'new' => !$st['continuing'], 'continuing' => (bool)$st['continuing'], 'sentup' => isset($sentup[$uid]), default => true };
            if (!$mine) { $out[$uid][$hid] = ['state' => 'na', 'owe' => 0]; continue; }
            $off = 0;
            if ($d && $h['discountable']) {
                if ($d['discount_type'] === 'percentage') $off = (int)round($a['amount'] * min(100, max(0, (float)$d['discount_value'])) / 100);
                else { $off = min($budget, $a['amount']); $budget -= $off; }
            }
            $out[$uid][$hid] = ['state' => $a['amount'] > $off ? 'todo' : 'zero', 'owe' => $a['amount'] - $off, 'gross' => $a['amount'], 'off' => $off, 'due' => $a['due_date']];
        }
    }
    return $out;
}

/**
 * What students owe now: their open bills of every session, and the fees of this session not billed yet that everyone
 * in their class pays — a fee for some students only is owed once it is billed. uid => paise.
 */
function fee_owing(int $session_id, array $uids): array {
    $uids = array_values(array_unique(array_map('strval', $uids)));
    if (!$uids) return [];
    $in = implode(',', array_fill(0, count($uids), '?'));
    $out = array_fill_keys($uids, 0);
    foreach (db_get_all("SELECT student_id, SUM(total - paid_amount) AS o FROM fee_invoices WHERE status IN ('pending', 'partial') AND student_id IN ($in) GROUP BY student_id",
        str_repeat('s', count($uids)), ...$uids) as $r) $out[$r['student_id']] += fee_paise($r['o']);
    $classes = array_column(db_get_all("SELECT DISTINCT class_id FROM student_academic_history WHERE session_id = ? AND academic_status = 'Current' AND student_id IN ($in)",
        'i' . str_repeat('s', count($uids)), $session_id, ...$uids), 'class_id');
    $heads = array_filter(fee_session_heads(), fn($h) => $h['who_pays'] !== 'some');
    foreach (fee_standing($session_id, fee_class_students($session_id, $classes, 0, $uids), $heads) as $uid => $cells) {
        foreach ($cells as $c) if ($c['state'] === 'todo') $out[$uid] += $c['owe'];
    }
    return $out;
}
/** What the session still waits for: its open bills, and the fees everyone in a class pays that are not billed yet. Paise. */
function fee_session_owing(int $session_id): int {
    $owe = fee_paise(db_get_row("SELECT COALESCE(SUM(total - paid_amount), 0) AS t FROM fee_invoices WHERE session_id = ? AND status IN ('pending', 'partial')", 'i', $session_id)['t'] ?? 0);
    $heads = array_filter(fee_session_heads(), fn($h) => $h['who_pays'] !== 'some');
    foreach (fee_standing($session_id, fee_class_students($session_id, array_keys(class_rows())), $heads) as $cells) {
        foreach ($cells as $c) if ($c['state'] === 'todo') $owe += $c['owe'];
    }
    return $owe;
}

/** Write one bill and its lines (inside the caller's transaction). */
function fee_insert_bill(string $uid, int $session_id, ?int $class_id, ?int $section_id, string $category, string $title, string $period, ?string $key, array $calc, ?array $discount, int $admin_id): int {
    $id = (int)db_insert('fee_invoices', [
        'student_id' => $uid, 'session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $section_id, 'category' => $category,
        'title' => $title, 'period' => $period !== '' ? $period : null, 'demand_key' => $key, 'invoice_date' => date('Y-m-d'), 'due_date' => $calc['due_date'],
        'subtotal' => fee_rupees($calc['subtotal']), 'discount_type' => $discount['discount_type'] ?? null, 'discount_value' => $discount['discount_value'] ?? '0',
        'discount_reason' => $discount['discount_reason'] ?? null, 'discount_amount' => fee_rupees($calc['discount']), 'total' => fee_rupees($calc['total']),
        'paid_amount' => '0.00', 'status' => $calc['total'] > 0 ? 'pending' : 'paid', 'created_by' => $admin_id ?: null]);
    if (!$id) throw new RuntimeException('The bill could not be saved.');
    foreach ($calc['lines'] as $l) {
        if (!db_insert('fee_invoice_items', ['invoice_id' => $id, 'fee_type_id' => $l['head'], 'description' => $l['text'],
                'amount' => fee_rupees($l['amount']), 'discount' => fee_rupees($l['discount']), 'net' => fee_rupees($l['net'])])) {
            throw new RuntimeException('A line of the bill could not be saved.');
        }
    }
    return $id;
}

/** A student for the counter (not Deleted, unless $any for an old receipt), with 'place': their class row of the session, else their latest. */
function fee_student(string $uid, int $session_id, bool $any = false): ?array {
    $s = db_get_row("SELECT s.*, g.father_name, g.father_mobile, g.guardian_contact FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        WHERE s.id = ?" . ($any ? '' : " AND s.student_status <> 'Deleted'"), 's', $uid);
    if (!$s) return null;
    $s['place'] = db_get_row('SELECT h.session_id, h.class_id, h.section_id, h.roll_no, h.academic_status, c.class_name, sec.section_name, se.session_name
        FROM student_academic_history h LEFT JOIN classes c ON c.id = h.class_id LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN academic_sessions se ON se.id = h.session_id
        WHERE h.student_id = ? ORDER BY h.session_id = ? DESC, se.session_name DESC LIMIT 1', 'si', $uid, $session_id) ?: null;
    $s['phone'] = trim((string)$s['mobile']) ?: (trim((string)$s['father_mobile']) ?: trim((string)$s['guardian_contact']));
    return $s;
}

/** How the money was paid, its reference and its date — the same checks for every payment. Returns the reference, trimmed. */
function fee_payment_check(string $method, string $reference, string $date): string {
    if (!isset(FEE_METHODS[$method])) throw new RuntimeException('Choose how the money was paid.');
    $reference = mb_substr(trim($reference), 0, 100);
    if ($method !== 'cash' && $reference === '') throw new RuntimeException('Give the ' . FEE_METHODS[$method] . ' reference (transaction or cheque number).');
    if (!fee_valid_date($date) || $date > date('Y-m-d')) throw new RuntimeException('Give a payment date that is not in the future.');
    return $reference;
}

/**
 * One receipt, inside the caller's transaction: $pay = bill id => paise. The student's bills are locked and each amount
 * is checked against its balance, the receipt gets the next number of its book in the session (under a lock) and the
 * receipt, its lines and the bills' paid amounts are written. Returns [receipt id, receipt number, paise].
 */
function fee_receipt_write(string $uid, int $session_id, array $pay, string $method, string $reference, string $date, string $remarks, int $admin_id, string $book, bool $slip): array {
    $session = exam_session_name($session_id);
    if ($session === '') throw new RuntimeException('Choose the session.');
    ksort($pay);
    $bills = [];
    foreach (db_get_all('SELECT id, title, total, paid_amount, status FROM fee_invoices WHERE student_id = ? AND id IN (' . implode(',', array_fill(0, count($pay), '?')) . ') ORDER BY id FOR UPDATE',
        's' . str_repeat('i', count($pay)), $uid, ...array_keys($pay)) as $b) $bills[(int)$b['id']] = $b;
    foreach ($pay as $id => $p) {
        $b = $bills[$id] ?? null;
        if (!$b || $b['status'] === 'cancelled') throw new RuntimeException('One of the bills is not this student\'s or was cancelled — open the counter again.');
        $left = fee_paise($b['total']) - fee_paise($b['paid_amount']);
        if ($p > $left) throw new RuntimeException(fee_money_p($p) . ' is more than the balance of ' . $b['title'] . ' (' . fee_money_p($left) . ').');
    }
    $total = array_sum($pay);
    $seq = (int)db_get_row('SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM fee_receipts WHERE session_id = ? AND book = ? FOR UPDATE', 'is', $session_id, $book)['n'];
    $prefix = fee_book_prefix($book);
    $no = ($prefix !== '' ? "$prefix/" : '') . "$session/" . sprintf('%05d', $seq);
    $rid = (int)db_insert('fee_receipts', ['session_id' => $session_id, 'book' => $book, 'seq' => $seq, 'receipt_no' => $no, 'student_id' => $uid, 'receipt_date' => $date,
        'amount' => fee_rupees($total), 'method' => $method, 'reference_no' => $reference !== '' ? $reference : null,
        'remarks' => mb_substr(trim($remarks), 0, 255) ?: null, 'slip_given' => $slip ? 1 : 0, 'received_by' => $admin_id ?: null]);
    if (!$rid) throw new RuntimeException('The receipt could not be saved.');
    foreach ($pay as $id => $p) {
        if (!db_insert('fee_transactions', ['receipt_id' => $rid, 'invoice_id' => $id, 'student_id' => $uid, 'amount' => fee_rupees($p)])) throw new RuntimeException('A line of the receipt could not be saved.');
        $paid = fee_paise($bills[$id]['paid_amount']) + $p;
        db_execute('UPDATE fee_invoices SET paid_amount = ?, status = ? WHERE id = ?', 'ssi', fee_rupees($paid), $paid >= fee_paise($bills[$id]['total']) ? 'paid' : 'partial', $id);
    }
    acc_post_fee_receipt($rid);
    return [$rid, $no, $total];
}

/** The valid receipts that paid each bill: bill id => "R/2026/00001, C/2026/00004". */
function fee_bill_receipt_nos(array $bill_ids): array {
    $bill_ids = array_values(array_unique(array_map('intval', $bill_ids)));
    if (!$bill_ids) return [];
    return array_column(db_get_all("SELECT t.invoice_id, GROUP_CONCAT(r.receipt_no ORDER BY r.id SEPARATOR ', ') AS nos FROM fee_transactions t JOIN fee_receipts r ON r.id = t.receipt_id
        WHERE r.status = 'valid' AND t.invoice_id IN (" . implode(',', array_fill(0, count($bill_ids), '?')) . ') GROUP BY t.invoice_id', str_repeat('i', count($bill_ids)), ...$bill_ids), 'nos', 'invoice_id');
}

/** The book a bill's receipt goes in: the main book when one of its fees gives a slip, else the cash book. */
function fee_bill_book(int $bill_id, array $heads): string {
    $items = db_get_all('SELECT fee_type_id FROM fee_invoice_items WHERE invoice_id = ?', 'i', $bill_id);
    foreach ($items as $it) if (!empty($heads[(int)$it['fee_type_id']]['slip'])) return 'main';
    return $items ? 'cash' : 'main';
}

/**
 * Take money from one or more students at once — all or nothing. $items: [uid, kind, id, shown, pay, note], kind being
 * 'fee' (a fee of the session, billed first when it is not), 'bill' (an open bill) or 'charge' (an any-amount fee written
 * in now, with a note); shown is what the page showed owing, and it must still be so. Every student is locked first, in
 * UID order, then the receipts are numbered: one per student and book — fees with a slip in the main book, the others in
 * the cash book. $print = book => whether its slips are printed now. Returns the receipts: [id, no, paise, 'book', 'uid'].
 */
function fee_collect_items(int $session_id, array $items, string $method, string $reference, string $date, string $remarks, array $print, int $admin_id): array {
    $reference = fee_payment_check($method, $reference, $date);
    if (!$items) throw new RuntimeException('Tick at least one fee to collect.');
    $session = exam_session_name($session_id);
    if ($session === '') throw new RuntimeException('Choose the session.');
    $heads = fee_heads();
    $session_heads = fee_session_heads();
    $by_uid = [];
    foreach ($items as [$uid, $kind, $id, $shown, $amount, $note]) $by_uid[(string)$uid][] = [(string)$kind, (int)$id, (int)$shown, (int)$amount, (string)$note];
    ksort($by_uid, SORT_STRING);
    $todo = []; $done = [];
    db_begin_transaction();
    try {
        foreach ($by_uid as $uid => $list) {
            $uid = (string)$uid;
            db_get_all('SELECT id FROM fee_invoices WHERE student_id = ? FOR UPDATE', 's', $uid);
            $st = fee_student($uid, $session_id);
            if (!$st) throw new RuntimeException("$uid is not a student here — nothing was saved.");
            $who = $st['student_name'];
            $place = $standing = $discount = null;
            $pay = ['main' => [], 'cash' => []];
            $seen = [];
            foreach ($list as [$kind, $id, $shown, $amount, $note]) {
                if ($amount <= 0) throw new RuntimeException("$who: give an amount to take — nothing was saved.");
                if ($kind !== 'charge' && isset($seen["$kind:$id"])) throw new RuntimeException("$who: the same fee is ticked twice — tick it once.");
                $seen["$kind:$id"] = true;
                if ($kind === 'fee') {
                    $h = $session_heads[$id] ?? null;
                    if (!$h) throw new RuntimeException("$who: a ticked fee is switched off now — nothing was saved. Look again.");
                    if ($standing === null) {
                        $place = fee_class_students($session_id, [(int)($st['place']['class_id'] ?? 0)], 0, [$uid])[$uid] ?? null;
                        if (!$place) throw new RuntimeException("$who is not a current student of $session — nothing was saved.");
                        $standing = fee_standing($session_id, [$uid => $place], $session_heads)[$uid];
                        $discount = fee_discounts($session_id, [$uid])[$uid] ?? null;
                    }
                    $c = $standing[$id];
                    if (!in_array($c['state'], ['todo', 'due', 'part'], true)) throw new RuntimeException("$who: {$h['type_name']} has nothing to pay now — nothing was saved. Look again.");
                    if ($c['owe'] !== $shown) throw new RuntimeException("$who now owes " . fee_money_p($c['owe']) . " for {$h['type_name']}, not " . fee_money_p($shown) . ' — nothing was saved. Look again.');
                    if ($c['state'] === 'todo') {
                        $bill = fee_insert_bill($uid, $session_id, (int)$place['class_id'] ?: null, (int)$place['section_id'] ?: null, $h['category'], "{$h['type_name']} $session", '', "h:$id",
                            ['lines' => [['head' => $id, 'text' => $h['type_name'], 'amount' => $c['gross'], 'discount' => $c['off'], 'net' => $c['owe']]],
                             'subtotal' => $c['gross'], 'discount' => $c['off'], 'total' => $c['owe'], 'due_date' => $c['due']], $c['off'] ? $discount : null, $admin_id);
                        $book = $h['slip'] ? 'main' : 'cash';
                    } else {
                        $bill = $c['bill']['id'];
                        $book = fee_bill_book($bill, $heads);
                    }
                    $owe = $c['owe'];
                } elseif ($kind === 'bill') {
                    $b = db_get_row('SELECT student_id, status, total, paid_amount FROM fee_invoices WHERE id = ?', 'i', $id);
                    if (!$b || $b['student_id'] !== $uid || $b['status'] === 'cancelled') throw new RuntimeException("$who: a bill is cancelled or gone — nothing was saved. Look again.");
                    $owe = fee_paise($b['total']) - fee_paise($b['paid_amount']);
                    if ($owe !== $shown) throw new RuntimeException("$who now owes " . fee_money_p($owe) . ' on a bill, not ' . fee_money_p($shown) . ' — nothing was saved. Look again.');
                    $bill = $id;
                    $book = fee_bill_book($bill, $heads);
                } elseif ($kind === 'charge') {
                    $h = $heads[$id] ?? null;
                    if (!$h || $h['charge'] !== 'any' || !$h['is_active']) throw new RuntimeException("$who: choose a fine or other fee that is switched on.");
                    if ($amount > 10000000) throw new RuntimeException("$who: a charge can be up to ₹1,00,000.");
                    $title = $h['type_name'] . (($note = mb_substr(trim($note), 0, 80)) !== '' ? " — $note" : '');
                    $bill = fee_insert_bill($uid, $session_id, (int)($st['place']['class_id'] ?? 0) ?: null, (int)($st['place']['section_id'] ?? 0) ?: null, $h['category'], $title, '', null,
                        ['lines' => [['head' => $id, 'text' => $title, 'amount' => $amount, 'discount' => 0, 'net' => $amount]], 'subtotal' => $amount, 'discount' => 0, 'total' => $amount, 'due_date' => $date], null, $admin_id);
                    $book = $h['slip'] ? 'main' : 'cash';
                    $owe = $amount;
                } else throw new RuntimeException('The ticks did not arrive — try again.');
                if ($amount > $owe) throw new RuntimeException("$who: " . fee_money_p($amount) . ' is more than what is owed (' . fee_money_p($owe) . ') — nothing was saved.');
                if (isset($pay['main'][$bill]) || isset($pay['cash'][$bill])) throw new RuntimeException("$who: two ticks pay the same bill — tick it once.");
                $pay[$book][$bill] = $amount;
            }
            $todo[$uid] = $pay;
        }
        foreach ($todo as $uid => $pay) foreach ($pay as $book => $p) {
            if ($p) $done[] = fee_receipt_write((string)$uid, $session_id, $p, $method, $reference, $date, $remarks, $admin_id, $book, !empty($print[$book])) + ['book' => $book, 'uid' => (string)$uid];
        }
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        if (!($e instanceof mysqli_sql_exception) && $e instanceof RuntimeException) throw $e;
        throw new RuntimeException((int)$e->getCode() === 1062 ? 'Someone collected for these students a moment ago — nothing was saved. Look again.' : 'The payment could not be saved: ' . $e->getMessage());
    }
    foreach ($done as $d) fee_log($admin_id, 'FEE_COLLECTED', 'fee_receipts', $d[0], null, ['receipt' => $d[1], 'student' => $d['uid'], 'amount' => fee_rupees($d[2]), 'method' => $method, 'book' => $d['book']]);
    return $done;
}

/** Cancel a receipt: its money comes off the bills it paid; the receipt stays, marked cancelled. */
function fee_cancel_receipt(int $id, string $reason, int $admin_id): string {
    $reason = mb_substr(trim($reason), 0, 255);
    if ($reason === '') throw new RuntimeException('Give the reason for cancelling.');
    db_begin_transaction();
    try {
        $r = db_get_row('SELECT id, receipt_no, status, student_id, amount FROM fee_receipts WHERE id = ? FOR UPDATE', 'i', $id);
        if (!$r) throw new RuntimeException('Receipt not found.');
        if ($r['status'] === 'cancelled') throw new RuntimeException("Receipt {$r['receipt_no']} is already cancelled.");
        foreach (db_get_all('SELECT invoice_id, amount FROM fee_transactions WHERE receipt_id = ? ORDER BY invoice_id', 'i', $id) as $l) {
            $b = db_get_row('SELECT total, paid_amount, status FROM fee_invoices WHERE id = ? FOR UPDATE', 'i', (int)$l['invoice_id']);
            $paid = max(0, fee_paise($b['paid_amount']) - fee_paise($l['amount']));
            $status = $paid >= fee_paise($b['total']) && fee_paise($b['total']) > 0 ? 'paid' : ($paid > 0 ? 'partial' : 'pending');
            db_execute('UPDATE fee_invoices SET paid_amount = ?, status = ? WHERE id = ?', 'ssi', fee_rupees($paid), $b['status'] === 'cancelled' ? 'cancelled' : $status, (int)$l['invoice_id']);
        }
        acc_unpost_fee_receipt($id, $reason, $admin_id);
        db_execute("UPDATE fee_receipts SET status = 'cancelled', cancelled_at = NOW(), cancelled_by = ?, cancel_reason = ? WHERE id = ?", 'isi', $admin_id ?: null, $reason, $id);
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        if (!($e instanceof mysqli_sql_exception) && $e instanceof RuntimeException) throw $e;
        throw new RuntimeException('The receipt could not be cancelled: ' . $e->getMessage());
    }
    fee_log($admin_id, 'FEE_RECEIPT_CANCELLED', 'fee_receipts', $id, ['status' => 'valid'], ['receipt' => $r['receipt_no'], 'student' => $r['student_id'], 'amount' => $r['amount'], 'reason' => $reason]);
    return $r['receipt_no'];
}

/** Cancel a bill that has no money on it; its demand can then be billed again. */
function fee_cancel_bill(int $id, string $reason, int $admin_id): string {
    $reason = mb_substr(trim($reason), 0, 255);
    if ($reason === '') throw new RuntimeException('Give the reason for cancelling.');
    db_begin_transaction();
    try {
        $b = db_get_row('SELECT id, title, student_id, status, paid_amount, total FROM fee_invoices WHERE id = ? FOR UPDATE', 'i', $id);
        if (!$b) throw new RuntimeException('Bill not found.');
        if ($b['status'] === 'cancelled') throw new RuntimeException('This bill is already cancelled.');
        if (fee_paise($b['paid_amount']) > 0) throw new RuntimeException('This bill has money on it — cancel its receipt first.');
        db_execute("UPDATE fee_invoices SET status = 'cancelled', demand_key = NULL, cancelled_at = NOW(), cancelled_by = ?, cancel_reason = ? WHERE id = ?", 'isi', $admin_id ?: null, $reason, $id);
        db_commit();
    } catch (Throwable $e) {
        db_rollback();
        if (!($e instanceof mysqli_sql_exception) && $e instanceof RuntimeException) throw $e;
        throw new RuntimeException('The bill could not be cancelled: ' . $e->getMessage());
    }
    fee_log($admin_id, 'FEE_BILL_CANCELLED', 'fee_invoices', $id, null, ['student' => $b['student_id'], 'bill' => $b['title'], 'total' => $b['total'], 'reason' => $reason]);
    return $b['title'];
}

/** cancelled, paid, overdue (past its due date with money owing), partial or pending. */
function fee_bill_state(array $b): string {
    if ($b['status'] === 'cancelled') return 'cancelled';
    $owed = fee_paise($b['total']) - fee_paise($b['paid_amount']);
    if ($owed <= 0) return 'paid';
    if (!empty($b['due_date']) && $b['due_date'] < date('Y-m-d')) return 'overdue';
    return fee_paise($b['paid_amount']) > 0 ? 'partial' : 'pending';
}
function fee_state_chip(string $state): string {
    [$cls, $label] = ['paid' => ['ok', 'Paid'], 'partial' => ['warn', 'Part paid'], 'pending' => ['off', 'Due'], 'overdue' => ['bad', 'Overdue'], 'cancelled' => ['off', 'Cancelled']][$state] ?? ['off', $state];
    return '<span class="chip ' . $cls . '">' . h($label) . '</span>';
}

/** A student's bills (one session, or all), newest session first, each with its lines. */
function fee_student_bills(string $uid, int $session_id = 0, bool $open_only = false): array {
    $sql = 'SELECT i.*, se.session_name FROM fee_invoices i JOIN academic_sessions se ON se.id = i.session_id WHERE i.student_id = ?';
    $types = 's'; $params = [$uid];
    if ($session_id) { $sql .= ' AND i.session_id = ?'; $types .= 'i'; $params[] = $session_id; }
    if ($open_only) $sql .= " AND i.status IN ('pending','partial')";
    $bills = [];
    foreach (db_get_all($sql . ' ORDER BY se.session_name DESC, i.id', $types, ...$params) as $b) $bills[(int)$b['id']] = $b + ['items' => []];
    if ($bills) {
        foreach (db_get_all('SELECT * FROM fee_invoice_items WHERE invoice_id IN (' . implode(',', array_fill(0, count($bills), '?')) . ') ORDER BY id',
            str_repeat('i', count($bills)), ...array_keys($bills)) as $it) $bills[(int)$it['invoice_id']]['items'][] = $it;
    }
    return $bills;
}
/** A student's receipts, newest first. */
function fee_student_receipts(string $uid): array {
    return db_get_all('SELECT r.*, a.full_name AS received_name FROM fee_receipts r LEFT JOIN admins a ON a.id = r.received_by WHERE r.student_id = ? ORDER BY r.receipt_date DESC, r.id DESC', 's', $uid);
}

/** A receipt with its student and lines; each line: the bill, what this receipt paid, and the balance it left. */
function fee_receipt(int $id): ?array {
    $r = db_get_row('SELECT r.*, se.session_name, a.full_name AS received_name, ca.full_name AS cancelled_name FROM fee_receipts r
        JOIN academic_sessions se ON se.id = r.session_id LEFT JOIN admins a ON a.id = r.received_by LEFT JOIN admins ca ON ca.id = r.cancelled_by WHERE r.id = ?', 'i', $id);
    if (!$r) return null;
    $r['student'] = fee_student($r['student_id'], (int)$r['session_id'], true);
    $r['lines'] = db_get_all("SELECT t.amount, i.id AS invoice_id, i.title, i.total, i.category,
            (SELECT COALESCE(SUM(t2.amount), 0) FROM fee_transactions t2 JOIN fee_receipts r2 ON r2.id = t2.receipt_id
              WHERE t2.invoice_id = i.id AND r2.status = 'valid' AND r2.id <= t.receipt_id) AS paid_upto
        FROM fee_transactions t JOIN fee_invoices i ON i.id = t.invoice_id WHERE t.receipt_id = ? ORDER BY t.id", 'i', $id);
    $ids = array_map(fn($l) => (int)$l['invoice_id'], $r['lines']);
    $items = [];
    if ($ids) foreach (db_get_all('SELECT invoice_id, description, amount, discount, net FROM fee_invoice_items WHERE invoice_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id',
        str_repeat('i', count($ids)), ...$ids) as $it) $items[(int)$it['invoice_id']][] = $it;
    foreach ($r['lines'] as &$l) $l['items'] = $items[(int)$l['invoice_id']] ?? [];
    unset($l);
    return $r;
}

require_once __DIR__ . '/acc_helper.php';

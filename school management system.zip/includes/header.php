<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

// header.php is included from admin/ folder, so db is already connected via ../includes/db.php
// Only fetch school info if $conn is available and $school not already set
if(isset($conn) && !isset($school)) {
    $school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings LIMIT 1"));
}

// Determine correct uploads path based on where this file is included from
$uploads_path = (strpos($_SERVER['SCRIPT_FILENAME'], '/admin/') !== false) ? '../uploads/' : 'uploads/';
?>

<div class="card shadow-sm mb-3">
    <div class="card-body">
        <div class="row align-items-center">

            <div class="col-md-2 text-center">
                <?php if(!empty($school['logo'])){ ?>
                    <img src="<?php echo $uploads_path . htmlspecialchars($school['logo'], ENT_QUOTES, 'UTF-8'); ?>"
                         style="height:80px;width:auto;" alt="School Logo">
                <?php } ?>
            </div>

            <div class="col-md-10 text-center">
                <h2 class="mb-1">
                    <?php echo htmlspecialchars($school['school_name'] ?? 'School Name', ENT_QUOTES, 'UTF-8'); ?>
                </h2>

                <p class="mb-1">
                    <?php echo htmlspecialchars($school['school_address'] ?? '', ENT_QUOTES, 'UTF-8'); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?>
                </p>

                <p class="mb-0">
                    <?php if(!empty($school['phone'])): ?>
                        Phone: <?php echo htmlspecialchars($school['phone'], ENT_QUOTES, 'UTF-8'); ?>
                    <?php endif; ?>
                    <?php if(!empty($school['phone']) && !empty($school['email'])): ?> | <?php endif; ?>
                    <?php if(!empty($school['email'])): ?>
                        Email: <?php echo htmlspecialchars($school['email'], ENT_QUOTES, 'UTF-8'); ?>
                    <?php endif; ?>
                </p>
            </div>

        </div>
    </div>
</div>
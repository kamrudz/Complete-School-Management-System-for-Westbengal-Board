<?php
/**
 * The one page behind the three HPRC observation sheets — Learning, Behaviour, Personality. Each entry page
 * is only its includes and hprc_grid_page('<kind>', '<its file>').
 *
 * Filter row (Session · Formative Phase for a per-phase sheet · Class · Section), the card's items and
 * grades as a legend, one grid of the class's current students, and three helpers that only fill the page:
 * Bulk Fill (one value into a column, blank cells or all), Magic Fill (random values into blank cells, as
 * the old pages had), Clear. Nothing is written until Save, which goes through hprc_save_grid().
 */
require_once __DIR__ . '/hprc_helper.php';
require_once __DIR__ . '/exam_ui.php';

/** Title, icon and the card's heading of each sheet. */
const HPRC_GRID_PAGES = [
    'learning'    => ['Learning', 'fa-brain', 'A. Identified Condition — Learning Perspective of Cognitive Domain (শিখনের বৌদ্ধিক দক্ষতার ক্ষেত্রসমূহ). Seven observations for each Formative Phase, written in.'],
    'behaviour'   => ['Behaviour', 'fa-heart', 'B. Behavioural Cognitive Outcomes (আচরণে বৌদ্ধিক ক্ষেত্রের প্রকাশসমূহ). Eleven grades A–D for each Formative Phase.'],
    'personality' => ['Personality', 'fa-star', 'Development of Personality and Life Skills (ব্যক্তিত্ব ও জীবনশৈলীর বিকাশ). Fifteen grades A–D, once a year.'],
];

function hprc_grid_page(string $kind, string $self): void {
    $g = HPRC_GRIDS[$kind];
    [$title, $icon, $about] = HPRC_GRID_PAGES[$kind];
    $admin_id = (int)($_SESSION['admin_id'] ?? 0);
    $sessions = exam_sessions();
    $session_id = (int)($_GET['session_id'] ?? $_POST['session_id'] ?? 0);
    if (!isset($sessions[$session_id])) $session_id = exam_active_session_id();
    $exams = [];   // a per-phase sheet is kept against the Summative that carries the phase
    if ($g['per_phase']) foreach (exam_list($session_id) as $e) if (hprc_part_of_exam($e)) $exams[(int)$e['id']] = $e;
    $exam_id = (int)($_GET['exam_id'] ?? $_POST['exam_id'] ?? 0);
    if (!isset($exams[$exam_id])) $exam_id = (int)array_key_first($exams);
    $exam = $exams[$exam_id] ?? null;
    $classes = exam_classes('pup');
    $class_id = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0); if (!isset($classes[$class_id])) $class_id = 0;
    $sections = $class_id ? exam_sections($session_id, $class_id) : [];
    $section_raw = (string)($_GET['section_id'] ?? $_POST['section_id'] ?? '');
    $all_sections = $section_raw === 'all';
    $section_id = $all_sections ? null : (int)$section_raw; if ($section_id && !isset($sections[$section_id])) $section_id = 0;
    $ready = (!$g['per_phase'] || $exam) && $class_id && ($all_sections || $section_id);
    $qs = "session_id=$session_id" . ($g['per_phase'] ? "&exam_id=$exam_id" : '') . "&class_id=$class_id&section_id=" . ($all_sections ? 'all' : (int)$section_id);

    $errors = []; $posted = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_grid'])) {
        verify_csrf_or_die();
        // the page falls back to the first phase for viewing; a save never does
        if ($g['per_phase'] && !isset($exams[(int)($_POST['exam_id'] ?? 0)])) { $_SESSION['error'] = 'That is not a Formative Phase of this session — nothing was saved.'; header("Location: $self?$qs"); exit; }
        if (!$ready) { $_SESSION['error'] = 'Pick ' . ($g['per_phase'] ? 'phase, ' : '') . 'class and section first.'; header("Location: $self?$qs"); exit; }
        $posted = (array)($_POST['m'] ?? []);
        $r = hprc_save_grid($kind, $session_id, $class_id, $exam_id, $posted, $admin_id);
        if ($r['ok']) {
            $_SESSION['success'] = $title . ' · Class ' . $classes[$class_id]['name'] . ($section_id ? '-' . $sections[$section_id] : '') . ($exam ? ' · ' . HPRC_PHASES[hprc_part_of_exam($exam)] : '') . ': ' . $r['saved'] . ' saved' . ($r['cleared'] ? ', ' . $r['cleared'] . ' cleared' : '') . '.';
            header("Location: $self?$qs"); exit;
        }
        $errors = $r['errors'];
    }

    $listed = $ready ? exam_students($session_id, $class_id, $section_id) : [];
    $rows = $ready ? hprc_grid_rows($kind, $session_id, $class_id, $exam_id) : [];
    $val = fn(string $uid, string $col): string => $posted ? (string)($posted[$uid][$col] ?? '') : (string)($rows[$uid][$col] ?? '');   // posted value wins (failed save)
    $entered = count(array_intersect_key($rows, $listed));
    $exam_opts = []; foreach ($exams as $id => $e) $exam_opts[$id] = HPRC_PHASES[hprc_part_of_exam($e)] . ' · ' . $e['exam_name'];
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo h($title); ?> Entry</title>
<?php exam_styles(); ?>
<style>
    .ex-table td.err { background: #fff2f2; } .ex-table td .em { display: block; color: #b71c1c; font-size: 11px; }
    .sticky { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #dfe7ef; padding: 10px 0 2px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
    .kb { font-size: 11.5px; color: #6b7d90; } .kb kbd { background: #eef1f4; border: 1px solid #d5dde5; border-radius: 4px; padding: 0 5px; font-size: 11px; }
    .legend { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 3px 16px; font-size: 12px; color: #3b5168; margin: 0 0 10px; }
    .legend b { color: var(--ex-dark); display: inline-block; min-width: 20px; } .legend span { color: #7a8a9a; }
    .grades { font-size: 12px; margin: 0 0 10px; } .grades b { padding: 1px 7px; border-radius: 5px; margin-right: 3px; }
    .tools { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; margin-bottom: 10px; font-size: 12.5px; color: #3b5168; }
    .tools select, .tools input[type=text] { height: 30px; border: 1px solid #c9d6e2; border-radius: 6px; padding: 0 6px; } .tools label { display: flex; align-items: center; gap: 4px; margin: 0; }
    .wrap { overflow-x: auto; }
    #grid th, #grid td { border: 1px solid #dde4ec; } #grid th { border-bottom: 2px solid #c9b8dd; vertical-align: bottom; } #grid tr:hover td { background: #f7f2fc; }
    #grid th.it { text-align: center; font-size: 10px; text-transform: none; letter-spacing: 0; line-height: 1.2; min-width: 58px; } #grid th.it b { display: block; font-size: 12px; }
    #grid td.c { text-align: center; padding: 4px; } #grid td.name { min-width: 150px; }
    #grid select.g { width: 52px; height: 30px; border: 1px solid #c9d6e2; border-radius: 6px; text-align: center; font-weight: 700; }
    #grid input.t { width: 150px; height: 30px; border: 1px solid #c9d6e2; border-radius: 6px; padding: 0 6px; font-size: 12.5px; }
    .gA { background: #e6f5ea !important; color: #1b7a3a; } .gB { background: #e7f0fb !important; color: #1f5b8a; } .gC { background: #fff4e0 !important; color: #8a5a00; } .gD { background: #fdecea !important; color: #b71c1c; }
</style>
</head>
<body>
<?php global $conn; include(__DIR__ . "/navbar.php");   // the menu reads the connection as a page-level variable ?>
<div class="page-box">
    <?php exam_banner($title . ' Entry', $about, $icon, ['hprc_formative_entry.php' => '<i class="fas fa-tasks"></i> Formative Entry']); ?>
    <?php exam_tabs($self, HPRC_PAGES, "session_id=$session_id&class_id=$class_id"); ?>
    <?php exam_flash(); ?>
    <?php if ($errors):
        $off_grid = array_diff_key($errors, $listed + ['_' => 1]);   // rows the grid does not show (another class, not on the roll)
        ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> Nothing was saved — fix the rows marked in red<?php if (isset($errors['_'])) echo ': ' . h($errors['_']); ?>.<?php
        foreach ($off_grid as $uid => $m) echo '<br>' . h($uid) . ': ' . h($m); ?></div><?php endif; ?>

    <form method="get" class="pick card" style="margin-bottom:12px">
        <div><label>Session</label><select name="session_id" onchange="this.form.class_id.value='';this.form.submit()"><?php echo exam_options($sessions, $session_id); ?></select></div>
        <?php if ($g['per_phase']): ?><div style="min-width:280px"><label>Formative Phase</label><select name="exam_id" onchange="this.form.submit()"><?php echo exam_options($exam_opts, $exam_id, $exam_opts ? '' : 'No Summative in this session'); ?></select></div><?php endif; ?>
        <div><label>Class</label><select name="class_id" onchange="this.form.section_id.value='';this.form.submit()"><?php echo exam_options(array_map(fn($c) => 'Class ' . $c['name'], $classes), $class_id, 'Select class'); ?></select></div>
        <div><label>Section</label><select name="section_id" onchange="this.form.submit()" <?php echo $class_id ? '' : 'disabled'; ?>><?php echo exam_options(['all' => 'All sections'] + $sections, $all_sections ? 'all' : ($section_id ?: ''), 'Select section'); ?></select></div>
    </form>

    <?php if (!$ready): ?>
        <div class="card"><div class="ex-empty"><i class="fas <?php echo h($icon); ?>"></i><?php echo $g['per_phase'] && !$exams ? 'This session has no 1st, 2nd or 3rd Summative yet — <a href="exams.php?section=pup">add the exams</a> first.' : (!$class_id ? 'Select a class.' : 'Select a section (or all sections).'); ?></div></div>
    <?php else: ?>
    <div class="card">
        <h2><i class="fas <?php echo h($icon); ?>"></i> <?php echo h($title); ?><?php echo $exam ? ' · ' . h(HPRC_PHASES[hprc_part_of_exam($exam)]) : ' · ' . h(exam_session_name($session_id)); ?> · Class <?php echo h($classes[$class_id]['name']); ?><?php echo $section_id ? '-' . h($sections[$section_id]) : ' (all sections)'; ?>
            <small><?php echo $entered; ?> of <?php echo count($listed); ?> students entered</small></h2>
        <div class="legend"><?php $i = 0; foreach ($g['fields'] as $col => $f): $i++; ?><div><b><?php echo $i; ?>.</b> <?php echo h($f[0]); ?> <span><?php echo h($f[1]); ?></span></div><?php endforeach; ?></div>
        <?php if ($g['graded']): ?><div class="grades"><?php foreach (HPRC_GRADES as $gr => $label): ?><b class="g<?php echo $gr; ?>"><?php echo $gr; ?></b><?php echo h($label); ?> &nbsp; <?php endforeach; ?></div><?php endif; ?>
        <?php if (!$listed): ?><div class="ex-empty"><i class="fas fa-user-slash"></i>No students to list.</div>
        <?php else: ?>
        <form method="post" id="mf" autocomplete="off">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="session_id" value="<?php echo $session_id; ?>"><?php if ($g['per_phase']): ?><input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>"><?php endif; ?><input type="hidden" name="class_id" value="<?php echo $class_id; ?>"><input type="hidden" name="section_id" value="<?php echo $all_sections ? 'all' : (int)$section_id; ?>">
            <?php if (!$g['graded']): foreach ($g['fields'] as $col => $f): ?><datalist id="dl-<?php echo h($col); ?>"><?php foreach ($f[2] as $o): ?><option value="<?php echo h($o); ?>"><?php endforeach; ?></datalist><?php endforeach; endif; ?>
            <div class="tools noprint"><b><i class="fas fa-bolt"></i> Bulk Fill</b>
                <?php if ($g['graded']): ?><select id="bv" aria-label="Grade"><?php foreach (HPRC_GRADES as $gr => $label): ?><option value="<?php echo $gr; ?>"><?php echo $gr . ' — ' . h($label); ?></option><?php endforeach; ?></select>
                <?php else: ?><input type="text" id="bv" maxlength="<?php echo HPRC_TEXT_MAX; ?>" placeholder="Text" aria-label="Text"><?php endif; ?>
                <select id="bc" aria-label="Column"><option value="">All columns</option><?php $i = 0; foreach ($g['fields'] as $col => $f): $i++; ?><option value="<?php echo h($col); ?>"><?php echo $i . '. ' . h($f[0]); ?></option><?php endforeach; ?></select>
                <label><input type="checkbox" id="ball"> also overwrite filled cells</label>
                <button type="button" class="btn btn-secondary btn-sm" id="bgo">Apply</button>
                <button type="button" class="btn btn-secondary btn-sm" id="magic" title="Random values into the blank cells — check them before saving"><i class="fas fa-magic"></i> Magic Fill</button>
                <button type="button" class="btn btn-secondary btn-sm" id="clear"><i class="fas fa-eraser"></i> Clear</button>
                <span class="kb" id="bmsg">these fill this page only — Save to keep</span></div>
            <div class="wrap">
            <table class="ex-table" id="grid"><thead><tr><th class="num">#</th><th class="num">Sec</th><th class="num">Roll</th><th>Student</th>
                <?php $i = 0; foreach ($g['fields'] as $col => $f): $i++; ?><th class="it" title="<?php echo h($f[0] . ' — ' . $f[1]); ?>"><b><?php echo $i; ?></b><?php echo h($f[0]); ?></th><?php endforeach; ?></tr></thead><tbody>
            <?php $n = 0; foreach ($listed as $uid => $st): $n++; $e = $errors[$uid] ?? null; ?>
            <tr>
                <td class="num"><?php echo $n; ?></td><td class="num"><?php echo h($st['section']); ?></td><td class="num"><?php echo h($st['roll']); ?></td>
                <td class="name <?php echo $e ? 'err' : ''; ?>"><b><?php echo h($st['name']); ?></b><small style="color:#8a98a8;display:block;font-size:10.5px"><?php echo h($uid); ?></small><?php if ($e): ?><span class="em"><?php echo h($e); ?></span><?php endif; ?></td>
                <?php foreach ($g['fields'] as $col => $f): $v = $val($uid, $col); $name = 'm[' . h($uid) . '][' . h($col) . ']'; ?>
                <td class="c"><?php if ($g['graded']): ?><select class="g" name="<?php echo $name; ?>" data-col="<?php echo h($col); ?>"><option value=""></option><?php foreach (HPRC_GRADES as $gr => $label): ?><option value="<?php echo $gr; ?>" <?php echo strtoupper($v) === $gr ? 'selected' : ''; ?>><?php echo $gr; ?></option><?php endforeach; ?></select>
                    <?php else: ?><input type="text" class="t" name="<?php echo $name; ?>" data-col="<?php echo h($col); ?>" value="<?php echo h($v); ?>" list="dl-<?php echo h($col); ?>" maxlength="<?php echo HPRC_TEXT_MAX; ?>"><?php endif; ?></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?></tbody></table>
            </div>
            <div class="sticky">
                <button type="submit" name="save_grid" value="1" class="btn btn-primary"><i class="fas fa-save"></i> Save <?php echo count($listed); ?> students</button>
                <span class="kb"><?php echo $g['graded'] ? 'Type <kbd>A</kbd>–<kbd>D</kbd> on a cell' : 'Type or pick a suggestion'; ?> · <kbd>Enter</kbd> next student · blank = not assessed · a student left wholly blank is cleared</span>
            </div>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<script>
(function () {
    var f = document.getElementById('mf'); if (!f) return;
    var graded = <?php echo $g['graded'] ? 'true' : 'false'; ?>, suggest = <?php echo json_encode($g['graded'] ? [] : array_map(fn($x) => $x[2], $g['fields'])); ?>;
    var cells = Array.prototype.slice.call(f.querySelectorAll('#grid [data-col]')), rows = Array.prototype.slice.call(f.querySelectorAll('#grid tbody tr'));
    var dirty = false, msg = document.getElementById('bmsg');
    function paint(el) { if (graded) el.className = 'g' + (el.value ? ' g' + el.value : ''); }
    function set(el, v) { el.value = v; paint(el); dirty = true; }
    cells.forEach(function (el) {
        paint(el);
        el.addEventListener('change', function () { paint(el); dirty = true; });
        el.addEventListener('input', function () { dirty = true; });
        el.addEventListener('keydown', function (e) {   // Enter: the same column, next student
            if (e.key !== 'Enter') return; e.preventDefault();
            var idx = rows.indexOf(el.closest('tr')) + 1;
            if (idx < rows.length) { var n = rows[idx].querySelector('[data-col="' + el.dataset.col + '"]'); if (n) n.focus(); }
        });
    });
    // Bulk Fill: one value into one column (or all), blank cells only unless "also overwrite" is ticked
    document.getElementById('bgo').addEventListener('click', function () {
        var v = document.getElementById('bv').value.trim(), col = document.getElementById('bc').value, all = document.getElementById('ball').checked, n = 0;
        if (v === '') { msg.textContent = 'Type the text to fill first.'; return; }
        cells.forEach(function (el) { if ((!col || el.dataset.col === col) && (all || el.value === '')) { set(el, v); n++; } });
        msg.textContent = n + ' cell' + (n === 1 ? '' : 's') + ' filled with ' + v + ' — Save to keep.';
    });
    // Magic Fill: random values into the blank cells — grades as the old pages gave them (the first 20 rows A/B, the rest A–D), text from the suggestions
    document.getElementById('magic').addEventListener('click', function () {
        if (!confirm('Fill every blank cell with a random value? Check them before saving.')) return;
        var n = 0, pick = function (a) { return a[Math.floor(Math.random() * a.length)]; };
        cells.forEach(function (el) {
            if (el.value !== '') return;
            var r = Math.random(), top = rows.indexOf(el.closest('tr')) < 20;
            set(el, graded ? (top ? (r < 0.7 ? 'A' : 'B') : (r < 0.4 ? 'A' : r < 0.7 ? 'B' : r < 0.9 ? 'C' : 'D')) : pick(suggest[el.dataset.col]));
            n++;
        });
        msg.textContent = n + ' blank cell' + (n === 1 ? '' : 's') + ' filled at random — check, then Save.';
    });
    document.getElementById('clear').addEventListener('click', function () {
        if (!confirm('Clear every cell on this page? Saving afterwards removes these students\' entries.')) return;
        cells.forEach(function (el) { set(el, ''); });
        msg.textContent = 'All cells cleared on the page — Save to keep, or reload to undo.';
    });
    window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
    f.addEventListener('submit', function () { dirty = false; });
})();
</script>
</body>
</html>
<?php
}

<?php
/**
 * HPRC — the holistic progress record of Primary & Upper Primary (the classes of exam_classes('pup')),
 * after the West Bengal Holistic Progress Report Card (2024).
 *
 *   Formative    nine parts per subject: F1a–F1c in the 1st Formative Phase (beside the 1st Summative),
 *                F2a–F2c in the 2nd, F3a–F3c in the 3rd (the exam's exam_order says which phase it is).
 *                Each part has its own full marks, set per class × subject in Formative Full Marks Settings — on the
 *                card 20 a part in Classes I–V and 30 in VI–VIII, half that for Art & Work Education and
 *                Health & Physical Education. Full marks bound the entry and are printed on the card;
 *                formative is never added to a total, a percentage, a grade, a result or a merit rank.
 *                A part not entered is NULL, never 0.
 *   Learning     A. Identified Condition — seven observations per Formative Phase, free text (HPRC_LEARNING).
 *   Behaviour    B. Behavioural Cognitive Outcomes — eleven A–D grades per Formative Phase (HPRC_BEHAVIOUR).
 *   Personality  Development of Personality and Life Skills — fifteen A–D grades once a year (HPRC_PERSONALITY).
 *
 * Every save here takes only the current students of the class (exam_students()), puts each on the
 * section the roll says (never the one a form posts), validates every row before writing any, and
 * writes in one transaction — a single bad row leaves the table as it was.
 */
require_once __DIR__ . '/exam_helper.php';
require_once __DIR__ . '/logger.php';

const HPRC_PAGES = [
    'formative_settings.php' => ['Formative Full Marks Settings', 'fa-cog'],
    'hprc_formative_entry.php' => ['Formative Entry', 'fa-tasks'],
    'hprc_learning_entry.php' => ['Learning', 'fa-brain'],
    'hprc_behavior_entry.php' => ['Behaviour', 'fa-heart'],
    'hprc_personality_entry.php' => ['Personality', 'fa-star'],
    'hprc_formative_report.php' => ['Formative Report', 'fa-file-alt'],
];
const HPRC_TERMS = [1, 2, 3];
const HPRC_PARTS = ['a', 'b', 'c'];
const HPRC_PART_MAX = 100;   // formative_settings holds whole-number full marks per part
const HPRC_PHASES = [1 => '1st Formative Phase', 2 => '2nd Formative Phase', 3 => '3rd Formative Phase'];

/** The card's grades for Behaviour and Personality. */
const HPRC_GRADES = ['A' => 'Very good', 'B' => 'Good', 'C' => 'Satisfactory', 'D' => 'Requires more development'];
const HPRC_TEXT_MAX = 100;   // a Learning observation (hprc_learning columns are VARCHAR(100))

/** A. Identified Condition (Learning Perspective of Cognitive Domain): column => [English, Bengali, suggestions]. */
const HPRC_LEARNING = [
    'pattern_of_intelligence'        => ['Pattern of intelligence', 'বুদ্ধিমত্তার বৈচিত্র্য', ['Linguistic', 'Logical', 'Spatial', 'Musical', 'Interpersonal', 'Intrapersonal', 'Naturalist', 'MATH']],
    'area_of_interest'               => ['Area of interest', 'আগ্রহের ক্ষেত্র', ['Sports', 'Drawing', 'Music', 'Dancing', 'Reading', 'Gardening', 'Craft', 'Debate', 'Painting']],
    'positive_attitude'              => ['Positive attitude', 'মনোভাব', ['Punctual', 'Helpful', 'Curious', 'Team Player', 'Disciplined', 'Leadership', 'Respectful']],
    'exceptional_ability'            => ['Exceptional ability', 'ব্যতিক্রমী দক্ষতা', ['None', 'Memory', 'Creativity', 'Orator', 'Problem Solver', 'Artistic', 'Analytical']],
    'features_of_anxiety'            => ['Features of anxiety', 'উদ্বেগের বৈশিষ্ট্যসমূহ', ['None', 'Exam Fear', 'Shyness', 'Anxiety', 'Confidence', 'Attention', 'Slow Learner']],
    'learning_gaps'                  => ['Learning gaps', 'শিখনে অপূর্ণতা', ['None', 'Basic Concepts', 'Reading', 'Math', 'Writing', 'Science', 'Language']],
    'specific_learning_difficulties' => ['Specific learning difficulties', 'বিশেষ শিখন প্রতিবন্ধকতা', ['None', 'Dyslexia', 'Dyscalculia', 'ADHD', 'Dysgraphia', 'Speech Delay', 'Processing']],
];
/** B. Behavioural Cognitive Outcomes: column => [English, Bengali]. */
const HPRC_BEHAVIOUR = [
    'self_awareness'         => ['Self awareness', 'আত্মসচেতনতা'],
    'communication_skill'    => ['Communication skill', 'যোগাযোগের দক্ষতা'],
    'collaborative_thinking' => ['Collaborative thinking / Classification', 'সমবেত চিন্তন / শ্রেণিবদ্ধকরণ'],
    'experiential_learning'  => ['Experiential learning skill', 'অভিজ্ঞতালব্ধ শিখন দক্ষতা'],
    'critical_thinking'      => ['Critical thinking', 'গভীর চিন্তন'],
    'computational_thinking' => ['Computational / Analytical thinking', 'গণন / বিশ্লেষণমূলক চিন্তন'],
    'problem_solving'        => ['Problem solving ability / Drawing effective conclusion', 'সমস্যা সমাধানের সামর্থ্য / সার্থক উপসংহার নির্মাণ'],
    'decision_making'        => ['Decision making skills', 'সিদ্ধান্ত গ্রহণের দক্ষতা'],
    'creative_presentation'  => ['Creative presentation skill', 'সৃজনশীল উপস্থাপনের দক্ষতা'],
    'aesthetic_appreciation' => ['Aesthetic appreciation', 'নান্দনিক বোধগম্যতা'],
    'teacher_perception'     => ["Teacher's perception (Overall)", 'শিক্ষিকা / শিক্ষকের সার্বিক মূল্যায়ন'],
];
/** Development of Personality and Life Skills: column => [English, Bengali]. */
const HPRC_PERSONALITY = [
    'listening_skill'     => ['Listening skill', 'শ্রবণ দক্ষতা'],
    'communication_skill' => ['Communication skill', 'সংযোগের দক্ষতা'],
    'empathy_skill'       => ['Empathy skill', 'সমানুভূতির দক্ষতা'],
    'cooperation_skill'   => ['Co-operation skill', 'সহযোগিতার দক্ষতা'],
    'conversation_skill'  => ['Conversation skill', 'কথোপকথনের দক্ষতা'],
    'friendship_skill'    => ['Friendship skill', 'বন্ধুত্ব স্থাপনের দক্ষতা'],
    'conflict_resolution' => ['Conflict resolution / Problem solving skills', 'দ্বন্দ্ব নিরসন / সমস্যা সমাধানের দক্ষতা'],
    'stress_coping'       => ['Stress coping skill', 'মানসিক চাপ মোকাবিলার দক্ষতা'],
    'decision_making'     => ['Decision making skill', 'সিদ্ধান্ত গ্রহণের দক্ষতা'],
    'interpersonal_skill' => ['Interpersonal skill', 'পারস্পরিক সম্পর্ক রক্ষার দক্ষতা'],
    'organisation_skill'  => ['Organisational skill', 'সাংগঠনিক দক্ষতা'],
    'emotion_control'     => ['Emotion control skill', 'আবেগ নিয়ন্ত্রণের দক্ষতা'],
    'respect_skill'       => ['Respect skill', 'শ্রদ্ধা জ্ঞাপনের দক্ষতা'],
    'assertiveness_skill' => ['Assertiveness skill / Positive attitude', 'দৃঢ় মত প্রকাশের দক্ষতা / ইতিবাচক মনোভাব'],
    'leadership'          => ['Leadership', 'নেতৃত্বদান'],
];
/**
 * The three observation grids. per_phase: one sheet per Formative Phase (kept against the exam that carries
 * it, evaluation_no 1); otherwise one sheet a year. graded: A–D; otherwise free text.
 */
const HPRC_GRIDS = [
    'learning'    => ['table' => 'hprc_learning', 'fields' => HPRC_LEARNING, 'per_phase' => true, 'graded' => false],
    'behaviour'   => ['table' => 'hprc_behavior', 'fields' => HPRC_BEHAVIOUR, 'per_phase' => true, 'graded' => true],
    'personality' => ['table' => 'hprc_personality_lifeskills', 'fields' => HPRC_PERSONALITY, 'per_phase' => false, 'graded' => true],
];

/** Column keys of the parts: all nine (f1a…f3c), or one phase's three. */
function hprc_part_keys(int $term = 0): array {
    $o = [];
    foreach ($term ? [$term] : HPRC_TERMS as $t) foreach (HPRC_PARTS as $p) $o[] = "f$t$p";
    return $o;
}

/** The formative phase an exam carries: its exam_order when that is 1–3 (1st/2nd/3rd Summative), else 0. */
function hprc_part_of_exam(array $exam): int {
    $o = (int)($exam['exam_order'] ?? 0);
    return in_array($o, HPRC_TERMS, true) ? $o : 0;
}

/**
 * The card's full marks for one part of a subject in a class: 20 in Classes I–V, 30 in VI–VIII, half for
 * Art & Work Education and Health & Physical Education (matched on "work" / "physical" in the name).
 * Only a suggestion for Formative Full Marks Settings to fill in — nothing is saved until the admin saves it.
 */
function hprc_standard_part_full(string $class_name, string $subject_name): int {
    $pos = array_search(strtoupper(trim($class_name)), class_roman_list(), true);
    $full = ($pos !== false && $pos >= 5) ? 30 : 20;   // index 5 = VI
    return preg_match('/work|physical/i', $subject_name) ? intdiv($full, 2) : $full;
}

/** Formative full marks of a class: subject_id => ['f1a' => x, …, 'f3c' => x] (only subjects that have settings). */
function hprc_formative_settings(int $session_id, int $class_id): array {
    $o = [];
    foreach (db_get_all('SELECT * FROM formative_settings WHERE session_id = ? AND class_id = ?', 'ii', $session_id, $class_id) as $r) {
        $parts = [];
        foreach (hprc_part_keys() as $k) $parts[$k] = (float)$r[$k . '_full_marks'];
        $o[(int)$r['subject_id']] = $parts;
    }
    return $o;
}

/**
 * Save Formative Full Marks Settings of a class. $rows = subject_id => ['f1a' => '', …]; whole numbers 0–100.
 * A subject left wholly blank has its settings removed; a blank part of a filled subject is 0 (not used).
 * A part cannot be set below marks already entered for it.
 */
function hprc_save_settings(int $session_id, int $class_id, array $rows, int $admin_id): array {
    if (!exam_class_has_formative($class_id)) return ['ok' => false, 'errors' => ['_' => 'This class has no formative evaluation']];
    $subs = exam_class_subject_list($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $sid => $r) {
        $sid = (int)$sid;
        if (!isset($subs[$sid])) { $errors[$sid] = 'not a subject of this class'; continue; }
        $vals = []; $any = false;
        foreach (hprc_part_keys() as $k) {
            $v = trim((string)($r[$k] ?? ''));
            if ($v === '') { $vals[$k] = 0; continue; }
            if (!preg_match('/^\d{1,3}$/', $v) || (int)$v > HPRC_PART_MAX) { $errors[$sid] = strtoupper($k) . ': a whole number 0–' . HPRC_PART_MAX; continue 2; }
            $vals[$k] = (int)$v; $any = true;
        }
        $clean[$sid] = $any ? $vals : null;
    }
    // a part may not drop below what is already entered for it
    foreach ($clean as $sid => $vals) {
        $max = db_get_row('SELECT ' . implode(', ', array_map(fn($k) => "MAX($k) AS $k", hprc_part_keys())) . ' FROM hprc_formative WHERE session_id = ? AND class_id = ? AND subject_id = ?', 'iii', $session_id, $class_id, $sid) ?: [];
        foreach (hprc_part_keys() as $k) {
            if (($max[$k] ?? null) === null) continue;
            $limit = $vals === null ? 0 : $vals[$k];
            if ((float)$max[$k] > $limit) { $errors[$sid] = strtoupper($k) . ': marks up to ' . exam_fmt($max[$k]) . ' are already entered — the full marks cannot be lower'; break; }
        }
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $saved = 0; $removed = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $sid => $vals) {
            if ($vals === null) { $removed += (int)db_execute('DELETE FROM formative_settings WHERE session_id = ? AND class_id = ? AND subject_id = ?', 'iii', $session_id, $class_id, $sid); continue; }
            $cols = array_map(fn($k) => $k . '_full_marks', hprc_part_keys());
            $ok = db_execute('INSERT INTO formative_settings (session_id, class_id, subject_id, ' . implode(', ', $cols) . ') VALUES (?, ?, ?' . str_repeat(', ?', 9) . ')
                ON DUPLICATE KEY UPDATE ' . implode(', ', array_map(fn($c) => "$c = VALUES($c)", $cols)),
                'iii' . str_repeat('i', 9), $session_id, $class_id, $sid, ...array_values($vals));
            if ($ok === false) throw new RuntimeException('formative_settings upsert failed');
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hprc_save_settings: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    log_action($admin_id, 'HPRC_SETTINGS_SAVED', 'formative_settings', $class_id, null, ['session_id' => $session_id, 'saved' => $saved, 'removed' => $removed]);
    return ['ok' => true, 'saved' => $saved, 'removed' => $removed];
}

/** Entered formative parts of a class, every subject (or one): uid => subject_id => ['f1a' => float|null, …]. */
function hprc_formative_class_rows(int $session_id, int $class_id, int $subject_id = 0): array {
    $sql = 'SELECT student_id, subject_id, ' . implode(', ', hprc_part_keys()) . ' FROM hprc_formative WHERE session_id = ? AND class_id = ?';
    $types = 'ii'; $params = [$session_id, $class_id];
    if ($subject_id) { $sql .= ' AND subject_id = ?'; $types .= 'i'; $params[] = $subject_id; }
    $o = [];
    foreach (db_get_all($sql, $types, ...$params) as $r) {
        foreach (hprc_part_keys() as $k) $o[$r['student_id']][(int)$r['subject_id']][$k] = $r[$k] === null ? null : (float)$r[$k];
    }
    return $o;
}

/** Entered formative parts of a class × subject: uid => ['f1a' => float|null, …]. */
function hprc_formative_rows(int $session_id, int $class_id, int $subject_id): array {
    return array_map(fn($by_subject) => $by_subject[$subject_id], hprc_formative_class_rows($session_id, $class_id, $subject_id));
}

/** Entry progress of one phase for a class: subject_id => ['done' => students with any part entered, 'total' => students who take it, 'set' => has settings]. */
function hprc_formative_status(int $session_id, int $class_id, int $term): array {
    $subs = exam_class_subject_list($session_id, $class_id);
    $settings = hprc_formative_settings($session_id, $class_id);
    $students = exam_students($session_id, $class_id);
    $done = [];
    if (in_array($term, HPRC_TERMS, true)) {
        $any = implode(' OR ', array_map(fn($k) => "$k IS NOT NULL", hprc_part_keys($term)));
        foreach (db_get_all("SELECT subject_id, COUNT(*) AS n FROM hprc_formative WHERE session_id = ? AND class_id = ? AND ($any) GROUP BY subject_id", 'ii', $session_id, $class_id) as $r) $done[(int)$r['subject_id']] = (int)$r['n'];
    }
    $out = [];
    foreach ($subs as $sid => $s) {
        $n = 0; foreach ($students as $st) if (exam_student_takes($st, $s)) $n++;
        $out[$sid] = ['done' => $done[$sid] ?? 0, 'total' => $n, 'set' => isset($settings[$sid])];
    }
    return $out;
}

/** One formative part: [whole number 0…$full | null when blank, error | null]. Formative takes no decimals. */
function hprc_parse_part(string $v, float $full): array {
    $v = trim($v);
    if ($v === '') return [null, null];
    if (!preg_match('/^\d{1,3}$/', $v)) return [null, 'a whole number, no decimals'];
    if ((int)$v > $full) return [null, 'exceeds full marks (' . exam_fmt($full) . ')'];
    return [(int)$v, null];
}

/**
 * Save one phase of formative marks: the phase the exam carries, for one subject of the class.
 * $rows = uid => ['a' => '', 'b' => '', 'c' => '']; each part a whole number up to its full marks.
 * Blank = not entered; all three blank clears the phase.
 */
function hprc_save_formative(int $session_id, int $exam_id, int $class_id, int $subject_id, array $rows, int $admin_id): array {
    $exam = exam_get($exam_id);
    if (!$exam || (int)$exam['session_id'] !== $session_id) return ['ok' => false, 'errors' => ['_' => 'Exam not found in this session']];
    if (!exam_class_has_formative($class_id)) return ['ok' => false, 'errors' => ['_' => 'This class has no formative evaluation']];
    $term = hprc_part_of_exam($exam);
    if (!$term) return ['ok' => false, 'errors' => ['_' => $exam['exam_name'] . ' carries no formative phase — only the 1st, 2nd and 3rd Summative do']];
    $sub = exam_class_subject_list($session_id, $class_id)[$subject_id] ?? null;
    if (!$sub) return ['ok' => false, 'errors' => ['_' => 'Subject is not part of this class']];
    $full = hprc_formative_settings($session_id, $class_id)[$subject_id] ?? null;
    if (!$full) return ['ok' => false, 'errors' => ['_' => 'Formative full marks are not set for ' . $sub['name'] . ' — set them under Formative Full Marks Settings first']];
    $students = exam_students($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $uid => $r) {
        $uid = student_uid_clean($uid);
        $st = $students[$uid] ?? null;
        if (!$st) { $errors[$uid] = 'not a current student of this class'; continue; }
        if (!exam_student_takes($st, $sub)) { $errors[$uid] = 'does not take this subject'; continue; }
        $vals = []; $any = false;
        foreach (HPRC_PARTS as $p) {
            $k = "f$term$p"; $v = (string)($r[$p] ?? '');
            if ($full[$k] <= 0) {
                if (trim($v) !== '') { $errors[$uid] = strtoupper($k) . ' is not used for this subject'; continue 2; }
                $vals[$k] = null; continue;
            }
            [$m, $e] = hprc_parse_part($v, $full[$k]);
            if ($e) { $errors[$uid] = strtoupper($k) . ': ' . $e; continue 2; }
            $vals[$k] = $m; if ($m !== null) $any = true;
        }
        $clean[$uid] = $any ? ['vals' => $vals, 'section' => $st['section_id']] : null;
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $keys = hprc_part_keys($term);   // column names come from fixed lists, never from the request
    $saved = 0; $cleared = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $c) {
            if ($c === null) {
                $cleared += (int)db_execute('UPDATE hprc_formative SET ' . implode(', ', array_map(fn($k) => "$k = NULL", $keys)) . ' WHERE session_id = ? AND class_id = ? AND student_id = ? AND subject_id = ?', 'iisi', $session_id, $class_id, $uid, $subject_id);
                db_execute('DELETE FROM hprc_formative WHERE session_id = ? AND class_id = ? AND student_id = ? AND subject_id = ? AND ' . implode(' AND ', array_map(fn($k) => "$k IS NULL", hprc_part_keys())), 'iisi', $session_id, $class_id, $uid, $subject_id);
                continue;
            }
            $v = array_values($c['vals']);
            $ok = db_execute('INSERT INTO hprc_formative (session_id, class_id, section_id, student_id, subject_id, ' . implode(', ', $keys) . ') VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE section_id = VALUES(section_id), ' . implode(', ', array_map(fn($k) => "$k = VALUES($k)", $keys)),
                'iiisiddd', $session_id, $class_id, $c['section'] ?: null, $uid, $subject_id, $v[0], $v[1], $v[2]);
            if ($ok === false) throw new RuntimeException('hprc_formative upsert failed');
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hprc_save_formative: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    log_action($admin_id, 'HPRC_FORMATIVE_SAVED', 'hprc_formative', $exam_id, null, ['class_id' => $class_id, 'subject_id' => $subject_id, 'term' => $term, 'saved' => $saved, 'cleared' => $cleared]);
    return ['ok' => true, 'saved' => $saved, 'cleared' => $cleared, 'term' => $term];
}

/** Entered observations of one sheet of a class: uid => [column => value|null]. $exam_id only for a per-phase grid. */
function hprc_grid_rows(string $kind, int $session_id, int $class_id, int $exam_id = 0): array {
    $g = HPRC_GRIDS[$kind];
    $cols = array_keys($g['fields']);   // column names come from fixed lists, never from the request
    $sql = 'SELECT student_id, ' . implode(', ', $cols) . ' FROM ' . $g['table'] . ' WHERE session_id = ? AND class_id = ?';
    $types = 'ii'; $params = [$session_id, $class_id];
    if ($g['per_phase']) { $sql .= ' AND exam_id = ? AND evaluation_no = 1'; $types .= 'i'; $params[] = $exam_id; }
    $o = [];
    foreach (db_get_all($sql, $types, ...$params) as $r) {
        foreach ($cols as $c) $o[$r['student_id']][$c] = ($r[$c] === null || $r[$c] === '') ? null : (string)$r[$c];
    }
    return $o;
}

/** One observation, cleaned: [value|null, error|null]. A grade is A–D (any case); text is one line of at most HPRC_TEXT_MAX characters. */
function hprc_parse_observation(bool $graded, string $v): array {
    $v = trim((string)preg_replace('/\s+/u', ' ', $v));
    if ($v === '') return [null, null];
    if ($graded) {
        $grade = strtoupper($v);
        return isset(HPRC_GRADES[$grade]) ? [$grade, null] : [null, 'grade must be A, B, C or D'];
    }
    if (preg_match('/[\x00-\x1F\x7F]/u', $v) || mb_strlen($v) > HPRC_TEXT_MAX) return [null, 'at most ' . HPRC_TEXT_MAX . ' characters of plain text'];
    return [$v, null];
}

/**
 * Save one observation sheet of a class: $kind of HPRC_GRIDS, and for a per-phase grid the exam that carries the
 * phase. $rows = uid => [column => value]. Blank = not assessed; a student left wholly blank has the row removed.
 */
function hprc_save_grid(string $kind, int $session_id, int $class_id, int $exam_id, array $rows, int $admin_id): array {
    $g = HPRC_GRIDS[$kind] ?? null;
    if (!$g) return ['ok' => false, 'errors' => ['_' => 'Unknown HPRC sheet']];
    if (!exam_class_has_formative($class_id)) return ['ok' => false, 'errors' => ['_' => 'HPRC is kept for Primary and Upper Primary classes only']];
    if ($g['per_phase']) {
        $exam = exam_get($exam_id);
        if (!$exam || (int)$exam['session_id'] !== $session_id || !hprc_part_of_exam($exam)) return ['ok' => false, 'errors' => ['_' => 'Choose a Formative Phase of this session']];
    } else {
        $exam_id = 0;
    }
    $students = exam_students($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $uid => $r) {
        $uid = student_uid_clean($uid);
        $st = $students[$uid] ?? null;
        if (!$st) { $errors[$uid] = 'not a current student of this class'; continue; }
        $vals = []; $any = false;
        foreach ($g['fields'] as $col => $f) {
            [$v, $e] = hprc_parse_observation($g['graded'], (string)($r[$col] ?? ''));
            if ($e) { $errors[$uid] = $f[0] . ': ' . $e; continue 2; }
            $vals[$col] = $v; if ($v !== null) $any = true;
        }
        $clean[$uid] = $any ? ['vals' => $vals, 'section' => $st['section_id']] : null;
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $cols = array_keys($g['fields']);
    $key = $g['per_phase'] ? ['exam_id', 'evaluation_no'] : [];   // the rest of the table's unique key
    $insert = array_merge(['session_id', 'class_id', 'section_id', 'student_id'], $key, $cols);
    $saved = 0; $cleared = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $c) {
            if ($c === null) {
                $where = 'session_id = ? AND class_id = ? AND student_id = ?' . ($g['per_phase'] ? ' AND exam_id = ? AND evaluation_no = 1' : '');
                $cleared += (int)db_execute('DELETE FROM ' . $g['table'] . ' WHERE ' . $where, $g['per_phase'] ? 'iisi' : 'iis', ...($g['per_phase'] ? [$session_id, $class_id, $uid, $exam_id] : [$session_id, $class_id, $uid]));
                continue;
            }
            $params = array_merge([$session_id, $class_id, $c['section'] ?: null, $uid], $g['per_phase'] ? [$exam_id, 1] : [], array_values($c['vals']));
            $ok = db_execute('INSERT INTO ' . $g['table'] . ' (' . implode(', ', $insert) . ') VALUES (' . implode(', ', array_fill(0, count($insert), '?')) . ')
                ON DUPLICATE KEY UPDATE section_id = VALUES(section_id), ' . implode(', ', array_map(fn($k) => "$k = VALUES($k)", $cols)),
                'iiis' . ($g['per_phase'] ? 'ii' : '') . str_repeat('s', count($cols)), ...$params);
            if ($ok === false) throw new RuntimeException($g['table'] . ' upsert failed');
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hprc_save_grid: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    log_action($admin_id, 'HPRC_' . strtoupper($kind) . '_SAVED', $g['table'], $class_id, null, ['session_id' => $session_id, 'exam_id' => $exam_id, 'saved' => $saved, 'cleared' => $cleared]);
    return ['ok' => true, 'saved' => $saved, 'cleared' => $cleared];
}

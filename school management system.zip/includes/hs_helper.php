<?php
/**
 * Higher Secondary helpers (classes XI–XII, WBCHSE semester system).
 *
 * Class XI sits Semester 1 and Semester 2 in the school (`hs_exam`); Class XII is examined by the board,
 * so the school keeps only its subject combination and WBCHSE registration.
 * Semester 1 is theory only; Semester 2 carries the practical / project marks as well, and every subject has one.
 * Full and pass marks are per exam × subject (`hs_exam_subject_marks`): theory 40 + practical 20, or theory 35 +
 * practical 30 — all configurable. THEORY AND PRACTICAL ARE PASSED SEPARATELY, and theory is judged per semester.
 * A student's own subject combination lives in `hs_student_subjects`, ONE ROW PER SUBJECT: five or six in all —
 * Bengali and English (compulsory), three main subjects, and an optional additional subject.
 * Marks are one row per exam × student × subject in `hs_marks` (theory, supplementary, practical, absent).
 *
 * The V–X helpers are reused wherever the rule is the same: exam_parse_mark(), exam_fmt(),
 * exam_sections(), grade_for() — see includes/exam_helper.php and includes/result_helper.php.
 */
require_once __DIR__ . '/exam_helper.php';

const HS_SEMESTERS = [1 => 'Semester 1', 2 => 'Semester 2', 3 => 'Semester 3', 4 => 'Semester 4'];
const HS_SCHOOL_SEMESTERS = [1, 2];          // what the school conducts; 3 and 4 are board exams
const HS_MAIN_REQUIRED = 3;                  // main subjects besides Bengali and English
const HS_ELECTIVES_MAX = 4;                  // the fourth one is the optional additional subject
const HS_COUNTED_SUBJECTS = 5;               // the mark sheet's Grand Total is the best five subjects
const HS_SLOTS = ['compulsory' => 'Compulsory', 'elective' => 'Main', 'additional' => 'Additional'];
const HS_COMPULSORY_NAMES = ['Bengali', 'English'];

/**
 * The Higher Secondary classes, taken from the STAGE stored on each class (not from its name):
 * id => ['name', 'semesters', 'board'] in order. The first HS class sits Semesters 1–2, the second 3–4.
 * 'board' means the board conducts that class's examination, so the school holds none.
 */
function hs_classes(): array {
    static $c = null;
    if ($c === null) {
        $c = []; $n = 0;
        foreach (class_rows() as $id => $row) {
            if ($row['stage'] !== 'higher_secondary') continue;
            $sem = $n === 0 ? [1, 2] : ($n === 1 ? [3, 4] : []);
            $c[$id] = ['name' => $row['name'], 'semesters' => $sem, 'board' => $row['board_exam']];
            $n++;
        }
    }
    return $c;
}
function hs_is_hs_class(int $class_id): bool { return isset(hs_classes()[$class_id]); }
function hs_class_name(int $class_id): string { return hs_classes()[$class_id]['name'] ?? ''; }
/** The two semesters of a class: XI => [1,2], XII => [3,4]. */
function hs_semesters(int $class_id): array { return hs_classes()[$class_id]['semesters'] ?? []; }
/** The semesters the school itself conducts for this class — none when the board conducts its exam. */
function hs_school_semesters(int $class_id): array {
    if (hs_classes()[$class_id]['board'] ?? false) return [];
    return array_values(array_intersect(hs_semesters($class_id), HS_SCHOOL_SEMESTERS));
}
/** Classes whose exams the school runs itself. Subject combination and registration still cover them all. */
function hs_exam_classes(): array { return array_filter(hs_classes(), fn($c) => !$c['board'] && $c['semesters']); }
/** The second semester of a year carries the practical / project marks. */
function hs_semester_has_practical(int $semester): bool { return $semester % 2 === 0; }

/** The two compulsory subjects (Bengali, English) as id => name; falls back to the first two subjects. */
function hs_compulsory_subjects(): array {
    static $c = null;
    if ($c === null) {
        $c = [];
        $names = implode(',', array_fill(0, count(HS_COMPULSORY_NAMES), '?'));
        foreach (db_get_all("SELECT id, subject_name FROM subjects WHERE subject_name IN ($names) ORDER BY id", str_repeat('s', count(HS_COMPULSORY_NAMES)), ...HS_COMPULSORY_NAMES) as $r) $c[(int)$r['id']] = $r['subject_name'];
    }
    return $c;
}

/* ─────────────────────────── exams ─────────────────────────── */

/** Semester exams of a session (optionally one class), in class + semester order, with counts. */
function hs_exam_list(int $session_id, int $class_id = 0): array {
    $sql = "SELECT e.*, c.class_name, s.session_name,
                   (SELECT COUNT(*) FROM hs_exam_subject_marks WHERE hs_exam_id = e.id) AS subjects_configured,
                   (SELECT COUNT(DISTINCT subject_id) FROM hs_marks WHERE hs_exam_id = e.id) AS subjects_with_marks,
                   (SELECT COUNT(*) FROM hs_marks WHERE hs_exam_id = e.id) AS marks_rows
            FROM hs_exam e JOIN classes c ON c.id = e.class_id JOIN academic_sessions s ON s.id = e.session_id
            WHERE e.session_id = ?";
    $t = 'i'; $p = [$session_id];
    if ($class_id) { $sql .= ' AND e.class_id = ?'; $t .= 'i'; $p[] = $class_id; }
    return db_get_all($sql . ' ORDER BY c.sort_order, e.semester', $t, ...$p);
}
function hs_exam_get(int $exam_id): ?array {
    return db_get_row('SELECT e.*, c.class_name, s.session_name FROM hs_exam e JOIN classes c ON c.id = e.class_id JOIN academic_sessions s ON s.id = e.session_id WHERE e.id = ?', 'i', $exam_id) ?: null;
}
/** The exam of one class × semester, or null. */
function hs_exam_of_semester(int $session_id, int $class_id, int $semester): ?array {
    return db_get_row('SELECT * FROM hs_exam WHERE session_id = ? AND class_id = ? AND semester = ?', 'iii', $session_id, $class_id, $semester) ?: null;
}
/** Rows that hang off a semester exam (delete guard). */
function hs_exam_dependencies(int $exam_id): array {
    $d = [];
    foreach (['hs_marks' => 'Marks', 'hs_exam_subject_marks' => 'Full/pass marks config'] as $t => $label) {
        $n = (int)(db_get_row("SELECT COUNT(*) AS n FROM $t WHERE hs_exam_id = ?", 'i', $exam_id)['n'] ?? 0);
        if ($n) $d[$label] = $n;
    }
    foreach (['exam_routine' => 'Exam routine', 'exam_seating_plan' => 'Seating plan', 'exam_duty_roster' => 'Duty roster'] as $t => $label) {
        $r = db_get_row("SELECT COUNT(*) AS n FROM $t WHERE exam_id = ? AND exam_source = 'hs'", 'i', $exam_id);
        if ($r && (int)$r['n']) $d[$label] = (int)$r['n'];
    }
    return $d;
}

/* ───────────────────── subjects and their marks config ───────────────────── */

/** Subjects the class offers (class_subjects catalogue): id => [id, name, code, practical_name]. */
function hs_class_subject_list(int $session_id, int $class_id): array {
    $out = [];
    foreach (db_get_all('SELECT s.id, s.subject_name, s.subject_code FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id
        WHERE cs.session_id = ? AND cs.class_id = ? AND cs.has_exam = 1 ORDER BY s.subject_name', 'ii', $session_id, $class_id) as $r) {
        $name = $r['subject_name'];
        $out[(int)$r['id']] = ['id' => (int)$r['id'], 'name' => $name, 'code' => (string)$r['subject_code'],
            // "Physics Practical" is the practical of Physics; in this module practical is a component of the subject
            'is_practical_row' => (bool)preg_match('/\bpractical\b/i', $name)];
    }
    return $out;
}

/**
 * Subjects of one semester exam with their full/pass marks.
 * Each: id, name, code, configured, theory_full, theory_pass, practical_full, practical_pass, has_practical, full (total).
 */
function hs_exam_subjects(int $exam_id): array {
    $exam = hs_exam_get($exam_id);
    if (!$exam) return [];
    $subs = hs_class_subject_list((int)$exam['session_id'], (int)$exam['class_id']);
    $cfg = [];
    foreach (db_get_all('SELECT * FROM hs_exam_subject_marks WHERE hs_exam_id = ?', 'i', $exam_id) as $r) $cfg[(int)$r['subject_id']] = $r;
    $has_prac = (int)$exam['has_practical'] === 1;
    foreach ($subs as $sid => &$s) {
        $c = $cfg[$sid] ?? null;
        $s['configured'] = (bool)$c;
        $s['theory_full'] = (float)($c['theory_full_marks'] ?? 0); $s['theory_pass'] = (float)($c['theory_pass_marks'] ?? 0);
        $s['practical_full'] = $has_prac ? (float)($c['practical_full_marks'] ?? 0) : 0.0;
        $s['practical_pass'] = $has_prac ? (float)($c['practical_pass_marks'] ?? 0) : 0.0;
        $s['has_practical'] = $s['practical_full'] > 0;
        $s['full'] = (float)($c['total_full_marks'] ?? 0);
        $s['pass'] = $s['theory_pass'] + $s['practical_pass'];   // for display only — each part is passed on its own
    }
    return $subs;
}

/** Save the full/pass marks of one semester exam: rows = subject_id => [theory_full, theory_pass, practical_full, practical_pass]. */
function hs_config_save(int $exam_id, array $rows, int $admin_id): array {
    $exam = hs_exam_get($exam_id);
    if (!$exam) return ['ok' => false, 'errors' => ['_' => 'Exam not found.']];
    $subs = hs_class_subject_list((int)$exam['session_id'], (int)$exam['class_id']);
    $has_prac = (int)$exam['has_practical'] === 1;
    $errors = []; $clean = [];
    foreach ($rows as $sid => $r) {
        $sid = (int)$sid; if (!isset($subs[$sid])) continue;
        $v = [];
        foreach (['theory_full', 'theory_pass', 'practical_full', 'practical_pass'] as $k) {
            $x = trim((string)($r[$k] ?? '')); if ($x === '') $x = '0';
            if (!preg_match('/^\d{1,3}(\.\d{1,2})?$/', $x)) { $errors[$sid] = 'Invalid number'; continue 2; }
            $v[$k] = (float)$x;
        }
        if (!$has_prac) { $v['practical_full'] = 0; $v['practical_pass'] = 0; }
        if ($v['theory_pass'] > $v['theory_full']) { $errors[$sid] = 'Theory pass marks cannot exceed theory full marks'; continue; }
        if ($v['practical_pass'] > $v['practical_full']) { $errors[$sid] = 'Practical pass marks cannot exceed practical full marks'; continue; }
        if ($v['theory_full'] <= 0 && $v['practical_full'] <= 0) continue;   // blank row = not in this exam
        $clean[$sid] = $v;
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    db_begin_transaction();
    try {
        db_execute('DELETE FROM hs_exam_subject_marks WHERE hs_exam_id = ?', 'i', $exam_id);
        foreach ($clean as $sid => $v) {
            db_execute('INSERT INTO hs_exam_subject_marks (hs_exam_id, session_id, class_id, subject_id, theory_full_marks, theory_pass_marks, practical_full_marks, practical_pass_marks, total_full_marks) VALUES (?,?,?,?,?,?,?,?,?)',
                'iiiiddddd', $exam_id, (int)$exam['session_id'], (int)$exam['class_id'], $sid, $v['theory_full'], $v['theory_pass'], $v['practical_full'], $v['practical_pass'], $v['theory_full'] + $v['practical_full']);
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hs_config_save: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed']]; }
    log_action($admin_id, 'HS_CONFIG_SAVED', 'hs_exam_subject_marks', $exam_id, null, ['subjects' => count($clean)]);
    return ['ok' => true, 'saved' => count($clean)];
}

/* ───────────────────── students and their subject choice ───────────────────── */

/**
 * HS students of a class in roll order: uid => row (+ registration no). By default the class as it is now (Active,
 * Current). With $as_of_exam (an hs_exam id) the class as it was for that exam, for its reports: also those who have
 * moved on since (promoted to XII, detained, passed out) and those who left later but sat that exam. Never Deleted.
 */
function hs_students(int $session_id, int $class_id, ?int $section_id = null, int $as_of_exam = 0): array {
    $who = $as_of_exam
        ? '(sah.academic_status = "Current" AND s.student_status = "Active") OR sah.promotion_status IN ("Promoted", "Detained")
           OR EXISTS (SELECT 1 FROM hs_marks m WHERE m.student_id = sah.student_id AND m.hs_exam_id = ?)'
        : 'sah.academic_status = "Current" AND s.student_status = "Active"';
    $sql = 'SELECT s.id, s.student_name, s.gender, s.dob, s.banglarshiksha_id, s.pen_id, g.father_name, sah.section_id, sec.section_name, sah.roll_no,
                   hr.registration_no, hr.registration_year
            FROM student_academic_history sah
            JOIN students s ON s.id = sah.student_id AND s.student_status <> "Deleted"
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN sections sec ON sec.id = sah.section_id
            LEFT JOIN hs_registration hr ON hr.student_id = s.id
            WHERE sah.session_id = ? AND sah.class_id = ? AND (' . $who . ')';
    $t = 'ii'; $p = [$session_id, $class_id];
    if ($as_of_exam) { $t .= 'i'; $p[] = $as_of_exam; }
    if ($section_id) { $sql .= ' AND sah.section_id = ?'; $t .= 'i'; $p[] = $section_id; }
    $sql .= ' ORDER BY sec.section_name, CAST(sah.roll_no AS UNSIGNED), sah.roll_no, s.student_name';
    $out = [];
    foreach (db_get_all($sql, $t, ...$p) as $r) {
        $out[$r['id']] = ['uid' => $r['id'], 'name' => $r['student_name'], 'father' => (string)$r['father_name'], 'gender' => (string)$r['gender'],
            'dob' => $r['dob'], 'bsid' => (string)$r['banglarshiksha_id'], 'pen' => (string)$r['pen_id'], 'section_id' => (int)$r['section_id'], 'section' => (string)$r['section_name'],
            'roll' => (string)$r['roll_no'], 'reg_no' => (string)$r['registration_no'], 'reg_year' => (string)$r['registration_year'], 'subjects' => []];
    }
    return $out;
}

/** Subject choice of a class (or section): uid => subject_id => slot. */
function hs_student_subjects(int $session_id, int $class_id, ?int $section_id = null): array {
    $sql = 'SELECT hss.student_id, hss.subject_id, hss.slot FROM hs_student_subjects hss';
    $t = 'ii'; $p = [$session_id, $class_id];
    // a student has one class row per session, so the section is that year's whether or not they are still there
    if ($section_id) { $sql .= ' JOIN student_academic_history sah ON sah.student_id = hss.student_id AND sah.session_id = hss.session_id'; }
    $sql .= ' WHERE hss.session_id = ? AND hss.class_id = ?';
    if ($section_id) { $sql .= ' AND sah.section_id = ?'; $t .= 'i'; $p[] = $section_id; }
    $out = [];
    foreach (db_get_all($sql, $t, ...$p) as $r) $out[$r['student_id']][(int)$r['subject_id']] = $r['slot'];
    return $out;
}
/** Subject choice of one student in a session: subject_id => slot. */
function hs_student_subjects_one(int $session_id, string $uid): array {
    $o = [];
    foreach (db_get_all('SELECT subject_id, slot FROM hs_student_subjects WHERE session_id = ? AND student_id = ?', 'is', $session_id, $uid) as $r) $o[(int)$r['subject_id']] = $r['slot'];
    return $o;
}

/**
 * Save one student's combination. $subject_ids = every subject the student takes (compulsory included).
 * Compulsory subjects are forced in; the rest become elective, and anything beyond the first three
 * electives is stored as 'additional'. Returns ['ok' => bool, 'error' => string|null].
 */
function hs_subjects_save(int $session_id, int $class_id, string $uid, array $subject_ids, int $admin_id = 0, bool $log = true): array {
    $uid = student_uid_clean($uid);
    if ($uid === '') return ['ok' => false, 'error' => 'No student.'];
    $catalogue = hs_class_subject_list($session_id, $class_id);
    $comp = array_keys(hs_compulsory_subjects());
    $ids = array_values(array_unique(array_map('intval', $subject_ids)));
    foreach ($ids as $sid) if (!isset($catalogue[$sid])) return ['ok' => false, 'error' => 'Subject #' . $sid . ' is not offered in Class ' . hs_class_name($class_id) . '.'];
    foreach ($comp as $c) if (isset($catalogue[$c]) && !in_array($c, $ids, true)) $ids[] = $c;
    $electives = array_values(array_diff($ids, $comp));
    if ($electives && (count($electives) < HS_MAIN_REQUIRED || count($electives) > HS_ELECTIVES_MAX)) return ['ok' => false, 'error' => 'Choose ' . HS_MAIN_REQUIRED . ' main subjects and at most one additional — ' . count($electives) . ' chosen.'];
    db_begin_transaction();
    try {
        db_execute('DELETE FROM hs_student_subjects WHERE session_id = ? AND student_id = ?', 'is', $session_id, $uid);
        foreach ($ids as $sid) {
            $slot = in_array($sid, $comp, true) ? 'compulsory' : (array_search($sid, $electives, true) >= 3 ? 'additional' : 'elective');
            db_execute('INSERT INTO hs_student_subjects (session_id, class_id, student_id, subject_id, slot) VALUES (?,?,?,?,?)', 'iisis', $session_id, $class_id, $uid, $sid, $slot);
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hs_subjects_save: ' . $e->getMessage()); return ['ok' => false, 'error' => 'Save failed.']; }
    if ($log && $admin_id) log_action($admin_id, 'HS_SUBJECTS_SAVED', 'hs_student_subjects', null, null, ['student' => $uid, 'session' => $session_id, 'subjects' => count($ids)]);
    return ['ok' => true, 'saved' => count($ids)];
}

/** Does this student take this subject? */
function hs_takes(array $choice, int $subject_id): bool { return isset($choice[$subject_id]); }

/**
 * One student's subjects in the order the tabulation sheet shows them — Compulsory 1 & 2 (Bengali, English),
 * Main 1–3, Additional — so every student fills the same six columns whatever their combination is.
 * @param array $rows subject_id => row carrying 'slot' (from hs_result_semester / hs_result_year)
 * @param array $names subject_id => subject name, for a stable order among the main subjects
 * @return array{c1:?int,c2:?int,m1:?int,m2:?int,m3:?int,a:?int}
 */
function hs_slot_order(array $rows, array $names): array {
    $comp = array_keys(hs_compulsory_subjects());
    $by = ['compulsory' => [], 'elective' => [], 'additional' => []];
    foreach ($rows as $sid => $r) {
        $slot = (string)($r['slot'] ?? 'elective');
        if (!isset($by[$slot])) $slot = 'elective';
        $by[$slot][] = (int)$sid;
    }
    usort($by['compulsory'], fn($a, $b) => array_search($a, $comp, true) <=> array_search($b, $comp, true));
    $byName = fn($a, $b) => strcmp((string)($names[$a] ?? ''), (string)($names[$b] ?? ''));
    usort($by['elective'], $byName); usort($by['additional'], $byName);
    $out = ['c1' => $by['compulsory'][0] ?? null, 'c2' => $by['compulsory'][1] ?? null,
        'm1' => $by['elective'][0] ?? null, 'm2' => $by['elective'][1] ?? null, 'm3' => $by['elective'][2] ?? null,
        'a' => $by['additional'][0] ?? null];
    if ($out['a'] === null && isset($by['elective'][3])) $out['a'] = $by['elective'][3];   // a fourth main = the additional one
    return $out;
}

/* ─────────────────────────── marks ─────────────────────────── */

/** Marks of one semester exam: uid => subject_id => row. One subject with $subject_id. */
function hs_marks(int $exam_id, int $subject_id = 0): array {
    $sql = 'SELECT m.*, a.username AS entered_by_name FROM hs_marks m LEFT JOIN admins a ON a.id = m.entered_by WHERE m.hs_exam_id = ?';
    $t = 'i'; $p = [$exam_id];
    if ($subject_id) { $sql .= ' AND m.subject_id = ?'; $t .= 'i'; $p[] = $subject_id; }
    $o = [];
    foreach (db_get_all($sql, $t, ...$p) as $r) $o[$r['student_id']][(int)$r['subject_id']] = $r;
    return $o;
}

/** Entry progress of a semester exam: subject_id => ['done' => n, 'total' => students who take it, 'configured' => bool]. */
function hs_entry_status(int $exam_id): array {
    $exam = hs_exam_get($exam_id); if (!$exam) return [];
    $subs = hs_exam_subjects($exam_id);
    $choice = hs_student_subjects((int)$exam['session_id'], (int)$exam['class_id']);
    $students = hs_students((int)$exam['session_id'], (int)$exam['class_id']);
    $done = [];
    foreach (db_get_all('SELECT subject_id, COUNT(*) AS n FROM hs_marks WHERE hs_exam_id = ? GROUP BY subject_id', 'i', $exam_id) as $r) $done[(int)$r['subject_id']] = (int)$r['n'];
    $out = [];
    foreach ($subs as $sid => $s) {
        $n = 0; foreach ($students as $uid => $st) if (isset($choice[$uid][$sid])) $n++;
        $out[$sid] = ['done' => $done[$sid] ?? 0, 'total' => $n, 'configured' => $s['configured']];
    }
    return $out;
}

/**
 * Save marks of one semester exam × subject. $rows = uid => [theory, supplementary, practical, theory_absent, practical_absent].
 * Every row is validated first; nothing is written when any row fails. Blank and not absent = not entered (row cleared).
 */
function hs_marks_save_rows(int $exam_id, int $subject_id, array $rows, int $admin_id): array {
    $exam = hs_exam_get($exam_id);
    if (!$exam) return ['ok' => false, 'errors' => ['_' => 'Exam not found.']];
    $subs = hs_exam_subjects($exam_id);
    $sub = $subs[$subject_id] ?? null;
    if (!$sub) return ['ok' => false, 'errors' => ['_' => 'Subject is not offered in this class']];
    if (!$sub['configured']) return ['ok' => false, 'errors' => ['_' => 'Full marks are not set for this subject — set them under HS Full & Pass Marks first']];
    $session_id = (int)$exam['session_id']; $class_id = (int)$exam['class_id'];
    $students = hs_students($session_id, $class_id);
    $choice = hs_student_subjects($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $uid => $r) {
        $uid = student_uid_clean($uid);
        if (!isset($students[$uid])) { $errors[$uid] = 'not a current student of this class'; continue; }
        if (!isset($choice[$uid][$subject_id])) { $errors[$uid] = 'does not take this subject'; continue; }
        $tab = !empty($r['theory_absent']); $pab = !empty($r['practical_absent']);
        [$th, $e1] = exam_parse_mark((string)($r['theory'] ?? ''), $sub['theory_full']);
        [$sp, $e2] = exam_parse_mark((string)($r['supplementary'] ?? ''), $sub['theory_full']);
        [$pr, $e3] = exam_parse_mark((string)($r['practical'] ?? ''), max($sub['practical_full'], 0));
        if ($e1) { $errors[$uid] = 'Theory: ' . $e1; continue; }
        if ($e2) { $errors[$uid] = 'Supplementary: ' . $e2; continue; }
        if ($e3) { $errors[$uid] = 'Practical: ' . $e3; continue; }
        // supplementary is the second chance for a failed semester — it cannot be given to a student who passed
        if ($sp !== null && !$tab) {
            if ($th === null) { $errors[$uid] = 'enter the theory mark first — supplementary is only for a failed semester'; continue; }
            if ($th >= $sub['theory_pass']) { $errors[$uid] = 'theory is already a pass (' . exam_fmt($th) . ' of ' . exam_fmt($sub['theory_full']) . ') — supplementary is only for a failed semester'; continue; }
        }
        if (!$sub['has_practical']) { $pr = null; $pab = false; }
        if ($tab) { $th = null; $sp = $sp; }
        if ($pab) $pr = null;
        if ($th === null && $sp === null && $pr === null && !$tab && !$pab) { $clean[$uid] = null; continue; }   // clear
        $clean[$uid] = ['t' => $th, 's' => $sp, 'p' => $pr, 'ta' => $tab ? 1 : 0, 'pa' => $pab ? 1 : 0];
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $saved = 0; $cleared = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $v) {
            if ($v === null) { $cleared += (int)db_execute('DELETE FROM hs_marks WHERE hs_exam_id = ? AND student_id = ? AND subject_id = ?', 'isi', $exam_id, $uid, $subject_id); continue; }
            $ok = db_execute('INSERT INTO hs_marks (hs_exam_id, student_id, subject_id, theory_marks, theory_supplementary_marks, theory_absent, practical_marks, practical_absent, entered_by)
                VALUES (?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE theory_marks = VALUES(theory_marks), theory_supplementary_marks = VALUES(theory_supplementary_marks),
                    theory_absent = VALUES(theory_absent), practical_marks = VALUES(practical_marks), practical_absent = VALUES(practical_absent), entered_by = VALUES(entered_by)',
                'isiddidii', $exam_id, $uid, $subject_id, $v['t'], $v['s'], $v['ta'], $v['p'], $v['pa'], $admin_id);
            if ($ok === false) throw new RuntimeException('hs marks upsert failed');
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hs_marks_save_rows: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    log_action($admin_id, 'HS_MARKS_SAVED', 'hs_marks', $exam_id, null, ['subject_id' => $subject_id, 'saved' => $saved, 'cleared' => $cleared]);
    return ['ok' => true, 'saved' => $saved, 'cleared' => $cleared];
}

/**
 * Save the combinations of many students at once (one page of the Subject Combination screen).
 * $rows = uid => [subject_id, …]. Every row is validated first; nothing is written when any row fails,
 * so a page never saves half its students.
 */
function hs_subjects_save_many(int $session_id, int $class_id, array $rows, int $admin_id): array {
    $catalogue = hs_class_subject_list($session_id, $class_id);
    $comp = array_keys(hs_compulsory_subjects());
    $students = hs_students($session_id, $class_id);
    $errors = []; $clean = [];
    foreach ($rows as $uid => $ids) {
        $uid = student_uid_clean($uid);
        if (!isset($students[$uid])) { $errors[$uid] = 'not a current student of this class'; continue; }
        $ids = array_values(array_unique(array_map('intval', (array)$ids)));
        foreach ($ids as $sid) if (!isset($catalogue[$sid])) { $errors[$uid] = 'subject #' . $sid . ' is not offered in this class'; continue 2; }
        foreach ($comp as $c) if (isset($catalogue[$c]) && !in_array($c, $ids, true)) $ids[] = $c;
        $electives = array_values(array_diff($ids, $comp));
        // a combination is either empty (not chosen yet) or exactly four subjects besides Bengali and English
        if ($electives && (count($electives) < HS_MAIN_REQUIRED || count($electives) > HS_ELECTIVES_MAX)) { $errors[$uid] = 'choose ' . HS_MAIN_REQUIRED . ' main subjects and at most one additional (' . count($electives) . ' chosen)'; continue; }
        $clean[$uid] = ['ids' => $ids, 'electives' => $electives];
    }
    if ($errors) return ['ok' => false, 'errors' => $errors];
    $saved = 0; $cleared = 0;
    db_begin_transaction();
    try {
        foreach ($clean as $uid => $v) {
            db_execute('DELETE FROM hs_student_subjects WHERE session_id = ? AND student_id = ?', 'is', $session_id, $uid);
            if (!$v['electives'] && count($v['ids']) === count($comp)) { $cleared++; continue; }   // nothing chosen: leave the student out
            foreach ($v['ids'] as $sid) {
                $slot = in_array($sid, $comp, true) ? 'compulsory' : (array_search($sid, $v['electives'], true) >= 3 ? 'additional' : 'elective');
                $ok = db_execute('INSERT INTO hs_student_subjects (session_id, class_id, student_id, subject_id, slot) VALUES (?,?,?,?,?)', 'iisis', $session_id, $class_id, $uid, $sid, $slot);
                if ($ok === false) throw new RuntimeException('combination insert failed');
            }
            $saved++;
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('hs_subjects_save_many: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['_' => 'Save failed — nothing was changed']]; }
    log_action($admin_id, 'HS_SUBJECTS_SAVED', 'hs_student_subjects', $class_id, null, ['session_id' => $session_id, 'students' => $saved, 'cleared' => $cleared]);
    return ['ok' => true, 'saved' => $saved, 'cleared' => $cleared];
}

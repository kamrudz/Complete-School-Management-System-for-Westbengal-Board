<?php
/**
 * Higher Secondary results (XI–XII) — the ONE place the WBCHSE rules are written.
 *
 * THEORY AND PRACTICAL ARE PASSED SEPARATELY, and theory is judged semester by semester:
 *   · Semester 1 theory must reach its own pass marks, and so must Semester 2 theory.
 *   · The practical / project (entered in Semester 2) must reach its own pass marks.
 * Supplementary is the second chance for a semester that was failed: the higher mark counts, and if it is
 * still below the pass marks the subject is failed.
 * Year result = Semester 1 + Semester 2 of Class XI (Class XII is examined by the board).
 *
 *   BEST OF 5 = the five highest-scoring subjects, whichever they are. The optional elective replaces the
 *   weakest subject even when that is a compulsory language — the school's own WBCHSE mark sheet is added up
 *   this way (BNGA 91 · ENGB 93 · CHEM 92 · COMA 94 · PHYS 93 · BIOS 93 → Grand Total 465, BNGA dropped).
 *   Overall FAIL when a compulsory subject fails, or fewer than five subjects pass (all of them when a
 *   student takes only five). Supplementary is the second chance: a subject rescued by it counts as passed.
 *
 * Grade comes from grade_bands (class_group 'XI-XII'), percentage from the best-of-5 total,
 * rank is dense over the list handed in — the same shape result_helper.php uses for V–X.
 */
require_once __DIR__ . '/hs_helper.php';
require_once __DIR__ . '/result_helper.php';

/**
 * The theory mark that counts. Supplementary is only sat after a failed semester, so it replaces the
 * regular mark when it is higher; a supplementary that is still below the pass marks leaves the subject failed.
 */
function hs_theory_counted(?float $theory, ?float $supp): ?float {
    if ($theory === null && $supp === null) return null;
    if ($theory === null) return $supp;
    if ($supp === null) return $theory;
    return max($theory, $supp);
}

/**
 * One semester exam for a class (or section).
 * ['exam' => row, 'subjects' => [sid => cfg], 'students' => [uid => student + subjects[sid] => cell]]
 * cell: theory, supplementary, counted, practical, total, full, pass, absent, missing, fail
 * $report: the class as it was for this exam — also the students who have left it since (see hs_students()).
 */
function hs_result_semester(int $exam_id, ?int $section_id = null, bool $report = false): array {
    $exam = hs_exam_get($exam_id);
    if (!$exam) return ['exam' => null, 'subjects' => [], 'students' => []];
    $session_id = (int)$exam['session_id']; $class_id = (int)$exam['class_id'];
    $subjects = array_filter(hs_exam_subjects($exam_id), fn($s) => $s['configured']);
    $students = hs_students($session_id, $class_id, $section_id, $report ? $exam_id : 0);
    $choice = hs_student_subjects($session_id, $class_id, $section_id);
    $marks = hs_marks($exam_id);
    foreach ($students as $uid => &$st) {
        $st['subjects'] = [];
        foreach ($subjects as $sid => $s) {
            if (!isset($choice[$uid][$sid])) continue;
            $m = $marks[$uid][$sid] ?? null;
            $th = $m && $m['theory_marks'] !== null ? (float)$m['theory_marks'] : null;
            $sp = $m && $m['theory_supplementary_marks'] !== null ? (float)$m['theory_supplementary_marks'] : null;
            $pr = $m && $m['practical_marks'] !== null ? (float)$m['practical_marks'] : null;
            $tab = $m ? (int)$m['theory_absent'] === 1 : false;
            $pab = $m ? (int)$m['practical_absent'] === 1 : false;
            // a supplementary sat after an absence counts too, so the absent theory is simply "no mark"
            $counted = hs_theory_counted($tab ? null : $th, $sp);
            $supp_used = $sp !== null && $counted !== null && $counted === $sp && ($tab || $th === null || $sp > $th);
            $total = (float)($counted ?? 0) + (float)($pab ? 0 : ($pr ?? 0));
            $theory_fail = ($tab && $counted === null) || ($counted !== null && $counted < $s['theory_pass']);
            $practical_fail = $s['has_practical'] && ($pab || ($pr !== null && $pr < $s['practical_pass']));
            $st['subjects'][$sid] = [
                'slot' => $choice[$uid][$sid], 'theory' => $th, 'supplementary' => $sp, 'counted' => $counted, 'supp_used' => $supp_used,
                'practical' => $pab ? null : $pr, 'theory_absent' => $tab, 'practical_absent' => $pab,
                'total' => $total, 'full' => $s['full'], 'pass' => $s['pass'],
                'theory_pass' => $s['theory_pass'], 'practical_pass' => $s['practical_pass'],
                'missing' => !$m, 'absent' => $tab || $pab,
                // theory and practical are judged on their own; a component not entered yet is not judged
                'theory_fail' => $theory_fail,
                'practical_fail' => $practical_fail,
                'fail' => $theory_fail || $practical_fail,
                'pct' => $s['full'] > 0 ? round($total / $s['full'] * 100, 2) : 0.0,
            ];
        }
    }
    unset($st);
    return ['exam' => $exam, 'subjects' => $subjects, 'students' => $students, 'has_practical' => (int)$exam['has_practical'] === 1];
}

/**
 * The year for a class: its two semesters added up per subject, then best of 5.
 * ['exams' => [sem => exam], 'subjects' => [sid => meta], 'students' => [uid => …], 'warnings' => []]
 * student: subjects[sid] => [sem => cell, 'total', 'full', 'fail', 'slot', 'pct', 'grade'],
 *          best5 (sid list), total, full, pct, grade, status PASS|FAIL|ABSENT, rank, failed_n
 * $report: the class as it was at the end of the year — also those who have left since (promoted to XII, detained,
 * passed out, or gone after sitting the year's last semester). Without it, only the students in the class now.
 */
function hs_result_year(int $session_id, int $class_id, ?int $section_id = null, bool $report = false): array {
    $sems = hs_school_semesters($class_id);
    $last = $report && $sems ? hs_exam_of_semester($session_id, $class_id, end($sems)) : null;
    $students = hs_students($session_id, $class_id, $section_id, $last ? (int)$last['id'] : 0);
    $choice = hs_student_subjects($session_id, $class_id, $section_id);
    $comp = array_keys(hs_compulsory_subjects());
    $exams = []; $per = []; $meta = []; $warnings = [];
    foreach (hs_school_semesters($class_id) as $sem) {   // XII is examined by the board
        $e = hs_exam_of_semester($session_id, $class_id, $sem);
        if (!$e) { $warnings[] = HS_SEMESTERS[$sem] . ': no exam created for this class'; continue; }
        $exams[$sem] = $e;
        $subs = array_filter(hs_exam_subjects((int)$e['id']), fn($s) => $s['configured']);
        if (!$subs) { $warnings[] = $e['exam_name'] . ': full marks are not set'; continue; }
        $per[$sem] = ['subjects' => $subs, 'marks' => hs_marks((int)$e['id']), 'has_practical' => (int)$e['has_practical'] === 1];
        if (!$per[$sem]['marks']) $warnings[] = $e['exam_name'] . ': no marks entered yet';
        foreach ($subs as $sid => $s) $meta[$sid] = $meta[$sid] ?? ['id' => $sid, 'name' => $s['name'], 'code' => $s['code']];
    }
    uasort($meta, fn($a, $b) => (in_array($b['id'], $comp, true) <=> in_array($a['id'], $comp, true)) ?: strcmp($a['name'], $b['name']));

    foreach ($students as $uid => &$st) {
        $st['subjects'] = [];
        foreach ($meta as $sid => $m) {
            if (!isset($choice[$uid][$sid])) continue;
            $row = ['slot' => $choice[$uid][$sid], 'sem' => [], 'total' => 0.0, 'full' => 0.0, 'pass' => 0.0, 'fail' => false, 'theory_fail' => false, 'practical_fail' => false, 'missing' => true, 'absent' => false];
            foreach ($per as $sem => $p) {
                if (!isset($p['subjects'][$sid])) { $row['sem'][$sem] = null; continue; }
                $cfg = $p['subjects'][$sid]; $mk = $p['marks'][$uid][$sid] ?? null;
                $th = $mk && $mk['theory_marks'] !== null ? (float)$mk['theory_marks'] : null;
                $sp = $mk && $mk['theory_supplementary_marks'] !== null ? (float)$mk['theory_supplementary_marks'] : null;
                $pr = $mk && $mk['practical_marks'] !== null ? (float)$mk['practical_marks'] : null;
                $tab = $mk ? (int)$mk['theory_absent'] === 1 : false;
                $pab = $mk ? (int)$mk['practical_absent'] === 1 : false;
                // a supplementary sat after an absence counts too, so the absent theory is simply "no mark"
                $counted = hs_theory_counted($tab ? null : $th, $sp);
                $supp_used = $sp !== null && $counted !== null && $counted === $sp && ($tab || $th === null || $sp > $th);
                $got = (float)($counted ?? 0) + (float)($pab ? 0 : ($pr ?? 0));
                $theory_fail = ($tab && $counted === null) || ($counted !== null && $counted < $cfg['theory_pass']);
                $practical_fail = $cfg['has_practical'] && ($pab || ($pr !== null && $pr < $cfg['practical_pass']));
                $row['sem'][$sem] = ['theory' => $th, 'supplementary' => $sp, 'counted' => $counted, 'supp_used' => $supp_used, 'practical' => $pab ? null : $pr,
                    'theory_absent' => $tab, 'practical_absent' => $pab, 'total' => $got, 'full' => $cfg['full'], 'missing' => !$mk,
                    'theory_full' => $cfg['theory_full'], 'practical_full' => $cfg['practical_full'], 'has_practical' => $cfg['has_practical'],
                    'theory_pass' => $cfg['theory_pass'], 'practical_pass' => $cfg['practical_pass'],
                    'theory_fail' => $theory_fail, 'practical_fail' => $practical_fail];
                $row['total'] += $got; $row['full'] += $cfg['full']; $row['pass'] += $cfg['pass'];
                if ($mk) $row['missing'] = false;
                if ($tab || $pab) $row['absent'] = true;
                if ($theory_fail) $row['theory_fail'] = true;
                if ($practical_fail) $row['practical_fail'] = true;
                if ($theory_fail || $practical_fail) $row['fail'] = true;   // each part is passed on its own
            }
            if ($row['missing']) $row['fail'] = true;   // nothing entered cannot be a pass
            $row['pct'] = $row['full'] > 0 ? round($row['total'] / $row['full'] * 100, 2) : 0.0;
            $row['grade'] = grade_for($row['pct'], $class_id)['grade'];
            $st['subjects'][$sid] = $row;
        }
        // ── best of five: the highest-scoring five, whatever they are (a passed subject beats a failed one
        //    with the same marks). This is what drops a weak compulsory language when an optional elective beats it.
        $ranked = $st['subjects'];
        uasort($ranked, fn($a, $b) => ($a['fail'] <=> $b['fail']) ?: ($b['total'] <=> $a['total']));
        $counted_ids = array_slice(array_keys($ranked), 0, HS_COUNTED_SUBJECTS);
        $total = 0.0; $full = 0.0;
        foreach ($counted_ids as $sid) { $total += $st['subjects'][$sid]['total']; $full += $st['subjects'][$sid]['full']; }
        // a compulsory subject must be passed, and five subjects in all (every one of them when only five are taken)
        $comp_fail = false;
        foreach ($comp as $c) if (isset($st['subjects'][$c]) && $st['subjects'][$c]['fail']) $comp_fail = true;
        $passing = count(array_filter($st['subjects'], fn($r) => !$r['fail']));
        $needed = min(HS_COUNTED_SUBJECTS, count($st['subjects']));
        $entered = count(array_filter($st['subjects'], fn($r) => !$r['missing']));
        $st['best5'] = $counted_ids;
        $st['total'] = round($total, 2); $st['full'] = round($full, 2);
        $st['pct'] = $full > 0 ? round($total / $full * 100, 2) : 0.0;
        $st['subjects_n'] = count($st['subjects']);
        $st['failed_n'] = count(array_filter($st['subjects'], fn($r) => $r['fail']));
        $st['status'] = $entered === 0 ? 'ABSENT' : (($comp_fail || $passing < $needed) ? 'FAIL' : 'PASS');
        $g = grade_for($st['pct'], $class_id); $st['grade'] = $st['status'] === 'ABSENT' ? '-' : $g['grade']; $st['grade_remark'] = $g['remark'];
        $st['rank'] = null;
    }
    unset($st);
    // dense rank on the best-of-5 total, absentees unranked (same rule as V–X)
    $order = array_keys($students);
    usort($order, fn($a, $b) => ($students[$b]['total'] <=> $students[$a]['total']) ?: ($students[$b]['pct'] <=> $students[$a]['pct']) ?: strcmp($students[$a]['name'], $students[$b]['name']));
    $rank = 0; $prev = null;
    foreach ($order as $uid) {
        if ($students[$uid]['status'] === 'ABSENT') continue;
        if ($prev === null || $students[$uid]['total'] < $prev) { $rank++; $prev = $students[$uid]['total']; }
        $students[$uid]['rank'] = $rank;
    }
    return ['exams' => $exams, 'subjects' => $meta, 'students' => $students, 'compulsory' => $comp, 'warnings' => $warnings];
}

/** True when every semester exam of the class in that session is published (public result allowed). */
function hs_year_publishable(int $session_id, int $class_id): bool {
    $sems = hs_school_semesters($class_id); if (!$sems) return false;
    foreach ($sems as $sem) { $e = hs_exam_of_semester($session_id, $class_id, $sem); if (!$e || (int)$e['is_published'] !== 1) return false; }
    return true;
}

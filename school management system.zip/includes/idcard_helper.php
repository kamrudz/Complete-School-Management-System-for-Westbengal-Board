<?php
/**
 * Returns the id_cards row for a student+session, creating one (with a fresh
 * random verification token) if it doesn't exist yet. One card per student
 * per session — regenerating the page reuses the same token/QR unless the
 * card is explicitly revoked and reissued.
 */
function ensure_id_card($conn, $student_id, $session_id) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM student_id_cards WHERE student_id=? AND session_id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "si", $student_id, $session_id);
    mysqli_stmt_execute($stmt);
    $card = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if($card) {
        return $card;
    }

    $token = bin2hex(random_bytes(32));
    $today = date('Y-m-d');
    $created_by = $_SESSION['admin_id'] ?? null;

    $stmt = mysqli_prepare($conn, "INSERT INTO student_id_cards (student_id, session_id, verification_token, issued_date, created_by) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "sissi", $student_id, $session_id, $token, $today, $created_by);
    mysqli_stmt_execute($stmt);

    $stmt = mysqli_prepare($conn, "SELECT * FROM student_id_cards WHERE student_id=? AND session_id=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "si", $student_id, $session_id);
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

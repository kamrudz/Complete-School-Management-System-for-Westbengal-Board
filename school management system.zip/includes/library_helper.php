<?php
/**
 * Generates the next Accession No — same pattern as certificate_add.php's next_cert_no().
 * Format: LIB-2026-001, LIB-2026-002 ...
 */
function next_accession_no($conn) {
    $prefix = 'LIB-' . date('Y') . '-';
    $stmt = mysqli_prepare($conn, "SELECT accession_no FROM library_book_copies WHERE accession_no LIKE ? ORDER BY id DESC LIMIT 1");
    $like = $prefix . '%';
    mysqli_stmt_bind_param($stmt, "s", $like);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if ($row && preg_match('/(\d+)$/', $row['accession_no'], $m)) {
        $num = (int)$m[1];
        return $prefix . str_pad($num + 1, strlen($m[1]), '0', STR_PAD_LEFT);
    }
    return $prefix . '001';
}

/** A borrower id as it is stored: a student's School UID, or a staff member's number as text; '' when invalid. */
function library_borrower_id(string $borrower_type, $raw): string {
    if ($borrower_type === 'Student') return student_uid_clean($raw);
    $id = (int)$raw;
    return $borrower_type === 'Staff' && $id > 0 ? (string)$id : '';
}

/** Returns the single row from library_settings (default values if none exists) */
function get_library_settings($conn) {
    $row = db_get_row("SELECT * FROM library_settings WHERE id=? LIMIT 1", 'i', 1);
    if ($row) return $row;
    return [
        'loan_period_days' => 15, 'max_renewals' => 2, 'fine_per_day' => 10.00,
        'max_books_per_student' => 2, 'max_books_per_staff' => 5,
    ];
}

/** Calculates fine as of today (for books not yet returned) */
function calc_current_fine($due_date, $fine_per_day, $return_date = null) {
    $end = $return_date ?: date('Y-m-d');
    $days_late = (strtotime($end) - strtotime($due_date)) / 86400;
    if ($days_late <= 0) return 0;
    return round($days_late * $fine_per_day, 2);
}

/**
 * Looks up name and class/designation from borrower_type + borrower_id —
 * for a student, current class/roll is auto-fetched from student_academic_history.
 */
function get_borrower_info($conn, $borrower_type, $borrower_id) {
    if ($borrower_type === 'Student') {
        $stmt = mysqli_prepare($conn, "
            SELECT s.id, s.student_name AS name, s.photo, h.roll_no, c.class_name, sec.section_name
            FROM students s
            LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
            LEFT JOIN classes c ON c.id = h.class_id
            LEFT JOIN sections sec ON sec.id = h.section_id
            WHERE s.id = ? LIMIT 1
        ");
    } else {
        $stmt = mysqli_prepare($conn, "SELECT id, staff_name AS name, photo, designation FROM staff WHERE id = ? LIMIT 1");
    }
    mysqli_stmt_bind_param($stmt, "s", $borrower_id);   // a student's id is a UID string; a staff id compares fine as text
    mysqli_stmt_execute($stmt);
    return mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
}

/** How many books this borrower currently has Issued (not yet returned) */
function count_active_issues($conn, $borrower_type, $borrower_id) {
    $stmt = mysqli_prepare($conn, "SELECT COUNT(*) c FROM library_issues WHERE borrower_type=? AND borrower_id=? AND status='Issued'");
    mysqli_stmt_bind_param($stmt, "ss", $borrower_type, $borrower_id);
    mysqli_stmt_execute($stmt);
    return (int)(mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['c'] ?? 0);
}

/** For checking before student deactivation/TC — whether any book is still with them */
function has_unreturned_books($conn, $student_id) {
    return count_active_issues($conn, 'Student', $student_id) > 0;
}

/** Whether this staff_id has library_staff_access — checked live against the DB
 *  instead of session, so revoking access from admin takes effect immediately
 *  (no re-login needed). */
function is_library_staff($conn, $staff_id) {
    $staff_id = (int)$staff_id;
    if ($staff_id <= 0) return false;
    return (bool)db_get_row("SELECT 1 AS ok FROM library_staff_access WHERE staff_id=? LIMIT 1", 'i', $staff_id);
}

/** Return one physical copy, optionally locking it inside a transaction. */
function get_library_copy($conn, $copy_id, $for_update = false) {
    $copy_id = (int)$copy_id;
    if ($copy_id <= 0) return null;
    $sql = "SELECT id, book_id, accession_no, status FROM library_book_copies WHERE id=? LIMIT 1";
    if ($for_update) $sql .= " FOR UPDATE";
    return db_get_row($sql, 'i', $copy_id);
}

/** Fetch an open issue with book/copy details; can lock it for return/lost actions. */
function get_open_library_issue($conn, $issue_id, $for_update = false) {
    $issue_id = (int)$issue_id;
    if ($issue_id <= 0) return null;
    $sql = "SELECT li.*, c.book_id, c.accession_no, b.title, b.price
            FROM library_issues li
            JOIN library_book_copies c ON c.id=li.copy_id
            JOIN library_books b ON b.id=c.book_id
            WHERE li.id=? AND li.status='Issued' LIMIT 1";
    if ($for_update) $sql .= " FOR UPDATE";
    return db_get_row($sql, 'i', $issue_id);
}

function set_library_copy_status($conn, $copy_id, $status) {
    $allowed = ['Available','Issued','Lost','Damaged','Withdrawn'];
    if (!in_array($status, $allowed, true)) return false;
    return db_execute("UPDATE library_book_copies SET status=? WHERE id=?", 'si', $status, (int)$copy_id) !== false;
}

/** Reject forged borrower IDs before a circulation transaction is created. */
function valid_library_borrower($conn, $borrower_type, $borrower_id) {
    $borrower_id = library_borrower_id((string)$borrower_type, $borrower_id);
    return $borrower_id !== '' && (bool)get_borrower_info($conn, $borrower_type, $borrower_id);
}


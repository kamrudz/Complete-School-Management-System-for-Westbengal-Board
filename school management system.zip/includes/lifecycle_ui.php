<?php
/**
 * Shared look and restore dialog for the three lifecycle lists
 * (TC students, Deleted students, Deactivated students).
 *
 *   lifecycle_styles()        — <style> block (call inside <head>)
 *   lifecycle_restore_modal() — the dialog + its script (call before </body>); needs $classes (id, class_name)
 *   lifecycle_student_cell()  — photo + name + UID cell
 */

function lifecycle_styles(): void { ?>
<style>
    .lc-head { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 14px; }
    .lc-head .count { background: #003366; color: #fff; font-weight: 700; padding: 3px 12px; border-radius: 999px; font-size: 13px; }
    .lc-head .spacer { flex: 1; }
    .lc-filter { display: flex; gap: 10px; flex-wrap: wrap; align-items: end; background: #f5f9fc; border: 1px solid #e1eaf2; border-radius: 12px; padding: 12px 14px; margin-bottom: 14px; }
    .lc-filter label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin-bottom: 4px; text-transform: uppercase; letter-spacing: .4px; }
    .lc-filter input, .lc-filter select { height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; background: #fff; font-size: 13.5px; min-width: 150px; }
    .lc-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 13.5px; }
    .lc-table th { background: #1f4e79; color: #fff; text-align: left; padding: 10px 12px; font-size: 12px; text-transform: uppercase; letter-spacing: .4px; position: sticky; top: 0; }
    .lc-table th:first-child { border-radius: 8px 0 0 0; } .lc-table th:last-child { border-radius: 0 8px 0 0; }
    .lc-table td { padding: 9px 12px; border-bottom: 1px solid #e6edf3; vertical-align: middle; }
    .lc-table tr:hover td { background: #f7fafd; }
    .lc-stu { display: flex; align-items: center; gap: 10px; }
    .lc-stu img, .lc-stu .noimg { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 1px solid #d5dee7; flex: 0 0 40px; }
    .lc-stu .noimg { background: #edf2f7; color: #8a9aab; display: flex; align-items: center; justify-content: center; font-size: 11px; }
    .lc-stu a { font-weight: 700; color: #10253a; text-decoration: none; }
    .lc-stu a:hover { color: #145da0; }
    .lc-uid { display: inline-block; background: #003366; color: #fff; font-size: 10.5px; font-weight: 700; padding: 1px 8px; border-radius: 8px; letter-spacing: .4px; margin-top: 2px; }
    .lc-tag { display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11.5px; font-weight: 700; border: 1px solid; }
    .lc-tag.ok { color: #1b7a3d; border-color: #9fd3b2; background: #ecf9f0; }
    .lc-tag.warn { color: #9a5a00; border-color: #f0c987; background: #fff6e5; }
    .lc-tag.bad { color: #9d2630; border-color: #f1b3b8; background: #fdeeef; }
    .lc-tag.muted { color: #5a6f84; border-color: #cfd8e1; background: #f3f6f9; }
    /* a td must stay a table-cell (display:flex on it breaks row height / borders); the buttons sit inline */
    .lc-actions { white-space: nowrap; vertical-align: middle; }
    .lc-actions .btn, .lc-actions form { display: inline-flex; vertical-align: middle; margin: 2px 4px 2px 0; }
    .lc-actions .btn:hover { transform: none; box-shadow: 0 2px 6px rgba(0,0,0,.18); }   /* no jump inside table rows */
    .btn-tc { background: #fd7e14; color: #fff; } .btn-tc:hover { background: #e8700f; }
    .btn-cert { background: #6f42c1; color: #fff; } .btn-cert:hover { background: #5d36a6; }
    .lc-empty { text-align: center; color: #7a8a9a; padding: 40px 10px; }
    .lc-empty i { font-size: 34px; display: block; margin-bottom: 10px; color: #c9d6e2; }
    /* dialog */
    .lc-modal { position: fixed; inset: 0; background: rgba(16, 37, 58, .55); display: none; align-items: center; justify-content: center; z-index: 1000; padding: 16px; }
    .lc-modal.open { display: flex; }
    .lc-dialog { background: #fff; border-radius: 14px; width: 100%; max-width: 520px; box-shadow: 0 20px 60px rgba(0,0,0,.3); overflow: hidden; }
    .lc-dialog h3 { margin: 0; padding: 14px 18px; background: linear-gradient(135deg, #145da0, #1f7ac2); color: #fff; font-size: 15px; }
    .lc-dialog .body { padding: 16px 18px; }
    .lc-dialog .row { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; margin-top: 10px; }
    .lc-dialog label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; margin-bottom: 4px; }
    .lc-dialog input, .lc-dialog select { width: 100%; height: 38px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 7px; box-sizing: border-box; }
    .lc-dialog .note { font-size: 12.5px; color: #5a6f84; background: #f6f9fc; border: 1px dashed #cfdbe6; border-radius: 8px; padding: 8px 12px; margin-top: 10px; }
    .lc-dialog .foot { display: flex; justify-content: flex-end; gap: 8px; padding: 12px 18px; background: #f5f9fc; border-top: 1px solid #e1eaf2; }
    .lc-dialog .danger-word { font-family: monospace; font-weight: 700; color: #9d2630; }
    @media (max-width: 800px) { .lc-dialog .row { grid-template-columns: 1fr; } }
</style>
<?php }

/** The reason the admin gave, taken from the status-change note in the audit log ("… | Reason: …"). */
function lifecycle_reason(?string $note): string {
    return $note && preg_match('/\| Reason: (.+)$/', $note, $m) ? trim($m[1]) : '';
}

/** Photo + name (link to profile) + UID badge. */
function lifecycle_student_cell(array $row): string {
    $name = htmlspecialchars($row['student_name'] ?? '', ENT_QUOTES, 'UTF-8');
    $uid  = htmlspecialchars($row['id'] ?? $row['student_id'] ?? '', ENT_QUOTES, 'UTF-8');
    $img  = !empty($row['photo'])
        ? '<img src="../uploads/students/' . rawurlencode($row['photo']) . '" alt="">'
        : '<span class="noimg">N/A</span>';
    return '<div class="lc-stu">' . $img . '<div><a href="' . htmlspecialchars(student_page_url('view_student.php', $uid)) . '">' . $name . '</a><br><span class="lc-uid">' . $uid . '</span></div></div>';
}

/**
 * Restore dialog. A row's button calls lcRestore(uid, name, needsPlacement, lastClassId, lastSectionId, lastRoll, from).
 * When the student's last enrolment is in the running session the dialog only confirms; otherwise it asks for
 * class / section / roll in the running session (student_set_status() insists on them).
 */
function lifecycle_restore_modal(array $classes, string $from): void { ?>
<div class="lc-modal" id="lcRestoreModal">
    <form class="lc-dialog" method="post" action="restore_student.php">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="from" value="<?php echo htmlspecialchars($from); ?>">
        <input type="hidden" name="uid" id="lcUid">
        <h3><i class="fas fa-undo"></i> Restore student</h3>
        <div class="body">
            <div><b id="lcName"></b> <span class="lc-uid" id="lcUidBadge"></span></div>
            <div class="note" id="lcNoteSame">Their last enrolment is in the running session — it will be reopened as is. Change class / section / roll below only if needed.</div>
            <div class="note" id="lcNoteNew">Their last enrolment was in an earlier session, so they need a place in the <b>running session</b>: choose class, section and roll.</div>
            <div class="row">
                <div><label>Class</label><select name="class_id" id="lcClass"><option value="">Select</option><?php foreach ($classes as $c): ?><option value="<?php echo (int)$c['id']; ?>"><?php echo htmlspecialchars($c['class_name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Section</label><select name="section_id" id="lcSection"><option value="">Select class first</option></select></div>
                <div><label>Roll</label><input type="text" name="roll_no" id="lcRoll" inputmode="numeric" maxlength="4"></div>
            </div>
            <?php if ($from === 'tc'): ?>
            <div style="margin-top:10px"><label>Reason for cancelling the TC</label><input type="text" name="cancel_reason" maxlength="255" placeholder="e.g. student decided to stay"></div>
            <?php endif; ?>
        </div>
        <div class="foot">
            <button type="button" class="btn btn-secondary" onclick="lcClose()">Cancel</button>
            <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Restore to Active</button>
        </div>
    </form>
</div>
<script>
var lcActiveSession = <?php echo (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0); ?>;
function lcLoadSections(classId, selectId) {
    var sel = document.getElementById('lcSection');
    if (!classId) { sel.innerHTML = '<option value="">Select class first</option>'; return; }
    var x = new XMLHttpRequest();
    x.open('GET', 'get_sections.php?class_id=' + encodeURIComponent(classId) + '&session_id=' + lcActiveSession, true);
    x.onload = function () { if (x.status === 200) { sel.innerHTML = x.responseText; if (selectId) sel.value = selectId; } };
    x.send();
}
function lcRestore(uid, name, needsPlacement, classId, sectionId, roll) {
    document.getElementById('lcUid').value = uid;
    document.getElementById('lcName').textContent = name;
    document.getElementById('lcUidBadge').textContent = uid;
    document.getElementById('lcNoteSame').style.display = needsPlacement ? 'none' : 'block';
    document.getElementById('lcNoteNew').style.display = needsPlacement ? 'block' : 'none';
    var cls = document.getElementById('lcClass'), rollEl = document.getElementById('lcRoll');
    cls.value = classId || ''; rollEl.value = needsPlacement ? '' : (roll || '');
    cls.required = needsPlacement; document.getElementById('lcSection').required = needsPlacement; rollEl.required = needsPlacement;
    lcLoadSections(cls.value, needsPlacement ? '' : sectionId);
    document.getElementById('lcRestoreModal').classList.add('open');
}
function lcClose() { document.getElementById('lcRestoreModal').classList.remove('open'); }
document.getElementById('lcClass').addEventListener('change', function () { lcLoadSections(this.value, ''); });
document.getElementById('lcRestoreModal').addEventListener('click', function (e) { if (e.target === this) lcClose(); });
</script>
<?php }

<?php
/**
 * logger.php — Admin Activity Logger (Fixed Foreign Key Issue)
 */

if (!defined('APP_TIMEZONE_SET')) { 
    date_default_timezone_set('Asia/Kolkata'); 
    define('APP_TIMEZONE_SET', true); 
}

// ============================================
// ENSURE DATABASE CONNECTION
// ============================================
global $conn;
if (!isset($conn) || $conn === null) {
    $db_path = __DIR__ . '/db.php';
    if (file_exists($db_path)) {
        include_once $db_path;
    } else {
        $db_path2 = dirname(__DIR__) . '/includes/db.php';
        if (file_exists($db_path2)) {
            include_once $db_path2;
        }
    }
}

if (!isset($conn) || $conn === null) {
    // No hardcoded credentials — if db.php failed to load above, log and bail out.
    error_log("Logger: \$conn is not available. Ensure db.php is included before logger.php.");
}

// ============================================
// LOG FUNCTION (FIXED)
// ============================================
function log_action($admin_id, $action, $table_name = null, $record_id = null, $old_data = null, $new_data = null) {
    global $conn;
    
    if (!isset($conn) || $conn === null) {
        error_log("Logger: \$conn is not available in log_action(). Skipping log.");
        return false;
    }
    
    // ✅ FIX: Check if admin exists before logging
    if ($admin_id > 0) {
        $check_admin = mysqli_prepare($conn, "SELECT id FROM admins WHERE id = ?");
        mysqli_stmt_bind_param($check_admin, "i", $admin_id);
        mysqli_stmt_execute($check_admin);
        $admin_exists = mysqli_num_rows(mysqli_stmt_get_result($check_admin)) > 0;
        mysqli_stmt_close($check_admin);
        
        // If admin doesn't exist, use 0 as fallback (or skip logging)
        if (!$admin_exists) {
            $admin_id = 0;
        }
    }
    
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    // Convert arrays to JSON string
    if (is_array($old_data)) {
        $old_data = json_encode($old_data, JSON_UNESCAPED_UNICODE);
    }
    if (is_array($new_data)) {
        $new_data = json_encode($new_data, JSON_UNESCAPED_UNICODE);
    }
    
    // Combine old and new data into details
    $details = '';
    if ($old_data && $new_data) {
        $details = "Old: " . $old_data . " | New: " . $new_data;
    } elseif ($new_data) {
        $details = $new_data;
    } elseif ($old_data) {
        $details = $old_data;
    }
    
    // ✅ FIX: If admin_id is 0, don't log (or log as system)
    if ($admin_id == 0) {
        // Still log but with admin_id = 0 (if your table allows NULL, you can use NULL)
        // For safety, we'll still try to log with 0
    }
    
    // Check if table exists, if not create it
    $check_table = mysqli_query($conn, "SHOW TABLES LIKE 'admin_logs'");
    if (mysqli_num_rows($check_table) == 0) {
        mysqli_query($conn, "
            CREATE TABLE IF NOT EXISTS `admin_logs` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `admin_id` INT(11) DEFAULT NULL,
                `action` VARCHAR(100) NOT NULL,
                `table_name` VARCHAR(50) DEFAULT NULL,
                `record_id` INT(11) DEFAULT NULL,
                `details` TEXT DEFAULT NULL,
                `ip_address` VARCHAR(45) DEFAULT NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_admin_id` (`admin_id`),
                KEY `idx_action` (`action`),
                KEY `idx_created_at` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
        ");
    }
    
    $created_at = date('Y-m-d H:i:s');

    // ✅ FIX: Use NULL for admin_id if 0, to avoid foreign key constraint
    if ($admin_id == 0) {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO admin_logs 
            (admin_id, action, table_name, record_id, details, ip_address, created_at)
            VALUES (NULL, ?, ?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt, "ssssss", 
            $action, 
            $table_name, 
            $record_id, 
            $details, 
            $ip_address,
            $created_at
        );
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO admin_logs 
            (admin_id, action, table_name, record_id, details, ip_address, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt, "issssss", 
            $admin_id, 
            $action, 
            $table_name, 
            $record_id, 
            $details, 
            $ip_address,
            $created_at
        );
    }
    
    if (!$stmt) {
        error_log("Logger: Prepare failed: " . mysqli_error($conn));
        return false;
    }
    
    // An audit-log failure must never abort the action being logged.
    try {
        $result = mysqli_stmt_execute($stmt);
    } catch (mysqli_sql_exception $e) {
        error_log('Logger: ' . $e->getMessage());
        $result = false;
    }
    mysqli_stmt_close($stmt);
    return $result;
}

// ============================================
// HELPER FUNCTIONS
// ============================================
function log_student_add($admin_id, $student_id, $student_name) {
    return log_action($admin_id, 'STUDENT_ADDED', 'students', $student_id, null, "Student: $student_name (ID: $student_id)");
}

function log_student_edit($admin_id, $student_id, $old_data, $new_data) {
    return log_action($admin_id, 'STUDENT_UPDATED', 'students', $student_id, $old_data, $new_data);
}

function log_student_delete($admin_id, $student_id, $student_name) {
    return log_action($admin_id, 'STUDENT_DELETED', 'students', $student_id, null, "Student: $student_name (ID: $student_id)");
}

function log_student_restore($admin_id, $student_id, $student_name) {
    return log_action($admin_id, 'STUDENT_RESTORED', 'students', $student_id, null, "Student: $student_name (ID: $student_id)");
}

function log_student_tc($admin_id, $student_id, $tc_no) {
    return log_action($admin_id, 'STUDENT_TC', 'students', $student_id, null, "TC No: $tc_no, Student ID: $student_id");
}

function log_staff_add($admin_id, $staff_id, $staff_name) {
    return log_action($admin_id, 'STAFF_ADDED', 'staff', $staff_id, null, "Staff: $staff_name (ID: $staff_id)");
}

function log_staff_edit($admin_id, $staff_id, $old_data, $new_data) {
    return log_action($admin_id, 'STAFF_UPDATED', 'staff', $staff_id, $old_data, $new_data);
}

function log_staff_delete($admin_id, $staff_id, $staff_name) {
    return log_action($admin_id, 'STAFF_DELETED', 'staff', $staff_id, null, "Staff: $staff_name (ID: $staff_id)");
}

function log_exam_add($admin_id, $exam_id, $exam_name) {
    return log_action($admin_id, 'EXAM_ADDED', 'exams', $exam_id, null, "Exam: $exam_name (ID: $exam_id)");
}

function log_exam_edit($admin_id, $exam_id, $old_data, $new_data) {
    return log_action($admin_id, 'EXAM_UPDATED', 'exams', $exam_id, $old_data, $new_data);
}

function log_exam_delete($admin_id, $exam_id, $exam_name) {
    return log_action($admin_id, 'EXAM_DELETED', 'exams', $exam_id, null, "Exam: $exam_name (ID: $exam_id)");
}

function log_class_add($admin_id, $class_id, $class_name) {
    return log_action($admin_id, 'CLASS_ADDED', 'classes', $class_id, null, "Class: $class_name (ID: $class_id)");
}

function log_class_edit($admin_id, $class_id, $old_data, $new_data) {
    return log_action($admin_id, 'CLASS_UPDATED', 'classes', $class_id, $old_data, $new_data);
}

function log_class_delete($admin_id, $class_id, $class_name) {
    return log_action($admin_id, 'CLASS_DELETED', 'classes', $class_id, null, "Class: $class_name (ID: $class_id)");
}

function log_session_activate($admin_id, $session_id, $session_name) {
    return log_action($admin_id, 'SESSION_ACTIVATED', 'academic_sessions', $session_id, null, "Session: $session_name (ID: $session_id)");
}

function log_fee_collect($admin_id, $student_id, $amount, $invoice_id) {
    return log_action($admin_id, 'FEE_COLLECTED', 'fee_transactions', $invoice_id, null, "Student ID: $student_id, Amount: $amount");
}

function log_login($admin_id, $username) {
    return log_action($admin_id, 'LOGIN', 'admins', $admin_id, null, "User: $username");
}

function log_logout($admin_id, $username) {
    return log_action($admin_id, 'LOGOUT', 'admins', $admin_id, null, "User: $username");
}

// ============================================
// VIEW LOGS
// ============================================
function get_logs($limit = 100, $offset = 0, $admin_id = null, $action = null) {
    global $conn;
    
    if (!isset($conn) || $conn === null) {
        return false;
    }
    
    $where = "WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($admin_id) {
        $where .= " AND admin_id = ?";
        $params[] = $admin_id;
        $types .= "i";
    }
    
    if ($action) {
        $where .= " AND action = ?";
        $params[] = $action;
        $types .= "s";
    }
    
    $sql = "SELECT l.*, a.username, a.full_name 
            FROM admin_logs l
            LEFT JOIN admins a ON l.admin_id = a.id
            $where
            ORDER BY l.created_at DESC
            LIMIT ? OFFSET ?";
    
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";
    
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return false;
    }
    
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}

function count_logs($admin_id = null, $action = null) {
    global $conn;
    
    if (!isset($conn) || $conn === null) {
        return 0;
    }
    
    $where = "WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($admin_id) {
        $where .= " AND admin_id = ?";
        $params[] = $admin_id;
        $types .= "i";
    }
    
    if ($action) {
        $where .= " AND action = ?";
        $params[] = $action;
        $types .= "s";
    }
    
    $sql = "SELECT COUNT(*) as total FROM admin_logs $where";
    $stmt = mysqli_prepare($conn, $sql);
    
    if (!$stmt) {
        return 0;
    }
    
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}
?>
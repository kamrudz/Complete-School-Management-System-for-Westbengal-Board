<?php
/**
 * Brute-force lockout shared by the login pages (login_attempts table):
 * 5 failures on an identifier -> locked for 15 minutes. Identifiers are namespaced
 * ("teacher:ULPHS-ST-0001", "teacher-ip:192.168.1.5") so portals do not affect each other.
 * admin/login.php still carries its own copy of the same logic; these are function_exists-guarded.
 */
if (!function_exists('get_login_attempt')) {
function get_login_attempt($conn, $identifier) {
    return db_get_row('SELECT * FROM login_attempts WHERE identifier = ?', 's', $identifier) ?: null;
}
function register_failed_attempt($conn, $identifier, $max_attempts = 5, $lockout_minutes = 15) {
    $row = get_login_attempt($conn, $identifier);
    if (!$row) { db_execute('INSERT INTO login_attempts (identifier, attempt_count, first_attempt_at) VALUES (?, 1, NOW())', 's', $identifier); return; }
    $n = (int)$row['attempt_count'] + 1;
    if ($n >= $max_attempts) db_execute('UPDATE login_attempts SET attempt_count = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE identifier = ?', 'iis', $n, $lockout_minutes, $identifier);
    else db_execute('UPDATE login_attempts SET attempt_count = ? WHERE identifier = ?', 'is', $n, $identifier);
}
function clear_login_attempts($conn, $identifier) {
    db_execute('DELETE FROM login_attempts WHERE identifier = ?', 's', $identifier);
}
}
/** Minutes left on a lock, or 0 when the identifier is not locked (expired locks are cleared). */
function login_locked_minutes($conn, string $identifier): int {
    $row = get_login_attempt($conn, $identifier);
    if (!$row || empty($row['locked_until'])) return 0;
    $left = strtotime($row['locked_until']) - time();
    if ($left <= 0) { clear_login_attempts($conn, $identifier); return 0; }
    return (int)ceil($left / 60);
}

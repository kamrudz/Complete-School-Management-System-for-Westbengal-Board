<?php
/** Shared helpers for notices, gallery, holidays and settings. */
require_once __DIR__ . "/db.php";

function app_valid_date($value) {
    if (!is_string($value) || $value === '') return false;
    $d = DateTime::createFromFormat('Y-m-d', $value);
    return $d && $d->format('Y-m-d') === $value;
}

function app_valid_holiday_type($type) {
    return in_array($type, ['public', 'school', 'exam', 'event'], true);
}

/**
 * A web address an admin typed: '' for blank, false for invalid. Only http(s) with a host — FILTER_VALIDATE_URL
 * alone lets "javascript://…%0Aalert(1)" through, which becomes XSS once it reaches an href.
 */
function app_safe_url_or_empty($value) {
    $value = trim((string)$value);
    if ($value === '') return '';
    if (!filter_var($value, FILTER_VALIDATE_URL)) return false;
    if (!in_array(strtolower((string)parse_url($value, PHP_URL_SCHEME)), ['http', 'https'], true)) return false;
    if ((string)parse_url($value, PHP_URL_HOST) === '') return false;
    return $value;
}

function app_safe_email_or_empty($value) {
    $value = trim((string)$value);
    if ($value === '') return '';
    return filter_var($value, FILTER_VALIDATE_EMAIL) ? $value : false;
}

function app_unlink_upload($baseDir, $filename) {
    $filename = basename((string)$filename);
    if ($filename === '') return true;
    $path = rtrim($baseDir, '/\\') . DIRECTORY_SEPARATOR . $filename;
    return !is_file($path) || @unlink($path);
}

/**
 * The website pages — notices, gallery, holidays, settings and the messages people send — share these.
 */

/** The admin pages of the website module, for the strip at the top of each. */
const WEB_PAGES = [
    'notices.php'         => ['Notices', 'fa-bullhorn'],
    'gallery.php'         => ['Gallery', 'fa-images'],
    'holidays.php'        => ['Holidays', 'fa-umbrella-beach'],
    'website_settings.php' => ['Website', 'fa-globe'],
    'contact_queries.php' => ['Messages', 'fa-envelope'],
];

/** What a holiday is, and the colour it wears. */
const HOLIDAY_TYPES = [
    'public' => ['Public holiday', 'fa-earth-asia', 'ok'],
    'school' => ['School holiday', 'fa-school', 'off'],
    'exam'   => ['Examination', 'fa-pen-to-square', 'warn'],
    'event'  => ['Event', 'fa-star', 'warn'],
];

/** A notice is only on the website when it is published and its day has come. */
const NOTICE_LIVE = "status = 'Published' AND publish_date IS NOT NULL AND publish_date <= CURDATE()";

/** How old a notice may be and still wear the NEW badge. */
const NOTICE_NEW_DAYS = 14;

/** Is this notice new enough to be worth a badge? Read off the date, never the row's position. */
function notice_is_new(?string $publish_date): bool
{
    if (!$publish_date || !app_valid_date($publish_date)) return false;
    $days = (int)((strtotime(date('Y-m-d')) - strtotime($publish_date)) / 86400);
    return $days >= 0 && $days <= NOTICE_NEW_DAYS;
}

/** Where a notice stands right now, for the chip beside it: [label, chip class]. */
function notice_state(array $n): array
{
    if (($n['status'] ?? '') !== 'Published') return ['Draft', 'off'];
    if (empty($n['publish_date'])) return ['No date', 'bad'];
    if ($n['publish_date'] > date('Y-m-d')) return ['Shows from ' . date('d M Y', strtotime($n['publish_date'])), 'warn'];
    return notice_is_new($n['publish_date']) ? ['New', 'ok'] : ['On the website', 'ok'];
}

/** The settings row the website reads. Created by the migration; made here too so a save is never lost. */
function website_settings(): array
{
    $row = db_get_row('SELECT * FROM website_settings WHERE id = 1');
    if (!$row) {
        db_execute('INSERT INTO website_settings (id) VALUES (1)');
        $row = db_get_row('SELECT * FROM website_settings WHERE id = 1') ?: [];
    }
    return $row;
}

/** The first and last day of a calendar year, as the holiday pages count them. */
function holiday_year_range(int $year): array
{
    return [sprintf('%04d-01-01', $year), sprintf('%04d-12-31', $year)];
}

/** The years that hold a holiday, newest first, with this year always offered. */
function holiday_years(): array
{
    $years = [(int)date('Y') => (int)date('Y')];
    // a vacation crossing new year belongs to both years, so look at where it ends as well as where it starts
    foreach (db_get_all("SELECT DISTINCT YEAR(COALESCE(start_date, holiday_date)) y FROM holidays WHERE COALESCE(start_date, holiday_date) IS NOT NULL
                         UNION SELECT DISTINCT YEAR(end_date) FROM holidays WHERE end_date IS NOT NULL") as $r) {
        $y = (int)$r['y'];
        if ($y) $years[$y] = $y;
    }
    krsort($years);
    return $years;
}

/** The holidays touching a year, in date order. A vacation counts in every year it reaches into. */
function holidays_of_year(int $year): array
{
    [$from, $to] = holiday_year_range($year);
    return db_get_all('SELECT * FROM holidays
        WHERE (holiday_date BETWEEN ? AND ?)
           OR (start_date IS NOT NULL AND end_date IS NOT NULL AND start_date <= ? AND end_date >= ?)
        ORDER BY COALESCE(start_date, holiday_date), id', 'ssss', $from, $to, $to, $from);
}

/** The first and last day a holiday row covers. */
function holiday_span(array $h): array
{
    if (!empty($h['start_date']) && !empty($h['end_date'])) return [$h['start_date'], $h['end_date']];
    $d = $h['holiday_date'] ?? null;
    return [$d, $d];
}

/**
 * Holidays already covering any day of a span — the same day must not be entered twice, because the
 * holiday list is what tells attendance which days are not working days.
 */
function holiday_overlaps(string $from, string $to, int $except_id = 0): array
{
    $sql = 'SELECT * FROM holidays
        WHERE (holiday_date BETWEEN ? AND ?)
           OR (start_date IS NOT NULL AND end_date IS NOT NULL AND start_date <= ? AND end_date >= ?)';
    $types = 'ssss';
    $params = [$from, $to, $to, $from];
    if ($except_id) { $sql .= ' AND id <> ?'; $types .= 'i'; $params[] = $except_id; }
    return db_get_all($sql . ' ORDER BY COALESCE(start_date, holiday_date)', $types, ...$params);
}

/** Days a holiday row covers, Sundays left out — a Sunday was never a working day to begin with. */
function holiday_working_days(array $h): int
{
    [$from, $to] = holiday_span($h);
    if (!$from || !$to) return 0;
    $n = 0;
    for ($d = new DateTime($from); $d <= new DateTime($to); $d->modify('+1 day')) if ((int)$d->format('N') !== 7) $n++;
    return $n;
}

/**
 * Capitals, the way a school register is written.
 *
 * Only free text a person types is listed here — names, places, addresses, schools, occupations and the
 * identifiers printed on a document. A value chosen from a list (caste, religion, gender, blood group,
 * relation, board, designation) is never touched: it must match that list exactly, letter case included.
 * Emails, web addresses and passwords are never touched either.
 */
const CAPS_FIELDS = [
    // who they are
    'student_name', 'name_as_per_aadhaar', 'staff_name', 'short_code',
    'father_name', 'mother_name', 'guardian_name', 'spouse_name',
    'father_occupation', 'mother_occupation', 'guardian_occupation', 'occupation',
    'father_qualification', 'mother_qualification', 'qualification',
    'sub_caste', 'mother_tongue', 'disability_type',
    // where they live
    'village', 'post_office', 'police_station', 'district', 'state',
    'present_address', 'permanent_address', 'address',
    // where they came from, and what they bring
    'previous_school', 'previous_class', 'previous_result', 'tc_no',
    'mp_roll_no', 'mp_registration_no',
    'bank_name', 'branch_name', 'account_number',
    'approval_number', 'national_code', 'state_govt_id', 'employee_id',
    'pan_number', 'ifsc_code', 'voter_number', 'father_voter_id', 'mother_voter_id',
];

/** One value in capitals. mb_strtoupper leaves Bengali alone — that script has no case. */
function app_caps_value($v): string
{
    return mb_strtoupper(trim((string)$v), 'UTF-8');
}

/** Every CAPS_FIELDS key present in the array, in capitals. Other keys are returned untouched. */
function app_caps(array $data): array
{
    foreach (CAPS_FIELDS as $f) {
        if (isset($data[$f]) && is_string($data[$f])) $data[$f] = app_caps_value($data[$f]);
    }
    return $data;
}

/** The CSS that shows capitals as they are typed. Pair it with app_caps() on the way in. */
function app_caps_css(): string
{
    $sel = [];
    foreach (CAPS_FIELDS as $f) $sel[] = 'input[name="' . $f . '"]';
    foreach (CAPS_FIELDS as $f) $sel[] = 'textarea[name="' . $f . '"]';
    return implode(', ', $sel) . ' { text-transform: uppercase; }';
}

/** One posted value: in capitals when the field is written in capitals, trimmed otherwise. */
function app_caps_value_if(string $field, string $value): string
{
    return in_array($field, CAPS_FIELDS, true) ? app_caps_value($value) : trim($value);
}

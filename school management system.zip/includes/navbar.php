<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

// navbar.php - Two-Tier Navigation
// Row 1 = fixed category buttons. Row 2 = links of the currently active category (switches on click).
$__current_page = basename($_SERVER['PHP_SELF']);

// Map every link to the category that owns it, so we can auto-open the right
// category tab when the page loads (e.g. landing on add_student.php opens "Students").
$__cat_pages = [
    'academic'     => ['sessions.php','classes.php','add_class.php','sections.php','add_section.php','subjects.php','add_subject.php','deleted_subjects.php','class_subjects.php','assign_third_language.php'],
    'students'     => ['students.php','add_student.php','edit_student.php','export_students.php','import_students.php','student_bulk_update.php','deleted_students.php','deactivated_students.php','tc_students.php','tc_student.php',
                       'promotion.php','promotion_preview.php','fail_students.php','pass_out_students.php','promotion_history.php',
                       'admission_applications.php','admission_merit.php','admission_centres.php','admission_settings.php','admission_finalize.php','admission_copy_print.php','houses.php'],
    'staff'        => ['staff.php','add_staff.php','teacher_passwords.php','user_access.php'],
    'routine'      => ['routine_settings.php','periods.php','routine_builder.php','routine_entry.php','class_routine.php','teacher_routine.php','daywise_class_routine.php','daywise_teacher_routine.php','provisional_routine.php','provisional_report.php','teacher_workload_report.php'],
    // the exam pages are shared by the two sections; ?section= decides which tab opens (see below)
    'exams_pup'    => ['exams.php','exam_subject_marks.php','marks_entry.php','bulk_marks_upload.php','bulk_grace_marks.php','student_marks_edit.php','tabulation_sheet.php','annual_result.php','report_card.php','student_merit_ranks.php','pass_fail_settings.php','formative_settings.php','hprc_formative_entry.php','hprc_learning_entry.php','hprc_behavior_entry.php','hprc_personality_entry.php'],
    'exams_sec'    => ['secondary_registration.php'],
    'hs'           => ['hs_exams.php','hs_exam_subject_marks.php','hs_registration.php','hs_subjects.php','hs_marks_entry.php','hs_bulk_marks_upload.php','hs_tabulation.php','hs_student_marks_edit.php','hs_report_card.php'],
    'exam_conduct' => ['exam_conduct_dashboard.php','exam_rooms.php','exam_room_config.php','exam_room_display.php','exam_shift_settings.php','exam_class_shift.php','exam_routine.php','exam_routine_print.php','exam_seating_settings.php','exam_seating.php','invigilator_rules.php','exam_duty_settings.php','exam_duty_roster.php'],
    'fees'         => ['fee_settings.php','student_discounts.php','fee_dues.php','generate_invoices.php','collect_fee.php','fee_class_collect.php','fee_receipts.php','fee_receipt.php','fee_ledger.php','fee_report.php'],
    'accounts'     => ['acc_settings.php','acc_entry.php','acc_vouchers.php','acc_voucher.php','acc_cashbook.php','acc_report.php','acc_bill.php'],
    'attendance'   => ['student_attendance.php','student_attendance_report.php','student_attendance_register.php','teacher_attendance.php','teacher_attendance_report.php'],
    'content'      => ['notices.php','add_notice.php','edit_notice.php','gallery.php','add_gallery.php','holidays.php','add_holiday.php','edit_holiday.php','website_settings.php','contact_queries.php'],
    'certificates' => ['certificate_list.php','certificate_add.php','idcard_home.php','idcard_bulk.php','admit_card_home.php','admit_card_bulk.php','admit_card_generate.php'],
    'reports'      => ['student_statistics.php','sibling_report.php','student_year_comparison.php'],
    'settings'     => ['school_settings.php','backup_now.php','view_logs.php','whatsapp_send.php'],
];
$__active_cat = '';
foreach ($__cat_pages as $__cat => $__pages) {
    if (in_array($__current_page, $__pages, true)) { $__active_cat = $__cat; break; }
}
// A shared exam page belongs to whichever section it was entered with.
if (($_GET['section'] ?? '') === 'sec' && $__active_cat === 'exams_pup') $__active_cat = 'exams_sec';
if (($_GET['section'] ?? '') === 'hs' && $__active_cat === 'exams_pup') $__active_cat = 'hs';   // the merit list of Class XI
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

.main-navbar-2tier {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    border-radius: 10px;
    overflow: visible !important;
    margin-bottom: 20px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}

/* ===== ROW 1 : CATEGORY BAR ===== */
.nav-row1 {
    background: linear-gradient(135deg, #0f1a2e 0%, #1a2d4a 100%);
    display: flex;
    align-items: center;
    padding: 0 15px;
    min-height: 46px;
    border-radius: 10px 10px 0 0;
    position: relative;
    z-index: 20;
}

.nav-toggle {
    display: none;
    background: none;
    border: none;
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 6px;
    flex-shrink: 0;
    margin-right: 8px;
}
.nav-toggle:hover { background: rgba(255,255,255,0.08); }

.nav-row1-links {
    list-style: none;
    display: flex;
    align-items: center;
    gap: 2px;
    flex-wrap: wrap;
    flex: 1;
}

.cat-btn {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #c5d8eb;
    background: none;
    border: none;
    padding: 7px 14px;
    text-decoration: none;
    font-size: 15px;
    font-weight: 600;
    font-family: inherit;
    border-radius: 6px;
    white-space: nowrap;
    cursor: pointer;
    letter-spacing: 0.3px;
    transition: all 0.2s ease;
}
.cat-btn:hover { background: rgba(255,255,255,0.1); color: #fff; }
.cat-btn i { font-size: 15px; color: #7a9bbd; transition: all 0.2s ease; }
.cat-btn:hover i { color: #fff; }

.cat-btn.active {
    background: rgba(31,91,138,0.4);
    color: #fff;
    border-bottom: 2px solid #6ea8fe;
}
.cat-btn.active i { color: #fff; }

.cat-btn .badge {
    background: #dc3545; color: #fff; font-size: 8px; font-weight: 700;
    padding: 1px 8px; border-radius: 20px; flex-shrink: 0;
}
.cat-btn .badge.green { background: #28a745; }
.cat-btn .badge.purple { background: #6f42c1; }
.cat-btn .badge.blue { background: #17a2b8; }
.cat-btn .badge.hs { background: #dc3545; }

/* ===== ROW 2 : ACTIVE CATEGORY'S LINKS ===== */
.nav-row2 {
    background: #f4f7fa;
    border-radius: 0 0 10px 10px;
    padding: 0 10px;
    display: none;
    border-top: 1px solid #e2e8f0;
}
.nav-row2.show { display: block; }

.cat-panel { display: none; padding: 6px 0; flex-wrap: wrap; align-items: center; gap: 4px; }
.cat-panel.show { display: flex; }

.cat-panel .group-label {
    font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px;
    color: #6c7a8a; font-weight: 700; padding: 0 6px 0 12px;
}
.cat-panel .group-sep { width: 1px; height: 18px; background: #d5dce3; margin: 0 6px; }

.cat-panel a {
    color: #1a2d4a; text-decoration: none; display: flex; align-items: center; gap: 6px;
    font-size: 13px; font-weight: 500; padding: 6px 12px; border-radius: 6px; white-space: nowrap;
    transition: all 0.2s ease;
}
.cat-panel a:hover { background: #e3edfa; color: #0056b3; }
.cat-panel a i { font-size: 12px; color: #4a6a8a; }
.cat-panel a:hover i { color: #0056b3; }
.cat-panel a.current { background: #dbeafe; color: #0056b3; font-weight: 700; }

/* ===== GLOBAL SEARCH ===== */
.nav-search-wrap { position: relative; margin-left: auto; flex: 1 1 150px; max-width: 240px; }
.nav-search-box { position: relative; display: flex; align-items: center; }
.nav-search-box > i.fa-search { position: absolute; left: 12px; color: rgba(255,255,255,0.5); font-size: 13px; pointer-events: none; }
.nav-search-box input {
    background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
    border-radius: 20px; color: #fff; padding: 7px 14px 7px 32px; font-size: 13px; width: 100%; box-sizing: border-box; outline: none;
}
.nav-search-box input::placeholder { color: rgba(255,255,255,0.45); }
.nav-search-box input:focus { background: rgba(255,255,255,0.15); border-color: rgba(255,255,255,0.3); }

.global-search-dropdown {
    display: none; position: absolute; top: calc(100% + 8px); right: 0; width: 340px; max-height: 420px;
    overflow-y: auto; background: #fff; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,0.2); z-index: 10000; padding: 6px 0;
}
.gs-group-label { font-size: 11px; font-weight: 700; text-transform: uppercase; color: #6ea8fe; padding: 8px 14px 4px 14px; letter-spacing: 0.5px; }
.gs-item { display: block; padding: 7px 14px; text-decoration: none; border-bottom: 1px solid #f2f2f2; }
.gs-item:hover { background: #f5f8fb; }
.gs-item-title { font-size: 13px; font-weight: 600; color: #1a3b55; }
.gs-item-sub { font-size: 11px; color: #8a97a5; margin-top: 1px; }
.gs-empty { padding: 16px; text-align: center; font-size: 13px; color: #8a97a5; }

/* ===== RESPONSIVE ===== */
@media (max-width: 1340px) {
    .cat-btn { padding: 7px 10px; }
}
@media (max-width: 1024px) {
    .cat-btn { padding: 6px 11px; font-size: 14px; }
}

@media (max-width: 768px) {
    .nav-toggle { display: block; }
    .nav-row1-links {
        display: none; width: 100%; flex-direction: column; align-items: stretch;
        max-height: 70vh; overflow-y: auto;
    }
    .nav-row1-links.open { display: flex; }
    .nav-row1 { flex-wrap: wrap; padding: 5px 10px; }
    .cat-btn { width: 100%; justify-content: flex-start; padding: 10px 14px; }
    .cat-btn > i:first-child { flex-shrink: 0; }
    .cat-btn .badge { margin-left: auto; }
    .nav-search-wrap { margin: 6px 0; width: 100%; max-width: none; flex: none; }
    .nav-search-box input { width: 100%; box-sizing: border-box; }
    .global-search-dropdown { width: 100%; left: 0; right: 0; }
    .cat-panel { flex-direction: column; align-items: stretch; }
    .cat-panel .group-sep { display: none; }
    .cat-panel .group-label { padding: 8px 0 2px 4px; }
    .cat-panel a { white-space: normal; }
}

@media (max-width: 420px) {
    .cat-btn { font-size: 14px; padding: 9px 12px; }
    .nav-row1 { padding: 4px 8px; }
}
</style>

<nav class="main-navbar-2tier" role="navigation">

    <!-- ===== ROW 1: CATEGORIES ===== -->
    <div class="nav-row1">
        <button class="nav-toggle" onclick="toggleMobileNav()" aria-label="Toggle Navigation">
            <i class="fas fa-bars"></i>
        </button>

        <ul class="nav-row1-links" id="navRow1Links" style="list-style:none;display:flex;">
            <li><a href="dashboard.php" class="cat-btn <?php echo $__current_page=='dashboard.php'?'active':''; ?>">
                <i class="fas fa-th-large"></i> Dashboard
            </a></li>

            <li><button type="button" class="cat-btn" data-cat="academic" onclick="showCategory('academic', this)">
                <i class="fas fa-school"></i> Academic
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="students" onclick="showCategory('students', this)">
                <i class="fas fa-user-graduate"></i> Students
                <span class="badge green"><?php $c=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM students WHERE student_status='Active'")); echo $c['total'] ?? 0; ?></span>
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="staff" onclick="showCategory('staff', this)">
                <i class="fas fa-user-tie"></i> Staff
                <span class="badge blue"><?php $c=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM staff")); echo $c['total'] ?? 0; ?></span>
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="routine" onclick="showCategory('routine', this)">
                <i class="fas fa-clock"></i> Routine
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="exams_pup" onclick="showCategory('exams_pup', this)">
                <i class="fas fa-child"></i> Primary &amp; Upper Primary
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="exams_sec" onclick="showCategory('exams_sec', this)">
                <i class="fas fa-pencil-alt"></i> Secondary (IX-X)
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="hs" onclick="showCategory('hs', this)">
                <i class="fas fa-university"></i> HS (XI-XII)
                <span class="badge hs"><?php $c=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM hs_exam")); echo $c['total'] ?? 0; ?></span>
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="exam_conduct" onclick="showCategory('exam_conduct', this)">
                <i class="fas fa-clipboard-check"></i> Exam Conduct
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="fees" onclick="showCategory('fees', this)">
                <i class="fas fa-money-bill-wave"></i> Fees
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="accounts" onclick="showCategory('accounts', this)">
                <i class="fas fa-university"></i> Accounts
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="attendance" onclick="showCategory('attendance', this)">
                <i class="fas fa-user-check"></i> Attendance
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="content" onclick="showCategory('content', this)">
                <i class="fas fa-bullhorn"></i> Website
                <?php $c=mysqli_query($conn,"SHOW TABLES LIKE 'contact_queries'"); if($c && mysqli_num_rows($c)>0){ $nq=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM contact_queries WHERE status='New'")); if(($nq['total'] ?? 0) > 0){ echo '<span class="badge">'.$nq['total'].'</span>'; } } ?>
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="certificates" onclick="showCategory('certificates', this)">
                <i class="fas fa-id-card"></i> Certificates
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="reports" onclick="showCategory('reports', this)">
                <i class="fas fa-chart-bar"></i> Reports
            </button></li>

            <li><button type="button" class="cat-btn" data-cat="settings" onclick="showCategory('settings', this)">
                <i class="fas fa-cogs"></i> Settings
            </button></li>

            <li class="nav-search-wrap">
                <div class="nav-search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="globalSearchInput" placeholder="Search Student, Staff, Subject, Exam, Notice..." autocomplete="off">
                    <div id="globalSearchResults" class="global-search-dropdown"></div>
                </div>
            </li>

            <li><a href="logout.php" class="cat-btn" style="color:#ef4444;">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a></li>
        </ul>
    </div>

    <!-- ===== ROW 2: ACTIVE CATEGORY'S LINKS ===== -->
    <div class="nav-row2" id="navRow2">

        <div class="cat-panel" data-cat="academic">
            <span class="group-label">Sessions</span>
            <a href="sessions.php" class="<?php echo $__current_page=='sessions.php'?'current':''; ?>"><i class="fas fa-calendar-alt"></i> Sessions</a>
            <div class="group-sep"></div>
            <span class="group-label">Classes & Sections</span>
            <a href="classes.php" class="<?php echo $__current_page=='classes.php'?'current':''; ?>"><i class="fas fa-chalkboard"></i> Classes</a>
            <a href="sections.php" class="<?php echo $__current_page=='sections.php'?'current':''; ?>"><i class="fas fa-layer-group"></i> Sections</a>
            <div class="group-sep"></div>
            <span class="group-label">Subjects</span>
            <a href="subjects.php" class="<?php echo $__current_page=='subjects.php'?'current':''; ?>"><i class="fas fa-book"></i> Subjects</a>
            <a href="class_subjects.php" class="<?php echo $__current_page=='class_subjects.php'?'current':''; ?>"><i class="fas fa-link"></i> Class Subjects</a>
            <div class="group-sep"></div>
            <span class="group-label">Third Language</span>
            <a href="assign_third_language.php" class="<?php echo $__current_page=='assign_third_language.php'?'current':''; ?>"><i class="fas fa-language"></i> 3rd Language Assign</a>
        </div>

        <div class="cat-panel" data-cat="students">
            <span class="group-label">Online Admission</span>
            <a href="admission_applications.php" class="<?php echo in_array($__current_page, ['admission_applications.php', 'admission_finalize.php', 'admission_copy_print.php'], true)?'current':''; ?>"><i class="fas fa-file-signature"></i> Applications</a>
            <a href="admission_merit.php" class="<?php echo $__current_page=='admission_merit.php'?'current':''; ?>"><i class="fas fa-ranking-star"></i> Merit List</a>
            <a href="admission_centres.php" class="<?php echo $__current_page=='admission_centres.php'?'current':''; ?>"><i class="fas fa-store"></i> Application Centres</a>
            <a href="admission_settings.php" class="<?php echo $__current_page=='admission_settings.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Admission Settings</a>
            <div class="group-sep"></div>
            <span class="group-label">Manage Students</span>
            <a href="students.php" class="<?php echo $__current_page=='students.php'?'current':''; ?>"><i class="fas fa-list"></i> All Students</a>
            <a href="import_students.php" class="<?php echo $__current_page=='import_students.php'?'current':''; ?>"><i class="fas fa-file-import"></i> Import Students</a>
            <a href="student_bulk_update.php" class="<?php echo $__current_page=='student_bulk_update.php'?'current':''; ?>"><i class="fas fa-edit"></i> Bulk Update</a>
            <div class="group-sep"></div>
            <span class="group-label">Status</span>
            <a href="deleted_students.php" class="<?php echo $__current_page=='deleted_students.php'?'current':''; ?>"><i class="fas fa-trash"></i> Deleted Students</a>
            <a href="deactivated_students.php" class="<?php echo $__current_page=='deactivated_students.php'?'current':''; ?>"><i class="fas fa-user-slash"></i> Deactivated Students</a>
            <a href="tc_students.php" class="<?php echo $__current_page=='tc_students.php'?'current':''; ?>"><i class="fas fa-file-export"></i> TC Students</a>
            <div class="group-sep"></div>
            <span class="group-label">Year end</span>
            <a href="promotion.php" class="<?php echo in_array($__current_page, ['promotion.php', 'promotion_preview.php'], true)?'current':''; ?>"><i class="fas fa-level-up-alt"></i> Promotion</a>
            <a href="fail_students.php" class="<?php echo $__current_page=='fail_students.php'?'current':''; ?>"><i class="fas fa-user-clock"></i> Not Promoted</a>
            <a href="pass_out_students.php" class="<?php echo $__current_page=='pass_out_students.php'?'current':''; ?>"><i class="fas fa-graduation-cap"></i> Pass Out</a>
            <a href="promotion_history.php" class="<?php echo $__current_page=='promotion_history.php'?'current':''; ?>"><i class="fas fa-history"></i> Promotion History</a>
            <a href="student_year_comparison.php" class="<?php echo $__current_page=='student_year_comparison.php'?'current':''; ?>"><i class="fas fa-arrows-left-right"></i> Year by Year</a>
            <div class="group-sep"></div>
            <span class="group-label">Houses</span>
            <a href="houses.php" class="<?php echo $__current_page=='houses.php'?'current':''; ?>"><i class="fas fa-shield-halved"></i> Houses</a>
        </div>

        <div class="cat-panel" data-cat="staff">
            <span class="group-label">Manage Staff</span>
            <a href="staff.php" class="<?php echo $__current_page=='staff.php'?'current':''; ?>"><i class="fas fa-list"></i> All Staff</a>
            <div class="group-sep"></div>
            <span class="group-label">Teacher Portal</span>
            <a href="teacher_passwords.php" class="<?php echo $__current_page=='teacher_passwords.php'?'current':''; ?>"><i class="fas fa-key"></i> Teacher Passwords</a>
            <a href="../teacher/login.php" target="_blank"><i class="fas fa-chalkboard-teacher"></i> Teacher Portal ↗</a>
            <div class="group-sep"></div>
            <span class="group-label">Portals & Access</span>
            <a href="user_access.php" class="<?php echo $__current_page=='user_access.php'?'current':''; ?>"><i class="fas fa-user-shield"></i> User Access</a>
        </div>

        <div class="cat-panel" data-cat="routine">
            <span class="group-label">Setup</span>
            <a href="routine_settings.php" class="<?php echo $__current_page=='routine_settings.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Routine Settings</a>
            <a href="periods.php" class="<?php echo $__current_page=='periods.php'?'current':''; ?>"><i class="fas fa-clock"></i> Periods</a>
            <a href="routine_builder.php" class="<?php echo in_array($__current_page, ['routine_builder.php', 'routine_entry.php'], true)?'current':''; ?>"><i class="fas fa-magic"></i> Routine Builder</a>
            <div class="group-sep"></div>
            <span class="group-label">View &amp; print</span>
            <a href="class_routine.php" class="<?php echo $__current_page=='class_routine.php'?'current':''; ?>"><i class="fas fa-table"></i> Class Routine</a>
            <a href="teacher_routine.php" class="<?php echo $__current_page=='teacher_routine.php'?'current':''; ?>"><i class="fas fa-chalkboard-teacher"></i> Teacher Routine</a>
            <a href="daywise_class_routine.php" class="<?php echo $__current_page=='daywise_class_routine.php'?'current':''; ?>"><i class="fas fa-calendar-day"></i> Day-wise Class</a>
            <a href="daywise_teacher_routine.php" class="<?php echo $__current_page=='daywise_teacher_routine.php'?'current':''; ?>"><i class="fas fa-user-clock"></i> Day-wise Teacher</a>
            <div class="group-sep"></div>
            <span class="group-label">Daily</span>
            <a href="provisional_routine.php" class="<?php echo $__current_page=='provisional_routine.php'?'current':''; ?>"><i class="fas fa-exchange-alt"></i> Substitution</a>
            <a href="provisional_report.php" class="<?php echo $__current_page=='provisional_report.php'?'current':''; ?>"><i class="fas fa-chart-bar"></i> Substitution Report</a>
            <a href="teacher_workload_report.php" class="<?php echo $__current_page=='teacher_workload_report.php'?'current':''; ?>"><i class="fas fa-balance-scale"></i> Teacher Workload</a>
        </div>

        <div class="cat-panel" data-cat="exams_pup">
            <span class="group-label">Setup</span>
            <a href="exams.php?section=pup" class="<?php echo $__current_page=='exams.php'?'current':''; ?>"><i class="fas fa-clipboard-list"></i> Exams</a>
            <a href="exam_subject_marks.php?section=pup" class="<?php echo $__current_page=='exam_subject_marks.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Full &amp; Pass Marks</a>
            <a href="pass_fail_settings.php?section=pup" class="<?php echo $__current_page=='pass_fail_settings.php'?'current':''; ?>"><i class="fas fa-cog"></i> Rules &amp; Grades</a>
            <div class="group-sep"></div>
            <span class="group-label">Marks</span>
            <a href="marks_entry.php?section=pup" class="<?php echo $__current_page=='marks_entry.php'?'current':''; ?>"><i class="fas fa-edit"></i> Marks Entry</a>
            <a href="bulk_marks_upload.php?section=pup" class="<?php echo $__current_page=='bulk_marks_upload.php'?'current':''; ?>"><i class="fas fa-file-excel"></i> Bulk Upload</a>
            <a href="bulk_grace_marks.php?section=pup" class="<?php echo $__current_page=='bulk_grace_marks.php'?'current':''; ?>"><i class="fas fa-hand-holding-heart"></i> Grace Marks</a>
            <div class="group-sep"></div>
            <span class="group-label">Result</span>
            <a href="tabulation_sheet.php?section=pup" class="<?php echo $__current_page=='tabulation_sheet.php'?'current':''; ?>"><i class="fas fa-table"></i> Tabulation Sheet</a>
            <a href="annual_result.php?section=pup" class="<?php echo $__current_page=='annual_result.php'?'current':''; ?>"><i class="fas fa-award"></i> Annual Result</a>
            <a href="report_card.php?section=pup" class="<?php echo $__current_page=='report_card.php'?'current':''; ?>"><i class="fas fa-id-card"></i> Report Card</a>
            <a href="student_merit_ranks.php?section=pup" class="<?php echo $__active_cat === 'exams_pup' && $__current_page=='student_merit_ranks.php'?'current':''; ?>"><i class="fas fa-trophy"></i> Merit List</a>
            <div class="group-sep"></div>
            <span class="group-label">HPRC</span>
            <a href="formative_settings.php" class="<?php echo $__current_page=='formative_settings.php'?'current':''; ?>"><i class="fas fa-cog"></i> Formative Full Marks Settings</a>
            <a href="hprc_formative_entry.php" class="<?php echo $__current_page=='hprc_formative_entry.php'?'current':''; ?>"><i class="fas fa-tasks"></i> Formative Entry</a>
            <a href="hprc_learning_entry.php" class="<?php echo $__current_page=='hprc_learning_entry.php'?'current':''; ?>"><i class="fas fa-brain"></i> Learning Entry</a>
            <a href="hprc_behavior_entry.php" class="<?php echo $__current_page=='hprc_behavior_entry.php'?'current':''; ?>"><i class="fas fa-heart"></i> Behavior Entry</a>
            <a href="hprc_personality_entry.php" class="<?php echo $__current_page=='hprc_personality_entry.php'?'current':''; ?>"><i class="fas fa-star"></i> Personality Entry</a>
        </div>
        <div class="cat-panel" data-cat="exams_sec">
            <span class="group-label">Setup</span>
            <a href="exams.php?section=sec" class="<?php echo $__current_page=='exams.php'?'current':''; ?>"><i class="fas fa-clipboard-list"></i> Exams</a>
            <a href="exam_subject_marks.php?section=sec" class="<?php echo $__current_page=='exam_subject_marks.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Full &amp; Pass Marks</a>
            <a href="pass_fail_settings.php?section=sec" class="<?php echo $__current_page=='pass_fail_settings.php'?'current':''; ?>"><i class="fas fa-cog"></i> Rules &amp; Grades</a>
            <div class="group-sep"></div>
            <span class="group-label">Marks</span>
            <a href="marks_entry.php?section=sec" class="<?php echo $__current_page=='marks_entry.php'?'current':''; ?>"><i class="fas fa-edit"></i> Marks Entry</a>
            <a href="bulk_marks_upload.php?section=sec" class="<?php echo $__current_page=='bulk_marks_upload.php'?'current':''; ?>"><i class="fas fa-file-excel"></i> Bulk Upload</a>
            <a href="bulk_grace_marks.php?section=sec" class="<?php echo $__current_page=='bulk_grace_marks.php'?'current':''; ?>"><i class="fas fa-hand-holding-heart"></i> Grace Marks</a>
            <div class="group-sep"></div>
            <span class="group-label">Result</span>
            <a href="tabulation_sheet.php?section=sec" class="<?php echo $__current_page=='tabulation_sheet.php'?'current':''; ?>"><i class="fas fa-table"></i> Tabulation Sheet</a>
            <a href="annual_result.php?section=sec" class="<?php echo $__current_page=='annual_result.php'?'current':''; ?>"><i class="fas fa-award"></i> Annual Result</a>
            <a href="report_card.php?section=sec" class="<?php echo $__current_page=='report_card.php'?'current':''; ?>"><i class="fas fa-id-card"></i> Report Card</a>
            <a href="student_merit_ranks.php?section=sec" class="<?php echo $__active_cat === 'exams_sec' && $__current_page=='student_merit_ranks.php'?'current':''; ?>"><i class="fas fa-trophy"></i> Merit List</a>
            <div class="group-sep"></div>
            <span class="group-label">Board</span>
            <a href="secondary_registration.php" class="<?php echo $__current_page=='secondary_registration.php'?'current':''; ?>"><i class="fas fa-id-badge"></i> Madhyamik Registration</a>
        </div>

        <div class="cat-panel" data-cat="hs">
            <span class="group-label">Setup</span>
            <a href="hs_exams.php" class="<?php echo $__current_page=='hs_exams.php'?'current':''; ?>"><i class="fas fa-list"></i> Semester Exams</a>
            <a href="hs_exam_subject_marks.php" class="<?php echo $__current_page=='hs_exam_subject_marks.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Full &amp; Pass Marks</a>
            <a href="hs_subjects.php" class="<?php echo $__current_page=='hs_subjects.php'?'current':''; ?>"><i class="fas fa-book-open"></i> Subject Combination</a>
            <div class="group-sep"></div>
            <span class="group-label">Marks</span>
            <a href="hs_marks_entry.php" class="<?php echo $__current_page=='hs_marks_entry.php'?'current':''; ?>"><i class="fas fa-pencil-alt"></i> HS Marks Entry</a>
            <a href="hs_bulk_marks_upload.php" class="<?php echo $__current_page=='hs_bulk_marks_upload.php'?'current':''; ?>"><i class="fas fa-file-excel"></i> HS Bulk Upload</a>
            <div class="group-sep"></div>
            <span class="group-label">Result</span>
            <a href="hs_tabulation.php" class="<?php echo $__current_page=='hs_tabulation.php'?'current':''; ?>"><i class="fas fa-table"></i> HS Tabulation</a>
            <a href="hs_report_card.php" class="<?php echo $__current_page=='hs_report_card.php'?'current':''; ?>"><i class="fas fa-id-card"></i> HS Mark Sheet</a>
            <a href="student_merit_ranks.php?section=hs" class="<?php echo $__active_cat === 'hs' && $__current_page=='student_merit_ranks.php'?'current':''; ?>"><i class="fas fa-trophy"></i> HS Merit List</a>
            <div class="group-sep"></div>
            <span class="group-label">Registration</span>
            <a href="hs_registration.php" class="<?php echo $__current_page=='hs_registration.php'?'current':''; ?>"><i class="fas fa-id-badge"></i> WBCHSE Registration</a>
        </div>

        <div class="cat-panel" data-cat="exam_conduct">
            <a href="exam_conduct_dashboard.php" class="<?php echo $__current_page=='exam_conduct_dashboard.php'?'current':''; ?>"><i class="fas fa-tachometer-alt"></i> Overview</a>
            <div class="group-sep"></div>
            <span class="group-label">Setup</span>
            <a href="exam_rooms.php" class="<?php echo $__current_page=='exam_rooms.php'?'current':''; ?>"><i class="fas fa-door-open"></i> Exam Rooms</a>
            <a href="exam_routine.php" class="<?php echo $__current_page=='exam_routine.php'?'current':''; ?>"><i class="fas fa-calendar-alt"></i> Exam Routine</a>
            <div class="group-sep"></div>
            <span class="group-label">Seating &amp; Duty</span>
            <a href="exam_seating.php" class="<?php echo $__current_page=='exam_seating.php'?'current':''; ?>"><i class="fas fa-chair"></i> Exam Seating</a>
            <a href="invigilator_rules.php" class="<?php echo $__current_page=='invigilator_rules.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Invigilator Rules</a>
            <a href="exam_duty_roster.php" class="<?php echo $__current_page=='exam_duty_roster.php'?'current':''; ?>"><i class="fas fa-user-clock"></i> Duty Roster</a>
            <a href="exam_duty_settings.php" class="<?php echo $__current_page=='exam_duty_settings.php'?'current':''; ?>"><i class="fas fa-user-shield"></i> Academic Council</a>
        </div>

        <div class="cat-panel" data-cat="fees">
            <span class="group-label">Collect</span>
            <a href="collect_fee.php" class="<?php echo $__current_page=='collect_fee.php'?'current':''; ?>"><i class="fas fa-cash-register"></i> Collect</a>
            <a href="fee_receipts.php" class="<?php echo in_array($__current_page, ['fee_receipts.php', 'fee_receipt.php', 'fee_ledger.php', 'fee_dues.php'], true)?'current':''; ?>"><i class="fas fa-receipt"></i> Receipts</a>
            <a href="fee_report.php" class="<?php echo $__current_page=='fee_report.php'?'current':''; ?>"><i class="fas fa-chart-bar"></i> Reports</a>
            <div class="group-sep"></div>
            <span class="group-label">Setup</span>
            <a href="fee_settings.php" class="<?php echo $__current_page=='fee_settings.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Fee Settings</a>
            <a href="student_discounts.php" class="<?php echo $__current_page=='student_discounts.php'?'current':''; ?>"><i class="fas fa-percent"></i> Discounts</a>
        </div>

        <div class="cat-panel" data-cat="accounts">
            <span class="group-label">Setup</span>
            <a href="acc_settings.php" class="<?php echo $__current_page=='acc_settings.php'?'current':''; ?>"><i class="fas fa-sliders-h"></i> Account Settings</a>
            <div class="group-sep"></div>
            <span class="group-label">Transactions</span>
            <a href="acc_entry.php" class="<?php echo $__current_page=='acc_entry.php'?'current':''; ?>"><i class="fas fa-pen"></i> New Entry</a>
            <a href="acc_vouchers.php" class="<?php echo in_array($__current_page, ['acc_vouchers.php', 'acc_voucher.php'], true)?'current':''; ?>"><i class="fas fa-file-invoice-dollar"></i> Vouchers</a>
            <div class="group-sep"></div>
            <span class="group-label">Books</span>
            <a href="acc_cashbook.php" class="<?php echo $__current_page=='acc_cashbook.php'?'current':''; ?>"><i class="fas fa-book"></i> Cash Book</a>
            <a href="acc_report.php" class="<?php echo $__current_page=='acc_report.php'?'current':''; ?>"><i class="fas fa-chart-line"></i> Account Reports</a>
        </div>

        <div class="cat-panel" data-cat="attendance">
            <span class="group-label">Student</span>
            <a href="student_attendance.php" class="<?php echo $__current_page=='student_attendance.php'?'current':''; ?>"><i class="fas fa-users"></i> Student Attendance</a>
            <a href="student_attendance_report.php" class="<?php echo $__current_page=='student_attendance_report.php'?'current':''; ?>"><i class="fas fa-file-alt"></i> Attendance Report</a>
            <a href="student_attendance_register.php" class="<?php echo $__current_page=='student_attendance_register.php'?'current':''; ?>"><i class="fas fa-clipboard-list"></i> Attendance Register</a>
            <div class="group-sep"></div>
            <span class="group-label">Teacher</span>
            <a href="teacher_attendance.php" class="<?php echo $__current_page=='teacher_attendance.php'?'current':''; ?>"><i class="fas fa-user-tie"></i> Teacher Attendance</a>
            <a href="teacher_attendance_report.php" class="<?php echo $__current_page=='teacher_attendance_report.php'?'current':''; ?>"><i class="fas fa-file-alt"></i> Teacher Report</a>
        </div>

        <div class="cat-panel" data-cat="content">
            <span class="group-label">Notices</span>
            <a href="notices.php" class="<?php echo $__current_page=='notices.php'?'current':''; ?>"><i class="fas fa-bullhorn"></i> Notices</a>
            <div class="group-sep"></div>
            <span class="group-label">Gallery &amp; Holidays</span>
            <a href="gallery.php" class="<?php echo $__current_page=='gallery.php'?'current':''; ?>"><i class="fas fa-images"></i> Gallery</a>
            <a href="holidays.php" class="<?php echo $__current_page=='holidays.php'?'current':''; ?>"><i class="fas fa-umbrella-beach"></i> Holidays</a>
            <div class="group-sep"></div>
            <span class="group-label">Website</span>
            <a href="website_settings.php" class="<?php echo $__current_page=='website_settings.php'?'current':''; ?>"><i class="fas fa-globe"></i> Website Settings</a>
            <a href="contact_queries.php" class="<?php echo $__current_page=='contact_queries.php'?'current':''; ?>"><i class="fas fa-envelope"></i> Contact Queries</a>
            <a href="../index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Live Site ↗</a>
        </div>

        <div class="cat-panel" data-cat="certificates">
            <span class="group-label">Certificates</span>
            <a href="certificate_list.php" class="<?php echo in_array($__current_page, ['certificate_list.php', 'certificate_add.php'], true)?'current':''; ?>"><i class="fas fa-certificate"></i> Certificate List</a>
            <div class="group-sep"></div>
            <span class="group-label">ID Cards</span>
            <a href="idcard_home.php" class="<?php echo $__current_page=='idcard_home.php'?'current':''; ?>"><i class="fas fa-id-card"></i> ID Card Home</a>
            <a href="idcard_bulk.php" class="<?php echo $__current_page=='idcard_bulk.php'?'current':''; ?>"><i class="fas fa-layer-group"></i> Bulk ID Cards</a>
            <div class="group-sep"></div>
            <span class="group-label">Admit Cards</span>
            <a href="admit_card_home.php" class="<?php echo $__current_page=='admit_card_home.php'?'current':''; ?>"><i class="fas fa-portrait"></i> Admit Card Home</a>
            <a href="admit_card_bulk.php" class="<?php echo $__current_page=='admit_card_bulk.php'?'current':''; ?>"><i class="fas fa-layer-group"></i> Bulk Admit Cards</a>
        </div>

        <div class="cat-panel" data-cat="reports">
            <span class="group-label">Student Reports</span>
            <a href="student_statistics.php" class="<?php echo $__current_page=='student_statistics.php'?'current':''; ?>"><i class="fas fa-chart-pie"></i> Student Statistics</a>
            <a href="sibling_report.php" class="<?php echo $__current_page=='sibling_report.php'?'current':''; ?>"><i class="fas fa-people-roof"></i> Brothers &amp; Sisters</a>
            <a href="student_year_comparison.php" class="<?php echo $__current_page=='student_year_comparison.php'?'current':''; ?>"><i class="fas fa-arrows-left-right"></i> Year by Year</a>
        </div>

        <div class="cat-panel" data-cat="settings">
            <span class="group-label">School</span>
            <a href="school_settings.php" class="<?php echo $__current_page=='school_settings.php'?'current':''; ?>"><i class="fas fa-school"></i> School Settings</a>
            <div class="group-sep"></div>
            <span class="group-label">Communication</span>
            <a href="whatsapp_send.php" class="<?php echo $__current_page=='whatsapp_send.php'?'current':''; ?>"><i class="fab fa-whatsapp"></i> WhatsApp Send</a>
            <div class="group-sep"></div>
            <span class="group-label">System</span>
            <a href="backup_now.php" class="<?php echo $__current_page=='backup_now.php'?'current':''; ?>"><i class="fas fa-database"></i> Backup</a>
            <a href="view_logs.php" class="<?php echo $__current_page=='view_logs.php'?'current':''; ?>"><i class="fas fa-history"></i> Activity Logs</a>
            <div class="group-sep"></div>
            <span class="group-label">Account</span>
            <a href="dashboard.php?page=change_password"><i class="fas fa-key"></i> Change Password</a>
        </div>

    </div>
</nav>

<script>
// ===== SWITCH ACTIVE CATEGORY (Row 1 click -> shows matching Row 2 panel) =====
function showCategory(cat, btn) {
    document.querySelectorAll('.cat-btn[data-cat]').forEach(function(b){ b.classList.remove('active'); });
    if (btn) btn.classList.add('active');

    document.querySelectorAll('.cat-panel').forEach(function(p){ p.classList.remove('show'); });
    var panel = document.querySelector('.cat-panel[data-cat="' + cat + '"]');
    if (panel) panel.classList.add('show');

    document.getElementById('navRow2').classList.add('show');

    if (window.innerWidth <= 768) {
        document.getElementById('navRow1Links').classList.remove('open');
    }
}

function toggleMobileNav() {
    document.getElementById('navRow1Links').classList.toggle('open');
}

// ===== AUTO-OPEN THE CATEGORY THAT OWNS THE CURRENT PAGE =====
document.addEventListener('DOMContentLoaded', function () {
    var activeCat = <?php echo json_encode($__active_cat); ?>;
    if (activeCat) {
        var btn = document.querySelector('.cat-btn[data-cat="' + activeCat + '"]');
        showCategory(activeCat, btn);
    }
});

document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') document.getElementById('navRow1Links').classList.remove('open');
});
</script>

<script>
(function(){
    const input = document.getElementById('globalSearchInput');
    const dropdown = document.getElementById('globalSearchResults');
    let debounceTimer = null;
    let activeController = null;

    function renderResults(groups) {
        if(!groups || groups.length === 0) {
            dropdown.innerHTML = '<div class="gs-empty">কোনো ফলাফল পাওয়া যায়নি</div>';
            dropdown.style.display = 'block';
            return;
        }
        let html = '';
        groups.forEach(group => {
            html += `<div class="gs-group-label"><i class="fas ${group.icon}"></i> ${group.category}</div>`;
            group.items.forEach(item => {
                html += `<a href="${item.url}" class="gs-item">
                    <div class="gs-item-title">${escapeHtml(item.title)}</div>
                    <div class="gs-item-sub">${escapeHtml(item.subtitle)}</div>
                </a>`;
            });
        });
        dropdown.innerHTML = html;
        dropdown.style.display = 'block';
    }

    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str ?? '';
        return div.innerHTML;
    }

    input.addEventListener('input', function(){
        const q = this.value.trim();
        clearTimeout(debounceTimer);
        if(q.length < 2) {
            dropdown.style.display = 'none';
            dropdown.innerHTML = '';
            return;
        }
        debounceTimer = setTimeout(() => {
            if(activeController) activeController.abort();
            activeController = new AbortController();
            fetch('global_search.php?q=' + encodeURIComponent(q), { signal: activeController.signal })
                .then(res => res.json())
                .then(data => renderResults(data.results))
                .catch(err => { if(err.name !== 'AbortError') console.error(err); });
        }, 250);
    });

    document.addEventListener('click', function(e){
        if(!e.target.closest('.nav-search-wrap')) {
            dropdown.style.display = 'none';
        }
    });
    input.addEventListener('focus', function(){
        if(dropdown.innerHTML.trim() !== '') dropdown.style.display = 'block';
    });
})();
</script>
<?php
// Kept for older includes: the result rules now live in result_helper.php (get_pass_fail_settings / get_student_result are defined there).
require_once __DIR__ . '/result_helper.php';

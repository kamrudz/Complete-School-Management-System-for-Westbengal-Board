<?php
/**
 * Student photo processing (GD only).
 *
 * Every photo that reaches uploads/students/ goes through here: it is rotated
 * upright (phone EXIF orientation), resized so the longest side is $max_side,
 * flattened onto white and re-encoded as JPEG until it is under $max_bytes.
 * Defaults are the school's rule (2026-09-16): 10 KB, 320 px.
 *
 *   $r = process_student_photo($_FILES['photo'], "../uploads/students/");        // an upload
 *   $r = process_student_photo_path($tmp_path, "../uploads/students/");         // a file already on disk
 *   $r = ['ok' => bool, 'filename' => string|null, 'error' => string|null, 'bytes' => int|null]
 */

/** Wrapper for a $_FILES entry: checks the upload itself, then delegates to process_student_photo_path(). */
function process_student_photo($file, $upload_dir, $max_bytes = 10240, $max_side = 320, $prefix = 'stu_') {
    if (empty($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'filename' => null, 'error' => null, 'bytes' => null];   // nothing chosen — not an error
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'filename' => null, 'error' => 'Photo upload failed (error code ' . $file['error'] . ').', 'bytes' => null];
    }
    if ($file['size'] > 8 * 1024 * 1024) {
        return ['ok' => false, 'filename' => null, 'error' => 'Photo is too large (max 8MB before compression).', 'bytes' => null];
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'filename' => null, 'error' => 'Invalid upload.', 'bytes' => null];
    }
    return process_student_photo_path($file['tmp_name'], $upload_dir, $max_bytes, $max_side, $prefix);
}

/** Core: read $path, rotate, resize, compress, save as stu_<random>.jpg in $upload_dir. */
function process_student_photo_path($path, $upload_dir, $max_bytes = 10240, $max_side = 320, $prefix = 'stu_') {
    $fail = fn($m) => ['ok' => false, 'filename' => null, 'error' => $m, 'bytes' => null];
    $info = @getimagesize($path);
    if ($info === false) return $fail('The file is not a valid image.');
    $type = $info[2];
    switch ($type) {
        case IMAGETYPE_JPEG: $src = @imagecreatefromjpeg($path); break;
        case IMAGETYPE_PNG:  $src = @imagecreatefrompng($path); break;
        case IMAGETYPE_GIF:  $src = @imagecreatefromgif($path); break;
        case IMAGETYPE_WEBP: $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($path) : false; break;
        default: $src = false;
    }
    if (!$src) return $fail('Unsupported image format. Please use a JPG, PNG, GIF or WEBP file.');

    // ---- upright: honour the EXIF orientation phones write ----
    if ($type === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $o = (int)(@exif_read_data($path)['Orientation'] ?? 1);
        if (in_array($o, [2, 4, 5, 7], true)) imageflip($src, IMG_FLIP_HORIZONTAL);
        $deg = [3 => 180, 4 => 180, 5 => -90, 6 => -90, 7 => 90, 8 => 90][$o] ?? 0;
        if ($deg) { $rot = imagerotate($src, $deg, 0); if ($rot) { imagedestroy($src); $src = $rot; } }
    }
    $w = imagesx($src); $h = imagesy($src);

    // ---- resize (never upscale), flatten alpha onto white ----
    $ratio = min($max_side / $w, $max_side / $h, 1);
    $nw = max(1, (int)round($w * $ratio)); $nh = max(1, (int)round($h * $ratio));
    $img = imagecreatetruecolor($nw, $nh);
    imagefill($img, 0, 0, imagecolorallocate($img, 255, 255, 255));
    imagecopyresampled($img, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($src);

    // ---- compress until under $max_bytes: quality first, then size ----
    $tmp = tempnam(sys_get_temp_dir(), 'stuphoto_');
    $quality = 82; $bytes = null;
    for ($attempt = 0; $attempt < 14; $attempt++) {
        imagejpeg($img, $tmp, $quality);
        $bytes = filesize($tmp);
        if ($bytes <= $max_bytes) break;
        if ($quality > 35) { $quality -= 8; continue; }
        $nw = max(40, (int)round($nw * 0.85)); $nh = max(40, (int)round($nh * 0.85));
        $small = imagecreatetruecolor($nw, $nh);
        imagefill($small, 0, 0, imagecolorallocate($small, 255, 255, 255));
        imagecopyresampled($small, $img, 0, 0, 0, 0, $nw, $nh, imagesx($img), imagesy($img));
        imagedestroy($img); $img = $small; $quality = 65;
    }
    imagedestroy($img);

    if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);
    $filename = $prefix . bin2hex(random_bytes(8)) . '.jpg';
    $dest = rtrim($upload_dir, '/\\') . '/' . $filename;
    if (!@rename($tmp, $dest)) {
        if (!@copy($tmp, $dest)) { @unlink($tmp); return $fail('Could not save the compressed photo to disk.'); }
        @unlink($tmp);
    }
    return ['ok' => true, 'filename' => $filename, 'error' => null, 'bytes' => $bytes];
}

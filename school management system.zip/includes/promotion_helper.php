<?php
/**
 * Promotion to the next session: who can go up, into which class, and how the new sections and rolls are
 * formed. A class goes up once per session (promotion_batches), from its stored merit list, into the next
 * class; everyone who does not go up is handled on the Not Promoted page.
 */

/** Results that go up to the next class. */
const PROMOTION_PASSED = ['PASS', 'PUC', 'COMPARTMENT'];

/** How the new section and roll are given: key => [label, what it does]. */
const PROMOTION_METHODS = [
    'keep_existing'      => ['Same Section & Roll', 'Every student goes to the section of the same name in the new class and keeps the same roll number.'],
    'merit_distribution' => ['By Merit — Boys / Girls', 'Boys in merit order go round the boys\' sections one by one: the 1st boy gets roll 1 of the first section, the 2nd boy roll 1 of the next, and so on, round again for roll 2. Girls go round the girls\' sections the same way.'],
    'section_steps'      => ['Section by Section', 'One section at a time: choose All, Boys or Girls, the order, a section, its first roll and a gap. Of the students not placed yet, the 1st goes to that section and then every one after the gap (2 gap: the 1st, 4th, 7th …), numbered on from the first roll. The next section takes from those left, until everyone has a section.'],
    'manual'             => ['Manual', 'You give every student\'s new section and roll yourself, one by one, on the next page. Choosing a section fills in its next free roll, which you can change; a roll given twice or already used in the new session is marked in red.'],
];

/** Section by Section: who a step takes, the order it takes them in, and how many it skips between two. */
const PROMOTION_STEP_WHO    = ['all' => 'All', 'boys' => 'Boys', 'girls' => 'Girls'];
const PROMOTION_STEP_ORDERS = ['merit' => 'Merit', 'name' => 'Name (A–Z)', 'roll' => 'Roll (this year)', 'pen' => 'PEN ID', 'bsid' => 'Banglar Shiksha ID'];
const PROMOTION_STEP_GAPS   = [0 => 'Continue', 1 => '1 gap', 2 => '2 gap', 3 => '3 gap', 4 => '4 gap'];

function promotion_method_label(string $method): string {
    return PROMOTION_METHODS[$method][0] ?? ucwords(str_replace('_', ' ', $method));
}

function promotion_get_merit_count($conn, int $session_id, int $class_id): int {
    if ($session_id <= 0 || $class_id <= 0) return 0;
    return (int)(db_get_row('SELECT COUNT(*) AS c FROM student_merit_ranks WHERE academic_session_id = ? AND class_id = ?', 'ii', $session_id, $class_id)['c'] ?? 0);
}

function promotion_batch_exists($conn, int $session_id, int $class_id): bool {
    if ($session_id <= 0 || $class_id <= 0) return false;
    return (bool)db_get_row('SELECT id FROM promotion_batches WHERE from_session_id = ? AND from_class_id = ? LIMIT 1', 'ii', $session_id, $class_id);
}

function promotion_get_session_name($conn, int $session_id): string {
    $row = db_get_row('SELECT session_name FROM academic_sessions WHERE id = ? LIMIT 1', 'i', $session_id);
    return (string)($row['session_name'] ?? '');
}

/** The sections of a class in a session, in name order: [['id', 'section_name'], ...]. */
function promotion_get_sections($conn, int $class_id, int $session_id): array {
    if ($class_id <= 0 || $session_id <= 0) return [];
    $rows = db_get_all('SELECT id, section_name FROM sections WHERE class_id = ? AND session_id = ?', 'ii', $class_id, $session_id);
    usort($rows, fn($a, $b) => strnatcasecmp($a['section_name'], $b['section_name']));
    return $rows;
}

/**
 * The class a class goes up to, or null when there is none: after the last class, and from Secondary to
 * Higher Secondary — Class X leaves through Pass Out and comes into XI through Admission.
 */
function promotion_next_class(int $class_id): ?int {
    $rows = array_values(class_rows());
    foreach ($rows as $i => $c) {
        if ($c['id'] !== $class_id) continue;
        $next = $rows[$i + 1] ?? null;
        if (!$next || ($c['stage'] === 'secondary' && $next['stage'] === 'higher_secondary')) return null;
        return $next['id'];
    }
    return null;
}

/** Why a class does not go up by promotion ('' when it does). */
function promotion_no_next_reason(int $class_id): string {
    if (promotion_next_class($class_id) !== null) return '';
    $rows = array_values(class_rows());
    $i = array_search($class_id, array_column($rows, 'id'), true);
    if ($i === false) return 'Choose the class again.';
    $name = $rows[$i]['name'];
    return isset($rows[$i + 1])
        ? "Class $name does not go up by promotion: its students leave through Pass Out, and those who stay on join Class {$rows[$i + 1]['name']} through Admission."
        : "Class $name is the last class: its students leave through Pass Out.";
}

/** True when session $to comes after session $from (by name: 2027 after 2026, 2026-27 after 2025-26). */
function promotion_session_later(int $from, int $to): bool {
    $a = promotion_get_session_name(null, $from); $b = promotion_get_session_name(null, $to);
    return $a !== '' && $b !== '' && strnatcmp($b, $a) > 0;
}

/** The nearest session after $session_id, or null when there is none yet. */
function promotion_next_session(int $session_id): ?int {
    $from = promotion_get_session_name(null, $session_id);
    if ($from === '') return null;
    $later = array_filter(db_get_all('SELECT id, session_name FROM academic_sessions'), fn($r) => strnatcmp($r['session_name'], $from) > 0);
    usort($later, fn($a, $b) => strnatcmp($a['session_name'], $b['session_name']));
    return $later ? (int)$later[0]['id'] : null;
}

/** Best first: merit rank, then %, then name, then UID — so equal ranks always come out in the same order. */
function promotion_sort_merit(array &$list): void {
    uasort($list, fn($a, $b) => (($a['rank'] ?? PHP_INT_MAX) <=> ($b['rank'] ?? PHP_INT_MAX))
        ?: (($b['pct'] ?? -1) <=> ($a['pct'] ?? -1))
        ?: strcasecmp($a['name'], $b['name'])
        ?: strcmp($a['uid'], $b['uid']));
}

/**
 * Everyone of a class in a session who is still there (Current and Active), with their stored merit row.
 * ['eligible' => [uid => student], 'left' => [uid => student]], both best first; 'left' holds FAIL, ABSENT
 * and students with no merit row (status ''). student: uid, name, gender, section_id, section, roll, rank, pct,
 * status, previous_school, father, pen, bsid.
 */
function promotion_students(int $session_id, int $class_id): array {
    $out = ['eligible' => [], 'left' => []];
    $rows = db_get_all("SELECT s.id, s.student_name, s.gender, s.pen_id, s.banglarshiksha_id, g.father_name, h.section_id, sec.section_name, h.roll_no, h.previous_school, r.merit_rank, r.percentage, r.result_status
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id AND s.student_status = 'Active'
        LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN student_merit_ranks r ON r.student_id = h.student_id AND r.academic_session_id = h.session_id AND r.class_id = h.class_id
        WHERE h.session_id = ? AND h.class_id = ? AND h.academic_status = 'Current'", 'ii', $session_id, $class_id);
    foreach ($rows as $r) {
        $status = (string)($r['result_status'] ?? '');
        $out[in_array($status, PROMOTION_PASSED, true) ? 'eligible' : 'left'][$r['id']] = [
            'uid' => $r['id'], 'name' => $r['student_name'], 'gender' => (string)$r['gender'],
            'section_id' => $r['section_id'] === null ? null : (int)$r['section_id'], 'section' => (string)$r['section_name'], 'roll' => $r['roll_no'],
            'rank' => $status === '' || $status === 'ABSENT' ? null : (int)$r['merit_rank'],
            'pct' => $r['percentage'] === null ? null : (float)$r['percentage'], 'status' => $status, 'previous_school' => $r['previous_school'],
            'father' => (string)$r['father_name'], 'pen' => trim((string)$r['pen_id']), 'bsid' => trim((string)$r['banglarshiksha_id']),
        ];
    }
    promotion_sort_merit($out['eligible']);
    promotion_sort_merit($out['left']);
    return $out;
}

/**
 * One step of Section by Section from a request, or null when it is not complete: who, order, section (an id of
 * $sections), start (the first roll; null = after the highest used there) and gap (how many to skip between two).
 */
function promotion_step_clean($s, array $sections): ?array {
    if (!is_array($s)) return null;
    $v = fn(string $k) => is_scalar($s[$k] ?? null) ? trim((string)$s[$k]) : '';
    [$who, $order, $sec, $start, $gap] = [$v('who'), $v('order'), (int)$v('section'), $v('start'), $v('gap')];
    if (!isset(PROMOTION_STEP_WHO[$who], PROMOTION_STEP_ORDERS[$order], $sections[$sec]) || !ctype_digit($gap) || !isset(PROMOTION_STEP_GAPS[(int)$gap])) return null;
    return ['who' => $who, 'order' => $order, 'section' => $sec, 'start' => ctype_digit($start) && strlen($start) <= 6 && (int)$start > 0 ? (int)$start : null, 'gap' => (int)$gap];
}

/** The complete steps of a request, in order. */
function promotion_steps_clean($raw, array $sections): array {
    return array_values(array_filter(array_map(fn($s) => promotion_step_clean($s, $sections), is_array($raw) ? $raw : [])));
}

/**
 * Manual: the section and roll given to each student on the preview page, from its JSON list [[uid, section id,
 * roll], ...], as uid => [section id, roll]. A malformed row is left out, so that student just has no section yet.
 */
function promotion_manual_clean($rows): array {
    $out = [];
    foreach (is_array($rows) ? $rows : [] as $r) {
        $r = is_array($r) ? array_values($r) : [];
        if (count($r) !== 3 || !is_scalar($r[0]) || !is_scalar($r[1]) || !is_scalar($r[2])) continue;
        $uid = student_uid_clean($r[0]);
        if ($uid !== '') $out[$uid] = [(int)$r[1], trim((string)$r[2])];
    }
    return $out;
}

/** True when a step for $who ('all' | 'boys' | 'girls') takes a student of $gender. */
function promotion_step_takes(string $who, string $gender): bool {
    return $who === 'all' || ($who === 'boys' && $gender === 'Male') || ($who === 'girls' && $gender === 'Female');
}

/**
 * Students in the order a step of Section by Section takes them: $order, then merit, so a tie (the same name, no
 * PEN) always comes out the same. Roll is this year's section and roll; a missing section, roll or ID goes last.
 */
function promotion_sort_step(array &$list, string $order): void {
    promotion_sort_merit($list);
    if ($order === 'merit') return;
    $merit = array_flip(array_map('strval', array_keys($list)));
    $last = fn(string $a, string $b) => ($a === '') <=> ($b === '');
    $cmp = match ($order) {
        'name' => fn($a, $b) => strcasecmp($a['name'], $b['name']),
        'roll' => fn($a, $b) => $last($a['section'], $b['section']) ?: strnatcasecmp($a['section'], $b['section'])
                                 ?: $last((string)$a['roll'], (string)$b['roll']) ?: strnatcmp((string)$a['roll'], (string)$b['roll']),
        'pen'  => fn($a, $b) => $last($a['pen'], $b['pen']) ?: strnatcmp($a['pen'], $b['pen']),
        'bsid' => fn($a, $b) => $last($a['bsid'], $b['bsid']) ?: strnatcmp($a['bsid'], $b['bsid']),
    };
    uasort($list, fn($a, $b) => $cmp($a, $b) ?: ($merit[(string)$a['uid']] <=> $merit[(string)$b['uid']]));
}

/** The rolls already used in each section of a class in a session: section id => [roll => true]. */
function promotion_taken_rolls(int $session_id, int $class_id): array {
    $taken = [];
    foreach (db_get_all('SELECT section_id, roll_no FROM student_academic_history WHERE session_id = ? AND class_id = ? AND roll_no IS NOT NULL', 'ii', $session_id, $class_id) as $r) {
        $taken[(int)$r['section_id']][(string)$r['roll_no']] = true;
    }
    return $taken;
}

/**
 * Who a section letter of a class held in a session: 'A' => 'Boys' | 'Girls' | 'Co-ed'. Everyone who sat in
 * the class that year counts, so it still works after that class has itself gone up.
 */
function promotion_section_genders(int $class_id, int $session_id): array {
    $out = [];
    foreach (db_get_all("SELECT sec.section_name, SUM(s.gender = 'Male') AS boys, SUM(s.gender = 'Female') AS girls
                         FROM student_academic_history h JOIN students s ON s.id = h.student_id JOIN sections sec ON sec.id = h.section_id
                         WHERE h.session_id = ? AND h.class_id = ? GROUP BY sec.section_name", 'ii', $session_id, $class_id) as $r) {
        $b = (int)$r['boys']; $g = (int)$r['girls'];
        if ($b || $g) $out[strtoupper(trim($r['section_name']))] = $b && $g ? 'Co-ed' : ($b ? 'Boys' : 'Girls');
    }
    return $out;
}

/**
 * A class's promotion exactly as it would be saved — worked out for the preview, and again for the save:
 *   students  uid => the student (promotion_students) with 'order' (1st, 2nd … boy or girl; By Merit only),
 *             'step' (the step that placed them; Section by Section only), 'new_section' (id | null),
 *             'new_roll' (string | null) and 'note' (why the roll is not the usual one, or why there is no section)
 *   left      FAIL, ABSENT and students not on the merit list: they wait on Not Promoted
 *   already   passed, but already placed in the new session: they are not moved again
 *   sections  id => name of the new class's sections, in name order
 *   steps     the complete steps of $steps (Section by Section only), for the page to show and pass on
 *   unplaced  students without a section; nothing is saved until this is 0
 *   key       a fingerprint of the result: the save refuses anything other than what the preview showed
 * Same Section & Roll: the section of the same name and the same roll. A roll already used there in the new
 * session, or no roll at all, becomes the next roll after the highest of that section.
 * By Merit: boys in merit order go round $boys (A → C → E → A …) and girls round $girls, both taken in name
 * order; every section numbers its students in merit order, after any roll already used there.
 * Section by Section: each step, in turn, lines up the students it takes (all, boys or girls) who have no section
 * yet, in its order, and gives its section the 1st and then every one after the gap (2 gap: the 1st, 4th, 7th …);
 * the ones in between wait for a later step. Rolls count up from the step's first roll, passing over any already
 * used in that section (no first roll: after the highest used there).
 * Manual: the section and roll chosen for each student ($manual: uid => [section id, roll]). No section, a roll
 * that is not 1–9999, one already used in the new session or one given to two students leaves that student
 * without a section, with the reason in 'note'. As the choices come from the admin, the key is the page they
 * were made on — the students, the new sections and the rolls already used — not the choices.
 */
function promotion_plan(int $from_session, int $from_class, int $to_session, int $to_class, string $method, array $boys = [], array $girls = [], array $steps = [], array $manual = []): array {
    $pool = promotion_students($from_session, $from_class);
    $students = $pool['eligible'];
    $already = [];
    if ($students) {
        $uids = array_keys($students);
        $in = implode(',', array_fill(0, count($uids), '?'));
        foreach (db_get_all("SELECT student_id FROM student_academic_history WHERE session_id = ? AND student_id IN ($in)", 'i' . str_repeat('s', count($uids)), $to_session, ...$uids) as $r) {
            $already[$r['student_id']] = $students[$r['student_id']];
            unset($students[$r['student_id']]);
        }
    }
    $sections = array_column(promotion_get_sections(null, $to_class, $to_session), 'section_name', 'id');
    $used = promotion_taken_rolls($to_session, $to_class);
    $after = function (int $sec) use (&$used): string {   // the next roll after the highest of a section, and it is taken
        $roll = (string)(empty($used[$sec]) ? 1 : max(array_map('intval', array_keys($used[$sec]))) + 1);
        $used[$sec][$roll] = true;
        return $roll;
    };
    foreach ($students as &$st) $st += ['order' => null, 'step' => null, 'new_section' => null, 'new_roll' => null, 'note' => ''];
    unset($st);
    $steps = $method === 'section_steps' ? promotion_steps_clean($steps, $sections) : [];

    if ($method === 'keep_existing') {
        $by_name = [];
        foreach ($sections as $id => $name) $by_name[strtoupper(trim($name))] = $id;
        $later = [];
        foreach ($students as $uid => &$st) {
            $sec = $by_name[strtoupper(trim($st['section']))] ?? null;
            if ($sec === null) { $st['note'] = $st['section'] === '' ? 'has no section this year' : "the new class has no section {$st['section']}"; continue; }
            $st['new_section'] = $sec;
            $roll = trim((string)$st['roll']);
            if ($roll !== '' && empty($used[$sec][$roll])) { $st['new_roll'] = $roll; $used[$sec][$roll] = true; }
            else $later[] = $uid;
        }
        unset($st);
        foreach ($later as $uid) {   // once every kept roll is in place
            $old = trim((string)$students[$uid]['roll']);
            $students[$uid]['new_roll'] = $after($students[$uid]['new_section']);
            $students[$uid]['note'] = $old === '' ? 'had no roll' : "roll $old is already taken in the new session";
        }
    } elseif ($method === 'merit_distribution') {
        foreach (['Male' => $boys, 'Female' => $girls] as $gender => $ids) {
            $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($id) => isset($sections[$id]))));
            usort($ids, fn($a, $b) => strnatcasecmp($sections[$a], $sections[$b]));
            $n = 0;
            foreach ($students as &$st) {
                if ($st['gender'] !== $gender) continue;
                $st['order'] = ++$n;
                if ($ids) $st['new_section'] = $ids[($n - 1) % count($ids)];
                else $st['note'] = 'no section is chosen for ' . ($gender === 'Male' ? 'boys' : 'girls');
            }
            unset($st);
        }
        foreach ($students as &$st) {   // best first, so every section numbers its students in merit order
            if ($st['new_section'] !== null) $st['new_roll'] = $after($st['new_section']);
            elseif (!in_array($st['gender'], ['Male', 'Female'], true)) $st['note'] = 'gender is ' . ($st['gender'] !== '' ? $st['gender'] : 'not set') . ' — neither boys\' nor girls\' sections';
        }
        unset($st);
    } elseif ($method === 'section_steps') {
        foreach ($steps as $i => $step) {
            $sec = $step['section'];
            $line = array_filter($students, fn($st) => $st['new_section'] === null && promotion_step_takes($step['who'], $st['gender']));
            promotion_sort_step($line, $step['order']);
            $roll = $step['start'];   // the roll the next one taken should get
            foreach (array_keys($line) as $n => $uid) {
                if ($n % ($step['gap'] + 1)) continue;   // inside the gap: left for a later step
                $students[$uid]['step'] = $i + 1;
                $students[$uid]['new_section'] = $sec;
                if ($roll === null) { $students[$uid]['new_roll'] = $after($sec); continue; }
                $got = $roll;
                while (!empty($used[$sec][(string)$got])) $got++;
                if ($got !== $roll) $students[$uid]['note'] = "roll $roll is already taken in the new session";
                $students[$uid]['new_roll'] = (string)$got;
                $used[$sec][(string)$got] = true;
                $roll = $got + 1;
            }
        }
    } elseif ($method === 'manual') {
        $given = [];   // how many students each "section|roll" is given to
        foreach ($students as $uid => $st) if (isset($manual[$uid])) $given[implode('|', $manual[$uid])] = ($given[implode('|', $manual[$uid])] ?? 0) + 1;
        foreach ($students as $uid => &$st) {
            [$sec, $roll] = $manual[$uid] ?? [0, ''];
            $name = $sections[$sec] ?? null;
            if ($name === null) $st['note'] = 'no section chosen';
            elseif (!preg_match('/^[1-9]\d{0,3}$/', $roll)) $st['note'] = $roll === '' ? "no roll in $name" : "roll $roll is not a number from 1 to 9999";
            elseif (!empty($used[$sec][$roll])) $st['note'] = "roll $roll of $name is already taken in the new session";
            elseif ($given["$sec|$roll"] > 1) $st['note'] = "roll $roll of $name is given to {$given["$sec|$roll"]} students";
            else { $st['new_section'] = $sec; $st['new_roll'] = $roll; }
        }
        unset($st);
    }

    $unplaced = count(array_filter($students, fn($st) => $st['new_section'] === null));
    if ($method === 'manual') {   // the page the choices were made on; $used is untouched by Manual
        $taken = [];
        foreach ($used as $sec => $rolls) { $r = array_map('strval', array_keys($rolls)); sort($r, SORT_NATURAL); $taken[$sec] = $r; }
        ksort($taken);
        $key = sha1(json_encode(['manual', array_map(fn($st) => [$st['section_id'], $st['roll'], $st['rank'], $st['status']], $students), $sections, $taken]));
    } else {
        $key = sha1(json_encode([$method, array_map(fn($st) => [$st['new_section'], $st['new_roll']], $students)]));
    }
    return ['students' => $students, 'left' => $pool['left'], 'already' => $already, 'sections' => $sections, 'steps' => $steps, 'unplaced' => $unplaced, 'key' => $key];
}

/**
 * The year end of a session, class by class, for the checklist: class id => [
 *   name, stage, next (class id | null), now (Active students still Current), waiting (of those, not yet placed in
 *   the new session), merit (status => n), next_sections / next_subjects (of the next class in the new session),
 *   batch (the promotion row | null), passed_out ].
 * Also 'sections' and 'subjects': class id => n in the new session, for every class.
 */
function promotion_year_status(int $from_session, int $to_session): array {
    $count = fn(string $sql, string $types, ...$args) => array_map('intval', array_column(db_get_all($sql, $types, ...$args), 'n', 'class_id'));
    $active = "FROM student_academic_history h JOIN students s ON s.id = h.student_id AND s.student_status = 'Active' WHERE h.session_id = ? AND h.academic_status = 'Current'";
    $now = $count("SELECT h.class_id, COUNT(*) n $active GROUP BY h.class_id", 'i', $from_session);
    $waiting = $to_session
        ? $count("SELECT h.class_id, COUNT(*) n $active AND NOT EXISTS (SELECT 1 FROM student_academic_history t WHERE t.student_id = h.student_id AND t.session_id = ?) GROUP BY h.class_id", 'ii', $from_session, $to_session)
        : $now;
    $sections = $to_session ? $count('SELECT class_id, COUNT(*) n FROM sections WHERE session_id = ? GROUP BY class_id', 'i', $to_session) : [];
    $subjects = $to_session ? $count('SELECT class_id, COUNT(*) n FROM class_subjects WHERE session_id = ? GROUP BY class_id', 'i', $to_session) : [];
    $passed = $count("SELECT class_id, COUNT(*) n FROM student_academic_history WHERE session_id = ? AND student_status = 'Passed' GROUP BY class_id", 'i', $from_session);
    $merit = [];
    foreach (db_get_all('SELECT class_id, result_status, COUNT(*) n FROM student_merit_ranks WHERE academic_session_id = ? GROUP BY class_id, result_status', 'i', $from_session) as $r) {
        $merit[(int)$r['class_id']][$r['result_status']] = (int)$r['n'];
    }
    $batches = [];
    foreach (db_get_all('SELECT id, from_class_id, total_students FROM promotion_batches WHERE from_session_id = ?', 'i', $from_session) as $b) $batches[(int)$b['from_class_id']] = $b;
    $classes = [];
    foreach (class_rows() as $id => $c) {
        $next = promotion_next_class($id);
        $classes[$id] = ['name' => $c['name'], 'stage' => $c['stage'], 'next' => $next, 'now' => $now[$id] ?? 0, 'waiting' => $waiting[$id] ?? 0, 'merit' => $merit[$id] ?? [],
            'next_sections' => $next ? ($sections[$next] ?? 0) : 0, 'next_subjects' => $next ? ($subjects[$next] ?? 0) : 0,
            'batch' => $batches[$id] ?? null, 'passed_out' => $passed[$id] ?? 0];
    }
    return ['classes' => $classes, 'sections' => $sections, 'subjects' => $subjects];
}

function promotion_get_batch($conn, int $batch_id): ?array {
    if ($batch_id <= 0) return null;
    return db_get_row(
        "SELECT pb.*, fc.class_name AS from_class_name, tc.class_name AS to_class_name,
                fs.session_name AS from_session_name, ts.session_name AS to_session_name
         FROM promotion_batches pb
         LEFT JOIN classes fc ON fc.id = pb.from_class_id
         LEFT JOIN classes tc ON tc.id = pb.to_class_id
         LEFT JOIN academic_sessions fs ON fs.id = pb.from_session_id
         LEFT JOIN academic_sessions ts ON ts.id = pb.to_session_id
         WHERE pb.id = ? LIMIT 1",
        'i', $batch_id
    );
}

function promotion_get_batch_student_ids($conn, int $batch_id): array {
    if ($batch_id <= 0) return [];
    $rows = db_get_all('SELECT student_id FROM promotion_details WHERE batch_id = ?', 'i', $batch_id);
    return array_values(array_filter(array_map('student_uid_clean', array_column($rows, 'student_id'))));
}

<?php
/**
 * Result helpers (V–X) — the ONE place pass/fail, grade and rank are worked out.
 * Used by tabulation, annual result, report card, merit list and the public result page.
 *
 * result_exam()   one exam:  student ⇒ subjects (written/project/grace/total/full/pass/absent/fail), total, %, status, rank
 * result_annual() whole year: counts_in_final exams added up per subject, same shape, each subject also carries a
 *                 per-exam breakdown. Formative marks (Primary & Upper Primary) ride along for the report card only —
 *                 they are never added to a total, a percentage, a grade, a result or a rank.
 *
 * Status:  ABSENT  every subject absent / nothing entered
 *          PASS    no subject failed and % ≥ pass_min_percentage
 *          PUC     (promoted under consideration) no_fail_policy, or puc_enabled and fails ≤ puc_max_fail_subjects and % ≥ puc_min_percentage
 *          FAIL    otherwise
 * A subject is failed when absent or obtained (incl. grace) < pass marks. Grade = grade_bands for the class group (V-VIII / IX-X).
 * Rank: dense, by total obtained desc (students with status ABSENT are ranked last and get no rank).
 */
require_once __DIR__ . '/exam_helper.php';

const RESULT_STATUSES = ['PASS' => 'Pass', 'PUC' => 'Promoted Under Consideration', 'FAIL' => 'Fail', 'ABSENT' => 'Absent'];

/** pass_fail_settings of a class with defaults. */
function result_settings(int $class_id): array {
    static $c = [];
    if (!isset($c[$class_id])) {
        $d = ['class_id' => $class_id, 'no_fail_policy' => 0, 'puc_enabled' => 1, 'puc_max_fail_subjects' => 1, 'puc_min_percentage' => 25.0, 'pass_min_percentage' => 33.0];
        $r = db_get_row('SELECT * FROM pass_fail_settings WHERE class_id = ?', 'i', $class_id);
        $c[$class_id] = $r ? array_merge($d, $r) : $d;
    }
    return $c[$class_id];
}

/** Grade bands of a class group, highest first. */
function grade_bands(string $group): array {
    static $c = [];
    if (!isset($c[$group])) $c[$group] = db_get_all('SELECT * FROM grade_bands WHERE class_group = ? ORDER BY sort_order, min_pct DESC', 's', $group);
    return $c[$group];
}
/** Grade for a percentage: ['grade' => 'A+', 'remark' => 'Excellent'] — % rounded to 2 places, band inclusive both ends. */
function grade_for(float $pct, int $class_id): array {
    $group = exam_class_group($class_id) ?? 'IX-X';
    $pct = round($pct, 2);
    foreach (grade_bands($group) as $b) if ($pct >= (float)$b['min_pct'] && $pct <= (float)$b['max_pct']) return ['grade' => $b['grade'], 'remark' => $b['remark']];
    $bands = grade_bands($group);
    $last = end($bands);
    return ['grade' => $last['grade'] ?? '-', 'remark' => $last['remark'] ?? ''];
}

/** Status from the counted subjects. */
function result_status(int $class_id, int $subjects, int $failed, int $absent, float $pct, int $missing = 0): string {
    if ($subjects === 0 || $absent + $missing >= $subjects) return 'ABSENT';
    $s = result_settings($class_id);
    if ($failed === 0 && $pct >= (float)$s['pass_min_percentage']) return 'PASS';
    if (!empty($s['no_fail_policy'])) return 'PUC';
    if (!empty($s['puc_enabled']) && $failed <= (int)$s['puc_max_fail_subjects'] && $pct >= (float)$s['puc_min_percentage']) return 'PUC';
    return 'FAIL';
}

/** Adds total/pct/status/grade/rank to a student list whose 'subjects' are filled. Rank is over the whole list given. */
function result_finalize(array &$students, int $class_id): void {
    foreach ($students as &$st) {
        $tot = 0.0; $full = 0.0; $failed = 0; $absent = 0; $missing = 0; $n = 0;
        foreach ($st['subjects'] as &$sub) {
            $n++;
            $sub['fail'] = $sub['absent'] || $sub['obtained'] < $sub['pass'];
            if ($sub['absent']) $absent++;
            if ($sub['fail']) $failed++;
            if (!empty($sub['missing'])) $missing++;
            $tot += $sub['obtained']; $full += $sub['full'];
            $sub['pct'] = $sub['full'] > 0 ? round($sub['obtained'] / $sub['full'] * 100, 2) : 0.0;
            $sub['grade'] = grade_for($sub['pct'], $class_id)['grade'];
        }
        unset($sub);
        $st['total'] = round($tot, 2); $st['full'] = round($full, 2);
        $st['pct'] = $full > 0 ? round($tot / $full * 100, 2) : 0.0;
        $st['failed_n'] = $failed; $st['absent_n'] = $absent; $st['missing_n'] = $missing; $st['subjects_n'] = $n;
        $st['status'] = result_status($class_id, $n, $failed, $absent, $st['pct'], $missing);
        $g = grade_for($st['pct'], $class_id); $st['grade'] = $g['grade']; $st['grade_remark'] = $g['remark'];
        $st['rank'] = null;
    }
    unset($st);
    // dense rank by total desc among those who sat
    $order = array_keys($students);
    usort($order, fn($a, $b) => ($students[$b]['total'] <=> $students[$a]['total']) ?: ($students[$b]['pct'] <=> $students[$a]['pct']) ?: strcmp($students[$a]['name'], $students[$b]['name']));
    $rank = 0; $prev = null;
    foreach ($order as $uid) {
        if ($students[$uid]['status'] === 'ABSENT') continue;
        if ($prev === null || $students[$uid]['total'] < $prev) { $rank++; $prev = $students[$uid]['total']; }
        $students[$uid]['rank'] = $rank;
    }
}

/**
 * Result of ONE exam for a class (or one section). Returns
 *   ['exam' => row, 'subjects' => [sid => subject], 'students' => [uid => student], 'unconfigured' => [sid...], 'tl_unassigned' => n]
 * student: uid, name, father, roll, section, section_id, gender, dob, subjects => [sid => [obtained, written, project, grace, full, pass, absent, missing, fail, pct, grade]], total, full, pct, status, grade, rank
 * Subjects with no full-marks config are left out of the result (listed in 'unconfigured').
 * $report: the class as it was for this exam — also the students who have left it since (promoted, detained, passed out,
 * or gone after sitting it), so a past year's sheets still show them. Without it, only the students in the class now.
 */
function result_exam(int $session_id, int $class_id, int $exam_id, ?int $section_id = null, bool $report = false): array {
    $exam = exam_get($exam_id);
    $all = exam_subjects($session_id, $exam_id, $class_id);
    $subjects = array_filter($all, fn($s) => $s['configured']);
    $unconfigured = array_keys(array_filter($all, fn($s) => !$s['configured']));
    $students = exam_students($session_id, $class_id, $section_id, $report ? $exam_id : 0);
    $marks = exam_marks($session_id, $exam_id, $class_id, 0, $section_id);
    $tl_unassigned = 0; $has_tl = (bool)array_filter($subjects, fn($s) => $s['tl']);
    foreach ($students as $uid => &$st) {
        if ($has_tl && !$st['tl']) $tl_unassigned++;
        $st['subjects'] = [];
        foreach ($subjects as $sid => $s) {
            if (!exam_student_takes($st, $s)) continue;
            $m = $marks[$uid][$sid] ?? null;
            $st['subjects'][$sid] = [
                'written' => $m ? (float)$m['written_marks'] : 0.0, 'project' => $m ? (float)$m['project_marks'] : 0.0, 'grace' => $m ? (float)$m['grace_marks'] : 0.0,
                'obtained' => $m ? (float)$m['marks'] + (float)$m['grace_marks'] : 0.0,
                'full' => $s['full'], 'pass' => $s['pass'], 'absent' => $m ? (int)$m['is_absent'] === 1 : false, 'missing' => !$m,
            ];
        }
    }
    unset($st);
    result_finalize($students, $class_id);
    return ['exam' => $exam, 'subjects' => $subjects, 'students' => $students, 'unconfigured' => $unconfigured, 'tl_unassigned' => $tl_unassigned];
}

/** Exams that count in the annual result of a session, in order. */
function result_counting_exams(int $session_id): array { return array_values(array_filter(exam_list($session_id), fn($e) => (int)$e['counts_in_final'] === 1)); }
/** True when every counting exam of the session is published (public annual result allowed). */
function result_publishable(int $session_id): bool {
    $ex = result_counting_exams($session_id);
    if (!$ex) return false;
    foreach ($ex as $e) if ((int)$e['is_published'] !== 1) return false;
    return true;
}

/**
 * ANNUAL result: Σ of counting exams per subject. Same shape as result_exam(), plus
 *   'exams' => counting exams, 'formative' => bool, student subjects carry 'exams' => [exam_id => obtained|null(absent/missing)],
 *   'formative' => formative marks obtained (shown on the report card only, never added), 'warnings' => strings (exam with no config/marks for this class).
 * Subject full = Σ full of the exams where the subject is configured; pass = Σ pass of those exams.
 * $report: the class as it was at the end of the year — also those who have left since (promoted, detained, passed out,
 * or gone after sitting the year's last exam). Without it, only the students in the class now.
 */
function result_annual(int $session_id, int $class_id, ?int $section_id = null, bool $report = false): array {
    $exams = result_counting_exams($session_id);
    $students = exam_students($session_id, $class_id, $section_id, $report && $exams ? (int)end($exams)['id'] : 0);
    $formative = exam_class_has_formative($class_id);                       // Primary & Upper Primary carry formative marks
    $fm_marks = $formative ? exam_formative_marks($session_id, $class_id, $section_id) : [];
    $per_exam = []; $warnings = []; $subject_meta = [];
    foreach ($exams as $e) {
        $eid = (int)$e['id'];
        $subs = array_filter(exam_subjects($session_id, $eid, $class_id), fn($s) => $s['configured']);
        if (!$subs) { $warnings[] = $e['exam_name'] . ': full marks not set for this class'; continue; }
        $per_exam[$eid] = ['subjects' => $subs, 'marks' => exam_marks($session_id, $eid, $class_id, 0, $section_id)];
        if (!$per_exam[$eid]['marks']) $warnings[] = $e['exam_name'] . ': no marks entered yet';
        foreach ($subs as $sid => $s) $subject_meta[$sid] = $subject_meta[$sid] ?? $s;
    }
    uasort($subject_meta, fn($a, $b) => ($a['tl'] <=> $b['tl']) ?: strcmp($a['name'], $b['name']));
    foreach ($students as $uid => &$st) {
        $st['subjects'] = [];
        foreach ($subject_meta as $sid => $s) {
            if (!exam_student_takes($st, $s)) continue;
            $row = ['obtained' => 0.0, 'written' => 0.0, 'project' => 0.0, 'grace' => 0.0, 'full' => 0.0, 'pass' => 0.0,
                    'written_full' => 0.0, 'project_full' => 0.0,   // the written / internal split of the full marks, for the mark sheet
                    'absent' => true, 'missing' => true, 'exams' => [], 'exams_w' => [], 'exams_p' => [],
                    'exams_full' => [], 'exams_full_w' => [], 'exams_full_p' => [], 'formative' => null];
            foreach ($per_exam as $eid => $pe) {
                if (!isset($pe['subjects'][$sid])) {
                    $row['exams'][$eid] = $row['exams_w'][$eid] = $row['exams_p'][$eid] = null;
                    $row['exams_full'][$eid] = $row['exams_full_w'][$eid] = $row['exams_full_p'][$eid] = null;
                    continue;
                }
                $cfg = $pe['subjects'][$sid]; $m = $pe['marks'][$uid][$sid] ?? null;
                $row['full'] += $cfg['full']; $row['pass'] += $cfg['pass'];
                // the mark sheet prints each exam's own full marks, written and project apart
                $row['exams_full'][$eid] = $cfg['full'];
                $row['exams_full_w'][$eid] = $cfg['written_full'];
                $row['exams_full_p'][$eid] = $cfg['project_full'];
                $row['written_full'] += $cfg['written_full']; $row['project_full'] += $cfg['project_full'];
                if ($m && (int)$m['is_absent'] !== 1) {
                    $ob = (float)$m['marks'] + (float)$m['grace_marks'];
                    $row['obtained'] += $ob; $row['written'] += (float)$m['written_marks']; $row['project'] += (float)$m['project_marks']; $row['grace'] += (float)$m['grace_marks'];
                    $row['exams'][$eid] = $ob; $row['absent'] = false;
                    // the mark sheet prints what was obtained in each half of each exam as well
                    $row['exams_w'][$eid] = (float)$m['written_marks'] + (float)$m['grace_marks'];
                    $row['exams_p'][$eid] = (float)$m['project_marks'];
                } else {
                    $row['exams'][$eid] = $m ? 'AB' : null;
                    $row['exams_w'][$eid] = $m ? 'AB' : null;
                    $row['exams_p'][$eid] = $m ? 'AB' : null;
                }
                if ($m) $row['missing'] = false;
            }
            if ($formative) $row['formative'] = $fm_marks[$uid][$sid]['total'] ?? null;   // shown on the report card, never added
            if ($row['missing'] && $row['obtained'] == 0) $row['absent'] = true;
            $st['subjects'][$sid] = $row;
        }
    }
    unset($st);
    result_finalize($students, $class_id);
    return ['exams' => $exams, 'subjects' => $subject_meta, 'students' => $students, 'formative' => $formative, 'warnings' => $warnings];
}

/** Result label for display. */
function result_label(string $status): string { return RESULT_STATUSES[$status] ?? $status; }
function result_badge(string $status): string {
    $c = ['PASS' => '#1b7a3a', 'PUC' => '#b26a00', 'FAIL' => '#b71c1c', 'ABSENT' => '#616161'][$status] ?? '#333';
    return '<span style="display:inline-block;padding:2px 8px;border-radius:4px;background:' . $c . ';color:#fff;font-size:11px;font-weight:700">' . htmlspecialchars($status) . '</span>';
}

/* ── compatibility with the old pass_fail_helper.php API (student/progress_report.php) ── */
function get_pass_fail_settings($conn, $class_id) { return result_settings((int)$class_id); }
function get_student_result($conn, $student_id, $session_id, $class_id, $exam_id) {
    $uid = student_uid_clean($student_id);
    $r = result_exam((int)$session_id, (int)$class_id, (int)$exam_id, null, true);   // a student looks back at their own year too
    $st = $r['students'][$uid] ?? null;
    if (!$st) return ['status' => 'ABSENT', 'total_marks' => 0, 'total_full_marks' => 0, 'percentage' => 0, 'subjects_failed' => 0, 'subjects_total' => 0, 'failed_subject_ids' => []];
    $failed = array_keys(array_filter($st['subjects'], fn($s) => $s['fail']));
    return ['status' => $st['status'] === 'PUC' ? 'PROMOTED UNDER CONSIDERATION' : $st['status'], 'total_marks' => $st['total'], 'total_full_marks' => $st['full'],
        'percentage' => $st['pct'], 'subjects_failed' => $st['failed_n'], 'subjects_total' => $st['subjects_n'], 'failed_subject_ids' => $failed];
}

<?php
/**
 * Routine Builder — automatic / semi-automatic timetable generation for classes V–X.
 *
 *   rb_scope_classes()      classes the builder handles (everything except XI / XII)
 *   rb_inputs($session)     units, periods, teachers (subjects, limits, blocks), class teachers, existing routine of
 *                           out-of-scope sections (kept as fixed teacher bookings)
 *   rb_demands($session)    what has to be placed: per unit+subject (normal), per class (combined), per class TL pair
 *   rb_auto_assign()        Automatic: choose a teacher for every demand (balanced load, level preference) + class teachers
 *   rb_generate()           place every demand into the week: hard rules never broken, soft costs minimised,
 *                           randomised restarts + repair within a time box; result in routine_save_unit() cell format
 *   rb_apply()              write a draft into `routine` through routine_save_unit() (all its checks apply)
 */
require_once __DIR__ . '/routine_helper.php';

const RB_LEVEL_OF_CLASS = ['I' => 0, 'II' => 0, 'III' => 0, 'IV' => 0, 'V' => 1, 'VI' => 1, 'VII' => 1, 'VIII' => 1, 'IX' => 2, 'X' => 2, 'XI' => 3, 'XII' => 3];
const RB_LEVEL_OF_SECTION = ['PRIMARY SECTION (I-IV)' => 0, 'UPPER PRIMARY SECTION (V-VIII)' => 1, 'SECONDARY SECTION (IX-X)' => 2, 'HS SECTION (XI-XII)' => 3];

function rb_scope_classes(): array {
    return array_values(array_filter(db_get_all('SELECT id, class_name, sort_order FROM classes ORDER BY sort_order'), fn($c) => !in_array($c['class_name'], ['XI', 'XII'], true)));
}

/** Slots of the week: list of ['day', 'pid', 'idx', 'key'] honouring the Saturday cut. */
function rb_slots(): array {
    $out = [];
    foreach (routine_days() as $day) foreach (routine_periods($day) as $i => $p) $out[] = ['day' => $day, 'pid' => (int)$p['id'], 'idx' => $i, 'key' => $day . '|' . $p['id']];
    return $out;
}

function rb_inputs(int $session_id): array {
    $classes = rb_scope_classes(); $units = []; $unit_of = []; $class_units = [];
    foreach ($classes as $c) foreach (routine_units($session_id, (int)$c['id']) as $k => $u) { $units[$k] = ['key' => $k, 'class_id' => (int)$c['id'], 'class' => $c['class_name'], 'label' => $u['label'], 'sections' => $u['section_ids'], 'first' => $u['section_ids'][0]]; $class_units[(int)$c['id']][] = $k; foreach ($u['section_ids'] as $sid) $unit_of[$sid] = $k; }
    $limits = routine_workload_limits();
    $teachers = [];
    foreach (routine_teachers() as $id => $t) $teachers[$id] = ['id' => $id, 'name' => $t['staff_name'], 'code' => $t['short_code'], 'designation' => $t['designation'], 'limit' => (int)($limits[$t['designation']] ?? 0), 'subjects' => [], 'level' => null, 'blocks' => []];
    foreach (db_get_all("SELECT id, academic_section FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'") as $r) if (isset($teachers[(int)$r['id']])) $teachers[(int)$r['id']]['level'] = RB_LEVEL_OF_SECTION[$r['academic_section']] ?? null;
    foreach (db_get_all('SELECT teacher_id, subject_id FROM teacher_subjects') as $r) if (isset($teachers[(int)$r['teacher_id']])) $teachers[(int)$r['teacher_id']]['subjects'][(int)$r['subject_id']] = true;
    foreach (db_get_all('SELECT teacher_id, day_name, period_id FROM teacher_slot_blocks WHERE session_id = ?', 'i', $session_id) as $r) if (isset($teachers[(int)$r['teacher_id']])) $teachers[(int)$r['teacher_id']]['blocks'][] = [$r['day_name'], (int)$r['period_id']];
    // class teacher = the teacher who takes the first period every day in that unit, always with the same subject
    $class_teacher = []; foreach (db_get_all('SELECT id, class_teacher_id, class_teacher_subject_id FROM sections WHERE session_id = ? AND class_teacher_id IS NOT NULL', 'i', $session_id) as $r) { $k = $unit_of[(int)$r['id']] ?? null; if ($k && isset($teachers[(int)$r['class_teacher_id']])) $class_teacher[$k] = ['t' => (int)$r['class_teacher_id'], 's' => (int)$r['class_teacher_subject_id']]; }
    $assign = []; foreach (db_get_all('SELECT section_id, subject_id, teacher_id FROM teacher_assignments WHERE session_id = ?', 'i', $session_id) as $r) $assign[(int)$r['section_id']][(int)$r['subject_id']] = (int)$r['teacher_id'];
    $subjects = []; foreach (db_get_all('SELECT id, subject_name FROM subjects') as $r) $subjects[(int)$r['id']] = $r['subject_name'];
    // teacher bookings outside the builder's scope (XI/XII or sections of other classes) stay fixed
    $in_scope = array_keys($unit_of); $ph = $in_scope ? implode(',', array_fill(0, count($in_scope), '?')) : '0';
    $fixed = [];
    foreach (db_get_all("SELECT DISTINCT teacher_id, day_name, period_id FROM routine WHERE session_id = ? AND teacher_id IS NOT NULL" . ($in_scope ? " AND section_id NOT IN ($ph)" : ''), 'i' . str_repeat('i', count($in_scope)), $session_id, ...$in_scope) as $r) $fixed[(int)$r['teacher_id']][$r['day_name'] . '|' . $r['period_id']] = true;
    return ['classes' => $classes, 'units' => $units, 'unit_of' => $unit_of, 'class_units' => $class_units, 'teachers' => $teachers, 'class_teacher' => $class_teacher, 'assign' => $assign, 'subjects' => $subjects, 'fixed' => $fixed, 'slots' => rb_slots(), 'settings' => routine_settings()];
}

/**
 * Demands.  Each: ['id', 'type' => normal|combined|tl, 'class_id', 'units' => [keys], 'subjects' => [sid...], 'teachers' => [tid...] (parallel to subjects; 0 = none assigned),
 *                  'n', 'max_per_day', 'band', 'label']
 */
function rb_demands(int $session_id, array $in): array {
    $out = []; $warn = [];
    $rows = db_get_all('SELECT cs.class_id, cs.subject_id, cs.periods_per_week, cs.max_per_day, cs.pref_band, cs.slot_mode, cs.is_third_language, s.subject_name FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.session_id = ? AND cs.periods_per_week > 0 ORDER BY cs.class_id, s.subject_name', 'i', $session_id);
    $tl = [];
    foreach ($rows as $r) {
        $cid = (int)$r['class_id']; if (empty($in['class_units'][$cid])) continue;
        $ukeys = $in['class_units'][$cid]; $sid = (int)$r['subject_id']; $first = $in['units'][$ukeys[0]]['first'];
        if ((int)$r['is_third_language']) { $tl[$cid][] = $r; continue; }
        if ($r['slot_mode'] === 'combined') { $out[] = ['type' => 'combined', 'class_id' => $cid, 'units' => $ukeys, 'subjects' => [$sid], 'teachers' => [(int)($in['assign'][$first][$sid] ?? 0)], 'n' => (int)$r['periods_per_week'], 'max_per_day' => max(1, (int)$r['max_per_day']), 'band' => $r['pref_band'], 'label' => $in['units'][$ukeys[0]]['class'] . ' (all) ' . $r['subject_name']]; continue; }
        foreach ($ukeys as $k) $out[] = ['type' => 'normal', 'class_id' => $cid, 'units' => [$k], 'subjects' => [$sid], 'teachers' => [(int)($in['assign'][$in['units'][$k]['first']][$sid] ?? 0)], 'n' => (int)$r['periods_per_week'], 'max_per_day' => max(1, (int)$r['max_per_day']), 'band' => $r['pref_band'], 'label' => $in['units'][$k]['class'] . '-' . $in['units'][$k]['label'] . ' ' . $r['subject_name']];
    }
    foreach ($tl as $cid => $list) {
        $ukeys = $in['class_units'][$cid]; $first = $in['units'][$ukeys[0]]['first'];
        if (count($list) === 1) { $r = $list[0]; foreach ($ukeys as $k) $out[] = ['type' => 'normal', 'class_id' => $cid, 'units' => [$k], 'subjects' => [(int)$r['subject_id']], 'teachers' => [(int)($in['assign'][$in['units'][$k]['first']][(int)$r['subject_id']] ?? 0)], 'n' => (int)$r['periods_per_week'], 'max_per_day' => max(1, (int)$r['max_per_day']), 'band' => $r['pref_band'], 'label' => $in['units'][$k]['class'] . '-' . $in['units'][$k]['label'] . ' ' . $r['subject_name']]; continue; }
        $list = array_slice($list, 0, 2); $n = max(array_map(fn($r) => (int)$r['periods_per_week'], $list));
        $out[] = ['type' => 'tl', 'class_id' => $cid, 'units' => $ukeys, 'subjects' => array_map(fn($r) => (int)$r['subject_id'], $list), 'teachers' => array_map(fn($r) => (int)($in['assign'][$first][(int)$r['subject_id']] ?? 0), $list), 'n' => $n, 'max_per_day' => max(1, (int)$list[0]['max_per_day']), 'band' => $list[0]['pref_band'], 'label' => $in['units'][$ukeys[0]]['class'] . ' (all) ' . implode(' / ', array_map(fn($r) => $r['subject_name'], $list))];
    }
    foreach ($out as $i => &$d) $d['id'] = $i; unset($d);
    // per-unit totals against the available slots
    $avail = count($in['slots']); $tot = [];
    foreach ($out as $d) foreach ($d['units'] as $k) $tot[$k] = ($tot[$k] ?? 0) + $d['n'];
    foreach ($out as $d) if ($d['n'] > count(routine_days()) * $d['max_per_day']) $warn[] = $d['label'] . ": {$d['n']} periods a week but at most {$d['max_per_day']} a day over " . count(routine_days()) . ' days — raise max/day';
    $ndays = count(routine_days()); $satN = routine_settings()['saturday_periods'];
    // Saturday is short: a subject with more periods than (max/day × 5 full days) must use Saturday — only saturday_periods of them fit
    foreach ($in['units'] as $k => $u) { $need = []; foreach ($out as $d) if (in_array($k, $d['units'], true)) { $x = $d['n'] - $d['max_per_day'] * ($ndays - 1); if ($x > 0) $need[] = $in['subjects'][$d['subjects'][0]] ?? '?'; } if (count($need) > $satN) $warn[] = $u['class'] . '-' . $u['label'] . ': ' . count($need) . ' subjects need a Saturday period (' . implode(', ', $need) . ") but Saturday has only $satN — raise max/day or lower a weekly count"; }
    foreach ($in['class_teacher'] as $k => $ct) { $found = null; foreach ($out as $d) if ($d['type'] === 'normal' && $d['units'][0] === $k && $d['subjects'][0] === $ct['s'] && $d['teachers'][0] === $ct['t']) $found = $d; if (!$found) $warn[] = ($in['units'][$k]['class'] ?? '') . '-' . ($in['units'][$k]['label'] ?? $k) . ': the class teacher is not assigned to their first-period subject there — fix in step 4'; elseif ($found['n'] < $ndays) $warn[] = $found['label'] . ": the class teacher's subject has only {$found['n']} periods a week, but the first period is daily ($ndays) — raise it or pick another subject"; }
    foreach ($in['units'] as $k => $u) { $t = $tot[$k] ?? 0; if ($t !== $avail) $warn[] = $u['class'] . '-' . $u['label'] . ": $t periods a week planned, $avail available" . ($t > $avail ? ' — too many, some will not fit' : ''); }
    return ['demands' => $out, 'warnings' => $warn, 'available' => $avail];
}

/** Automatic: pick a teacher for every demand and a class teacher per unit.  Writes teacher_assignments + sections.class_teacher_id. */
function rb_auto_assign(int $session_id, int $admin_id): array {
    $in = rb_inputs($session_id); $dm = rb_demands($session_id, $in);
    $T = $in['teachers']; $load = []; $per_unit = []; $assign = []; $problems = [];
    foreach ($T as $id => $t) $load[$id] = 0;
    // hardest first: subjects with the fewest eligible teachers, then the biggest demands
    $elig = fn($sid) => array_keys(array_filter($T, fn($t) => !empty($t['subjects'][$sid]) && $t['limit'] > 0));
    $tasks = [];
    foreach ($dm['demands'] as $d) foreach ($d['subjects'] as $i => $sid) $tasks[] = ['d' => $d, 'sid' => $sid, 'i' => $i, 'elig' => $elig($sid)];
    usort($tasks, fn($a, $b) => [count($a['elig']), -$a['d']['n']] <=> [count($b['elig']), -$b['d']['n']]);
    foreach ($tasks as $task) {
        $d = $task['d']; $sid = $task['sid']; $level = RB_LEVEL_OF_CLASS[$in['units'][$d['units'][0]]['class']] ?? 1;
        if (!$task['elig']) { $problems[] = 'No teacher can take ' . ($in['subjects'][$sid] ?? $sid) . ' (' . $d['label'] . ') — tick the subject for a teacher in step 3.'; continue; }
        $best = null; $bestScore = PHP_FLOAT_MAX;
        foreach ($task['elig'] as $tid) {
            $t = $T[$tid]; $ratio = ($load[$tid] + $d['n']) / max(1, $t['limit']);
            $score = $ratio * 100 + ($t['level'] !== null && $t['level'] !== $level ? 15 : 0) + (isset($per_unit[$d['units'][0]][$tid]) ? -2 : 0) + ($load[$tid] + $d['n'] > $t['limit'] ? 60 : 0) + mt_rand(0, 100) / 1000;
            if ($score < $bestScore) { $bestScore = $score; $best = $tid; }
        }
        $load[$best] += $d['n'];
        foreach ($d['units'] as $k) { if ($d['type'] === 'normal') $per_unit[$k][$best . '|' . $sid] = $d['n']; foreach ($in['units'][$k]['sections'] as $sec) $assign[$sec][$sid] = $best; }
    }
    // class teachers: the teacher with most periods in the unit (enough for one a day), one unit per teacher, assistant teachers first
    $days = count(routine_days()); $ct = []; $taken = [];
    $firstPid = (int)(routine_periods()[0]['id'] ?? 0); $noFirst = []; foreach ($T as $tid => $t) foreach ($t['blocks'] as [$d, $pid]) if ($pid === $firstPid) $noFirst[$tid] = true;   // blocked in P1 → cannot be a class teacher
    $order = array_keys($in['units']); usort($order, fn($a, $b) => strcmp($in['units'][$a]['class'] . $in['units'][$a]['label'], $in['units'][$b]['class'] . $in['units'][$b]['label']));
    foreach ($order as $k) {
        $cands = $per_unit[$k] ?? []; if (!$cands) continue;
        $tOf = fn($key) => (int)explode('|', $key)[0];
        uksort($cands, function ($a, $b) use ($cands, $T, $tOf, $days) { $ta = $tOf($a); $tb = $tOf($b); return [$cands[$b] >= $days ? 1 : 0, in_array($T[$tb]['designation'], ['Assistant Teacher', 'Para Teacher'], true) ? 1 : 0, $cands[$b]] <=> [$cands[$a] >= $days ? 1 : 0, in_array($T[$ta]['designation'], ['Assistant Teacher', 'Para Teacher'], true) ? 1 : 0, $cands[$a]]; });
        foreach (array_keys($cands) as $key) { $tid = $tOf($key); if (!isset($taken[$tid]) && !isset($noFirst[$tid])) { $ct[$k] = ['t' => $tid, 's' => (int)explode('|', $key)[1]]; $taken[$tid] = true; break; } }
    }
    // write
    $secs = array_keys($in['unit_of']);
    db_begin_transaction();
    try {
        if ($secs) { $ph = implode(',', array_fill(0, count($secs), '?')); db_execute("DELETE FROM teacher_assignments WHERE session_id = ? AND section_id IN ($ph)", 'i' . str_repeat('i', count($secs)), $session_id, ...$secs); db_execute("UPDATE sections SET class_teacher_id = NULL, class_teacher_subject_id = NULL WHERE id IN ($ph)", str_repeat('i', count($secs)), ...$secs); }
        foreach ($assign as $sec => $bys) foreach ($bys as $sid => $tid) db_insert('teacher_assignments', ['session_id' => $session_id, 'section_id' => $sec, 'subject_id' => $sid, 'teacher_id' => $tid]);
        foreach ($ct as $k => $c) foreach ($in['units'][$k]['sections'] as $sec) db_update('sections', ['class_teacher_id' => $c['t'], 'class_teacher_subject_id' => $c['s']], ['id' => $sec], 'i');
        db_commit();
    } catch (Throwable $e) { db_rollback(); return ['ok' => false, 'problems' => ['Could not save: ' . $e->getMessage()]]; }
    $over = []; foreach ($load as $tid => $l) if ($T[$tid]['limit'] && $l > $T[$tid]['limit']) $over[] = $T[$tid]['name'] . " $l/" . $T[$tid]['limit'];
    return ['ok' => true, 'problems' => $problems, 'load' => $load, 'over' => $over, 'class_teachers' => $ct, 'warnings' => $dm['warnings']];
}

/**
 * Place every demand.  $opts: time_limit (s), keep (unit => day => pid => cell, pinned), seed.
 * Returns ['result' => unit => day => pid => cell, 'unplaced' => [...], 'stats' => [...], 'load' => teacher => day => n]
 */
function rb_generate(int $session_id, array $opts = []): array {
    $in = rb_inputs($session_id); $dm = rb_demands($session_id, $in); $demands = $dm['demands'];
    $S = $in['settings']; $maxDay = max(1, (int)$S['teacher_max_per_day']); $maxRun = max(1, (int)$S['teacher_max_consecutive']); $ctFirst = (int)$S['class_teacher_first_period'] === 1;
    $slots = $in['slots']; $bySlot = []; $slotAt = []; $daySlots = [];
    foreach ($slots as $s) { $bySlot[$s['key']] = $s; $slotAt[$s['day']][$s['idx']] = $s['key']; $daySlots[$s['day']][] = $s['key']; }
    $nPer = count(routine_periods()); $half = $nPer / 2; $days = routine_days();
    $blocked = []; foreach ($in['teachers'] as $tid => $t) foreach ($t['blocks'] as [$day, $pid]) { if ($day === null || $day === '') { foreach ($days as $d) $blocked[$tid][$d . '|' . $pid] = true; } else $blocked[$tid][$day . '|' . $pid] = true; }
    $limit = (float)($opts['time_limit'] ?? 8); $t0 = microtime(true);
    mt_srand((int)($opts['seed'] ?? time()));
    $keep = $opts['keep'] ?? [];
    $best = null; $attempt = 0;

    while ($attempt === 0 || microtime(true) - $t0 < $limit * 0.85) {
        $attempt++; $tA = microtime(true); $budget = max(1.0, min($limit - ($tA - $t0), $limit / 2));
        // ── state: what sits where.  cell[unit][slot] = demand id (or 'keep'); teachAt[t][slot] = n demands; subjDay[unit][sid][day]; tDay[t][day]
        $cell = []; $teachAt = []; $subjDay = []; $tDay = []; $left = [];
        foreach ($in['fixed'] as $tid => $keys) foreach ($keys as $key => $_) $teachAt[$tid][$key] = 1;
        foreach ($demands as $d) $left[$d['id']] = $d['n'];
        $put = function (array $d, string $key) use (&$cell, &$teachAt, &$subjDay, &$tDay, $bySlot) { $day = $bySlot[$key]['day']; foreach ($d['units'] as $k) { $cell[$k][$key] = $d['id']; foreach ($d['subjects'] as $sid) $subjDay[$k][$sid][$day] = ($subjDay[$k][$sid][$day] ?? 0) + 1; } foreach ($d['teachers'] as $tid) if ($tid) { $teachAt[$tid][$key] = ($teachAt[$tid][$key] ?? 0) + 1; $tDay[$tid][$day] = ($tDay[$tid][$day] ?? 0) + 1; } };
        $take = function (array $d, string $key) use (&$cell, &$teachAt, &$subjDay, &$tDay, $bySlot) { $day = $bySlot[$key]['day']; foreach ($d['units'] as $k) { unset($cell[$k][$key]); foreach ($d['subjects'] as $sid) $subjDay[$k][$sid][$day]--; } foreach ($d['teachers'] as $tid) if ($tid) { $teachAt[$tid][$key]--; $tDay[$tid][$day]--; } };
        // conflicts a demand causes/suffers at a slot (hard rules), assuming it is NOT currently placed there
        $conf = function (array $d, string $key) use (&$teachAt, &$subjDay, $blocked, $bySlot): int { $day = $bySlot[$key]['day']; $c = 0; foreach ($d['teachers'] as $tid) if ($tid) { if (!empty($teachAt[$tid][$key])) $c += 2; if (isset($blocked[$tid][$key])) $c += 3; } foreach ($d['units'] as $k) foreach ($d['subjects'] as $sid) if (($subjDay[$k][$sid][$day] ?? 0) >= $d['max_per_day']) $c += 1; return $c; };
        $free = function (array $d, string $key) use (&$cell): bool { foreach ($d['units'] as $k) if (isset($cell[$k][$key])) return false; return true; };
        // soft cost of a slot for a demand (preferences), used to pick among conflict-free options
        $ctOf = $ctFirst ? $in['class_teacher'] : [];
        $nDays = count($days);
        $soft = function (array $d, string $key) use (&$tDay, &$teachAt, $bySlot, $slotAt, $half, $maxDay, $maxRun, $ctOf, $nDays): float {
            $s = $bySlot[$key]; $c = mt_rand(0, 100) / 10000;
            if ($s['idx'] === 0 && $d['type'] === 'normal' && isset($ctOf[$d['units'][0]])) $c += ($ctOf[$d['units'][0]]['t'] === $d['teachers'][0] && $ctOf[$d['units'][0]]['s'] === $d['subjects'][0]) ? -8 : 8;
            if ($s['idx'] === 0 && $d['type'] !== 'normal' && $ctOf) $c += 30;   // class-wide periods keep out of P1 so class teachers can have it
            foreach ($d['teachers'] as $tid) { if (!$tid) continue; $td = $tDay[$tid][$s['day']] ?? 0; $c += $td * 1.5 + ($td >= $maxDay ? 20 : 0);
                $run = 1; for ($i = $s['idx'] - 1; $i >= 0; $i--) { $k = $slotAt[$s['day']][$i] ?? null; if ($k && !empty($teachAt[$tid][$k])) $run++; else break; } for ($i = $s['idx'] + 1; ; $i++) { $k = $slotAt[$s['day']][$i] ?? null; if ($k && !empty($teachAt[$tid][$k])) $run++; else break; } if ($run > $maxRun) $c += 6 * ($run - $maxRun); }
            if ($d['band'] === 'early' && $s['idx'] >= $half) $c += 4; if ($d['band'] === 'late' && $s['idx'] < $half) $c += 4;
            if ($s['day'] === 'Saturday' && $d['n'] <= $d['max_per_day'] * ($nDays - 1)) $c += 7;   // the short Saturday is kept for subjects that cannot fit into the full days
            return $c;
        };
        // 1. pinned cells (semi-automatic "keep")
        foreach ($keep as $k => $kd) foreach ($kd as $day => $per) foreach ($per as $pid => $kc) {
            if (!isset($in['units'][$k]) || !isset($bySlot[$day . '|' . $pid])) continue;
            $units = array_merge([$k], array_values(array_filter((array)($kc['combined'] ?? []), fn($x) => isset($in['units'][$x]))));
            $subs = [(int)($kc['g0']['s'] ?? 0)]; $tea = [(int)($kc['g0']['t'] ?? 0)]; if (!empty($kc['g1'])) { $subs[] = (int)$kc['g1']['s']; $tea[] = (int)$kc['g1']['t']; }
            $put(['id' => 'keep', 'units' => $units, 'subjects' => $subs, 'teachers' => $tea], $day . '|' . $pid);
            foreach ($demands as $d) if ($d['units'][0] === $k && $d['subjects'][0] === $subs[0] && $left[$d['id']] > 0) { $left[$d['id']]--; break; }
        }
        $bestFree = function (array $d) use ($slots, $free, $conf, $soft): ?string { $b = null; $bc = PHP_FLOAT_MAX; foreach ($slots as $s) { if (!$free($d, $s['key'])) continue; $c = $conf($d, $s['key']) * 100 + $soft($d, $s['key']); if ($c < $bc) { $bc = $c; $b = $s['key']; } } return $b; };
        // 2. class-wide demands (every room of the class free at once) — placed first, then fixed
        $wide = array_filter($demands, fn($d) => $d['type'] !== 'normal'); usort($wide, fn($a, $b) => [-count($a['units']), -$a['n']] <=> [-count($b['units']), -$b['n']]);
        foreach ($wide as $d) while ($left[$d['id']] > 0) { $key = $bestFree($d); if ($key === null || $conf($d, $key) > 0) break; $put($d, $key); $left[$d['id']]--; }
        // 3. class teacher: first period every day
        $pin = [];   // class-teacher first periods are fixed once placed
        if ($ctFirst) foreach ($in['class_teacher'] as $k => $ct) foreach ($days as $day) {
            $key = $slotAt[$day][0] ?? null; if (!$key || isset($cell[$k][$key])) continue;
            foreach ($demands as $d) if ($d['type'] === 'normal' && $d['units'][0] === $k && $d['teachers'][0] === $ct['t'] && $d['subjects'][0] === $ct['s'] && $left[$d['id']] > 0 && $conf($d, $key) === 0) { $put($d, $key); $left[$d['id']]--; $pin[$k . '|' . $key] = true; break; }
        }
        // 4. fill every room: normal demands, biggest first, one period at a time (spreads subjects over the week); conflicts allowed for now
        $normal = array_filter($demands, fn($d) => $d['type'] === 'normal'); usort($normal, fn($a, $b) => $b['n'] <=> $a['n']);
        $progress = true;
        while ($progress) { $progress = false; foreach ($normal as $d) { if ($left[$d['id']] <= 0) continue; $key = $bestFree($d); if ($key === null) continue; $put($d, $key); $left[$d['id']]--; $progress = true; } }
        // 5. min-conflicts: swap two placements inside a room until no hard rule is broken (or time is up)
        $isNormal = function ($id) use ($demands) { return $id !== 'keep' && isset($demands[$id]) && $demands[$id]['type'] === 'normal'; };
        $conflicted = function () use (&$cell, $demands, $conf, $take, $put, $isNormal, &$pin): array { $out = []; foreach ($cell as $k => $row) foreach ($row as $key => $id) { if (!$isNormal($id) || isset($pin[$k . '|' . $key])) continue; $d = $demands[$id]; $take($d, $key); $c = $conf($d, $key); $put($d, $key); if ($c > 0) $out[] = [$k, $key]; } return $out; };
        $iter = 0; $tabu = [];
        while (microtime(true) - $tA < $budget * 0.8 && microtime(true) - $t0 < $limit) {
            // periods still out (a room had no free slot earlier) go into any free slot of their room, conflicts and all — the swaps below sort them out
            foreach ($normal as $d) while ($left[$d['id']] > 0) { $key = $bestFree($d); if ($key === null) break; $put($d, $key); $left[$d['id']]--; }
            $bad = $conflicted(); if (!$bad) break;
            for ($m = 0; $m < 40 && $bad; $m++) {
                [$k, $key1] = $bad[mt_rand(0, count($bad) - 1)]; $id1 = $cell[$k][$key1] ?? null; if (!$isNormal($id1) || isset($pin[$k . '|' . $key1])) continue; $d1 = $demands[$id1];
                $bestKey = null; $bestDelta = PHP_INT_MAX; $bestTie = 0;
                $take($d1, $key1); $before1 = $conf($d1, $key1);
                foreach ($cell[$k] + array_fill_keys(array_column($slots, 'key'), null) as $key2 => $id2) {
                    if ($key2 === $key1 || isset($tabu[$key1 . '>' . $key2]) || isset($pin[$k . '|' . $key2])) continue;
                    if ($id2 === null) { $after = $conf($d1, $key2); $delta = $after - $before1; $tie = $soft($d1, $key2); }
                    elseif ($isNormal($id2)) { $d2 = $demands[$id2]; if ($d2['subjects'][0] === $d1['subjects'][0] && $d2['teachers'][0] === $d1['teachers'][0]) continue; $take($d2, $key2); $before2 = $conf($d2, $key2); $after = $conf($d1, $key2); $put($d1, $key2); $after2 = $conf($d2, $key1); $take($d1, $key2); $put($d2, $key2); $delta = ($after + $after2) - ($before1 + $before2); $tie = $soft($d1, $key2); }
                    else continue;
                    if ($delta < $bestDelta || ($delta === $bestDelta && $tie < $bestTie)) { $bestDelta = $delta; $bestKey = $key2; $bestTie = $tie; }
                }
                if ($bestKey === null || $bestDelta > 0 && mt_rand(0, 9) > 1) { $put($d1, $key1); continue; }   // mostly refuse worsening moves, sometimes accept (escapes plateaus)
                $id2 = $cell[$k][$bestKey] ?? null;
                if ($id2 !== null) { $d2 = $demands[$id2]; $take($d2, $bestKey); $put($d2, $key1); }
                $put($d1, $bestKey); $tabu[$bestKey . '>' . $key1] = true; if (count($tabu) > 60) $tabu = array_slice($tabu, -30, null, true);
                $iter++;
            }
        }
        // 5b. polish: swaps inside a room that keep the hard rules and lower the soft cost (teacher day load, runs, class teacher P1, preferences)
        $pairCost = function (array $d1, string $k1, ?array $d2, string $k2) use ($conf, $soft, $put, $take): float { $c = $conf($d1, $k1) * 100 + $soft($d1, $k1); $put($d1, $k1); if ($d2) $c += $conf($d2, $k2) * 100 + $soft($d2, $k2); $take($d1, $k1); return $c; };
        $units_k = array_keys($cell); $polish = 0; $lastGain = microtime(true);
        while ($units_k && microtime(true) - $tA < $budget && microtime(true) - $t0 < $limit && microtime(true) - $lastGain < 0.7) {
            $k = $units_k[mt_rand(0, count($units_k) - 1)]; $keys = array_keys($cell[$k]); if (!$keys) continue; $key1 = $keys[mt_rand(0, count($keys) - 1)]; $id1 = $cell[$k][$key1]; if (!$isNormal($id1) || isset($pin[$k . '|' . $key1])) continue; $d1 = $demands[$id1];
            $take($d1, $key1); $bestKey = null; $bestGain = 0.5;
            foreach ($slots as $s) { $key2 = $s['key']; if ($key2 === $key1 || isset($pin[$k . '|' . $key2])) continue; $id2 = $cell[$k][$key2] ?? null; if ($id2 !== null && !$isNormal($id2)) continue; $d2 = $id2 !== null ? $demands[$id2] : null;
                if ($d2) $take($d2, $key2);
                $now = $pairCost($d1, $key1, $d2, $key2); $new = $pairCost($d1, $key2, $d2, $key1);
                if ($d2) $put($d2, $key2);
                if ($now - $new > $bestGain) { $bestGain = $now - $new; $bestKey = $key2; } }
            if ($bestKey !== null) { $id2 = $cell[$k][$bestKey] ?? null; if ($id2 !== null) { $take($demands[$id2], $bestKey); $put($demands[$id2], $key1); } $put($d1, $bestKey); $polish++; $lastGain = microtime(true); } else $put($d1, $key1);
        }
        // 6. what is still in conflict comes out (never write a broken routine)
        $unplaced = []; $stillLeft = $left;
        foreach ($conflicted() as [$k, $key]) { $id = $cell[$k][$key]; $d = $demands[$id]; $why = []; foreach ($d['teachers'] as $tid) if ($tid) { if (($teachAt[$tid][$key] ?? 0) > 1) $why[] = 'teacher busy'; if (isset($blocked[$tid][$key])) $why[] = 'teacher blocked'; } if (!$why) $why[] = 'subject max/day'; $take($d, $key); $stillLeft[$id]++; $unplaced[$id] = ['label' => $d['label'], 'left' => $stillLeft[$id], 'why' => $why[0]]; }
        foreach ($stillLeft as $id => $n) if ($n > 0 && !isset($unplaced[$id])) $unplaced[$id] = ['label' => $demands[$id]['label'], 'left' => $n, 'why' => 'no free period in the room'];
        $nLeft = array_sum($stillLeft);
        $softTot = 0; foreach ($tDay as $tid => $dd) foreach ($dd as $n) if ($n > $maxDay) $softTot += ($n - $maxDay) * 10;
        foreach ($teachAt as $tid => $keys) foreach ($days as $day) { $run = 0; $mx = 0; foreach ($daySlots[$day] as $key) { if (!empty($keys[$key])) { $run++; $mx = max($mx, $run); } else $run = 0; } if ($mx > $maxRun) $softTot += ($mx - $maxRun) * 4; }
        $score = $nLeft * 1000 + $softTot;
        if ($best === null || $score < $best['score']) $best = ['score' => $score, 'left' => $nLeft, 'soft' => $softTot, 'cell' => $cell, 'unplaced' => array_values($unplaced), 'tDay' => $tDay, 'attempt' => $attempt, 'iter' => $iter];
        if ($nLeft === 0 && $softTot === 0) break;
    }
    // build cells in routine_save_unit() format
    $result = [];
    foreach ($best['cell'] as $k => $row) foreach ($row as $key => $id) {
        if ($id === 'keep' || !isset($demands[$id])) continue;
        $d = $demands[$id]; $s = $bySlot[$key];
        $result[$k][$s['day']][$s['pid']] = ['g0' => ['s' => $d['subjects'][0], 't' => $d['teachers'][0]], 'g1' => isset($d['subjects'][1]) ? ['s' => $d['subjects'][1], 't' => $d['teachers'][1]] : null, 'combined' => array_values(array_diff($d['units'], [$k]))];
    }
    foreach ($keep as $k => $kd) foreach ($kd as $day => $per) foreach ($per as $pid => $kc) if (isset($in['units'][$k])) $result[$k][$day][$pid] = $kc;
    $placedN = 0; foreach ($result as $k => $dd) foreach ($dd as $per) $placedN += count($per);
    $ctOk = 0; $ctTot = 0; $firstPid = (int)(routine_periods()[0]['id'] ?? 0);
    if ($ctFirst) foreach ($in['class_teacher'] as $k => $ct) foreach ($days as $day) { $ctTot++; $g0 = $result[$k][$day][$firstPid]['g0'] ?? null; if ($g0 && (int)$g0['t'] === $ct['t'] && (int)$g0['s'] === $ct['s']) $ctOk++; }
    $stats = ['attempts' => $attempt, 'best_attempt' => $best['attempt'], 'iterations' => $best['iter'], 'seconds' => round(microtime(true) - $t0, 2), 'placed' => $placedN, 'unplaced' => $best['left'], 'soft' => $best['soft'], 'demanded' => array_sum(array_map(fn($d) => $d['n'] * count($d['units']), $demands)), 'units' => count($in['units']), 'warnings' => $dm['warnings'], 'ct_first' => [$ctOk, $ctTot]];
    return ['result' => $result, 'unplaced' => $best['unplaced'], 'stats' => $stats, 'load' => $best['tDay'], 'units' => $in['units']];
}

/** Write a draft's result into `routine`, unit by unit, through routine_save_unit(). */
function rb_apply(int $session_id, array $result, int $admin_id, ?array $only_units = null): array {
    $done = []; $errors = [];
    foreach ($result as $k => $cells) {
        if ($only_units !== null && !in_array($k, $only_units, true)) continue;
        $class_id = 0; foreach (rb_scope_classes() as $c) { if (isset(routine_units($session_id, (int)$c['id'])[$k])) { $class_id = (int)$c['id']; break; } }
        if (!$class_id) { $errors[$k] = 'unit no longer exists'; continue; }
        $r = routine_save_unit($session_id, $class_id, $k, $cells, $admin_id);
        if ($r['ok']) $done[$k] = $r['slots']; else $errors[$k] = implode('; ', array_slice($r['errors'], 0, 3));
    }
    return ['done' => $done, 'errors' => $errors];
}

<?php
/**
 * Routine helpers — periods, days, routine units, clash and workload queries.
 *
 * A routine is entered per "unit" (depends on routine_settings.routine_mode):
 *   section_wise  every section is its own unit
 *   group_wise    configured pairs (section_groups + section_group_members) are one unit, unpaired sections stand alone
 *   class_wise    all sections of the class are one unit
 * The `routine` table always holds ONE ROW PER SECTION, so attendance, substitution, teacher-portal
 * access (teacher_can_access_class_section) and the views never need to know about units.
 *
 * routine.group_id:  0 = normal row · 1 = second group of a split period (Arabic / Sanskrit) ·
 *                   -1 = "combined": this slot is taught together with sections outside the unit ·
 *                   -2 = second group of a combined slot (the whole class's Sanskrit hall while -1 is the Arabic hall).
 */

const ROUTINE_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const ROUTINE_MODES = ['section_wise' => 'Section-wise', 'group_wise' => 'Paired sections', 'class_wise' => 'Class-wise'];
const ROUTINE_GROUP_NORMAL = 0;
const ROUTINE_GROUP_SPLIT = 1;
const ROUTINE_GROUP_COMBINED = -1;
const ROUTINE_GROUP_COMBINED_SPLIT = -2;

function routine_days(): array { return ROUTINE_DAYS; }
function schoolms_valid_weekday($day): bool { return in_array($day, ROUTINE_DAYS, true); }
function routine_day_short(string $day): string { return substr($day, 0, 3); }

/** routine_settings row (id 1), created with defaults if missing. */
function routine_settings(): array {
    static $s = null;
    if ($s === null) {
        $s = db_get_row('SELECT * FROM routine_settings WHERE id = 1');
        if (!$s) { db_execute("INSERT INTO routine_settings (id, routine_mode) VALUES (1, 'section_wise')"); $s = db_get_row('SELECT * FROM routine_settings WHERE id = 1'); }
        if (!isset(ROUTINE_MODES[$s['routine_mode'] ?? ''])) $s['routine_mode'] = 'section_wise';
        $s['saturday_periods'] = max(0, (int)($s['saturday_periods'] ?? 4));
        $s['hs_period_weight'] = (float)($s['hs_period_weight'] ?? 1);
    }
    return $s;
}
function routine_mode(): string { return routine_settings()['routine_mode']; }

/** All periods in order; with $day the list is cut to the Saturday count. */
function routine_periods(?string $day = null): array {
    static $all = null;
    if ($all === null) $all = db_get_all('SELECT id, period_name, start_time, end_time, sort_order FROM periods ORDER BY sort_order, id');
    if ($day === 'Saturday') return array_slice($all, 0, routine_settings()['saturday_periods']);
    return $all;
}
function routine_period_ids_for_day(string $day): array { return array_map(fn($p) => (int)$p['id'], routine_periods($day)); }
function routine_time(?string $t): string { return $t ? date('g:i', strtotime($t)) : ''; }

/** Sections of a class in a session, id => name, ordered by name. */
function routine_sections(int $session_id, int $class_id): array {
    $out = [];
    foreach (db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $session_id, $class_id) as $r) $out[(int)$r['id']] = $r['section_name'];
    return $out;
}

/**
 * Units of a class:  unit_key => ['label' => 'A + B', 'section_ids' => [..], 'group_id' => int|null].
 * unit_key is "s<section_id>" for a single section, "g<group_id>" for a pair, "c<class_id>" for the whole class.
 */
function routine_units(int $session_id, int $class_id, ?string $mode = null): array {
    $mode = $mode ?? routine_mode();
    $sections = routine_sections($session_id, $class_id);
    if (!$sections) return [];
    if ($mode === 'class_wise') {
        $class = db_get_row('SELECT class_name FROM classes WHERE id = ?', 'i', $class_id);
        return ['c' . $class_id => ['label' => 'Class ' . ($class['class_name'] ?? $class_id) . ' (all sections)', 'section_ids' => array_keys($sections), 'group_id' => null]];
    }
    $units = [];
    if ($mode === 'group_wise') {
        $rows = db_get_all('SELECT g.id, g.group_name, m.section_id FROM section_groups g JOIN section_group_members m ON m.group_id = g.id WHERE g.session_id = ? AND g.class_id = ? ORDER BY g.group_name, m.section_id', 'ii', $session_id, $class_id);
        foreach ($rows as $r) {
            $sid = (int)$r['section_id']; if (!isset($sections[$sid])) continue;
            $k = 'g' . (int)$r['id'];
            if (!isset($units[$k])) $units[$k] = ['label' => $r['group_name'], 'section_ids' => [], 'group_id' => (int)$r['id']];
            $units[$k]['section_ids'][] = $sid; unset($sections[$sid]);
        }
    }
    foreach ($sections as $sid => $name) $units['s' . $sid] = ['label' => $name, 'section_ids' => [$sid], 'group_id' => null];
    uasort($units, fn($a, $b) => strcmp($a['label'], $b['label']));
    return $units;
}

/** The unit a section belongs to (key), or null. */
function routine_unit_of_section(int $session_id, int $class_id, int $section_id): ?string {
    foreach (routine_units($session_id, $class_id) as $k => $u) if (in_array($section_id, $u['section_ids'], true)) return $k;
    return null;
}

/**
 * Is the teacher already placed somewhere else at day+period?  Returns the clash row
 * (class_name, section_name, subject_name) or null.  Sections in $ignore (the unit being saved,
 * plus any combined partners) do not count.
 * $hall_subject: when the teacher is placed in a combined (hall) period of this subject, other combined rows of
 * the same subject at the same time do not count — one hall can hold several classes (VII-G with VIII for Arabic).
 */
function routine_teacher_busy(int $session_id, int $teacher_id, string $day, int $period_id, array $ignore_section_ids = [], ?int $hall_subject = null): ?array {
    $ignore = array_values(array_filter(array_map('intval', $ignore_section_ids)));
    $sql = 'SELECT r.section_id, c.class_name, s.section_name, sub.subject_name FROM routine r JOIN classes c ON c.id = r.class_id JOIN sections s ON s.id = r.section_id LEFT JOIN subjects sub ON sub.id = r.subject_id
            WHERE r.session_id = ? AND r.teacher_id = ? AND r.day_name = ? AND r.period_id = ?';
    $types = 'iisi'; $params = [$session_id, $teacher_id, $day, $period_id];
    if ($ignore) { $sql .= ' AND r.section_id NOT IN (' . implode(',', array_fill(0, count($ignore), '?')) . ')'; $types .= str_repeat('i', count($ignore)); $params = array_merge($params, $ignore); }
    // same subject in a hall period elsewhere (a combined row, or one half of a split period) = the same hall, not a clash
    if ($hall_subject) { $sql .= ' AND NOT (r.subject_id = ? AND (r.group_id <> 0 OR EXISTS (SELECT 1 FROM routine r2 WHERE r2.session_id = r.session_id AND r2.section_id = r.section_id AND r2.day_name = r.day_name AND r2.period_id = r.period_id AND r2.group_id = 1)))'; $types .= 'i'; $params[] = $hall_subject; }
    $row = db_get_row($sql . ' ORDER BY c.sort_order, s.section_name LIMIT 1', $types, ...$params);
    return $row ?: null;
}

/** designation => max weekly periods (0 = does not teach). */
function routine_workload_limits(): array {
    $out = [];
    foreach (db_get_all('SELECT designation, max_weekly_periods FROM workload_limits') as $r) $out[$r['designation']] = (int)$r['max_weekly_periods'];
    return $out;
}

/**
 * Weekly load of every teacher in the session, counted per unit-slot (a pair or a combined class
 * taught in one room counts once).  teacher_id => ['periods' => n, 'weighted' => n, 'hs' => n].
 */
function routine_teacher_week_load(int $session_id, array $exclude_section_ids = [], array $only_section_ids = []): array {
    $w = routine_settings()['hs_period_weight'];
    $ex = array_values(array_filter(array_map('intval', $exclude_section_ids)));
    $sql = "SELECT r.teacher_id, r.day_name, r.period_id, r.class_id, r.subject_id, r.group_id, c.class_name
            FROM routine r JOIN classes c ON c.id = r.class_id WHERE r.session_id = ? AND r.teacher_id IS NOT NULL";
    $types = 'i'; $params = [$session_id];
    if ($ex) { $sql .= ' AND r.section_id NOT IN (' . implode(',', array_fill(0, count($ex), '?')) . ')'; $types .= str_repeat('i', count($ex)); $params = array_merge($params, $ex); }
    $on = array_values(array_filter(array_map('intval', $only_section_ids)));
    if ($on) { $sql .= ' AND r.section_id IN (' . implode(',', array_fill(0, count($on), '?')) . ')'; $types .= str_repeat('i', count($on)); $params = array_merge($params, $on); }
    $rows = db_get_all($sql, $types, ...$params);
    $seen = []; $out = [];
    foreach ($rows as $r) {
        // one room = one period, however many sections sit in it
        $k = $r['teacher_id'] . '|' . $r['day_name'] . '|' . $r['period_id'] . '|' . $r['class_id'] . '|' . $r['subject_id'];
        if (isset($seen[$k])) continue; $seen[$k] = true;
        $t = (int)$r['teacher_id']; $hs = in_array($r['class_name'], ['XI', 'XII'], true);
        $out[$t] = $out[$t] ?? ['periods' => 0, 'weighted' => 0.0, 'hs' => 0, 'slots' => []];
        $out[$t]['slots'][] = $k; $out[$t]['periods']++; $out[$t]['hs'] += $hs ? 1 : 0; $out[$t]['weighted'] += $hs ? $w : 1;
    }
    return $out;
}

/** Active teaching staff who can be put on a routine: id => [staff_name, short_code, designation]. */
function routine_teachers(): array {
    $out = [];
    foreach (db_get_all("SELECT id, staff_name, short_code, designation FROM staff WHERE service_status = 'Active' AND staff_type = 'Teaching'
        ORDER BY FIELD(designation, 'Headmaster', 'Assistant Headmaster', 'Teacher-In-Charge', 'Assistant Teacher', 'Para Teacher'), staff_name") as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/** Subjects assigned to a class in a session: subject_id => [subject_name, is_third_language]. */
function routine_class_subjects(int $session_id, int $class_id): array {
    $out = [];
    foreach (db_get_all('SELECT s.id, s.subject_name, cs.is_third_language FROM class_subjects cs JOIN subjects s ON s.id = cs.subject_id WHERE cs.session_id = ? AND cs.class_id = ? ORDER BY s.subject_name', 'ii', $session_id, $class_id) as $r) $out[(int)$r['id']] = $r;
    return $out;
}

/**
 * Routine rows of some sections:  [section_id][day][period_id] => list of rows
 * (each: group_id, subject_id, subject_name, teacher_id, staff_name, short_code).
 */
function routine_grid(int $session_id, array $section_ids): array {
    $ids = array_values(array_filter(array_map('intval', $section_ids))); if (!$ids) return [];
    $rows = db_get_all('SELECT r.section_id, r.day_name, r.period_id, r.group_id, r.subject_id, r.teacher_id, sub.subject_name, st.staff_name, st.short_code
                        FROM routine r LEFT JOIN subjects sub ON sub.id = r.subject_id LEFT JOIN staff st ON st.id = r.teacher_id
                        WHERE r.session_id = ? AND r.section_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY ABS(r.group_id)', 'i' . str_repeat('i', count($ids)), $session_id, ...$ids);
    $g = [];
    foreach ($rows as $r) $g[(int)$r['section_id']][$r['day_name']][(int)$r['period_id']][] = $r;
    return $g;
}

/** A cell label: "Subject — SC" with split groups joined by " / ". */
function routine_cell_text(array $rows): string {
    $parts = [];
    foreach ($rows as $r) $parts[] = ($r['subject_name'] ?? '—') . ($r['short_code'] ? ' (' . $r['short_code'] . ')' : '');
    return implode(' / ', $parts);
}

function routine_period_name(int $pid): string { foreach (routine_periods() as $p) if ((int)$p['id'] === $pid) return $p['period_name']; return 'P?'; }

/**
 * Save one unit's whole week.  $cells = [day => [period_id => ['g0' => ['s' => subject_id, 't' => teacher_id],
 * 'g1' => [...]|null, 'combined' => [other unit keys]]]].  Everything the unit had is replaced in one
 * transaction; a combined slot is rewritten for every section that shares it.
 * Returns ['ok' => bool, 'errors' => [...], 'dropped' => [...], 'rows' => n, 'slots' => n].
 * With $drop_clash a clashing teacher is dropped (subject kept) instead of failing — used by "copy from".
 */
function routine_save_unit(int $session_id, int $class_id, string $unit_key, array $cells, int $admin_id, bool $drop_clash = false): array {
    $units = routine_units($session_id, $class_id);
    if (!isset($units[$unit_key])) return ['ok' => false, 'errors' => ['Unknown routine unit.'], 'dropped' => [], 'rows' => 0, 'slots' => 0];
    $own = $units[$unit_key]['section_ids'];
    $subjects = routine_class_subjects($session_id, $class_id); $teachers = routine_teachers();
    $errors = []; $dropped = []; $plan = []; $seen = [];
    $ph = implode(',', array_fill(0, count($own), '?')); $t = 'i' . str_repeat('i', count($own));
    // slots this unit shares now (combined, group_id -1): every section in them is rewritten or cleared by this save,
    // so those rows never count as a clash
    $old_comb = []; $old_partners = [];
    foreach (db_get_all("SELECT DISTINCT r2.day_name, r2.period_id, r2.section_id FROM routine r1 JOIN routine r2 ON r2.session_id = r1.session_id AND r2.class_id = r1.class_id AND r2.day_name = r1.day_name AND r2.period_id = r1.period_id AND r2.group_id < 0 WHERE r1.session_id = ? AND r1.group_id < 0 AND r1.section_id IN ($ph)", $t, $session_id, ...$own) as $r) { $old_comb[$r['day_name'] . '|' . $r['period_id']] = [$r['day_name'], (int)$r['period_id']]; $old_partners[$r['day_name']][(int)$r['period_id']][] = (int)$r['section_id']; }
    foreach (routine_days() as $day) {
        foreach (routine_period_ids_for_day($day) as $pid) {
            $c = $cells[$day][$pid] ?? null; if (!$c || !is_array($c)) continue;
            $g0 = ['s' => (int)($c['g0']['s'] ?? 0), 't' => (int)($c['g0']['t'] ?? 0)];
            $g1 = !empty($c['g1']) && is_array($c['g1']) ? ['s' => (int)($c['g1']['s'] ?? 0), 't' => (int)($c['g1']['t'] ?? 0)] : null;
            $comb = []; foreach ((array)($c['combined'] ?? []) as $k) if (is_string($k) && isset($units[$k]) && $k !== $unit_key) $comb[$k] = $units[$k]['section_ids'];
            $label = routine_day_short($day) . ' ' . routine_period_name($pid);
            $bad = '';
            foreach ([$g0, $g1] as $g) {
                if (!$g) continue;
                if ($g['s'] && !isset($subjects[$g['s']])) $bad = 'that subject is not assigned to this class';
                elseif ($g['t'] && !isset($teachers[$g['t']])) $bad = 'unknown teacher';
                elseif ($g['t'] && !$g['s']) $bad = 'choose a subject for the teacher';
            }
            if ($bad) { $errors[] = "$label: $bad."; continue; }
            if (!$g0['s']) { if ($g1 && $g1['s']) { $g0 = $g1; $g1 = null; } else continue; }   // empty cell
            if ($g1 && !$g1['s']) $g1 = null;
            if ($g1 && $g1['t'] && $g1['t'] === $g0['t']) { $errors[] = "$label: the same teacher cannot take both groups."; continue; }
            $ignore = array_merge($own, $old_partners[$day][$pid] ?? []); foreach ($comb as $secs) $ignore = array_merge($ignore, $secs);
            foreach (['g0', 'g1'] as $gk) {
                $g = $gk === 'g0' ? $g0 : $g1;
                if (!$g || !$g['t']) continue;
                $k = $day . '|' . $pid . '|' . $g['t'];
                $busy = isset($seen[$k]) ? ['class_name' => 'this unit', 'section_name' => '', 'subject_name' => ''] : routine_teacher_busy($session_id, $g['t'], $day, $pid, $ignore, ($comb || $g1) ? $g['s'] : null);
                if ($busy) {
                    $where = trim($busy['class_name'] . '-' . $busy['section_name'], '-') . ($busy['subject_name'] ? ' (' . $busy['subject_name'] . ')' : '');
                    if ($drop_clash) { $dropped[] = "$label: " . $teachers[$g['t']]['staff_name'] . " — already in $where"; if ($gk === 'g0') $g0['t'] = 0; else $g1['t'] = 0; continue; }
                    $errors[] = "$label: " . $teachers[$g['t']]['staff_name'] . " is already in $where.";
                }
                $seen[$k] = true;
            }
            $plan[] = ['day' => $day, 'pid' => $pid, 'g0' => $g0, 'g1' => $g1, 'comb' => $comb];
        }
    }
    if ($errors) return ['ok' => false, 'errors' => $errors, 'dropped' => $dropped, 'rows' => 0, 'slots' => 0];

    $rows = 0; $cleared = 0;
    db_begin_transaction();
    try {
        db_execute("DELETE FROM routine WHERE session_id = ? AND section_id IN ($ph)", $t, $session_id, ...$own);
        // a combined slot is one thing for every section in it: partners lose it when this unit drops or rewrites it
        $still = []; foreach ($plan as $p) if ($p['comb']) $still[$p['day'] . '|' . $p['pid']] = true;   // combined slots this save keeps (partners are rewritten, not lost)
        foreach ($old_comb as $oc) { db_execute('DELETE FROM routine WHERE session_id = ? AND class_id = ? AND day_name = ? AND period_id = ? AND group_id < 0', 'iisi', $session_id, $class_id, $oc[0], $oc[1]); if (!isset($still[$oc[0] . '|' . $oc[1]])) $cleared += max(0, count($old_partners[$oc[0]][$oc[1]] ?? []) - count($own)); }
        foreach ($plan as $p) {
            $secs = $own; $gid = ROUTINE_GROUP_NORMAL;
            if ($p['comb']) { $gid = ROUTINE_GROUP_COMBINED; foreach ($p['comb'] as $s) $secs = array_merge($secs, $s); $pp = implode(',', array_fill(0, count($secs), '?')); db_execute("DELETE FROM routine WHERE session_id = ? AND day_name = ? AND period_id = ? AND section_id IN ($pp)", 'isi' . str_repeat('i', count($secs)), $session_id, $p['day'], $p['pid'], ...$secs); }
            foreach ($secs as $sid) { db_insert('routine', ['session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $sid, 'group_id' => $gid, 'day_name' => $p['day'], 'period_id' => $p['pid'], 'subject_id' => $p['g0']['s'], 'teacher_id' => $p['g0']['t'] ?: null, 'updated_by' => $admin_id]); $rows++; }
            // second group: within the unit (1) or, for a combined slot, in every section that shares it (-2)
            if ($p['g1']) foreach ($secs as $sid) { db_insert('routine', ['session_id' => $session_id, 'class_id' => $class_id, 'section_id' => $sid, 'group_id' => $p['comb'] ? ROUTINE_GROUP_COMBINED_SPLIT : ROUTINE_GROUP_SPLIT, 'day_name' => $p['day'], 'period_id' => $p['pid'], 'subject_id' => $p['g1']['s'], 'teacher_id' => $p['g1']['t'] ?: null, 'updated_by' => $admin_id]); $rows++; }
        }
        db_commit();
    } catch (Throwable $e) { db_rollback(); error_log('routine save: ' . $e->getMessage()); return ['ok' => false, 'errors' => ['The routine could not be saved — nothing was changed.'], 'dropped' => $dropped, 'rows' => 0, 'slots' => 0]; }
    return ['ok' => true, 'errors' => [], 'dropped' => $dropped, 'rows' => $rows, 'slots' => count($plan), 'cleared_partner_rows' => $cleared];
}

/**
 * A unit's week as the entry page needs it: [day][period_id] => ['g0' => [s,t], 'g1' => [s,t]|null, 'combined' => [unit keys]].
 * Read from the unit's first section; combined partners = the other units holding a -1 row in that slot.
 */
function routine_unit_cells(int $session_id, int $class_id, string $unit_key): array {
    $units = routine_units($session_id, $class_id); if (!isset($units[$unit_key])) return [];
    $first = $units[$unit_key]['section_ids'][0];
    $sec_unit = []; foreach ($units as $k => $u) foreach ($u['section_ids'] as $sid) $sec_unit[$sid] = $k;
    $grid = routine_grid($session_id, [$first])[$first] ?? [];
    $comb = [];
    foreach (db_get_all('SELECT DISTINCT day_name, period_id, section_id FROM routine WHERE session_id = ? AND class_id = ? AND group_id < 0', 'ii', $session_id, $class_id) as $r) { $k = $sec_unit[(int)$r['section_id']] ?? null; if ($k && $k !== $unit_key) $comb[$r['day_name']][(int)$r['period_id']][$k] = true; }
    $out = [];
    foreach ($grid as $day => $per) foreach ($per as $pid => $rows) {
        $cell = ['g0' => null, 'g1' => null, 'combined' => []];
        foreach ($rows as $r) { $g = ['s' => (int)$r['subject_id'], 't' => (int)$r['teacher_id']]; $gid = (int)$r['group_id']; if ($gid === ROUTINE_GROUP_SPLIT || $gid === ROUTINE_GROUP_COMBINED_SPLIT) $cell['g1'] = $g; else $cell['g0'] = $g; if ($gid < 0) $cell['combined'] = array_keys($comb[$day][$pid] ?? []); }
        if ($cell['g0']) $out[$day][$pid] = $cell;
    }
    return $out;
}

/**
 * Shared rendering for the routine views: one unit's week as an HTML table (days x periods).
 * $grid = routine_grid() slice of the unit's first section; $partners[day][pid] = "with C + D" text.
 */
function routine_render_week(array $grid, array $partners = [], bool $show_teacher = true): string {
    $periods = routine_periods(); $sat = routine_settings()['saturday_periods'];
    $h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
    $o = '<table class="rv"><thead><tr><th class="d">Day</th>';
    foreach ($periods as $p) $o .= '<th>' . $h($p['period_name']) . ($p['start_time'] ? '<small>' . $h(routine_time($p['start_time']) . '–' . routine_time($p['end_time'])) . '</small>' : '') . '</th>';
    $o .= '</tr></thead><tbody>';
    foreach (routine_days() as $day) {
        $o .= '<tr><td class="d">' . routine_day_short($day) . '</td>';
        foreach ($periods as $i => $p) {
            $pid = (int)$p['id'];
            if ($day === 'Saturday' && $i >= $sat) { $o .= '<td class="off"></td>'; continue; }
            $rows = $grid[$day][$pid] ?? [];
            if (!$rows) { $o .= '<td class="e"></td>'; continue; }
            $parts = [];
            foreach ($rows as $r) $parts[] = '<b>' . $h($r['subject_name'] ?? '—') . '</b>' . ($show_teacher ? '<span>' . $h($r['short_code'] ?: ($r['staff_name'] ? $r['staff_name'] : '')) . '</span>' : '');
            $comb = (int)($rows[0]['group_id'] ?? 0) < 0;
            $o .= '<td class="' . ($comb ? 'c' : '') . (count($rows) > 1 ? ' s' : '') . '">' . implode('<i class="sep">/</i>', $parts) . ($comb && !empty($partners[$day][$pid]) ? '<small>' . $h($partners[$day][$pid]) . '</small>' : '') . '</td>';
        }
        $o .= '</tr>';
    }
    return $o . '</tbody></table>';
}

/**
 * Actual daily load over a date range (working days only — Sundays and holidays skipped):
 *   ['days' => [date => ['holiday' => name|null, 'sunday' => bool]],
 *    'load' => [date][teacher_id] => ['regular' => n, 'closed' => n, 'subs' => n, 'lost' => n, 'status' => attendance|null]]
 * regular = own routine slots that day (a pair / combined room counts once) minus closed classes/periods;
 * closed  = own slots cancelled for the day (closed class/period, or "class closed" in substitution);
 * subs    = periods taken as substitute; lost = own periods handed to a substitute (teacher absent).
 */
function routine_daily_load(int $session_id, string $from, string $to): array {
    require_once __DIR__ . '/attendance_helper.php';
    $hol = attendance_holiday_map($from, $to);
    $sat = routine_settings()['saturday_periods']; $pids_all = array_map(fn($p) => (int)$p['id'], routine_periods()); $sat_pids = array_slice($pids_all, 0, $sat);
    $by_day = []; // weekday => list of slot rows
    foreach (db_get_all("SELECT r.teacher_id, r.day_name, r.period_id, r.class_id, r.subject_id FROM routine r WHERE r.session_id = ? AND r.teacher_id IS NOT NULL GROUP BY r.teacher_id, r.day_name, r.period_id, r.class_id, r.subject_id", 'i', $session_id) as $r) $by_day[$r['day_name']][] = $r;
    $cc = []; foreach (db_get_all('SELECT closed_date, class_id FROM closed_classes WHERE session_id = ? AND closed_date BETWEEN ? AND ?', 'iss', $session_id, $from, $to) as $r) $cc[$r['closed_date']][(int)$r['class_id']] = true;
    $cp = []; foreach (db_get_all('SELECT closed_date, period_id FROM closed_periods WHERE session_id = ? AND closed_date BETWEEN ? AND ?', 'iss', $session_id, $from, $to) as $r) $cp[$r['closed_date']][(int)$r['period_id']] = true;
    $prov = []; foreach (db_get_all("SELECT provisional_date, period_id, original_teacher_id, provisional_teacher_id, adjustment_type, class_id, original_subject_id FROM provisional_routine WHERE session_id = ? AND provisional_date BETWEEN ? AND ? GROUP BY provisional_date, period_id, original_teacher_id, provisional_teacher_id, adjustment_type, class_id, original_subject_id", 'iss', $session_id, $from, $to) as $r) $prov[$r['provisional_date']][] = $r;
    $att = []; foreach (db_get_all('SELECT teacher_id, attendance_date, attendance_status FROM teacher_attendance WHERE attendance_date BETWEEN ? AND ?', 'ss', $from, $to) as $r) $att[$r['attendance_date']][(int)$r['teacher_id']] = $r['attendance_status'];
    $days = []; $load = [];
    for ($d = new DateTime($from); $d <= new DateTime($to); $d->modify('+1 day')) {
        $k = $d->format('Y-m-d'); $dow = $d->format('l'); $days[$k] = ['holiday' => $hol[$k] ?? null, 'sunday' => $dow === 'Sunday'];
        if ($dow === 'Sunday' || isset($hol[$k])) continue;
        $load[$k] = [];
        $allowed = $dow === 'Saturday' ? $sat_pids : $pids_all;
        foreach ($by_day[$dow] ?? [] as $r) {
            if (!in_array((int)$r['period_id'], $allowed, true)) continue;
            $t = (int)$r['teacher_id']; $load[$k][$t] = $load[$k][$t] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'status' => $att[$k][$t] ?? null];
            if (isset($cc[$k][(int)$r['class_id']]) || isset($cp[$k][(int)$r['period_id']])) $load[$k][$t]['closed']++; else $load[$k][$t]['regular']++;
        }
        foreach ($prov[$k] ?? [] as $p) {
            $o = (int)$p['original_teacher_id']; $s = (int)$p['provisional_teacher_id'];
            if ($o) { $load[$k][$o] = $load[$k][$o] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'status' => $att[$k][$o] ?? null]; if ($p['adjustment_type'] === 'closed') { $load[$k][$o]['closed']++; } elseif ($s) $load[$k][$o]['lost']++; }
            if ($s && $p['adjustment_type'] !== 'closed') { $load[$k][$s] = $load[$k][$s] ?? ['regular' => 0, 'closed' => 0, 'subs' => 0, 'lost' => 0, 'status' => $att[$k][$s] ?? null]; $load[$k][$s]['subs']++; }
        }
        foreach ($att[$k] ?? [] as $t => $st) if (isset($load[$k][$t])) $load[$k][$t]['status'] = $st;
    }
    return ['days' => $days, 'load' => $load];
}

/** CSS for routine_render_week() tables (screen + print). */
function routine_view_styles(): string {
    return '<style>
    table.rv { border-collapse: collapse; width: 100%; font-size: 12.5px; table-layout: fixed; }
    .rv th, .rv td { border: 1px solid #c9d6e2; padding: 5px 4px; text-align: center; vertical-align: middle; height: 46px; }
    .rv th { background: #0b3d5c; color: #fff; font-size: 12px; } .rv th small { display: block; font-weight: 400; font-size: 10px; opacity: .85; }
    .rv th.d, .rv td.d { width: 52px; background: #f5f9fc; color: #0b3d5c; font-weight: 800; } .rv th.d { background: #0b3d5c; color: #fff; }
    .rv td b { display: block; font-size: 12.5px; color: #10253a; } .rv td span { display: block; font-size: 11px; color: #4d6178; }
    .rv td.c { background: #eef6fc; } .rv td.c small { display: block; font-size: 9.5px; color: #1a6fa3; font-weight: 700; }
    .rv td.s .sep { display: block; height: 0; overflow: hidden; border-top: 1px dashed #b0454f; margin: 3px 6px; font-size: 0; } .rv td.s b { font-size: 11.5px; } .rv td.s span { font-size: 10.5px; }
    .rv td.off { background: repeating-linear-gradient(45deg, #f7f9fb, #f7f9fb 5px, #e9eef3 5px, #e9eef3 10px); }
    .rv-legend { display: flex; gap: 6px 14px; flex-wrap: wrap; font-size: 11.5px; color: #3b5168; margin: 6px 0 0; } .rv-legend b { color: #0b3d5c; }
    @media print { table.rv { font-size: 11px; } .rv th, .rv td { padding: 3px; height: 40px; } .rv td, .rv th, .rv td.c, .rv td.d, .rv td.off { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
    </style>';
}

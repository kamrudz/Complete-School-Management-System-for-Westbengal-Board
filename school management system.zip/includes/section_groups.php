<?php
/**
 * Section-pair helpers used by the teacher/student portals and marks entry.
 * Kept with the old signatures; the pairs now live in section_groups + section_group_members
 * (one section can belong to one pair only).  See includes/routine_helper.php for the full model.
 */
require_once __DIR__ . '/routine_helper.php';

/** Sections that sit together with $section_id (itself included); just [$section_id] when unpaired. */
function get_paired_section_ids($conn, $session_id, $class_id, $section_id) {
    $section_id = (int)$section_id;
    $rows = db_get_all('SELECT m2.section_id FROM section_group_members m1 JOIN section_groups g ON g.id = m1.group_id JOIN section_group_members m2 ON m2.group_id = g.id
                        WHERE m1.section_id = ? AND g.session_id = ? AND g.class_id = ? ORDER BY m2.section_id', 'iii', $section_id, (int)$session_id, (int)$class_id);
    $ids = array_map(fn($r) => (int)$r['section_id'], $rows);
    return $ids ?: [$section_id];
}

function get_routine_mode($conn) { return routine_mode(); }

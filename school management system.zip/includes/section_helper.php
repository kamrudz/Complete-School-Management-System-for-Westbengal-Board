<?php
/**
 * Sections belong to one (session, class). Once anything is attached — an enrolment, a routine, marks —
 * the section is frozen: no rename, no move, no delete (db_dependents('sections', $id) says what holds it).
 * The admin's rule: a mistake on first entry can be fixed; once a student is added, nothing changes.
 */

function section_name_normalise($name): string {
    return strtoupper(trim((string)$name));
}

/** Null when acceptable, otherwise the message to show. */
function section_name_error(string $name): ?string {
    if ($name === '') return 'Section name is required.';
    if (!preg_match('/^[A-Z0-9]{1,3}$/', $name)) return 'Section name must be 1–3 capital letters or digits (A, B, A1, SC).';
    return null;
}

<?php
/** Shared CSRF and file-upload security helpers. */

function csrf_token() {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

/** True when $token is this session's CSRF token (constant-time). For JSON bodies, where $_POST is empty. */
function csrf_check(string $token): bool {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $stored = (string)($_SESSION['csrf_token'] ?? '');
    return $token !== '' && $stored !== '' && hash_equals($stored, $token);
}

function verify_csrf_or_die() {
    if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) {
        http_response_code(403);
        exit('Invalid request token.');
    }
}

function ensure_upload_dir($dir) {
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) return false;
    return is_dir($dir) && is_writable($dir);
}

function safe_uploaded_file($file, $upload_dir, array $allowed_ext, array $allowed_mime, $prefix = 'file_', $max_bytes = 5242880) {
    if (empty($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => true, 'filename' => '', 'error' => null];
    }
    if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
        return ['ok' => false, 'filename' => '', 'error' => 'Upload failed.'];
    }
    if ((int)$file['size'] < 1 || (int)$file['size'] > (int)$max_bytes) {
        return ['ok' => false, 'filename' => '', 'error' => 'File is too large or empty.'];
    }

    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext, true)) {
        return ['ok' => false, 'filename' => '', 'error' => 'Invalid file type.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : false;
    if ($finfo) finfo_close($finfo);
    if (!$mime || !in_array($mime, $allowed_mime, true)) {
        return ['ok' => false, 'filename' => '', 'error' => 'Invalid file content.'];
    }
    if (!ensure_upload_dir($upload_dir)) {
        return ['ok' => false, 'filename' => '', 'error' => 'Upload directory is not writable.'];
    }

    $filename = $prefix . bin2hex(random_bytes(12)) . '.' . $ext;
    $dest = rtrim($upload_dir, '/\\') . DIRECTORY_SEPARATOR . $filename;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return ['ok' => false, 'filename' => '', 'error' => 'Could not save uploaded file.'];
    }
    return ['ok' => true, 'filename' => $filename, 'error' => null];
}

<?php
/** Academic sessions: the name rule shared by Add and Edit. Sessions are never deleted — the whole year hangs off one. */

/** "2026" or "2026-2027" (the second year follows the first); null when the name is fine. */
function session_name_error(string $name): ?string {
    if ($name === '') return 'Session name is required.';
    if (!preg_match('/^(\d{4})(?:-(\d{4}))?$/', $name, $m)) return 'Session name must look like 2026 or 2026-2027.';
    if (isset($m[2]) && (int)$m[2] !== (int)$m[1] + 1) return 'In a two-year session the second year must follow the first (e.g. 2026-2027).';
    return null;
}

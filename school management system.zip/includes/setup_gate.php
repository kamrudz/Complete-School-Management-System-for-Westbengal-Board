<?php
/**
 * Setup gate: until School Settings holds the details every printed document needs, an admin is sent back
 * there from any other page in /admin/. Loaded from includes/db.php. It is a convenience, not security —
 * if the lookup fails the gate stays open rather than locking the admin out.
 */

/** The fields a school cannot operate without; School Settings validates against the same list. */
function schoolms_required_settings() {
    return [
        'school_name'    => 'School Name',
        'udise_code'     => 'DISE Code',
        'school_address' => 'School Address',
        'phone'          => 'Phone',
        'email'          => 'Email',
        'hoi_name'       => 'HOI Name',
        'logo'           => 'School Logo',
    ];
}

/**
 * Returns the labels of the compulsory settings that are still empty.
 * An empty array means School Settings is complete.
 */
function schoolms_missing_settings($conn) {
    $required = schoolms_required_settings();

    $result = @mysqli_query($conn,
        'SELECT `' . implode('`, `', array_keys($required)) . '` FROM school_settings WHERE id=1 LIMIT 1');
    if (!$result) return [];               // fail open

    $row = mysqli_fetch_assoc($result);
    if (!$row) return array_values($required);   // no settings row at all

    $missing = [];
    foreach ($required as $column => $label) {
        if (trim((string)($row[$column] ?? '')) === '') $missing[] = $label;
    }
    return $missing;
}

/**
 * Sends a logged-in admin back to School Settings while anything compulsory is
 * missing. Does nothing outside /admin/, on the CLI, or on the pages an admin
 * still has to be able to reach.
 */
function schoolms_require_school_settings($conn) {
    if (PHP_SAPI === 'cli') return;
    if (session_status() !== PHP_SESSION_ACTIVE) return;
    if (empty($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) return;

    // PHP_SELF is a URL path, so it is always forward-slashed even on Windows.
    $script = (string)($_SERVER['PHP_SELF'] ?? '');
    if (strpos($script, '/admin/') === false) return;

    // School Settings itself, plus the way in and out.
    $allowed = ['school_settings.php', 'login.php', 'logout.php'];
    if (in_array(basename($script), $allowed, true)) return;

    $missing = schoolms_missing_settings($conn);
    if (!$missing) return;

    $_SESSION['error'] = 'প্রথমে School Settings সম্পূর্ণ করুন। এখনো বাকি: '
                       . implode(', ', $missing)
                       . '। এগুলো ছাড়া Student ID, Certificate, ID Card বা Tabulation কিছুই ঠিকভাবে তৈরি হবে না।';
    header('Location: school_settings.php');
    exit;
}

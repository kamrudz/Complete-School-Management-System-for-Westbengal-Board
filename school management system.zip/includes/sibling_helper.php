<?php
/**
 * Siblings are never stored: they are worked out from the guardian details each time, so a corrected
 * guardian record changes the sibling list at once. Two students count as siblings when at least three of
 * these match: father's name, mother's name, father's mobile, father's voter ID, father's Aadhaar.
 */

/** A value reduced to what matters when comparing: lower case, letters and digits only; '' for "N/A" and the like. */
function sibling_normalize($value, string $type = 'text'): string {
    $value = strtolower(trim((string)$value));
    $value = (string)preg_replace($type === 'text' ? '/[^\p{L}\p{N}]+/u' : '/[^a-z0-9]+/', '', $value);
    if (in_array($value, ['', 'na', 'notavailable', 'notprovided', 'unknown', 'none', 'null', 'nil', 'no', '0'], true)) return '';
    if ($type !== 'text' && preg_match('/^0+$/', $value)) return '';
    if ($type === 'mobile') {
        // +91 98…, 91 98… and 098… are the same number
        if (strlen($value) === 12 && str_starts_with($value, '91')) $value = substr($value, 2);
        elseif (strlen($value) === 11 && str_starts_with($value, '0')) $value = substr($value, 1);
    }
    return $value;
}

/** The five compared fields of a student or guardian row, normalised. */
function sibling_profile_fields(array $row): array {
    return [
        'father_name'     => sibling_normalize($row['father_name'] ?? ''),
        'mother_name'     => sibling_normalize($row['mother_name'] ?? ''),
        'father_mobile'   => sibling_normalize($row['father_mobile'] ?? '', 'mobile'),
        'father_voter_id' => sibling_normalize($row['father_voter_id'] ?? '', 'id'),
        'father_aadhaar'  => sibling_normalize($row['father_aadhaar'] ?? '', 'id'),
    ];
}

/** How many of the five fields match, counting only fields filled in on both sides. */
function sibling_score(array $a, array $b): int {
    $n = 0;
    foreach ($a as $field => $v) if ($v !== '' && $v === ($b[$field] ?? '')) $n++;
    return $n;
}

/** Every student who is not deleted (except $except), with guardian details and latest class: uid => row. */
function load_sibling_profiles(string $except = ''): array {
    $rows = [];
    foreach (db_get_all("SELECT s.id, s.student_name, s.student_status, s.guardian_id,
                                g.father_name, g.mother_name, g.father_mobile, g.father_voter_id, g.father_aadhaar, g.guardian_name, g.guardian_contact,
                                c.class_name, sec.section_name, h.roll_no
                         FROM students s
                         LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
                         LEFT JOIN student_academic_history h ON h.id = (SELECT MAX(h2.id) FROM student_academic_history h2 WHERE h2.student_id = s.id)
                         LEFT JOIN classes c ON c.id = h.class_id
                         LEFT JOIN sections sec ON sec.id = h.section_id
                         WHERE s.student_status <> 'Deleted' AND s.id <> ?
                         ORDER BY s.student_name", 's', $except) as $row) {
        $row['_sibling_fields'] = sibling_profile_fields($row);
        $rows[$row['id']] = $row;
    }
    return $rows;
}

/** The profiles scoring at least $min_score against $fields, best match first. */
function sibling_rank(array $fields, array $profiles, int $min_score): array {
    $matches = [];
    foreach ($profiles as $p) {
        $score = sibling_score($fields, $p['_sibling_fields']);
        if ($score < $min_score) continue;
        $p['match_score'] = $score;
        $p['class_label'] = trim(($p['class_name'] ?? '') . ' ' . ($p['section_name'] ?? ''));
        $matches[] = $p;
    }
    usort($matches, fn($a, $b) => ($b['match_score'] <=> $a['match_score']) ?: strcasecmp($a['student_name'], $b['student_name']));
    return $matches;
}

/** The likely siblings of one student. */
function find_sibling_matches($conn, $uid, int $min_score = 3): array {
    $uid = student_uid_clean($uid);
    $me = $uid === '' ? null : db_get_row("SELECT g.father_name, g.mother_name, g.father_mobile, g.father_voter_id, g.father_aadhaar
                                           FROM students s LEFT JOIN guardians g ON g.guardian_id = s.guardian_id
                                           WHERE s.id = ? AND s.student_status <> 'Deleted'", 's', $uid);
    return $me ? sibling_rank(sibling_profile_fields($me), load_sibling_profiles($uid), $min_score) : [];
}

/** Students matching guardian details typed into a form (needs at least $min_score of the fields filled in). */
function find_sibling_matches_for_profile($conn, array $profile, int $min_score = 3): array {
    $fields = sibling_profile_fields($profile);
    if (count(array_filter($fields, fn($v) => $v !== '')) < $min_score) return [];
    return sibling_rank($fields, load_sibling_profiles(), $min_score);
}

/**
 * Every sibling pair in the school at once: [uid => [sibling uid => score], ...] plus the profiles.
 * Students are grouped by each shared value, so only students sharing something are ever compared.
 */
function build_sibling_index($conn, int $min_score = 3): array {
    $profiles = load_sibling_profiles();
    $groups = [];   // field => value => [uid, ...]
    foreach ($profiles as $uid => $p) {
        foreach ($p['_sibling_fields'] as $field => $v) if ($v !== '') $groups[$field][$v][] = (string)$uid;
    }
    $scores = [];
    foreach ($groups as $values) {
        foreach ($values as $uids) {
            $n = count($uids);
            for ($i = 0; $i < $n; $i++) {
                for ($j = $i + 1; $j < $n; $j++) {
                    [$a, $b] = [$uids[$i], $uids[$j]];
                    $scores[$a][$b] = ($scores[$a][$b] ?? 0) + 1;
                    $scores[$b][$a] = ($scores[$b][$a] ?? 0) + 1;
                }
            }
        }
    }
    foreach ($scores as $uid => $pairs) {
        $scores[$uid] = array_filter($pairs, fn($s) => $s >= $min_score);
        if (!$scores[$uid]) unset($scores[$uid]);
    }
    return [$scores, $profiles];
}

/**
 * The guardian row a new student should share: the best match for the typed guardian details
 * (score ≥ $min_score). null when nothing matches well enough, or two different rows tie for best.
 */
function find_matching_guardian_id_by_score($conn, array $values, int $min_score = 3): ?int {
    $fields = sibling_profile_fields($values);
    if (count(array_filter($fields, fn($v) => $v !== '')) < $min_score) return null;
    $best = null; $best_score = 0; $tie = false;
    foreach (db_get_all('SELECT guardian_id, father_name, mother_name, father_mobile, father_voter_id, father_aadhaar FROM guardians') as $g) {
        $score = sibling_score($fields, sibling_profile_fields($g));
        if ($score < $min_score || $score < $best_score) continue;
        if ($score > $best_score) { $best = (int)$g['guardian_id']; $best_score = $score; $tie = false; }
        elseif ($best !== null && (int)$g['guardian_id'] !== $best) $tie = true;
    }
    return $tie ? null : $best;
}

/**
 * The report's three lists. A family is one guardian row holding more than one student — the database
 * already says who belongs together — so the five compared fields above are needed for one thing only:
 * two children of the same parents sitting on two different guardian rows.
 */

/** Every family with a child in the session: guardian_id => the guardian's details and their children. */
function sib_families(int $session_id, int $class_id = 0, string $search = ''): array
{
    $rows = db_get_all("SELECT g.guardian_id, g.father_name, g.mother_name, g.father_mobile, g.guardian_name, g.guardian_contact,
                   s.id, s.student_name, s.gender, s.student_status, h.roll_no, h.class_id, c.class_name, sec.section_name
            FROM students s
            JOIN guardians g ON g.guardian_id = s.guardian_id
            LEFT JOIN student_academic_history h ON h.id = (SELECT MAX(h2.id) FROM student_academic_history h2 WHERE h2.student_id = s.id AND h2.session_id = ?)
            LEFT JOIN classes c ON c.id = h.class_id
            LEFT JOIN sections sec ON sec.id = h.section_id
            WHERE s.student_status <> 'Deleted'
              AND s.guardian_id IN (SELECT guardian_id FROM students WHERE student_status <> 'Deleted' AND guardian_id IS NOT NULL GROUP BY guardian_id HAVING COUNT(*) > 1)
            ORDER BY g.guardian_id, c.sort_order, s.student_name", 'i', $session_id);
    $out = [];
    foreach ($rows as $r) {
        $gid = (int)$r['guardian_id'];
        if (!isset($out[$gid])) $out[$gid] = ['guardian_id' => $gid, 'father_name' => (string)$r['father_name'], 'mother_name' => (string)$r['mother_name'],
            'mobile' => (string)($r['father_mobile'] ?: $r['guardian_contact']), 'guardian_name' => (string)$r['guardian_name'], 'children' => []];
        $out[$gid]['children'][] = $r;
    }
    $needle = mb_strtolower($search);
    foreach ($out as $gid => $fam) {
        $here = false;
        $hay = mb_strtolower(implode(' ', [$fam['father_name'], $fam['mother_name'], $fam['mobile'], $fam['guardian_name']]));
        foreach ($fam['children'] as $ch) {
            if ($ch['class_name'] !== null && (!$class_id || (int)$ch['class_id'] === $class_id)) $here = true;
            $hay .= ' ' . mb_strtolower($ch['student_name'] . ' ' . $ch['id']);
        }
        if (!$here || ($needle !== '' && mb_strpos($hay, $needle) === false)) unset($out[$gid]);
    }
    return $out;
}

/**
 * Two students whose guardian details match on at least $min of the five fields but who sit on different
 * guardian rows — the only pairs an admin still has to join up by hand.
 */
function sib_not_linked(mysqli $conn, int $min = 3): array
{
    [$index, $profiles] = build_sibling_index($conn, $min);
    $guardian = array_column(db_get_all("SELECT id, guardian_id FROM students WHERE student_status <> 'Deleted'"), 'guardian_id', 'id');
    $pairs = [];
    foreach ($index as $a => $matches) {
        foreach ($matches as $b => $score) {
            if (strcmp((string)$a, (string)$b) >= 0) continue;
            if ((int)($guardian[$a] ?? 0) === (int)($guardian[$b] ?? -1)) continue;
            $pairs[] = ['a' => $profiles[$a], 'b' => $profiles[$b], 'score' => (int)$score];
        }
    }
    usort($pairs, fn($x, $y) => $y['score'] <=> $x['score'] ?: strcasecmp($x['a']['student_name'], $y['a']['student_name']));
    return $pairs;
}

/** Guardian rows holding more students than one family plausibly has — nearly always an entry mistake. */
function sib_too_many(int $many): array
{
    $rows = db_get_all("SELECT g.guardian_id, g.father_name, g.mother_name, g.father_mobile, COUNT(s.id) n,
                               GROUP_CONCAT(CONCAT_WS('\t', s.id, s.student_name, COALESCE(c.class_name, '')) ORDER BY s.id SEPARATOR '\n') who
        FROM guardians g
        JOIN students s ON s.guardian_id = g.guardian_id AND s.student_status <> 'Deleted'
        LEFT JOIN student_academic_history h ON h.id = (SELECT MAX(h2.id) FROM student_academic_history h2 WHERE h2.student_id = s.id)
        LEFT JOIN classes c ON c.id = h.class_id
        GROUP BY g.guardian_id HAVING n > ? ORDER BY n DESC, g.father_name", 'i', $many);
    foreach ($rows as $i => $r) {
        $kids = [];
        foreach (explode("\n", (string)$r['who']) as $line) {
            $p = explode("\t", $line);
            if (($p[0] ?? '') !== '') $kids[] = ['id' => $p[0], 'name' => $p[1] ?? '', 'class' => $p[2] ?? ''];
        }
        $rows[$i]['kids'] = $kids;
    }
    return $rows;
}

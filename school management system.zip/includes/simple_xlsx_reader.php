<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

/**
 * SimpleXLSXReader
 * A minimal, dependency-free (.xlsx) reader using PHP's built-in ZipArchive + SimpleXML.
 * No Composer / PHPSpreadsheet required.
 *
 * Limitations (acceptable for CSV-style import use cases):
 * - readFirstSheet() reads the FIRST worksheet; readAllSheets() returns every sheet as name => rows.
 * - Returns raw cell text/numbers as strings (dates come through as Excel serial
 *   numbers unless the cell is explicitly formatted as text in the source file —
 *   handled below via a basic serial-to-date conversion when a column looks like a date).
 * - Merged cells are not expanded (each merged cell other than the top-left is empty).
 */
class SimpleXLSXReader
{
    /**
     * @param string $filePath Path to the uploaded .xlsx file
     * @return array<int, array<int, string>> Rows of cell values, 0-indexed columns
     * @throws Exception on read/parse failure
     */
    public static function readFirstSheet(string $filePath): array
    {
        foreach (self::readAllSheets($filePath) as $rows) {
            return $rows;
        }
        return [];
    }

    /**
     * Every worksheet of the workbook, in workbook order.
     * @return array<string, array<int, array<int, string>>> sheet name => rows
     * @throws Exception on read/parse failure
     */
    public static function readAllSheets(string $filePath): array
    {
        // ZipArchive when the zip extension is loaded, otherwise the small pure-PHP reader below
        $zip = class_exists('ZipArchive') ? new ZipArchive() : new SimpleZipReader();
        if ($zip->open($filePath) !== true) {
            throw new Exception("Unable to open the uploaded file as an XLSX (zip) archive.");
        }

        // ---- Shared strings (string table) ----
        $sharedStrings = [];
        $sharedXml = $zip->getFromName('xl/sharedStrings.xml');
        if ($sharedXml !== false) {
            $sst = @simplexml_load_string($sharedXml);
            if ($sst !== false) {
                foreach ($sst->si as $si) {
                    // A shared string can contain a single <t> or multiple <r><t> runs
                    if (isset($si->t)) {
                        $sharedStrings[] = (string)$si->t;
                    } else {
                        $text = '';
                        if (isset($si->r)) {
                            foreach ($si->r as $run) {
                                $text .= (string)$run->t;
                            }
                        }
                        $sharedStrings[] = $text;
                    }
                }
            }
        }

        // ---- Sheet name => part path, via workbook + relationships ----
        $sheets = [];
        $workbookXml = $zip->getFromName('xl/workbook.xml');
        $relsXml = $zip->getFromName('xl/_rels/workbook.xml.rels');
        if ($workbookXml !== false && $relsXml !== false) {
            $wb = @simplexml_load_string($workbookXml);
            $rels = @simplexml_load_string($relsXml);
            if ($wb !== false && $rels !== false && isset($wb->sheets->sheet)) {
                $target = [];
                foreach ($rels->Relationship as $rel) {
                    // "/xl/worksheets/sheet1.xml" is from the package root, "worksheets/sheet1.xml" from xl/
                    $t = (string)$rel['Target'];
                    $target[(string)$rel['Id']] = str_starts_with($t, '/') ? ltrim($t, '/') : 'xl/' . $t;
                }
                $n = 0;
                foreach ($wb->sheets->sheet as $sheet) {
                    $n++;
                    $ns = $sheet->attributes('r', true);
                    $rId = (string)($ns['id'] ?? '');
                    $path = $target[$rId] ?? ('xl/worksheets/sheet' . $n . '.xml');
                    $name = trim((string)$sheet['name']);
                    if ($name === '') $name = 'Sheet' . $n;
                    while (isset($sheets[$name])) $name .= '_';   // two tabs of the same name: keep both
                    $sheets[$name] = $path;
                }
            }
        }
        if (!$sheets) {
            $sheets = ['Sheet1' => 'xl/worksheets/sheet1.xml'];   // fallback: the most common default path
        }

        $out = []; $read = 0;
        foreach ($sheets as $name => $path) {
            $raw = $zip->getFromName($path);
            if ($raw === false) continue;
            $read++;
            $out[$name] = self::parseSheet($raw, $sharedStrings);
        }
        $zip->close();

        if ($read === 0) {
            throw new Exception("Could not locate worksheet data inside the XLSX file.");
        }
        return $out;
    }

    /** One worksheet's XML into rows of cell values (0-indexed columns, gaps filled). */
    private static function parseSheet(string $sheetXmlRaw, array $sharedStrings): array
    {
        $sheetXml = @simplexml_load_string($sheetXmlRaw);
        if ($sheetXml === false || !isset($sheetXml->sheetData->row)) {
            return [];
        }

        $rows = [];
        foreach ($sheetXml->sheetData->row as $row) {
            $rowIndex = (int)$row['r'] - 1; // 1-indexed in XML -> 0-indexed
            $cells = [];
            foreach ($row->c as $cell) {
                $ref = (string)$cell['r']; // e.g. "C5"
                $colLetters = preg_replace('/[0-9]/', '', $ref);
                $colIndex = self::colLettersToIndex($colLetters);

                $type = (string)($cell['t'] ?? '');
                $rawValue = isset($cell->v) ? (string)$cell->v : '';

                if ($type === 's') {
                    // shared string index
                    $idx = (int)$rawValue;
                    $value = $sharedStrings[$idx] ?? '';
                } elseif ($type === 'inlineStr') {
                    $value = isset($cell->is->t) ? (string)$cell->is->t : '';
                } elseif ($type === 'str') {
                    $value = $rawValue; // formula result as string
                } else {
                    // numeric, boolean, or date-serial — keep as raw string,
                    // caller decides if a column needs date conversion
                    $value = $rawValue;
                }

                $cells[$colIndex] = $value;
            }

            // Fill any gaps so row arrays are sequential 0..max
            if (!empty($cells)) {
                $maxCol = max(array_keys($cells));
                for ($i = 0; $i <= $maxCol; $i++) {
                    if (!isset($cells[$i])) {
                        $cells[$i] = '';
                    }
                }
                ksort($cells);
            }

            $rows[$rowIndex] = array_values($cells);
        }

        ksort($rows);
        return array_values($rows);
    }

    /**
     * Convert an Excel date serial number to Y-m-d, if the value looks numeric
     * and plausible as a date serial. Returns the original string otherwise.
     */
    public static function excelSerialToDate(string $value): string
    {
        $value = trim($value);
        if ($value === '' || !is_numeric($value)) {
            return $value;
        }
        $serial = (float)$value;
        // Excel's epoch: Dec 30, 1899. Plausible student DOB range check.
        if ($serial < 1 || $serial > 80000) {
            return $value;
        }
        $unixTimestamp = ($serial - 25569) * 86400; // 25569 = days between 1899-12-30 and 1970-01-01
        return gmdate('Y-m-d', (int)$unixTimestamp);
    }

    private static function colLettersToIndex(string $letters): int
    {
        $letters = strtoupper($letters);
        $index = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $index = $index * 26 + (ord($letters[$i]) - ord('A') + 1);
        }
        return $index - 1; // 0-indexed
    }
}
/**
 * Minimal read-only zip parser (stored + deflate entries) with the ZipArchive methods the reader uses,
 * for servers without the zip extension. Reads the central directory from the end of the file.
 */
class SimpleZipReader
{
    private array $entries = [];
    private string $data = '';

    public function open(string $path): bool
    {
        $d = @file_get_contents($path);
        if ($d === false || strlen($d) < 22) return false;
        $eocd = strrpos($d, "PK\x05\x06");
        if ($eocd === false) return false;
        $h = unpack('vdisk/vcddisk/ventries/vtotal/Vcdsize/Vcdoffset', substr($d, $eocd + 4, 16));
        $p = $h['cdoffset'];
        for ($i = 0; $i < $h['total']; $i++) {
            if (substr($d, $p, 4) !== "PK\x01\x02") return false;
            $c = unpack('vver/vvby/vflag/vmethod/vtime/vdate/Vcrc/Vcsize/Vsize/vnlen/velen/vclen/vdisk/viattr/Veattr/Voffset', substr($d, $p + 4, 42));
            $name = substr($d, $p + 46, $c['nlen']);
            $this->entries[$name] = $c;
            $p += 46 + $c['nlen'] + $c['elen'] + $c['clen'];
        }
        $this->data = $d;
        return true;
    }

    public function getFromName(string $name)
    {
        if (!isset($this->entries[$name])) return false;
        $c = $this->entries[$name];
        $lp = $c['offset'];
        if (substr($this->data, $lp, 4) !== "PK\x03\x04") return false;
        $l = unpack('vnlen/velen', substr($this->data, $lp + 26, 4));
        $raw = substr($this->data, $lp + 30 + $l['nlen'] + $l['elen'], $c['csize']);
        if ($c['method'] === 0) return $raw;
        if ($c['method'] === 8) { $out = @gzinflate($raw); return $out === false ? false : $out; }
        return false;
    }

    public function close(): void { $this->data = ''; $this->entries = []; }
}
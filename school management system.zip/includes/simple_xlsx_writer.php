<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

/**
 * SimpleXLSXWriter
 * Minimal dependency-free XLSX writer — writes the ZIP container itself, no php 'zip' extension needed.
 * Suitable for tabular exports/templates without formulas or charts. One worksheet through download()/save(),
 * several through downloadBook()/saveBook() — every sheet carries its own rows and options.
 */
class SimpleXLSXWriter
{
    /**
     * @param string $filename Download filename.
     * @param array<int,array<int,mixed>> $rows Worksheet rows.
     * @param string $sheetName Worksheet title.
     * @param array<string,mixed> $options Supported: title_rows, header_rows, total_rows, freeze_rows,
     *        merge_cells, protect (lock the sheet), unlocked_cols (1-based columns left editable while protected)
     *        and band_cols (1-based column => 0|1|2, a tint that groups columns together, e.g. one subject block).
     */
    public static function download(string $filename, array $rows, string $sheetName = 'Sheet1', array $options = []): void
    {
        self::downloadBook($filename, [['name' => $sheetName, 'rows' => $rows, 'options' => $options]]);
    }

    /**
     * Download a workbook of several worksheets.
     * @param array<int,array<string,mixed>> $sheets [['name' => …, 'rows' => [[…]], 'options' => […]], …]
     */
    public static function downloadBook(string $filename, array $sheets): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $path = tempnam(sys_get_temp_dir(), 'xlsx_');
        if ($path === false) {
            http_response_code(500);
            exit('Could not create a temporary Excel file.');
        }

        try {
            self::saveBook($path, $sheets);
        } catch (Exception $e) {
            @unlink($path);
            http_response_code(500);
            exit('Could not create Excel file: ' . $e->getMessage());
        }

        $filename = self::safeFilename($filename);
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');
        readfile($path);
        @unlink($path);
        exit;
    }

    /**
     * @param string $filePath Output path.
     * @param array<int,array<int,mixed>> $rows Worksheet rows.
     * @param string $sheetName Worksheet title.
     * @param array<string,mixed> $options Supported: title_rows, header_rows, total_rows, freeze_rows.
     * @throws Exception
     */
    public static function save(string $filePath, array $rows, string $sheetName = 'Sheet1', array $options = []): void
    {
        self::saveBook($filePath, [['name' => $sheetName, 'rows' => $rows, 'options' => $options]]);
    }

    /**
     * Several worksheets in one workbook. Each sheet keeps its own rows and options (protect, merge_cells,
     * column widths), so one file can carry a tab per subject. Sheet names are made legal and unique.
     * @param array<int,array<string,mixed>> $sheets [['name' => …, 'rows' => [[…]], 'options' => […]], …]
     * @throws Exception
     */
    public static function saveBook(string $filePath, array $sheets): void
    {
        $sheets = array_values(array_filter($sheets, 'is_array'));
        if (!$sheets) $sheets = [['name' => 'Sheet1', 'rows' => [['']], 'options' => []]];
        $names = self::sheetNames(array_map(fn($s) => (string)($s['name'] ?? ''), $sheets));
        $entries = [
            '[Content_Types].xml'         => self::contentTypesXml(count($sheets)),
            '_rels/.rels'                 => self::rootRelsXml(),
            'docProps/app.xml'            => self::appXml(),
            'docProps/core.xml'           => self::coreXml(gmdate('Y-m-d\TH:i:s\Z')),
            'xl/workbook.xml'             => self::workbookXml($names),
            'xl/_rels/workbook.xml.rels'  => self::workbookRelsXml(count($sheets)),
            'xl/styles.xml'               => self::stylesXml(),
        ];
        foreach ($sheets as $i => $s) {
            $entries['xl/worksheets/sheet' . ($i + 1) . '.xml'] = self::sheetXml((array)($s['rows'] ?? []), (array)($s['options'] ?? []));
        }
        self::writeZip($filePath, $entries);
    }

    /** Excel sheet names: at most 31 characters, none of [ ] : * ? / \, never empty and never repeated. */
    private static function sheetNames(array $names): array
    {
        $out = []; $seen = [];
        foreach ($names as $i => $name) {
            $clean = trim(preg_replace('/[\[\]:\*\?\/\\\\]/u', ' ', (string)$name) ?? '');
            $clean = mb_substr($clean, 0, 31);
            if ($clean === '') $clean = 'Sheet' . ($i + 1);
            $try = $clean; $k = 2;
            while (isset($seen[mb_strtolower($try)])) {
                $suffix = '_' . $k++;
                $try = mb_substr($clean, 0, 31 - mb_strlen($suffix)) . $suffix;
            }
            $seen[mb_strtolower($try)] = true;
            $out[] = $try;
        }
        return $out;
    }

    /**
     * Write a ZIP archive without the php 'zip' extension (which shared hosting and
     * this XAMPP do not always enable): local headers + central directory + EOCD,
     * entries deflated with gzdeflate(). An .xlsx is exactly such an archive.
     */
    private static function writeZip(string $filePath, array $entries): void
    {
        $fh = @fopen($filePath, 'wb');
        if (!$fh) throw new Exception('Unable to open XLSX archive for writing.');
        $central = ''; $offset = 0; $count = 0;
        $t = time(); $dosTime = ((int)date('H', $t) << 11) | ((int)date('i', $t) << 5) | ((int)date('s', $t) >> 1);
        $dosDate = (((int)date('Y', $t) - 1980) << 9) | ((int)date('n', $t) << 5) | (int)date('j', $t);
        foreach ($entries as $name => $data) {
            $crc = crc32($data); $size = strlen($data);
            $comp = gzdeflate($data, 6); $method = 8;
            if ($comp === false || strlen($comp) >= $size) { $comp = $data; $method = 0; }
            $csize = strlen($comp);
            $local = "PK" . pack('vvvvvVVVvv', 20, 0x0800, $method, $dosTime, $dosDate, $crc, $csize, $size, strlen($name), 0) . $name;
            fwrite($fh, $local); fwrite($fh, $comp);
            $central .= "PK" . pack('vvvvvvVVVvvvvvVV', 20, 20, 0x0800, $method, $dosTime, $dosDate, $crc, $csize, $size, strlen($name), 0, 0, 0, 0, 0, $offset) . $name;
            $offset += strlen($local) + $csize; $count++;
        }
        fwrite($fh, $central);
        fwrite($fh, "PK" . pack('vvvvVVv', 0, 0, $count, $count, strlen($central), $offset, 0));
        fclose($fh);
    }

    public static function columnName(int $colNumber): string
    {
        return self::colName($colNumber);
    }

    private static function sheetXml(array $rows, array $options): string
    {
        if (empty($rows)) {
            $rows = [['']];
        }

        $rowCount = count($rows);
        $maxCol = 1;
        foreach ($rows as $row) {
            $maxCol = max($maxCol, count($row));
        }

        $lastCell = self::colName($maxCol) . $rowCount;
        $titleRows = max(0, (int)($options['title_rows'] ?? 0));
        $headerRows = max(0, (int)($options['header_rows'] ?? 1));
        $totalRows = max(0, (int)($options['total_rows'] ?? 0));
        $freezeRows = max(0, (int)($options['freeze_rows'] ?? ($titleRows + $headerRows)));

        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' .
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' .
            '<dimension ref="A1:' . $lastCell . '"/>';

        if ($freezeRows > 0 && $rowCount > $freezeRows) {
            $topLeft = 'A' . ($freezeRows + 1);
            $xml .= '<sheetViews><sheetView workbookViewId="0"><pane ySplit="' . $freezeRows .
                '" topLeftCell="' . $topLeft . '" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>';
        } else {
            $xml .= '<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
        }

        $unlocked = (!empty($options['protect']) && isset($options['unlocked_cols'])) ? array_map('intval', (array)$options['unlocked_cols']) : null;
        $bands = isset($options['band_cols']) ? array_map('intval', (array)$options['band_cols']) : [];
        $xml .= '<sheetFormatPr defaultRowHeight="15"/>' . self::colsXml($rows, $maxCol, $titleRows, (int)($options['max_col_width'] ?? 30)) . '<sheetData>';

        foreach ($rows as $rIdx => $row) {
            $rowNumber = $rIdx + 1;
            $style = self::rowStyle($rowNumber, $rowCount, $titleRows, $headerRows, $totalRows);
            $rowOpen = '<row r="' . $rowNumber . '">';
            $dataRow = $style === 0;
            $lines = 1;
            foreach ($row as $v) $lines = max($lines, substr_count((string)$v, "\n") + 1);
            $xml .= $lines > 1 ? '<row r="' . $rowNumber . '" ht="' . (14 * $lines + 4) . '" customHeight="1">' : $rowOpen;
            for ($cIdx = 0; $cIdx < $maxCol; $cIdx++) {
                $s = ($dataRow && $unlocked !== null) ? (in_array($cIdx + 1, $unlocked, true) ? 4 : 5) : $style;
                $band = $bands[$cIdx + 1] ?? 0;
                if ($band) {
                    if ($dataRow && $unlocked === null) $s = $band === 1 ? 7 : 8;               // tinted data cell
                    elseif ($style === 1) $s = $band === 1 ? 9 : 10;                            // tinted heading
                }
                $xml .= self::cellXml($cIdx + 1, $rowNumber, $row[$cIdx] ?? '', $s);
            }
            $xml .= '</row>';
        }

        $xml .= '</sheetData>';

        // Locked sheet: only the columns in unlocked_cols can be typed in (stops the key columns being edited by mistake).
        if (!empty($options['protect'])) $xml .= '<sheetProtection sheet="1" objects="1" scenarios="1" formatCells="0" formatColumns="0" formatRows="0" sort="0" autoFilter="0"/>';

        if (!empty($options['merge_cells']) && is_array($options['merge_cells'])) {
            $merges = array_values(array_filter(array_map('strval', $options['merge_cells'])));
            if (!empty($merges)) {
                $xml .= '<mergeCells count="' . count($merges) . '">';
                foreach ($merges as $ref) {
                    $xml .= '<mergeCell ref="' . self::escapeAttr($ref) . '"/>';
                }
                $xml .= '</mergeCells>';
            }
        }

        $xml .= '<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>' .
            '</worksheet>';

        return $xml;
    }

    private static function rowStyle(int $rowNumber, int $rowCount, int $titleRows, int $headerRows, int $totalRows): int
    {
        if ($titleRows > 0 && $rowNumber <= $titleRows) {
            return $rowNumber === 1 ? 2 : 6;
        }
        if ($headerRows > 0 && $rowNumber <= ($titleRows + $headerRows)) {
            return 1;
        }
        if ($totalRows > 0 && $rowNumber > ($rowCount - $totalRows)) {
            return 3;
        }
        return 0;
    }

    private static function cellXml(int $colNumber, int $rowNumber, $value, int $style): string
    {
        $ref = self::colName($colNumber) . $rowNumber;
        $styleAttr = $style > 0 ? ' s="' . $style . '"' : '';

        if ($value === null || $value === '') {
            return '<c r="' . $ref . '"' . $styleAttr . '/>';
        }

        if (is_bool($value)) {
            return '<c r="' . $ref . '" t="b"' . $styleAttr . '><v>' . ($value ? '1' : '0') . '</v></c>';
        }

        if ((is_int($value) || is_float($value)) && is_finite((float)$value)) {
            return '<c r="' . $ref . '"' . $styleAttr . '><v>' . self::escapeText((string)$value) . '</v></c>';
        }

        $text = self::escapeText(self::cleanString((string)$value));
        return '<c r="' . $ref . '" t="inlineStr"' . $styleAttr . '><is><t xml:space="preserve">' . $text . '</t></is></c>';
    }

    /**
     * Column widths from the content: title rows are skipped (they are merged banners and would
     * stretch column A), and a heading broken over several lines counts by its longest line.
     */
    private static function colsXml(array $rows, int $maxCol, int $titleRows = 0, int $maxWidth = 30): string
    {
        $widths = array_fill(0, $maxCol, 5);
        foreach ($rows as $rIdx => $row) {
            if ($rIdx < $titleRows) continue;
            for ($i = 0; $i < $maxCol; $i++) {
                $longest = 0;
                foreach (explode("\n", (string)($row[$i] ?? '')) as $line) {
                    $len = function_exists('mb_strlen') ? mb_strlen($line, 'UTF-8') : strlen($line);
                    $longest = max($longest, $len);
                }
                $widths[$i] = max($widths[$i], min($maxWidth, $longest + 2));
            }
        }

        $xml = '<cols>';
        foreach ($widths as $i => $width) {
            $col = $i + 1;
            $xml .= '<col min="' . $col . '" max="' . $col . '" width="' . $width . '" customWidth="1"/>';
        }
        return $xml . '</cols>';
    }

    private static function colName(int $colNumber): string
    {
        $name = '';
        while ($colNumber > 0) {
            $mod = ($colNumber - 1) % 26;
            $name = chr(65 + $mod) . $name;
            $colNumber = (int)(($colNumber - $mod) / 26);
        }
        return $name;
    }

    private static function safeFilename(string $filename): string
    {
        $filename = basename(str_replace('\\', '/', $filename));
        $filename = preg_replace('/[\r\n"]+/', '_', $filename);
        if (!preg_match('/\.xlsx$/i', $filename)) {
            $filename .= '.xlsx';
        }
        return $filename ?: 'export.xlsx';
    }

    private static function cleanString(string $text): string
    {
        return preg_replace('/[^\P{C}\t\r\n]/u', '', $text) ?? $text;
    }

    private static function escapeText(string $text): string
    {
        return htmlspecialchars($text, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    private static function escapeAttr(string $text): string
    {
        return htmlspecialchars($text, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }

    private static function contentTypesXml(int $sheets = 1): string
    {
        $overrides = '';
        for ($i = 1; $i <= max(1, $sheets); $i++) {
            $overrides .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' .
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' .
            '<Default Extension="xml" ContentType="application/xml"/>' .
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>' .
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>' .
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' .
            $overrides .
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' .
            '</Types>';
    }

    private static function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' .
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>' .
            '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>' .
            '</Relationships>';
    }

    private static function workbookRelsXml(int $sheets = 1): string
    {
        $sheets = max(1, $sheets); $rels = '';
        for ($i = 1; $i <= $sheets; $i++) {
            $rels .= '<Relationship Id="rId' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' .
            $rels .
            '<Relationship Id="rId' . ($sheets + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' .
            '</Relationships>';
    }

    /** @param array<int,string> $names sheet titles, already cleaned by sheetNames() */
    private static function workbookXml(array $names): string
    {
        if (!$names) $names = ['Sheet1'];
        $sheets = '';
        foreach ($names as $i => $name) {
            $sheets .= '<sheet name="' . self::escapeAttr($name) . '" sheetId="' . ($i + 1) . '" r:id="rId' . ($i + 1) . '"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" ' .
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' .
            '<sheets>' . $sheets . '</sheets>' .
            '</workbook>';
    }

    private static function stylesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' .
            '<fonts count="5">' .
            '<font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>' .
            '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>' .
            '<font><b/><sz val="16"/><color rgb="FF003366"/><name val="Calibri"/><family val="2"/></font>' .
            '<font><b/><sz val="11"/><color rgb="FF003366"/><name val="Calibri"/><family val="2"/></font>' .
            '<font><sz val="11"/><color rgb="FF555555"/><name val="Calibri"/><family val="2"/></font>' .
            '</fonts>' .
            '<fills count="10">' .
            '<fill><patternFill patternType="none"/></fill>' .
            '<fill><patternFill patternType="gray125"/></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FF003366"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F4FF"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFFDE7"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF2F2F2"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF2FB"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFDF3E8"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FF17548A"/><bgColor indexed="64"/></patternFill></fill>' .
            '<fill><patternFill patternType="solid"><fgColor rgb="FF8A5A17"/><bgColor indexed="64"/></patternFill></fill>' .
            '</fills>' .
            '<borders count="2">' .
            '<border><left/><right/><top/><bottom/><diagonal/></border>' .
            '<border><left style="thin"><color rgb="FFBFC9D4"/></left><right style="thin"><color rgb="FFBFC9D4"/></right><top style="thin"><color rgb="FFBFC9D4"/></top><bottom style="thin"><color rgb="FFBFC9D4"/></bottom><diagonal/></border>' .
            '</borders>' .
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' .
            '<cellXfs count="11">' .
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' .
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' .
            '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' .
            '<xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' .
            '<xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1" applyProtection="1"><alignment horizontal="center"/><protection locked="0"/></xf>' .
            '<xf numFmtId="0" fontId="4" fillId="5" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyProtection="1"><protection locked="1"/></xf>' .
            '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>' .
            '<xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf>' .
            '<xf numFmtId="0" fontId="0" fillId="7" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center"/></xf>' .
            '<xf numFmtId="0" fontId="1" fillId="8" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' .
            '<xf numFmtId="0" fontId="1" fillId="9" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>' .
            '</cellXfs>' .
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' .
            '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/>' .
            '</styleSheet>';
    }

    private static function appXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" ' .
            'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">' .
            '<Application>Codex School Export</Application></Properties>';
    }

    private static function coreXml(string $created): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' .
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" ' .
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" ' .
            'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' .
            '<dc:creator>School Management System</dc:creator><cp:lastModifiedBy>School Management System</cp:lastModifiedBy>' .
            '<dcterms:created xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:created>' .
            '<dcterms:modified xsi:type="dcterms:W3CDTF">' . $created . '</dcterms:modified>' .
            '</cp:coreProperties>';
    }
}

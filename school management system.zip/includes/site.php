<?php
/**
 * The public website's one layout and the data every page of it reads. Pages live in the project root and call
 * site_page() for the top and site_footer() for the bottom; nothing here is reachable on its own.
 *
 * The teacher list reads a fixed set of columns from staff and nothing else: that table also holds Aadhaar,
 * PAN, bank details, phone numbers and addresses, none of which may ever reach a public page.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/misc_helper.php';
require_once __DIR__ . '/admission_helper.php';

if (!function_exists('h')) { function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); } }

/** The menu, in order: file => [label, key the page passes as active]. */
const SITE_NAV = [
    'index.php'    => 'Home',
    'about.php'    => 'About',
    'teachers.php' => 'Teachers',
    'notices.php'  => 'Notices',
    'gallery.php'  => 'Gallery',
    'result.php'   => 'Results',
    'contact.php'  => 'Contact',
];

/** Everything the layout and the home page show about the school, with a sensible word where nothing is set. */
function site_data(): array
{
    static $d = null;
    if ($d !== null) return $d;
    $school = db_get_row('SELECT * FROM school_settings WHERE id = 1') ?: [];
    $web = website_settings();
    $pick = fn(string ...$v) => current(array_filter(array_map('trim', array_map('strval', $v)), fn($x) => $x !== '')) ?: '';

    $adm = adm_settings();
    $reason = adm_closed_reason($adm);
    $d = [
        'name'      => $pick($school['school_name'] ?? '', 'Our School'),
        'short'     => $pick(preg_replace('/\s*\(.*\)\s*$/', '', (string)($school['school_name'] ?? '')), 'Our School'),
        'motto'     => $pick($web['motto'] ?? ''),
        'since'     => (int)($school['established_year'] ?? 0),
        'hero_title'    => $pick($web['hero_title'] ?? '') === 'Welcome To Our School' ? '' : $pick($web['hero_title'] ?? ''),
        'hero_subtitle' => $pick($web['hero_subtitle'] ?? '') === 'Education For Better Future' ? '' : $pick($web['hero_subtitle'] ?? ''),
        'about'     => $pick($web['about_school'] ?? ''),
        'message'   => $pick($web['headmaster_message'] ?? ''),
        'hoi'       => $pick($web['hoi_name'] ?? '', $school['hoi_name'] ?? ''),
        'address'   => $pick($web['contact_address'] ?? '', $school['school_address'] ?? ''),
        'phone'     => $pick($web['contact_phone'] ?? '', $school['phone'] ?? ''),
        'email'     => $pick($web['contact_email'] ?? '', $school['email'] ?? ''),
        'map'       => $pick($web['contact_map_url'] ?? ''),
        'udise'     => $pick($school['udise_code'] ?? ''),
        'logo'      => !empty($school['logo']) ? 'uploads/' . $school['logo'] : '',
        'hero'      => !empty($web['hero_image']) && is_file(__DIR__ . '/../uploads/' . basename($web['hero_image'])) ? 'uploads/' . $web['hero_image'] : '',
        'hoi_photo' => !empty($web['hoi_photo']) && is_file(__DIR__ . '/../uploads/' . basename($web['hoi_photo'])) ? 'uploads/' . $web['hoi_photo'] : '',
        'about_img' => !empty($web['about_image']) && is_file(__DIR__ . '/../uploads/' . basename($web['about_image'])) ? 'uploads/' . $web['about_image'] : '',
        'social'    => array_filter(['facebook' => $web['facebook_url'] ?? '', 'youtube' => $web['youtube_url'] ?? '', 'instagram' => $web['instagram_url'] ?? '',
            'x-twitter' => $web['twitter_url'] ?? '', 'linkedin' => $web['linkedin_url'] ?? ''], fn($u) => $u !== '' && $u !== '#'),
        'meta_title' => $pick($web['meta_title'] ?? ''),
        'meta_desc'  => $pick($web['meta_description'] ?? ''),
        'meta_keys'  => $pick($web['meta_keywords'] ?? ''),
        'footer'     => $pick($web['footer_text'] ?? ''),
        'copyright'  => $pick($web['footer_copyright'] ?? ''),
        'adm'        => $adm,
        'adm_shown'  => !empty($adm['admission_open']),
        'adm_open'   => $reason === '',
        'adm_reason' => $reason,
        'adm_classes'=> $reason === '' ? adm_open_classes((int)$adm['admission_session_id']) : [],
        'adm_session'=> (int)$adm['admission_session_id'] ? adm_session_name((int)$adm['admission_session_id']) : '',
    ];
    return $d;
}

/** "BENGALI" reads "Bengali"; "M.A., B.ED" is left as written. */
function site_title_case(string $s): string
{
    $s = trim($s);
    return $s === mb_strtoupper($s) ? mb_convert_case(mb_strtolower($s), MB_CASE_TITLE) : $s;
}

/** Two letters for a face that has no photograph. */
function site_initials(string $name): string
{
    $parts = preg_split('/[\s.]+/', trim(preg_replace('/^(md|sk|mst|mr|mrs|ms|dr|smt|sri)\.?\s+/i', '', $name)), -1, PREG_SPLIT_NO_EMPTY);
    $first = mb_substr($parts[0] ?? '?', 0, 1);
    $last = count($parts) > 1 ? mb_substr(end($parts), 0, 1) : '';
    return mb_strtoupper($first . $last);
}

/** A round face: the photograph when there is one, otherwise the initials. */
function site_avatar(string $name, string $photo_url = '', string $extra = ''): string
{
    if ($photo_url !== '') return '<img class="avatar' . h($extra) . '" src="' . h($photo_url) . '" alt="' . h($name) . '" loading="lazy">';
    return '<div class="avatar' . h($extra) . '" aria-hidden="true">' . h(site_initials($name)) . '</div>';
}

/** Order of the posts on the teacher page: the head first. */
function site_post_rank(string $post): int
{
    $p = strtolower($post);
    if (preg_match('/^(head ?master|head ?mistress|headmaster|teacher.in.charge|principal)/', $p)) return 0;
    if (str_contains($p, 'assistant head')) return 1;
    if (str_contains($p, 'assistant teacher')) return 2;
    if (str_contains($p, 'para')) return 4;
    return 3;
}

/**
 * The teachers the website may show — name, post, subject, qualification, year they joined and photograph,
 * and nothing more. Only teaching staff still in service whose card is switched on in Edit Staff.
 */
function site_teachers(): array
{
    static $rows = null;
    if ($rows !== null) return $rows;
    $rows = db_get_all("SELECT id, staff_name, designation, subject_name, qualification, YEAR(date_of_joining) since, photo
        FROM staff
        WHERE staff_type = 'Teaching' AND (service_status = 'Active' OR service_status IS NULL) AND show_on_website = 1
        ORDER BY staff_name");
    foreach ($rows as $i => $r) {
        $rows[$i]['subject'] = site_title_case((string)$r['subject_name']) ?: 'General';
        $rows[$i]['post'] = site_title_case((string)$r['designation']) ?: 'Teacher';
        $rows[$i]['photo_url'] = !empty($r['photo']) && is_file(__DIR__ . '/../uploads/staff/' . basename($r['photo'])) ? 'uploads/staff/' . rawurlencode(basename($r['photo'])) : '';
        unset($rows[$i]['photo'], $rows[$i]['subject_name'], $rows[$i]['designation']);
    }
    usort($rows, fn($a, $b) => [site_post_rank($a['post']), $a['subject'], $a['staff_name']] <=> [site_post_rank($b['post']), $b['subject'], $b['staff_name']]);
    return $rows;
}

/** The figures in the band under the banner. */
function site_counts(): array
{
    $session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
    $students = $session ? (int)(db_get_row("SELECT COUNT(*) n FROM student_academic_history h JOIN students s ON s.id = h.student_id
        WHERE h.session_id = ? AND h.student_status = 'Active' AND s.student_status = 'Active'", 'i', $session)['n'] ?? 0) : 0;
    $classes = $session ? (int)(db_get_row("SELECT COUNT(DISTINCT class_id) n FROM student_academic_history WHERE session_id = ? AND student_status = 'Active'", 'i', $session)['n'] ?? 0) : 0;
    return ['students' => $students, 'teachers' => count(site_teachers()), 'classes' => $classes];
}

/** Published notices whose day has come, newest first. */
function site_notices(int $limit, int $offset = 0, string $search = ''): array
{
    $where = NOTICE_LIVE;
    $types = '';
    $params = [];
    if ($search !== '') {
        $where .= ' AND (notice_title LIKE ? OR notice_details LIKE ?)';
        $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
        $types = 'ss';
        $params = [$like, $like];
    }
    $total = (int)(db_get_row("SELECT COUNT(*) n FROM notices WHERE $where", $types, ...$params)['n'] ?? 0);
    $rows = db_get_all("SELECT id, notice_title, notice_details, publish_date, attachment FROM notices WHERE $where
        ORDER BY publish_date DESC, id DESC LIMIT " . max(1, $limit) . ' OFFSET ' . max(0, $offset), $types, ...$params);
    return [$rows, $total];
}

/** Photographs, newest first. */
function site_gallery(int $limit, int $offset = 0): array
{
    $total = (int)(db_get_row('SELECT COUNT(*) n FROM gallery')['n'] ?? 0);
    $rows = db_get_all('SELECT id, title, photo FROM gallery ORDER BY id DESC LIMIT ' . max(1, $limit) . ' OFFSET ' . max(0, $offset));
    return [$rows, $total];
}

/** The next holidays from today. */
function site_upcoming_holidays(int $limit): array
{
    return db_get_all('SELECT holiday_name, holiday_type, holiday_date, start_date, end_date FROM holidays
        WHERE COALESCE(end_date, holiday_date) >= CURDATE()
        ORDER BY COALESCE(start_date, holiday_date) LIMIT ' . max(1, $limit));
}

/** A date block: day number over a short month. */
function site_date_block(?string $date): string
{
    if (!$date || !app_valid_date($date)) return '<div class="date"><b>–</b><span>&nbsp;</span></div>';
    return '<div class="date"><b>' . date('j', strtotime($date)) . '</b><span>' . date('M', strtotime($date)) . '</span></div>';
}

/** Page numbers under a list. */
function site_pager(int $page, int $pages, callable $link): string
{
    if ($pages <= 1) return '';
    $out = '<nav class="pager" aria-label="Pages">';
    if ($page > 1) $out .= '<a href="' . h($link($page - 1)) . '" aria-label="Previous page"><i class="fas fa-angle-left"></i></a>';
    for ($p = max(1, $page - 2); $p <= min($pages, $page + 2); $p++) {
        $out .= $p === $page ? '<span class="on" aria-current="page">' . $p . '</span>' : '<a href="' . h($link($p)) . '">' . $p . '</a>';
    }
    if ($page < $pages) $out .= '<a href="' . h($link($page + 1)) . '" aria-label="Next page"><i class="fas fa-angle-right"></i></a>';
    return $out . '</nav>';
}

/** Is there a page at this path? Keeps the menu free of links that would lead nowhere. */
function site_has(string $path): bool
{
    return is_file(__DIR__ . '/../' . $path);
}

/** The fonts, the icons and the header-footer stylesheet — what a page needs to wear the site's header. */
function site_chrome_links(): void
{
    $d = site_data(); ?>
<link rel="icon" href="<?php echo h($d['logo']); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/css/site-chrome.css?v=<?php echo (int)@filemtime(__DIR__ . '/../assets/css/site-chrome.css'); ?>">
<?php
}

/** The strip at the top and the header with the menu. $active is a file name from SITE_NAV. */
function site_header(string $active = ''): void
{
    $d = site_data(); ?>
<a class="skip" href="#main">Skip to the content</a>
<div class="topstrip">
    <div class="shell">
        <div class="bits">
            <?php if ($d['phone'] !== ''): ?><a href="tel:<?php echo h(preg_replace('/[^0-9+]/', '', $d['phone'])); ?>"><i class="fas fa-phone"></i><?php echo h($d['phone']); ?></a><?php endif; ?>
            <?php if ($d['email'] !== ''): ?><a href="mailto:<?php echo h($d['email']); ?>" class="hide-sm"><i class="fas fa-envelope"></i><?php echo h($d['email']); ?></a><?php endif; ?>
            <?php if ($d['udise'] !== ''): ?><span class="hide-sm"><i class="fas fa-hashtag"></i>UDISE <?php echo h($d['udise']); ?></span><?php endif; ?>
        </div>
        <div class="bits">
            <a href="admission_status.php"><i class="fas fa-magnifying-glass"></i>Application status</a>
            <a href="holidays.php" class="hide-sm"><i class="fas fa-calendar-days"></i>Holidays</a>
        </div>
    </div>
</div>
<header class="site-header">
    <div class="shell">
        <a class="brand" href="index.php">
            <?php if ($d['logo'] !== ''): ?><img src="<?php echo h($d['logo']); ?>" alt=""><?php endif; ?>
            <span><b><?php echo h($d['name']); ?></b><?php if ($d['since']): ?><small>Estd. <?php echo (int)$d['since']; ?><?php echo $d['udise'] !== '' ? ' · UDISE ' . h($d['udise']) : ''; ?></small><?php endif; ?></span>
        </a>
        <button class="burger" type="button" aria-label="Menu" aria-expanded="false"><i class="fas fa-bars"></i></button>
        <nav class="nav" aria-label="Main">
            <?php foreach (SITE_NAV as $file => $label): if (!site_has($file)) continue; ?>
                <a href="<?php echo h($file); ?>" class="<?php echo $file === $active ? 'on' : ''; ?>"<?php echo $file === $active ? ' aria-current="page"' : ''; ?>><?php echo h($label); ?></a>
            <?php endforeach; ?>
            <div class="drop">
                <button type="button" aria-expanded="false" aria-haspopup="true">Login <i class="fas fa-angle-down"></i></button>
                <div class="menu">
                    <a href="student/login.php"><i class="fas fa-user-graduate"></i> Student</a>
                    <a href="teacher/login.php"><i class="fas fa-chalkboard-user"></i> Teacher</a>
                    <a href="admin/login.php"><i class="fas fa-user-shield"></i> Office</a>
                    <?php if (site_has('centre/login.php')): ?><a href="centre/login.php"><i class="fas fa-store"></i> Application centre</a><?php endif; ?>
                </div>
            </div>
            <?php if ($d['adm_shown']): ?><a href="admission.php" class="apply<?php echo $active === 'admission.php' ? ' on' : ''; ?>"><i class="fas fa-pen-to-square"></i> Admission</a><?php endif; ?>
        </nav>
    </div>
</header>
<?php
}

/** A whole page's top: <head> with both stylesheets, the header, and the opening of <main>. */
function site_page(string $title, string $active = '', string $description = ''): void
{
    $d = site_data();
    $full = $title === '' ? ($d['meta_title'] ?: $d['name']) : $title . ' — ' . $d['name'];
    $desc = $description !== '' ? $description : ($d['meta_desc'] ?: $d['name'] . ($d['since'] ? ', since ' . $d['since'] : '') . '. ' . $d['address']);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo h($full); ?></title>
<meta name="description" content="<?php echo h(mb_substr($desc, 0, 300)); ?>">
<?php if ($d['meta_keys'] !== ''): ?><meta name="keywords" content="<?php echo h($d['meta_keys']); ?>"><?php endif; ?>
<meta property="og:title" content="<?php echo h($full); ?>">
<meta property="og:description" content="<?php echo h(mb_substr($desc, 0, 300)); ?>">
<meta property="og:image" content="<?php echo h($d['hero'] ?: $d['logo']); ?>">
<meta property="og:type" content="website">
<meta name="theme-color" content="#2a2886">
<?php site_chrome_links(); ?>
<link rel="stylesheet" href="assets/css/site.css?v=<?php echo (int)@filemtime(__DIR__ . '/../assets/css/site.css'); ?>">
</head>
<body>
<?php site_header($active); ?>
<main id="main">
<?php
}

/** The band at the top of every page but the home page. */
function site_band(string $title, string $lead = '', string $crumb = ''): void
{ ?>
<section class="band">
    <div class="wrap">
        <div class="crumbs"><a href="index.php">Home</a> &nbsp;/&nbsp; <?php echo h($crumb !== '' ? $crumb : $title); ?></div>
        <h1><?php echo h($title); ?></h1>
        <?php if ($lead !== ''): ?><p><?php echo h($lead); ?></p><?php endif; ?>
    </div>
</section>
<?php }

/** The foot of the site and its script. A page that wears only the header and footer passes $full = false. */
function site_footer_block(): void
{
    $d = site_data(); ?>
<footer class="site-footer">
    <div class="shell cols">
        <div class="about">
            <?php if ($d['logo'] !== ''): ?><img src="<?php echo h($d['logo']); ?>" alt=""><?php endif; ?>
            <b><?php echo h($d['name']); ?></b>
            <?php if ($d['motto'] !== ''): ?><p style="font-style:italic"><?php echo h($d['motto']); ?></p><?php endif; ?>
            <?php if ($d['footer'] !== ''): ?><p><?php echo h($d['footer']); ?></p><?php endif; ?>
            <?php if ($d['social']): ?>
            <div class="social">
                <?php foreach ($d['social'] as $icon => $url): ?><a href="<?php echo h($url); ?>" target="_blank" rel="noopener" aria-label="<?php echo h(ucfirst($icon)); ?>"><i class="fab fa-<?php echo h($icon); ?>"></i></a><?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <div>
            <h4>The school</h4>
            <ul>
                <li><a href="about.php">About us</a></li>
                <li><a href="teachers.php">Our teachers</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="holidays.php">Holiday list</a></li>
            </ul>
        </div>
        <div>
            <h4>For parents</h4>
            <ul>
                <li><a href="notices.php">Notices</a></li>
                <li><a href="result.php">Check a result</a></li>
                <li><a href="admission.php">Admission</a></li>
                <li><a href="admission_status.php">Application status</a></li>
            </ul>
        </div>
        <div>
            <h4>Reach us</h4>
            <?php if ($d['address'] !== ''): ?><div class="line"><i class="fas fa-location-dot"></i><span><?php echo h($d['address']); ?></span></div><?php endif; ?>
            <?php if ($d['phone'] !== ''): ?><div class="line"><i class="fas fa-phone"></i><a href="tel:<?php echo h(preg_replace('/[^0-9+]/', '', $d['phone'])); ?>"><?php echo h($d['phone']); ?></a></div><?php endif; ?>
            <?php if ($d['email'] !== ''): ?><div class="line"><i class="fas fa-envelope"></i><a href="mailto:<?php echo h($d['email']); ?>"><?php echo h($d['email']); ?></a></div><?php endif; ?>
            <div class="line"><i class="fas fa-paper-plane"></i><a href="contact.php">Write to the school</a></div>
        </div>
    </div>
    <div class="bottom">
        <div class="shell">
            <span><?php echo h($d['copyright'] !== '' ? $d['copyright'] : '© ' . date('Y') . ' ' . $d['name']); ?></span>
            <span><?php echo $d['udise'] !== '' ? 'UDISE ' . h($d['udise']) : ''; ?></span>
        </div>
    </div>
</footer>
<script src="assets/js/site.js?v=<?php echo (int)@filemtime(__DIR__ . '/../assets/js/site.js'); ?>"></script>
<?php
}

/** The end of a whole page: </main>, the footer, the photo viewer, and the closing tags. */
function site_footer(): void
{ ?>
</main>
<div class="lightbox" role="dialog" aria-modal="true" aria-label="Photograph">
    <button type="button" class="x" aria-label="Close"><i class="fas fa-xmark"></i></button>
    <button type="button" class="prev" aria-label="Previous"><i class="fas fa-angle-left"></i></button>
    <img src="" alt="">
    <button type="button" class="next" aria-label="Next"><i class="fas fa-angle-right"></i></button>
    <div class="cap"></div>
</div>
<?php site_footer_block(); ?>
</body>
</html>
<?php
}

/** The classes the school teaches this session, first to last: "V to XII". */
function site_class_range(): string
{
    $session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
    $rows = $session ? db_get_all("SELECT DISTINCT c.class_name, c.sort_order FROM student_academic_history h JOIN classes c ON c.id = h.class_id
        WHERE h.session_id = ? ORDER BY c.sort_order", 'i', $session) : [];
    if (!$rows) return '';
    $first = $rows[0]['class_name'];
    $last = end($rows)['class_name'];
    return $first === $last ? (string)$first : $first . ' to ' . $last;
}

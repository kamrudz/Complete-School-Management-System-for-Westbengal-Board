<?php
/**
 * The Add / Edit Staff form — one include so the two pages stay twins.
 *   staff_form_styles()                    — <style> for <head>
 *   staff_form_render($v, $mode, $errors)  — the form body; $v = field values (old input or the row),
 *                                             $mode = 'add' | 'edit'
 * Compulsory fields are marked with a star and enforced again in staff_validate().
 */
const STAFF_REQUIRED = ['staff_name' => 1, 'short_code' => 1, 'designation' => 1, 'gender' => 1, 'date_of_birth' => 1, 'date_of_joining' => 1, 'mobile' => 1, 'subject_name' => 1];

function sf_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function sf_lbl(string $key, string $text): string { return '<label for="s_' . $key . '">' . $text . (isset(STAFF_REQUIRED[$key]) ? ' <span class="req">*</span>' : '') . '</label>'; }
function sf_input(array $v, string $key, string $type = 'text', string $extra = ''): string {
    return '<input type="' . $type . '" id="s_' . $key . '" name="' . $key . '" value="' . sf_h($v[$key] ?? '') . '"' . (isset(STAFF_REQUIRED[$key]) ? ' required' : '') . ($extra ? ' ' . $extra : '') . '>';
}
function sf_select(array $v, string $key, array $options, string $placeholder = 'Select', string $extra = ''): string {
    $cur = (string)($v[$key] ?? '');
    $o = '<select id="s_' . $key . '" name="' . $key . '"' . (isset(STAFF_REQUIRED[$key]) ? ' required' : '') . ($extra ? ' ' . $extra : '') . '><option value="">' . sf_h($placeholder) . '</option>';
    foreach ($options as $opt) $o .= '<option value="' . sf_h($opt) . '"' . (strcasecmp($cur, $opt) === 0 ? ' selected' : '') . '>' . sf_h($opt) . '</option>';
    return $o . '</select>';
}

function staff_form_styles(): void { ?>
<style>
    .card-head { position: relative; display: flex; align-items: center; gap: 10px; color: #fff; padding: 12px 16px; border-radius: 10px; margin: 22px 0 14px; font-size: 15px; font-weight: 700; box-shadow: 0 4px 12px rgba(31,65,95,.12); overflow: hidden; background: linear-gradient(135deg, var(--a1, #145da0), var(--a2, #1f7ac2)); }
    .card-head::after { content: ''; position: absolute; right: 0; top: 0; width: 38%; height: 100%; background: linear-gradient(90deg, transparent, rgba(255,255,255,.14)); pointer-events: none; }
    .card-head > i:first-child { width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; background: rgba(255,255,255,.18); flex: 0 0 30px; }
    .card-head .hint { margin-left: auto; font-size: 12px; font-weight: 500; color: rgba(255,255,255,.85); }
    .card-post     { --a1: #145da0; --a2: #1f7ac2; }
    .card-personal { --a1: #6a3fb5; --a2: #8757d6; }
    .card-service  { --a1: #c77b18; --a2: #e49a2e; }
    .card-contact  { --a1: #138a72; --a2: #20a486; }
    .card-bank     { --a1: #28708a; --a2: #338eaa; }
    .card-other    { --a1: #4d6178; --a2: #667d96; }
    .grid { display: grid; grid-template-columns: repeat(12, minmax(0, 1fr)); gap: 14px; }
    .grid + .grid { margin-top: 14px; }
    .c2 { grid-column: span 2; } .c3 { grid-column: span 3; } .c4 { grid-column: span 4; } .c6 { grid-column: span 6; } .c8 { grid-column: span 8; } .c12 { grid-column: span 12; }
    .f { display: flex; flex-direction: column; min-width: 0; padding: 12px; background: #fbfdff; border: 1px solid #e2ebf3; border-radius: 10px; box-shadow: 0 2px 7px rgba(30,70,100,.045); transition: border-color .18s, box-shadow .18s; }
    .f[hidden] { display: none; }
    .f:hover { border-color: #cbdbea; } .f:focus-within { border-color: #80add0; box-shadow: 0 0 0 3px rgba(31,122,194,.08); }
    .f label { font-weight: 700; font-size: 12.5px; color: #28455f; margin: 0 0 7px; line-height: 1.35; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .f .req { color: #d9363e; font-weight: 800; }
    .f input:not([type="file"]):not([type="checkbox"]), .f select, .f textarea { box-sizing: border-box; width: 100%; min-height: 41px; padding: 10px 11px; border: 1px solid #cfdde9; border-radius: 7px; background: #fff; color: #20364a; font-size: 13.5px; }
    .f textarea { min-height: 70px; resize: vertical; }
    .f input[type="file"] { font-size: 12.5px; padding: 6px 0; }
    .f input:focus, .f select:focus, .f textarea:focus { outline: none; border-color: #2b78b6; box-shadow: 0 0 0 3px rgba(43,120,182,.10); }
    .f input[readonly] { background: #f1f5f9; color: #4d6178; }
    .f small { font-size: 11.5px; color: #718294; margin-top: 5px; line-height: 1.45; }
    .f .chk { display: flex; align-items: center; gap: 8px; min-height: 41px; font-size: 13.5px; color: #20364a; }
    .f .chk input { width: 18px; height: 18px; accent-color: #145da0; margin: 0; }
    .f .pill { display: inline-flex; align-items: center; min-height: 41px; padding: 0 12px; border-radius: 7px; font-weight: 700; font-size: 13.5px; background: #eaf2fb; color: #1f4e79; }
    .f .pill.nt { background: #f3f0fb; color: #5b3fa0; }
    .upl { display: flex; align-items: center; gap: 10px; } .upl input[type="file"] { flex: 1 1 auto; min-width: 0; }
    .pv { flex: 0 0 auto; height: 64px; width: 64px; object-fit: cover; border: 1px solid #c9d6e2; border-radius: 6px; background: #f6f9fc; }
    .cur { display: flex; align-items: center; gap: 10px; margin-bottom: 6px; } .cur img { height: 64px; width: 64px; object-fit: cover; border: 1px solid #c9d6e2; border-radius: 6px; } .cur .none { color: #8a9aab; font-size: 12.5px; }
    .legend { font-size: 12.5px; color: #6b7d90; margin: -6px 0 6px; } .legend .req { color: #d9363e; font-weight: 800; }
    .alert-danger ul { margin: 0; padding-left: 18px; font-weight: 500; } .alert-danger { align-items: flex-start; }
    .btn-secondary { background: #e6edf3; color: #1f4e79; } .btn-secondary:hover { background: #d5e0ea; }
    .sf-actions { position: sticky; bottom: 0; background: rgba(255,255,255,.96); border-top: 1px solid #e1eaf2; padding: 12px 0; margin-top: 18px; display: flex; gap: 10px; justify-content: flex-end; backdrop-filter: blur(4px); }
    @media (max-width: 1100px) { .c2, .c3 { grid-column: span 4; } .c4 { grid-column: span 6; } }
    @media (max-width: 700px)  { .c2, .c3, .c4, .c6, .c8 { grid-column: span 12; } }
</style>
<?php }

function staff_form_render(array $v, string $mode): void {
    $des = staff_designations(); $type = $v['staff_type'] ?? ($des[$v['designation'] ?? ''][0] ?? 'Teaching');
    $can_login = array_key_exists('can_login', $v) ? (int)$v['can_login'] : 1;
    $on_site = array_key_exists('show_on_website', $v) ? (int)$v['show_on_website'] : 1;
    ?>
    <div class="legend"><span class="req">*</span> compulsory<?php echo $mode === 'add' ? ' — the rest can be filled later from Edit Staff' : ''; ?>.</div>

    <div class="card-head card-post"><i class="fas fa-id-badge"></i> Identity &amp; post <span class="hint">Employee ID = school's own ID · State Govt ID = teacher-portal username</span></div>
    <div class="grid">
        <div class="f c3"><label for="s_employee_id">Employee ID</label>
            <?php if ($mode === 'edit'): ?><input type="text" id="s_employee_id" value="<?php echo sf_h($v['employee_id']); ?>" readonly><input type="hidden" name="employee_id" value="<?php echo sf_h($v['employee_id']); ?>"><small>Fixed once created.</small>
            <?php else: ?><input type="text" id="s_employee_id" value="<?php echo sf_h(staff_next_employee_id()); ?>" readonly><small>Assigned automatically when saved.</small><?php endif; ?></div>
        <div class="f c3"><?php echo sf_lbl('state_govt_id', 'State Govt ID'); ?><?php echo sf_input($v, 'state_govt_id', 'text', 'maxlength="30" placeholder="iOSMS / eHRMS employee ID" style="text-transform:uppercase"'); ?><small>iOSMS / eHRMS employee ID — the <b>portal username</b>; required for portal login, must be unique.</small></div>
        <div class="f c3"><?php echo sf_lbl('national_code', 'National code'); ?><?php echo sf_input($v, 'national_code', 'text', 'maxlength="30" placeholder="UDISE+ teacher code" style="text-transform:uppercase"'); ?><small>UDISE+ teacher code — optional, must be unique.</small></div>
        <div class="f c3"><?php echo sf_lbl('designation', 'Designation'); ?><?php echo sf_select($v, 'designation', array_keys($des), 'Select designation', 'onchange="sfDesignation()"'); ?></div>
    </div>
    <div class="grid">
        <div class="f c6"><?php echo sf_lbl('staff_name', 'Full name'); ?><?php echo sf_input($v, 'staff_name', 'text', 'maxlength="100" placeholder="As per service book"'); ?></div>
        <div class="f c2"><?php echo sf_lbl('short_code', 'Short code'); ?><?php echo sf_input($v, 'short_code', 'text', 'maxlength="6" placeholder="AK" style="text-transform:uppercase"'); ?><small>Shown on the routine.</small></div>
        <div class="f c2"><label>Staff type</label><span class="pill <?php echo $type === 'Non-teaching' ? 'nt' : ''; ?>" id="s_type_pill"><?php echo sf_h($type); ?></span><small>Follows the designation.</small></div>
        <div class="f c2"><label for="s_can_login">Teacher portal login</label><label class="chk"><input type="checkbox" id="s_can_login" name="can_login" value="1" <?php echo $can_login ? 'checked' : ''; ?>> Allowed</label><small>First password: Teacher@&lt;birth year&gt;, to be changed at first login.</small></div>
        <div class="f c2"><label for="s_on_site">School website</label><label class="chk"><input type="checkbox" id="s_on_site" name="show_on_website" value="1" <?php echo $on_site ? 'checked' : ''; ?>> Show on the teacher list</label><small>Name, post, subject, qualification, year joined and photo only — never phone, email or ID numbers.</small></div>
    </div>
    <div class="grid">
        <div class="f c3"><?php echo sf_lbl('subject_name', 'Subject'); ?><?php echo sf_select($v, 'subject_name', staff_subjects(), 'Select subject'); ?><small>Required for teaching staff.</small></div>
        <div class="f c3"><?php echo sf_lbl('academic_section', 'Academic section'); ?><?php echo sf_select($v, 'academic_section', staff_sections()); ?></div>
        <div class="f c3"><?php echo sf_lbl('vacancy_status', 'Post type'); ?><?php echo sf_select($v, 'vacancy_status', staff_vacancy_statuses()); ?></div>
        <div class="f c3"><?php echo sf_lbl('qualification', 'Qualification'); ?><?php echo sf_input($v, 'qualification', 'text', 'maxlength="100" placeholder="M.A., B.Ed."'); ?></div>
    </div>

    <div class="card-head card-personal"><i class="fas fa-user"></i> Personal</div>
    <div class="grid">
        <div class="f c2"><?php echo sf_lbl('date_of_birth', 'Date of birth'); ?><?php echo sf_input($v, 'date_of_birth', 'date', 'onchange="sfRetire()"'); ?></div>
        <div class="f c2"><?php echo sf_lbl('gender', 'Gender'); ?><?php echo sf_select($v, 'gender', ['Male', 'Female', 'Other']); ?></div>
        <div class="f c2"><?php echo sf_lbl('blood_group', 'Blood group'); ?><?php echo sf_select($v, 'blood_group', staff_blood_groups()); ?></div>
        <div class="f c2"><?php echo sf_lbl('religion', 'Religion'); ?><?php echo sf_select($v, 'religion', student_religions()); ?></div>
        <div class="f c2"><?php echo sf_lbl('caste', 'Caste'); ?><?php echo sf_select($v, 'caste', student_castes()); ?></div>
        <div class="f c2"><?php echo sf_lbl('mother_tongue', 'Mother tongue'); ?><?php echo sf_input($v, 'mother_tongue', 'text', 'maxlength="50"'); ?></div>
    </div>
    <div class="grid">
        <div class="f c3"><?php echo sf_lbl('father_name', "Father's name"); ?><?php echo sf_input($v, 'father_name', 'text', 'maxlength="100"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('mother_name', "Mother's name"); ?><?php echo sf_input($v, 'mother_name', 'text', 'maxlength="100"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('marital_status', 'Marital status'); ?><?php echo sf_select($v, 'marital_status', staff_marital_statuses()); ?></div>
        <div class="f c3"><?php echo sf_lbl('spouse_name', "Spouse's name"); ?><?php echo sf_input($v, 'spouse_name', 'text', 'maxlength="100"'); ?></div>
    </div>

    <div class="card-head card-service"><i class="fas fa-briefcase"></i> Service</div>
    <div class="grid">
        <div class="f c2"><?php echo sf_lbl('date_of_joining', 'Joining (school)'); ?><?php echo sf_input($v, 'date_of_joining', 'date'); ?></div>
        <div class="f c2"><?php echo sf_lbl('joining_date_present_post', 'Joining (present post)'); ?><?php echo sf_input($v, 'joining_date_present_post', 'date'); ?></div>
        <div class="f c2"><?php echo sf_lbl('retirement_date', 'Retirement'); ?><?php echo sf_input($v, 'retirement_date', 'date'); ?><small>DOB + 60 yrs, editable.</small></div>
        <div class="f c2"><?php echo sf_lbl('date_of_approval', 'Approval date'); ?><?php echo sf_input($v, 'date_of_approval', 'date'); ?></div>
        <div class="f c4"><?php echo sf_lbl('approval_number', 'Approval number'); ?><?php echo sf_input($v, 'approval_number', 'text', 'maxlength="100"'); ?></div>
    </div>
    <?php if ($mode === 'edit'): ?>
    <div class="grid">
        <div class="f c3"><?php echo sf_lbl('service_status', 'Service status'); ?><?php echo sf_select($v, 'service_status', staff_service_statuses(), 'Active', 'onchange="sfStatus()"'); ?></div>
        <div class="f c3" id="f_status_date"><?php echo sf_lbl('status_date', 'Date of transfer / retirement'); ?><?php echo sf_input($v, 'status_date', 'date'); ?></div>
    </div>
    <?php else: ?><input type="hidden" name="service_status" value="Active"><?php endif; ?>

    <div class="card-head card-contact"><i class="fas fa-address-book"></i> Contact &amp; identity documents</div>
    <div class="grid">
        <div class="f c3"><?php echo sf_lbl('mobile', 'Mobile'); ?><?php echo sf_input($v, 'mobile', 'text', 'inputmode="numeric" maxlength="10" placeholder="10 digits"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('email', 'Email'); ?><?php echo sf_input($v, 'email', 'email', 'maxlength="100"'); ?><small>Also works as the portal username.</small></div>
        <div class="f c2"><?php echo sf_lbl('aadhar_number', 'Aadhaar'); ?><?php echo sf_input($v, 'aadhar_number', 'text', 'inputmode="numeric" maxlength="12" placeholder="12 digits"'); ?></div>
        <div class="f c2"><?php echo sf_lbl('voter_number', 'Voter ID'); ?><?php echo sf_input($v, 'voter_number', 'text', 'maxlength="10" placeholder="ABC1234567" style="text-transform:uppercase"'); ?></div>
        <div class="f c2"><?php echo sf_lbl('pan_number', 'PAN'); ?><?php echo sf_input($v, 'pan_number', 'text', 'maxlength="10" placeholder="ABCDE1234F" style="text-transform:uppercase"'); ?></div>
    </div>
    <div class="grid">
        <div class="f c6"><?php echo sf_lbl('present_address', 'Present address'); ?><textarea id="s_present_address" name="present_address" rows="2"><?php echo sf_h($v['present_address'] ?? ''); ?></textarea></div>
        <div class="f c6"><?php echo sf_lbl('permanent_address', 'Permanent address'); ?><textarea id="s_permanent_address" name="permanent_address" rows="2"><?php echo sf_h($v['permanent_address'] ?? ''); ?></textarea><small><a href="#" onclick="document.getElementById('s_permanent_address').value = document.getElementById('s_present_address').value; return false;">Same as present address</a></small></div>
    </div>

    <div class="card-head card-bank"><i class="fas fa-university"></i> Bank (for salary)</div>
    <div class="grid">
        <div class="f c3"><?php echo sf_lbl('bank_name', 'Bank'); ?><?php echo sf_input($v, 'bank_name', 'text', 'maxlength="100"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('branch_name', 'Branch'); ?><?php echo sf_input($v, 'branch_name', 'text', 'maxlength="100"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('account_number', 'Account number'); ?><?php echo sf_input($v, 'account_number', 'text', 'inputmode="numeric" maxlength="18"'); ?></div>
        <div class="f c3"><?php echo sf_lbl('ifsc_code', 'IFSC'); ?><?php echo sf_input($v, 'ifsc_code', 'text', 'maxlength="11" placeholder="SBIN0001234" style="text-transform:uppercase"'); ?></div>
    </div>

    <div class="card-head card-other"><i class="fas fa-camera"></i> Photo &amp; remarks</div>
    <div class="grid">
        <div class="f c4"><label for="s_photo">Photo</label>
            <?php if ($mode === 'edit'): ?><div class="cur"><?php if (!empty($v['photo'])): ?><img src="<?php echo sf_h(staff_photo_url($v['photo'])); ?>" alt="current photo"><span class="none">current — choose a file only to replace</span><?php else: ?><span class="none">Not uploaded yet</span><?php endif; ?></div><?php endif; ?>
            <div class="upl"><input type="file" id="s_photo" name="photo" accept="image/*" onchange="sfPreview(this)"><img id="s_photo_pv" class="pv" alt="" hidden></div><small>Auto-compressed to ~10 KB, 320 px (used on ID card / routine).</small></div>
        <div class="f c8"><?php echo sf_lbl('remarks', 'Remarks'); ?><textarea id="s_remarks" name="remarks" rows="2" maxlength="1000"><?php echo sf_h($v['remarks'] ?? ''); ?></textarea></div>
    </div>
    <script>
    var SF_DES = <?php echo json_encode($des); ?>;
    function sfDesignation() {
        var d = document.getElementById('s_designation').value, info = SF_DES[d]; if (!info) return;
        var pill = document.getElementById('s_type_pill'); pill.textContent = info[0]; pill.className = 'pill' + (info[0] === 'Non-teaching' ? ' nt' : '');
        document.getElementById('s_can_login').checked = !!info[1];
        var subj = document.getElementById('s_subject_name'); subj.required = info[0] === 'Teaching';
        var star = document.querySelector('label[for="s_subject_name"] .req'); if (star) star.style.display = info[0] === 'Teaching' ? '' : 'none';
    }
    function sfRetire() {
        var dob = document.getElementById('s_date_of_birth').value, r = document.getElementById('s_retirement_date'); if (!dob || r.value) return;
        var d = new Date(dob); if (isNaN(d)) return; d.setFullYear(d.getFullYear() + 60);
        // WB rule of thumb: retire on the last day of the month in which 60 is reached
        var last = new Date(d.getFullYear(), d.getMonth() + 1, 0), p = function (n) { return (n < 10 ? '0' : '') + n; };
        r.value = last.getFullYear() + '-' + p(last.getMonth() + 1) + '-' + p(last.getDate());
    }
    function sfStatus() { var s = document.getElementById('s_service_status'), f = document.getElementById('f_status_date'); if (s && f) f.hidden = s.value === 'Active'; }
    function sfPreview(inp) { var img = document.getElementById('s_photo_pv'); if (inp.files && inp.files[0]) { img.src = URL.createObjectURL(inp.files[0]); img.hidden = false; } }
    sfStatus(); (function () { var d = document.getElementById('s_designation'); if (d.value) { var i = SF_DES[d.value]; document.getElementById('s_subject_name').required = i && i[0] === 'Teaching'; var star = document.querySelector('label[for="s_subject_name"] .req'); if (star) star.style.display = i && i[0] === 'Teaching' ? '' : 'none'; } })();
    </script>
<?php }

<?php
/**
 * Shared helpers for staff / teacher management.
 *
 * Identity: staff.id (int) is the internal key; staff.employee_id is the school's own
 * ID (ULPHS-ST-0001, auto-allocated, UNIQUE, never changes). The teacher-portal username is
 * the State Govt ID (iOSMS / eHRMS employee id); the first password is Teacher@<birth year>.
 * staff_type (Teaching / Non-teaching) follows the designation and decides who can be put
 * on a routine; can_login decides who may use the teacher portal.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/misc_helper.php';

function staff_get_by_id($staff_id) {
    return db_get_row('SELECT * FROM staff WHERE id = ? LIMIT 1', 'i', (int)$staff_id);
}

function staff_get_login_record($staff_id) {
    return db_get_row('SELECT id, staff_name, employee_id, state_govt_id, designation, can_login, service_status, login_password, date_of_birth FROM staff WHERE id = ? LIMIT 1', 'i', (int)$staff_id);
}

/** Teacher@1985 — the first password the office hands out (from the date of birth). */
function staff_default_password(?string $dob): ?string {
    return $dob && preg_match('/^(\d{4})-/', $dob, $m) ? 'Teacher@' . $m[1] : null;
}
/** Set the default password (Teacher@<birth year>) and require a change at first login. */
function staff_set_default_password(int $staff_id, ?string $dob): ?string {
    $pw = staff_default_password($dob);
    if ($pw === null) return null;
    db_update('staff', ['login_password' => password_hash($pw, PASSWORD_DEFAULT), 'pw_must_change' => 1, 'pw_changed_at' => date('Y-m-d H:i:s')], ['id' => $staff_id], 'i');
    return $pw;
}

function staff_update_password($staff_id, $plain_password) {
    $hash = password_hash($plain_password, PASSWORD_DEFAULT);
    if ($hash === false) return false;
    $ok = db_update('staff', ['login_password' => $hash], ['id' => (int)$staff_id], 'i');
    return $ok === false ? false : $hash;
}

/** Does this teacher take at least one routine period in the class (/ section / subject)? */
function teacher_can_access_class_section($teacher_id, $session_id, $class_id, $section_id = 0, $subject_id = 0) {
    $sql = 'SELECT id FROM routine WHERE teacher_id = ? AND session_id = ? AND class_id = ?';
    $types = 'iii';
    $params = [(int)$teacher_id, (int)$session_id, (int)$class_id];
    if ((int)$section_id > 0) { $sql .= ' AND section_id = ?'; $types .= 'i'; $params[] = (int)$section_id; }
    if ((int)$subject_id > 0) { $sql .= ' AND subject_id = ?'; $types .= 'i'; $params[] = (int)$subject_id; }
    $sql .= ' LIMIT 1';
    return (bool) db_get_row($sql, $types, ...$params);
}

// ---------- lists ----------

/** Designation => [staff_type, portal login by default]. */
function staff_designations(): array {
    return [
        'Headmaster'          => ['Teaching', 1],
        'Assistant Headmaster'=> ['Teaching', 1],
        'Teacher-In-Charge'   => ['Teaching', 1],
        'Assistant Teacher'   => ['Teaching', 1],
        'Para Teacher'        => ['Teaching', 1],
        'Librarian'           => ['Non-teaching', 1],
        'Clerk'               => ['Non-teaching', 0],
        'Accountant'          => ['Non-teaching', 0],
        'Group D'             => ['Non-teaching', 0],
    ];
}
function staff_sections(): array { return ['PRIMARY SECTION (I-IV)', 'UPPER PRIMARY SECTION (V-VIII)', 'SECONDARY SECTION (IX-X)', 'HS SECTION (XI-XII)']; }
function staff_subjects(): array {
    return ['AGRICULTURE', 'AGRONOMY', 'ANTHROPOLOGY', 'ARABIC', 'BENGALI', 'BIOLOGICAL SCIENCE', 'CHEMISTRY', 'COMMERCE', 'COMPUTER APPLICATION', 'COMPUTER SCIENCE', 'ECONOMIC GEOGRAPHY', 'ECONOMICS', 'EDUCATION',
        'ENGLISH', 'FINE ARTS & CRAFT', 'FISHERY SCIENCE', 'GEOGRAPHY', 'GEOLOGY', 'GURUMUKHI', 'HINDI', 'HISTORY', 'HOME MANAGEMENT & HOME NURSING', 'HOME SCIENCE', 'MATHEMATICS', 'MUSIC', 'NEPALI', 'NUTRITION', 'ORIYA',
        'PERSIAN', 'PHILOSOPHY', 'PHYSICAL EDUCATION', 'PHYSICS', 'POLITICAL SCIENCE', 'PSYCHOLOGY', 'SANSKRIT', 'SANTALI', 'SOCIOLOGY', 'STATISTICS', 'TELEGU', 'URDU', 'VETERINARY & ANIMAL SCIENCE',
        'SCIENCE', 'LIFE SCIENCE', 'PHYSICAL SCIENCE', 'WORK EDUCATION', 'ENVIRONMENTAL STUDIES', 'N/A'];
}
function staff_vacancy_statuses(): array { return ['Permanent', 'Temporary', 'Contractual', 'Deputation']; }
function staff_service_statuses(): array { return ['Active', 'Transferred', 'Retired', 'Deceased']; }
function staff_marital_statuses(): array { return ['Married', 'Un-Married', 'Widow', 'Widower', 'Divorcee', 'Separate']; }
function staff_blood_groups(): array { return ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']; }

// ---------- employee id ----------

/** ULPHS-ST — school prefix from School Settings (falls back to SCH). */
function staff_id_prefix(): string {
    $p = strtoupper(trim((string)(db_get_row('SELECT student_id_prefix FROM school_settings WHERE id = 1')['student_id_prefix'] ?? '')));
    return ($p !== '' ? $p : 'SCH') . '-ST';
}
function staff_employee_id_valid(string $v): bool { return (bool)preg_match('/^[A-Z0-9_-]{2,30}$/', $v); }
/** Next free ULPHS-ST-NNNN. */
function staff_next_employee_id(): string {
    $prefix = staff_id_prefix() . '-';
    $row = db_get_row('SELECT MAX(CAST(SUBSTRING(employee_id, ?) AS UNSIGNED)) AS n FROM staff WHERE employee_id LIKE ?', 'is', strlen($prefix) + 1, $prefix . '%');
    return $prefix . str_pad((string)((int)($row['n'] ?? 0) + 1), 4, '0', STR_PAD_LEFT);
}

// ---------- validation ----------

/** The editable staff columns, in form order. */
function staff_fields(): array {
    return ['employee_id', 'state_govt_id', 'national_code', 'staff_name', 'short_code', 'designation', 'staff_type', 'can_login', 'show_on_website', 'academic_section', 'subject_name', 'qualification', 'department', 'vacancy_status',
        'date_of_birth', 'gender', 'blood_group', 'religion', 'caste', 'mother_tongue', 'marital_status', 'spouse_name', 'father_name', 'mother_name',
        'date_of_joining', 'joining_date_present_post', 'retirement_date', 'approval_number', 'date_of_approval', 'service_status', 'status_date', 'exclude_from_exam_duty',
        'mobile', 'email', 'present_address', 'permanent_address', 'aadhar_number', 'voter_number', 'pan_number',
        'bank_name', 'branch_name', 'account_number', 'ifsc_code', 'remarks'];
}

/** Read + normalise the staff form. Returns [$data, $errors]. $exclude_id: the row being edited (for uniqueness). */
function staff_validate(array $in, int $exclude_id = 0): array {
    $d = []; $e = [];
    foreach (staff_fields() as $k) $d[$k] = trim((string)($in[$k] ?? ''));
    $d = app_caps($d);   // names, places and the identifiers on a document are kept in capitals
    $d['employee_id'] = strtoupper($d['employee_id']); $d['short_code'] = strtoupper($d['short_code']);
    $d['pan_number'] = strtoupper($d['pan_number']); $d['ifsc_code'] = strtoupper($d['ifsc_code']); $d['voter_number'] = strtoupper($d['voter_number']);
    $d['state_govt_id'] = strtoupper(preg_replace('/\s+/', '', $d['state_govt_id'])); $d['national_code'] = strtoupper(preg_replace('/\s+/', '', $d['national_code']));
    $d['can_login'] = !empty($in['can_login']) ? 1 : 0;
    $d['show_on_website'] = !empty($in['show_on_website']) ? 1 : 0;
    $d['exclude_from_exam_duty'] = !empty($in['exclude_from_exam_duty']) ? 1 : 0;

    // identity
    if ($d['employee_id'] === '') $d['employee_id'] = staff_next_employee_id();
    elseif (!staff_employee_id_valid($d['employee_id'])) $e[] = 'Employee ID: letters, digits, - and _ only (2–30).';
    // government ids: the exact formats are not published, so accept 4–30 letters/digits and rely on uniqueness
    if ($d['state_govt_id'] !== '' && !preg_match('/^[A-Z0-9\/-]{4,30}$/', $d['state_govt_id'])) $e[] = 'State Govt ID: 4–30 letters/digits.';
    if ($d['national_code'] !== '' && !preg_match('/^[A-Z0-9\/-]{4,30}$/', $d['national_code'])) $e[] = 'National code: 4–30 letters/digits.';
    if (($m = student_v_name($d['staff_name'], 'Name')) !== null) $e[] = $m;
    if (!preg_match('/^[A-Z0-9]{1,6}$/', $d['short_code'])) $e[] = 'Short code: 1–6 letters/digits (e.g. AK) — used on the routine.';
    $des = staff_designations();
    if (!isset($des[$d['designation']])) $e[] = 'Choose a designation.';
    else $d['staff_type'] = $des[$d['designation']][0];   // the type follows the designation
    if ($d['academic_section'] !== '' && !in_array($d['academic_section'], staff_sections(), true)) $e[] = 'Academic section: pick from the list.';
    if ($d['subject_name'] !== '' && !in_array($d['subject_name'], staff_subjects(), true)) $e[] = 'Subject: pick from the list.';
    if ($d['vacancy_status'] !== '' && !in_array($d['vacancy_status'], staff_vacancy_statuses(), true)) $e[] = 'Post type: pick from the list.';
    if ($d['staff_type'] === 'Teaching' && $d['subject_name'] === '') $e[] = 'Subject is required for teaching staff.';
    if ($d['can_login'] && $d['state_govt_id'] === '') $e[] = 'Teacher portal login needs the State Govt ID — it is the portal username. Untick "Teacher portal login" if they have none yet.';

    // personal
    if (!in_array($d['gender'], ['Male', 'Female', 'Other'], true)) $e[] = 'Choose a gender.';
    if ($d['date_of_birth'] === '') $e[] = 'Date of birth is required.';
    else { $dt = DateTime::createFromFormat('Y-m-d', $d['date_of_birth']); $age = $dt ? (int)$dt->diff(new DateTime('today'))->y : 0;
        if (!$dt || $dt->format('Y-m-d') !== $d['date_of_birth']) $e[] = 'Date of birth: enter a valid date.';
        elseif ($age < 18 || $age > 75) $e[] = "Date of birth gives an age of $age — check the year."; }
    if ($d['blood_group'] !== '' && !in_array($d['blood_group'], staff_blood_groups(), true)) $e[] = 'Blood group: pick from the list.';
    if ($d['religion'] !== '' && !in_array($d['religion'], student_religions(), true)) $e[] = 'Religion: pick from the list.';
    if ($d['caste'] !== '' && !in_array($d['caste'], student_castes(), true)) $e[] = 'Caste: pick from the list.';
    if ($d['marital_status'] !== '' && !in_array($d['marital_status'], staff_marital_statuses(), true)) $e[] = 'Marital status: pick from the list.';
    foreach (['father_name' => "Father's name", 'mother_name' => "Mother's name", 'spouse_name' => "Spouse's name"] as $k => $l) if ($d[$k] !== '' && ($m = student_v_name($d[$k], $l)) !== null) $e[] = $m;

    // service
    foreach (['date_of_joining' => 'Date of joining', 'joining_date_present_post' => 'Joining date (present post)', 'retirement_date' => 'Retirement date', 'date_of_approval' => 'Date of approval', 'status_date' => 'Status date'] as $k => $l) {
        if ($d[$k] === '') continue;
        $dt = DateTime::createFromFormat('Y-m-d', $d[$k]);
        if (!$dt || $dt->format('Y-m-d') !== $d[$k]) $e[] = "$l: enter a valid date.";
    }
    if ($d['date_of_joining'] === '') $e[] = 'Date of joining is required.';
    elseif ($d['date_of_birth'] !== '' && $d['date_of_joining'] < $d['date_of_birth']) $e[] = 'Date of joining cannot be before the date of birth.';
    if ($d['joining_date_present_post'] !== '' && $d['date_of_joining'] !== '' && $d['joining_date_present_post'] < $d['date_of_joining']) $e[] = 'Joining date (present post) cannot be before the date of joining.';
    if (!in_array($d['service_status'], staff_service_statuses(), true)) $d['service_status'] = 'Active';
    if ($d['service_status'] !== 'Active' && $d['status_date'] === '') $e[] = 'Give the date of ' . ['Transferred' => 'transfer', 'Retired' => 'retirement', 'Deceased' => 'death'][$d['service_status']] . '.';

    // contact & ids
    if ($d['mobile'] === '') $e[] = 'Mobile number is required.';
    elseif (($m = student_v_mobile($d['mobile'])) !== null) $e[] = $m;
    if ($d['email'] !== '' && ($m = student_v_email($d['email'])) !== null) $e[] = $m;
    if ($d['aadhar_number'] !== '' && ($m = student_v_aadhaar($d['aadhar_number'])) !== null) $e[] = 'Aadhaar: ' . $m;
    if ($d['voter_number'] !== '' && !preg_match('/^[A-Z]{3}[0-9]{7}$/', $d['voter_number'])) $e[] = 'Voter ID: 3 letters + 7 digits (e.g. ABC1234567).';
    if ($d['pan_number'] !== '' && !preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $d['pan_number'])) $e[] = 'PAN: 5 letters, 4 digits, 1 letter (e.g. ABCDE1234F).';
    if ($d['ifsc_code'] !== '' && ($m = student_v_ifsc($d['ifsc_code'])) !== null) $e[] = $m;
    if ($d['account_number'] !== '' && !preg_match('/^[0-9]{9,18}$/', $d['account_number'])) $e[] = 'Account number: 9–18 digits.';
    if (mb_strlen($d['remarks']) > 1000) $e[] = 'Remarks: at most 1000 characters.';

    // uniqueness (clear message before the UNIQUE index fires)
    foreach (['employee_id' => 'Employee ID', 'state_govt_id' => 'State Govt ID', 'national_code' => 'National code', 'email' => 'Email', 'aadhar_number' => 'Aadhaar number', 'pan_number' => 'PAN', 'mobile' => 'Mobile number'] as $col => $label) {
        if ($d[$col] === '') continue;
        $dup = db_get_row("SELECT id, staff_name, employee_id FROM staff WHERE `$col` = ? AND id <> ? LIMIT 1", 'si', $d[$col], $exclude_id);
        if ($dup) $e[] = "$label {$d[$col]} already belongs to {$dup['staff_name']} ({$dup['employee_id']}).";
    }

    // blanks -> NULL for dates / unique columns
    foreach (['date_of_birth', 'date_of_joining', 'joining_date_present_post', 'retirement_date', 'date_of_approval', 'status_date', 'email', 'aadhar_number', 'pan_number', 'state_govt_id', 'national_code'] as $k) if ($d[$k] === '') $d[$k] = null;
    return [$d, $e];
}

/** How many rows elsewhere point at this staff member (shown before a permanent delete). */
function staff_dependency_counts(int $id): array {
    $q = ['routine periods' => ['routine', 'teacher_id'], 'provisional routine' => ['provisional_routine', 'original_teacher_id'], 'attendance days' => ['teacher_attendance', 'teacher_id'],
        'exam duties' => ['exam_duty_roster', 'staff_id'], 'library issues handled' => ['library_issues', 'issued_by']];
    $out = [];
    foreach ($q as $label => [$t, $c]) {
        $n = (int)(db_get_row("SELECT COUNT(*) AS c FROM `$t` WHERE `$c` = ?", 'i', $id)['c'] ?? 0);
        if ($n) $out[$label] = $n;
    }
    return $out;
}

function staff_photo_url(?string $photo): string { return $photo ? '../uploads/staff/' . rawurlencode($photo) : ''; }

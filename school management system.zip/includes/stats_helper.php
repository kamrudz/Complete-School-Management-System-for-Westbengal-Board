<?php
/**
 * Student Statistics: one place that counts students, so the page on screen and the Excel beside it can
 * never disagree.
 *
 * A session's history row says what happened to the student that year: student_status 'Active' means they
 * were on the roll, anything else is how they left (Passed, TC, Transferred, Dropped, Deactivated). That is
 * why "on the roll" does not look at academic_status — once a student is promoted the old row is closed as
 * History, but they were still on the roll that year.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/class_helper.php';
require_once __DIR__ . '/student_helper.php';

/** The three report pages, for the strip at the top of each. */
const STATS_PAGES = [
    'student_statistics.php'      => ['Student Statistics', 'fa-chart-pie'],
    'sibling_report.php'          => ['Brothers & Sisters', 'fa-people-roof'],
    'student_year_comparison.php' => ['Year by Year', 'fa-arrows-left-right'],
];

/** Who the numbers cover. */
const STATS_SCOPES = [
    'on_roll' => 'On the roll that session',
    'all'     => 'Everyone, including those who left',
];

const STATS_VIEWS = [
    'overview' => ['Overview', 'fa-table'],
    'status'   => ['Who left', 'fa-user-clock'],
    'social'   => ['Religion & Caste', 'fa-layer-group'],
    'age'      => ['Age', 'fa-cake-candles'],
    'places'   => ['Sections & Places', 'fa-location-dot'],
    'data'     => ['What is missing', 'fa-clipboard-check'],
];

/** How a student left the session, in the order the report shows them. */
const STATS_LEFT = [
    'Active'      => ['On the roll', 'ok'],
    'Passed'      => ['Passed out', 'off'],
    'TC'          => ['Took a TC', 'warn'],
    'Transferred' => ['Transferred', 'warn'],
    'Dropped'     => ['Dropped out', 'bad'],
    'Deactivated' => ['Deactivated', 'bad'],
];

/** The four categories the state asks for. OBC-A and OBC-B were merged into OBC, so both count as OBC. */
const STATS_CASTES = ['General', 'SC', 'ST', 'OBC'];

/** What each of these must hold before a student's record counts as complete. */
const STATS_FIELDS = [
    'student_aadhaar'    => ['Aadhaar', 's.student_aadhaar'],
    'pen_id'             => ['PEN', 's.pen_id'],
    'apaar_id'           => ['APAAR', 's.apaar_id'],
    'banglarshiksha_id'  => ['Banglar Shiksha ID', 's.banglarshiksha_id'],
    'dob'                => ['Date of birth', 's.dob'],
    'religion'           => ['Religion', 's.religion'],
    'caste'              => ['Caste', 's.caste'],
    'bank'               => ['Bank account', "IF(s.bank_name <> '' AND s.account_number <> '' AND s.ifsc_code <> '', 'y', '')"],
    'photo'              => ['Photo', 's.photo'],
    'birth_certificate'  => ['Birth certificate', 's.birth_certificate'],
];

/** An identifier that must never sit on two students. */
const STATS_UNIQUE = ['student_aadhaar' => 'Aadhaar', 'pen_id' => 'PEN', 'banglarshiksha_id' => 'Banglar Shiksha ID', 'apaar_id' => 'APAAR'];

/** 'OBC-A' and 'OBC-B' answer as 'OBC'; a blank caste answers as ''. */
function stats_caste_case(): string
{
    return "CASE WHEN s.caste IN ('OBC', 'OBC-A', 'OBC-B') THEN 'OBC'
                 WHEN s.caste = 'General' THEN 'General'
                 WHEN s.caste = 'SC' THEN 'SC'
                 WHEN s.caste = 'ST' THEN 'ST'
                 WHEN s.caste IS NULL OR TRIM(s.caste) = '' THEN ''
                 ELSE s.caste END";
}

/** Minority is read off the religion: every religion other than Hindu, which is the Govt. of India list. */
function stats_minority_case(): string
{
    return "(s.religion IS NOT NULL AND TRIM(s.religion) <> '' AND s.religion <> 'Hindu')";
}

/** 'ISLAM' and 'Islam' are one religion; anything unknown keeps its own spelling. */
function stats_religion_label(string $raw): string
{
    $raw = trim($raw);
    if ($raw === '') return 'Not given';
    foreach (student_religions() as $known) if (strcasecmp($known, $raw) === 0) return $known;
    return ucwords(strtolower($raw));
}

/** The class number, so Class V answers 5. 0 when the name is not one of I–XII. */
function stats_class_number(string $name): int
{
    $i = array_search(class_name_normalise($name), class_roman_list(), true);
    return $i === false ? 0 : $i + 1;
}

/** The age a class is normally in on the 1st of April: Class I is 6, and a year either side is fine. */
function stats_age_band(string $class_name): array
{
    $n = stats_class_number($class_name);
    return $n ? [$n + 5, $n + 6] : [0, 0];
}

/** The 1st of April the session starts on — '2026' and '2026-27' both answer 2026-04-01. */
function stats_ref_date(string $session_name): string
{
    return (preg_match('/(\d{4})/', $session_name, $m) ? $m[1] : date('Y')) . '-04-01';
}

/** The sections of a session, narrowed to one class when asked: id => "V-A". */
function stats_sections(int $session_id, int $class_id = 0): array
{
    $sql = 'SELECT sec.id, sec.section_name, c.class_name FROM sections sec JOIN classes c ON c.id = sec.class_id
            WHERE sec.session_id = ?' . ($class_id ? ' AND sec.class_id = ?' : '') . ' ORDER BY c.sort_order, sec.section_name';
    $rows = $class_id ? db_get_all($sql, 'ii', $session_id, $class_id) : db_get_all($sql, 'i', $session_id);
    $out = [];
    foreach ($rows as $r) $out[(int)$r['id']] = $r['class_name'] . '-' . $r['section_name'];
    return $out;
}

/** What the page was asked for, cleaned up: everything below trusts this and nothing else. */
function stats_filter(array $in): array
{
    $sessions = db_get_all("SELECT id, session_name, status FROM academic_sessions ORDER BY status = 'Active' DESC, session_name DESC");
    $names = [];
    foreach ($sessions as $s) $names[(int)$s['id']] = $s['session_name'];
    $session_id = (int)($in['session_id'] ?? 0);
    if (!isset($names[$session_id])) {
        $session_id = 0;
        foreach ($sessions as $s) if ((string)$s['status'] === 'Active') { $session_id = (int)$s['id']; break; }
        if (!$session_id) $session_id = (int)(array_key_first($names) ?: 0);
    }
    $classes = class_rows();
    $class_id = (int)($in['class_id'] ?? 0);
    if (!isset($classes[$class_id])) $class_id = 0;
    $sections = stats_sections($session_id, $class_id);
    $section_id = (int)($in['section_id'] ?? 0);
    if (!isset($sections[$section_id])) $section_id = 0;
    $gender = (string)($in['gender'] ?? '');
    if (!in_array($gender, ['Male', 'Female', 'Other'], true)) $gender = '';
    $scope = (string)($in['scope'] ?? 'on_roll');
    if (!isset(STATS_SCOPES[$scope])) $scope = 'on_roll';
    return ['session_id' => $session_id, 'session_name' => $names[$session_id] ?? '', 'class_id' => $class_id,
        'section_id' => $section_id, 'gender' => $gender, 'scope' => $scope, 'sessions' => $names, 'sections' => $sections];
}

/** The joins a list needs on top of the counting ones: class, section, guardian. */
const STATS_JOIN_NAMES = 'LEFT JOIN classes c ON c.id = h.class_id
             LEFT JOIN sections sec ON sec.id = h.section_id';
const STATS_JOIN_GUARDIAN = 'LEFT JOIN guardians g ON g.guardian_id = s.guardian_id';
const STATS_JOIN_TC = "LEFT JOIN tc_students tc ON tc.student_id = s.id AND tc.status = 'Issued'";

/**
 * The FROM and WHERE every count shares: [sql, types, params]. $joins adds the tables a list needs for
 * its columns; $scope overrides the filter's own, which the "who left" view needs.
 */
function stats_from(array $f, string $scope = '', string $joins = ''): array
{
    $scope = $scope ?: $f['scope'];
    $sql = " FROM student_academic_history h
             JOIN students s ON s.id = h.student_id "
        . ($joins !== '' ? $joins . ' ' : '')
        . "WHERE h.session_id = ? AND h.student_status <> 'Deleted' AND s.student_status <> 'Deleted'";
    $types = 'i';
    $params = [$f['session_id']];
    if ($scope === 'on_roll') $sql .= " AND h.student_status = 'Active'";
    if ($f['class_id'])   { $sql .= ' AND h.class_id = ?';   $types .= 'i'; $params[] = $f['class_id']; }
    if ($f['section_id']) { $sql .= ' AND h.section_id = ?'; $types .= 'i'; $params[] = $f['section_id']; }
    if ($f['gender'])     { $sql .= ' AND s.gender = ?';     $types .= 's'; $params[] = $f['gender']; }
    return [$sql, $types, $params];
}

/**
 * The classes the report shows, in class order: id => name. A class nobody was in that session is left out,
 * so an old session does not grow empty columns. One class asked for is always shown, even if it is empty.
 */
function stats_classes(array $f): array
{
    [$from, $types, $params] = stats_from($f, 'all');
    $have = array_column(db_get_all('SELECT DISTINCT h.class_id cid' . $from, $types, ...$params), 'cid', 'cid');
    $out = [];
    foreach (class_rows() as $id => $c) {
        if ($f['class_id'] ? $id === $f['class_id'] : isset($have[$id])) $out[$id] = $c['name'];
    }
    return $out;
}

/** One empty row of the overview, so a class with nobody in it still lines up. */
function stats_blank_row(): array
{
    $row = ['total' => 0, 'Male' => 0, 'Female' => 0, 'Other' => 0];
    foreach (array_merge(STATS_CASTES, ['Minority', 'PWD']) as $k) $row[$k] = ['Male' => 0, 'Female' => 0, 'Other' => 0, 'total' => 0];
    return $row;
}

/**
 * Overview: every class against the categories the state asks for.
 * Returns [class_id => row, 'total' => row] where a row holds gender counts and a count per category.
 */
function stats_overview(array $f): array
{
    [$from, $types, $params] = stats_from($f);
    $rows = db_get_all('SELECT h.class_id cid, s.gender g, ' . stats_caste_case() . ' cst, ' . stats_minority_case() . " mino,
        (s.disability = 'Yes') pwd, COUNT(*) n" . $from . ' GROUP BY cid, g, cst, mino, pwd', $types, ...$params);
    $out = [];
    foreach (stats_classes($f) as $cid => $name) $out[$cid] = stats_blank_row() + ['name' => $name];
    $out['total'] = stats_blank_row() + ['name' => 'All classes'];
    foreach ($rows as $r) {
        $cid = (int)$r['cid'];
        $g = in_array($r['g'], ['Male', 'Female', 'Other'], true) ? $r['g'] : 'Other';
        $n = (int)$r['n'];
        $cst = in_array($r['cst'], STATS_CASTES, true) ? $r['cst'] : '';
        foreach ([$cid, 'total'] as $k) {
            if (!isset($out[$k])) continue;
            $out[$k]['total'] += $n;
            $out[$k][$g] += $n;
            if ($cst !== '') { $out[$k][$cst][$g] += $n; $out[$k][$cst]['total'] += $n; }
            if ((int)$r['mino']) { $out[$k]['Minority'][$g] += $n; $out[$k]['Minority']['total'] += $n; }
            if ((int)$r['pwd'])  { $out[$k]['PWD'][$g] += $n; $out[$k]['PWD']['total'] += $n; }
        }
    }
    return $out;
}

/** A category nobody in this view belongs to is not worth a column. */
function stats_live_categories(array $overview): array
{
    $live = [];
    foreach (array_merge(STATS_CASTES, ['Minority', 'PWD']) as $k) if (($overview['total'][$k]['total'] ?? 0) > 0) $live[] = $k;
    return $live;
}

/** Who left and who stayed: [class_id => [status => ['Male','Female','Other','total']], 'total' => …]. */
function stats_status(array $f): array
{
    [$from, $types, $params] = stats_from($f, 'all');
    $rows = db_get_all('SELECT h.class_id cid, h.student_status st, s.gender g, COUNT(*) n' . $from . ' GROUP BY cid, st, g', $types, ...$params);
    $blank = [];
    foreach (STATS_LEFT as $st => $_) $blank[$st] = ['Male' => 0, 'Female' => 0, 'Other' => 0, 'total' => 0];
    $out = [];
    foreach (stats_classes($f) as $cid => $name) $out[$cid] = ['name' => $name] + $blank;
    $out['total'] = ['name' => 'All classes'] + $blank;
    foreach ($rows as $r) {
        $cid = (int)$r['cid'];
        $st = isset(STATS_LEFT[$r['st']]) ? $r['st'] : 'Dropped';
        $g = in_array($r['g'], ['Male', 'Female', 'Other'], true) ? $r['g'] : 'Other';
        foreach ([$cid, 'total'] as $k) {
            if (!isset($out[$k])) continue;
            $out[$k][$st][$g] += (int)$r['n'];
            $out[$k][$st]['total'] += (int)$r['n'];
        }
    }
    return $out;
}

/**
 * The students who left this session, newest first: name, class, how they left, and when and why.
 * The TC number and date come from tc_students; the reason for a deactivation from the activity log.
 */
function stats_left_list(array $f, int $limit = 500): array
{
    [$from, $types, $params] = stats_from($f, 'all', STATS_JOIN_NAMES . ' ' . STATS_JOIN_TC);
    $sql = "SELECT s.id, s.student_name, s.gender, h.student_status st, h.roll_no, c.class_name, sec.section_name,
                   tc.tc_no, tc.tc_date, tc.reason tc_reason,
                   (SELECT l.details FROM admin_logs l WHERE l.record_id = s.id AND l.action LIKE 'STUDENT_STATUS_%' ORDER BY l.id DESC LIMIT 1) note,
                   (SELECT l.created_at FROM admin_logs l WHERE l.record_id = s.id AND l.action LIKE 'STUDENT_STATUS_%' ORDER BY l.id DESC LIMIT 1) note_at"
        . $from . " AND h.student_status <> 'Active'"
        . ' ORDER BY c.sort_order, sec.section_name, s.student_name LIMIT ' . max(1, $limit);
    return db_get_all($sql, $types, ...$params);
}

/** Religion against class, and caste against class: [label => [class_id => n, 'total' => n]]. */
function stats_social(array $f): array
{
    [$from, $types, $params] = stats_from($f);
    $out = ['religion' => [], 'caste' => []];
    foreach (db_get_all('SELECT h.class_id cid, s.religion r, COUNT(*) n' . $from . ' GROUP BY cid, r', $types, ...$params) as $r) {
        $label = stats_religion_label((string)$r['r']);
        $out['religion'][$label][(int)$r['cid']] = ($out['religion'][$label][(int)$r['cid']] ?? 0) + (int)$r['n'];
        $out['religion'][$label]['total'] = ($out['religion'][$label]['total'] ?? 0) + (int)$r['n'];
    }
    foreach (db_get_all('SELECT h.class_id cid, ' . stats_caste_case() . ' cst, COUNT(*) n' . $from . ' GROUP BY cid, cst', $types, ...$params) as $r) {
        $label = (string)$r['cst'] !== '' ? (string)$r['cst'] : 'Not given';
        $out['caste'][$label][(int)$r['cid']] = ($out['caste'][$label][(int)$r['cid']] ?? 0) + (int)$r['n'];
        $out['caste'][$label]['total'] = ($out['caste'][$label]['total'] ?? 0) + (int)$r['n'];
    }
    foreach ($out as $k => $rows) { uasort($out[$k], fn($a, $b) => $b['total'] <=> $a['total']); }
    return $out;
}

/** Age on the 1st of April: [class_id => [age => n]], the ages seen, and how many have no date of birth. */
function stats_age(array $f): array
{
    [$from, $types, $params] = stats_from($f);
    $ref = stats_ref_date($f['session_name']);
    $rows = db_get_all('SELECT h.class_id cid, TIMESTAMPDIFF(YEAR, s.dob, ?) age, COUNT(*) n' . $from
        . ' AND s.dob IS NOT NULL GROUP BY cid, age', 's' . $types, $ref, ...$params);
    $grid = [];
    $ages = [];
    foreach ($rows as $r) {
        $grid[(int)$r['cid']][(int)$r['age']] = (int)$r['n'];
        $ages[(int)$r['age']] = true;
    }
    ksort($ages);
    $no_dob = (int)(db_get_row('SELECT COUNT(*) n' . $from . ' AND s.dob IS NULL', $types, ...$params)['n'] ?? 0);
    return ['grid' => $grid, 'ages' => array_keys($ages), 'no_dob' => $no_dob, 'ref' => $ref];
}

/** The students whose age falls outside their class's band — a wrong date of birth shows up here first. */
function stats_age_outliers(array $f, int $limit = 500): array
{
    [$from, $types, $params] = stats_from($f, '', STATS_JOIN_NAMES);
    $ref = stats_ref_date($f['session_name']);
    $sql = 'SELECT s.id, s.student_name, s.gender, s.dob, h.roll_no, c.class_name, sec.section_name,
                   TIMESTAMPDIFF(YEAR, s.dob, ?) age' . $from . ' AND s.dob IS NOT NULL'
        . ' ORDER BY c.sort_order, age DESC LIMIT 4000';
    $out = [];
    foreach (db_get_all($sql, 's' . $types, $ref, ...$params) as $r) {
        [$lo, $hi] = stats_age_band((string)$r['class_name']);
        if (!$lo) continue;
        $age = (int)$r['age'];
        if ($age >= $lo && $age <= $hi) continue;
        $r['band'] = $lo . '–' . $hi;
        $r['why'] = $age < $lo ? 'younger' : 'older';
        $out[] = $r;
        if (count($out) >= $limit) break;
    }
    return $out;
}

/** Section strength: [class_id => [section_id => ['name','Male','Female','Other','total']]]. */
function stats_section_strength(array $f): array
{
    [$from, $types, $params] = stats_from($f, '', 'LEFT JOIN sections sec ON sec.id = h.section_id');
    $rows = db_get_all('SELECT h.class_id cid, h.section_id sid, sec.section_name nm, s.gender g, COUNT(*) n'
        . $from . ' GROUP BY cid, sid, nm, g', $types, ...$params);
    $out = [];
    foreach ($rows as $r) {
        $cid = (int)$r['cid'];
        $sid = (int)$r['sid'];
        $g = in_array($r['g'], ['Male', 'Female', 'Other'], true) ? $r['g'] : 'Other';
        if (!isset($out[$cid][$sid])) $out[$cid][$sid] = ['name' => (string)($r['nm'] ?? '—'), 'Male' => 0, 'Female' => 0, 'Other' => 0, 'total' => 0];
        $out[$cid][$sid][$g] += (int)$r['n'];
        $out[$cid][$sid]['total'] += (int)$r['n'];
    }
    foreach ($out as $cid => $secs) { uasort($out[$cid], fn($a, $b) => strcasecmp($a['name'], $b['name'])); }
    return $out;
}

/** Where the students come from: counts for one address column, biggest first. */
function stats_places(array $f, string $column, int $limit = 25): array
{
    $allowed = ['police_station' => 'Police station', 'post_office' => 'Post office', 'village' => 'Village', 'district' => 'District'];
    if (!isset($allowed[$column])) $column = 'police_station';
    [$from, $types, $params] = stats_from($f);
    $rows = db_get_all("SELECT CASE WHEN s.$column IS NULL OR TRIM(s.$column) = '' THEN 'Not given' ELSE UPPER(TRIM(s.$column)) END p,
        COUNT(*) n, SUM(s.gender = 'Male') boys, SUM(s.gender = 'Female') girls" . $from . ' GROUP BY p ORDER BY n DESC', $types, ...$params);
    $top = array_slice($rows, 0, $limit);
    $rest = array_slice($rows, $limit);
    $other = ['p' => count($rest) . ' more place(s)', 'n' => 0, 'boys' => 0, 'girls' => 0];
    foreach ($rest as $r) { $other['n'] += (int)$r['n']; $other['boys'] += (int)$r['boys']; $other['girls'] += (int)$r['girls']; }
    return ['label' => $allowed[$column], 'column' => $column, 'rows' => $top, 'other' => $rest ? $other : null, 'places' => count($rows)];
}
function stats_place_columns(): array
{
    return ['police_station' => 'Police station', 'post_office' => 'Post office', 'village' => 'Village', 'district' => 'District'];
}

/** How much of each record is filled in: [field => ['label', 'have' => n, 'missing' => n, per class]]. */
function stats_completeness(array $f): array
{
    [$from, $types, $params] = stats_from($f);
    $parts = [];
    foreach (STATS_FIELDS as $key => [$label, $expr]) $parts[] = "SUM($expr IS NOT NULL AND TRIM($expr) <> '') AS `$key`";
    $rows = db_get_all('SELECT h.class_id cid, COUNT(*) n, ' . implode(', ', $parts) . $from . ' GROUP BY cid', $types, ...$params);
    $out = [];
    $totals = ['n' => 0];
    foreach (STATS_FIELDS as $key => [$label]) $out[$key] = ['label' => $label, 'have' => 0, 'classes' => []];
    foreach ($rows as $r) {
        $cid = (int)$r['cid'];
        $totals['n'] += (int)$r['n'];
        foreach (STATS_FIELDS as $key => [$label]) {
            $have = (int)$r[$key];
            $out[$key]['have'] += $have;
            $out[$key]['classes'][$cid] = ['n' => (int)$r['n'], 'have' => $have, 'missing' => (int)$r['n'] - $have];
        }
    }
    foreach ($out as $key => $row) $out[$key]['missing'] = $totals['n'] - $row['have'];
    return ['fields' => $out, 'total' => $totals['n']];
}

/** The students whose one field is empty, so the office knows exactly whom to ask. */
function stats_missing_list(array $f, string $field, int $limit = 500): array
{
    if (!isset(STATS_FIELDS[$field])) return [];
    $expr = STATS_FIELDS[$field][1];
    [$from, $types, $params] = stats_from($f, '', STATS_JOIN_NAMES . ' ' . STATS_JOIN_GUARDIAN);
    $sql = 'SELECT s.id, s.student_name, s.gender, h.roll_no, c.class_name, sec.section_name, g.father_name, g.father_mobile'
        . $from
        . " AND ($expr IS NULL OR TRIM($expr) = '')"
        . ' ORDER BY c.sort_order, sec.section_name, CAST(h.roll_no AS UNSIGNED), s.student_name LIMIT ' . max(1, $limit);
    return db_get_all($sql, $types, ...$params);
}

/** An identifier sitting on more than one student — always an entry mistake, and it blocks a UNIQUE index. */
function stats_duplicate_ids(array $f): array
{
    $out = [];
    foreach (STATS_UNIQUE as $col => $label) {
        $rows = db_get_all("SELECT s.$col v, COUNT(*) n, GROUP_CONCAT(CONCAT(s.id, ' · ', s.student_name) ORDER BY s.id SEPARATOR ' | ') who
            FROM students s WHERE s.student_status <> 'Deleted' AND s.$col IS NOT NULL AND TRIM(s.$col) <> ''
            GROUP BY v HAVING n > 1 ORDER BY n DESC, v LIMIT 50");
        if ($rows) $out[$label] = $rows;
    }
    return $out;
}

<?php
/**
 * The one list of student fields the Bulk Update grid may show and save.
 * admin/student_bulk_update.php renders columns from it; admin/bulk_update_save.php
 * refuses anything not in it. Lifecycle columns (student_status, promotion_status,
 * academic_status) are deliberately absent — includes/student_lifecycle.php owns them.
 *
 * key => [table, col, label, group, type, options?, max?, upper?, hint?]
 *   table : students | guardians | history (the running session's Current row)
 *   type  : text | date | number | select | class | section | file
 */
function student_bulk_fields(): array {
    $bg = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
    $f = [
        // ---- Academic (history row of the running session) ----
        'class_id'        => ['history', 'class_id',        'Class',            'Academic', 'class'],
        'section_id'      => ['history', 'section_id',      'Section',          'Academic', 'section'],
        'roll_no'         => ['history', 'roll_no',         'Roll',             'Academic', 'text', null, 4],
        'previous_school' => ['history', 'previous_school', 'Previous School',  'Academic', 'text', null, 200],
        // ---- Student ----
        'student_name'              => ['students', 'student_name',              'Student Name',          'Student', 'text', null, 100],
        'name_as_per_aadhaar'       => ['students', 'name_as_per_aadhaar',       'Name as per Aadhaar',   'Student', 'text', null, 150],
        'dob'                       => ['students', 'dob',                       'Date of Birth',         'Student', 'date'],
        'gender'                    => ['students', 'gender',                    'Gender',                'Student', 'select', ['Male', 'Female', 'Other']],
        'blood_group'               => ['students', 'blood_group',               'Blood Group',           'Student', 'select', $bg],
        'religion'                  => ['students', 'religion',                  'Religion',              'Student', 'select', student_religions()],
        'caste'                     => ['students', 'caste',                     'Caste',                 'Student', 'select', student_castes()],
        'sub_caste'                 => ['students', 'sub_caste',                 'Sub Caste',             'Student', 'text', null, 50],
        'nationality'               => ['students', 'nationality',               'Nationality',           'Student', 'text', null, 50],
        'mother_tongue'             => ['students', 'mother_tongue',             'Mother Tongue',         'Student', 'text', null, 50],
        'disability'                => ['students', 'disability',                'Disability',            'Student', 'select', ['No', 'Yes']],
        'disability_type'           => ['students', 'disability_type',           'Disability Type',       'Student', 'select', student_disability_types()],
        'disability_percentage'     => ['students', 'disability_percentage',     'Disability %',          'Student', 'number'],
        'birth_registration_number' => ['students', 'birth_registration_number', 'Birth Reg No',          'Student', 'text', null, 50],
        'student_aadhaar'           => ['students', 'student_aadhaar',           'Student Aadhaar',       'Student', 'text', null, 12],
        'banglarshiksha_id'         => ['students', 'banglarshiksha_id',         'Banglar Shiksha ID',    'Student', 'text', null, 14],
        'pen_id'                    => ['students', 'pen_id',                    'PEN',                   'Student', 'text', null, 11],
        'apaar_id'                  => ['students', 'apaar_id',                  'APAAR ID',              'Student', 'text', null, 12],
        'admission_no'              => ['students', 'admission_no',              'Admission Reg No',      'Student', 'text', null, 30],
        'admission_year'            => ['students', 'admission_year',            'Admission Year',        'Student', 'text', null, 4],
        'admission_date'            => ['students', 'admission_date',            'Admission Date',        'Student', 'date'],
        'mobile'                    => ['students', 'mobile',                    'Student Mobile',        'Student', 'text', null, 10],
        'email'                     => ['students', 'email',                     'Email',                 'Student', 'text', null, 100],
        'remarks'                   => ['students', 'remarks',                   'Remarks',               'Student', 'text', null, 500],
        // ---- Address ----
        'village'        => ['students', 'village',        'Village / Town', 'Address', 'text', null, 100],
        'post_office'    => ['students', 'post_office',    'Post Office',    'Address', 'text', null, 100],
        'police_station' => ['students', 'police_station', 'Police Station', 'Address', 'text', null, 100],
        'district'       => ['students', 'district',       'District',       'Address', 'text', null, 100],
        'state'          => ['students', 'state',          'State',          'Address', 'text', null, 100],
        'pin_code'       => ['students', 'pin_code',       'PIN Code',       'Address', 'text', null, 6],
        // ---- Bank ----
        'bank_name'      => ['students', 'bank_name',      'Bank',           'Bank', 'text', null, 100],
        'branch_name'    => ['students', 'branch_name',    'Branch',         'Bank', 'text', null, 100],
        'account_number' => ['students', 'account_number', 'Account Number', 'Bank', 'text', null, 30],
        'ifsc_code'      => ['students', 'ifsc_code',      'IFSC',           'Bank', 'text', null, 11, true],
        // ---- Guardian (the family's own row) ----
        'father_name'          => ['guardians', 'father_name',          'Father',               'Guardian', 'text', null, 150],
        'father_aadhaar'       => ['guardians', 'father_aadhaar',       'Father Aadhaar',       'Guardian', 'text', null, 12],
        'father_voter_id'      => ['guardians', 'father_voter_id',      'Father Voter ID',      'Guardian', 'text', null, 20, true],
        'father_mobile'        => ['guardians', 'father_mobile',        'Father Mobile',        'Guardian', 'text', null, 10],
        'father_occupation'    => ['guardians', 'father_occupation',    'Father Occupation',    'Guardian', 'text', null, 100],
        'father_qualification' => ['guardians', 'father_qualification', 'Father Qualification', 'Guardian', 'text', null, 100],
        'annual_income'        => ['guardians', 'annual_income',        'Annual Income',        'Guardian', 'number'],
        'mother_name'          => ['guardians', 'mother_name',          'Mother',               'Guardian', 'text', null, 150],
        'mother_aadhaar'       => ['guardians', 'mother_aadhaar',       'Mother Aadhaar',       'Guardian', 'text', null, 12],
        'mother_voter_id'      => ['guardians', 'mother_voter_id',      'Mother Voter ID',      'Guardian', 'text', null, 20, true],
        'mother_occupation'    => ['guardians', 'mother_occupation',    'Mother Occupation',    'Guardian', 'text', null, 100],
        'guardian_name'        => ['guardians', 'guardian_name',        'Guardian',             'Guardian', 'text', null, 150],
        'guardian_relation'    => ['guardians', 'guardian_relation',    'Guardian Relation',    'Guardian', 'select', student_guardian_relations()],
        'guardian_contact'     => ['guardians', 'guardian_contact',     'Guardian Contact',     'Guardian', 'text', null, 10],
        'guardian_email'       => ['guardians', 'guardian_email',       'Guardian Email',       'Guardian', 'text', null, 100],
        // ---- Files (uploaded through student_photo_upload.php, never through the save endpoint) ----
        'photo'             => ['students', 'photo',             'Photo',             'Files', 'file'],
        'signature'         => ['students', 'signature',         'Signature',         'Files', 'file'],
        'birth_certificate' => ['students', 'birth_certificate', 'Birth Certificate', 'Files', 'file'],
        'student_aadhaar_image' => ['students', 'student_aadhaar_image', 'Aadhaar Card', 'Files', 'file'],
    ];
    $out = [];
    foreach ($f as $key => $d) {
        $out[$key] = ['table' => $d[0], 'col' => $d[1], 'label' => $d[2], 'group' => $d[3], 'type' => $d[4],
            'options' => $d[5] ?? null, 'max' => $d[6] ?? null, 'upper' => (bool)($d[7] ?? false)];
    }
    return $out;
}

function student_bulk_groups(): array {
    return ['Academic', 'Student', 'Address', 'Bank', 'Guardian', 'Files'];
}

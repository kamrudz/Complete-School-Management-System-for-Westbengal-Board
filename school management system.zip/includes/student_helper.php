<?php
/**
 * Student identity and field checks, shared by admission, edit, import and online admission.
 *
 * students.id is the School UID, PREFIX-YEAR-NNNN (ULPHS-2026-0001): given once at admission, never
 * changed, and the value every other table's student_id holds. It does not depend on any government ID.
 * Banglar Shiksha ID (14 digits), PEN and APAAR are optional and unique. The admission register number
 * is not unique, so it is never used to find a student.
 */

/** The fields a student cannot be saved without; the add and edit forms star the same list. */
const STUDENT_REQUIRED_FIELDS = [
    'student_name'     => 'Student Name',
    'dob'              => 'Date of Birth',
    'gender'           => 'Gender',
    'religion'         => 'Religion',
    'caste'            => 'Caste',
    'father_name'      => 'Father Name',
    'mother_name'      => 'Mother Name',
    'guardian_contact' => 'Guardian Contact',
    'admission_date'   => 'Admission Date',
    'session_id'       => 'Academic Session',
    'class_id'         => 'Class',
    'section_id'       => 'Section',
    'roll_no'          => 'Roll Number',
];

/** The configured prefix (e.g. ULPHS), or '' if School Settings has none. */
function student_uid_prefix(): string {
    $row = db_get_row('SELECT student_id_prefix FROM school_settings WHERE id = 1');
    return strtoupper(trim((string)($row['student_id_prefix'] ?? '')));
}

/**
 * The next School UID for a year: the highest serial for that prefix and year, plus one. Two admins
 * saving at the same moment can get the same value; student_insert() then simply asks again.
 * '' when School Settings has no prefix.
 */
function student_next_uid(?int $year = null): string {
    $prefix = student_uid_prefix();
    if ($prefix === '') return '';
    $year = $year ?: (int)date('Y');
    $like = $prefix . '-' . $year . '-%';
    $max = (int)(db_get_row(
        "SELECT MAX(CAST(SUBSTRING_INDEX(id, '-', -1) AS UNSIGNED)) AS m FROM students WHERE id LIKE ?",
        's', $like)['m'] ?? 0);
    return sprintf('%s-%d-%04d', $prefix, $year, $max + 1);
}

/**
 * Insert a student with a fresh UID and return the UID. $data holds the other columns. A clash on the
 * UID (two admins at once) is retried; a clash on a government ID comes back as a readable message.
 */
function student_insert(mysqli $conn, array $data, ?int $year = null): string {
    unset($data['id']);
    $data = student_blank_ids_to_null($data);
    if ($dups = student_duplicates($data)) throw new RuntimeException(implode(' ', $dups));
    $cols = array_keys($data);
    $sql = 'INSERT INTO students (id, ' . implode(', ', array_map(fn($c) => "`$c`", $cols)) . ') VALUES (?' . str_repeat(', ?', count($cols)) . ')';
    for ($attempt = 0; $attempt < 10; $attempt++) {
        $uid = student_next_uid($year);
        if ($uid === '') throw new RuntimeException('School UID not generated — set Student ID Prefix in School Settings.');
        try {
            $stmt = mysqli_prepare($conn, $sql);
            $params = array_merge([$uid], array_values($data));
            mysqli_stmt_bind_param($stmt, str_repeat('s', count($params)), ...$params);
            mysqli_stmt_execute($stmt);
            return $uid;
        } catch (mysqli_sql_exception $e) {
            // someone took this serial a moment ago: try the next one; any other error is the caller's
            if ((int)$e->getCode() !== 1062 || stripos($e->getMessage(), "for key 'PRIMARY'") === false) throw $e;
        }
    }
    throw new RuntimeException('Could not allocate a School UID after 10 attempts.');
}
/** Shape check for a UID typed by a user (login, search). */
function student_uid_valid(string $uid): bool {
    return (bool)preg_match('/^[A-Z0-9]{2,20}-\d{4}-\d{4,}$/', strtoupper(trim($uid)));
}

// ---------------------------------------------------------------------------
// Field validation. Each returns null when fine, or the message to show.
// Empty is allowed everywhere except where stated — "required" is decided by
// the form, these only judge a value that was given.
// ---------------------------------------------------------------------------

function student_v_aadhaar(string $v): ?string {
    if ($v === '') return null;
    // 12 digits; UIDAI never issues a number starting with 0 or 1.
    if (!preg_match('/^[2-9]\d{11}$/', $v)) return 'Aadhaar must be 12 digits and cannot start with 0 or 1.';
    return null;
}

function student_v_mobile(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^[6-9]\d{9}$/', $v)) return 'Mobile must be 10 digits starting with 6–9.';
    return null;
}

function student_v_pin(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^[1-9]\d{5}$/', $v)) return 'PIN code must be 6 digits.';
    return null;
}

function student_v_ifsc(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^[A-Z]{4}0[A-Z0-9]{6}$/', $v)) return 'IFSC must look like SBIN0001234.';
    return null;
}

function student_v_email(string $v): ?string {
    if ($v === '') return null;
    if (!filter_var($v, FILTER_VALIDATE_EMAIL)) return 'Email address is not valid.';
    return null;
}

/** YYYY-MM-DD, a real date, not in the future, and a school-age person (3–30). */
function student_v_dob(string $v): ?string {
    if ($v === '') return null;
    $d = DateTime::createFromFormat('!Y-m-d', $v);   // '!' = midnight, so it compares fairly with 'today'
    if (!$d || $d->format('Y-m-d') !== $v) return 'Date of birth must be a valid date (YYYY-MM-DD).';
    $age = (int)$d->diff(new DateTime('today'))->y;
    if ($d > new DateTime('today')) return 'Date of birth cannot be in the future.';
    if ($age < 3 || $age > 30) return "Date of birth gives an age of $age — check the year.";
    return null;
}

/** 14 digits after normalisation (see student_normalize_bsid); an older 13-digit ID is accepted and padded. */
function student_v_banglarshiksha(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^\d{13,14}$/', $v)) return 'Banglar Shiksha ID must be 14 digits.';
    return null;
}

/** Banglar Shiksha IDs are stored as exactly 14 digits; a 13-digit one gets a leading 0 (admin's rule, 2026-09-15). */
function student_normalize_bsid(?string $v): ?string {
    $v = trim((string)$v);
    if ($v === '') return null;
    return preg_match('/^\d{13}$/', $v) ? '0' . $v : $v;
}
function student_v_pen(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^\d{11}$/', $v)) return 'PEN must be 11 digits.';
    return null;
}

function student_v_apaar(string $v): ?string {
    if ($v === '') return null;
    if (!preg_match('/^\d{12}$/', $v)) return 'APAAR ID must be 12 digits.';
    return null;
}

/** Person and place names: letters of any script, spaces, dot, hyphen, apostrophe. */
function student_v_name(string $v, string $label = 'Name'): ?string {
    if ($v === '') return null;
    if (mb_strlen($v) > 100) return "$label must be 100 characters or fewer.";
    if (!preg_match("/^[\p{L}\p{M} .'\-]+$/u", $v)) return "$label can only contain letters, spaces, . - '";
    return null;
}

/**
 * Validate the common student fields in one go. $data is the assoc array the
 * form or import row produced. Returns [] when everything passes, else
 * field => message.
 */
function student_validate(array $data): array {
    $checks = [
        'student_name'              => fn($v) => $v === '' ? 'Student Name is required.' : student_v_name($v, 'Student Name'),
        'name_as_per_aadhaar'       => fn($v) => student_v_name($v, 'Name as per Aadhaar'),
        'dob'                       => 'student_v_dob',
        'student_aadhaar'           => 'student_v_aadhaar',
        'banglarshiksha_id'         => 'student_v_banglarshiksha',
        'pen_id'                    => 'student_v_pen',
        'apaar_id'                  => 'student_v_apaar',
        'mobile'                    => 'student_v_mobile',
        'email'                     => 'student_v_email',
        'pin_code'                  => 'student_v_pin',
        'ifsc_code'                 => 'student_v_ifsc',
    ];
    $errors = [];
    foreach ($checks as $field => $fn) {
        $v = trim((string)($data[$field] ?? ''));
        if (($m = $fn($v)) !== null) $errors[$field] = $m;
    }
    if (isset($data['gender']) && $data['gender'] !== '' && !in_array($data['gender'], ['Male', 'Female', 'Other'], true)) {
        $errors['gender'] = 'Gender must be Male, Female or Other.';
    }
    return $errors;
}

/**
 * Another student already holding this Aadhaar, Banglar Shiksha ID, PEN or APAAR:
 * field => "Aadhaar already belongs to ULPHS-2021-0050 AHAMED REJA."
 */
function student_duplicates(array $data, string $exclude_id = ''): array {
    $found = [];
    foreach (['student_aadhaar' => 'Aadhaar', 'banglarshiksha_id' => 'Banglar Shiksha ID', 'pen_id' => 'PEN', 'apaar_id' => 'APAAR'] as $col => $label) {
        $v = trim((string)($data[$col] ?? ''));
        if ($col === 'banglarshiksha_id') $v = (string)student_normalize_bsid($v);
        if ($v === '') continue;
        $row = db_get_row('SELECT id, student_name FROM students WHERE ' . db_identifier($col) . ' = ? AND id <> ? LIMIT 1', 'ss', $v, $exclude_id);
        if ($row) $found[$col] = "$label already belongs to {$row['id']} {$row['student_name']}.";
    }
    return $found;
}

/**
 * The government IDs are UNIQUE with NULL allowed. A form leaves an unknown
 * one as '' — and two '' values would collide — so blank becomes NULL here,
 * in one place, before any INSERT or UPDATE.
 */
function student_blank_ids_to_null(array $data): array {
    foreach (['banglarshiksha_id', 'pen_id', 'apaar_id', 'student_aadhaar', 'email'] as $k) {
        if (array_key_exists($k, $data) && trim((string)$data[$k]) === '') $data[$k] = null;
    }
    if (array_key_exists('banglarshiksha_id', $data)) $data['banglarshiksha_id'] = student_normalize_bsid($data['banglarshiksha_id']);
    return $data;
}

// ---------------------------------------------------------------------------
// Dropdown lists shared by the add / edit forms
// ---------------------------------------------------------------------------

/** Matches the values already in the table (imports write ISLAM / HINDU in caps; readers compare case-insensitively). */
function student_religions(): array {
    return ['Hindu', 'Islam', 'Christian', 'Sikh', 'Buddhist', 'Jain', 'Others'];
}

/** OBC-A and OBC-B were merged by the state; there is one OBC. */
function student_castes(): array {
    return ['General', 'SC', 'ST', 'OBC'];
}

/** The 21 disabilities in the RPwD Act 2016 schedule, plus Other. */
function student_disability_types(): array {
    return [
        'Blindness', 'Low Vision', 'Leprosy Cured Person', 'Hearing Impairment (Deaf / Hard of Hearing)',
        'Locomotor Disability', 'Dwarfism', 'Intellectual Disability', 'Mental Illness',
        'Autism Spectrum Disorder', 'Cerebral Palsy', 'Muscular Dystrophy', 'Chronic Neurological Condition',
        'Specific Learning Disability', 'Multiple Sclerosis', 'Speech and Language Disability',
        'Thalassemia', 'Hemophilia', 'Sickle Cell Disease', 'Multiple Disabilities (incl. Deaf-blindness)',
        'Acid Attack Victim', "Parkinson's Disease", 'Other',
    ];
}

function student_guardian_relations(): array {
    return ['Father', 'Mother', 'Grandfather', 'Grandmother', 'Uncle', 'Aunt', 'Brother', 'Sister', 'Legal Guardian', 'Other'];
}

// ---------------------------------------------------------------------------
// Madhyamik (Class X board) result, optional on the add / edit forms — mainly for Class XI
// ---------------------------------------------------------------------------

function student_mp_boards(): array {
    return ['WBBSE', 'CBSE', 'ICSE', 'Other'];
}

/** The result posted by the form — [board, year, roll, subjects => [[name, full, got], …]] — and what is wrong with it. */
function student_mp_from_post(): array {
    $t = fn($k) => trim((string)($_POST[$k] ?? ''));
    $mp = ['board' => $t('mp_board'), 'year' => $t('mp_year'), 'roll' => $t('mp_roll_no'), 'subjects' => []];
    $errors = [];
    foreach ((array)(json_decode($_POST['mp_subjects_json'] ?? '[]', true) ?: []) as $row) {
        $name = is_array($row) ? trim((string)($row['subject'] ?? '')) : '';
        if ($name === '') continue;
        $full = (float)($row['full_marks'] ?? 0);
        $got = (float)($row['marks_obtained'] ?? 0);
        if (mb_strlen($name) > 100 || $full <= 0 || $full > 1000 || $got < 0 || $got > $full) $errors[] = "Madhyamik $name: marks must be between 0 and the full marks.";
        else $mp['subjects'][] = [$name, $full, $got];
    }
    if ($mp['board'] !== '' && !in_array($mp['board'], student_mp_boards(), true)) $errors[] = 'Madhyamik Board is not a valid choice.';
    if ($mp['year'] !== '' && !preg_match('/^(19|20)\d\d$/', $mp['year'])) $errors[] = 'Madhyamik Year of Passing must be a 4-digit year.';
    return [$mp, $errors];
}

/** Store the result for a student, replacing an earlier one. A blank form leaves an existing record alone. */
function student_mp_save(string $uid, array $mp): void {
    if ($mp['board'] === '' && $mp['year'] === '' && $mp['roll'] === '' && !$mp['subjects']) return;
    $full = array_sum(array_column($mp['subjects'], 1));
    $got = array_sum(array_column($mp['subjects'], 2));
    $row = ['mp_board' => $mp['board'], 'mp_year' => $mp['year'], 'mp_roll_no' => $mp['roll'],
            'mp_total_marks' => $got, 'mp_total_full_marks' => $full, 'mp_percentage' => $full > 0 ? round($got / $full * 100, 2) : 0];
    $id = (int)(db_get_row('SELECT id FROM hs_student_mp_marks WHERE student_id = ?', 's', $uid)['id'] ?? 0);
    if ($id) {
        db_update('hs_student_mp_marks', $row, ['id' => $id], 'i');
        db_execute('DELETE FROM hs_student_mp_subject_marks WHERE mp_marks_id = ?', 'i', $id);
    } else {
        $id = (int)db_insert('hs_student_mp_marks', ['student_id' => $uid] + $row);
    }
    foreach ($mp['subjects'] as [$name, $sub_full, $sub_got]) {
        db_insert('hs_student_mp_subject_marks', ['mp_marks_id' => $id, 'subject_name' => $name, 'full_marks' => $sub_full, 'marks_obtained' => $sub_got]);
    }
}

/** Disability percentage: blank, or 0–100 (certificates give whole or half percents). */
function student_v_disability_pct(string $v): ?string {
    if ($v === '') return null;
    if (!is_numeric($v) || (float)$v < 0 || (float)$v > 100) return 'Disability % must be between 0 and 100.';
    return null;
}

// ---------------------------------------------------------------------------
// Page addressing: the School UID is the student's identity in every URL.
// ---------------------------------------------------------------------------

/**
 * The UID of the student named in the request — ?uid=ULPHS-2026-0001 (the normal
 * form) or the older ?id=. '' when neither carries a well-formed UID. Case-insensitive.
 */
function student_id_from_request(): string {
    $uid = strtoupper(trim((string)($_GET['uid'] ?? $_GET['id'] ?? '')));
    return student_uid_valid($uid) ? $uid : '';
}
/** view_student.php?uid=… — the one way to address a student page. */
function student_page_url(string $page, ?string $uid): string {
    return $page . '?uid=' . rawurlencode((string)$uid);
}

/**
 * A UID from any source (form, sheet, URL) normalised, or '' when it is not one.
 * The safe replacement for the old (int) cast: an accepted value contains only
 * A–Z, 0–9 and '-', so it is also safe inside a quoted SQL literal.
 */
function student_uid_clean($v): string {
    $v = strtoupper(trim((string)$v));
    return student_uid_valid($v) ? $v : '';
}
// ---------- Sensitive documents: Aadhaar card, birth certificate ----------
// They live in uploads/students/docs/, which Apache never serves (.htaccess); the only way
// to see one is admin/student_doc.php, which checks the admin login first.

/** The kinds of locked document: type key => students column, label, filename prefix. */
function student_doc_kinds(): array {
    return [
        'birth'   => ['col' => 'birth_certificate',     'label' => 'Birth certificate', 'prefix' => 'bc'],
        'aadhaar' => ['col' => 'student_aadhaar_image', 'label' => 'Aadhaar card',      'prefix' => 'adh'],
    ];
}

/** Absolute path of the locked folder (with trailing slash); creates it, its .htaccess and an empty index on first use. */
function student_docs_dir(): string {
    $dir = dirname(__DIR__) . '/uploads/students/docs/';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (!is_file($dir . '.htaccess')) @file_put_contents($dir . '.htaccess', "# Student identity documents: never served directly — see admin/student_doc.php\n<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n");
    if (!is_file($dir . 'index.html')) @file_put_contents($dir . 'index.html', '');
    return $dir;
}

/** URL (relative to admin/) that shows a student's locked document to a logged-in admin. */
function student_doc_url(string $uid, string $kind): string {
    return 'student_doc.php?uid=' . rawurlencode($uid) . '&type=' . rawurlencode($kind);
}

/** Store an uploaded document ($_FILES entry) of the given kind: image only, compressed to ~80 KB. Same result shape as process_student_document(). */
function student_doc_store_upload(array $file, string $kind): array {
    require_once __DIR__ . '/document_helper.php';
    $k = student_doc_kinds()[$kind] ?? null;
    if (!$k) return ['ok' => false, 'error' => 'Unknown document type.', 'filename' => null];
    return process_student_document($file, student_docs_dir(), 80, $k['prefix']);
}

/** Copy an existing file (e.g. from uploads/admission/) into the locked folder under a random name; null when the source is missing. */
function student_doc_copy_path(string $src, string $kind): ?string {
    $k = student_doc_kinds()[$kind] ?? null;
    if (!$k || $src === '' || !is_file($src)) return null;
    $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'pdf'], true)) $ext = 'jpg';
    $name = $k['prefix'] . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    return @copy($src, student_docs_dir() . $name) ? $name : null;
}

require_once __DIR__ . '/student_lifecycle.php';

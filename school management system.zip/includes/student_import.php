<?php
/**
 * Student import from Excel: the template, and the run.
 *
 * One row per student, matched on the Banglar Shiksha ID. A new ID becomes a new student (with a sibling's
 * guardian row shared when three of the five family details match); an ID already in school is skipped,
 * or — when the admin asks — its student is updated. Every row is checked exactly like Add Student and
 * saved on its own, all or nothing, so one bad row never leaves half a student behind.
 */
require_once __DIR__ . '/simple_xlsx_reader.php';
require_once __DIR__ . '/simple_xlsx_writer.php';
require_once __DIR__ . '/sibling_helper.php';

/**
 * The template's columns, in order: key => where it goes. Columns 49–52 were added at the end, so a sheet
 * filled in from an older 49-column template still reads correctly.
 */
function student_import_columns(): array {
    $s = 'students'; $g = 'guardian'; $h = 'history';
    return [
        'banglarshiksha_id' => $s, 'pen_id' => $s, 'apaar_id' => $s, 'student_name' => $s, 'name_as_per_aadhaar' => $s,
        'dob' => $s, 'gender' => $s, 'blood_group' => $s, 'religion' => $s, 'caste' => $s, 'sub_caste' => $s, 'disability' => $s,
        'birth_registration_number' => $s, 'student_aadhaar' => $s, 'village' => $s, 'post_office' => $s, 'police_station' => $s,
        'district' => $s, 'state' => $s, 'pin_code' => $s, 'mobile' => $s, 'email' => $s, 'bank_name' => $s, 'branch_name' => $s,
        'account_number' => $s, 'ifsc_code' => $s, 'admission_no' => $s, 'admission_year' => $s, 'admission_date' => $s,
        'father_name' => $g, 'father_aadhaar' => $g, 'father_voter_id' => $g, 'father_mobile' => $g, 'father_occupation' => $g,
        'mother_name' => $g, 'mother_aadhaar' => $g, 'mother_voter_id' => $g, 'mother_occupation' => $g,
        'guardian_name' => $g, 'guardian_relation' => $g, 'guardian_contact' => $g,
        'session_name' => $h, 'class_name' => $h, 'section_name' => $h, 'roll_no' => $h, 'previous_school' => $h,
        'disability_type' => $s, 'remarks' => $s,
        'father_qualification' => $g, 'annual_income' => $g, 'guardian_email' => $g, 'admission_class_name' => $s,
    ];
}

/** Send the template: the header row, and a sheet of instructions. */
function student_import_template(): void {
    $keys = array_keys(student_import_columns());
    $col = fn(string $k) => SimpleXLSXWriter::columnName(array_search($k, $keys, true) + 1);
    $notes = [
        ['Student import — how to fill the sheet'], [''],
        ['1. Keep row 1 (the column names) exactly as it is; add one student per row below it.'],
        ['2. Needed on every row: banglarshiksha_id (14 digits), student_name, class_name, section_name, roll_no.'],
        ['3. session_name is the session\'s name as in Academic Sessions (e.g. ' . (db_get_row("SELECT session_name FROM academic_sessions WHERE status = 'Active'")['session_name'] ?? '2026') . '); leave it blank for the active session.'],
        ['4. class_name and section_name must match a class and a section already set up for that session.'],
        ['5. Dates (dob, admission_date): YYYY-MM-DD or DD-MM-YYYY. An Excel date cell works too.'],
        ['6. gender: Male / Female / Other. Mobile numbers: 10 digits. Aadhaar: 12 digits.'],
        ['7. disability: Yes / No; with Yes, fill disability_type (column ' . $col('disability_type') . ').'],
        ['8. A blank Father / Mother Aadhaar is saved as "Not available".'],
        ['9. admission_class_name (column ' . $col('admission_class_name') . ') is the class the student first joined; blank = the current class.'],
        ['10. A Banglar Shiksha ID already in school is skipped, unless "Update them" is chosen on the import page.'],
        ['11. When updating, a blank cell keeps what is already stored — it never erases anything.'],
    ];
    SimpleXLSXWriter::downloadBook('student_import_template.xlsx', [
        ['name' => 'Student Import', 'rows' => [$keys], 'options' => ['header_rows' => 1, 'freeze_rows' => 1]],
        ['name' => 'Instructions', 'rows' => $notes, 'options' => ['header_rows' => 1]],
    ]);
}

/** A sheet date: an Excel date number, YYYY-MM-DD, or DD-MM-YYYY (also with / or .). '' when it is none of these. */
function student_import_date(string $v): string {
    if ($v === '') return '';
    if (preg_match('/^\d+(\.\d+)?$/', $v)) $v = SimpleXLSXReader::excelSerialToDate($v);
    if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $v, $m)) [$y, $mo, $d] = [$m[1], $m[2], $m[3]];
    elseif (preg_match('#^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$#', $v, $m)) [$d, $mo, $y] = [$m[1], $m[2], $m[3]];
    else return '';
    return checkdate((int)$mo, (int)$d, (int)$y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : '';
}

/** A value matched to one of the choices ignoring case, or left as it is. */
function student_import_pick(string $v, array $choices): string {
    foreach ($choices as $c) if (strcasecmp($v, $c) === 0) return $c;
    return $v;
}

/** One sheet row, tidied: [values by key, problems]. Formatting slips (spaces, +91, lower case) are fixed, not reported. */
function student_import_clean(array $cells): array {
    $v = [];
    foreach (array_keys(student_import_columns()) as $i => $k) $v[$k] = trim(preg_replace('/\s+/u', ' ', (string)($cells[$i] ?? '')));
    $digits = fn(string $x) => preg_replace('/[\s\-]/', '', $x);
    foreach (['mobile', 'father_mobile', 'guardian_contact'] as $k) {
        $m = preg_replace('/\D/', '', $v[$k]);
        if (strlen($m) === 12 && str_starts_with($m, '91')) $m = substr($m, 2);
        elseif (strlen($m) === 11 && str_starts_with($m, '0')) $m = substr($m, 1);
        $v[$k] = $v[$k] === '' ? '' : $m;
    }
    foreach (['banglarshiksha_id', 'pen_id', 'apaar_id', 'student_aadhaar', 'father_aadhaar', 'mother_aadhaar', 'pin_code'] as $k) $v[$k] = $digits($v[$k]);
    foreach (['ifsc_code', 'father_voter_id', 'mother_voter_id', 'class_name', 'section_name'] as $k) $v[$k] = strtoupper($v[$k]);
    $v['admission_class_name'] = strtoupper($v['admission_class_name']);
    $v['banglarshiksha_id'] = (string)student_normalize_bsid($v['banglarshiksha_id']);
    $v['gender'] = ['m' => 'Male', 'male' => 'Male', 'f' => 'Female', 'female' => 'Female', 'o' => 'Other', 'other' => 'Other'][strtolower($v['gender'])] ?? $v['gender'];
    $blood = str_replace(['POSITIVE', '+VE', 'NEGATIVE', '-VE', ' '], ['+', '+', '-', '-', ''], strtoupper($v['blood_group']));
    if (in_array($blood, ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'], true)) $v['blood_group'] = $blood;
    $v['religion'] = student_import_pick($v['religion'], student_religions());
    $v['caste'] = student_import_pick($v['caste'], student_castes());
    $v['disability'] = student_import_pick($v['disability'], ['Yes', 'No']);
    $v['disability_type'] = student_import_pick($v['disability_type'], student_disability_types());
    $v['guardian_relation'] = student_import_pick($v['guardian_relation'], student_guardian_relations());

    $errors = [];
    foreach (['dob' => 'Date of birth', 'admission_date' => 'Admission date'] as $k => $label) {
        if ($v[$k] === '') continue;
        $d = student_import_date($v[$k]);
        if ($d === '') $errors[] = "$label '{$v[$k]}' is not a date (use YYYY-MM-DD or DD-MM-YYYY).";
        $v[$k] = $d;
    }
    foreach (['banglarshiksha_id' => 'Banglar Shiksha ID', 'class_name' => 'Class', 'section_name' => 'Section', 'roll_no' => 'Roll'] as $k => $label) {
        if ($v[$k] === '') $errors[] = "$label is missing.";
    }
    $checked = student_validate($v);
    if ($v['student_name'] === '') unset($checked['student_name']);   // needed for a new student only; run() decides
    $errors = array_merge($errors, array_values($checked));
    foreach (['father_aadhaar' => 'Father Aadhaar', 'mother_aadhaar' => 'Mother Aadhaar'] as $k => $label) if (($m = student_v_aadhaar($v[$k])) !== null) $errors[] = "$label: $m";
    foreach (['father_mobile' => 'Father mobile', 'guardian_contact' => 'Guardian contact'] as $k => $label) if (($m = student_v_mobile($v[$k])) !== null) $errors[] = "$label: $m";
    foreach (['father_name' => 'Father name', 'mother_name' => 'Mother name', 'guardian_name' => 'Guardian name'] as $k => $label) if (($m = student_v_name($v[$k], $label)) !== null) $errors[] = $m;
    if (($m = student_v_email($v['guardian_email'])) !== null) $errors[] = "Guardian email: $m";
    if ($v['roll_no'] !== '' && !preg_match('/^\d{1,4}$/', $v['roll_no'])) $errors[] = 'Roll must be digits only (up to 4).';
    if ($v['admission_year'] !== '' && !preg_match('/^(19|20)\d\d$/', $v['admission_year'])) $errors[] = 'Admission year must be a 4-digit year.';
    if ($v['annual_income'] !== '' && (!is_numeric($v['annual_income']) || (float)$v['annual_income'] < 0)) $errors[] = 'Annual income must be a number.';
    if ($v['disability'] !== '' && !in_array($v['disability'], ['Yes', 'No'], true)) $errors[] = 'Disability must be Yes or No.';
    return [$v, $errors];
}

/** Every guardian row's compared details, loaded once per import: guardian_id => fields. */
function student_import_guardian_pool(): array {
    $pool = [];
    foreach (db_get_all('SELECT guardian_id, father_name, mother_name, father_mobile, father_voter_id, father_aadhaar FROM guardians') as $g) $pool[(int)$g['guardian_id']] = sibling_profile_fields($g);
    return $pool;
}

/** The guardian a new student should share (same rule as Add Student), or null. */
function student_import_match_guardian(array $v, array $pool): ?int {
    $fields = sibling_profile_fields($v);
    if (count(array_filter($fields, fn($x) => $x !== '')) < 3) return null;
    $best = null; $best_score = 0; $tie = false;
    foreach ($pool as $gid => $g) {
        $score = sibling_score($fields, $g);
        if ($score < 3 || $score < $best_score) continue;
        if ($score > $best_score) { $best = $gid; $best_score = $score; $tie = false; }
        elseif ($gid !== $best) $tie = true;
    }
    return $tie ? null : $best;
}

/**
 * Import a sheet. $update_existing: update the students whose Banglar Shiksha ID is already in school
 * (otherwise they are skipped). Returns counts and one line per row that was not simply created.
 */
function student_import_run(string $path, bool $update_existing): array {
    $out = ['created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'rows' => []];
    $rows = SimpleXLSXReader::readFirstSheet($path);
    $header = array_map(fn($x) => strtolower(trim((string)$x)), array_shift($rows) ?? []);
    $keys = array_keys(student_import_columns());
    foreach ($keys as $i => $k) {
        if ($i >= 49 && !isset($header[$i])) break;   // an older 49-column sheet
        if (($header[$i] ?? '') !== $k) throw new RuntimeException('This is not the student import template: column ' . SimpleXLSXWriter::columnName($i + 1) . " should be '$k'" . (isset($header[$i]) && $header[$i] !== '' ? ", not '{$header[$i]}'" : '') . '. Download the template and copy the data into it.');
    }

    $active = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active'")['id'] ?? 0);
    $session_rows = db_get_all('SELECT id, session_name FROM academic_sessions');
    $sessions = array_column($session_rows, 'id', 'session_name');
    $session_names = array_column($session_rows, 'session_name', 'id');
    $classes = array_column(db_get_all('SELECT id, UPPER(class_name) AS n FROM classes'), 'id', 'n');
    $pool = student_import_guardian_pool();

    foreach ($rows as $n => $cells) {
        $line = $n + 2;   // the row number in Excel
        if (implode('', array_map(fn($c) => trim((string)$c), $cells)) === '') continue;
        [$v, $errors] = student_import_clean($cells);
        $bsid = $v['banglarshiksha_id'];
        $existing = $bsid === '' ? null : db_get_row("SELECT id, student_name, student_status, guardian_id FROM students WHERE TRIM(LEADING '0' FROM banglarshiksha_id) = ? LIMIT 1", 's', ltrim($bsid, '0'));
        $who = $v['student_name'] !== '' ? $v['student_name'] : ($existing['student_name'] ?? 'row ' . $line);
        if ($existing && (!$update_existing || $existing['student_status'] !== 'Active')) {
            $why = $existing['student_status'] === 'Active' ? 'already in school — skipped' : "is {$existing['student_status']} — restore them first; not changed";
            $out['skipped']++; $out['rows'][] = [$line, 'skipped', $who, "Banglar Shiksha ID $bsid: {$existing['id']} {$existing['student_name']} $why."];
            continue;
        }
        if (!$existing) {   // a blank cell keeps what is stored, so these are needed only for a new student
            if ($v['student_name'] === '') $errors[] = 'Student name is missing.';
            if ($v['gender'] === '') $errors[] = 'Gender is missing.';
        }

        $session_id = $v['session_name'] === '' ? $active : (int)($sessions[$v['session_name']] ?? 0);
        if (!$session_id) $errors[] = $v['session_name'] === '' ? 'There is no active session.' : "Session '{$v['session_name']}' does not exist.";
        $class_id = (int)($classes[$v['class_name']] ?? 0);
        if ($v['class_name'] !== '' && !$class_id) $errors[] = "Class '{$v['class_name']}' does not exist.";
        $section_id = ($class_id && $session_id && $v['section_name'] !== '')
            ? (int)(db_get_row('SELECT id FROM sections WHERE session_id = ? AND class_id = ? AND UPPER(section_name) = ?', 'iis', $session_id, $class_id, $v['section_name'])['id'] ?? 0) : 0;
        if ($class_id && $session_id && $v['section_name'] !== '' && !$section_id) $errors[] = "Section '{$v['section_name']}' is not set up for class {$v['class_name']} in that session.";
        $admission_class_id = $v['admission_class_name'] === '' ? 0 : (int)($classes[$v['admission_class_name']] ?? 0);
        if ($v['admission_class_name'] !== '' && !$admission_class_id) $errors[] = "Admission class '{$v['admission_class_name']}' does not exist.";
        if ($errors) { $out['failed']++; $out['rows'][] = [$line, 'failed', $who, implode(' ', $errors)]; continue; }

        db_begin_transaction();
        try {
            $uid = $existing ? $existing['id'] : '';
            $clash = db_get_row('SELECT s.id, s.student_name FROM student_academic_history h JOIN students s ON s.id = h.student_id
                                 WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.roll_no = ? AND h.student_id <> ? LIMIT 1',
                                 'iiiss', $session_id, $class_id, $section_id, $v['roll_no'], $uid);
            if ($clash) throw new InvalidArgumentException("Roll {$v['roll_no']} of {$v['class_name']}-{$v['section_name']} already belongs to {$clash['id']} {$clash['student_name']}.");
            $student = []; $guardian = [];
            foreach (student_import_columns() as $k => $table) {
                if ($table === 'students' && $k !== 'admission_class_name') $student[$k] = $v[$k];
                if ($table === 'guardian') $guardian[$k] = $v[$k];
            }
            if ($dups = student_duplicates($student, $uid)) throw new InvalidArgumentException(implode(' ', $dups));

            if ($existing) {
                $now = db_get_row("SELECT a.session_name FROM student_academic_history h JOIN academic_sessions a ON a.id = h.session_id
                                   WHERE h.student_id = ? AND h.academic_status = 'Current' LIMIT 1", 's', $uid);
                $target = (string)$session_names[$session_id];
                if ($now && strcmp($now['session_name'], $target) > 0) throw new InvalidArgumentException("$uid is already in session {$now['session_name']} — an older sheet cannot move them back to $target.");
                // a blank cell keeps what is stored; the Banglar Shiksha ID itself never changes
                $set = array_filter($student, fn($x) => $x !== '');
                unset($set['banglarshiksha_id']);
                if ($admission_class_id) $set['admission_class_id'] = $admission_class_id;
                if ($set) db_update('students', student_blank_ids_to_null($set), ['id' => $uid]);
                $g = array_filter($guardian, fn($x) => $x !== '');
                foreach (['father', 'mother'] as $p) if (isset($g[$p . '_aadhaar'])) $g[$p . '_aadhaar_not_available'] = 0;
                if ($g && $existing['guardian_id']) db_update('guardians', $g, ['guardian_id' => (int)$existing['guardian_id']], 'i');
                elseif ($g) db_update('students', ['guardian_id' => student_import_new_guardian($guardian, $pool)], ['id' => $uid]);
                student_import_place($uid, $session_id, $class_id, $section_id, $v['roll_no'], $v['previous_school']);
                $out['updated']++; $out['rows'][] = [$line, 'updated', $who, "$uid — placed in {$v['class_name']}-{$v['section_name']}, roll {$v['roll_no']}."];
            } else {
                $gid = null;
                if (array_filter($guardian, fn($x) => $x !== '')) $gid = student_import_match_guardian($guardian, $pool) ?? student_import_new_guardian($guardian, $pool);
                $blank_to_null = array_map(fn($x) => $x === '' ? null : $x, $student);   // a blank date must not become 0000-00-00
                $uid = student_insert($GLOBALS['conn'], $blank_to_null + ['guardian_id' => $gid, 'admission_class_id' => $admission_class_id ?: $class_id],
                    $v['admission_year'] !== '' ? (int)$v['admission_year'] : null);
                student_import_place($uid, $session_id, $class_id, $section_id, $v['roll_no'], $v['previous_school']);
                $out['created']++; $out['rows'][] = [$line, 'created', $who, "$uid — {$v['class_name']}-{$v['section_name']}, roll {$v['roll_no']}."];
            }
            db_commit();
        } catch (Throwable $e) {
            db_rollback();
            $out['failed']++;
            $out['rows'][] = [$line, 'failed', $who, $e instanceof InvalidArgumentException || $e instanceof RuntimeException ? $e->getMessage() : 'Database error: ' . $e->getMessage()];
        }
    }
    return $out;
}

/** A guardian row for the details on the sheet; added to the pool so later rows of the same family share it. */
function student_import_new_guardian(array $g, array &$pool): int {
    $g += ['father_name' => '', 'mother_name' => '', 'father_aadhaar' => '', 'mother_aadhaar' => ''];
    $row = array_map(fn($x) => $x === '' ? null : $x, $g);
    foreach (['father_name', 'mother_name', 'father_aadhaar', 'mother_aadhaar'] as $k) $row[$k] = $g[$k];   // NOT NULL columns
    $row['father_aadhaar_not_available'] = $g['father_aadhaar'] === '' ? 1 : 0;
    $row['mother_aadhaar_not_available'] = $g['mother_aadhaar'] === '' ? 1 : 0;
    $id = (int)db_insert('guardians', $row);
    $pool[$id] = sibling_profile_fields($g);
    return $id;
}

/**
 * Put a student in a class for a session: their row of that session is corrected in place, or — for a
 * new session — the current placement is closed and a new one opened.
 */
function student_import_place(string $uid, int $session_id, int $class_id, int $section_id, string $roll, string $previous_school): void {
    $row = db_get_row('SELECT id FROM student_academic_history WHERE student_id = ? AND session_id = ? ORDER BY id DESC LIMIT 1', 'si', $uid, $session_id);
    $place = ['class_id' => $class_id, 'section_id' => $section_id, 'roll_no' => $roll,
              'promotion_status' => 'Studying', 'student_status' => 'Active', 'academic_status' => 'Current'];
    if ($previous_school !== '') $place['previous_school'] = $previous_school;
    if ($row) {
        db_update('student_academic_history', $place, ['id' => (int)$row['id']], 'i');
        return;
    }
    db_execute("UPDATE student_academic_history SET academic_status = 'History', promotion_status = 'Promoted' WHERE student_id = ? AND academic_status = 'Current'", 's', $uid);
    db_insert('student_academic_history', ['student_id' => $uid, 'session_id' => $session_id] + $place);
}

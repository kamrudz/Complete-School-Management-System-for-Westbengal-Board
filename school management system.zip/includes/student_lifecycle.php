<?php
/**
 * A student's status (Active, Deactivated, Deleted, TC) changes only through student_set_status(), so
 * students.student_status and the academic history always agree: a student who is not Active has no
 * Current history row, which is what keeps them off every list of the running session.
 */

/**
 * Move a student to a new status. Runs in its own transaction and logs the change.
 *
 *   'Deactivated' | 'Deleted'  from Active (Deleted also from Deactivated) — the Current row is closed as History
 *   'TC'                       from Active — $opts: tc_no, tc_date, reason, conduct, dues_cleared -> tc_students row
 *   'Active'  (restore)        from Deactivated / Deleted / TC —
 *                              the latest closed row is reopened as Current when it belongs to the running session;
 *                              otherwise a new Current row is created and $opts must carry class_id, section_id, roll_no.
 *                              A TC restore marks the TC record Cancelled ($opts['cancel_reason']) — it is never deleted.
 *
 * Returns ['ok' => true, 'message' => ...] or ['ok' => false, 'message' => ...]. A rule violation never
 * throws; a database failure rolls back and is rethrown.
 */
function student_set_status(mysqli $conn, string $uid, string $to, array $opts = [], int $admin_id = 0): array {
    $uid = student_uid_clean($uid);
    $student = $uid !== '' ? db_get_row('SELECT id, student_name, student_status FROM students WHERE id = ?', 's', $uid) : null;
    if (!$student) return ['ok' => false, 'message' => 'Student not found.'];
    $from = $student['student_status'];
    $allowed = [
        'Deactivated' => ['Active'],
        'Deleted'     => ['Active', 'Deactivated'],
        'TC'          => ['Active'],
        'Active'      => ['Deactivated', 'Deleted', 'TC'],
    ];
    if (!isset($allowed[$to])) return ['ok' => false, 'message' => "Unknown status '$to'."];
    if (!in_array($from, $allowed[$to], true)) return ['ok' => false, 'message' => "{$student['student_name']} is $from — cannot change to $to from there."];

    $active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
    db_begin_transaction();
    try {
        if ($to === 'TC') {
            $tc_no = trim((string)($opts['tc_no'] ?? ''));
            if ($tc_no === '' || empty($opts['tc_date'])) throw new InvalidArgumentException('TC number and date are required.');
            if (db_get_row('SELECT id FROM tc_students WHERE tc_no = ?', 's', $tc_no)) throw new InvalidArgumentException("TC number '$tc_no' is already used (a cancelled TC keeps its number).");
            $dues = !empty($opts['dues_cleared']) ? 1 : 0;
            $by = $admin_id ?: null;
            $token = bin2hex(random_bytes(32));   // the QR on the certificate points at tc_verify.php?token=…
            db_execute("INSERT INTO tc_students (student_id, tc_no, tc_date, reason, conduct, dues_cleared, status, issued_by, verification_token) VALUES (?,?,?,?,?,?,'Issued',?,?)",
                'sssssiis', $uid, $tc_no, $opts['tc_date'], (string)($opts['reason'] ?? ''), (string)($opts['conduct'] ?? ''), $dues, $by, $token);
        }

        if ($to !== 'Active') {
            // leaving: close the Current row
            db_execute("UPDATE student_academic_history SET academic_status = 'History', student_status = ? WHERE student_id = ? AND academic_status = 'Current'", 'ss', $to, $uid);
        } else {
            // restoring: reopen or re-place
            $last = db_get_row('SELECT * FROM student_academic_history WHERE student_id = ? ORDER BY id DESC LIMIT 1', 's', $uid);
            $class_id = (int)($opts['class_id'] ?? 0); $section_id = (int)($opts['section_id'] ?? 0); $roll_no = trim((string)($opts['roll_no'] ?? ''));
            if ($last && (int)$last['session_id'] === $active_session) {
                if ($class_id <= 0) $class_id = (int)$last['class_id'];
                if ($section_id <= 0) $section_id = (int)$last['section_id'];
                if ($roll_no === '') $roll_no = (string)$last['roll_no'];
                db_execute("UPDATE student_academic_history SET academic_status = 'Current', student_status = 'Active', promotion_status = 'Studying', class_id = ?, section_id = ?, roll_no = ? WHERE id = ?",
                    'iisi', $class_id, $section_id, $roll_no, $last['id']);
            } else {
                if (!$active_session) throw new InvalidArgumentException('No active academic session — activate one first.');
                if ($class_id <= 0 || $section_id <= 0 || $roll_no === '') throw new InvalidArgumentException('Class, section and roll for the current session are required to restore this student.');
                if (!db_get_row('SELECT id FROM sections WHERE id = ? AND class_id = ? AND session_id = ?', 'iii', $section_id, $class_id, $active_session)) throw new InvalidArgumentException('That section does not belong to the class in the current session.');
                $clash = db_get_row("SELECT s.student_name FROM student_academic_history h JOIN students s ON s.id = h.student_id WHERE h.session_id = ? AND h.class_id = ? AND h.section_id = ? AND h.roll_no = ? AND h.student_id <> ? LIMIT 1", 'iiiss', $active_session, $class_id, $section_id, $roll_no, $uid);
                if ($clash) throw new InvalidArgumentException("Roll $roll_no already belongs to {$clash['student_name']} in that section.");
                $prev = (string)($last['previous_school'] ?? '');
                db_execute("INSERT INTO student_academic_history (student_id, session_id, class_id, section_id, roll_no, promotion_status, student_status, academic_status, previous_school) VALUES (?,?,?,?,?,'Studying','Active','Current',?)",
                    'siiiss', $uid, $active_session, $class_id, $section_id, $roll_no, $prev);
            }
            if ($from === 'TC') {
                $why = (string)($opts['cancel_reason'] ?? 'Restored to Active');
                db_execute("UPDATE tc_students SET status = 'Cancelled', cancelled_at = NOW(), cancel_reason = ? WHERE student_id = ? AND status = 'Issued'", 'ss', $why, $uid);
            }
        }
        db_execute('UPDATE students SET student_status = ? WHERE id = ?', 'ss', $to, $uid);
        db_commit();
    } catch (InvalidArgumentException $e) {
        db_rollback();
        return ['ok' => false, 'message' => $e->getMessage()];
    } catch (Throwable $e) {
        db_rollback();
        throw $e;
    }
    if (function_exists('log_action')) {
        $note = "{$student['student_name']}: $from -> $to" . ($to === 'TC' ? ' (TC ' . $opts['tc_no'] . ')' : '')
            . (in_array($to, ['Deactivated', 'Deleted'], true) && trim((string)($opts['reason'] ?? '')) !== '' ? ' | Reason: ' . trim((string)$opts['reason']) : '');
        log_action($admin_id, 'STUDENT_STATUS_' . strtoupper($to), 'students', $uid, null, $note);
    }
    return ['ok' => true, 'message' => "{$student['student_name']} is now $to.", 'from' => $from];
}

/** The uploaded files of a student, as [dir, filename] pairs (relative to admin/) — removed on permanent delete. */
function student_files(array $student): array {
    $map = [
        'photo'                 => '../uploads/students/',
        'signature'             => '../uploads/students/signatures/',
        'birth_certificate'     => student_docs_dir(),
        'student_aadhaar_image' => student_docs_dir(),
    ];
    $out = [];
    foreach ($map as $col => $dir) if (!empty($student[$col])) $out[] = [$dir, $student[$col]];
    return $out;
}

/** How many rows elsewhere belong to this student (table => rows) — shown before a permanent delete. */
function student_dependency_counts(string $uid): array {
    $out = db_dependents('students', $uid);
    // library_issues.borrower_id holds staff ids too, so it has no foreign key to students
    $n = (int)(db_get_row("SELECT COUNT(*) AS c FROM library_issues WHERE borrower_type = 'Student' AND borrower_id = ?", 's', $uid)['c'] ?? 0);
    if ($n > 0) $out['library_issues'] = $n;
    return $out;
}

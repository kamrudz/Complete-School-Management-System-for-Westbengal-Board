<?php
/** The subject master list. Names are unique (case-insensitive); the code is optional. */

/** Trim and collapse inner spaces: "Physical   Education" -> "Physical Education". */
function subject_name_normalise($name): string {
    return trim(preg_replace('/\s+/u', ' ', (string)$name));
}

function subject_code_normalise($code): string {
    return strtoupper(trim((string)$code));
}

/** Null when acceptable, otherwise the message to show. */
function subject_name_error(string $name): ?string {
    if ($name === '') return 'Subject name is required.';
    if (mb_strlen($name) > 60) return 'Subject name must be 60 characters or fewer.';
    if (!preg_match('/^[\p{L}\p{N} .&()\-\/]+$/u', $name)) return 'Subject name can only contain letters, digits, spaces and . & ( ) - /';
    return null;
}

function subject_code_error(string $code): ?string {
    if ($code === '' || preg_match('/^[A-Z0-9\-]{1,20}$/', $code)) return null;
    return 'Subject code must be 1–20 capital letters, digits or hyphens.';
}

/** Insert one subject: 'added', 'duplicate', or the error message. The unique name is the duplicate guard. */
function subject_insert(string $name, string $code): string {
    $name = subject_name_normalise($name);
    $code = subject_code_normalise($code);
    $error = subject_name_error($name) ?? subject_code_error($code);
    if ($error !== null) return $error;
    try {
        db_insert('subjects', ['subject_name' => $name, 'subject_code' => $code]);
        return 'added';
    } catch (mysqli_sql_exception $e) {
        if ((int)$e->getCode() !== 1062) throw $e;
        return 'duplicate';
    }
}

<?php
/**
 * includes/user_access.php — Portal & Self-Edit Access Control
 *
 * Admin controls which pages/features students & teachers can access and which
 * profile fields students may edit. Settings are stored in `user_access_permissions`.
 * Default behaviour: if no row exists for a key, access is ALLOWED (so existing
 * portals keep working until admin turns something off).
 */

if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

/**
 * All available access keys grouped by user type.
 * Each key -> [label (Bengali), hint (optional)].
 */
function ua_all_keys() {
    return [
        'student' => [
            'feature_profile'        => ['My Profile', 'Student apna profile dekhbe'],
            'feature_edit_profile'   => ['Self-Edit Profile (Master)', 'Eita on thakle student edit_profile.php te jete parbe; niche field-wise permission eir moddhe kaaj kore'],
            'feature_routine'        => ['Class Routine', 'Nijer class/section er routine'],
            'feature_holidays'       => ['Holiday List', 'Chhuti / vacation list'],
            'feature_progress_report'=> ['Progress Report', 'Examination result / progress report'],
            'feature_fees'           => ['My Fees', 'Nijer bill, baki taka ar money receipt dekhbe'],
        ],
        'teacher' => [
            'feature_my_routine'     => ['My Routine', 'Nijer routine'],
            'feature_my_students'    => ['My Students', 'Student list'],
            'feature_my_attendance'  => ['My Attendance', 'Nijer attendance'],
            'feature_marks_entry'    => ['Marks Entry (V-X)', 'Examination marks entry'],
            'feature_hs_marks'       => ['Marks Entry (HS)', 'HS marks entry'],
            'feature_marks_view'     => ['View Marks', 'Marks dekhbe'],
            'feature_notices'        => ['Notices', 'Notice dekha'],
            'feature_profile_view'   => ['My Profile', 'Nijer profile dekha'],
        ],
    ];
}

/**
 * Editable student fields config:
 *   key -> [label, hint, columns: [[db_col, type, label], ...]]
 * type: text | number | email | tel | date | blood | photo
 */
function ua_student_edit_fields() {
    return [
        'edit_mobile' => [
            'label' => 'Mobile Number',
            'hint'  => 'Student er mobile number',
            'fields'=> [
                ['mobile', 'tel', 'Mobile Number'],
            ],
        ],
        'edit_email' => [
            'label' => 'Email Address',
            'hint'  => 'Student er email',
            'fields'=> [
                ['email', 'email', 'Email Address'],
            ],
        ],
        'edit_photo' => [
            'label' => 'Photo',
            'hint'  => 'Student upload korte parbe (jpg/png, max 1MB)',
            'fields'=> [
                ['photo', 'photo', 'Photo'],
            ],
        ],
        'edit_signature' => [
            'label' => 'Signature',
            'hint'  => 'Student nijer signature upload korte parbe (jpg/png, max 1MB)',
            'fields'=> [
                ['signature', 'photo', 'Signature'],
            ],
        ],
        'edit_blood_group' => [
            'label' => 'Blood Group',
            'hint'  => 'Blood group update',
            'fields'=> [
                ['blood_group', 'blood', 'Blood Group'],
            ],
        ],
        'edit_name_as_per_aadhaar' => [
            'label' => 'Name (as per Aadhaar)',
            'hint'  => 'Aadhaar onujayi naam',
            'fields'=> [
                ['name_as_per_aadhaar', 'text', 'Name as per Aadhaar'],
            ],
        ],
        'edit_aadhaar' => [
            'label' => 'Aadhaar Number',
            'hint'  => 'Student er aadhaar',
            'fields'=> [
                ['student_aadhaar', 'text', 'Aadhaar Number'],
            ],
        ],
        'edit_birth_registration' => [
            'label' => 'Birth Registration No.',
            'hint'  => 'Birth registration number',
            'fields'=> [
                ['birth_registration_number', 'text', 'Birth Registration Number'],
            ],
        ],
        'edit_address' => [
            'label' => 'Address',
            'hint'  => 'Village, post office, police station, district, state, PIN',
            'fields'=> [
                ['village', 'text', 'Village'],
                ['post_office', 'text', 'Post Office'],
                ['police_station', 'text', 'Police Station'],
                ['district', 'text', 'District'],
                ['state', 'text', 'State'],
                ['pin_code', 'text', 'PIN Code'],
            ],
        ],
        'edit_bank' => [
            'label' => 'Bank Details',
            'hint'  => 'Bank name, branch, account no., IFSC',
            'fields'=> [
                ['bank_name', 'text', 'Bank Name'],
                ['branch_name', 'text', 'Branch Name'],
                ['account_number', 'text', 'Account Number'],
                ['ifsc_code', 'text', 'IFSC Code'],
            ],
        ],
        'edit_other' => [
            'label' => 'Other Details',
            'hint'  => 'Religion, caste, sub-caste, disability',
            'fields'=> [
                ['religion', 'text', 'Religion'],
                ['caste', 'text', 'Caste'],
                ['sub_caste', 'text', 'Sub-Caste'],
                ['disability', 'text', 'Disability'],
                ['disability_type', 'text', 'Disability Type'],
            ],
        ],
    ];
}

/**
 * Ensure `user_access_permissions` table exists and is seeded with all keys.
 */
function ua_ensure_table($conn) {
    static $done = false;
    if ($done) return true;
    $t = "CREATE TABLE IF NOT EXISTS `user_access_permissions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_type` enum('student','teacher') NOT NULL,
        `access_key` varchar(80) NOT NULL,
        `is_allowed` tinyint(1) NOT NULL DEFAULT 1,
        `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_type_key` (`user_type`,`access_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
    mysqli_query($conn, $t);

    $types = ['student', 'teacher'];
    $keys = array_merge(
        array_keys(ua_all_keys()['student']),
        array_keys(ua_all_keys()['teacher']),
        array_keys(ua_student_edit_fields())
    );
    $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO `user_access_permissions` (`user_type`,`access_key`,`is_allowed`) VALUES (?,?,1)");
    foreach ($keys as $key) {
        $ut = (strpos($key, 'edit_') === 0) ? 'student' : ((isset(ua_all_keys()['student'][$key])) ? 'student' : 'teacher');
        mysqli_stmt_bind_param($stmt, 'ss', $ut, $key);
        mysqli_stmt_execute($stmt);
    }
    if ($stmt) mysqli_stmt_close($stmt);
    $done = true;
    return true;
}

/**
 * Load full access map: ['student' => ['feature_profile' => 1|0, ...], ...]
 */
function ua_access_map($conn) {
    static $map = null;
    if ($map !== null) return $map;
    ua_ensure_table($conn);
    $map = [];
    $res = mysqli_query($conn, "SELECT `user_type`,`access_key`,`is_allowed` FROM `user_access_permissions`");
    if ($res) {
        while ($r = mysqli_fetch_assoc($res)) {
            $map[$r['user_type']][$r['access_key']] = (int)$r['is_allowed'];
        }
    }
    // Default ALLOWED for any key not stored
    foreach (ua_all_keys() as $ut => $keys) {
        foreach (array_keys($keys) as $key) {
            if (!isset($map[$ut][$key])) $map[$ut][$key] = 1;
        }
    }
    return $map;
}

/**
 * Check whether a user type may use a feature.
 */
function ua_can($conn, $user_type, $access_key) {
    $map = ua_access_map($conn);
    if (isset($map[$user_type][$access_key])) return (bool)$map[$user_type][$access_key];
    return true;
}

/**
 * List of student profile fields the logged-in student may EDIT (respects both
 * the master switch and the individual field toggles).
 * Returns: ['edit_mobile' => [ ['db_col','type','label'], ...], ...]
 */
function ua_student_editable_blocks($conn) {
    if (!ua_can($conn, 'student', 'feature_edit_profile')) return [];
    $allowed = [];
    foreach (ua_student_edit_fields() as $key => $block) {
        if (ua_can($conn, 'student', $key)) $allowed[$key] = $block;
    }
    return $allowed;
}

/**
 * Union of all editable column names (for whitelist updates).
 */
function ua_student_editable_columns($conn) {
    $cols = [];
    foreach (ua_student_editable_blocks($conn) as $block) {
        foreach ($block['fields'] as $f) $cols[] = $f[0];
    }
    return $cols;
}

/**
 * Student activity log (self-actions). Separate from admin_logs because that
 * table is strictly admin-oriented (admin_id FK NOT NULL).
 */
function ua_log_student_activity($conn, $student_id, $action, $details = '') {
    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `student_activity_logs` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `student_id` int(11) NOT NULL,
        `action` varchar(100) NOT NULL,
        `details` text DEFAULT NULL,
        `ip_address` varchar(45) DEFAULT NULL,
        `user_agent` varchar(255) DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
        PRIMARY KEY (`id`),
        KEY `idx_student` (`student_id`),
        KEY `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    if (is_array($details)) $details = json_encode($details, JSON_UNESCAPED_UNICODE);
    $stmt = mysqli_prepare($conn, "INSERT INTO `student_activity_logs` (`student_id`,`action`,`details`,`ip_address`,`user_agent`) VALUES (?,?,?,?,?)");
    if (!$stmt) return false;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $ua = substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 254);
    mysqli_stmt_bind_param($stmt, 'sssss', $student_id, $action, $details, $ip, $ua);
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}

<?php
require_once __DIR__ . '/includes/site.php';

/** An old contact form may still post here; the form lives on its own page now. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_query'])) { header('Location: contact.php', true, 303); exit(); }

$d = site_data();
$counts = site_counts();
[$notices] = site_notices(5);
[$photos, $photo_total] = site_gallery(8);
$holidays = site_upcoming_holidays(5);
$teachers = site_teachers();
$subjects = count(array_unique(array_column($teachers, 'subject')));
$range = site_class_range();
$about = $d['about'] !== '' ? $d['about']
    : trim(($d['since'] ? 'Teaching since ' . $d['since'] . '. ' : '') . ($range !== '' ? 'Classes ' . $range . '.' : ''));

site_page('', 'index.php');
?>
<section class="hero">
    <div class="bg<?php echo $d['hero'] === '' ? ' rays' : ''; ?>"<?php echo $d['hero'] !== '' ? ' style="background-image:url(\'' . h($d['hero']) . '\')"' : ''; ?>></div>
    <div class="sun"></div>
    <?php if ($d['hero'] === '' && $d['logo'] !== ''): ?><div class="seal"><img src="<?php echo h($d['logo']); ?>" alt=""></div><?php endif; ?>
    <div class="wrap">
        <span class="kicker"><i class="fas fa-sun"></i> <?php echo $d['since'] ? 'Since ' . (int)$d['since'] : 'Welcome'; ?></span>
        <h1><?php echo h($d['hero_title'] !== '' ? $d['hero_title'] : $d['name']); ?></h1>
        <?php $line = $d['hero_subtitle'] !== '' ? $d['hero_subtitle'] : $d['motto']; if ($line !== ''): ?><p class="motto"><?php echo h($line); ?></p><?php endif; ?>
        <div class="cta">
            <?php if ($d['adm_open']): ?>
                <a href="admission.php" class="btn btn-gold"><i class="fas fa-pen-to-square"></i> Apply for admission</a>
            <?php else: ?>
                <a href="about.php" class="btn btn-gold"><i class="fas fa-school"></i> About the school</a>
            <?php endif; ?>
            <a href="result.php" class="btn btn-ghost"><i class="fas fa-square-poll-vertical"></i> Check a result</a>
            <a href="notices.php" class="btn btn-ghost"><i class="fas fa-bullhorn"></i> Notices</a>
        </div>
    </div>
</section>

<section class="stats">
    <div class="wrap">
        <div class="grid">
            <div class="cell"><i class="fas fa-user-graduate"></i><b><?php echo number_format($counts['students']); ?></b><span>Students</span></div>
            <div class="cell"><i class="fas fa-chalkboard-user"></i><b><?php echo number_format($counts['teachers']); ?></b><span>Teachers</span></div>
            <div class="cell"><i class="fas fa-layer-group"></i><b><?php echo number_format($counts['classes']); ?></b><span>Classes</span></div>
            <div class="cell"><i class="fas fa-landmark"></i><b><?php echo $d['since'] ? (int)date('Y') - (int)$d['since'] : '—'; ?></b><span>Years of teaching</span></div>
        </div>
    </div>
</section>

<?php if ($d['adm_shown']): ?>
<section class="admit" aria-label="Admission">
    <div class="wrap">
        <span class="tag"><?php echo $d['adm_open'] ? 'Admission open' : 'Admission'; ?></span>
        <div class="grow">
            <b><?php echo $d['adm_open'] ? 'Applications are being taken' . ($d['adm_session'] !== '' ? ' for ' . h($d['adm_session']) : '') : h($d['adm_reason']); ?></b>
            <?php if ($d['adm_classes']): ?>
                <span>Class <?php echo h(implode(', ', array_column($d['adm_classes'], 'name'))); ?><?php echo !empty($d['adm']['admission_end']) ? ' · Last date ' . h(date('d M Y', strtotime($d['adm']['admission_end']))) : ''; ?></span>
            <?php endif; ?>
        </div>
        <?php if ($d['adm_open']): ?><a href="admission.php" class="btn btn-brand btn-sm">Apply now <i class="fas fa-arrow-right"></i></a><?php endif; ?>
        <a href="admission_status.php" class="btn btn-line btn-sm">Check a status</a>
    </div>
</section>
<?php endif; ?>

<?php if ($d['message'] !== ''): ?>
<section class="sec">
    <div class="wrap message reveal">
        <div class="photo">
            <?php echo $d['hoi_photo'] !== '' ? '<img src="' . h($d['hoi_photo']) . '" alt="' . h($d['hoi']) . '" loading="lazy">' : site_avatar($d['hoi'] ?: 'Head', '', ' big'); ?>
        </div>
        <div>
            <span class="kick">From the head of the institution</span>
            <blockquote><?php echo nl2br(h($d['message'])); ?></blockquote>
            <?php if ($d['hoi'] !== ''): ?><div class="who"><b><?php echo h($d['hoi']); ?></b><span>Head of the Institution</span></div><?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="sec<?php echo $d['message'] !== '' ? ' tint' : ''; ?>">
    <div class="wrap">
        <div class="head reveal"><span class="kick">What is happening</span><h2>Notices and coming holidays</h2><p>Everything the school has told parents and students, newest first.</p></div>
        <div class="board">
            <div class="panel reveal">
                <h3><i class="fas fa-bullhorn"></i> Latest notices</h3>
                <?php if (!$notices): ?>
                    <div class="empty"><i class="fas fa-bullhorn"></i>No notice right now. New ones appear here the day they are published.</div>
                <?php else: ?>
                <ul class="nlist">
                    <?php foreach ($notices as $n): ?>
                    <li><a href="<?php echo h('notice.php?id=' . (int)$n['id']); ?>">
                        <?php echo site_date_block($n['publish_date']); ?>
                        <div>
                            <div class="t"><?php echo h($n['notice_title']); ?>
                                <?php if (notice_is_new($n['publish_date'])): ?><span class="pill new">New</span><?php endif; ?>
                                <?php if (!empty($n['attachment'])): ?><span class="pill file"><i class="fas fa-paperclip"></i> File</span><?php endif; ?></div>
                            <?php if (trim((string)$n['notice_details']) !== ''): ?><div class="s"><?php echo h(mb_substr(trim($n['notice_details']), 0, 160)); ?></div><?php endif; ?>
                        </div>
                    </a></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <div class="foot"><a class="more" href="notices.php">Every notice <i class="fas fa-arrow-right"></i></a></div>
            </div>
            <div class="panel reveal">
                <h3><i class="fas fa-calendar-days"></i> Coming holidays</h3>
                <?php if (!$holidays): ?>
                    <div class="empty"><i class="fas fa-calendar-days"></i>No holiday is listed for the days ahead.</div>
                <?php else: ?>
                <ul class="hlist">
                    <?php foreach ($holidays as $hd): [$from, $to] = holiday_span($hd); ?>
                    <li><?php echo site_date_block($from); ?>
                        <div><div class="t"><?php echo h($hd['holiday_name']); ?></div>
                            <div class="s"><?php echo $from !== $to ? h('Till ' . date('d M', strtotime($to)) . ' · ' . holiday_working_days($hd) . ' working days') : h(date('l', strtotime($from))); ?></div></div></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                <div class="foot"><a class="more" href="holidays.php">The whole list <i class="fas fa-arrow-right"></i></a></div>
            </div>
        </div>
    </div>
</section>

<?php if ($photos): ?>
<section class="sec<?php echo $d['message'] !== '' ? '' : ' tint'; ?>">
    <div class="wrap">
        <div class="row-head reveal">
            <div class="head"><span class="kick">Life at school</span><h2>From the gallery</h2></div>
            <a class="more" href="gallery.php">All <?php echo (int)$photo_total; ?> photographs <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="gal reveal">
            <?php foreach ($photos as $p): ?>
            <a href="<?php echo h('uploads/gallery/' . $p['photo']); ?>" data-light data-title="<?php echo h($p['title'] ?? ''); ?>">
                <img src="<?php echo h('uploads/gallery/' . $p['photo']); ?>" alt="<?php echo h($p['title'] ?? ''); ?>" loading="lazy">
                <span><?php echo h($p['title'] ?? ''); ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($teachers): ?>
<section class="sec">
    <div class="wrap">
        <div class="teaser reveal">
            <div class="faces">
                <?php foreach (array_slice($teachers, 0, 6) as $t) echo site_avatar($t['staff_name'], $t['photo_url']); ?>
            </div>
            <div class="grow">
                <h2><?php echo count($teachers); ?> teachers, <?php echo $subjects; ?> subjects</h2>
                <p>Meet the people who teach here — who teaches what, and since when.</p>
            </div>
            <a href="teachers.php" class="btn btn-gold">Meet our teachers <i class="fas fa-arrow-right"></i></a>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="sec tint">
    <div class="wrap split reveal">
        <div>
            <span class="kick">About us</span>
            <h2><?php echo h($d['short']); ?></h2>
            <?php if ($about !== ''): ?><p style="color:var(--muted);font-size:17px"><?php echo h(mb_substr($about, 0, 420)); ?><?php echo mb_strlen($about) > 420 ? '…' : ''; ?></p><?php endif; ?>
            <a href="about.php" class="btn btn-brand">More about the school <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php if ($d['about_img'] !== ''): ?>
            <img src="<?php echo h($d['about_img']); ?>" alt="<?php echo h($d['name']); ?>" loading="lazy">
        <?php else: ?>
            <div class="facts">
                <?php if ($d['since']): ?><div class="fact"><span>Established</span><b><?php echo (int)$d['since']; ?></b></div><?php endif; ?>
                <?php if ($d['udise'] !== ''): ?><div class="fact"><span>UDISE code</span><b><?php echo h($d['udise']); ?></b></div><?php endif; ?>
                <?php if ($range !== ''): ?><div class="fact"><span>Classes</span><b><?php echo h($range); ?></b></div><?php endif; ?>
                <?php if ($d['address'] !== ''): ?><div class="fact"><span>Where</span><b><?php echo h($d['address']); ?></b></div><?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="sec tight">
    <div class="wrap">
        <div class="teaser reveal" style="background:linear-gradient(120deg,var(--ink),var(--brand))">
            <div class="grow">
                <h2>Have a question?</h2>
                <p>Write to the school — the office reads every message.</p>
            </div>
            <a href="contact.php" class="btn btn-gold"><i class="fas fa-paper-plane"></i> Write to us</a>
            <?php if ($d['phone'] !== ''): ?><a href="tel:<?php echo h(preg_replace('/[^0-9+]/', '', $d['phone'])); ?>" class="btn btn-ghost"><i class="fas fa-phone"></i> <?php echo h($d['phone']); ?></a><?php endif; ?>
        </div>
    </div>
</section>
<?php site_footer();

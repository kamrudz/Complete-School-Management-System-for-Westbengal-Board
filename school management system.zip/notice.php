<?php
require_once __DIR__ . '/includes/site.php';

/** One notice. A draft, or one whose date has not come, is not found — the same as one that never existed. */
$id = (int)($_GET['id'] ?? 0);
$notice = $id ? db_get_row('SELECT id, notice_title, notice_details, publish_date, attachment FROM notices WHERE id = ? AND ' . NOTICE_LIVE . ' LIMIT 1', 'i', $id) : null;
[$latest] = site_notices(6);
$latest = array_values(array_filter($latest, fn($n) => (int)$n['id'] !== $id));
if (!$notice) http_response_code(404);

$file = '';
$kind = '';
if ($notice && !empty($notice['attachment']) && is_file(__DIR__ . '/uploads/notices/' . basename($notice['attachment']))) {
    $file = 'uploads/notices/' . rawurlencode(basename($notice['attachment']));
    $kind = strtolower(pathinfo($notice['attachment'], PATHINFO_EXTENSION)) === 'pdf' ? 'pdf' : 'image';
}

site_page($notice ? $notice['notice_title'] : 'Notice not found', 'notices.php', $notice ? mb_substr(trim((string)$notice['notice_details']), 0, 200) : '');
site_band($notice ? 'Notice' : 'Notice not found', '', 'Notices');
?>
<section class="sec">
    <div class="wrap article">
        <article class="body">
            <?php if (!$notice): ?>
                <h1>This notice is not here</h1>
                <p style="color:var(--muted)">It may have been taken down, or the link may be wrong.</p>
                <a href="notices.php" class="btn btn-brand"><i class="fas fa-arrow-left"></i> Every notice</a>
            <?php else: ?>
                <div class="when">
                    <span><i class="far fa-calendar"></i> <?php echo h(date('l, d F Y', strtotime($notice['publish_date']))); ?></span>
                    <?php if (notice_is_new($notice['publish_date'])): ?><span class="pill new">New</span><?php endif; ?>
                </div>
                <h1><?php echo h($notice['notice_title']); ?></h1>
                <?php if (trim((string)$notice['notice_details']) !== ''): ?><div class="text"><?php echo h($notice['notice_details']); ?></div><?php endif; ?>
                <?php if ($file !== ''): ?>
                <div class="attach">
                    <i class="fas <?php echo $kind === 'pdf' ? 'fa-file-pdf' : 'fa-file-image'; ?>"></i>
                    <div class="grow"><b>The notice as issued</b><br><span style="color:var(--muted);font-size:14px"><?php echo $kind === 'pdf' ? 'PDF document' : 'Picture'; ?></span></div>
                    <a href="<?php echo h($file); ?>" target="_blank" rel="noopener" class="btn btn-brand btn-sm"><i class="fas fa-download"></i> Open</a>
                </div>
                <?php if ($kind === 'image'): ?><a href="<?php echo h($file); ?>" data-light data-title="<?php echo h($notice['notice_title']); ?>"><img src="<?php echo h($file); ?>" alt="<?php echo h($notice['notice_title']); ?>" style="margin-top:18px;border-radius:10px;border:1px solid var(--line)"></a><?php endif; ?>
                <?php endif; ?>
                <p style="margin:26px 0 0"><a class="more" href="notices.php"><i class="fas fa-arrow-left"></i> Every notice</a></p>
            <?php endif; ?>
        </article>
        <aside class="panel">
            <h3><i class="fas fa-bullhorn"></i> Other notices</h3>
            <?php if (!$latest): ?>
                <div class="empty">No other notice.</div>
            <?php else: ?>
            <ul class="nlist">
                <?php foreach (array_slice($latest, 0, 5) as $n): ?>
                <li><a href="<?php echo h('notice.php?id=' . (int)$n['id']); ?>"><?php echo site_date_block($n['publish_date']); ?><div class="t"><?php echo h($n['notice_title']); ?></div></a></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </aside>
    </div>
</section>
<?php site_footer();

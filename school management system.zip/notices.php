<?php
require_once __DIR__ . '/includes/site.php';

/** Every notice the school has published whose date has come, newest first. */
$per = 12;
$search = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
[$rows, $total] = site_notices($per, ($page - 1) * $per, $search);
$pages = max(1, (int)ceil($total / $per));
if ($page > $pages) { $page = $pages; [$rows] = site_notices($per, ($page - 1) * $per, $search); }

site_page('Notices', 'notices.php');
site_band('Notices', 'What the school has told parents and students, newest first.');
?>
<section class="sec">
    <div class="wrap" style="max-width:900px">
        <form class="tools" method="get" role="search">
            <label class="search"><span class="sr-only">Search the notices</span><i class="fas fa-magnifying-glass"></i>
                <input type="search" name="q" value="<?php echo h($search); ?>" placeholder="Search the notices — e.g. examination, holiday"></label>
            <button class="btn btn-brand" type="submit">Search</button>
            <?php if ($search !== ''): ?><a class="btn btn-line" href="notices.php">Show all</a><?php endif; ?>
        </form>

        <?php if (!$rows): ?>
            <div class="panel"><div class="empty"><i class="fas fa-bullhorn"></i><?php echo $search !== '' ? 'No notice mentions "' . h($search) . '".' : 'No notice has been published yet.'; ?></div></div>
        <?php else: ?>
        <div class="ncards">
            <?php foreach ($rows as $n): ?>
            <a class="ncard" href="<?php echo h('notice.php?id=' . (int)$n['id']); ?>">
                <?php echo site_date_block($n['publish_date']); ?>
                <div>
                    <h3><?php echo h($n['notice_title']); ?>
                        <?php if (notice_is_new($n['publish_date'])): ?><span class="pill new">New</span><?php endif; ?>
                        <?php if (!empty($n['attachment'])): ?><span class="pill file"><i class="fas fa-paperclip"></i> File</span><?php endif; ?></h3>
                    <?php if (trim((string)$n['notice_details']) !== ''): ?><p><?php echo h(mb_substr(trim($n['notice_details']), 0, 220)); ?></p><?php endif; ?>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php echo site_pager($page, $pages, fn($p) => 'notices.php?' . http_build_query(array_filter(['q' => $search, 'page' => $p]))); ?>
        <?php endif; ?>
    </div>
</section>
<?php site_footer();

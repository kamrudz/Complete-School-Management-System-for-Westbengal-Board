<?php
/**
 * result.php — PUBLIC result checker (no login).
 * Session → class → section → roll + date of birth. Shows the published exams of classes V–X, and the annual
 * result once every counting exam is published. Everything comes from includes/result_helper.php, so the
 * numbers match the admin tabulation exactly. Lookups are rate-limited per IP and per roll (login_attempts).
 * XI–XII results are not available here until the HS module is rebuilt.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("includes/db.php");
require_once 'includes/security.php';
require_once 'includes/login_attempts.php';
require_once 'includes/result_helper.php';
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$school = db_get_row('SELECT school_name, school_address, established_year, logo FROM school_settings WHERE id = 1') ?: [];
$sessions = db_get_all("SELECT id, session_name FROM academic_sessions ORDER BY status = 'Active' DESC, session_name DESC");
$active_session = (int)(db_get_row("SELECT id FROM academic_sessions WHERE status = 'Active' LIMIT 1")['id'] ?? 0);
$classes = exam_classes();
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$error = ''; $found = null; $exam_results = []; $annual = null; $annual_locked = false;
$in = ['session_id' => (int)($_POST['session_id'] ?? $active_session), 'class_id' => (int)($_POST['class_id'] ?? 0), 'section_id' => (int)($_POST['section_id'] ?? 0), 'roll_no' => trim((string)($_POST['roll_no'] ?? '')), 'dob' => trim((string)($_POST['dob'] ?? ''))];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_result'])) {
    $ip_key = 'result-ip:' . $ip;
    $roll_key = 'result:' . $in['session_id'] . '-' . $in['class_id'] . '-' . $in['section_id'] . '-' . substr(preg_replace('/\D/', '', $in['roll_no']), 0, 6);
    $locked = max(login_locked_minutes($conn, $ip_key), login_locked_minutes($conn, $roll_key));
    if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) $error = 'The form has expired — please try again.';
    elseif ($locked) $error = "Too many wrong attempts. Please try again after $locked minute" . ($locked === 1 ? '' : 's') . '.';
    elseif ($in['session_id'] <= 0 || $in['class_id'] <= 0 || $in['section_id'] <= 0 || !preg_match('/^\d{1,4}$/', $in['roll_no']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $in['dob'])) $error = 'Please fill in every field (roll number = digits only).';
    elseif (!isset($classes[$in['class_id']])) $error = 'Results of classes XI–XII are not available online yet.';
    else {
        $found = db_get_row('SELECT s.id, s.student_name, s.dob, g.father_name, sah.roll_no, sec.section_name, c.class_name
            FROM student_academic_history sah JOIN students s ON s.id = sah.student_id AND s.student_status <> "Deleted"
            LEFT JOIN guardians g ON g.guardian_id = s.guardian_id JOIN sections sec ON sec.id = sah.section_id JOIN classes c ON c.id = sah.class_id
            WHERE sah.session_id = ? AND sah.class_id = ? AND sah.section_id = ? AND sah.roll_no = ? AND s.dob = ? LIMIT 1',   // that year's class: a student who has moved on still finds it
            'iiiss', $in['session_id'], $in['class_id'], $in['section_id'], $in['roll_no'], $in['dob']);
        if (!$found) { register_failed_attempt($conn, $ip_key, 10, 15); register_failed_attempt($conn, $roll_key, 5, 15); $error = 'No student matches — check session, class, section, roll number and date of birth.'; }
        else {
            clear_login_attempts($conn, $roll_key);
            $uid = $found['id']; $sid = $in['session_id']; $cid = $in['class_id']; $secid = $in['section_id'];
            foreach (exam_list($sid) as $e) {
                if ((int)$e['is_published'] !== 1) continue;
                $r = result_exam($sid, $cid, (int)$e['id'], $secid, true);
                $st = $r['students'][$uid] ?? null;
                if ($st && $st['subjects'] && $st['missing_n'] < $st['subjects_n']) $exam_results[] = ['exam' => $e, 'subjects' => $r['subjects'], 'st' => $st];
            }
            if (result_publishable($sid)) { $a = result_annual($sid, $cid, $secid, true); $annual = ['res' => $a, 'st' => $a['students'][$uid] ?? null]; }
            else $annual_locked = (bool)result_counting_exams($sid);
        }
    }
}
$section_names = ($in['class_id'] && $in['session_id']) ? db_get_all('SELECT id, section_name FROM sections WHERE session_id = ? AND class_id = ? ORDER BY section_name', 'ii', $in['session_id'], $in['class_id']) : [];
$short = fn($name) => preg_replace('/^(\d)(st|nd|rd|th) /', '$1', str_ireplace('Summative', 'S', $name));
$cell = function (array $s): string { if ($s['missing']) return '—'; if ($s['absent']) return 'AB'; return exam_fmt($s['obtained']) . ($s['grace'] > 0 ? '†' : ''); };
$badge = fn($status) => '<span class="st st-' . strtolower($status) . '">' . h(result_label($status)) . '</span>';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Result — <?php echo h($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
    * { box-sizing: border-box; } body { margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; background: #f2f0f7; color: #222; }
    .wrap { max-width: 900px; margin: 0 auto; padding: 18px 14px 40px; }
    .head { text-align: center; padding: 14px 0 10px; } .head img { height: 64px; } .head h1 { margin: 6px 0 2px; font-size: 21px; color: #3b1d5c; } .head p { margin: 0; font-size: 12.5px; color: #555; }
    .card { background: #fff; border-radius: 14px; padding: 18px 20px; margin-top: 14px; box-shadow: 0 6px 20px rgba(59,29,92,.08); } .card h2 { margin: 0 0 12px; font-size: 16px; color: #3b1d5c; } .card h2 small { font-weight: 400; color: #6b7d90; font-size: 12px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; } label { display: block; font-size: 11.5px; font-weight: 700; color: #3b5168; text-transform: uppercase; margin-bottom: 4px; } select, input { width: 100%; height: 40px; padding: 6px 10px; border: 1px solid #c9d6e2; border-radius: 8px; font-size: 14px; background: #fff; }
    .btn { background: #3b1d5c; color: #fff; border: 0; border-radius: 9px; padding: 11px 20px; font-size: 14px; font-weight: 700; cursor: pointer; margin-top: 14px; } .btn:hover { background: #7a3fa3; }
    .err { background: #fdecea; color: #b71c1c; border: 1px solid #f5b5b0; border-radius: 9px; padding: 10px 12px; font-size: 13.5px; margin-bottom: 12px; } .info { background: #fff6e5; color: #7a4a00; border: 1px solid #f0c987; border-radius: 9px; padding: 10px 12px; font-size: 13px; }
    .who { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 6px 14px; font-size: 13px; color: #3b5168; } .who b { color: #111; }
    table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 8px; } th, td { border: 1px solid #d5dde5; padding: 6px 8px; text-align: center; } th { background: #f3eef8; color: #3b1d5c; font-size: 11.5px; } td.l { text-align: left; font-weight: 600; } td.f { color: #b71c1c; font-weight: 700; } tr.tot td { background: #faf7fd; font-weight: 700; }
    .sum { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px; } .sum span { padding: 6px 12px; border-radius: 9px; background: #f3eef8; border: 1px solid #d9c9ea; font-size: 13px; } .sum b { display: block; font-size: 17px; color: #3b1d5c; }
    .st { display: inline-block; padding: 3px 10px; border-radius: 6px; color: #fff; font-weight: 800; font-size: 12px; } .st-pass { background: #1b7a3a; } .st-puc { background: #b26a00; } .st-fail { background: #b71c1c; } .st-absent { background: #616161; }
    .legend { font-size: 11.5px; color: #6b7d90; margin-top: 8px; } .tabwrap { overflow: auto; }
    .foot { text-align: center; font-size: 12px; color: #6b7d90; margin-top: 18px; } .foot a { color: #3b1d5c; }
    @media print { body { background: #fff; } .card { box-shadow: none; } .noprint { display: none; } }
</style>
</head>
<body>
<div class="wrap">
    <div class="head"><?php if (!empty($school['logo'])): ?><img src="uploads/<?php echo h($school['logo']); ?>" alt=""><?php endif; ?><h1><?php echo h($school['school_name'] ?? 'School'); ?></h1><p><?php echo h($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p></div>

    <div class="card noprint">
        <h2><i class="fas fa-search"></i> Result checker <small>classes V–X</small></h2>
        <?php if ($error): ?><div class="err"><i class="fas fa-exclamation-circle"></i> <?php echo h($error); ?></div><?php endif; ?>
        <form method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="grid">
                <div><label>Session</label><select name="session_id" id="session_id" required><?php foreach ($sessions as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === $in['session_id'] ? 'selected' : ''; ?>><?php echo h($s['session_name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Class</label><select name="class_id" id="class_id" required><option value="">Select class</option><?php foreach ($classes as $id => $c): ?><option value="<?php echo $id; ?>" <?php echo $id === $in['class_id'] ? 'selected' : ''; ?>>Class <?php echo h($c['name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Section</label><select name="section_id" id="section_id" required><option value="">Select section</option><?php foreach ($section_names as $s): ?><option value="<?php echo (int)$s['id']; ?>" <?php echo (int)$s['id'] === $in['section_id'] ? 'selected' : ''; ?>><?php echo h($s['section_name']); ?></option><?php endforeach; ?></select></div>
                <div><label>Roll number</label><input type="text" name="roll_no" inputmode="numeric" pattern="\d{1,4}" required value="<?php echo h($in['roll_no']); ?>"></div>
                <div><label>Date of birth</label><input type="date" name="dob" required value="<?php echo h($in['dob']); ?>"></div>
            </div>
            <button type="submit" name="check_result" value="1" class="btn"><i class="fas fa-search"></i> Show result</button>
        </form>
    </div>

    <?php if ($found): ?>
    <div class="card">
        <h2><i class="fas fa-user-graduate"></i> <?php echo h($found['student_name']); ?></h2>
        <div class="who"><div>Class <b><?php echo h($found['class_name']); ?>-<?php echo h($found['section_name']); ?></b></div><div>Roll <b><?php echo h($found['roll_no']); ?></b></div><div>Father <b><?php echo h($found['father_name']); ?></b></div><div>Date of birth <b><?php echo date('d-m-Y', strtotime($found['dob'])); ?></b></div></div>
        <?php if (!$exam_results && !$annual): ?><p class="info" style="margin-top:12px"><i class="fas fa-info-circle"></i> No result has been published for this student yet.</p><?php endif; ?>
    </div>

    <?php foreach ($exam_results as $er): $st = $er['st']; ?>
    <div class="card">
        <h2><i class="fas fa-clipboard-list"></i> <?php echo h($er['exam']['exam_name']); ?></h2>
        <div class="tabwrap"><table><thead><tr><th style="text-align:left">Subject</th><th>Full</th><th>Pass</th><th>Obtained</th><th>Grade</th></tr></thead><tbody>
        <?php foreach ($er['subjects'] as $sid => $s): $x = $st['subjects'][$sid] ?? null; if (!$x) continue; ?><tr><td class="l"><?php echo h($s['name']); ?></td><td><?php echo exam_fmt($x['full']); ?></td><td><?php echo exam_fmt($x['pass']); ?></td><td class="<?php echo $x['fail'] ? 'f' : ''; ?>"><?php echo $cell($x); ?></td><td><?php echo $x['missing'] ? '' : h($x['grade']); ?></td></tr><?php endforeach; ?>
        <tr class="tot"><td class="l">Total</td><td><?php echo exam_fmt($st['full']); ?></td><td></td><td><?php echo exam_fmt($st['total']); ?></td><td><?php echo h($st['grade']); ?></td></tr>
        </tbody></table></div>
        <div class="sum"><span>Percentage<b><?php echo exam_fmt($st['pct']); ?>%</b></span><span>Result<b><?php echo $badge($st['status']); ?></b></span><span>Rank in section<b><?php echo $st['rank'] ?? '—'; ?></b></span></div>
    </div>
    <?php endforeach; ?>

    <?php if ($annual && $annual['st']): $st = $annual['st']; $a = $annual['res']; ?>
    <div class="card">
        <h2><i class="fas fa-award"></i> Annual result <small><?php echo h(implode(' + ', array_map(fn($e) => $e['exam_name'], $a['exams']))); ?></small></h2>
        <div class="tabwrap"><table><thead><tr><th style="text-align:left">Subject</th><?php foreach ($a['exams'] as $e): ?><th><?php echo h($short($e['exam_name'])); ?></th><?php endforeach; ?><th>Total</th><th>Full</th><th>Grade</th></tr></thead><tbody>
        <?php foreach ($a['subjects'] as $sid => $s): $x = $st['subjects'][$sid] ?? null; if (!$x) continue; ?><tr><td class="l"><?php echo h($s['name']); ?></td><?php foreach ($a['exams'] as $e): $v = $x['exams'][(int)$e['id']] ?? null; ?><td><?php echo $v === null ? '—' : ($v === 'AB' ? 'AB' : exam_fmt($v)); ?></td><?php endforeach; ?><td class="<?php echo $x['fail'] ? 'f' : ''; ?>" style="font-weight:700"><?php echo $x['absent'] ? 'AB' : exam_fmt($x['obtained']) . ($x['grace'] > 0 ? '†' : ''); ?></td><td><?php echo exam_fmt($x['full']); ?></td><td><?php echo h($x['grade']); ?></td></tr><?php endforeach; ?>
        <tr class="tot"><td class="l">Grand total</td><td colspan="<?php echo count($a['exams']); ?>"></td><td><?php echo exam_fmt($st['total']); ?></td><td><?php echo exam_fmt($st['full']); ?></td><td><?php echo h($st['grade']); ?></td></tr>
        </tbody></table></div>
        <div class="sum"><span>Percentage<b><?php echo exam_fmt($st['pct']); ?>%</b></span><span>Grade<b><?php echo h($st['grade']); ?> <small style="font-weight:400;color:#555"><?php echo h($st['grade_remark']); ?></small></b></span><span>Result<b><?php echo $badge($st['status']); ?></b></span><span>Rank in section<b><?php echo $st['rank'] ?? '—'; ?></b></span></div>
        <div class="legend">† includes grace marks · AB absent · — not held / not entered</div>
    </div>
    <?php elseif ($annual_locked && $exam_results): ?><p class="info"><i class="fas fa-info-circle"></i> The annual result will appear once every exam of the year is published.</p><?php endif; ?>
    <?php if ($found): ?><div class="noprint" style="text-align:center;margin-top:12px"><button class="btn" onclick="window.print()"><i class="fas fa-print"></i> Print</button></div><?php endif; ?>
    <?php endif; ?>

    <div class="foot"><a href="index.php"><i class="fas fa-home"></i> Home</a></div>
</div>
<script>
(function () {
    var cls = document.getElementById('class_id'), sec = document.getElementById('section_id'), ses = document.getElementById('session_id');
    function load() {
        sec.innerHTML = '<option value="">Loading…</option>';
        if (!cls.value) { sec.innerHTML = '<option value="">Select section</option>'; return; }
        fetch('get_sections_public.php?session_id=' + encodeURIComponent(ses.value) + '&class_id=' + encodeURIComponent(cls.value)).then(function (r) { return r.json(); }).then(function (list) {
            sec.innerHTML = '<option value="">Select section</option>';
            list.forEach(function (s) { var o = document.createElement('option'); o.value = s.id; o.textContent = s.name; sec.appendChild(o); });
        }).catch(function () { sec.innerHTML = '<option value="">Could not load sections</option>'; });
    }
    cls.addEventListener('change', load); ses.addEventListener('change', load);
})();
</script>
</body>
</html>

<?php
/**
 * student/auth.php — Student session & authentication helper
 * Include at the TOP of every student portal page (before any output)
 * Usage: require_once 'auth.php';
 */
require_once __DIR__ . '/../includes/auth.php';

$STUDENT_SESSION_TIMEOUT = 7200;

if(isset($_SESSION['student_login'])) {
    if(isset($_SESSION['student_last_activity'])) {
        if((time() - $_SESSION['student_last_activity']) > $STUDENT_SESSION_TIMEOUT) {
            schoolms_destroy_session();
            header("Location: login.php?timeout=1");
            exit();
        }
    }
    $_SESSION['student_last_activity'] = time();
}

function require_student_login() {
    if(!isset($_SESSION['student_login']) || $_SESSION['student_login'] !== true) {
        header("Location: login.php");
        exit();
    }
}

function redirect_student_if_logged_in() {
    if(isset($_SESSION['student_login']) && $_SESSION['student_login'] === true) {
        header("Location: dashboard.php");
        exit();
    }
}

function student_secure_login($student) {
    session_regenerate_id(true);
    $_SESSION['student_login']        = true;
    $_SESSION['student_id']           = $student['id'];
    $_SESSION['student_name']         = $student['student_name'];
    $_SESSION['student_uid']          = $student['id'];
    $_SESSION['student_admission_no'] = $student['admission_no'] ?? '';
    $_SESSION['student_dob']          = $student['dob'];
    $_SESSION['student_photo']        = $student['photo'] ?? '';
    $_SESSION['student_last_activity']= time();
    $_SESSION['student_login_time']   = time();
}

/**
 * Fetch a student's current academic placement
 * (session + class + section + roll). Falls back to the most
 * recent record if no "Current" row exists.
 */
function get_student_current_academic($conn, $student_id) {
    $sql = "SELECT sah.session_id, sah.class_id, sah.section_id, sah.roll_no,
                   ss.session_name, c.class_name, sec.section_name
            FROM student_academic_history sah
            JOIN academic_sessions ss ON ss.id = sah.session_id
            JOIN classes c ON c.id = sah.class_id
            LEFT JOIN sections sec ON sec.id = sah.section_id
            WHERE sah.student_id = ?
            ORDER BY (sah.academic_status='Current') DESC, sah.session_id DESC
            LIMIT 1";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return null;
    $student_id = student_uid_clean($student_id);
    mysqli_stmt_bind_param($stmt, 's', $student_id);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $row ?: null;
}

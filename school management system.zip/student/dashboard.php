<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once "../includes/section_groups.php";
require_once '../includes/user_access.php';
require_once '../includes/fee_helper.php';

$student_id = student_uid_clean($_SESSION['student_id'] ?? '');
$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id='$student_id'"));
if(!$student) { header("Location: logout.php"); exit(); }

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));
$acad = get_student_current_academic($conn, $student_id);

$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_sid = (int)($active_session['id'] ?? 0);

// Today's routine snapshot
$today = date('l');
if ($today === 'Sunday') $today = 'Monday';
$today_routine = [];
$class_id = (int)($acad['class_id'] ?? 0);
$section_id = (int)($acad['section_id'] ?? 0);

if ($acad && $class_id > 0 && $section_id > 0 && $active_sid > 0) {
    $routine_mode = get_routine_mode($conn);
    $paired_ids = ($routine_mode === 'group_wise')
        ? get_paired_section_ids($conn, $active_sid, $class_id, $section_id)
        : [$section_id];
    $paired_in_sql = implode(',', array_map('intval', $paired_ids));

    $q = mysqli_query($conn, "
        SELECT sub.subject_name, st.staff_name, st.short_code, p.period_name, p.start_time, p.end_time
        FROM routine r
        LEFT JOIN subjects sub ON sub.id = r.subject_id
        LEFT JOIN staff st ON st.id = r.teacher_id
        LEFT JOIN periods p ON p.id = r.period_id
        WHERE r.session_id='$active_sid' AND r.class_id='$class_id'
          AND r.section_id IN ($paired_in_sql)
          AND r.day_name='$today'
        ORDER BY p.sort_order, p.id
    ");
    while ($row = mysqli_fetch_assoc($q)) $today_routine[] = $row;
}

// Recent notices
$notices = mysqli_query($conn, "SELECT * FROM notices ORDER BY id DESC LIMIT 4");

// Upcoming holidays
$holidays = mysqli_query($conn, "
    SELECT * FROM holidays
    WHERE (holiday_date >= CURDATE() OR end_date >= CURDATE())
    ORDER BY COALESCE(holiday_date, start_date) ASC
    LIMIT 4
");

$fee_due = (fee_owing(fee_student_session($student_id), [$student_id])[$student_id] ?? 0) / 100;
$can_fees = ua_can($conn, 'student', 'feature_fees');

// Attendance summary
$att_summary = null;
if ($acad) {
    $att_q = mysqli_query($conn, "
        SELECT COUNT(*) AS total,
               SUM(status='Present') AS present,
               SUM(status='Absent') AS absent,
               SUM(status='Leave') AS leave_count
        FROM student_attendance
        WHERE student_id='$student_id'
    ");
    if ($att_q) $att_summary = mysqli_fetch_assoc($att_q);
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Dashboard — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;overflow-x:hidden;}
.alert-warn{background:#fef3c7;color:#92400e;padding:11px 16px;border-radius:8px;margin-bottom:16px;font-weight:600;display:flex;align-items:center;gap:8px;}
.welcome-bar{background:linear-gradient(135deg,#1f5b8a,#003366);color:#fff;border-radius:12px;padding:18px 22px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;}
.welcome-bar .greeting h2{font-size:20px;font-weight:800;display:flex;align-items:center;gap:10px;}
.welcome-bar .greeting p{font-size:13px;opacity:.8;margin-top:4px;}
.welcome-bar .greeting img{width:44px;height:44px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.35);}
.welcome-bar .date-box{text-align:right;font-size:13px;opacity:.8;}
.welcome-bar .date-box .time{font-size:24px;font-weight:800;opacity:1;}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:20px;}
.stat-card{background:#fff;border-radius:10px;padding:16px 18px;border:1px solid #e5e7eb;box-shadow:0 2px 8px rgba(0,0,0,.04);position:relative;overflow:hidden;transition:transform .2s;text-decoration:none;display:block;color:inherit;}
.stat-card:hover{transform:translateY(-3px);box-shadow:0 6px 20px rgba(0,0,0,.08);}
.stat-card::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;}
.stat-card.blue::after{background:#3b82f6;} .stat-card.green::after{background:#22c55e;} .stat-card.orange::after{background:#f59e0b;} .stat-card.purple::after{background:#8b5cf6;} .stat-card.red::after{background:#ef4444;} .stat-card.teal::after{background:#14b8a6;}
.stat-card .icon{font-size:24px;margin-bottom:6px;display:inline-block;padding:8px;border-radius:8px;background:rgba(31,91,138,.07);}
.stat-card .num{font-size:26px;font-weight:800;color:#0f1a2e;line-height:1.1;}
.stat-card .lbl{font-size:12px;color:#6c7a8a;font-weight:500;margin-top:3px;}
.two-col{display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:18px;}
.widget{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.widget-head{padding:10px 16px;border-bottom:1px solid #f0f2f5;background:#fafbfc;display:flex;justify-content:space-between;align-items:center;}
.widget-head h4{font-size:14px;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:6px;}
.widget-head h4 i{color:#1f5b8a;}
.widget-head a{font-size:12px;color:#1f5b8a;text-decoration:none;font-weight:600;}
.widget-body{padding:12px 14px;}
.item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f2f5;}
.item:last-child{border-bottom:none;}
.badge{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;white-space:nowrap;}
.item-info .name{font-size:13px;font-weight:600;color:#0f1a2e;}
.item-info .sub{font-size:11px;color:#6c7a8a;margin-top:1px;}
.time-badge{font-size:11px;color:#6c7a8a;margin-left:auto;white-space:nowrap;}
.notice-item{padding:8px 0;border-bottom:1px solid #f0f2f5;}
.notice-item:last-child{border-bottom:none;}
.notice-item .ntitle{font-size:13px;font-weight:600;color:#0f1a2e;}
.notice-item .nmeta{font-size:11px;color:#6c7a8a;margin-top:2px;}
.empty-msg{text-align:center;padding:20px;color:#6c7a8a;font-size:13px;}
.empty-msg i{font-size:28px;opacity:.3;display:block;margin-bottom:6px;}
.holiday-date{font-size:11px;color:#6c7a8a;margin-top:2px;}
.due-red{color:#dc2626;font-weight:700;}
.quick-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;}
.quick-btn{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 12px;text-align:center;text-decoration:none;color:#0f1a2e;transition:all .2s;display:block;}
.quick-btn:hover{transform:translateY(-3px);border-color:#1f5b8a;box-shadow:0 6px 18px rgba(31,91,138,.15);}
.quick-btn i{font-size:22px;color:#1f5b8a;display:block;margin-bottom:8px;}
.quick-btn span{font-size:12px;font-weight:700;}
.profile-card{display:flex;gap:16px;align-items:center;margin-bottom:14px;background:#fff;border-radius:10px;border:1px solid #e5e7eb;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.profile-card img{width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid #1f5b8a;}
.profile-card .avatar{width:72px;height:72px;border-radius:50%;background:#e8f4ff;display:flex;align-items:center;justify-content:center;color:#1f5b8a;font-size:30px;font-weight:700;}
.profile-card .pname{font-size:18px;font-weight:800;color:#0f1a2e;}
.profile-card .pmeta{font-size:13px;color:#6c7a8a;margin-top:3px;line-height:1.5;}
@media(max-width:900px){.two-col{grid-template-columns:1fr;}.profile-card{flex-direction:column;align-items:flex-start;}}
@media(max-width:700px){.stats-grid{grid-template-columns:1fr 1fr;}.quick-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.item{flex-wrap:wrap;}.time-badge{margin-left:0;}}
@media(max-width:480px){body{padding:12px;}.welcome-bar{padding:16px;}.welcome-bar .greeting h2{font-size:18px;}.welcome-bar .greeting p{font-size:12px;}.stats-grid{grid-template-columns:1fr;}.quick-grid{grid-template-columns:1fr;}.stat-card .num{font-size:22px;}.widget-head{flex-direction:column;align-items:flex-start;gap:6px;}.widget-head a{font-size:11px;}.profile-card .pname{font-size:16px;}.profile-card .pmeta{font-size:12px;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'access_denied'): ?>
    <div class="alert-warn"><i class="fas fa-exclamation-triangle"></i> Access denied — eita nirdhoron kora hoyeche je apnar jonno boyesh.</div>
<?php endif; ?>

<!-- Welcome Bar -->
<div class="welcome-bar">
    <div class="greeting">
        <h2>
            <?php if(!empty($student['photo'])): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" alt="">
            <?php else: ?>
                <i class="fas fa-user-graduate" style="font-size:30px;opacity:.85;"></i>
            <?php endif; ?>
            Welcome, <?php echo htmlspecialchars($student['student_name']); ?>
        </h2>
        <p>
            <i class="fas fa-id-card"></i> UID: <?php echo htmlspecialchars($student['id']); ?>
            <?php if($acad): ?>
            &nbsp;·&nbsp;
            <i class="fas fa-chalkboard"></i> Class <?php echo htmlspecialchars($acad['class_name']); ?> - <?php echo htmlspecialchars($acad['section_name'] ?? ''); ?>
            &nbsp;·&nbsp;
            <i class="fas fa-hashtag"></i> Roll: <?php echo htmlspecialchars($acad['roll_no'] ?? '—'); ?>
            <?php endif; ?>
        </p>
    </div>
    <div class="date-box">
        <div><?php echo date('d M Y'); ?></div>
        <div class="time" id="liveTime"><?php echo date('h:i A'); ?></div>
        <div><?php echo $today; ?></div>
    </div>
</div>

<!-- Profile card -->
<div class="profile-card">
    <?php if(!empty($student['photo'])): ?>
        <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" alt="Photo">
    <?php else: ?>
        <div class="avatar"><?php echo strtoupper(substr($student['student_name'],0,1)); ?></div>
    <?php endif; ?>
    <div>
        <div class="pname"><?php echo htmlspecialchars($student['student_name']); ?></div>
        <div class="pmeta">
            <?php if($acad): ?>
                <span>Class <?php echo htmlspecialchars($acad['class_name']); ?> (<?php echo htmlspecialchars($acad['section_name'] ?? '—'); ?>)</span>
                <span>Roll: <?php echo htmlspecialchars($acad['roll_no'] ?? '—'); ?></span>
                <span>Session: <?php echo htmlspecialchars($acad['session_name']); ?></span>
            <?php else: ?>
                Academic placement not found.
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Quick Links -->
<div class="widget" style="margin-bottom:20px;">
    <div class="widget-head"><h4><i class="fas fa-link"></i> Quick Access</h4></div>
    <div class="widget-body">
        <div class="quick-grid">
            <?php if (ua_can($conn, 'student', 'feature_profile')): ?>
            <a href="profile.php" class="quick-btn"><i class="fas fa-user-circle"></i><span>Profile</span></a>
            <?php endif; ?>
            <?php if (ua_can($conn, 'student', 'feature_routine')): ?>
            <a href="my_routine.php" class="quick-btn"><i class="fas fa-calendar-alt"></i><span>Class Routine</span></a>
            <?php endif; ?>
            <?php if (ua_can($conn, 'student', 'feature_progress_report')): ?>
            <a href="progress_report.php" class="quick-btn"><i class="fas fa-chart-bar"></i><span>Progress Report</span></a>
            <?php endif; ?>
            <?php if ($can_fees): ?>
            <a href="fees.php" class="quick-btn"><i class="fas fa-wallet"></i><span>My Fees</span></a>
            <?php endif; ?>
            <?php if (ua_can($conn, 'student', 'feature_holidays')): ?>
            <a href="holidays.php" class="quick-btn"><i class="fas fa-umbrella-beach"></i><span>Holidays</span></a>
            <?php endif; ?>
            <?php if (ua_can($conn, 'student', 'feature_edit_profile')): ?>
            <a href="edit_profile.php" class="quick-btn"><i class="fas fa-user-edit"></i><span>Edit Profile</span></a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card blue">
        <div class="icon"><i class="fas fa-book-open" style="color:#3b82f6;"></i></div>
        <div class="num"><?php echo count($today_routine); ?></div>
        <div class="lbl">Periods Today</div>
    </div>
    <div class="stat-card green">
        <div class="icon"><i class="fas fa-check-circle" style="color:#22c55e;"></i></div>
        <div class="num"><?php echo (int)($att_summary['present'] ?? 0); ?></div>
        <div class="lbl">Days Present</div>
    </div>
    <div class="stat-card red">
        <div class="icon"><i class="fas fa-times-circle" style="color:#ef4444;"></i></div>
        <div class="num"><?php echo (int)($att_summary['absent'] ?? 0); ?></div>
        <div class="lbl">Days Absent</div>
    </div>
    <?php if ($can_fees): ?><a href="fees.php" class="stat-card orange"><?php else: ?><div class="stat-card orange"><?php endif; ?>
        <div class="icon"><i class="fas fa-money-bill-wave" style="color:#f59e0b;"></i></div>
        <div class="num">₹<?php echo number_format($fee_due, 0); ?></div>
        <div class="lbl">Fee Due</div>
    <?php echo $can_fees ? '</a>' : '</div>'; ?>
</div>

<!-- Main widgets -->
<div class="two-col">
    <?php if (ua_can($conn, 'student', 'feature_routine')): ?>
    <div class="widget">
        <div class="widget-head">
            <h4><i class="fas fa-clock"></i> Today's Routine (<?php echo $today; ?>)</h4>
            <a href="my_routine.php">Full Routine →</a>
        </div>
        <div class="widget-body">
            <?php if(empty($today_routine)): ?>
                <div class="empty-msg"><i class="fas fa-coffee"></i> Today no class scheduled</div>
            <?php else: ?>
                <?php foreach($today_routine as $r): ?>
                <div class="item">
                    <span class="badge"><?php echo htmlspecialchars($r['period_name'] ?? ''); ?></span>
                    <div class="item-info">
                        <div class="name"><?php echo htmlspecialchars($r['subject_name'] ?? '—'); ?></div>
                        <div class="sub"><i class="fas fa-chalkboard-teacher"></i> <?php echo htmlspecialchars($r['short_code'] ?: $r['staff_name'] ?? ''); ?></div>
                    </div>
                    <span class="time-badge"><?php echo $r['start_time'] ? date('h:i A', strtotime($r['start_time'])) : ''; ?></span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div style="display:flex;flex-direction:column;gap:16px;">
        <!-- Notices -->
        <div class="widget">
            <div class="widget-head">
                <h4><i class="fas fa-bullhorn"></i> Recent Notices</h4>
                <a href="../notices.php" target="_blank">All →</a>
            </div>
            <div class="widget-body">
                <?php $nc = 0; while($n = mysqli_fetch_assoc($notices)): $nc++; ?>
                <div class="notice-item">
                    <div class="ntitle"><?php echo htmlspecialchars($n['notice_title'] ?? 'Notice'); ?></div>
                    <div class="nmeta"><?php echo date('d M Y', strtotime($n['publish_date'] ?? $n['created_at'])); ?></div>
                </div>
                <?php endwhile; ?>
                <?php if($nc == 0): ?>
                <div class="empty-msg"><i class="fas fa-bell-slash"></i> No notices</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Upcoming holidays -->
        <?php if (ua_can($conn, 'student', 'feature_holidays')): ?>
        <div class="widget">
            <div class="widget-head">
                <h4><i class="fas fa-umbrella-beach"></i> Upcoming Holidays</h4>
                <a href="holidays.php">All →</a>
            </div>
            <div class="widget-body">
                <?php $hc = 0; while($h = mysqli_fetch_assoc($holidays)): $hc++; ?>
                <div class="notice-item">
                    <div class="ntitle"><?php echo htmlspecialchars($h['holiday_name']); ?></div>
                    <div class="nmeta"><?php echo date('d M Y', strtotime($h['holiday_date'] ?? $h['start_date'])); ?></div>
                </div>
                <?php endwhile; ?>
                <?php if($hc == 0): ?>
                <div class="empty-msg"><i class="fas fa-calendar-check"></i> No upcoming holidays</div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
setInterval(function(){
    var now = new Date();
    var h = now.getHours()%12||12;
    var m = now.getMinutes().toString().padStart(2,'0');
    var ampm = now.getHours()>=12?'PM':'AM';
    document.getElementById('liveTime').textContent = h+':'+m+' '+ampm;
}, 1000);
</script>
</body>
</html>

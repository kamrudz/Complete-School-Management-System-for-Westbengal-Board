<?php
/**
 * student/edit_profile.php — Student self-edit profile
 * Only fields that the admin allowed in User Access are editable/saveable.
 * All other fields are hidden (view them on profile.php).
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/user_access.php';
require_once '../includes/photo_helper.php';

$student_id = student_uid_clean($_SESSION['student_id'] ?? '');

// Master switch: student self-edit feature
if (!ua_can($conn, 'student', 'feature_edit_profile')) {
    header("Location: dashboard.php?msg=access_denied");
    exit();
}

$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id='$student_id'"));
if (!$student) { header("Location: logout.php"); exit(); }

$editable = ua_student_editable_blocks($conn); // key => block
$can_photo = ua_can($conn, 'student', 'edit_photo');

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));

$success = '';
$errors  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();

    // Build a strict whitelist of allowed columns
    $allowed_cols = [];
    foreach ($editable as $block) {
        foreach ($block['fields'] as $f) $allowed_cols[] = $f[0];
    }
    if (empty($allowed_cols)) {
        $errors[] = 'You are not allowed to edit any field.';
    }

    if (empty($errors)) {
        $new_data = [];
        foreach ($student as $col => $old_val) {
            if (!in_array($col, $allowed_cols, true)) continue;
            if ($col === 'photo' || $col === 'signature') continue; // handled as file uploads below
            $new_data[$col] = trim((string)($_POST[$col] ?? ''));
        }

        // PIN code / mobile / aadhaar / account number: numbers only where relevant
        if (isset($new_data['pin_code']) && $new_data['pin_code'] !== '') {
            $new_data['pin_code'] = preg_replace('/[^0-9]/', '', $new_data['pin_code']);
            if (!preg_match('/^\d{6}$/', $new_data['pin_code'])) $errors[] = 'PIN Code must be 6 digits.';
        }
        if (isset($new_data['mobile']) && $new_data['mobile'] !== '') {
            $new_data['mobile'] = preg_replace('/[^0-9]/', '', $new_data['mobile']);
            if (!preg_match('/^\d{10}$/', $new_data['mobile'])) $errors[] = 'Mobile number must be 10 digits.';
        }
        if (isset($new_data['student_aadhaar']) && $new_data['student_aadhaar'] !== '') {
            $new_data['student_aadhaar'] = preg_replace('/[^0-9]/', '', $new_data['student_aadhaar']);
        }
        if (isset($new_data['account_number']) && $new_data['account_number'] !== '') {
            $new_data['account_number'] = preg_replace('/[^0-9]/', '', $new_data['account_number']);
        }
        if (isset($new_data['email']) && $new_data['email'] !== '') {
            if (!filter_var($new_data['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
        }

        // Photo upload
        $photo_filename = null;
        if ($can_photo && !empty($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $up = process_student_photo($_FILES['photo'], dirname(__DIR__) . '/uploads/students/');   // upright, 320 px, ≤ 10 KB — same as the admin side
            if (!$up['ok']) {
                $errors[] = $up['error'];
            } else {
                $photo_filename = $up['filename'];
            }
        }

        // Signature upload
        $signature_filename = null;
        $can_signature = ua_can($conn, 'student', 'edit_signature');
        if ($can_signature && !empty($_FILES['signature']) && $_FILES['signature']['error'] !== UPLOAD_ERR_NO_FILE) {
            $up = safe_uploaded_file($_FILES['signature'], dirname(__DIR__) . '/uploads/students', ['jpg','jpeg','png','webp'], ['image/jpeg','image/png','image/webp'], 'sig_' . $student_id . '_', 1048576);
            if (!$up['ok']) {
                $errors[] = $up['error'];
            } else {
                $signature_filename = $up['filename'];
            }
        }

        if (empty($errors)) {
            // Compute changed columns only
            $changes = [];
            foreach ($new_data as $col => $val) {
                $old = (string)($student[$col] ?? '');
                if ($old !== $val) $changes[$col] = $val;
            }
            if ($photo_filename) $changes['photo'] = $photo_filename;
            if ($signature_filename) $changes['signature'] = $signature_filename;

            if (!empty($changes)) {
                $old_snap = [];
                foreach (array_keys($changes) as $c) $old_snap[$c] = $student[$c] ?? '';
                $new_snap = $changes;

                $set  = [];
                $vals = [];
                $types = '';
                foreach ($changes as $col => $val) {
                    $set[] = "`$col` = ?";
                    $vals[] = $val;
                    $types .= 's';
                }
                $vals[] = $student_id;
                $types .= 's';   // students.id is the School UID
                $stmt = mysqli_prepare($conn, "UPDATE students SET " . implode(', ', $set) . " WHERE id = ?");
                mysqli_stmt_bind_param($stmt, $types, ...$vals);
                if (mysqli_stmt_execute($stmt)) {
                    if ($photo_filename) {
                        $_SESSION['student_photo'] = $photo_filename;
                    }
                    try {
                        ua_log_student_activity($conn, $student_id, 'STUDENT_SELF_UPDATED', ['old' => $old_snap, 'new' => $new_snap]);
                    } catch (Throwable $e) {
                        error_log("Student activity log failed: " . $e->getMessage());
                    }
                    $success = 'Your profile has been updated successfully!';
                } else {
                    $errors[] = 'Update failed. Please try again.';
                }
                mysqli_stmt_close($stmt);
            } else {
                $success = 'No changes were made.';
            }
        }
    }

    // Refresh student data
    $student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id='$student_id'"));
}

$blood_groups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Edit Profile — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);margin-bottom:16px;}
.card-head{padding:12px 18px;background:#fafbfc;border-bottom:1px solid #f0f2f5;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.card-head i{color:#1f5b8a;}
.card-body{padding:16px 18px;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px 18px;}
.form-group label{display:block;font-weight:600;font-size:12.5px;color:#4a5a6a;margin-bottom:5px;}
.form-group input,.form-group select{width:100%;padding:9px 12px;border:2px solid #e4edf6;border-radius:8px;font-size:14px;font-family:inherit;background:#fff;}
.form-group input:focus,.form-group select:focus{outline:none;border-color:#1f5b8a;}
.form-group input[readonly]{background:#f1f5f9;color:#94a3b8;}
.field-full{grid-column:1/-1;}
.btn-save{padding:11px 26px;background:#003366;color:#fff;border:none;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;}
.btn-save:hover{background:#0f4c81;}
.btn-cancel{padding:11px 20px;background:#fff;color:#475569;border:2px solid #d1d9e2;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;text-decoration:none;display:inline-block;}
.btn-cancel:hover{background:#f1f5f9;}
.alert-success{background:#d4edda;color:#155724;padding:11px 16px;border-radius:8px;margin-bottom:16px;font-weight:600;}
.alert-error{background:#f8d7da;color:#721c24;padding:11px 16px;border-radius:8px;margin-bottom:16px;font-weight:600;}
.alert-error li{margin-left:18px;}
.photo-box{display:flex;align-items:center;gap:16px;flex-wrap:wrap;}
.photo-box img{width:92px;height:92px;border-radius:12px;object-fit:cover;border:2px solid #e4edf6;}
.photo-box .avatar{width:92px;height:92px;border-radius:12px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-size:34px;font-weight:700;color:#94a3b8;}
.lock-note{background:#f0f4f9;border:1px dashed #c3d3e3;border-radius:10px;padding:12px 16px;font-size:12.5px;color:#5a6b7a;margin-bottom:16px;}
.lock-note i{color:#1f5b8a;margin-right:6px;}
@media(max-width:700px){.form-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="page-title"><i class="fas fa-user-edit"></i> Edit My Profile</div>

<?php if ($success): ?><div class="alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div><?php endif; ?>
<?php if (!empty($errors)): ?>
    <div class="alert-error"><i class="fas fa-exclamation-triangle"></i> Please fix the following:<ul>
        <?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?>
    </ul></div>
<?php endif; ?>

<?php if (empty($editable)): ?>
    <div class="card"><div class="card-body" style="text-align:center;color:#6c7a8a;padding:30px;">
        <i class="fas fa-lock" style="font-size:30px;color:#94a3b8;margin-bottom:10px;"></i><br>
        You are not allowed to edit any field. Please contact the school office.
    </div></div>
<?php else: ?>
<form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <?php if (isset($editable['edit_photo'])): ?>
    <div class="card">
        <div class="card-head"><i class="fas fa-camera"></i> Photo</div>
        <div class="card-body">
            <div class="photo-box">
                <?php if (!empty($student['photo'])): ?>
                    <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" alt="Photo">
                <?php else: ?>
                    <div class="avatar"><?php echo strtoupper(substr($student['student_name'],0,1)); ?></div>
                <?php endif; ?>
                <div style="flex:1;">
                    <input type="file" name="photo" accept="image/*">
                    <div style="font-size:11.5px;color:#94a3b8;margin-top:5px;">JPG/PNG/WebP, max 1MB. Current: <?php echo htmlspecialchars($student['photo'] ?? '—'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (isset($editable['edit_signature'])): ?>
    <div class="card">
        <div class="card-head"><i class="fas fa-signature"></i> Signature</div>
        <div class="card-body">
            <div class="photo-box">
                <?php if (!empty($student['signature'])): ?>
                    <img src="../uploads/students/<?php echo htmlspecialchars($student['signature']); ?>" alt="Signature" style="background:#fff;border:1px solid #d1d9e2;padding:4px;">
                <?php else: ?>
                    <div class="avatar"><i class="fas fa-signature"></i></div>
                <?php endif; ?>
                <div style="flex:1;">
                    <input type="file" name="signature" accept="image/*">
                    <div style="font-size:11.5px;color:#94a3b8;margin-top:5px;">JPG/PNG/WebP, max 1MB. Current: <?php echo htmlspecialchars($student['signature'] ?? '—'); ?></div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php foreach ($editable as $key => $block): ?>
        <?php if ($key === 'edit_photo' || $key === 'edit_signature') continue; ?>
        <div class="card">
            <div class="card-head"><i class="fas fa-edit"></i> <?php echo htmlspecialchars($block['label']); ?></div>
            <div class="card-body">
                <div class="form-grid">
                    <?php foreach ($block['fields'] as $f): ?>
                        <?php
                        [$col, $type, $label] = $f;
                        $val = $student[$col] ?? '';
                        ?>
                        <div class="form-group <?php echo $type === 'photo' ? 'field-full' : ''; ?>">
                            <label for="f_<?php echo $col; ?>"><?php echo htmlspecialchars($label); ?></label>
                            <?php if ($type === 'blood'): ?>
                                <select id="f_<?php echo $col; ?>" name="<?php echo $col; ?>">
                                    <option value="">— Select —</option>
                                    <?php foreach ($blood_groups as $bg): ?>
                                        <option value="<?php echo $bg; ?>" <?php echo $val === $bg ? 'selected' : ''; ?>><?php echo $bg; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php else: ?>
                                <input type="<?php echo $type === 'email' ? 'email' : ($type === 'tel' ? 'tel' : ($type === 'photo' ? 'file' : 'text')); ?>"
                                       id="f_<?php echo $col; ?>" name="<?php echo $col; ?>"
                                       value="<?php echo htmlspecialchars($val); ?>"
                                       <?php echo $type === 'photo' ? 'accept="image/*"' : ''; ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="lock-note">
        <i class="fas fa-lock"></i>Shudhu admin-approve kora fields ekhane dekha jacche.
        Baaki details <b>My Profile</b> page-e dekhte pabe (edit kora jabe na).
    </div>

    <div style="display:flex;gap:10px;margin-bottom:30px;">
        <button type="submit" class="btn-save"><i class="fas fa-save"></i> Save Changes</button>
        <a href="profile.php" class="btn-cancel"><i class="fas fa-times"></i> Cancel</a>
    </div>
</form>
<?php endif; ?>

</body>
</html>

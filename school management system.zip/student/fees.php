<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once '../includes/user_access.php';
if (!ua_can($conn, 'student', 'feature_fees')) { header("Location: dashboard.php?msg=access_denied"); exit(); }
require_once '../includes/fee_helper.php';

$uid = student_uid_clean($_SESSION['student_id'] ?? '');
$school = db_get_row('SELECT school_name FROM school_settings LIMIT 1') ?: [];
$bills = array_filter(fee_student_bills($uid), fn($b) => $b['status'] !== 'cancelled');
$receipts = fee_student_receipts($uid);
$paid_for = [];
foreach (db_get_all('SELECT t.receipt_id, i.title, t.amount FROM fee_transactions t JOIN fee_invoices i ON i.id = t.invoice_id JOIN fee_receipts r ON r.id = t.receipt_id WHERE r.student_id = ? ORDER BY t.id', 's', $uid) as $t) {
    $paid_for[(int)$t['receipt_id']][] = $t;
}
$session_id = fee_student_session($uid);
$class_now = $session_id ? (int)(db_get_row("SELECT class_id FROM student_academic_history WHERE student_id = ? AND session_id = ? AND academic_status = 'Current'", 'si', $uid, $session_id)['class_id'] ?? 0) : 0;
$place = $class_now ? (fee_class_students($session_id, [$class_now], 0, [$uid])[$uid] ?? null) : null;
$heads = fee_session_heads();
$fees_now = [];
foreach ($place ? fee_standing($session_id, [$uid => $place], $heads)[$uid] : [] as $hid => $c) {
    if ($c['state'] === 'na' || ($c['state'] === 'todo' && $heads[$hid]['who_pays'] === 'some')) continue;
    $fees_now[$hid] = $c;
}
$paid = array_sum(array_map(fn($b) => fee_paise($b['paid_amount']), $bills));
$owing = $session_id ? (fee_owing($session_id, [$uid])[$uid] ?? 0) : 0;
$to_pay = $paid + $owing;
$by_session = [];
foreach ($bills as $b) $by_session[$b['session_name']][] = $b;
$valid = count(array_filter($receipts, fn($r) => $r['status'] === 'valid'));
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Fees — <?php echo h($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;color:#0f1a2e;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
.summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:18px;}
.summary-card{background:#fff;border-radius:10px;padding:14px 16px;border:1px solid #e5e7eb;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.summary-card .num{font-size:22px;font-weight:800;color:#1f5b8a;font-variant-numeric:tabular-nums;}
.summary-card .lbl{font-size:11px;color:#6c7a8a;font-weight:600;text-transform:uppercase;letter-spacing:.4px;margin-top:2px;}
.summary-card.ok .num{color:#15803d;} .summary-card.owe .num{color:#b91c1c;}
.notice{background:#fff7e6;border:1px solid #f5d08a;color:#7a4a00;border-radius:10px;padding:10px 14px;margin-bottom:18px;font-size:13px;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);margin-bottom:18px;}
.list-head{padding:12px 18px;background:#fafbfc;border-bottom:1px solid #f0f2f5;font-weight:700;display:flex;align-items:center;gap:8px;}
.list-head i{color:#1f5b8a;}
.sess{padding:7px 18px;background:#eef4fa;color:#1f5b8a;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:.5px;}
.bill{padding:14px 18px;border-bottom:1px solid #f0f2f5;}
.bill:last-child{border-bottom:none;}
.b-top{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;}
.b-top b{font-size:15px;}
.b-top .due{margin-left:auto;font-size:12px;color:#6c7a8a;}
.items{width:100%;max-width:520px;border-collapse:collapse;font-size:13px;}
.items td{padding:4px 0;border-bottom:1px dashed #edf1f5;}
.items td.amt{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums;padding-left:12px;}
.items tr.less td{color:#15803d;}
.items tr.tot td{font-weight:700;border-bottom:1px solid #d5dee7;}
.items tr.owe td{font-weight:800;color:#b91c1c;border-bottom:none;}
.chip{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.chip.ok{background:#dcfce7;color:#166534;} .chip.warn{background:#fef3c7;color:#92400e;} .chip.off{background:#eef1f4;color:#55677a;} .chip.bad{background:#fee2e2;color:#991b1b;}
.scroll{overflow-x:auto;}
table.rc{width:100%;border-collapse:collapse;font-size:13px;}
table.rc th{background:#fafbfc;text-align:left;padding:9px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:#6c7a8a;border-bottom:1px solid #f0f2f5;}
table.rc td{padding:10px 14px;border-bottom:1px solid #f0f2f5;vertical-align:top;}
table.rc td.amt,table.rc th.amt{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums;}
table.rc td.amt{font-weight:700;}
table.rc tr.void td{color:#9aa5b1;} table.rc tr.void td.amt{text-decoration:line-through;}
table.rc small{display:block;color:#6c7a8a;font-size:12px;}
.empty-msg{text-align:center;padding:36px 20px;color:#6c7a8a;font-size:14px;}
.empty-msg i{font-size:36px;opacity:.3;display:block;margin-bottom:10px;}
@media(max-width:600px){body{padding:12px;}.b-top .due{margin-left:0;width:100%;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="page-title"><i class="fas fa-wallet"></i> My Fees</div>

<div class="summary-grid">
    <div class="summary-card"><div class="num"><?php echo h(fee_money_p($to_pay)); ?></div><div class="lbl">Total fees</div></div>
    <div class="summary-card ok"><div class="num"><?php echo h(fee_money_p($paid)); ?></div><div class="lbl">Paid</div></div>
    <div class="summary-card <?php echo $owing > 0 ? 'owe' : 'ok'; ?>"><div class="num"><?php echo h(fee_money_p($owing)); ?></div><div class="lbl">Still to pay</div></div>
    <div class="summary-card"><div class="num"><?php echo $valid; ?></div><div class="lbl">Receipts</div></div>
</div>
<?php if ($owing > 0): ?>
<div class="notice"><i class="fas fa-info-circle"></i> Pay at the school fee counter and take a money receipt. Give your School UID: <b><?php echo h($uid); ?></b></div>
<?php endif; ?>

<?php if ($fees_now): ?>
<div class="card">
    <div class="list-head"><i class="fas fa-list-check"></i> Fees of <?php echo h(exam_session_name($session_id)); ?></div>
    <div class="scroll">
        <table class="rc">
            <thead><tr><th>Fee</th><th>Status</th><th class="amt">Still to pay</th></tr></thead>
            <tbody>
            <?php foreach ($fees_now as $hid => $c): ?>
            <tr>
                <td><b><?php echo h($heads[$hid]['type_name']); ?></b><?php if ($c['state'] === 'todo' && $c['off']): ?><small><?php echo h(fee_money_p($c['gross'])); ?> less <?php echo h(fee_money_p($c['off'])); ?> discount</small><?php endif; ?></td>
                <td><?php echo match ($c['state']) { 'paid' => '<span class="chip ok">Paid</span>', 'part' => '<span class="chip warn">Part paid</span>', 'zero' => '<span class="chip off">Nothing to pay</span>', default => '<span class="chip bad">Not paid</span>' }; ?></td>
                <td class="amt"><?php echo $c['owe'] > 0 && $c['state'] !== 'zero' ? h(fee_money_p($c['owe'])) : '—'; ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="list-head"><i class="fas fa-file-invoice"></i> My bills</div>
    <?php if (!$bills): ?>
    <div class="empty-msg"><i class="fas fa-file-invoice"></i> No fee bills yet.</div>
    <?php endif; ?>
    <?php foreach ($by_session as $name => $list): ?>
    <div class="sess">Session <?php echo h($name); ?></div>
    <?php foreach ($list as $b): $owe = fee_paise($b['total']) - fee_paise($b['paid_amount']); ?>
    <div class="bill">
        <div class="b-top">
            <b><?php echo h($b['title']); ?></b> <?php echo fee_state_chip(fee_bill_state($b)); ?>
            <?php if ($owe > 0 && $b['due_date']): ?><span class="due"><i class="far fa-calendar"></i> Pay by <?php echo h(date('d M Y', strtotime($b['due_date']))); ?></span><?php endif; ?>
        </div>
        <table class="items">
            <?php foreach ($b['items'] as $it): ?><tr><td><?php echo h($it['description']); ?></td><td class="amt"><?php echo h(fee_money($it['amount'])); ?></td></tr><?php endforeach; ?>
            <?php if (fee_paise($b['discount_amount']) > 0): ?><tr class="less"><td>Less: discount<?php echo $b['discount_reason'] ? ' (' . h($b['discount_reason']) . ')' : ''; ?></td><td class="amt">− <?php echo h(fee_money($b['discount_amount'])); ?></td></tr><?php endif; ?>
            <tr class="tot"><td>To pay</td><td class="amt"><?php echo h(fee_money($b['total'])); ?></td></tr>
            <tr><td>Paid</td><td class="amt"><?php echo h(fee_money($b['paid_amount'])); ?></td></tr>
            <?php if ($owe > 0): ?><tr class="owe"><td>Still to pay</td><td class="amt"><?php echo h(fee_money_p($owe)); ?></td></tr><?php endif; ?>
        </table>
    </div>
    <?php endforeach; endforeach; ?>
</div>

<div class="card">
    <div class="list-head"><i class="fas fa-receipt"></i> Money receipts</div>
    <?php if (!$receipts): ?>
    <div class="empty-msg"><i class="fas fa-receipt"></i> No money receipts yet.</div>
    <?php else: ?>
    <div class="scroll">
        <table class="rc">
            <thead><tr><th>Receipt No</th><th>Date</th><th>Paid for</th><th>Paid by</th><th class="amt">Amount</th></tr></thead>
            <tbody>
            <?php foreach ($receipts as $r): $void = $r['status'] !== 'valid'; ?>
            <tr class="<?php echo $void ? 'void' : ''; ?>">
                <td style="white-space:nowrap"><b><?php echo h($r['receipt_no']); ?></b><?php if ($void): ?> <span class="chip bad">Cancelled</span><?php endif; ?></td>
                <td style="white-space:nowrap"><?php echo h(date('d M Y', strtotime($r['receipt_date']))); ?></td>
                <td><?php foreach ($paid_for[(int)$r['id']] ?? [] as $t): ?><small><?php echo h($t['title']); ?> — <?php echo h(fee_money($t['amount'])); ?></small><?php endforeach; ?></td>
                <td><?php echo h(FEE_METHODS[$r['method']] ?? $r['method']); ?><?php if ($r['reference_no']): ?><small><?php echo h($r['reference_no']); ?></small><?php endif; ?></td>
                <td class="amt"><?php echo h(fee_money($r['amount'])); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once '../includes/user_access.php';
if (!ua_can($conn, 'student', 'feature_holidays')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));

$view = $_GET['view'] ?? 'upcoming';

$today = date('Y-m-d');

// Upcoming
$upcoming = mysqli_query($conn, "
    SELECT * FROM holidays
    WHERE (holiday_date >= '$today' OR (start_date IS NOT NULL AND end_date >= '$today'))
    ORDER BY COALESCE(holiday_date, start_date) ASC
");

// Past
$past = mysqli_query($conn, "
    SELECT * FROM holidays
    WHERE (holiday_date IS NOT NULL AND holiday_date < '$today')
       OR (end_date IS NOT NULL AND end_date < '$today')
    ORDER BY COALESCE(holiday_date, end_date) DESC
    LIMIT 60
");

function holiday_date_range($h) {
    if(!empty($h['holiday_date'])) {
        return date('d M Y', strtotime($h['holiday_date']));
    }
    if(!empty($h['start_date']) && !empty($h['end_date'])) {
        $s = date('d M Y', strtotime($h['start_date']));
        $e = date('d M Y', strtotime($h['end_date']));
        return $s . ' → ' . $e;
    }
    return '—';
}

function holiday_days($h) {
    if(!empty($h['holiday_date'])) return 1;
    if(!empty($h['start_date']) && !empty($h['end_date'])) {
        $d = (strtotime($h['end_date']) - strtotime($h['start_date'])) / 86400 + 1;
        return (int)$d;
    }
    return 1;
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Holidays — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
.tabs{display:flex;gap:8px;margin-bottom:18px;}
.tab{padding:9px 22px;border-radius:30px;border:2px solid #d0dbe8;background:#fff;color:#1a3b55;font-weight:700;font-size:13px;cursor:pointer;text-decoration:none;transition:all .2s;}
.tab:hover{border-color:#1f5b8a;color:#1f5b8a;}
.tab.active{background:#1f5b8a;border-color:#1f5b8a;color:#fff;}
.count-badge{background:#e8f4ff;color:#1f5b8a;border-radius:20px;padding:1px 8px;font-size:11px;margin-left:4px;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.list-head{padding:12px 18px;background:#fafbfc;border-bottom:1px solid #f0f2f5;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.list-head i{color:#1f5b8a;}
.h-row{display:flex;align-items:center;gap:14px;padding:12px 18px;border-bottom:1px solid #f0f2f5;}
.h-row:last-child{border-bottom:none;}
.h-row:hover{background:#f8faff;}
.h-date{min-width:120px;text-align:center;}
.h-date .d{font-size:20px;font-weight:800;color:#1f5b8a;line-height:1.1;}
.h-date .m{font-size:11px;color:#6c7a8a;font-weight:700;text-transform:uppercase;}
.h-info{flex:1;}
.h-info .name{font-size:14px;font-weight:700;color:#0f1a2e;}
.h-info .sub{font-size:12px;color:#6c7a8a;margin-top:2px;}
.h-info .sub i{margin-right:4px;}
.h-tag{flex-shrink:0;}
.tag{display:inline-block;padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;}
.tag-public{background:#e8f4ff;color:#1f5b8a;}
.tag-school{background:#dcfce7;color:#166534;}
.tag-exam{background:#fef3c7;color:#92400e;}
.tag-event{background:#fce7f3;color:#9d174d;}
.tag-long{background:#efe9ff;color:#5b21b6;}
.empty-msg{text-align:center;padding:40px 20px;color:#6c7a8a;font-size:14px;}
.empty-msg i{font-size:40px;opacity:.3;display:block;margin-bottom:10px;}
.summary-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:18px;}
.summary-card{background:#fff;border-radius:10px;padding:14px 16px;border:1px solid #e5e7eb;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.summary-card .num{font-size:24px;font-weight:800;color:#1f5b8a;}
.summary-card .lbl{font-size:11px;color:#6c7a8a;font-weight:600;text-transform:uppercase;letter-spacing:.4px;margin-top:2px;}
@media(max-width:600px){.h-row{flex-wrap:wrap;}.h-date{min-width:90px;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="page-title"><i class="fas fa-umbrella-beach"></i> Holidays</div>

<?php
// Counts
$up_count = mysqli_num_rows($upcoming);
$all_count = (int)(mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM holidays"))['c'] ?? 0);

// Upcoming day count
$up_days = 0;
$up_days_q = mysqli_query($conn, "
    SELECT COALESCE(
        DATEDIFF(IFNULL(end_date, holiday_date), IFNULL(start_date, holiday_date)) + 1, 1
    ) AS days
    FROM holidays
    WHERE (holiday_date >= '$today' OR (start_date IS NOT NULL AND end_date >= '$today'))
");
while($r = mysqli_fetch_assoc($up_days_q)) $up_days += (int)$r['days'];
?>

<div class="summary-grid">
    <div class="summary-card"><div class="num"><?php echo $up_count; ?></div><div class="lbl">Upcoming</div></div>
    <div class="summary-card"><div class="num"><?php echo $up_days; ?></div><div class="lbl">Holiday Days</div></div>
    <div class="summary-card"><div class="num"><?php echo $all_count; ?></div><div class="lbl">Total</div></div>
    <div class="summary-card"><div class="num"><?php echo date('Y'); ?></div><div class="lbl">Year</div></div>
</div>

<div class="tabs">
    <a href="holidays.php?view=upcoming" class="tab <?php echo $view==='upcoming'?'active':''; ?>">
        <i class="fas fa-calendar-day"></i> Upcoming <span class="count-badge"><?php echo $up_count; ?></span>
    </a>
    <a href="holidays.php?view=past" class="tab <?php echo $view==='past'?'active':''; ?>">
        <i class="fas fa-calendar-check"></i> Past
    </a>
    <a href="holidays.php?view=all" class="tab <?php echo $view==='all'?'active':''; ?>">
        <i class="fas fa-list"></i> All
    </a>
</div>

<?php if($view === 'past'): ?>
<div class="card">
    <div class="list-head"><i class="fas fa-history"></i> Past Holidays</div>
    <?php $count = 0; while($h = mysqli_fetch_assoc($past)): $count++; ?>
    <div class="h-row">
        <div class="h-date">
            <?php if(!empty($h['holiday_date'])): ?>
                <div class="d"><?php echo date('d', strtotime($h['holiday_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['holiday_date'])); ?></div>
            <?php else: ?>
                <div class="d"><?php echo date('d', strtotime($h['start_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['start_date'])); ?></div>
            <?php endif; ?>
        </div>
        <div class="h-info">
            <div class="name"><?php echo htmlspecialchars($h['holiday_name']); ?></div>
            <div class="sub"><i class="fas fa-calendar-alt"></i> <?php echo holiday_date_range($h); ?> &nbsp;·&nbsp; <?php echo holiday_days($h); ?> day(s)</div>
        </div>
        <div class="h-tag">
            <?php
            $t = $h['holiday_type'] ?? 'public';
            $cls = 'tag-' . ($t === 'long_vacation' ? 'long' : $t);
            echo '<span class="tag ' . $cls . '">' . htmlspecialchars(ucwords($t)) . '</span>';
            ?>
        </div>
    </div>
    <?php endwhile; ?>
    <?php if($count == 0): ?>
    <div class="empty-msg"><i class="fas fa-calendar-check"></i> No past holidays found.</div>
    <?php endif; ?>
</div>
<?php else: ?>
<div class="card">
    <div class="list-head"><i class="fas fa-calendar-day"></i> <?php echo $view==='all' ? 'All Holidays' : 'Upcoming Holidays'; ?></div>
    <?php
    $count = 0;
    if($view === 'all') {
        $allq = mysqli_query($conn, "SELECT * FROM holidays ORDER BY COALESCE(holiday_date, start_date) DESC");
        while($h = mysqli_fetch_assoc($allq)):
            $count++;
    ?>
    <div class="h-row">
        <div class="h-date">
            <?php if(!empty($h['holiday_date'])): ?>
                <div class="d"><?php echo date('d', strtotime($h['holiday_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['holiday_date'])); ?></div>
            <?php else: ?>
                <div class="d"><?php echo date('d', strtotime($h['start_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['start_date'])); ?></div>
            <?php endif; ?>
        </div>
        <div class="h-info">
            <div class="name"><?php echo htmlspecialchars($h['holiday_name']); ?></div>
            <div class="sub"><i class="fas fa-calendar-alt"></i> <?php echo holiday_date_range($h); ?> &nbsp;·&nbsp; <?php echo holiday_days($h); ?> day(s)</div>
        </div>
        <div class="h-tag">
            <?php
            $t = $h['holiday_type'] ?? 'public';
            $cls = 'tag-' . ($t === 'long_vacation' ? 'long' : $t);
            echo '<span class="tag ' . $cls . '">' . htmlspecialchars(ucwords($t)) . '</span>';
            ?>
        </div>
    </div>
    <?php endwhile; } else { while($h = mysqli_fetch_assoc($upcoming)): $count++; ?>
    <div class="h-row">
        <div class="h-date">
            <?php if(!empty($h['holiday_date'])): ?>
                <div class="d"><?php echo date('d', strtotime($h['holiday_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['holiday_date'])); ?></div>
            <?php else: ?>
                <div class="d"><?php echo date('d', strtotime($h['start_date'])); ?></div>
                <div class="m"><?php echo date('M Y', strtotime($h['start_date'])); ?></div>
            <?php endif; ?>
        </div>
        <div class="h-info">
            <div class="name"><?php echo htmlspecialchars($h['holiday_name']); ?></div>
            <div class="sub"><i class="fas fa-calendar-alt"></i> <?php echo holiday_date_range($h); ?> &nbsp;·&nbsp; <?php echo holiday_days($h); ?> day(s)</div>
        </div>
        <div class="h-tag">
            <?php
            $t = $h['holiday_type'] ?? 'public';
            $cls = 'tag-' . ($t === 'long_vacation' ? 'long' : $t);
            echo '<span class="tag ' . $cls . '">' . htmlspecialchars(ucwords($t)) . '</span>';
            ?>
        </div>
    </div>
    <?php endwhile; } ?>
    <?php if($count == 0): ?>
    <div class="empty-msg"><i class="fas fa-umbrella-beach"></i> No holidays found.</div>
    <?php endif; ?>
</div>
<?php endif; ?>

</body>
</html>

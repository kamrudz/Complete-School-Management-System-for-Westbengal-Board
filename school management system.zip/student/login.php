<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
redirect_student_if_logged_in();
require_once '../includes/db.php';
require_once '../includes/security.php';

// ===== BRUTE-FORCE PROTECTION (per UID, same as admin login) =====
$MAX_ATTEMPTS = 5;
$LOCKOUT_MINUTES = 15;

function s_get_attempt($conn, $identifier) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM login_attempts WHERE identifier = ?");
    if (!$stmt) return null;
    mysqli_stmt_bind_param($stmt, "s", $identifier);
    mysqli_stmt_execute($stmt);
    $r = mysqli_stmt_get_result($stmt);
    return $r && mysqli_num_rows($r) > 0 ? mysqli_fetch_assoc($r) : null;
}
function s_register_fail($conn, $identifier, $max_attempts, $lockout_minutes) {
    $row = s_get_attempt($conn, $identifier);
    if ($row === null) {
        $stmt = mysqli_prepare($conn, "INSERT INTO login_attempts (identifier, attempt_count, first_attempt_at) VALUES (?, 1, NOW())");
        if ($stmt) { mysqli_stmt_bind_param($stmt, "s", $identifier); mysqli_stmt_execute($stmt); }
        return;
    }
    $new_count = (int)$row['attempt_count'] + 1;
    if ($new_count >= $max_attempts) {
        $stmt = mysqli_prepare($conn, "UPDATE login_attempts SET attempt_count = ?, locked_until = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE identifier = ?");
        if ($stmt) mysqli_stmt_bind_param($stmt, "iis", $new_count, $lockout_minutes, $identifier);
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE login_attempts SET attempt_count = ? WHERE identifier = ?");
        if ($stmt) mysqli_stmt_bind_param($stmt, "is", $new_count, $identifier);
    }
    if ($stmt) mysqli_stmt_execute($stmt);
}
function s_clear_attempts($conn, $identifier) {
    $stmt = mysqli_prepare($conn, "DELETE FROM login_attempts WHERE identifier = ?");
    if ($stmt) { mysqli_stmt_bind_param($stmt, "s", $identifier); mysqli_stmt_execute($stmt); }
}

$error = '';
$locked_wait_msg = '';

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $uid = strtoupper(trim($_POST['uid'] ?? ''));
    $dob = trim($_POST['dob'] ?? '');

    // Lock check by UID
    $attempt_row = $uid !== '' ? s_get_attempt($conn, strtoupper($uid)) : null;
    $is_locked = false;
    if ($attempt_row && !empty($attempt_row['locked_until']) && strtotime($attempt_row['locked_until']) > time()) {
        $is_locked = true;
        $mins_left = max(1, ceil((strtotime($attempt_row['locked_until']) - time()) / 60));
        $locked_wait_msg = "অনেকবার ভুল তথ্য দেওয়ায় এই School UID থেকে লগইন সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে {$mins_left} মিনিট পর আবার চেষ্টা করুন।";
    }

    if($is_locked) {
        $error = $locked_wait_msg;
    } elseif($uid === '' || $dob === '') {
        $error = 'School UID এবং Date of Birth দুটোই দিন।';
    } else {
        // School UID only. admission_no used to be accepted too, but it is the
        // admission register serial — 3,136 students share 1,070 values — so
        // "admission_no = ? LIMIT 1" could log a student into a classmate's
        // account whose date of birth happened to match.
        $stmt = mysqli_prepare($conn, "
            SELECT * FROM students
            WHERE id = ?
              AND student_status = 'Active'
            LIMIT 1
        ");
        mysqli_stmt_bind_param($stmt, "s", $uid);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $student = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);

        if($student && !empty($student['dob']) && $student['dob'] === $dob) {
            s_clear_attempts($conn, strtoupper($uid));
            student_secure_login($student);
            header("Location: dashboard.php");
            exit();
        } else {
            s_register_fail($conn, strtoupper($uid), $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
            $error = 'School UID বা Date of Birth ঠিক নেই। আবার চেষ্টা করুন।';
        }
    }
}

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));
$timeout = isset($_GET['timeout']);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Student Login — <?php echo htmlspecialchars($school['school_name'] ?? 'SchoolMS'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
    font-family:'Segoe UI', system-ui, sans-serif;
    min-height:100vh;
    display:flex; align-items:center; justify-content:center;
    padding:20px;
    background:#0f1a2e;
    position:relative;
    overflow:hidden;
}
body::before {
    content:'';
    position:fixed; inset:0;
    background:
        radial-gradient(ellipse at 20% 50%, rgba(31,91,138,.25) 0%, transparent 60%),
        radial-gradient(ellipse at 80% 20%, rgba(0,51,102,.3) 0%, transparent 50%),
        radial-gradient(ellipse at 60% 80%, rgba(110,168,254,.1) 0%, transparent 50%);
    z-index:0;
}
.floating-shapes{position:fixed;inset:0;z-index:0;pointer-events:none;}
.shape{position:absolute;border-radius:50%;opacity:.06;animation:float linear infinite;}
.shape:nth-child(1){width:300px;height:300px;background:#6ea8fe;top:-80px;left:-80px;animation-duration:20s;}
.shape:nth-child(2){width:200px;height:200px;background:#1f5b8a;bottom:-60px;right:-60px;animation-duration:25s;animation-delay:-8s;}
.shape:nth-child(3){width:150px;height:150px;background:#6ea8fe;top:50%;left:70%;animation-duration:18s;animation-delay:-4s;}
@keyframes float{0%{transform:translate(0,0) rotate(0deg);}33%{transform:translate(30px,-30px) rotate(120deg);}66%{transform:translate(-20px,20px) rotate(240deg);}100%{transform:translate(0,0) rotate(360deg);}}
.login-wrapper{position:relative;z-index:1;width:100%;max-width:440px;}
.school-brand{text-align:center;margin-bottom:24px;color:#fff;}
.school-brand .school-icon{
    width:72px;height:72px;background:linear-gradient(135deg,#1f5b8a,#003366);
    border-radius:20px;display:inline-flex;align-items:center;justify-content:center;
    font-size:34px;margin-bottom:12px;box-shadow:0 8px 32px rgba(31,91,138,.4);
}
.school-brand h1{font-size:22px;font-weight:800;letter-spacing:1px;color:#fff;}
.school-brand p{font-size:13px;color:#8aaccc;margin-top:4px;}
.login-card{
    background:rgba(255,255,255,.04);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
    border:1px solid rgba(255,255,255,.1);border-radius:24px;padding:36px;
    box-shadow:0 24px 64px rgba(0,0,0,.4);
}
.card-title{font-size:18px;font-weight:700;color:#fff;margin-bottom:6px;}
.card-subtitle{font-size:13px;color:#8aaccc;margin-bottom:24px;}
.alert{padding:12px 16px;border-radius:12px;margin-bottom:20px;display:flex;align-items:center;gap:10px;font-size:14px;}
.alert-danger{background:rgba(220,53,69,.15);border:1px solid rgba(220,53,69,.3);color:#ff8091;}
.alert-warning{background:rgba(255,193,7,.12);border:1px solid rgba(255,193,7,.25);color:#ffd666;}
.form-group{margin-bottom:18px;}
.form-group label{display:block;font-size:12px;font-weight:600;color:#a8c4e0;margin-bottom:7px;letter-spacing:.5px;text-transform:uppercase;}
.input-wrap{position:relative;}
.input-wrap i.input-icon{position:absolute;left:15px;top:50%;transform:translateY(-50%);color:#5a7fa0;font-size:15px;pointer-events:none;}
.input-wrap input{
    width:100%;padding:12px 14px 12px 42px;background:rgba(255,255,255,.06);
    border:1.5px solid rgba(255,255,255,.1);border-radius:12px;font-size:15px;color:#fff;transition:all .25s;outline:none;
}
.input-wrap input::placeholder{color:#4a6a85;}
.input-wrap input:focus{background:rgba(110,168,254,.08);border-color:#6ea8fe;box-shadow:0 0 0 4px rgba(110,168,254,.12);}
.input-wrap:focus-within i.input-icon{color:#6ea8fe;}
input[type="date"]{color-scheme:dark;}
.btn-login{
    width:100%;padding:14px;background:linear-gradient(135deg,#1f5b8a 0%,#003366 100%);color:#fff;
    border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;letter-spacing:.5px;
    display:flex;align-items:center;justify-content:center;gap:10px;transition:all .25s;
    box-shadow:0 4px 20px rgba(0,51,102,.4);margin-top:6px;
}
.btn-login:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(31,91,138,.5);}
.btn-login:active{transform:translateY(0);}
.btn-login.loading{pointer-events:none;opacity:.8;}
.card-footer{margin-top:22px;text-align:center;font-size:12px;color:#4a6a85;display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;}
.card-footer a{color:#8aaccc;text-decoration:none;display:inline-flex;align-items:center;gap:5px;}
.card-footer a:hover{color:#fff;}
.hint-box{background:rgba(255,255,255,.04);border:1px dashed rgba(255,255,255,.12);border-radius:10px;padding:10px 14px;font-size:12px;color:#8aaccc;margin-top:16px;line-height:1.6;}
.hint-box i{color:#6ea8fe;margin-right:4px;}
@media(max-width:480px){.login-card{padding:26px 20px;}.school-brand h1{font-size:20px;}}
</style>
</head>
<body>
<div class="floating-shapes"><div class="shape"></div><div class="shape"></div><div class="shape"></div></div>

<div class="login-wrapper">
    <div class="school-brand">
        <?php if(!empty($school['logo'])): ?>
            <img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="school-icon" style="width:72px;height:72px;object-fit:cover;border-radius:20px;" alt="Logo">
        <?php else: ?>
            <div class="school-icon"><i class="fas fa-user-graduate"></i></div>
        <?php endif; ?>
        <h1><?php echo htmlspecialchars($school['school_name'] ?? 'School Management System'); ?></h1>
        <p>Student Portal</p>
    </div>

    <div class="login-card">
        <div class="card-title"><i class="fas fa-user-graduate"></i> Student Login</div>
        <div class="card-subtitle">School UID এবং Date of Birth দিয়ে প্রবেশ করুন</div>

        <?php if($timeout): ?>
        <div class="alert alert-warning"><i class="fas fa-clock"></i> Session শেষ হয়ে গেছে। আবার login করুন।</div>
        <?php endif; ?>

        <?php if($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>School UID</label>
                <div class="input-wrap">
                    <input type="text" name="uid" id="uid" placeholder="যেমন ULS-2026-0001"
                           value="<?php echo htmlspecialchars($_POST['uid'] ?? ''); ?>" autofocus required autocomplete="username">
                    <i class="fas fa-id-card input-icon"></i>
                </div>
            </div>
            <div class="form-group">
                <label>Date of Birth</label>
                <div class="input-wrap">
                    <input type="date" name="dob" id="dob" value="<?php echo htmlspecialchars($_POST['dob'] ?? ''); ?>" required>
                    <i class="fas fa-calendar-alt input-icon"></i>
                </div>
            </div>
            <button type="submit" class="btn-login" id="loginBtn"><i class="fas fa-sign-in-alt"></i> <span>Login</span></button>
        </form>

        <div class="hint-box">
            <i class="fas fa-info-circle"></i>
            School UID admission এর সময় দেওয়া হয় (admit card / report card-এ থাকে)। না জানলে office-এ যোগাযোগ করুন।
        </div>

        <div class="card-footer">
            <a href="../index.php"><i class="fas fa-home"></i> Home</a>
            <span>·</span>
            <a href="../admin/login.php"><i class="fas fa-shield-alt"></i> Admin</a>
            <span>·</span>
            <a href="../teacher/login.php"><i class="fas fa-chalkboard-teacher"></i> Teacher</a>
        </div>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', function() {
    var btn = document.getElementById('loginBtn');
    btn.classList.add('loading');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Logging in...</span>';
});
</script>
</body>
</html>

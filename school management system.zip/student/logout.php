<?php
require_once 'auth.php';
schoolms_destroy_session();
header('Location: login.php?logout=1');
exit;

<?php
/**
 * student/my_routine.php
 * ─────────────────────
 * Student নিজের class routine দেখতে পাবে।
 * Session login থাকলে নিজের Class/Section auto-detect হয়ে যাবে,
 * চাইলে উপরের dropdown থেকে অন্য Session/Class/Section-ও দেখা যাবে।
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }

require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once "../includes/section_groups.php";
require_once "../includes/user_access.php";
if (!ua_can($conn, 'student', 'feature_routine')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings WHERE id=1"));

// Active session by default
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$active_sid = (int)($active_session['id'] ?? 0);

// ── Student's own academic placement (auto-fill) ──
$my_acad = get_student_current_academic($conn, student_uid_clean($_SESSION['student_id'] ?? ''));

$session_id = isset($_GET['session_id']) ? (int)$_GET['session_id'] : ($active_sid > 0 ? $active_sid : (int)($my_acad['session_id'] ?? 0));
$class_id   = isset($_GET['class_id'])   ? (int)$_GET['class_id']   : (int)($my_acad['class_id'] ?? 0);
$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : (int)($my_acad['section_id'] ?? 0);

$days  = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$today = date('l');
if ($today === 'Sunday') $today = 'Monday';

$routine_mode = get_routine_mode($conn);

// All sessions, classes, sections for dropdown
$all_sessions = [];
$sq = mysqli_query($conn, "SELECT * FROM academic_sessions ORDER BY id DESC");
while ($r = mysqli_fetch_assoc($sq)) $all_sessions[] = $r;

$all_classes = [];
$cq = mysqli_query($conn, "SELECT * FROM classes ORDER BY class_name");
while ($r = mysqli_fetch_assoc($cq)) $all_classes[] = $r;

$all_sections = [];
if ($class_id > 0 && $session_id > 0) {
    $secq = mysqli_query($conn, "SELECT id, section_name FROM sections
        WHERE class_id='$class_id' AND session_id='$session_id' ORDER BY section_name");
    while ($r = mysqli_fetch_assoc($secq)) $all_sections[] = $r;
}

// ── Build routine if all filters selected ──
$routine_data  = [];
$period_rows   = [];
$class_info    = null;
$section_info  = null;
$session_info  = null;
$pair_label    = '';
$paired_ids    = [];

if ($session_id > 0 && $class_id > 0 && $section_id > 0) {
    $class_info   = mysqli_fetch_assoc(mysqli_query($conn, "SELECT class_name FROM classes WHERE id='$class_id'"));
    $section_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT section_name FROM sections WHERE id='$section_id'"));
    $session_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT session_name FROM academic_sessions WHERE id='$session_id'"));

    // Paired sections
    $paired_ids    = ($routine_mode === 'group_wise')
                     ? get_paired_section_ids($conn, $session_id, $class_id, $section_id)
                     : [$section_id];
    $paired_in_sql = implode(',', array_map('intval', $paired_ids));

    $pair_label = $section_info['section_name'];
    if ($routine_mode === 'group_wise' && count($paired_ids) > 1) {
        $pnames = [];
        foreach ($paired_ids as $psid) {
            $psr = mysqli_fetch_assoc(mysqli_query($conn, "SELECT section_name FROM sections WHERE id='$psid' LIMIT 1"));
            if ($psr) $pnames[] = $psr['section_name'];
        }
        $pair_label = implode(' + ', $pnames);
    }

    // Periods
    $pq = mysqli_query($conn, "SELECT * FROM periods ORDER BY sort_order, id");
    while ($pr = mysqli_fetch_assoc($pq)) $period_rows[] = $pr;

    // Routine data
    foreach ($days as $day) {
        $q = mysqli_query($conn, "
            SELECT r.period_id, r.group_id, r.subject_id, r.teacher_id,
                   s.subject_name, s.subject_code,
                   st.staff_name, st.short_code
            FROM routine r
            LEFT JOIN subjects s  ON s.id  = r.subject_id
            LEFT JOIN staff    st ON st.id = r.teacher_id
            WHERE r.session_id='$session_id'
              AND r.class_id='$class_id'
              AND r.section_id IN ($paired_in_sql)
              AND r.day_name='$day'
            ORDER BY r.period_id, r.group_id, r.id
        ");
        $routine_data[$day] = [];
        $seen = [];
        while ($row = mysqli_fetch_assoc($q)) {
            $pid = (int)$row['period_id'];
            if ((int)$row['group_id'] === -1) {
                $dk = $pid . '_' . $row['subject_id'] . '_' . $row['teacher_id'];
                if (isset($seen[$dk])) continue;
                $seen[$dk] = true;
            }
            $routine_data[$day][$pid][] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Class Routine — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:0;min-height:100vh;}

/* ── HEADER ── */
.site-header{background:linear-gradient(135deg,#0f1a2e,#1a3a5c);color:#fff;padding:14px 20px;display:flex;align-items:center;gap:14px;}
.site-header .logo{width:50px;height:50px;object-fit:contain;border-radius:6px;}
.site-header .logo-placeholder{width:50px;height:50px;background:rgba(255,255,255,.15);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:22px;}
.site-header .hinfo h1{font-size:17px;font-weight:800;margin-bottom:2px;}
.site-header .hinfo p{font-size:12px;opacity:.75;}
.site-header .hright{margin-left:auto;text-align:right;font-size:12px;opacity:.8;}

/* ── MAIN ── */
.main{max-width:1200px;margin:0 auto;padding:18px;}

/* ── FILTER CARD ── */
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;box-shadow:0 2px 10px rgba(0,0,0,.06);padding:18px 20px;margin-bottom:18px;}
.filter-row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;min-width:150px;flex:1;}
.fg label{font-size:11px;font-weight:700;color:#1a3b55;text-transform:uppercase;letter-spacing:.3px;}
.fg select{padding:8px 10px;border:2px solid #d0dbe8;border-radius:7px;font-size:13px;background:#fff;width:100%;}
.fg select:focus{outline:none;border-color:#003366;}
.btn{display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;text-decoration:none;transition:.2s;}
.btn-primary{background:#003366;color:#fff;} .btn-primary:hover{background:#004d99;}
.btn-print{background:#f59e0b;color:#fff;} .btn-print:hover{background:#d97706;}

/* ── INFO BAR ── */
.info-bar{background:linear-gradient(135deg,#e8f4ff,#eef7ff);border:1px solid #c9e3ff;border-radius:10px;padding:12px 18px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:18px;align-items:center;font-size:13px;}
.info-bar strong{color:#003366;}
.pair-badge{background:#1f5b8a;color:#fff;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;}
.today-badge{background:#28a745;color:#fff;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:700;}

/* ── DAY TABS ── */
.day-tabs{display:flex;flex-wrap:nowrap;gap:0;margin-bottom:0;overflow-x:auto;border-bottom:2px solid #e5e7eb;}
.day-tab{padding:9px 18px;font-size:13px;font-weight:600;color:#6c7a8a;cursor:pointer;border:none;background:none;white-space:nowrap;border-bottom:3px solid transparent;margin-bottom:-2px;transition:.2s;}
.day-tab:hover{color:#003366;}
.day-tab.active{color:#003366;border-bottom-color:#003366;}
.day-tab.today-tab.active{color:#28a745;border-bottom-color:#28a745;}

/* ── ROUTINE TABLE ── */
.table-wrap{overflow-x:auto;border-radius:10px;border:1px solid #e5e7eb;margin-top:12px;}
table.rt{width:100%;border-collapse:collapse;font-size:13px;min-width:500px;}
table.rt thead th{background:#003366;color:#fff;padding:10px 12px;text-align:center;font-size:12px;font-weight:600;white-space:nowrap;}
table.rt thead th:first-child{text-align:left;width:120px;}
table.rt tbody tr{border-bottom:1px solid #f0f2f5;transition:background .15s;}
table.rt tbody tr:hover{background:#f8faff;}
table.rt tbody tr.today-row{background:#f0fff4;}
table.rt tbody td{padding:10px 12px;vertical-align:middle;text-align:center;}
table.rt tbody td:first-child{text-align:left;font-weight:700;color:#003366;background:#f8f9fa;}
.period-time{font-size:10px;font-weight:400;color:#6c7a8a;margin-top:2px;}
.subj-name{font-weight:700;color:#1a3b55;font-size:13px;}
.teacher-name{font-size:11px;color:#1f5b8a;margin-top:3px;}
.split-div{border-top:1px dashed #f59e0b;margin:5px 0;}
.grp-badge{font-size:9px;background:#fff3cd;color:#856404;padding:1px 5px;border-radius:3px;font-weight:700;}
.empty-cell{color:#c5cdd8;font-size:18px;}

/* ── ALL-DAYS VIEW ── */
.alldays table.rt thead th{font-size:11px;padding:8px 8px;}
.alldays table.rt tbody td{padding:7px 8px;font-size:12px;}
.alldays .subj-name{font-size:12px;}

/* ── EMPTY STATE ── */
.empty-state{text-align:center;padding:50px 20px;background:#f8f9fa;border-radius:12px;border:2px dashed #d0dbe8;}
.empty-state i{font-size:44px;color:#003366;opacity:.2;display:block;margin-bottom:12px;}
.empty-state h3{color:#003366;}
.empty-state p{color:#6c7a8a;font-size:13px;margin-top:6px;}

/* ── PRINT ── */
@media print {
    body{background:#fff;padding:0;margin:0;}
    .site-header,.card,.day-tabs,.print-hide{display:none !important;}
    .table-wrap{border:none;}
    table.rt{width:100% !important;border-collapse:collapse;font-size:14px !important;}
    table.rt thead th{background:#003366 !important;color:#fff !important;padding:10px 14px !important;font-size:13px !important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
    table.rt tbody td{padding:10px 14px !important;font-size:13px !important;border:1px solid #ccc !important;}
    table.rt tbody td:first-child{background:#f0f4f9 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
    .print-header{display:flex !important;}
    @page{size:A4 landscape;margin:10mm 12mm;}
}
.print-header{display:none;align-items:center;gap:10px;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #003366;}
.print-header h1{font-size:17px;color:#003366;text-transform:uppercase;}
.print-header .sub{font-size:12px;color:#333;margin-top:2px;}
.print-header .logo{width:55px;height:55px;object-fit:contain;}

@media(max-width:600px){
    .fg{min-width:100%;}
    .info-bar{gap:10px;}
    .day-tab{padding:7px 12px;font-size:12px;}
}
</style>
</head>
<body>

<!-- Site Header -->
<div class="site-header">
    <?php if(!empty($school['logo'])): ?>
    <img class="logo" src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" alt="Logo">
    <?php else: ?>
    <div class="logo-placeholder"><i class="fas fa-school"></i></div>
    <?php endif; ?>
    <div class="hinfo">
        <h1><?php echo htmlspecialchars($school['school_name'] ?? 'School Name'); ?></h1>
        <p><?php echo htmlspecialchars($school['school_address'] ?? ''); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></p>
    </div>
    <div class="hright">
        <div><i class="fas fa-calendar-alt"></i> <?php echo date('d M Y'); ?></div>
        <div><i class="fas fa-clock"></i> <?php echo date('h:i A'); ?></div>
    </div>
</div>

<div class="main">

    <!-- Print header (hidden on screen) -->
    <div class="print-header" id="printHeader">
        <?php if(!empty($school['logo'])): ?>
        <img class="logo" src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" alt="">
        <?php endif; ?>
        <div>
            <h1><?php echo htmlspecialchars($school['school_name'] ?? ''); ?></h1>
            <div class="sub">
                CLASS ROUTINE —
                <?php if($class_info): ?>
                Class <?php echo htmlspecialchars($class_info['class_name']); ?> (<?php echo htmlspecialchars($pair_label); ?>)
                <?php endif; ?>
                <?php if($session_info): ?> | <?php echo htmlspecialchars($session_info['session_name']); ?><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card print-hide">
        <form method="GET" id="filterForm">
            <div class="filter-row">
                <div class="fg">
                    <label><i class="fas fa-calendar-alt"></i> Session</label>
                    <select name="session_id" onchange="this.form.submit()">
                        <?php foreach($all_sessions as $sess): ?>
                        <option value="<?php echo $sess['id']; ?>" <?php echo $session_id==$sess['id']?'selected':''; ?>>
                            <?php echo htmlspecialchars($sess['session_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="fg">
                    <label><i class="fas fa-chalkboard"></i> Class</label>
                    <select name="class_id" onchange="this.form.submit()">
                        <option value="">Select Class</option>
                        <?php foreach($all_classes as $cls): ?>
                        <option value="<?php echo $cls['id']; ?>" <?php echo $class_id==$cls['id']?'selected':''; ?>>
                            Class <?php echo htmlspecialchars($cls['class_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if(!empty($all_sections)): ?>
                <div class="fg">
                    <label><i class="fas fa-layer-group"></i> Section</label>
                    <select name="section_id" onchange="this.form.submit()">
                        <option value="">Select Section</option>
                        <?php foreach($all_sections as $sec): ?>
                        <option value="<?php echo $sec['id']; ?>" <?php echo $section_id==$sec['id']?'selected':''; ?>>
                            <?php echo htmlspecialchars($sec['section_name']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                <input type="hidden" name="section_id" value="0">
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if($session_id > 0 && $class_id > 0 && $section_id > 0 && !empty($period_rows)): ?>

    <!-- Info bar -->
    <div class="info-bar print-hide">
        <span><i class="fas fa-chalkboard"></i> <strong>Class:</strong> <?php echo htmlspecialchars($class_info['class_name']); ?></span>
        <span><i class="fas fa-layer-group"></i> <strong>Section:</strong> <?php echo htmlspecialchars($pair_label); ?>
            <?php if($routine_mode === 'group_wise' && count($paired_ids) > 1): ?>
            <span class="pair-badge"><i class="fas fa-link"></i> Paired</span>
            <?php endif; ?>
        </span>
        <span><i class="fas fa-calendar-alt"></i> <strong>Session:</strong> <?php echo htmlspecialchars($session_info['session_name']); ?></span>
        <span class="today-badge"><i class="fas fa-calendar-day"></i> Today: <?php echo $today; ?></span>
        <button onclick="window.print()" class="btn btn-print" style="margin-left:auto;">
            <i class="fas fa-print"></i> Print
        </button>
    </div>

    <!-- View toggle: day tabs or all-days -->
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;flex-wrap:wrap;" class="print-hide">
        <div class="day-tabs" id="dayTabs">
            <button class="day-tab active" data-day="ALL" onclick="switchDay('ALL', this)">
                <i class="fas fa-table"></i> All Days
            </button>
            <?php foreach($days as $d): ?>
            <button class="day-tab <?php echo $d===$today?'today-tab':''; ?> <?php echo $d===$today?'':''; ?>"
                    data-day="<?php echo $d; ?>"
                    onclick="switchDay('<?php echo $d; ?>', this)">
                <?php echo substr($d, 0, 3); ?>
                <?php if($d===$today): ?><span style="font-size:9px;vertical-align:super;color:#28a745;">●</span><?php endif; ?>
            </button>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ── ALL DAYS VIEW (default / print) ── -->
    <div id="view_ALL" class="alldays">
        <div class="table-wrap">
        <table class="rt">
            <thead>
                <tr>
                    <th><i class="fas fa-calendar-day"></i> Day</th>
                    <?php foreach($period_rows as $period): ?>
                    <th style="<?php echo $d===$today?'background:#1a5c2e;':''; ?>">
                        <i class="fas fa-clock"></i> <?php echo htmlspecialchars($period['period_name']); ?>
                        <?php if(!empty($period['start_time'])): ?>
                        <br><small style="font-weight:400;opacity:.8;">
                            <?php echo date('h:i A', strtotime($period['start_time'])); ?>
                            –
                            <?php echo date('h:i A', strtotime($period['end_time'])); ?>
                        </small>
                        <?php endif; ?>
                    </th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
            <?php foreach($days as $d):
                $is_today = ($d === $today);
            ?>
            <tr style="<?php echo $is_today?'background:#f0fff4;':''; ?>">
                <td style="text-align:left;font-weight:700;color:#003366;background:<?php echo $is_today?'#f0fff4':'#f8f9fa'; ?>;">
                    <?php echo $d; ?>
                    <?php if($is_today): ?><br><span style="font-size:9px;background:#28a745;color:#fff;padding:1px 6px;border-radius:10px;font-weight:700;">TODAY</span><?php endif; ?>
                </td>
                <?php foreach($period_rows as $period):
                    $entries = $routine_data[$d][(int)$period['id']] ?? [];
                    $is_split = count($entries) > 1;
                ?>
                <td style="text-align:center;<?php echo $is_today?'background:#f0fff4;':''; ?>">
                    <?php if(empty($entries)): ?>
                        <span class="empty-cell">·</span>
                    <?php else: ?>
                        <?php foreach($entries as $idx => $entry): ?>
                        <?php if($idx > 0): ?><div class="split-div"></div><?php endif; ?>
                        <?php if($is_split): ?><span class="grp-badge">GRP <?php echo $idx+1; ?></span><br><?php endif; ?>
                        <div class="subj-name"><?php echo htmlspecialchars($entry['subject_name'] ?? '—'); ?></div>
                        <div class="teacher-name"><i class="fas fa-user"></i> <?php echo htmlspecialchars($entry['short_code'] ?: $entry['staff_name'] ?? ''); ?></div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>

    <!-- ── SINGLE DAY VIEWS ── -->
    <?php foreach($days as $d): ?>
    <div id="view_<?php echo $d; ?>" style="display:none;">
        <div class="table-wrap">
        <table class="rt">
            <thead>
                <tr>
                    <th><i class="fas fa-clock"></i> Period</th>
                    <th style="<?php echo $d===$today?'background:#1a5c2e;':''; ?>">
                        <i class="fas fa-calendar-day"></i> <?php echo $d; ?>
                        <?php if($d===$today): ?> <span class="today-badge" style="font-size:10px;">Today</span><?php endif; ?>
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($period_rows as $period):
                $entries  = $routine_data[$d][(int)$period['id']] ?? [];
                $is_split = count($entries) > 1;
            ?>
            <tr class="<?php echo $d===$today?'today-row':''; ?>">
                <td style="min-width:110px;">
                    <div><?php echo htmlspecialchars($period['period_name']); ?></div>
                    <?php if(!empty($period['start_time']) && !empty($period['end_time'])): ?>
                    <div class="period-time"><?php echo date('h:i A', strtotime($period['start_time'])); ?> – <?php echo date('h:i A', strtotime($period['end_time'])); ?></div>
                    <?php endif; ?>
                </td>
                <td style="text-align:left;padding-left:18px;">
                    <?php if(empty($entries)): ?>
                        <span style="color:#c5cdd8;">— Free —</span>
                    <?php else: ?>
                        <?php foreach($entries as $idx => $entry): ?>
                        <?php if($idx > 0): ?><div class="split-div"></div><?php endif; ?>
                        <?php if($is_split): ?><span class="grp-badge">GROUP <?php echo $idx+1; ?></span><br><?php endif; ?>
                        <div class="subj-name" style="font-size:15px;"><?php echo htmlspecialchars($entry['subject_name'] ?? '—'); ?></div>
                        <div class="teacher-name"><i class="fas fa-chalkboard-teacher"></i> <?php echo htmlspecialchars($entry['staff_name'] ?? ''); ?></div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php endforeach; ?>

    <?php elseif($session_id > 0 && $class_id > 0 && $section_id > 0): ?>
    <div class="empty-state">
        <i class="fas fa-calendar-times"></i>
        <h3>কোনো Routine পাওয়া যায়নি</h3>
        <p>এই Class/Section-এর জন্য এখনো Routine তৈরি হয়নি।</p>
    </div>
    <?php else: ?>
    <div class="empty-state">
        <i class="fas fa-filter"></i>
        <h3>Class ও Section Select করুন</h3>
        <p>উপরে Class এবং Section বেছে নিন — Routine দেখতে পাবেন।</p>
    </div>
    <?php endif; ?>

</div><!-- /main -->

<script>
function switchDay(day, btn) {
    // Hide all views
    document.querySelectorAll('[id^="view_"]').forEach(function(el){ el.style.display = 'none'; });
    // Show selected
    var target = document.getElementById('view_' + day);
    if (target) target.style.display = 'block';
    // Update tabs
    document.querySelectorAll('.day-tab').forEach(function(t){ t.classList.remove('active'); });
    btn.classList.add('active');
}

// On load: if today is a school day, activate today's tab
document.addEventListener('DOMContentLoaded', function() {
    var today = '<?php echo $today; ?>';
    var todayBtn = document.querySelector('.day-tab[data-day="' + today + '"]');
    if (todayBtn) {
        switchDay(today, todayBtn);
    }
});
</script>
</body>
</html>

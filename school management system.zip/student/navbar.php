<?php
/**
 * student/navbar.php — Student Portal Navigation
 */
// Partial: the portal pages include this after connecting to the database.
// Requested directly there is no $conn, and the page fatalled with a stack
// trace exposing filesystem paths to anonymous visitors.
if (!isset($conn)) { http_response_code(404); exit; }

require_once '../includes/user_access.php';
$current_page = basename($_SERVER['PHP_SELF']);
$ua_can_student = function($key) use ($conn) {
    return ua_can($conn, 'student', $key);
};
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
.s-navbar{background:linear-gradient(135deg,#0f1a2e,#1a3a5c);padding:0 18px;border-radius:10px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;min-height:50px;position:relative;z-index:999;box-shadow:0 4px 16px rgba(0,0,0,.2);}
.s-nav-brand{color:#fff;font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;text-decoration:none;flex-shrink:0;}
.s-nav-brand i{color:#6ea8fe;font-size:18px;}
.s-nav-links{display:flex;align-items:center;gap:2px;flex-wrap:wrap;}
.s-nav-links a{color:#c5d8eb;text-decoration:none;font-size:13px;font-weight:600;padding:7px 13px;border-radius:6px;display:flex;align-items:center;gap:6px;white-space:nowrap;transition:all .2s;}
.s-nav-links a:hover,.s-nav-links a.active{background:rgba(255,255,255,.12);color:#fff;}
.s-nav-links a i{font-size:13px;color:#7a9bbd;}
.s-nav-links a:hover i,.s-nav-links a.active i{color:#fff;}
.s-nav-links a.active{border-bottom:2px solid #6ea8fe;}
.s-nav-right{display:flex;align-items:center;gap:8px;flex-shrink:0;}
.s-nav-user{display:flex;align-items:center;gap:8px;color:#c5d8eb;font-size:13px;font-weight:600;}
.s-nav-user img{width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.25);}
.s-nav-user .avatar{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:12px;color:#fff;font-weight:700;}
.s-nav-logout{color:#ef4444;text-decoration:none;font-size:13px;font-weight:600;padding:6px 12px;border-radius:6px;display:flex;align-items:center;gap:5px;transition:.2s;}
.s-nav-logout:hover{background:rgba(239,68,68,.1);}
.s-toggle{display:none;background:none;border:none;color:#fff;font-size:20px;cursor:pointer;padding:4px 8px;}
@media(max-width:900px){
    .s-navbar{flex-wrap:wrap;padding:6px 12px;}
    .s-toggle{display:block;margin-left:auto;}
    .s-nav-links{display:none;width:100%;flex-direction:column;align-items:stretch;padding:4px 0;}
    .s-nav-links.open{display:flex;}
    .s-nav-links a{padding:8px 12px;font-size:14px;justify-content:center;}
    .s-nav-right{display:none;}
    .s-nav-right.open{display:flex;justify-content:center;align-items:center;flex-wrap:wrap;width:100%;padding:6px 0;border-top:1px solid rgba(255,255,255,.08);}
}
@media(max-width:480px){
    .s-navbar{padding:6px 10px;}
    .s-nav-brand{font-size:14px;}
    .s-nav-user span{display:none;}
}
</style>
<nav class="s-navbar">
    <a href="dashboard.php" class="s-nav-brand"><i class="fas fa-user-graduate"></i> Student Portal</a>

    <button class="s-toggle" onclick="toggleSNav()"><i class="fas fa-bars"></i></button>

    <div class="s-nav-links" id="sNavLinks">
        <a href="dashboard.php" class="<?php echo $current_page==='dashboard.php'?'active':''; ?>">
            <i class="fas fa-th-large"></i> Dashboard
        </a>
        <a href="profile.php" class="<?php echo $current_page==='profile.php'?'active':''; ?>">
            <i class="fas fa-user-circle"></i> Profile
        </a>
        <?php if ($ua_can_student('feature_routine')): ?>
        <a href="my_routine.php" class="<?php echo $current_page==='my_routine.php'?'active':''; ?>">
            <i class="fas fa-calendar-alt"></i> Routine
        </a>
        <?php endif; ?>
        <?php if ($ua_can_student('feature_progress_report')): ?>
        <a href="progress_report.php" class="<?php echo $current_page==='progress_report.php'?'active':''; ?>">
            <i class="fas fa-chart-bar"></i> Progress Report
        </a>
        <?php endif; ?>
        <?php if ($ua_can_student('feature_fees')): ?>
        <a href="fees.php" class="<?php echo $current_page==='fees.php'?'active':''; ?>">
            <i class="fas fa-wallet"></i> My Fees
        </a>
        <?php endif; ?>
        <?php if ($ua_can_student('feature_holidays')): ?>
        <a href="holidays.php" class="<?php echo $current_page==='holidays.php'?'active':''; ?>">
            <i class="fas fa-umbrella-beach"></i> Holidays
        </a>
        <?php endif; ?>
        <?php if ($ua_can_student('feature_edit_profile')): ?>
        <a href="edit_profile.php" class="<?php echo $current_page==='edit_profile.php'?'active':''; ?>">
            <i class="fas fa-user-edit"></i> Edit Profile
        </a>
        <?php endif; ?>
    </div>

    <div class="s-nav-right" id="sNavRight">
        <div class="s-nav-user">
            <?php if(!empty($_SESSION['student_photo'])): ?>
                <img src="../uploads/students/<?php echo htmlspecialchars($_SESSION['student_photo']); ?>" alt="">
            <?php else: ?>
                <div class="avatar"><?php echo strtoupper(substr($_SESSION['student_name']??'S',0,1)); ?></div>
            <?php endif; ?>
            <span><?php echo htmlspecialchars($_SESSION['student_name'] ?? 'Student'); ?></span>
        </div>
        <a href="logout.php" class="s-nav-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>
<script>
function toggleSNav(){
    document.getElementById('sNavLinks').classList.toggle('open');
    document.getElementById('sNavRight').classList.toggle('open');
}
</script>

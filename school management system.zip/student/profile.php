<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once '../includes/user_access.php';
if (!ua_can($conn, 'student', 'feature_profile')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$student_id = student_uid_clean($_SESSION['student_id'] ?? '');
$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id='$student_id'"));
if(!$student) { header("Location: logout.php"); exit(); }

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));
$acad = get_student_current_academic($conn, $student_id);

$guardian = null;
if(!empty($student['guardian_id'])) {
    $guardian = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM guardians WHERE guardian_id='" . (int)$student['guardian_id'] . "'"));
}

// Academic history (all sessions)
$history = [];
$hq = mysqli_query($conn, "
    SELECT sah.session_id, sah.roll_no, sah.academic_status, sah.promotion_status,
           ss.session_name, c.class_name, sec.section_name
    FROM student_academic_history sah
    JOIN academic_sessions ss ON ss.id = sah.session_id
    JOIN classes c ON c.id = sah.class_id
    LEFT JOIN sections sec ON sec.id = sah.section_id
    WHERE sah.student_id='$student_id'
    ORDER BY sah.session_id DESC
");
while ($r = mysqli_fetch_assoc($hq)) $history[] = $r;

function profile_row($label, $value, $icon = 'fas fa-circle-info') {
    echo '<div class="p-row"><span class="p-label"><i class="' . $icon . '"></i> ' . htmlspecialchars($label) . '</span><span class="p-value">' . ($value === '' || $value === null ? '<span class="na">—</span>' : htmlspecialchars($value)) . '</span></div>';
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Profile — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;overflow-x:hidden;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
.profile-head{display:flex;gap:20px;align-items:center;background:linear-gradient(135deg,#1f5b8a,#003366);border-radius:14px;padding:24px;margin-bottom:20px;color:#fff;flex-wrap:wrap;}
.profile-head img{width:110px;height:110px;border-radius:14px;object-fit:cover;border:3px solid rgba(255,255,255,.3);}
.profile-head .avatar{width:110px;height:110px;border-radius:14px;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:44px;font-weight:700;}
.profile-head .h-name{font-size:24px;font-weight:800;}
.profile-head .h-meta{font-size:13px;opacity:.85;margin-top:6px;line-height:1.6;}
.profile-head .h-meta span{background:rgba(255,255,255,.15);padding:2px 10px;border-radius:20px;display:inline-block;margin:2px 4px 2px 0;font-weight:600;}
.sections{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.card-head{padding:12px 18px;background:#fafbfc;border-bottom:1px solid #f0f2f5;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.card-head i{color:#1f5b8a;}
.card-body{padding:8px 18px 14px;}
.p-row{display:flex;justify-content:space-between;gap:16px;padding:9px 0;border-bottom:1px dashed #f0f2f5;font-size:13px;}
.p-row:last-child{border-bottom:none;}
.p-label{color:#6c7a8a;font-weight:600;display:flex;align-items:center;gap:7px;flex-shrink:0;}
.p-label i{width:16px;color:#1f5b8a;font-size:12px;}
.p-value{color:#0f1a2e;font-weight:600;text-align:right;}
.p-value .na{color:#c5cdd8;font-weight:400;}
.full{grid-column:1/-1;}
.hist-table{width:100%;border-collapse:collapse;font-size:13px;}
.hist-table th{background:#f8f9fa;color:#1a3b55;text-align:left;padding:8px 12px;font-size:12px;}
.hist-table td{padding:8px 12px;border-bottom:1px solid #f0f2f5;}
.tag{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:700;}
.tag-current{background:#dcfce7;color:#166534;}
.tag-history{background:#f1f5f9;color:#475569;}
@media(max-width:900px){.profile-head{padding:18px;}.profile-head .h-name{font-size:20px;}.sections{grid-template-columns:1fr;}}
@media(max-width:640px){.page-title{font-size:20px;}.profile-head{align-items:flex-start;}.profile-head .h-meta span{display:inline-flex;align-items:center;}.p-row{flex-direction:column;align-items:flex-start;gap:4px;}.p-value{text-align:left;}.hist-table th,.hist-table td{padding:8px 10px;font-size:12px;}}
@media(max-width:480px){body{padding:12px;}.profile-head{padding:16px;}.profile-head img,.profile-head .avatar{width:84px;height:84px;}.profile-head .h-meta{font-size:12px;}.card-head{padding:10px 14px;}.card-body{padding:10px 14px 12px;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:18px;">
    <div class="page-title" style="margin-bottom:0;"><i class="fas fa-user-circle"></i> My Profile</div>
    <?php if (ua_can($conn, 'student', 'feature_edit_profile')): ?>
        <a href="edit_profile.php" style="background:#003366;color:#fff;text-decoration:none;padding:10px 18px;border-radius:8px;font-weight:700;font-size:13px;"><i class="fas fa-user-edit"></i> Edit Profile</a>
    <?php endif; ?>
</div>

<div class="profile-head">
    <?php if(!empty($student['photo'])): ?>
        <img src="../uploads/students/<?php echo htmlspecialchars($student['photo']); ?>" alt="Photo">
    <?php else: ?>
        <div class="avatar"><?php echo strtoupper(substr($student['student_name'],0,1)); ?></div>
    <?php endif; ?>
    <?php if(!empty($student['signature'])): ?>
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
            <img src="../uploads/students/<?php echo htmlspecialchars($student['signature']); ?>" alt="Signature" style="width:150px;height:60px;border-radius:8px;object-fit:contain;background:#fff;padding:4px;border:2px solid rgba(255,255,255,.35);">
            <span style="font-size:11px;opacity:.8;">Signature</span>
        </div>
    <?php endif; ?>
    <div>
        <div class="h-name"><?php echo htmlspecialchars($student['student_name']); ?></div>
        <div class="h-meta">
            <?php if($acad): ?>
                <span>Class <?php echo htmlspecialchars($acad['class_name']); ?> - <?php echo htmlspecialchars($acad['section_name'] ?? ''); ?></span>
                <span>Roll: <?php echo htmlspecialchars($acad['roll_no'] ?? ''); ?></span>
                <span><?php echo htmlspecialchars($acad['session_name']); ?></span>
            <?php endif; ?>
            <span>UID: <?php echo htmlspecialchars($student['id']); ?></span>
        </div>
    </div>
</div>

<div class="sections">

    <div class="card">
        <div class="card-head"><i class="fas fa-id-card"></i> Admission & Identity</div>
        <div class="card-body">
            <?php
            profile_row('School UID', $student['id'], 'fas fa-fingerprint');
            profile_row('Admission No', $student['admission_no'] ?? '', 'fas fa-hashtag');
            profile_row('Admission Date', $student['admission_date'] ? date('d M Y', strtotime($student['admission_date'])) : '', 'fas fa-calendar-plus');
            profile_row('Banglarshiksha ID', $student['banglarshiksha_id'] ?? '', 'fas fa-id-badge');
            profile_row('PEN ID', $student['pen_id'] ?? '', 'fas fa-qrcode');
            profile_row('APAAR ID', $student['apaar_id'] ?? '', 'fas fa-file-invoice');
            profile_row('Birth Reg. No', $student['birth_registration_number'] ?? '', 'fas fa-file-certificate');
            profile_row('Aadhaar No', $student['student_aadhaar'] ?? '', 'fas fa-credit-card');
            ?>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><i class="fas fa-user"></i> Personal Details</div>
        <div class="card-body">
            <?php
            profile_row('Name as per Aadhaar', $student['name_as_per_aadhaar'] ?? '', 'fas fa-signature');
            profile_row('Date of Birth', $student['dob'] ? date('d M Y', strtotime($student['dob'])) : '', 'fas fa-cake-candles');
            profile_row('Gender', $student['gender'] ?? '', 'fas fa-venus-mars');
            profile_row('Blood Group', $student['blood_group'] ?? '', 'fas fa-droplet');
            profile_row('Religion', $student['religion'] ?? '', 'fas fa-place-of-worship');
            profile_row('Caste', $student['caste'] ?? '', 'fas fa-layer-group');
            profile_row('Sub-Caste', $student['sub_caste'] ?? '', 'fas fa-layer-group');
            profile_row('Disability', !empty($student['disability']) ? $student['disability'] . ($student['disability_type'] ? ' (' . $student['disability_type'] . ')' : '') : '', 'fas fa-wheelchair');
            profile_row('House', (string)(db_get_row('SELECT name FROM houses WHERE id = ?', 'i', (int)($student['house_id'] ?? 0))['name'] ?? ''), 'fas fa-shield-halved');
            ?>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><i class="fas fa-address-book"></i> Address & Contact</div>
        <div class="card-body">
            <?php
            profile_row('Village', $student['village'] ?? '', 'fas fa-location-dot');
            profile_row('Post Office', $student['post_office'] ?? '', 'fas fa-envelope');
            profile_row('Police Station', $student['police_station'] ?? '', 'fas fa-building-shield');
            profile_row('District', $student['district'] ?? '', 'fas fa-map');
            profile_row('State', $student['state'] ?? '', 'fas fa-map-location-dot');
            profile_row('PIN Code', $student['pin_code'] ?? '', 'fas fa-hashtag');
            profile_row('Mobile', $student['mobile'] ?? '', 'fas fa-phone');
            profile_row('Email', $student['email'] ?? '', 'fas fa-envelope-open-text');
            ?>
        </div>
    </div>

    <div class="card">
        <div class="card-head"><i class="fas fa-users"></i> Guardian / Parent Details</div>
        <div class="card-body">
            <?php if($guardian): ?>
                <?php
                profile_row('Father Name', $guardian['father_name'] ?? '', 'fas fa-user');
                profile_row('Father Aadhaar', $guardian['father_aadhaar'] ?? '', 'fas fa-credit-card');
                profile_row('Father Mobile', $guardian['father_mobile'] ?? '', 'fas fa-phone');
                profile_row('Father Occupation', $guardian['father_occupation'] ?? '', 'fas fa-briefcase');
                profile_row('Mother Name', $guardian['mother_name'] ?? '', 'fas fa-user');
                profile_row('Mother Aadhaar', $guardian['mother_aadhaar'] ?? '', 'fas fa-credit-card');
                profile_row('Mother Occupation', $guardian['mother_occupation'] ?? '', 'fas fa-briefcase');
                if(!empty($guardian['guardian_name'])):
                    profile_row('Guardian', $guardian['guardian_name'] . ($guardian['guardian_relation'] ? ' (' . $guardian['guardian_relation'] . ')' : ''), 'fas fa-user-tie');
                endif;
                ?>
            <?php else: ?>
                <div class="empty-msg" style="text-align:center;padding:16px;color:#6c7a8a;">Guardian details not available.</div>
            <?php endif; ?>
        </div>
    </div>

    <?php if(!empty($history)): ?>
    <div class="card full">
        <div class="card-head"><i class="fas fa-history"></i> Academic History</div>
        <div class="card-body" style="padding:0;overflow-x:auto;">
            <table class="hist-table">
                <thead><tr><th>Session</th><th>Class</th><th>Section</th><th>Roll</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach($history as $h): ?>
                <tr>
                    <td><?php echo htmlspecialchars($h['session_name']); ?></td>
                    <td><?php echo htmlspecialchars($h['class_name']); ?></td>
                    <td><?php echo htmlspecialchars($h['section_name'] ?? '—'); ?></td>
                    <td><?php echo htmlspecialchars($h['roll_no'] ?? '—'); ?></td>
                    <td>
                        <?php if($h['academic_status'] === 'Current'): ?>
                            <span class="tag tag-current">Current</span>
                        <?php else: ?>
                            <span class="tag tag-history"><?php echo htmlspecialchars($h['promotion_status'] ?? 'History'); ?></span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <?php if(!empty($student['bank_name']) || !empty($student['account_number'])): ?>
    <div class="card full">
        <div class="card-head"><i class="fas fa-landmark"></i> Bank Details</div>
        <div class="card-body">
            <?php
            profile_row('Bank', $student['bank_name'] ?? '', 'fas fa-landmark');
            profile_row('Branch', $student['branch_name'] ?? '', 'fas fa-building');
            profile_row('Account No', $student['account_number'] ?? '', 'fas fa-hashtag');
            profile_row('IFSC Code', $student['ifsc_code'] ?? '', 'fas fa-barcode');
            ?>
        </div>
    </div>
    <?php endif; ?>

</div>

</body>
</html>

<?php
/**
 * student/progress_report.php
 * Logged-in student apne saare published exam results dekhega.
 * V-X  -> `marks` + `exams` + `exam_subject_marks` (pass/fail via pass_fail_helper)
 * XI-XII -> `hs_marks` + `hs_exam` + `hs_exam_subject_marks`
 * Sirf is_published=1 results dikhte hain.
 */
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_student_login();
include("../includes/db.php");
require_once("../includes/pass_fail_helper.php");
require_once '../includes/user_access.php';
if (!ua_can($conn, 'student', 'feature_progress_report')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings WHERE id=1"));
$student_id = student_uid_clean($_SESSION['student_id'] ?? '');

// All sessions the student attended
$my_sessions = [];
$sq = mysqli_query($conn, "
    SELECT ss.id, ss.session_name, sah.class_id, c.class_name
    FROM student_academic_history sah
    JOIN academic_sessions ss ON ss.id = sah.session_id
    JOIN classes c ON c.id = sah.class_id
    WHERE sah.student_id='$student_id'
    ORDER BY ss.id DESC
");
while($r = mysqli_fetch_assoc($sq)) $my_sessions[] = $r;

$session_id = isset($_GET['session_id']) ? (int)$_GET['session_id'] : (int)($my_sessions[0]['id'] ?? 0);

// The academic record for chosen session
$acad = null;
if($session_id > 0) {
    $acad = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT sah.session_id, sah.class_id, sah.section_id, sah.roll_no,
               ss.session_name, c.class_name, sec.section_name
        FROM student_academic_history sah
        JOIN academic_sessions ss ON ss.id = sah.session_id
        JOIN classes c ON c.id = sah.class_id
        LEFT JOIN sections sec ON sec.id = sah.section_id
        WHERE sah.student_id='$student_id' AND sah.session_id='$session_id'
        LIMIT 1
    "));
}

$student = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM students WHERE id='$student_id'"));
$class_name = $acad['class_name'] ?? '';
$class_id = (int)($acad['class_id'] ?? 0);

$vx_exams = [];
$hs_exams_list = [];
$combined_result = null;

if($acad) {
    $sid = $student_id;

    if(in_array($class_name, ['V','VI','VII','VIII','IX','X'], true)) {
        $exam_q = mysqli_query($conn, "
            SELECT id, exam_name, exam_order
            FROM exams
            WHERE session_id='$session_id' AND exam_type='v-x' AND is_published=1
            ORDER BY exam_order ASC, id ASC
        ");
        while($ex = mysqli_fetch_assoc($exam_q)) {
            $exam_id = (int)$ex['id'];
            $m_q = mysqli_query($conn, "
                SELECT m.subject_id, sub.subject_name, m.written_marks, m.project_marks,
                       m.marks, m.is_absent,
                       esm.written_full_marks, esm.project_full_marks,
                       esm.total_full_marks, esm.total_pass_marks
                FROM marks m
                JOIN subjects sub ON sub.id = m.subject_id
                LEFT JOIN exam_subject_marks esm
                       ON esm.session_id = m.session_id AND esm.exam_id = m.exam_id
                      AND esm.class_id = m.class_id AND esm.subject_id = m.subject_id
                WHERE m.student_id='$sid' AND m.session_id='$session_id' AND m.exam_id='$exam_id'
                ORDER BY sub.subject_name ASC
            ");
            $subject_rows = [];
            while($mr = mysqli_fetch_assoc($m_q)) $subject_rows[] = $mr;
            if(empty($subject_rows)) continue;

            $result_summary = get_student_result($conn, $sid, $session_id, $class_id, $exam_id);
            $vx_exams[] = ['exam_name' => $ex['exam_name'], 'subjects' => $subject_rows, 'summary' => $result_summary];
        }

        $summative_names = [];
        foreach($vx_exams as $ex) {
            if(stripos($ex['exam_name'], 'summative') !== false) $summative_names[] = $ex['exam_name'];
        }
        if(count($summative_names) >= 2) {
            $subj_combined = [];
            foreach($vx_exams as $ex) {
                if(!in_array($ex['exam_name'], $summative_names, true)) continue;
                foreach($ex['subjects'] as $sub) {
                    $sj = $sub['subject_id'];
                    if(!isset($subj_combined[$sj])) {
                        $subj_combined[$sj] = ['name' => $sub['subject_name'], 'obtained' => 0, 'full' => 0, 'pass' => 0];
                    }
                    $subj_combined[$sj]['obtained'] += $sub['is_absent'] ? 0 : (float)$sub['marks'];
                    $subj_combined[$sj]['full']     += (float)($sub['total_full_marks'] ?? 0);
                    $subj_combined[$sj]['pass']     += (float)($sub['total_pass_marks'] ?? 0);
                }
            }
            $c_total = 0; $c_full = 0; $c_failed = 0;
            foreach($subj_combined as $st) {
                $c_total += $st['obtained'];
                $c_full  += $st['full'];
                if($st['obtained'] < $st['pass']) $c_failed++;
            }
            $c_percentage = $c_full > 0 ? round(($c_total / $c_full) * 100, 2) : 0;
            $pf_settings = get_pass_fail_settings($conn, $class_id);
            if($c_failed == 0 && $c_percentage >= (float)$pf_settings['pass_min_percentage']) {
                $c_status = 'PASS';
            } elseif(!empty($pf_settings['no_fail_policy'])) {
                $c_status = 'PROMOTED UNDER CONSIDERATION';
            } elseif(!empty($pf_settings['puc_enabled']) && $c_failed > 0
                      && $c_failed <= (int)$pf_settings['puc_max_fail_subjects']
                      && $c_percentage >= (float)$pf_settings['puc_min_percentage']) {
                $c_status = 'PROMOTED UNDER CONSIDERATION';
            } else {
                $c_status = 'FAIL';
            }
            $combined_result = [
                'exam_names' => $summative_names,
                'subjects'   => $subj_combined,
                'total'      => $c_total,
                'full'       => $c_full,
                'percentage' => $c_percentage,
                'status'     => $c_status,
                'failed'     => $c_failed,
            ];
        }
    } elseif(in_array($class_name, ['XI','XII'], true)) {
        $hs_exam_q = mysqli_query($conn, "
            SELECT id, exam_name, academic_year
            FROM hs_exam
            WHERE session_id='$session_id' AND class_id='$class_id' AND is_published=1
            ORDER BY id ASC
        ");
        while($he = mysqli_fetch_assoc($hs_exam_q)) {
            $hs_exam_id = (int)$he['id'];
            $hm_q = mysqli_query($conn, "
                SELECT hm.subject_id, sub.subject_name,
                       hm.sem1_marks, hm.sem1_supplementary_marks, hm.sem1_absent,
                       hm.sem2_marks, hm.sem2_supplementary_marks, hm.sem2_absent,
                       hm.practical_marks, hm.practical_absent,
                       hm.total_marks, hm.subject_grade, hm.remarks,
                       hesm.sem1_full_marks, hesm.sem2_full_marks, hesm.practical_full_marks
                FROM hs_marks hm
                JOIN subjects sub ON sub.id = hm.subject_id
                LEFT JOIN hs_exam_subject_marks hesm
                       ON hesm.hs_exam_id = hm.hs_exam_id AND hesm.subject_id = hm.subject_id
                WHERE hm.hs_exam_id='$hs_exam_id' AND hm.student_id='$sid'
                ORDER BY sub.subject_name ASC
            ");
            $subject_rows = [];
            while($hr = mysqli_fetch_assoc($hm_q)) $subject_rows[] = $hr;
            if(empty($subject_rows)) continue;

            $hs_failed = 0;
            foreach($subject_rows as $sr) {
                $is_f = (strtoupper($sr['subject_grade'] ?? '') === 'F');
                $is_abs = !empty($sr['sem1_absent']) || !empty($sr['sem2_absent']);
                if($is_f || $is_abs) $hs_failed++;
            }
            $hs_status = $hs_failed > 0 ? 'FAIL' : 'PASS';
            $hs_exams_list[] = [
                'exam_name' => $he['exam_name'],
                'academic_year' => $he['academic_year'],
                'subjects' => $subject_rows,
                'status' => $hs_status,
                'failed' => $hs_failed,
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Progress Report — <?php echo htmlspecialchars($school['school_name'] ?? 'School'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
.toolbar{display:flex;gap:10px;align-items:center;background:#fff;border:1px solid #e5e7eb;border-radius:10px;padding:12px 16px;margin-bottom:18px;box-shadow:0 2px 8px rgba(0,0,0,.04);flex-wrap:wrap;}
.toolbar label{font-size:12px;font-weight:700;color:#1a3b55;text-transform:uppercase;letter-spacing:.3px;}
.toolbar select{padding:8px 12px;border:2px solid #d0dbe8;border-radius:8px;font-size:13px;min-width:180px;}
.toolbar select:focus{outline:none;border-color:#1f5b8a;}
.info-bar{background:linear-gradient(135deg,#e8f4ff,#eef7ff);border:1px solid #c9e3ff;border-radius:10px;padding:12px 18px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:16px;align-items:center;font-size:13px;color:#1a3b55;}
.info-bar strong{color:#003366;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);margin-bottom:18px;}
.card .card-head{padding:12px 16px;background:#fafbfc;border-bottom:1px solid #f0f2f5;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.card .card-head i{color:#1f5b8a;}
.exam-block{border:1px solid #e4edf6;border-radius:10px;margin:14px;overflow:hidden;}
.exam-block .exam-title{background:#003366;color:#fff;padding:10px 16px;font-weight:700;font-size:14px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;}
.final-block{border:2px solid #ffc107;border-radius:10px;margin:14px;overflow:hidden;}
.final-block .exam-title{background:#b8860b;color:#fff;padding:10px 16px;font-weight:700;font-size:15px;display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap;}
.final-block .exam-title small{font-weight:400;font-size:11px;opacity:.9;}
table.result-table{width:100%;border-collapse:collapse;font-size:13px;}
table.result-table th,table.result-table td{padding:8px 10px;border-bottom:1px solid #eef2f6;text-align:center;}
table.result-table th{background:#f8f9fa;color:#1a3b55;font-size:12px;}
table.result-table td:first-child,table.result-table th:first-child{text-align:left;}
.status-badge{padding:3px 12px;border-radius:20px;font-size:11px;font-weight:700;}
.status-pass{background:#d4edda;color:#155724;}
.status-fail{background:#f8d7da;color:#721c24;}
.status-puc{background:#fff3cd;color:#856404;}
.summary-bar{padding:10px 16px;background:#f8f9fa;display:flex;justify-content:space-between;flex-wrap:wrap;gap:8px;font-size:13px;}
.disclaimer-box{background:#fff8e1;border:1px dashed #d4a017;padding:12px 16px;font-size:12px;color:#6b5000;margin:14px;border-radius:8px;text-align:center;}
.empty-state{text-align:center;padding:50px 20px;background:#f8f9fa;border-radius:12px;border:2px dashed #d0dbe8;}
.empty-state i{font-size:44px;color:#003366;opacity:.2;display:block;margin-bottom:12px;}
.empty-state h3{color:#003366;}
.empty-state p{color:#6c7a8a;font-size:13px;margin-top:6px;}
.no-photo{width:64px;height:64px;border-radius:8px;background:#e4edf6;display:flex;align-items:center;justify-content:center;color:#6c7a8a;font-size:11px;flex-shrink:0;}
@media(max-width:600px){.toolbar select{width:100%;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<div class="page-title"><i class="fas fa-chart-bar"></i> Progress Report</div>

<form class="toolbar" method="GET">
    <label><i class="fas fa-calendar-alt"></i> Session</label>
    <select name="session_id" onchange="this.form.submit()">
        <?php foreach($my_sessions as $s): ?>
        <option value="<?php echo $s['id']; ?>" <?php echo $session_id==$s['id']?'selected':''; ?>>
            <?php echo htmlspecialchars($s['session_name']); ?> (Class <?php echo htmlspecialchars($s['class_name']); ?>)
        </option>
        <?php endforeach; ?>
    </select>
</form>

<?php if(!$acad): ?>
<div class="empty-state">
    <i class="fas fa-user-graduate"></i>
    <h3>Academic placement not found</h3>
    <p>Office থেকে student admission record ঠিক করা প্রয়োজন।</p>
</div>
<?php else: ?>

<div class="info-bar">
    <span><i class="fas fa-user"></i> <strong><?php echo htmlspecialchars($student['student_name']); ?></strong></span>
    <span><i class="fas fa-chalkboard"></i> Class: <?php echo htmlspecialchars($class_name); ?> - <?php echo htmlspecialchars($acad['section_name'] ?? ''); ?></span>
    <span><i class="fas fa-hashtag"></i> Roll: <?php echo htmlspecialchars($acad['roll_no'] ?? '—'); ?></span>
    <span><i class="fas fa-calendar-alt"></i> Session: <?php echo htmlspecialchars($acad['session_name']); ?></span>
</div>

<?php if(empty($vx_exams) && empty($hs_exams_list)): ?>
<div class="empty-state">
    <i class="fas fa-file-alt"></i>
    <h3>কোনো Published Result নেই</h3>
    <p>এই session-এর জন্য এখনো কোনো result publish হয়নি।</p>
</div>
<?php else: ?>

<div class="card">
    <div class="card-head"><i class="fas fa-file-alt"></i> Published Results</div>

    <?php foreach($vx_exams as $exam):
        $sum = $exam['summary'];
        $status_class = 'status-fail';
        if($sum['status'] === 'PASS') $status_class = 'status-pass';
        elseif($sum['status'] === 'PROMOTED UNDER CONSIDERATION') $status_class = 'status-puc';
    ?>
    <div class="exam-block">
        <div class="exam-title">
            <span><i class="fas fa-file-alt"></i> <?php echo htmlspecialchars($exam['exam_name']); ?></span>
            <span class="status-badge <?php echo $status_class; ?>"><?php echo htmlspecialchars($sum['status']); ?></span>
        </div>
        <table class="result-table">
            <thead><tr><th>Subject</th><th>Written</th><th>Project</th><th>Total</th><th>Full Marks</th><th>Pass Marks</th></tr></thead>
            <tbody>
                <?php foreach($exam['subjects'] as $sub): ?>
                <tr>
                    <td><?php echo htmlspecialchars($sub['subject_name']); ?></td>
                    <td><?php echo $sub['is_absent'] ? 'AB' : $sub['written_marks']; ?></td>
                    <td><?php echo $sub['is_absent'] ? '-' : $sub['project_marks']; ?></td>
                    <td><strong><?php echo $sub['is_absent'] ? 'AB' : $sub['marks']; ?></strong></td>
                    <td><?php echo $sub['total_full_marks'] ?? '-'; ?></td>
                    <td><?php echo $sub['total_pass_marks'] ?? '-'; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="summary-bar">
            <span><strong>Total:</strong> <?php echo $sum['total_marks']; ?> / <?php echo $sum['total_full_marks']; ?></span>
            <span><strong>Percentage:</strong> <?php echo $sum['percentage']; ?>%</span>
            <span><strong>Subjects Failed:</strong> <?php echo $sum['subjects_failed']; ?></span>
        </div>
    </div>
    <?php endforeach; ?>

    <?php if($combined_result):
        $fc_class = 'status-fail';
        if($combined_result['status'] === 'PASS') $fc_class = 'status-pass';
        elseif($combined_result['status'] === 'PROMOTED UNDER CONSIDERATION') $fc_class = 'status-puc';
    ?>
    <div class="final-block">
        <div class="exam-title">
            <span><i class="fas fa-trophy"></i> Final Result <small>(<?php echo htmlspecialchars(implode(' + ', $combined_result['exam_names'])); ?>)</small></span>
            <span class="status-badge <?php echo $fc_class; ?>"><?php echo htmlspecialchars($combined_result['status']); ?></span>
        </div>
        <table class="result-table">
            <thead><tr><th>Subject</th><th>Marks Obtained</th><th>Full Marks</th></tr></thead>
            <tbody>
                <?php foreach($combined_result['subjects'] as $st): ?>
                <tr>
                    <td><?php echo htmlspecialchars($st['name']); ?></td>
                    <td><?php echo $st['obtained']; ?></td>
                    <td><?php echo $st['full']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="summary-bar">
            <span><strong>Grand Total:</strong> <?php echo $combined_result['total']; ?> / <?php echo $combined_result['full']; ?></span>
            <span><strong>Percentage:</strong> <?php echo $combined_result['percentage']; ?>%</span>
            <span><strong>Subjects Failed:</strong> <?php echo $combined_result['failed']; ?></span>
        </div>
    </div>
    <?php endif; ?>

    <?php foreach($hs_exams_list as $exam):
        $hs_status_class = ($exam['status'] === 'PASS') ? 'status-pass' : 'status-fail';
    ?>
    <div class="exam-block">
        <div class="exam-title">
            <span><i class="fas fa-university"></i> <?php echo htmlspecialchars($exam['exam_name']); ?> (<?php echo htmlspecialchars($exam['academic_year']); ?>)</span>
            <span class="status-badge <?php echo $hs_status_class; ?>"><?php echo htmlspecialchars($exam['status']); ?></span>
        </div>
        <table class="result-table">
            <thead><tr><th>Subject</th><th>Sem 1</th><th>Sem 2</th><th>Practical</th><th>Total</th><th>Grade</th></tr></thead>
            <tbody>
                <?php foreach($exam['subjects'] as $sub):
                    $sem1_disp = $sub['sem1_absent'] ? 'AB' : ($sub['sem1_supplementary_marks'] ?? $sub['sem1_marks']);
                    $sem2_disp = $sub['sem2_absent'] ? 'AB' : ($sub['sem2_supplementary_marks'] ?? $sub['sem2_marks']);
                    $prac_disp = $sub['practical_absent'] ? 'AB' : $sub['practical_marks'];
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($sub['subject_name']); ?></td>
                    <td><?php echo $sem1_disp ?? '-'; ?></td>
                    <td><?php echo $sem2_disp ?? '-'; ?></td>
                    <td><?php echo $prac_disp ?? '-'; ?></td>
                    <td><strong><?php echo $sub['total_marks'] ?? '-'; ?></strong></td>
                    <td><?php echo htmlspecialchars($sub['subject_grade'] ?? '-'); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="summary-bar">
            <span><strong>Result:</strong> <?php echo htmlspecialchars($exam['status']); ?></span>
            <span><strong>Subjects Failed:</strong> <?php echo $exam['failed']; ?></span>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="disclaimer-box">
        <i class="fas fa-info-circle"></i>
        This is a computer generated result. marks-এ কোনো ভুল/গরমিল মনে হলে school-এর সাথে যোগাযোগ করুন।
    </div>
</div>

<?php endif; ?>
<?php endif; ?>

</body>
</html>

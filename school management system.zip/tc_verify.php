<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
// ===== PUBLIC page — anyone who scans the QR on a Transfer Certificate lands here. No login. =====
// It confirms only what the certificate itself shows; no address, Aadhaar or family data.
include("includes/db.php");
require_once __DIR__ . '/includes/card_document_helper.php';

$token = (string)($_GET['token'] ?? '');
$tc = null;
if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $tc = db_get_row("
        SELECT t.tc_no, t.tc_date, t.status, t.cancelled_at, s.id AS uid, s.student_name, s.photo,
               c.class_name, a.session_name
        FROM tc_students t
        JOIN students s ON s.id = t.student_id
        LEFT JOIN student_academic_history h ON h.id = (SELECT h2.id FROM student_academic_history h2 WHERE h2.student_id = s.id ORDER BY h2.id DESC LIMIT 1)
        LEFT JOIN classes c ON c.id = h.class_id
        LEFT JOIN academic_sessions a ON a.id = h.session_id
        WHERE t.verification_token = ? LIMIT 1", 's', $token);
}
$school = document_get_school_settings($conn, 'verify_basic');
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$state = !$tc ? 'invalid' : ($tc['status'] === 'Cancelled' ? 'cancelled' : 'valid');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transfer Certificate Verification</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: Arial, sans-serif; background: linear-gradient(135deg, #f0f4f8, #dbe7f0); min-height: 100vh; margin: 0; display: flex; align-items: center; justify-content: center; padding: 20px; }
.card { background: #fff; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.1); max-width: 480px; width: 100%; padding: 30px; text-align: center; }
.card img.logo { height: 60px; margin-bottom: 10px; }
.card h2 { color: #003366; margin: 5px 0 20px; font-size: 18px; }
.icon { font-size: 55px; margin-bottom: 10px; }
.valid { color: #198754; } .invalid, .cancelled { color: #dc3545; }
.title { font-size: 20px; font-weight: 700; margin-bottom: 20px; }
.row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; font-size: 14px; text-align: left; gap: 12px; }
.row span:first-child { color: #6c7a8a; } .row span:last-child { font-weight: 600; color: #1a3b55; text-align: right; }
.uid { display: inline-block; background: #003366; color: #fff; font-weight: 700; padding: 2px 12px; border-radius: 999px; font-size: 13px; }
.photo { width: 90px; height: 108px; object-fit: cover; border-radius: 8px; border: 1px solid #cfd8e1; margin: 0 auto 12px; display: block; }
.note { font-size: 12px; color: #6c7a8a; margin-top: 18px; }
</style>
</head>
<body>
<div class="card">
    <?php if (!empty($school['logo'])): ?><img class="logo" src="uploads/<?php echo rawurlencode($school['logo']); ?>" alt=""><?php endif; ?>
    <h2><?php echo h($school['school_name'] ?? 'School'); ?></h2>

    <?php if ($state === 'invalid'): ?>
        <div class="icon invalid"><i class="fas fa-times-circle"></i></div>
        <div class="title invalid">Not a valid Transfer Certificate</div>
        <p>No Transfer Certificate issued by this school matches this code. Please contact the school office.</p>
    <?php else: ?>
        <?php if ($state === 'cancelled'): ?>
        <div class="icon cancelled"><i class="fas fa-ban"></i></div>
        <div class="title cancelled">This Transfer Certificate was CANCELLED<br><small style="font-size:13px;font-weight:400">on <?php echo date('d-m-Y', strtotime($tc['cancelled_at'])); ?> — the student continues in this school</small></div>
        <?php else: ?>
        <div class="icon valid"><i class="fas fa-check-circle"></i></div>
        <div class="title valid">Genuine Transfer Certificate</div>
        <?php endif; ?>
        <?php if ($tc['photo']): ?><img class="photo" src="uploads/students/<?php echo rawurlencode($tc['photo']); ?>" alt=""><?php endif; ?>
        <div class="row"><span>TC No</span><span><?php echo h($tc['tc_no']); ?></span></div>
        <div class="row"><span>Date of issue</span><span><?php echo $tc['tc_date'] ? date('d-m-Y', strtotime($tc['tc_date'])) : '—'; ?></span></div>
        <div class="row"><span>Student</span><span><?php echo h($tc['student_name']); ?></span></div>
        <div class="row"><span>Student ID</span><span class="uid"><?php echo h($tc['uid']); ?></span></div>
        <div class="row"><span>Class at leaving</span><span><?php echo h($tc['class_name'] ? 'Class ' . $tc['class_name'] . ' · ' . $tc['session_name'] : '—'); ?></span></div>
        <div class="row"><span>Status</span><span class="<?php echo $state; ?>"><?php echo $state === 'valid' ? 'ISSUED' : 'CANCELLED'; ?></span></div>
    <?php endif; ?>
    <div class="note"><i class="fas fa-shield-alt"></i> Verified against the school's records on <?php echo date('d-m-Y H:i'); ?>. Only the details printed on the certificate are shown here.</div>
</div>
</body>
</html>

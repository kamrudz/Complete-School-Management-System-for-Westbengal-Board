<?php
/** Teacher portal authentication helper. */
require_once __DIR__ . '/../includes/auth.php';

const SCHOOLMS_TEACHER_SESSION_TIMEOUT = 7200;

function teacher_login_url(): string { return 'login.php'; }

if (!empty($_SESSION['teacher_login'])) {
    $last = (int)($_SESSION['teacher_last_activity'] ?? 0);
    if ($last && (time() - $last) > SCHOOLMS_TEACHER_SESSION_TIMEOUT) {
        schoolms_destroy_session();
        header('Location: ' . teacher_login_url() . '?timeout=1');
        exit;
    }
    $_SESSION['teacher_last_activity'] = time();
}

function require_teacher_login(): void {
    if (empty($_SESSION['teacher_login']) || $_SESSION['teacher_login'] !== true) {
        header('Location: ' . teacher_login_url()); exit;
    }
    // a password the office set with "must change" has to be replaced before the portal opens
    if (!empty($_SESSION['teacher_pw_must_change']) && basename($_SERVER['SCRIPT_NAME']) !== 'change_password.php' && basename($_SERVER['SCRIPT_NAME']) !== 'logout.php') {
        header('Location: change_password.php?first=1'); exit;
    }
}

function teacher_secure_login(array $staff): void {
    session_regenerate_id(true);
    $_SESSION['teacher_login'] = true;
    $_SESSION['teacher_id'] = (int)$staff['id'];
    $_SESSION['teacher_name'] = (string)($staff['staff_name'] ?? '');
    $_SESSION['teacher_short_code'] = (string)($staff['short_code'] ?? '');
    $_SESSION['teacher_designation'] = (string)($staff['designation'] ?? '');
    $_SESSION['teacher_subject'] = (string)($staff['subject_name'] ?? '');
    $_SESSION['teacher_photo'] = (string)($staff['photo'] ?? '');
    $_SESSION['teacher_employee_id'] = (string)($staff['employee_id'] ?? '');
    $_SESSION['teacher_last_activity'] = time();
    $_SESSION['teacher_login_time'] = time();
    $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? '';
    $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
}

function teacher_logout(): void { schoolms_destroy_session(); }

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/logger.php';

/**
 * Teacher changes their own portal password. Reached from the profile menu, or forced right
 * after login when the office set a temporary password (?first=1).
 */
$tid = (int)($_SESSION['teacher_id'] ?? 0);
$staff = staff_get_login_record($tid);
if (!$staff) { teacher_logout(); header('Location: login.php'); exit(); }
$first = !empty($_SESSION['teacher_pw_must_change']);
$error = ''; $done = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $cur = (string)($_POST['current_password'] ?? ''); $new = (string)($_POST['new_password'] ?? ''); $conf = (string)($_POST['confirm_password'] ?? '');
    if (!password_verify($cur, (string)$staff['login_password'])) $error = 'The current password is wrong.';
    elseif (strlen($new) < 8) $error = 'The new password must be at least 8 characters.';
    elseif (!preg_match('/[A-Za-z]/', $new) || !preg_match('/[0-9]/', $new)) $error = 'Use at least one letter and one digit.';
    elseif (strcasecmp($new, $staff['employee_id']) === 0 || strcasecmp($new, (string)$staff['state_govt_id']) === 0) $error = 'The password cannot be your ID.';
    elseif (staff_default_password($staff['date_of_birth']) !== null && $new === staff_default_password($staff['date_of_birth'])) $error = 'That is the default password — choose your own.';
    elseif ($new === $cur) $error = 'Choose a password different from the current one.';
    elseif ($new !== $conf) $error = 'The two new passwords do not match.';
    else {
        db_update('staff', ['login_password' => password_hash($new, PASSWORD_DEFAULT), 'pw_must_change' => 0, 'pw_changed_at' => date('Y-m-d H:i:s')], ['id' => $tid], 'i');
        $_SESSION['teacher_pw_must_change'] = false;
        log_action(0, 'TEACHER_PASSWORD_CHANGED', 'staff', (string)$tid, null, "{$staff['staff_name']} ({$staff['employee_id']}) changed own portal password");
        $done = true;
    }
}
$school = db_get_row('SELECT school_name, logo FROM school_settings LIMIT 1') ?: [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Change password — Teacher portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{min-height:100vh;background:linear-gradient(135deg,#0f1a2e 0%,#1a3a5c 50%,#0f2a45 100%);display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',Arial,sans-serif;padding:20px}
.card{background:#fff;border-radius:16px;padding:30px 28px;box-shadow:0 25px 60px rgba(0,0,0,.35);width:100%;max-width:440px}
.card h2{font-size:20px;color:#0f1a2e;display:flex;align-items:center;gap:10px;margin-bottom:4px}.card h2 i{color:#1f5b8a}
.sub{font-size:13px;color:#6c7a8a;margin-bottom:18px}
.who{background:#f5f9fc;border:1px solid #e1eaf2;border-radius:10px;padding:10px 12px;font-size:13px;margin-bottom:16px}.who b{display:block;font-size:14px;color:#0f1a2e}
.alert{padding:11px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:16px;display:flex;gap:8px;align-items:flex-start}
.alert-danger{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}.alert-warning{background:#fffbeb;color:#92400e;border:1px solid #fde68a}.alert-success{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}
.fg{margin-bottom:14px}.fg label{font-size:13px;font-weight:700;color:#1a2d4a;margin-bottom:6px;display:block}
.fg input{width:100%;padding:11px 12px;border:1.5px solid #d0dbe8;border-radius:8px;font-size:14px}.fg input:focus{outline:none;border-color:#1f5b8a;box-shadow:0 0 0 3px rgba(31,91,138,.1)}
.rules{font-size:12px;color:#6c7a8a;margin:-6px 0 14px}
.btn{width:100%;padding:12px;border:none;border-radius:9px;background:#1f5b8a;color:#fff;font-weight:700;font-size:15px;cursor:pointer}.btn:hover{background:#174a72}
.links{text-align:center;margin-top:14px;font-size:13px}.links a{color:#1f5b8a;text-decoration:none;font-weight:600}
</style>
</head>
<body>
<div class="card">
    <h2><i class="fas fa-key"></i> <?php echo $first ? 'Set your own password' : 'Change password'; ?></h2>
    <div class="sub"><?php echo htmlspecialchars($school['school_name'] ?? ''); ?> · Teacher portal</div>
    <div class="who"><b><?php echo htmlspecialchars($staff['staff_name']); ?></b><?php echo htmlspecialchars($staff['designation'] ?? ''); ?> · <?php echo htmlspecialchars($staff['employee_id']); ?></div>
    <?php if ($done): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> Password changed. Use the new one from your next login.</div>
    <div class="links"><a href="dashboard.php"><i class="fas fa-arrow-right"></i> Go to the dashboard</a></div>
    <?php else: ?>
    <?php if ($first): ?><div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> The office gave you a temporary password. Choose your own before continuing.</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="fg"><label>Current (temporary) password</label><input type="password" name="current_password" required autocomplete="current-password" autofocus></div>
        <div class="fg"><label>New password</label><input type="password" name="new_password" required minlength="8" autocomplete="new-password"></div>
        <div class="rules">At least 8 characters with a letter and a digit; not your ID or the default password.</div>
        <div class="fg"><label>New password again</label><input type="password" name="confirm_password" required minlength="8" autocomplete="new-password"></div>
        <button type="submit" class="btn"><i class="fas fa-save"></i> Save password</button>
    </form>
    <div class="links"><?php if (!$first): ?><a href="profile.php">Back to profile</a> · <?php endif; ?><a href="logout.php">Log out</a></div>
    <?php endif; ?>
</div>
</body>
</html>

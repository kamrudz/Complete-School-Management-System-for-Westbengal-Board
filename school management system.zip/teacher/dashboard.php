<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");

$tid   = (int)$_SESSION['teacher_id'];
$today = date('Y-m-d');
$day   = date('l'); // Monday etc.

// Active session
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active_session['id'] ?? 0);

// School info
$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT school_name, logo FROM school_settings LIMIT 1"));

// Today's classes from routine
$today_classes = [];
if($session_id > 0) {
    $q = mysqli_query($conn, "
        SELECT cr.*, c.class_name, s.section_name, sub.subject_name, p.period_name, p.start_time, p.end_time
        FROM routine cr
        JOIN classes c ON cr.class_id = c.id
        LEFT JOIN sections s ON cr.section_id = s.id
        LEFT JOIN subjects sub ON cr.subject_id = sub.id
        LEFT JOIN periods p ON cr.period_id = p.id
        WHERE cr.teacher_id = '$tid' AND cr.session_id = '$session_id' AND cr.day_name = '$day'
        ORDER BY p.start_time ASC
    ");
    while($r = mysqli_fetch_assoc($q)) $today_classes[] = $r;
}

// Today's attendance status — count records saved today for this teacher's classes
$att_done = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) AS c FROM student_attendance sa
     JOIN routine r ON sa.class_id=r.class_id AND sa.session_id=r.session_id
     WHERE r.teacher_id='$tid' AND sa.attendance_date='$today' AND sa.session_id='$session_id'"
));
$att_done_count = (int)($att_done['c'] ?? 0);

// Total students in my assigned classes
$my_classes = mysqli_query($conn, "
    SELECT DISTINCT cr.class_id, cr.section_id, c.class_name, s.section_name
    FROM routine cr
    JOIN classes c ON cr.class_id = c.id
    LEFT JOIN sections s ON cr.section_id = s.id
    WHERE cr.teacher_id = '$tid' AND cr.session_id = '$session_id'
");
$class_list = [];
while($r = mysqli_fetch_assoc($my_classes)) $class_list[] = $r;

$total_my_students = 0;
if(!empty($class_list)) {
    foreach($class_list as $cl) {
        $cid = (int)$cl['class_id'];
        $sid_c = (int)($cl['section_id'] ?? 0);
        $sec_cond = $sid_c > 0 ? "AND sah.section_id='$sid_c'" : '';
        $cnt = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT COUNT(DISTINCT s.id) AS c FROM students s
             JOIN student_academic_history sah ON s.id=sah.student_id
             WHERE sah.session_id='$session_id' AND sah.class_id='$cid' $sec_cond
               AND sah.academic_status='Current' AND s.student_status='Active'"
        ));
        $total_my_students += (int)($cnt['c'] ?? 0);
    }
    $total_my_students = (int)(mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COUNT(DISTINCT s.id) AS c FROM students s
         JOIN student_academic_history sah ON s.id=sah.student_id
         JOIN routine cr ON cr.class_id=sah.class_id AND cr.session_id=sah.session_id
         WHERE cr.teacher_id='$tid' AND cr.session_id='$session_id'
           AND sah.academic_status='Current' AND s.student_status='Active'"
    ))['c'] ?? 0);
}

// Unread notices (last 5)
$notices = mysqli_query($conn, "SELECT * FROM notices ORDER BY id DESC LIMIT 5");

// Today's provisional duties
$provisional = mysqli_query($conn, "
    SELECT pr.*, c.class_name, s.section_name, sub.subject_name, p.period_name, p.start_time
    FROM provisional_routine pr
    JOIN classes c ON pr.class_id = c.id
    LEFT JOIN sections s ON pr.section_id = s.id
    LEFT JOIN subjects sub ON pr.provisional_subject_id = sub.id
    LEFT JOIN periods p ON pr.period_id = p.id
    WHERE pr.provisional_teacher_id = '$tid' AND pr.provisional_date = '$today' AND pr.status = 'assigned'
    ORDER BY p.start_time ASC
");
$prov_rows = [];
while($r = mysqli_fetch_assoc($provisional)) $prov_rows[] = $r;

// My total classes this week
$week_count = (int)(mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) AS c FROM routine WHERE teacher_id='$tid' AND session_id='$session_id'"
))['c'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Teacher Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:20px;}
.stat-card{background:#fff;border-radius:10px;padding:16px 18px;border:1px solid #e5e7eb;box-shadow:0 2px 8px rgba(0,0,0,.04);position:relative;overflow:hidden;transition:transform .2s;}
.stat-card:hover{transform:translateY(-3px);box-shadow:0 6px 20px rgba(0,0,0,.08);}
.stat-card::after{content:'';position:absolute;top:0;left:0;right:0;height:3px;}
.stat-card.blue::after{background:#3b82f6;} .stat-card.green::after{background:#22c55e;} .stat-card.orange::after{background:#f59e0b;} .stat-card.purple::after{background:#8b5cf6;} .stat-card.red::after{background:#ef4444;}
.stat-card .icon{font-size:26px;margin-bottom:6px;display:inline-block;padding:8px;border-radius:8px;background:rgba(31,91,138,.07);}
.stat-card .num{font-size:28px;font-weight:800;color:#0f1a2e;line-height:1.1;}
.stat-card .lbl{font-size:12px;color:#6c7a8a;font-weight:500;margin-top:3px;}
.two-col{display:grid;grid-template-columns:2fr 1fr;gap:16px;margin-bottom:18px;}
.widget{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.04);}
.widget-head{padding:10px 16px;border-bottom:1px solid #f0f2f5;background:#fafbfc;display:flex;justify-content:space-between;align-items:center;}
.widget-head h4{font-size:14px;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:6px;}
.widget-head h4 i{color:#1f5b8a;}
.widget-head a{font-size:12px;color:#1f5b8a;text-decoration:none;font-weight:600;}
.widget-body{padding:12px 14px;}
.class-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f2f5;}
.class-item:last-child{border-bottom:none;}
.class-badge{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;white-space:nowrap;}
.class-info .name{font-size:13px;font-weight:600;color:#0f1a2e;}
.class-info .sub{font-size:11px;color:#6c7a8a;margin-top:1px;}
.time-badge{font-size:11px;color:#6c7a8a;margin-left:auto;white-space:nowrap;}
.notice-item{padding:8px 0;border-bottom:1px solid #f0f2f5;}
.notice-item:last-child{border-bottom:none;}
.notice-item .ntitle{font-size:13px;font-weight:600;color:#0f1a2e;}
.notice-item .nmeta{font-size:11px;color:#6c7a8a;margin-top:2px;}
.empty-msg{text-align:center;padding:20px;color:#6c7a8a;font-size:13px;}
.empty-msg i{font-size:28px;opacity:.3;display:block;margin-bottom:6px;}
.welcome-bar{background:linear-gradient(135deg,#1f5b8a,#003366);color:#fff;border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
.welcome-bar .greeting h2{font-size:18px;font-weight:800;display:flex;align-items:center;gap:8px;}
.welcome-bar .greeting p{font-size:13px;opacity:.75;margin-top:3px;}
.welcome-bar .date-box{text-align:right;font-size:13px;opacity:.8;}
.welcome-bar .date-box .time{font-size:22px;font-weight:800;opacity:1;}
.prov-item{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid #f0f2f5;}
.prov-item:last-child{border-bottom:none;}
.prov-badge{background:#fff3cd;color:#856404;font-size:11px;font-weight:700;padding:2px 8px;border-radius:12px;}
.att-done{background:#dcfce7;color:#166534;border:1px solid #bbf7d0;border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;margin-bottom:10px;}
.att-pending{background:#fef3c7;color:#92400e;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px;margin-bottom:10px;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;font-weight:700;font-size:13px;text-decoration:none;transition:.2s;}
.btn-primary{background:#1f5b8a;color:#fff;} .btn-primary:hover{background:#003366;}
.btn-success{background:#22c55e;color:#fff;} .btn-success:hover{background:#16a34a;}
@media(max-width:900px){.two-col{grid-template-columns:1fr;}}
@media(max-width:600px){.stats-grid{grid-template-columns:1fr 1fr;} .welcome-bar{flex-direction:column;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>

<?php if (isset($_GET['msg']) && $_GET['msg'] === 'access_denied'): ?>
    <div style="background:#fef3c7;color:#92400e;padding:11px 16px;border-radius:8px;margin-bottom:16px;font-weight:600;display:flex;align-items:center;gap:8px;">
        <i class="fas fa-exclamation-triangle"></i> Access denied — ei section apnar jonno bodho hoyeche.
    </div>
<?php endif; ?>

<!-- Welcome Bar -->
<div class="welcome-bar">
    <div class="greeting">
        <h2>
            <?php if(!empty($_SESSION['teacher_photo'])): ?>
                <img src="../uploads/staff/<?php echo htmlspecialchars($_SESSION['teacher_photo']); ?>" style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.3);">
            <?php else: ?>
                <i class="fas fa-user-circle" style="font-size:32px;opacity:.8;"></i>
            <?php endif; ?>
            Welcome, <?php echo htmlspecialchars($_SESSION['teacher_name'] ?? 'Teacher'); ?>!
        </h2>
        <p>
            <i class="fas fa-id-badge"></i> <?php echo htmlspecialchars($_SESSION['teacher_employee_id'] ?? ''); ?>
            &nbsp;·&nbsp;
            <i class="fas fa-briefcase"></i> <?php echo htmlspecialchars($_SESSION['teacher_designation'] ?? ''); ?>
            &nbsp;·&nbsp;
            <i class="fas fa-book"></i> <?php echo htmlspecialchars($_SESSION['teacher_subject'] ?? ''); ?>
        </p>
    </div>
    <div class="date-box">
        <div><?php echo date('d M Y'); ?></div>
        <div class="time" id="liveTime"><?php echo date('h:i A'); ?></div>
        <div><?php echo $day; ?></div>
    </div>
</div>

<!-- Stats -->
<div class="stats-grid">
    <div class="stat-card blue">
        <div class="icon"><i class="fas fa-calendar-day" style="color:#3b82f6;"></i></div>
        <div class="num"><?php echo count($today_classes); ?></div>
        <div class="lbl">Classes Today</div>
    </div>
    <div class="stat-card green">
        <div class="icon"><i class="fas fa-user-graduate" style="color:#22c55e;"></i></div>
        <div class="num"><?php echo $total_my_students; ?></div>
        <div class="lbl">My Students</div>
    </div>
    <div class="stat-card purple">
        <div class="icon"><i class="fas fa-table" style="color:#8b5cf6;"></i></div>
        <div class="num"><?php echo $week_count; ?></div>
        <div class="lbl">Periods/Week</div>
    </div>
    <div class="stat-card orange">
        <div class="icon"><i class="fas fa-clipboard-check" style="color:#f59e0b;"></i></div>
        <div class="num"><?php echo $att_done_count; ?></div>
        <div class="lbl">Attendance Marked Today</div>
    </div>
    <div class="stat-card red">
        <div class="icon"><i class="fas fa-exchange-alt" style="color:#ef4444;"></i></div>
        <div class="num"><?php echo count($prov_rows); ?></div>
        <div class="lbl">Substitute Today</div>
    </div>
</div>

<!-- Main Widgets -->
<div class="two-col">

    <!-- Today's Schedule -->
    <div class="widget">
        <div class="widget-head">
            <h4><i class="fas fa-clock"></i> Today's Schedule (<?php echo $day; ?>)</h4>
            <a href="my_routine.php">Full Routine →</a>
        </div>
        <div class="widget-body">
            <?php if(empty($today_classes) && empty($prov_rows)): ?>
                <div class="empty-msg"><i class="fas fa-coffee"></i> No classes scheduled today</div>
            <?php else: ?>
                <?php foreach($today_classes as $cl): ?>
                <div class="class-item">
                    <span class="class-badge"><?php echo htmlspecialchars($cl['class_name'].($cl['section_name']?' - '.$cl['section_name']:'')); ?></span>
                    <div class="class-info">
                        <div class="name"><?php echo htmlspecialchars($cl['subject_name'] ?? '-'); ?></div>
                        <div class="sub"><?php echo htmlspecialchars($cl['period_name'] ?? ''); ?></div>
                    </div>
                    <span class="time-badge"><?php echo $cl['start_time'] ? date('h:i A', strtotime($cl['start_time'])) : ''; ?><?php echo $cl['end_time'] ? ' – '.date('h:i A', strtotime($cl['end_time'])) : ''; ?></span>
                </div>
                <?php endforeach; ?>
                <?php foreach($prov_rows as $pr): ?>
                <div class="prov-item">
                    <span class="prov-badge">SUB</span>
                    <div class="class-info">
                        <div class="name"><?php echo htmlspecialchars($pr['class_name'].($pr['section_name']?' - '.$pr['section_name']:'')); ?> — <?php echo htmlspecialchars($pr['subject_name'] ?? ''); ?></div>
                        <div class="sub">Provisional substitute</div>
                    </div>
                    <span class="time-badge"><?php echo $pr['start_time'] ? date('h:i A', strtotime($pr['start_time'])) : ''; ?></span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Notices + Attendance Quick -->
    <div style="display:flex;flex-direction:column;gap:16px;">

        <!-- Attendance Quick Action -->
        <div class="widget">
            <div class="widget-head">
                <h4><i class="fas fa-clipboard-check"></i> Today's Attendance</h4>
            </div>
            <div class="widget-body">
                <?php if($att_done_count > 0): ?>
                    <div class="att-done"><i class="fas fa-check-circle"></i> <?php echo $att_done_count; ?> attendance record(s) marked today</div>
                <?php else: ?>
                    <div class="att-pending"><i class="fas fa-exclamation-circle"></i> No attendance marked today</div>
                <?php endif; ?>
                <a href="my_attendance.php" class="btn btn-success" style="width:100%;justify-content:center;">
                    <i class="fas fa-clipboard-check"></i> Mark / View Attendance
                </a>
            </div>
        </div>

        <!-- Notices -->
        <div class="widget">
            <div class="widget-head">
                <h4><i class="fas fa-bullhorn"></i> Recent Notices</h4>
                <a href="notices.php">All →</a>
            </div>
            <div class="widget-body">
                <?php $notice_count = 0; mysqli_data_seek($notices, 0); while($n = mysqli_fetch_assoc($notices)): $notice_count++; ?>
                <div class="notice-item">
                    <div class="ntitle"><?php echo htmlspecialchars($n['notice_title'] ?? $n['title'] ?? 'Notice'); ?></div>
                    <div class="nmeta"><?php echo htmlspecialchars($n['notice_date'] ?? $n['created_at'] ?? ''); ?></div>
                </div>
                <?php endwhile; ?>
                <?php if($notice_count == 0): ?>
                    <div class="empty-msg"><i class="fas fa-bell-slash"></i> No notices</div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<script>
setInterval(function(){
    var now = new Date();
    var h = now.getHours()%12||12;
    var m = now.getMinutes().toString().padStart(2,'0');
    var ampm = now.getHours()>=12?'PM':'AM';
    document.getElementById('liveTime').textContent = h+':'+m+' '+ampm;
}, 1000);
</script>
</body>
</html>

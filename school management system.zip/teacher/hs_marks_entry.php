<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/section_groups.php';
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_hs_marks')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$tid = (int)$_SESSION['teacher_id'];

// Active session
$active_session = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"
));
$session_id = (int)($active_session['id'] ?? 0);

// Routine mode
$routine_mode = get_routine_mode($conn);

// ============================================================
// SAVE MARKS (POST)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marks'])) {
    verify_csrf_or_die();

    $hs_exam_id  = (int)$_POST['hs_exam_id'];
    $subject_id  = (int)$_POST['subject_id'];
    $component   = in_array($_POST['component'] ?? '', ['sem1','sem2','practical'])
                   ? $_POST['component'] : 'sem1';
    $sem1_pass   = (float)($_POST['sem1_pass_marks'] ?? 12);
    $sem2_pass   = (float)($_POST['sem2_pass_marks'] ?? 12);
    $student_ids = $_POST['student_id'] ?? [];

    // Absent lists from POST
    $absent_sem1 = array_map('intval', $_POST['absent_sem1'] ?? []);
    $absent_sem2 = array_map('intval', $_POST['absent_sem2'] ?? []);
    $absent_prac = array_map('intval', $_POST['absent_prac'] ?? []);

    // Load existing marks to preserve untouched columns
    $existing = [];
    if (!empty($student_ids)) {
        $id_list = implode(',', array_map(fn($v) => "'" . $v . "'", array_filter(array_map('student_uid_clean', $student_ids))));
        $eres = mysqli_query($conn,
            "SELECT student_id, sem1_marks, sem1_supplementary_marks, sem1_absent,
                    sem2_marks, sem2_supplementary_marks, sem2_absent,
                    practical_marks, practical_absent
             FROM hs_marks
             WHERE hs_exam_id=$hs_exam_id AND subject_id=$subject_id AND student_id IN ($id_list)"
        );
        while ($er = mysqli_fetch_assoc($eres)) $existing[$er['student_id']] = $er;
    }

    foreach ($student_ids as $sid) {
        $sid = student_uid_clean($sid);
        if ($sid === '') continue;
        $old = $existing[$sid] ?? null;

        if ($component === 'sem1') {
            $s1_abs    = in_array($sid, $absent_sem1) ? 1 : 0;
            $sem1      = $s1_abs ? null : (isset($_POST['sem1'][$sid]) && $_POST['sem1'][$sid] !== '' ? (float)$_POST['sem1'][$sid] : null);
            $sem1_supp = (!$s1_abs && $sem1 !== null && $sem1 >= $sem1_pass) ? null
                         : (isset($_POST['sem1_supp'][$sid]) && $_POST['sem1_supp'][$sid] !== '' ? (float)$_POST['sem1_supp'][$sid] : null);
            $sem2      = $old['sem2_marks'] ?? null;
            $sem2_supp = $old['sem2_supplementary_marks'] ?? null;
            $prac      = $old['practical_marks'] ?? null;
            $s2_abs    = (int)($old['sem2_absent']     ?? 0);
            $pr_abs    = (int)($old['practical_absent'] ?? 0);
        } elseif ($component === 'sem2') {
            $s2_abs    = in_array($sid, $absent_sem2) ? 1 : 0;
            $sem1      = $old['sem1_marks'] ?? null;
            $sem1_supp = $old['sem1_supplementary_marks'] ?? null;
            $sem2      = $s2_abs ? null : (isset($_POST['sem2'][$sid]) && $_POST['sem2'][$sid] !== '' ? (float)$_POST['sem2'][$sid] : null);
            $sem2_supp = (!$s2_abs && $sem2 !== null && $sem2 >= $sem2_pass) ? null
                         : (isset($_POST['sem2_supp'][$sid]) && $_POST['sem2_supp'][$sid] !== '' ? (float)$_POST['sem2_supp'][$sid] : null);
            $prac      = $old['practical_marks'] ?? null;
            $s1_abs    = (int)($old['sem1_absent']     ?? 0);
            $pr_abs    = (int)($old['practical_absent'] ?? 0);
        } else { // practical
            $pr_abs    = in_array($sid, $absent_prac) ? 1 : 0;
            $sem1      = $old['sem1_marks'] ?? null;
            $sem1_supp = $old['sem1_supplementary_marks'] ?? null;
            $sem2      = $old['sem2_marks'] ?? null;
            $sem2_supp = $old['sem2_supplementary_marks'] ?? null;
            $prac      = $pr_abs ? null : (isset($_POST['practical'][$sid]) && $_POST['practical'][$sid] !== '' ? (float)$_POST['practical'][$sid] : null);
            $s1_abs    = (int)($old['sem1_absent']  ?? 0);
            $s2_abs    = (int)($old['sem2_absent']  ?? 0);
        }

        if ($old !== null) {
            $stmt = mysqli_prepare($conn,
                "UPDATE hs_marks SET
                 sem1_marks=?, sem1_supplementary_marks=?, sem1_absent=?,
                 sem2_marks=?, sem2_supplementary_marks=?, sem2_absent=?,
                 practical_marks=?, practical_absent=?
                 WHERE hs_exam_id=? AND student_id=? AND subject_id=?"
            );
            $stmt->bind_param("ddiddiidiii",
                $sem1, $sem1_supp, $s1_abs,
                $sem2, $sem2_supp, $s2_abs,
                $prac, $pr_abs,
                $hs_exam_id, $sid, $subject_id);
        } else {
            $stmt = mysqli_prepare($conn,
                "INSERT INTO hs_marks
                 (hs_exam_id,student_id,subject_id,
                  sem1_marks,sem1_supplementary_marks,sem1_absent,
                  sem2_marks,sem2_supplementary_marks,sem2_absent,
                  practical_marks,practical_absent)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->bind_param("iiiddiddidi",
                $hs_exam_id, $sid, $subject_id,
                $sem1, $sem1_supp, $s1_abs,
                $sem2, $sem2_supp, $s2_abs,
                $prac, $pr_abs);
        }
        $stmt->execute();
    }

    $_SESSION['success'] = "✅ Marks saved successfully!";
    $redir_sec = (int)$_POST['section_id'];
    $redir_cls = (int)$_POST['class_id'];
    header("Location: hs_marks_entry.php?class_id=$redir_cls&section_id=$redir_sec&hs_exam_id=$hs_exam_id&subject_id=$subject_id&component=".urlencode($component));
    exit();
}

// ============================================================
// FILTERS
// ============================================================
$sel_class   = isset($_GET['class_id'])   ? (int)$_GET['class_id']   : 0;
$sel_section = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$sel_exam    = isset($_GET['hs_exam_id']) ? (int)$_GET['hs_exam_id'] : 0;
$sel_subject = isset($_GET['subject_id']) ? (int)$_GET['subject_id'] : 0;
$component   = in_array($_GET['component'] ?? '', ['sem1','sem2','practical'])
               ? $_GET['component'] : 'sem1';

// HS Classes (XI, XII)
$hs_classes_q = mysqli_query($conn, "SELECT * FROM classes WHERE class_name IN ('XI','XII') ORDER BY id ASC");
$hs_classes = [];
while ($r = mysqli_fetch_assoc($hs_classes_q)) $hs_classes[] = $r;

// Sections for selected class
// group_wise mode-এ teacher-এর routine-এ যে sections আছে + paired sections
$sections = [];
if ($sel_class > 0 && $session_id > 0) {
    if ($routine_mode === 'group_wise') {
        // Teacher-এর routine থেকে HS classes-এর sections
        $tsec_q = mysqli_query($conn, "
            SELECT DISTINCT r.section_id FROM routine r
            WHERE r.teacher_id='$tid' AND r.session_id='$session_id' AND r.class_id='$sel_class'
        ");
        $teacher_sections = [];
        while ($tr = mysqli_fetch_assoc($tsec_q)) $teacher_sections[] = (int)$tr['section_id'];

        // Add paired sections
        $all_visible_sec_ids = [];
        foreach ($teacher_sections as $tsid) {
            $paired = get_paired_section_ids($conn, $session_id, $sel_class, $tsid);
            foreach ($paired as $psid) $all_visible_sec_ids[] = $psid;
        }
        $all_visible_sec_ids = array_unique($all_visible_sec_ids);

        if (!empty($all_visible_sec_ids)) {
            $vis_in = implode(',', $all_visible_sec_ids);
            $sq = mysqli_query($conn, "SELECT id, section_name FROM sections
                  WHERE id IN ($vis_in) ORDER BY section_name");
        } else {
            $sq = mysqli_query($conn, "SELECT id, section_name FROM sections
                  WHERE session_id='$session_id' AND class_id='$sel_class' ORDER BY section_name");
        }
    } else {
        $sq = mysqli_query($conn, "SELECT id, section_name FROM sections
              WHERE session_id='$session_id' AND class_id='$sel_class' ORDER BY section_name");
    }
    while ($r = mysqli_fetch_assoc($sq)) $sections[] = $r;
}

// HS Exams for selected class
$exams = [];
if ($sel_class > 0 && $session_id > 0) {
    $eq = mysqli_query($conn, "SELECT * FROM hs_exam
          WHERE session_id='$session_id' AND class_id='$sel_class' ORDER BY id");
    while ($r = mysqli_fetch_assoc($eq)) $exams[] = $r;
}

// Subjects from hs_exam_subject_marks
$subjects = [];
if ($sel_exam > 0) {
    $subq = mysqli_query($conn, "
        SELECT DISTINCT hesm.subject_id, s.subject_name, s.subject_code
        FROM hs_exam_subject_marks hesm
        LEFT JOIN subjects s ON hesm.subject_id = s.id
        WHERE hesm.hs_exam_id='$sel_exam'
        ORDER BY s.subject_name ASC
    ");
    while ($r = mysqli_fetch_assoc($subq)) $subjects[] = $r;
}

// Marks config for selected subject
$marks_config = null;
$sem1_pass = 12; $sem2_pass = 12;
if ($sel_exam > 0 && $sel_subject > 0) {
    $marks_config = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT * FROM hs_exam_subject_marks
         WHERE hs_exam_id='$sel_exam' AND subject_id='$sel_subject' LIMIT 1"
    ));
    if ($marks_config) {
        $sem1_pass = (float)$marks_config['sem1_pass_marks'];
        $sem2_pass = (float)$marks_config['sem2_pass_marks'];
    }
}

// Students who have selected this subject
// group_wise mode-এ paired sections-এর students একসাথে দেখাও
$students = [];
if ($sel_exam > 0 && $sel_subject > 0 && $sel_section > 0) {
    $exam_info = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT class_id, session_id FROM hs_exam WHERE id='$sel_exam'"
    ));
    if ($exam_info) {
        $sections_to_load = ($routine_mode === 'group_wise')
            ? get_paired_section_ids($conn, $session_id, $sel_class, $sel_section)
            : [$sel_section];
        $sec_in_hs = implode(',', array_map('intval', $sections_to_load));

        $stq = mysqli_query($conn, "
            SELECT s.id, s.student_name, s.banglarshiksha_id, h.roll_no, h.section_id,
                   sec.section_name,
                   hm.sem1_marks, hm.sem1_supplementary_marks, hm.sem1_absent,
                   hm.sem2_marks, hm.sem2_supplementary_marks, hm.sem2_absent,
                   hm.practical_marks, hm.practical_absent
            FROM students s
            JOIN student_academic_history h ON s.id = h.student_id
            LEFT JOIN sections sec ON h.section_id = sec.id
            LEFT JOIN hs_student_subjects hss ON hss.student_id = s.id
                AND hss.session_id = h.session_id AND hss.class_id = h.class_id
            LEFT JOIN hs_marks hm ON hm.student_id = s.id
                AND hm.hs_exam_id = '$sel_exam' AND hm.subject_id = '$sel_subject'
            WHERE h.session_id = '{$exam_info['session_id']}'
              AND h.class_id   = '{$exam_info['class_id']}'
              AND h.section_id IN ($sec_in_hs)
              AND h.academic_status = 'Current'
              AND s.student_status  = 'Active'
              AND (
                hss.compulsory_1 = '$sel_subject' OR hss.compulsory_2 = '$sel_subject' OR
                hss.main_1 = '$sel_subject' OR hss.main_2 = '$sel_subject' OR
                hss.main_3 = '$sel_subject' OR hss.additional = '$sel_subject'
              )
            ORDER BY h.section_id ASC, CAST(h.roll_no AS UNSIGNED) ASC
        ");
        while ($r = mysqli_fetch_assoc($stq)) $students[] = $r;
    }
}

// Current exam/subject names for display
$exam_name_str = '';
$sub_name_str  = '';
foreach ($exams    as $e) { if ($e['id'] == $sel_exam)    $exam_name_str = $e['exam_name']; }
foreach ($subjects as $s) { if ($s['subject_id'] == $sel_subject) $sub_name_str = $s['subject_name']; }

// group_wise: section column দেখাবে কিনা
$hs_show_section_col = ($routine_mode === 'group_wise' && count(array_unique(array_column($students, 'section_id'))) > 1);

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>HS Marks Entry — Teacher Portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.page-title .sub{font-size:13px;font-weight:400;color:#6c7a8a;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;box-shadow:0 2px 10px rgba(0,0,0,.06);padding:20px 22px;margin-bottom:18px;}
.filter-row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;min-width:140px;flex:1;}
.fg label{font-size:11px;font-weight:700;color:#1a3b55;text-transform:uppercase;letter-spacing:.3px;}
.fg select{padding:8px 10px;border:2px solid #d0dbe8;border-radius:7px;font-size:13px;background:#fff;width:100%;}
.fg select:focus{outline:none;border-color:#003366;}
/* Component tabs */
.comp-tabs{display:flex;gap:6px;margin-bottom:16px;flex-wrap:wrap;}
.comp-tab{padding:8px 20px;border-radius:20px;font-size:13px;font-weight:600;border:2px solid #d0dbe8;color:#6c7a8a;text-decoration:none;transition:.2s;}
.comp-tab:hover{border-color:#003366;color:#003366;}
.comp-tab.active{background:#003366;color:#fff;border-color:#003366;}
.comp-tab.active.sem2{background:#1a5276;border-color:#1a5276;}
.comp-tab.active.prac{background:#7c5cd8;border-color:#7c5cd8;}
/* Info bar */
.info-bar{background:linear-gradient(135deg,#e8f4ff,#f0f8ff);border:1px solid #c9e3ff;border-radius:10px;padding:10px 16px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:14px;align-items:center;font-size:13px;color:#003366;}
.info-bar strong{color:#003366;} .info-bar i{color:#1f5b8a;}
.badge-pass{padding:3px 12px;border-radius:12px;font-size:11px;font-weight:600;background:#28a745;color:#fff;}
.badge-fm{padding:3px 12px;border-radius:12px;font-size:11px;font-weight:600;background:#003366;color:#fff;}
/* Table */
.table-wrap{overflow-x:auto;border-radius:10px;border:1px solid #e5e7eb;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.05);}
table{width:100%;border-collapse:collapse;font-size:13px;}
thead{background:#003366;color:#fff;position:sticky;top:0;z-index:5;}
thead th{padding:10px 12px;text-align:center;font-size:11px;font-weight:600;white-space:nowrap;}
thead th:nth-child(3){text-align:left;}
tbody tr{border-bottom:1px solid #f0f2f5;transition:background .15s;}
tbody tr:hover{background:#f8faff;}
tbody tr.absent-row{background:#fff5f5 !important;}
tbody td{padding:8px 10px;vertical-align:middle;text-align:center;}
tbody td:nth-child(3){text-align:left;}
.roll-cell{font-weight:700;color:#003366;font-size:14px;}
.name-cell{font-weight:600;color:#1a3b55;}
.bsid-cell{font-size:11px;color:#6c7a8a;}
.mark-input{width:75px;padding:6px 8px;border:2px solid #d0dbe8;border-radius:6px;font-size:14px;text-align:center;font-weight:600;transition:border .2s;}
.mark-input:focus{outline:none;border-color:#003366;box-shadow:0 0 0 3px rgba(0,51,102,.1);}
.mark-input:disabled{background:#f5f5f5;color:#bbb;cursor:not-allowed;}
.mark-input.supp{border-color:#f59e0b;}
.mark-input.supp:focus{border-color:#d97706;box-shadow:0 0 0 3px rgba(245,158,11,.15);}
.mark-input.prac{border-color:#7c5cd8;}
.mark-input.prac:focus{border-color:#6d43cc;box-shadow:0 0 0 3px rgba(124,92,216,.15);}
/* Absent checkbox */
.absent-cb{width:18px;height:18px;accent-color:#dc3545;cursor:pointer;}
.absent-label{font-size:11px;color:#dc3545;font-weight:700;}
input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;}
input[type=number]{-moz-appearance:textfield;appearance:textfield;}
.saved-cell{font-size:11px;color:#28a745;font-weight:600;}
.not-saved{color:#ccc;}
/* Buttons */
.btn{display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;text-decoration:none;transition:.2s;}
.btn-success{background:#28a745;color:#fff;} .btn-success:hover{background:#218838;}
.save-bar{margin-top:18px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;}
/* Alert */
.alert{padding:12px 16px;border-radius:9px;margin-bottom:16px;font-weight:600;display:flex;align-items:center;gap:10px;}
.alert-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
.alert-danger{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
.empty-state{text-align:center;padding:50px 20px;background:#f8f9fa;border-radius:12px;border:2px dashed #d0dbe8;}
.empty-state i{font-size:44px;color:#003366;opacity:.2;}
.empty-state h3{color:#003366;margin-top:12px;}
.empty-state p{color:#6c7a8a;font-size:13px;margin-top:5px;}
.note{background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:10px 14px;font-size:12px;color:#7d5c00;margin-bottom:14px;}
@media(max-width:600px){.fg{min-width:100%;}.comp-tabs{flex-direction:column;}.mark-input{width:60px;}}
</style>
</head>
<body>
<?php include("navbar.php"); ?>

<div class="page-title">
    <i class="fas fa-graduation-cap"></i> HS Marks Entry
    <span class="sub">Class XI / XII — Semester & Practical</span>
</div>

<?php if(isset($_SESSION['success'])): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
<?php endif; ?>
<?php if(isset($_SESSION['error'])): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
<?php endif; ?>

<!-- ===== FILTER CARD ===== -->
<div class="card">
<div class="note">
    <i class="fas fa-info-circle"></i>
    <strong>নিজের Subject বেছে নিন।</strong>
    আপনি যে Subject পড়ান সেটা select করুন, তারপর marks দিন।
    &nbsp;|&nbsp; Component: <strong>Sem1</strong> = প্রথম সেমিস্টার, <strong>Sem2</strong> = দ্বিতীয় সেমিস্টার, <strong>Practical</strong> = Practical/Project marks।
    &nbsp;|&nbsp; <strong style="color:#dc3545;">Absent</strong> checkbox টিক দিলে marks field disable হবে।
</div>
<form method="GET" id="filterForm">
<div class="filter-row">

    <div class="fg">
        <label><i class="fas fa-chalkboard"></i> Class</label>
        <select name="class_id" onchange="this.form.submit()">
            <option value="">Select Class</option>
            <?php foreach($hs_classes as $cls): ?>
            <option value="<?php echo $cls['id']; ?>" <?php echo $sel_class==$cls['id']?'selected':''; ?>>
                Class <?php echo htmlspecialchars($cls['class_name']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <?php if($sel_class > 0): ?>
    <div class="fg">
        <label><i class="fas fa-layer-group"></i> Section</label>
        <select name="section_id" onchange="this.form.submit()">
            <option value="">Select Section</option>
            <?php foreach($sections as $sec): ?>
            <option value="<?php echo $sec['id']; ?>" <?php echo $sel_section==$sec['id']?'selected':''; ?>>
                <?php echo htmlspecialchars($sec['section_name']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="fg">
        <label><i class="fas fa-file-signature"></i> Exam</label>
        <select name="hs_exam_id" onchange="this.form.submit()">
            <option value="">Select Exam</option>
            <?php foreach($exams as $ex): ?>
            <option value="<?php echo $ex['id']; ?>" <?php echo $sel_exam==$ex['id']?'selected':''; ?>>
                <?php echo htmlspecialchars($ex['exam_name']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php else: ?>
    <input type="hidden" name="section_id" value="0">
    <input type="hidden" name="hs_exam_id" value="0">
    <?php endif; ?>

    <?php if($sel_exam > 0): ?>
    <div class="fg">
        <label><i class="fas fa-book"></i> Subject (আমার Subject)</label>
        <select name="subject_id" onchange="this.form.submit()">
            <option value="">Select Subject</option>
            <?php foreach($subjects as $sub): ?>
            <option value="<?php echo $sub['subject_id']; ?>" <?php echo $sel_subject==$sub['subject_id']?'selected':''; ?>>
                <?php echo htmlspecialchars($sub['subject_name']); ?>
            </option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php else: ?>
    <input type="hidden" name="subject_id" value="0">
    <?php endif; ?>

    <input type="hidden" name="component" value="<?php echo htmlspecialchars($component); ?>">
</div>
</form>
</div>

<?php if($sel_exam > 0 && $sel_subject > 0 && $sel_section > 0): ?>

<!-- ===== COMPONENT TABS ===== -->
<?php
$base_url = "hs_marks_entry.php?class_id=$sel_class&section_id=$sel_section&hs_exam_id=$sel_exam&subject_id=$sel_subject";
?>
<div class="comp-tabs">
    <a href="<?php echo $base_url; ?>&component=sem1"
       class="comp-tab <?php echo $component==='sem1'?'active':''; ?>">
        <i class="fas fa-1"></i> Semester 1
        <?php if($marks_config): ?><small>(FM: <?php echo (int)$marks_config['sem1_full_marks']; ?>, Pass: <?php echo (int)$marks_config['sem1_pass_marks']; ?>)</small><?php endif; ?>
    </a>
    <a href="<?php echo $base_url; ?>&component=sem2"
       class="comp-tab sem2 <?php echo $component==='sem2'?'active':''; ?>">
        <i class="fas fa-2"></i> Semester 2
        <?php if($marks_config): ?><small>(FM: <?php echo (int)$marks_config['sem2_full_marks']; ?>, Pass: <?php echo (int)$marks_config['sem2_pass_marks']; ?>)</small><?php endif; ?>
    </a>
    <a href="<?php echo $base_url; ?>&component=practical"
       class="comp-tab prac <?php echo $component==='practical'?'active':''; ?>">
        <i class="fas fa-flask"></i> Practical / Project
        <?php if($marks_config && $marks_config['practical_full_marks'] > 0): ?>
        <small>(FM: <?php echo (int)$marks_config['practical_full_marks']; ?>, Pass: <?php echo (int)$marks_config['practical_pass_marks']; ?>)</small>
        <?php endif; ?>
    </a>
</div>

<?php if(empty($students)): ?>
<div class="empty-state">
    <i class="fas fa-user-graduate"></i>
    <h3>কোনো Student পাওয়া যায়নি</h3>
    <p>এই Section এ এই Subject নেওয়া কোনো Active student নেই।</p>
    <p style="font-size:12px;margin-top:8px;">Admin কে <strong>HS Subject Selection</strong> confirm করতে বলুন।</p>
</div>

<?php else: ?>

<!-- Info bar -->
<div class="info-bar">
    <span><i class="fas fa-graduation-cap"></i> <strong>Exam:</strong> <?php echo htmlspecialchars($exam_name_str); ?></span>
    <span><i class="fas fa-book"></i> <strong>Subject:</strong> <?php echo htmlspecialchars($sub_name_str); ?></span>
    <span><i class="fas fa-users"></i> <strong>Students:</strong> <?php echo count($students); ?></span>
    <?php if($component === 'sem1' && $marks_config): ?>
        <span class="badge-fm">FM: <?php echo (int)$marks_config['sem1_full_marks']; ?></span>
        <span class="badge-pass">Pass: <?php echo (int)$marks_config['sem1_pass_marks']; ?></span>
    <?php elseif($component === 'sem2' && $marks_config): ?>
        <span class="badge-fm">FM: <?php echo (int)$marks_config['sem2_full_marks']; ?></span>
        <span class="badge-pass">Pass: <?php echo (int)$marks_config['sem2_pass_marks']; ?></span>
    <?php elseif($component === 'practical' && $marks_config): ?>
        <span class="badge-fm" style="background:#7c5cd8;">FM: <?php echo (int)$marks_config['practical_full_marks']; ?></span>
        <span class="badge-pass">Pass: <?php echo (int)$marks_config['practical_pass_marks']; ?></span>
    <?php endif; ?>
</div>

<form method="POST" id="hsMarksForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="save_marks"      value="1">
    <input type="hidden" name="class_id"        value="<?php echo $sel_class; ?>">
    <input type="hidden" name="section_id"      value="<?php echo $sel_section; ?>">
    <input type="hidden" name="hs_exam_id"      value="<?php echo $sel_exam; ?>">
    <input type="hidden" name="subject_id"      value="<?php echo $sel_subject; ?>">
    <input type="hidden" name="component"       value="<?php echo htmlspecialchars($component); ?>">
    <input type="hidden" name="sem1_pass_marks" value="<?php echo $sem1_pass; ?>">
    <input type="hidden" name="sem2_pass_marks" value="<?php echo $sem2_pass; ?>">

    <div class="table-wrap">
    <table>
        <thead>
        <tr>
            <th style="width:40px;">#</th>
            <th>Roll</th>
            <?php if($hs_show_section_col): ?><th>Sec</th><?php endif; ?>
            <th style="text-align:left;">Student Name</th>
            <th>BS ID</th>
            <?php if($component === 'sem1'): ?>
                <th style="color:#ffcccc;">Absent</th>
                <th>Sem 1 Marks <br><small>Max: <?php echo $marks_config ? (int)$marks_config['sem1_full_marks'] : '—'; ?></small></th>
                <th>Sem 1 Supp <br><small style="color:#ffe082;">(Fail/Absent)</small></th>
                <th>Prev Sem2</th>
                <th>Prev Prac</th>
            <?php elseif($component === 'sem2'): ?>
                <th style="color:#ffcccc;">Absent</th>
                <th>Sem 2 Marks <br><small>Max: <?php echo $marks_config ? (int)$marks_config['sem2_full_marks'] : '—'; ?></small></th>
                <th>Sem 2 Supp <br><small style="color:#ffe082;">(Fail/Absent)</small></th>
                <th>Prev Sem1</th>
                <th>Prev Prac</th>
            <?php else: ?>
                <th style="color:#ffcccc;">Absent</th>
                <th>Practical / Project <br><small>Max: <?php echo $marks_config ? (int)$marks_config['practical_full_marks'] : '—'; ?></small></th>
                <th>Prev Sem1</th>
                <th>Prev Sem2</th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody>
        <?php $sl = 1; foreach($students as $stu):
            $s1_abs = (int)($stu['sem1_absent']     ?? 0);
            $s2_abs = (int)($stu['sem2_absent']     ?? 0);
            $pr_abs = (int)($stu['practical_absent'] ?? 0);
            $sem1_passed = (!$s1_abs && $stu['sem1_marks'] !== null && $stu['sem1_marks'] >= $sem1_pass);
            $sem2_passed = (!$s2_abs && $stu['sem2_marks'] !== null && $stu['sem2_marks'] >= $sem2_pass);

            // Which absent flag applies for this component
            $cur_absent = ($component === 'sem1') ? $s1_abs
                        : (($component === 'sem2') ? $s2_abs : $pr_abs);
        ?>
        <tr id="row_<?php echo $stu['id']; ?>" class="<?php echo $cur_absent ? 'absent-row' : ''; ?>">
            <td style="color:#6c7a8a;font-size:12px;"><?php echo $sl++; ?></td>
            <td class="roll-cell"><?php echo htmlspecialchars($stu['roll_no']); ?></td>
            <?php if($hs_show_section_col): ?>
            <td><span style="background:#e8f4ff;color:#003366;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:700;"><?php echo htmlspecialchars($stu['section_name'] ?? ''); ?></span></td>
            <?php endif; ?>
            <td class="name-cell">
                <?php echo htmlspecialchars($stu['student_name']); ?>
                <input type="hidden" name="student_id[]" value="<?php echo $stu['id']; ?>">
            </td>
            <td class="bsid-cell"><?php echo htmlspecialchars($stu['banglarshiksha_id'] ?? '—'); ?></td>

            <?php if($component === 'sem1'): ?>
            <!-- Absent checkbox -->
            <td>
                <input type="checkbox" class="absent-cb"
                       name="absent_sem1[]" value="<?php echo $stu['id']; ?>"
                       id="abs_sem1_<?php echo $stu['id']; ?>"
                       <?php echo $s1_abs ? 'checked' : ''; ?>
                       onchange="toggleAbsent(this, <?php echo $stu['id']; ?>, 'sem1')">
            </td>
            <td>
                <input type="number" step="0.5" class="mark-input"
                       name="sem1[<?php echo $stu['id']; ?>]"
                       value="<?php echo $stu['sem1_marks'] !== null ? $stu['sem1_marks']+0 : ''; ?>"
                       min="0" max="<?php echo $marks_config ? (int)$marks_config['sem1_full_marks'] : 100; ?>"
                       placeholder="—"
                       id="m_sem1_<?php echo $stu['id']; ?>"
                       <?php echo $s1_abs ? 'disabled' : ''; ?>
                       oninput="checkPass(this, <?php echo $stu['id']; ?>, 'sem1', <?php echo $sem1_pass; ?>)">
            </td>
            <td>
                <input type="number" step="0.5" class="mark-input supp"
                       name="sem1_supp[<?php echo $stu['id']; ?>]"
                       value="<?php echo $stu['sem1_supplementary_marks'] !== null ? $stu['sem1_supplementary_marks']+0 : ''; ?>"
                       id="supp_sem1_<?php echo $stu['id']; ?>"
                       <?php echo ($sem1_passed && !$s1_abs) ? 'disabled' : ''; ?>
                       placeholder="—">
            </td>
            <td class="<?php echo $stu['sem2_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['sem2_marks'] !== null ? $stu['sem2_marks']+0 : '—'; ?>
            </td>
            <td class="<?php echo $stu['practical_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['practical_marks'] !== null ? $stu['practical_marks']+0 : '—'; ?>
            </td>

            <?php elseif($component === 'sem2'): ?>
            <!-- Absent checkbox -->
            <td>
                <input type="checkbox" class="absent-cb"
                       name="absent_sem2[]" value="<?php echo $stu['id']; ?>"
                       id="abs_sem2_<?php echo $stu['id']; ?>"
                       <?php echo $s2_abs ? 'checked' : ''; ?>
                       onchange="toggleAbsent(this, <?php echo $stu['id']; ?>, 'sem2')">
            </td>
            <td>
                <input type="number" step="0.5" class="mark-input"
                       name="sem2[<?php echo $stu['id']; ?>]"
                       value="<?php echo $stu['sem2_marks'] !== null ? $stu['sem2_marks']+0 : ''; ?>"
                       min="0" max="<?php echo $marks_config ? (int)$marks_config['sem2_full_marks'] : 100; ?>"
                       placeholder="—"
                       id="m_sem2_<?php echo $stu['id']; ?>"
                       <?php echo $s2_abs ? 'disabled' : ''; ?>
                       oninput="checkPass(this, <?php echo $stu['id']; ?>, 'sem2', <?php echo $sem2_pass; ?>)">
            </td>
            <td>
                <input type="number" step="0.5" class="mark-input supp"
                       name="sem2_supp[<?php echo $stu['id']; ?>]"
                       value="<?php echo $stu['sem2_supplementary_marks'] !== null ? $stu['sem2_supplementary_marks']+0 : ''; ?>"
                       id="supp_sem2_<?php echo $stu['id']; ?>"
                       <?php echo ($sem2_passed && !$s2_abs) ? 'disabled' : ''; ?>
                       placeholder="—">
            </td>
            <td class="<?php echo $stu['sem1_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['sem1_marks'] !== null ? $stu['sem1_marks']+0 : '—'; ?>
            </td>
            <td class="<?php echo $stu['practical_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['practical_marks'] !== null ? $stu['practical_marks']+0 : '—'; ?>
            </td>

            <?php else: /* practical */ ?>
            <!-- Absent checkbox -->
            <td>
                <input type="checkbox" class="absent-cb"
                       name="absent_prac[]" value="<?php echo $stu['id']; ?>"
                       id="abs_prac_<?php echo $stu['id']; ?>"
                       <?php echo $pr_abs ? 'checked' : ''; ?>
                       onchange="toggleAbsent(this, <?php echo $stu['id']; ?>, 'prac')">
            </td>
            <td>
                <input type="number" step="0.5" class="mark-input prac"
                       name="practical[<?php echo $stu['id']; ?>]"
                       value="<?php echo $stu['practical_marks'] !== null ? $stu['practical_marks']+0 : ''; ?>"
                       min="0" max="<?php echo $marks_config ? (int)$marks_config['practical_full_marks'] : 100; ?>"
                       placeholder="—"
                       id="m_prac_<?php echo $stu['id']; ?>"
                       <?php echo $pr_abs ? 'disabled' : ''; ?>>
            </td>
            <td class="<?php echo $stu['sem1_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['sem1_marks'] !== null ? $stu['sem1_marks']+0 : '—'; ?>
            </td>
            <td class="<?php echo $stu['sem2_marks']!==null?'saved-cell':'not-saved'; ?>">
                <?php echo $stu['sem2_marks'] !== null ? $stu['sem2_marks']+0 : '—'; ?>
            </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>

    <div class="save-bar">
        <button type="submit" class="btn btn-success">
            <i class="fas fa-save"></i> Save Marks
        </button>
        <span style="font-size:12px;color:#6c7a8a;">
            <i class="fas fa-info-circle"></i>
            Pass হলে Supp field auto-disable &nbsp;|&nbsp;
            <span style="color:#dc3545;"><i class="fas fa-square-xmark"></i> Absent</span> টিক দিলে Marks field disable হয় &nbsp;|&nbsp; Ctrl+S = Save
        </span>
    </div>
</form>

<?php endif; // students empty check ?>

<?php else: ?>
<div class="empty-state">
    <i class="fas fa-filter"></i>
    <h3>Filter Select করুন</h3>
    <p>উপরে Class, Section, Exam এবং Subject select করুন।</p>
</div>
<?php endif; ?>

<script>
// Absent toggle → disable/enable marks input; supp stays enabled for absent students
function toggleAbsent(cb, sid, comp) {
    var mInput    = document.getElementById('m_' + comp + '_' + sid);
    var suppInput = document.getElementById('supp_' + comp + '_' + sid);
    var row       = cb.closest('tr');
    if (cb.checked) {
        if (mInput) { mInput.disabled = true; mInput.value = ''; }
        // Supp stays enabled — absent students can sit supplementary
        if (suppInput) suppInput.disabled = false;
        if (row) row.classList.add('absent-row');
    } else {
        if (mInput)   mInput.disabled = false;
        if (row) row.classList.remove('absent-row');
    }
}

// Pass check → Supp disable/enable
function checkPass(input, sid, sem, passMarks) {
    var suppInput = document.getElementById('supp_' + sem + '_' + sid);
    if (!suppInput) return;
    var val = parseFloat(input.value) || 0;
    if (val >= passMarks) {
        suppInput.disabled = true;
        suppInput.value = '';
    } else {
        suppInput.disabled = false;
    }
}

// Enter → next enabled input
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.mark-input').forEach(function(inp) {
        inp.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                var allInputs = Array.from(document.querySelectorAll('.mark-input'));
                var i = allInputs.indexOf(inp);
                for (var j = i + 1; j < allInputs.length; j++) {
                    if (!allInputs[j].disabled) { allInputs[j].focus(); break; }
                }
            }
        });
    });
});

// Ctrl+S Save
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        document.getElementById('hsMarksForm')?.submit();
    }
});
</script>
</body>
</html>

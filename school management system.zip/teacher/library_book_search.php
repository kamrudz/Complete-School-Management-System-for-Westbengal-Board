<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once("../includes/library_helper.php");

if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 1) { echo json_encode(['results' => []]); exit(); }
$esc = mysqli_real_escape_string($conn, $q);
$is_numeric_q = ctype_digit($q);

// The same search box looks across Title, Author, ISBN, Accession No, and Book ID (if numeric) all at once
$where = "b.status='Active' AND (
    b.title LIKE '%$esc%' OR b.author LIKE '%$esc%' OR b.isbn LIKE '%$esc%' OR c.accession_no LIKE '%$esc%'";
if ($is_numeric_q) { $where .= " OR b.id = " . (int)$q; }
$where .= ")";

$res = mysqli_query($conn, "
    SELECT c.id AS copy_id, c.accession_no, c.status AS copy_status,
           b.id AS book_id, b.title, b.author, b.isbn, b.price
    FROM library_book_copies c
    JOIN library_books b ON b.id = c.book_id
    WHERE $where
    ORDER BY b.title ASC, c.accession_no ASC
    LIMIT 20
");
$results = [];
while ($r = mysqli_fetch_assoc($res)) {
    $results[] = [
        'copy_id' => $r['copy_id'],
        'book_id' => $r['book_id'],
        'accession_no' => $r['accession_no'],
        'copy_status' => $r['copy_status'],
        'title' => $r['title'],
        'author' => $r['author'],
        'isbn' => $r['isbn'],
        'price' => $r['price'],
    ];
}
echo json_encode(['results' => $results]);

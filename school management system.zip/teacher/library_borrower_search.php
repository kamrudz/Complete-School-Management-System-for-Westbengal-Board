<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once("../includes/library_helper.php");

if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$type = ($_GET['type'] ?? 'Student') === 'Staff' ? 'Staff' : 'Student';
$q = trim($_GET['q'] ?? '');
if (mb_strlen($q) < 2) { echo json_encode(['results' => []]); exit(); }
$esc = mysqli_real_escape_string($conn, $q);
$results = [];

if ($type === 'Student') {
    $res = mysqli_query($conn, "
        SELECT s.id, s.student_name, s.photo, s.admission_no, h.roll_no, c.class_name, sec.section_name
        FROM students s
        LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
        LEFT JOIN classes c ON c.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        WHERE s.student_status='Active' AND (s.student_name LIKE '%$esc%' OR s.admission_no LIKE '%$esc%')
        ORDER BY s.student_name ASC LIMIT 12
    ");
    while ($r = mysqli_fetch_assoc($res)) {
        $sub = trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? '')) . (!empty($r['roll_no']) ? ' • Roll: ' . $r['roll_no'] : '') . ' • Adm: ' . $r['admission_no'];
        $results[] = ['id' => $r['id'], 'name' => $r['student_name'], 'subtitle' => $sub, 'photo' => !empty($r['photo']) ? '../uploads/students/' . $r['photo'] : ''];
    }
} else {
    $res = mysqli_query($conn, "SELECT id, staff_name, photo, designation, employee_id FROM staff WHERE service_status='Active' AND (staff_name LIKE '%$esc%' OR employee_id LIKE '%$esc%') ORDER BY staff_name ASC LIMIT 12");
    while ($r = mysqli_fetch_assoc($res)) {
        $results[] = ['id' => $r['id'], 'name' => $r['staff_name'], 'subtitle' => ($r['designation'] ?? '') . ' • ID: ' . $r['employee_id'], 'photo' => !empty($r['photo']) ? '../uploads/staff/' . $r['photo'] : ''];
    }
}
echo json_encode(['results' => $results]);

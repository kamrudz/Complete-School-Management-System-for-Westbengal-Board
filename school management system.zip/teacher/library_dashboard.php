<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("../includes/db.php");
require_once("../includes/library_helper.php");

$is_librarian = is_library_staff($conn, $_SESSION['teacher_id'] ?? 0);

if ($is_librarian) {
    $stock = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT
            (SELECT COUNT(*) FROM library_book_copies WHERE status='Available') AS available_copies,
            (SELECT COUNT(*) FROM library_book_copies WHERE status='Issued') AS issued_copies
    "));
    $overdue_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM library_issues WHERE status='Issued' AND due_date < CURDATE()"))['c'];
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Library Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 16px; }
.wrap { max-width: 480px; margin: 0 auto; }
.deny-box { background:#fff; border-radius:14px; padding:30px 20px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,.08); }
.deny-box i { font-size:40px; color:#dc3545; margin-bottom:12px; }

.page-title { font-size: 20px; font-weight: 800; color: #003366; margin-bottom: 18px; display:flex; align-items:center; gap:10px; }

.big-btn { display:flex; align-items:center; gap:16px; text-decoration:none; padding:22px 20px; border-radius:16px; font-weight:800; font-size:17px; margin-bottom:16px; box-shadow:0 3px 10px rgba(0,0,0,.08); }
.big-btn .icon { width:48px; height:48px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0; }
.big-btn .sub { font-size:12px; font-weight:500; opacity:.85; margin-top:2px; }

.btn-issue { background:#003366; color:#fff; }
.btn-issue .icon { background:rgba(255,255,255,.15); }

.btn-return { background:#fff; color:#003366; border:2px solid #003366; }
.btn-return .icon { background:#eaf2fb; color:#003366; }

.stat-strip { display:flex; gap:10px; margin-top:10px; }
.stat-card { flex:1; background:#fff; border-radius:12px; padding:14px; text-align:center; box-shadow:0 2px 8px rgba(0,0,0,.05); }
.stat-card .num { font-size:22px; font-weight:800; color:#003366; }
.stat-card .lbl { font-size:11px; color:#6c7a8a; margin-top:2px; }
.stat-card.warn .num { color:#a4161a; }
</style>
</head>
<body>
<?php include("navbar.php"); ?>
<div class="wrap">

<?php if (!$is_librarian): ?>
    <div class="deny-box">
        <i class="fas fa-lock"></i>
        <h3 style="color:#003366;">Access Denied</h3>
        <p style="color:#6c7a8a; font-size:13px;">Only staff who have been granted Library Access can view this page.<br>Ask the Admin to add you from the "Library Staff Access" page.</p>
        <a href="dashboard.php" style="color:#0f5b8a; font-weight:600; text-decoration:none; font-size:13px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
<?php else: ?>

    <div class="page-title"><i class="fas fa-book-reader"></i> Library</div>

    <a href="library_issue_scan.php" class="big-btn btn-issue">
        <div class="icon"><i class="fas fa-hand-holding"></i></div>
        <div>
            Issue a Book
            <div class="sub">Pick a book first, then the student/staff</div>
        </div>
    </a>

    <a href="library_return_scan.php" class="big-btn btn-return">
        <div class="icon"><i class="fas fa-undo-alt"></i></div>
        <div>
            Return / Renew a Book
            <div class="sub">Find the student/staff, then manage their books</div>
        </div>
    </a>

    <div class="stat-strip">
        <div class="stat-card"><div class="num" style="color:#155724;"><?php echo (int)$stock['available_copies']; ?></div><div class="lbl">Available</div></div>
        <div class="stat-card"><div class="num" style="color:#856404;"><?php echo (int)$stock['issued_copies']; ?></div><div class="lbl">Issued</div></div>
        <div class="stat-card warn"><div class="num"><?php echo (int)$overdue_count; ?></div><div class="lbl">Overdue</div></div>
    </div>

<?php endif; ?>
</div>
</body>
</html>

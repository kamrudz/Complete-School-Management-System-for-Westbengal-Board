<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once("../includes/library_helper.php");

if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$class_id = (int)($_GET['class_id'] ?? 0);
$active = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active['id'] ?? 0);

$sections = [];
if ($class_id > 0 && $session_id > 0) {
    $q = mysqli_query($conn, "SELECT id, section_name FROM sections WHERE class_id=$class_id AND session_id=$session_id ORDER BY section_name ASC");
    while ($r = mysqli_fetch_assoc($q)) { $sections[] = $r; }
}
echo json_encode(['sections' => $sections]);

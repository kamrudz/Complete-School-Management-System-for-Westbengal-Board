<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once("../includes/library_helper.php");

if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied']);
    exit();
}

$class_id = (int)($_GET['class_id'] ?? 0);
$section_id = (int)($_GET['section_id'] ?? 0);
$active = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active['id'] ?? 0);

$students = [];
if ($class_id > 0 && $session_id > 0) {
    $where = "h.class_id=$class_id AND h.session_id=$session_id AND h.academic_status='Current' AND s.student_status='Active'";
    if ($section_id > 0) { $where .= " AND h.section_id=$section_id"; }
    $q = mysqli_query($conn, "
        SELECT s.id, s.student_name, s.photo, h.roll_no
        FROM student_academic_history h
        JOIN students s ON s.id = h.student_id
        WHERE $where
        ORDER BY CAST(h.roll_no AS UNSIGNED) ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $students[] = $r; }
}
echo json_encode(['students' => $students]);

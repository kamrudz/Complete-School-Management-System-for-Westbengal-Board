<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

$is_librarian = is_library_staff($conn, $_SESSION['teacher_id'] ?? 0);
$settings = get_library_settings($conn);
$classes = $is_librarian ? mysqli_query($conn, "SELECT id, class_name FROM classes ORDER BY sort_order ASC") : null;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Issue a Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f9; margin:0; padding: 12px; }
.wrap { max-width: 480px; margin: 0 auto; }
.deny-box { background:#fff; border-radius:14px; padding:30px 20px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,.08); }
.deny-box i { font-size:40px; color:#dc3545; margin-bottom:12px; }
.back-link { display:inline-flex; align-items:center; gap:6px; color:#0f5b8a; text-decoration:none; font-weight:600; font-size:13px; margin-bottom:12px; }

.card { background:#fff; border-radius:14px; padding:18px; margin-bottom:14px; box-shadow:0 2px 10px rgba(0,0,0,.06); }
.card h4 { margin:0 0 12px 0; color:#003366; font-size:15px; display:flex; align-items:center; gap:8px; }

.mode-tabs { display:flex; gap:6px; margin-bottom:12px; background:#f0f2f5; border-radius:10px; padding:4px; }
.mode-tabs button { flex:1; padding:8px 4px; border:none; background:transparent; border-radius:8px; font-size:12px; font-weight:700; color:#5a6b7a; cursor:pointer; }
.mode-tabs button.active { background:#003366; color:#fff; }
.mode-pane { display:none; }
.mode-pane.active { display:block; }

.scan-area { position:relative; border-radius:12px; overflow:hidden; background:#000; margin-bottom:10px; display:none; }
.scan-area video { width:100%; display:block; }
.scan-frame { position:absolute; inset:15%; border:3px solid #22c55e; border-radius:12px; box-shadow:0 0 0 999px rgba(0,0,0,0.35); }
.scan-buttons { display:flex; gap:8px; margin-bottom:4px; }
.scan-buttons button { flex:1; padding:11px; border-radius:10px; border:none; font-weight:700; font-size:13px; cursor:pointer; }
.btn-cam { background:#003366; color:#fff; }
.btn-stop { background:#dc3545; color:#fff; display:none; }

.search-box { position:relative; }
.search-box input { width:100%; padding:11px 14px; border:2px solid #e4edf6; border-radius:10px; font-size:14px; }
.search-results { position:absolute; top:100%; left:0; right:0; background:#fff; border:1px solid #e4edf6; border-radius:8px; box-shadow:0 6px 20px rgba(0,0,0,.12); max-height:260px; overflow-y:auto; z-index:30; display:none; }
.result-item { display:flex; align-items:center; gap:10px; padding:10px 12px; cursor:pointer; border-bottom:1px solid #f0f0f0; font-size:13px; }
.result-item:hover { background:#f0f7ff; }
.result-item img { width:30px; height:30px; border-radius:6px; object-fit:cover; background:#ddd; }
.result-item .rname { font-weight:700; color:#1a3b55; }
.result-item .rsub { font-size:11px; color:#6c7a8a; }

.select-row { display:flex; gap:8px; margin-bottom:8px; }
.select-row select { flex:1; padding:10px; border:2px solid #e4edf6; border-radius:10px; font-size:13px; }

.book-box, .borrower-box { background:#eaf2fb; border-radius:12px; padding:14px; display:none; align-items:center; gap:12px; margin-bottom:4px; }
.borrower-box img { width:44px; height:44px; border-radius:10px; object-fit:cover; background:#ddd; }
.bname { font-weight:700; color:#003366; font-size:14px; }
.bsub { font-size:12px; color:#5a6b7a; }
.clear-btn { margin-left:auto; color:#a4161a; font-size:12px; cursor:pointer; white-space:nowrap; }

.type-toggle { display:flex; gap:8px; margin-bottom:12px; }
.type-toggle button { flex:1; padding:9px; border:2px solid #e4edf6; background:#fff; border-radius:8px; cursor:pointer; font-weight:700; font-size:13px; color:#1a3b55; }
.type-toggle button.active { background:#003366; color:#fff; border-color:#003366; }

.alert { padding:12px 16px; border-radius:10px; margin-bottom:14px; font-weight:600; font-size:13px; }
.alert-success { background:#d4edda; color:#155724; }
.alert-error { background:#f8d7da; color:#842029; }
.issue-book-btn { width:100%; padding:13px; border:none; border-radius:10px; background:#22c55e; color:#fff; font-weight:700; font-size:15px; margin-top:10px; }
.issue-book-btn:disabled { background:#ccc; cursor:not-allowed; }
.step-locked { opacity:0.4; pointer-events:none; }
</style>
</head>
<body>
<?php include("navbar.php"); ?>
<div class="wrap">

<?php if (!$is_librarian): ?>
    <div class="deny-box">
        <i class="fas fa-lock"></i>
        <h3 style="color:#003366;">Access Denied</h3>
        <p style="color:#6c7a8a; font-size:13px;">Only staff who have been granted Library Access can use this page.</p>
        <a href="dashboard.php" style="color:#0f5b8a; font-weight:600; text-decoration:none; font-size:13px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
    </div>
</body>
</html>
<?php exit(); endif; ?>

<a href="library_dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Library Dashboard</a>

<?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

<!-- ===== STEP 1: BOOK ===== -->
<div class="card">
    <h4><i class="fas fa-book"></i> Step 1 — Find the Book</h4>
    <div class="mode-tabs">
        <button type="button" class="active" onclick="switchMode(this,'book','scan')"><i class="fas fa-camera"></i> Scan</button>
        <button type="button" onclick="switchMode(this,'book','search')"><i class="fas fa-search"></i> Search</button>
    </div>

    <div class="mode-pane active" id="book-mode-scan">
        <div class="scan-area" id="scanAreaBook"><video id="videoBook" playsinline></video><div class="scan-frame"></div></div>
        <div class="scan-buttons">
            <button type="button" class="btn-cam" id="btnCamBook" onclick="startScan('book')"><i class="fas fa-camera"></i> Scan Book QR with Camera</button>
            <button type="button" class="btn-stop" id="btnStopBook" onclick="stopScan('book')"><i class="fas fa-times"></i> Stop</button>
        </div>
    </div>
    <div class="mode-pane" id="book-mode-search">
        <div class="search-box">
            <input type="text" id="searchBookInput" placeholder="Search by title, ISBN, Book ID, or Accession No..." autocomplete="off">
            <div class="search-results" id="searchBookResults"></div>
        </div>
    </div>

    <div class="book-box" id="bookBox" style="margin-top:10px;">
        <div style="flex:1;"><div class="bname" id="bkTitle"></div><div class="bsub" id="bkSub"></div></div>
        <span class="clear-btn" onclick="clearBook()"><i class="fas fa-times"></i> Change</span>
    </div>
</div>

<!-- ===== STEP 2: BORROWER ===== -->
<div class="card step-locked" id="borrowerStep">
    <h4><i class="fas fa-user"></i> Step 2 — Who is this for?</h4>

    <div class="type-toggle">
        <button type="button" class="active" id="btnTypeStudent" onclick="setBorrowerType('Student')"><i class="fas fa-user-graduate"></i> Student</button>
        <button type="button" id="btnTypeStaff" onclick="setBorrowerType('Staff')"><i class="fas fa-chalkboard-teacher"></i> Staff</button>
    </div>

    <!-- Student sub-tabs: Search / Class-Roll -->
    <div id="studentModeTabs" class="mode-tabs">
        <button type="button" class="active" onclick="switchMode(this,'borrower','search')"><i class="fas fa-search"></i> Search by Name</button>
        <button type="button" onclick="switchMode(this,'borrower','classroll')"><i class="fas fa-school"></i> Class/Roll</button>
    </div>

    <div class="mode-pane active" id="borrower-mode-search">
        <div class="search-box">
            <input type="text" id="searchBorrowerInput" placeholder="Search by name or ID..." autocomplete="off">
            <div class="search-results" id="searchBorrowerResults"></div>
        </div>
    </div>

    <div class="mode-pane" id="borrower-mode-classroll">
        <div class="select-row">
            <select id="pickClass" onchange="onClassChange()">
                <option value="">Class</option>
                <?php mysqli_data_seek($classes, 0); while ($c = mysqli_fetch_assoc($classes)): ?>
                <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['class_name']); ?></option>
                <?php endwhile; ?>
            </select>
            <select id="pickSection" onchange="onSectionChange()" disabled>
                <option value="">Section (all)</option>
            </select>
        </div>
        <div class="select-row">
            <select id="pickStudent" disabled onchange="onStudentPick()">
                <option value="">Roll No — Name</option>
            </select>
        </div>
    </div>

    <div class="borrower-box" id="borrowerBox" style="margin-top:6px;">
        <img id="bImg" src=""><div style="flex:1;"><div class="bname" id="bName"></div><div class="bsub" id="bSub"></div></div>
        <span class="clear-btn" onclick="clearBorrower()"><i class="fas fa-times"></i> Change</span>
    </div>

    <form method="POST" action="library_scan_action.php" id="issueForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="borrower_type" id="f_borrower_type" value="Student">
        <input type="hidden" name="borrower_id" id="f_borrower_id">
        <input type="hidden" name="copy_id" id="f_copy_id">
        <button type="submit" name="issue_book" class="issue-book-btn" id="issueSubmitBtn" disabled><i class="fas fa-hand-holding"></i> Issue This Book</button>
    </form>
</div>

</div>

<script>
var currentBorrowerType = 'Student';
var selectedBook = null;

// ================= MODE TAB SWITCHING =================
function switchMode(btn, section, mode) {
    var container = btn.closest('.card');
    // for the borrower card, only toggle panes within the relevant tab-group (studentModeTabs), not the type-toggle
    var scope = section === 'borrower' ? document.getElementById('studentModeTabs') : container.querySelector('.mode-tabs');
    scope.querySelectorAll('button').forEach(function(b){ b.classList.remove('active'); });
    btn.classList.add('active');
    container.querySelectorAll('.mode-pane').forEach(function(p){ p.classList.remove('active'); });
    document.getElementById(section + '-mode-' + mode).classList.add('active');
    if (mode !== 'scan') { stopScan(section); }
}

// ================= BORROWER TYPE (Student/Staff) =================
function setBorrowerType(type) {
    currentBorrowerType = type;
    document.getElementById('f_borrower_type').value = type;
    document.getElementById('btnTypeStudent').classList.toggle('active', type === 'Student');
    document.getElementById('btnTypeStaff').classList.toggle('active', type === 'Staff');
    document.getElementById('studentModeTabs').style.display = type === 'Student' ? 'flex' : 'none';
    document.getElementById('borrower-mode-classroll').classList.remove('active');
    document.getElementById('borrower-mode-search').classList.add('active');
    if (document.getElementById('studentModeTabs').children[0]) {
        document.getElementById('studentModeTabs').children[0].classList.add('active');
        document.getElementById('studentModeTabs').children[1].classList.remove('active');
    }
    clearBorrower();
}

// ================= BARCODE/QR SCAN (native BarcodeDetector, no external library needed) =================
var streams = {};
function scanSupported() { return 'BarcodeDetector' in window; }
async function startScan(target) {
    if (!scanSupported()) { alert('Camera scanning is not supported in this browser — please use Search instead. (Usually works in the Chrome browser)'); return; }
    var video = document.getElementById('video' + cap(target));
    var area = document.getElementById('scanArea' + cap(target));
    area.style.display = 'block';
    document.getElementById('btnCam' + cap(target)).style.display = 'none';
    document.getElementById('btnStop' + cap(target)).style.display = 'block';
    try {
        var stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        streams[target] = stream;
        video.srcObject = stream;
        await video.play();
        var detector = new BarcodeDetector({ formats: ['qr_code'] });
        var loop = async function() {
            if (!streams[target]) return;
            try {
                var codes = await detector.detect(video);
                if (codes.length > 0) { stopScan(target); lookupBookByCode(codes[0].rawValue); return; }
            } catch (e) {}
            requestAnimationFrame(loop);
        };
        loop();
    } catch (e) {
        alert('Camera access was not granted — check permissions, or use Search instead.');
        stopScan(target);
    }
}
function stopScan(target) {
    if (streams[target]) { streams[target].getTracks().forEach(t => t.stop()); delete streams[target]; }
    var area = document.getElementById('scanArea' + cap(target));
    var camBtn = document.getElementById('btnCam' + cap(target));
    var stopBtn = document.getElementById('btnStop' + cap(target));
    if (area) area.style.display = 'none';
    if (camBtn) camBtn.style.display = 'block';
    if (stopBtn) stopBtn.style.display = 'none';
}
function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ================= BOOK: scan + search =================
function lookupBookByCode(code) {
    if (!code || !code.trim()) return;
    fetch('library_lookup.php?code=' + encodeURIComponent(code.trim()))
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(data => {
            if (data.error || data.type !== 'book') { alert(data.error || 'This is not a valid book Accession No.'); return; }
            applyBook(data.data);
        })
        .catch(err => { console.error('lookupBookByCode failed:', err); alert('Could not reach library_lookup.php — check the file is uploaded to the teacher/ folder. (' + err.message + ')'); });
}
function applyBook(data) {
    if (data.copy_status !== 'Available') {
        alert('This copy is currently "' + data.copy_status + '" — it cannot be issued. Pick another copy.');
        return;
    }
    selectedBook = data;
    document.getElementById('bkTitle').textContent = data.title;
    document.getElementById('bkSub').textContent = data.accession_no + (data.author ? ' • ' + data.author : '');
    document.getElementById('bookBox').style.display = 'flex';
    document.getElementById('f_copy_id').value = data.copy_id;
    document.getElementById('borrowerStep').classList.remove('step-locked');
    checkReady();
}
function clearBook() {
    selectedBook = null;
    document.getElementById('bookBox').style.display = 'none';
    document.getElementById('f_copy_id').value = '';
    document.getElementById('borrowerStep').classList.add('step-locked');
    checkReady();
}

var kTimer;
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('searchBookInput').addEventListener('input', function () {
        var q = this.value.trim();
        clearTimeout(kTimer);
        var box = document.getElementById('searchBookResults');
        if (q.length < 1) { box.style.display = 'none'; return; }
        kTimer = setTimeout(function () {
            fetch('library_book_search.php?q=' + encodeURIComponent(q))
                .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
                .then(data => {
                    box.innerHTML = '';
                    if (!data.results || data.results.length === 0) {
                        box.innerHTML = '<div class="result-item">No matching book/copy found</div>';
                    } else {
                        data.results.forEach(function (r) {
                            var div = document.createElement('div');
                            div.className = 'result-item';
                            var statusTag = r.copy_status === 'Available' ? '' : ' — <b style="color:#a4161a;">' + r.copy_status + '</b>';
                            div.innerHTML = '<div><div class="rname">' + r.title + '</div><div class="rsub">' + r.accession_no + statusTag + (r.isbn ? ' • ISBN: ' + r.isbn : '') + '</div></div>';
                            div.onclick = function () { box.style.display = 'none'; applyBook(r); };
                            box.appendChild(div);
                        });
                    }
                    box.style.display = 'block';
                })
                .catch(err => { console.error('Book search failed:', err); box.innerHTML = '<div class="result-item" style="color:#a4161a;">Search failed — library_book_search.php not reachable (' + err.message + ')</div>'; box.style.display = 'block'; });
        }, 300);
    });

    // ================= BORROWER: live name/ID search =================
    document.getElementById('searchBorrowerInput').addEventListener('input', function () {
        var q = this.value.trim();
        clearTimeout(bTimer);
        var box = document.getElementById('searchBorrowerResults');
        if (q.length < 2) { box.style.display = 'none'; return; }
        bTimer = setTimeout(function () {
            fetch('library_borrower_search.php?type=' + currentBorrowerType + '&q=' + encodeURIComponent(q))
                .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
                .then(data => {
                    box.innerHTML = '';
                    if (!data.results || data.results.length === 0) {
                        box.innerHTML = '<div class="result-item">No results found</div>';
                    } else {
                        data.results.forEach(function (r) {
                            var div = document.createElement('div');
                            div.className = 'result-item';
                            div.innerHTML = '<img src="' + (r.photo || '') + '" onerror="this.style.display=\'none\'"><div><div class="rname">' + r.name + '</div><div class="rsub">' + r.subtitle + '</div></div>';
                            div.onclick = function () { box.style.display = 'none'; applyBorrower(r); };
                            box.appendChild(div);
                        });
                    }
                    box.style.display = 'block';
                })
                .catch(err => { console.error('Borrower search failed:', err); box.innerHTML = '<div class="result-item" style="color:#a4161a;">Search failed — library_borrower_search.php not reachable (' + err.message + ')</div>'; box.style.display = 'block'; });
        }, 300);
    });

    document.addEventListener('click', function (e) {
        if (!e.target.closest('.search-box')) {
            document.getElementById('searchBorrowerResults').style.display = 'none';
            document.getElementById('searchBookResults').style.display = 'none';
        }
    });
});
var bTimer;

// ================= BORROWER: Class / Section / Roll =================
function onClassChange() {
    var classId = document.getElementById('pickClass').value;
    var secSel = document.getElementById('pickSection');
    var stuSel = document.getElementById('pickStudent');
    secSel.innerHTML = '<option value="">Section (all)</option>';
    stuSel.innerHTML = '<option value="">Roll No — Name</option>';
    stuSel.disabled = true;
    if (!classId) { secSel.disabled = true; return; }
    secSel.disabled = false;
    fetch('library_get_sections.php?class_id=' + classId)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(data => {
            (data.sections || []).forEach(function (s) {
                var opt = document.createElement('option');
                opt.value = s.id; opt.textContent = s.section_name;
                secSel.appendChild(opt);
            });
        })
        .catch(err => { console.error('get_sections failed:', err); alert('Could not load sections — library_get_sections.php not reachable (' + err.message + ')'); });
    loadStudentsForClassSection();
}
function onSectionChange() { loadStudentsForClassSection(); }
function loadStudentsForClassSection() {
    var classId = document.getElementById('pickClass').value;
    var sectionId = document.getElementById('pickSection').value;
    var stuSel = document.getElementById('pickStudent');
    stuSel.innerHTML = '<option value="">Roll No — Name</option>';
    if (!classId) { stuSel.disabled = true; return; }
    fetch('library_get_students.php?class_id=' + classId + '&section_id=' + sectionId)
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(data => {
            stuSel.disabled = false;
            (data.students || []).forEach(function (s) {
                var opt = document.createElement('option');
                opt.value = JSON.stringify(s);
                opt.textContent = (s.roll_no || '-') + ' — ' + s.student_name;
                stuSel.appendChild(opt);
            });
        })
        .catch(err => { console.error('get_students failed:', err); alert('Could not load students — library_get_students.php not reachable (' + err.message + ')'); });
}
function onStudentPick() {
    var val = document.getElementById('pickStudent').value;
    if (!val) return;
    var s = JSON.parse(val);
    applyBorrower({ id: s.id, name: s.student_name, photo: s.photo,
        subtitle: [document.getElementById('pickClass').selectedOptions[0].textContent,
                   document.getElementById('pickSection').selectedOptions[0] ? document.getElementById('pickSection').selectedOptions[0].textContent : '',
                   s.roll_no ? 'Roll: ' + s.roll_no : ''].filter(Boolean).join(' • ') });
}

// ================= APPLY BORROWER =================
function applyBorrower(data) {
    var photoSrc = '';
    if (data.photo) {
        photoSrc = data.photo.indexOf('../uploads/') === 0 ? data.photo
            : (currentBorrowerType === 'Student' ? '../uploads/students/' : '../uploads/staff/') + data.photo;
    }
    document.getElementById('bImg').src = photoSrc;
    document.getElementById('bName').textContent = data.name;
    document.getElementById('bSub').textContent = data.subtitle || '';
    document.getElementById('borrowerBox').style.display = 'flex';
    document.getElementById('f_borrower_id').value = data.id;
    checkReady();
}
function clearBorrower() {
    document.getElementById('borrowerBox').style.display = 'none';
    document.getElementById('f_borrower_id').value = '';
    document.getElementById('searchBorrowerInput').value = '';
    document.getElementById('pickClass').value = '';
    document.getElementById('pickSection').innerHTML = '<option value="">Section (all)</option>';
    document.getElementById('pickSection').disabled = true;
    document.getElementById('pickStudent').innerHTML = '<option value="">Roll No — Name</option>';
    document.getElementById('pickStudent').disabled = true;
    checkReady();
}

function checkReady() {
    var ready = document.getElementById('f_copy_id').value && document.getElementById('f_borrower_id').value;
    document.getElementById('issueSubmitBtn').disabled = !ready;
}
</script>
</body>
</html>

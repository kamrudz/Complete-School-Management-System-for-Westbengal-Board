<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
header('Content-Type: application/json');
include("../includes/db.php");
require_once("../includes/library_helper.php");

// Only staff present in library_staff_access can use this lookup (live DB check)
if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    http_response_code(403);
    echo json_encode(['error' => 'Access denied — you do not have library access.']);
    exit();
}

$code = trim($_GET['code'] ?? '');
if ($code === '') { echo json_encode(['error' => 'No code received.']); exit(); }

// ===== 1. Book Accession No (LIB-2026-001 pattern) =====
if (preg_match('/^LIB-\d{4}-\d+$/i', $code)) {
    $stmt = mysqli_prepare($conn, "
        SELECT c.id AS copy_id, c.accession_no, c.status AS copy_status, b.id AS book_id, b.title, b.author, b.price
        FROM library_book_copies c JOIN library_books b ON b.id = c.book_id
        WHERE c.accession_no = ? LIMIT 1
    ");
    mysqli_stmt_bind_param($stmt, "s", $code);
    mysqli_stmt_execute($stmt);
    $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    if (!$row) { echo json_encode(['error' => 'No book found for this Accession No.']); exit(); }
    echo json_encode(['type' => 'book', 'data' => $row]);
    exit();
}

// ===== 2. Verification token inside the ID Card QR (scanned as a URL) =====
$student_id = null;
if (preg_match('/token=([a-f0-9]{64})/i', $code, $m)) {
    $token = $m[1];
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT student_id FROM student_id_cards WHERE verification_token='" . mysqli_real_escape_string($conn, $token) . "' AND is_active=1 LIMIT 1"));
    if ($row) { $student_id = $row['student_id']; }
}

// ===== 3. If student_id was found, fetch borrower info =====
if ($student_id) {
    $info = get_borrower_info($conn, 'Student', $student_id);
    if ($info) {
        echo json_encode(['type' => 'borrower', 'borrower_type' => 'Student', 'data' => $info]);
        exit();
    }
}

// ===== 4. Manual fallback — Admission No / Employee ID typed directly =====
$esc = mysqli_real_escape_string($conn, $code);
$stu = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM students WHERE admission_no='$esc' AND student_status='Active' LIMIT 1"));
if ($stu) {
    $info = get_borrower_info($conn, 'Student', $stu['id']);
    echo json_encode(['type' => 'borrower', 'borrower_type' => 'Student', 'data' => $info]);
    exit();
}
$stf = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id FROM staff WHERE employee_id='$esc' AND service_status='Active' LIMIT 1"));
if ($stf) {
    $info = get_borrower_info($conn, 'Staff', $stf['id']);
    echo json_encode(['type' => 'borrower', 'borrower_type' => 'Staff', 'data' => $info]);
    exit();
}

echo json_encode(['error' => 'Nothing found — check the Accession No, ID Card, Admission No, or Employee ID.']);

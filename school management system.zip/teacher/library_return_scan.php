<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

$is_librarian = is_library_staff($conn, $_SESSION['teacher_id'] ?? 0);
$settings = get_library_settings($conn);

$search = trim($_GET['search'] ?? '');
$overdue_only = isset($_GET['overdue_only']);
$rows = [];

if ($is_librarian) {
    $where = "li.status='Issued'";
    if ($overdue_only) { $where .= " AND li.due_date < CURDATE()"; }
    if ($search !== '') {
        $esc = mysqli_real_escape_string($conn, $search);
        $where .= " AND (
            b.title LIKE '%$esc%' OR c.accession_no LIKE '%$esc%'
            OR s.student_name LIKE '%$esc%' OR s.admission_no LIKE '%$esc%'
            OR st.staff_name LIKE '%$esc%' OR st.employee_id LIKE '%$esc%'
        )";
    }

    $q = mysqli_query($conn, "
        SELECT li.*, c.accession_no, b.title, b.price,
               s.student_name, s.photo AS student_photo, s.admission_no,
               cl.class_name, sec.section_name, h.roll_no,
               st.staff_name, st.photo AS staff_photo, st.designation, st.employee_id
        FROM library_issues li
        JOIN library_book_copies c ON c.id = li.copy_id
        JOIN library_books b ON b.id = c.book_id
        LEFT JOIN students s ON li.borrower_type='Student' AND s.id = li.borrower_id
        LEFT JOIN student_academic_history h ON h.student_id = s.id AND h.academic_status='Current'
        LEFT JOIN classes cl ON cl.id = h.class_id
        LEFT JOIN sections sec ON sec.id = h.section_id
        LEFT JOIN staff st ON li.borrower_type='Staff' AND st.id = li.borrower_id
        WHERE $where
        ORDER BY li.due_date ASC
    ");
    while ($r = mysqli_fetch_assoc($q)) { $rows[] = $r; }
}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Return / Renew a Book</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f6f9; margin:0; padding: 12px; }
.wrap { max-width: 560px; margin: 0 auto; }
.deny-box { background:#fff; border-radius:14px; padding:30px 20px; text-align:center; box-shadow:0 2px 10px rgba(0,0,0,.08); }
.deny-box i { font-size:40px; color:#dc3545; margin-bottom:12px; }
.back-link { display:inline-flex; align-items:center; gap:6px; color:#0f5b8a; text-decoration:none; font-weight:600; font-size:13px; margin-bottom:12px; }
.page-title { font-size:18px; font-weight:800; color:#003366; margin-bottom:14px; display:flex; align-items:center; gap:8px; }

/* ===== Search/scan filter bar ===== */
.filter-card { background:#fff; border-radius:14px; padding:14px; margin-bottom:14px; box-shadow:0 2px 10px rgba(0,0,0,.06); }
.filter-row { display:flex; gap:8px; }
.filter-row input[type=text] { flex:1; padding:11px 14px; border:2px solid #e4edf6; border-radius:10px; font-size:14px; }
.filter-row button { padding:11px 16px; border:none; border-radius:10px; font-weight:700; font-size:13px; cursor:pointer; white-space:nowrap; }
.btn-search { background:#003366; color:#fff; }
.btn-scan { background:#22c55e; color:#fff; }
.filter-meta { display:flex; align-items:center; justify-content:space-between; margin-top:10px; font-size:12px; }
.filter-meta label { display:flex; align-items:center; gap:6px; color:#5a6b7a; }
.filter-meta a { color:#a4161a; text-decoration:none; font-weight:600; }
.scan-area { position:relative; border-radius:12px; overflow:hidden; background:#000; margin-top:10px; display:none; }
.scan-area video { width:100%; display:block; }
.scan-frame { position:absolute; inset:15%; border:3px solid #22c55e; border-radius:12px; box-shadow:0 0 0 999px rgba(0,0,0,0.35); }
.scan-stop { width:100%; margin-top:6px; padding:9px; border:none; border-radius:8px; background:#dc3545; color:#fff; font-weight:700; font-size:12px; display:none; }

/* ===== Issue cards ===== */
.issue-row { background:#fff; border-radius:14px; padding:14px 16px; margin-bottom:10px; box-shadow:0 2px 8px rgba(0,0,0,.05); display:flex; gap:12px; flex-wrap:wrap; align-items:center; }
.issue-row.overdue { border:1.5px solid #f1aeb5; background:#fff8f8; }
.issue-row img { width:38px; height:38px; border-radius:8px; object-fit:cover; background:#ddd; flex-shrink:0; }
.issue-info { flex:1; min-width:180px; }
.issue-info .bname { font-weight:700; color:#003366; font-size:13.5px; }
.issue-info .meta { font-size:11.5px; color:#6c7a8a; margin-top:2px; }
.due-box { text-align:center; min-width:88px; }
.due-box .label { font-size:9px; color:#6c7a8a; text-transform:uppercase; }
.due-box .val { font-weight:700; font-size:12px; }
.due-ontime { color:#155724; }
.due-late { color:#a4161a; }
.fine-badge { background:#f8d7da; color:#842029; padding:3px 8px; border-radius:8px; font-size:11px; font-weight:700; margin-top:4px; display:inline-block; }
.action-group { display:flex; gap:6px; flex-wrap:wrap; width:100%; margin-top:8px; }
.action-group button { flex:1; padding:8px; border:none; border-radius:8px; font-size:11.5px; font-weight:700; cursor:pointer; }
.btn-return { background:#22c55e; color:#fff; }
.btn-renew { background:#0f5b8a; color:#fff; }
.btn-renew:disabled { background:#ccc; cursor:not-allowed; }
.btn-lost { background:#dc3545; color:#fff; }
.fine-check { font-size:10.5px; color:#5a6b7a; display:flex; align-items:center; gap:4px; width:100%; margin-top:6px; }

.alert { padding:12px 16px; border-radius:10px; margin-bottom:14px; font-weight:600; font-size:13px; }
.alert-success { background:#d4edda; color:#155724; }
.alert-error { background:#f8d7da; color:#842029; }
.empty-note { text-align:center; color:#6c7a8a; font-size:13px; padding:30px 10px; }
</style>
</head>
<body>
<?php include("navbar.php"); ?>
<div class="wrap">

<?php if (!$is_librarian): ?>
    <div class="deny-box">
        <i class="fas fa-lock"></i>
        <h3 style="color:#003366;">Access Denied</h3>
        <p style="color:#6c7a8a; font-size:13px;">Only staff who have been granted Library Access can use this page.</p>
        <a href="dashboard.php" style="color:#0f5b8a; font-weight:600; text-decoration:none; font-size:13px;"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
    </div>
    </div>
</body>
</html>
<?php exit(); endif; ?>

<a href="library_dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i> Library Dashboard</a>
<div class="page-title"><i class="fas fa-undo-alt"></i> Return / Renew a Book</div>

<?php if (!empty($_SESSION['success'])): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div><?php endif; ?>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div><?php endif; ?>

<!-- ===== SEARCH / SCAN FILTER ===== -->
<div class="filter-card">
    <form method="GET" id="searchForm">
        <div class="filter-row">
            <input type="text" name="search" id="searchInput" placeholder="Search student/staff, book, or accession no..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn-search"><i class="fas fa-search"></i></button>
            <button type="button" class="btn-scan" id="btnScan" onclick="startScan()"><i class="fas fa-camera"></i></button>
        </div>
        <?php if ($overdue_only): ?><input type="hidden" name="overdue_only" value="1"><?php endif; ?>
    </form>
    <div class="scan-area" id="scanArea"><video id="video" playsinline></video><div class="scan-frame"></div></div>
    <button type="button" class="scan-stop" id="btnStopScan" onclick="stopScan()"><i class="fas fa-times"></i> Stop Camera</button>
    <div class="filter-meta">
        <label><input type="checkbox" onchange="toggleOverdue(this)" <?php echo $overdue_only?'checked':''; ?>> Overdue only</label>
        <?php if ($search !== '' || $overdue_only): ?><a href="library_return_scan.php"><i class="fas fa-times"></i> Clear filters</a><?php endif; ?>
    </div>
</div>

<!-- ===== LIST OF ISSUED BOOKS ===== -->
<?php if (empty($rows)): ?>
    <div class="empty-note"><i class="fas fa-check-circle" style="font-size:22px; color:#155724; display:block; margin-bottom:8px;"></i>
        <?php echo $search !== '' ? 'No matching issued books found.' : 'No books are currently issued.'; ?>
    </div>
<?php endif; ?>

<?php foreach ($rows as $row):
    $is_overdue = strtotime($row['due_date']) < strtotime(date('Y-m-d'));
    $fine_now = calc_current_fine($row['due_date'], $settings['fine_per_day']);
    $is_student = $row['borrower_type'] === 'Student';
    $bname = $is_student ? $row['student_name'] : $row['staff_name'];
    $bphoto = $is_student ? $row['student_photo'] : $row['staff_photo'];
    $photo_src = !empty($bphoto) ? '../uploads/' . ($is_student ? 'students/' : 'staff/') . $bphoto : '';
    $bmeta = $is_student
        ? trim(($row['class_name'] ?? '') . ' ' . ($row['section_name'] ?? '')) . (!empty($row['roll_no']) ? ' • Roll: ' . $row['roll_no'] : '')
        : ($row['designation'] ?? 'Staff');
?>
<div class="issue-row <?php echo $is_overdue ? 'overdue' : ''; ?>">
    <?php if ($photo_src): ?><img src="<?php echo htmlspecialchars($photo_src); ?>"><?php else: ?><div style="width:38px;height:38px;border-radius:8px;background:#eaf2fb;"></div><?php endif; ?>
    <div class="issue-info">
        <div class="bname"><?php echo htmlspecialchars($row['title']); ?> <small style="color:#6c7a8a; font-weight:400;">(<?php echo htmlspecialchars($row['accession_no']); ?>)</small></div>
        <div class="meta"><i class="fas fa-user"></i> <?php echo htmlspecialchars($bname ?? '(deleted)'); ?> — <?php echo htmlspecialchars($bmeta); ?></div>
    </div>
    <div class="due-box">
        <div class="label">Due</div>
        <div class="val <?php echo $is_overdue ? 'due-late' : 'due-ontime'; ?>"><?php echo date('d M Y', strtotime($row['due_date'])); ?></div>
        <?php if ($fine_now > 0): ?><div class="fine-badge">₹<?php echo number_format($fine_now, 2); ?></div><?php endif; ?>
    </div>
    <form method="POST" action="library_scan_action.php" class="action-group">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="issue_id" value="<?php echo $row['id']; ?>">
        <?php if ($fine_now > 0): ?>
        <label class="fine-check"><input type="checkbox" name="fine_paid" value="1"> Fine paid</label>
        <?php endif; ?>
        <button type="submit" name="return_book" class="btn-return" onclick="return confirm('Confirm this return?')">Return</button>
        <button type="submit" name="renew_book" class="btn-renew" <?php echo ((int)$row['renewal_count'] >= (int)$settings['max_renewals']) ? 'disabled' : ''; ?>>Renew</button>
        <button type="submit" name="mark_lost" class="btn-lost" onclick="return confirm('Mark as Lost? Fine will be ₹<?php echo number_format($row['price'],2); ?>')">Lost</button>
    </form>
</div>
<?php endforeach; ?>

</div>
<script>
function toggleOverdue(cb) {
    var form = document.getElementById('searchForm');
    var existing = form.querySelector('input[name="overdue_only"]');
    if (cb.checked) {
        if (!existing) {
            var inp = document.createElement('input');
            inp.type = 'hidden'; inp.name = 'overdue_only'; inp.value = '1';
            form.appendChild(inp);
        }
    } else if (existing) { existing.remove(); }
    form.submit();
}

// ================= QR/Barcode scan (native BarcodeDetector) — result becomes the search text =================
var stream = null;
function scanSupported() { return 'BarcodeDetector' in window; }
async function startScan() {
    if (!scanSupported()) { alert('Camera scanning is not supported in this browser — please type in the search box instead. (Usually works in the Chrome browser)'); return; }
    document.getElementById('scanArea').style.display = 'block';
    document.getElementById('btnScan').style.display = 'none';
    document.getElementById('btnStopScan').style.display = 'block';
    try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        var video = document.getElementById('video');
        video.srcObject = stream;
        await video.play();
        var detector = new BarcodeDetector({ formats: ['qr_code'] });
        var loop = async function () {
            if (!stream) return;
            try {
                var codes = await detector.detect(video);
                if (codes.length > 0) { stopScan(); handleScanResult(codes[0].rawValue); return; }
            } catch (e) {}
            requestAnimationFrame(loop);
        };
        loop();
    } catch (e) {
        alert('Camera access was not granted — check permissions, or type in the search box instead.');
        stopScan();
    }
}
function stopScan() {
    if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; }
    document.getElementById('scanArea').style.display = 'none';
    document.getElementById('btnScan').style.display = 'block';
    document.getElementById('btnStopScan').style.display = 'none';
}
function handleScanResult(code) {
    // Book QR (accession no) is already a clean search term — use directly.
    // ID Card QR is a verification URL — resolve it via library_lookup.php to get a readable name first.
    if (/^LIB-\d{4}-\d+$/i.test(code)) {
        document.getElementById('searchInput').value = code;
        document.getElementById('searchForm').submit();
        return;
    }
    fetch('library_lookup.php?code=' + encodeURIComponent(code))
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(data => {
            if (data.error) { alert(data.error); return; }
            var term = data.type === 'book' ? data.data.accession_no : data.data.name;
            document.getElementById('searchInput').value = term;
            document.getElementById('searchForm').submit();
        })
        .catch(err => { console.error('Scan lookup failed:', err); alert('Could not look up scanned code (' + err.message + ')'); });
}
</script>
</body>
</html>

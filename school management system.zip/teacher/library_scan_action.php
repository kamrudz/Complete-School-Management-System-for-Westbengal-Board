<?php
require_once 'auth.php';
require_teacher_login();
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
include("../includes/db.php");
require_once("../includes/security.php");
require_once("../includes/library_helper.php");

if (!is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)) {
    $_SESSION['error'] = "Access denied — you do not have library access.";
    header("Location: library_dashboard.php");
    exit();
}

verify_csrf_or_die();
$settings = get_library_settings($conn);
$librarian_staff_id = (int)($_SESSION['teacher_id'] ?? 0);

if (isset($_POST['issue_book'])) {
    $borrower_type = in_array($_POST['borrower_type'] ?? '', ['Student','Staff'], true) ? $_POST['borrower_type'] : 'Student';
    $borrower_id = library_borrower_id($borrower_type, $_POST['borrower_id'] ?? '');
    $copy_id = (int)$_POST['copy_id'];

    if (!valid_library_borrower($conn, $borrower_type, $borrower_id) || $copy_id <= 0) { $_SESSION['error']='Invalid borrower or book copy.'; header('Location: library_issue_scan.php'); exit(); }

    $limit = $borrower_type === 'Student' ? (int)$settings['max_books_per_student'] : (int)$settings['max_books_per_staff'];
    $active_count = count_active_issues($conn, $borrower_type, $borrower_id);
    if ($active_count >= $limit) {
        $_SESSION['error'] = "Maximum limit ($limit) reached — a book must be returned first.";
        header("Location: library_issue_scan.php");
        exit();
    }

    $copy = get_library_copy($conn, $copy_id);
    if (!$copy || $copy['status'] !== 'Available') {
        $_SESSION['error'] = "This copy is not currently available.";
        header("Location: library_issue_scan.php");
        exit();
    }

    $issue_date = date('Y-m-d');
    $due_date = date('Y-m-d', strtotime("+{$settings['loan_period_days']} days"));

    mysqli_begin_transaction($conn);
    try {
        $copy = get_library_copy($conn, $copy_id, true);
        if (!$copy || $copy['status'] !== 'Available') throw new RuntimeException('Copy unavailable');
        $stmt = mysqli_prepare($conn, "INSERT INTO library_issues (copy_id, borrower_type, borrower_id, issue_date, due_date, issued_by) VALUES (?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt, "issssi", $copy_id, $borrower_type, $borrower_id, $issue_date, $due_date, $librarian_staff_id);
        if (!mysqli_stmt_execute($stmt) || !set_library_copy_status($conn, $copy_id, 'Issued')) throw new RuntimeException('Issue failed');
        mysqli_commit($conn);
        $_SESSION['success'] = "Issued! {$copy['accession_no']} — Due date: " . date('d M Y', strtotime($due_date));
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $_SESSION['error'] = "Something went wrong.";
    }

} elseif (isset($_POST['return_book']) || isset($_POST['renew_book']) || isset($_POST['mark_lost'])) {
    $issue_id = (int)$_POST['issue_id'];
    $issue = get_open_library_issue($conn, $issue_id);

    if (!$issue) {
        $_SESSION['error'] = "Transaction not found.";
    } elseif (isset($_POST['return_book'])) {
        $today = date('Y-m-d');
        $fine = calc_current_fine($issue['due_date'], $settings['fine_per_day'], $today);
        $fine_paid = isset($_POST['fine_paid']) ? 1 : 0;
        mysqli_begin_transaction($conn);
        $issue = get_open_library_issue($conn, $issue_id, true);
        $stmt = mysqli_prepare($conn, "UPDATE library_issues SET return_date=?, fine_amount=?, fine_paid=?, status='Returned', returned_to=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "sdiii", $today, $fine, $fine_paid, $librarian_staff_id, $issue_id);
        if (!$issue || !mysqli_stmt_execute($stmt) || !set_library_copy_status($conn, $issue['copy_id'], 'Available')) { mysqli_rollback($conn); $_SESSION['error']='Return could not be completed.'; }
        else { mysqli_commit($conn);
        $_SESSION['success'] = "\"{$issue['title']}\" has been returned." . ($fine > 0 ? " Fine: ₹" . number_format($fine, 2) : ''); }
    } elseif (isset($_POST['renew_book'])) {
        if ((int)$issue['renewal_count'] >= (int)$settings['max_renewals']) {
            $_SESSION['error'] = "Maximum renewal limit reached.";
        } else {
            $new_due = date('Y-m-d', strtotime($issue['due_date'] . " +{$settings['loan_period_days']} days"));
            $stmt = mysqli_prepare($conn, "UPDATE library_issues SET due_date=?, renewal_count=renewal_count+1 WHERE id=?");
            mysqli_stmt_bind_param($stmt, "si", $new_due, $issue_id);
            mysqli_stmt_execute($stmt);
            $_SESSION['success'] = "Renewed — new due date: " . date('d M Y', strtotime($new_due));
        }
    } elseif (isset($_POST['mark_lost'])) {
        $today = date('Y-m-d');
        $fine = (float)$issue['price'];
        mysqli_begin_transaction($conn);
        $issue = get_open_library_issue($conn, $issue_id, true);
        $stmt = mysqli_prepare($conn, "UPDATE library_issues SET return_date=?, fine_amount=?, status='Lost' WHERE id=?");
        mysqli_stmt_bind_param($stmt, "sdi", $today, $fine, $issue_id);
        if (!$issue || !mysqli_stmt_execute($stmt) || !set_library_copy_status($conn, $issue['copy_id'], 'Lost')) { mysqli_rollback($conn); $_SESSION['error']='Lost-book update could not be completed.'; }
        else { mysqli_commit($conn);
        $_SESSION['success'] = "\"{$issue['title']}\" has been marked as Lost. Fine: ₹" . number_format($fine, 2); }
    }
}

// Issue lands back on the Issue page; Return/Renew/Lost land back on the Return page
if (isset($_POST['issue_book'])) {
    header("Location: library_issue_scan.php");
} else {
    header("Location: library_return_scan.php");
}
exit();

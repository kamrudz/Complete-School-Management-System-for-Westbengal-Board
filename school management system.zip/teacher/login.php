<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
if(isset($_SESSION['teacher_login']) && $_SESSION['teacher_login'] === true) {
    header("Location: dashboard.php"); exit();
}
require_once '../includes/db.php';
require_once '../includes/security.php';
require_once '../includes/login_attempts.php';
require_once '../includes/logger.php';

/**
 * Teacher / staff portal login. Username = State Govt ID (iOSMS / eHRMS employee id); only Active
 * staff with portal access (can_login) and a password. 5 wrong tries lock the account and
 * the IP for 15 minutes. A password the admin set with "must change" sends the user to
 * change_password.php first.
 */
$error = '';
$MAX_ATTEMPTS = 5; $LOCKOUT_MINUTES = 15;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf_or_die();
    $username = strtoupper(trim((string)($_POST['username'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $key_user = 'teacher:' . mb_substr($username, 0, 80); $key_ip = 'teacher-ip:' . $ip;
    if ($username === '' || $password === '') {
        $error = 'Please enter your Govt Employee ID and password.';
    } elseif (($m = max(login_locked_minutes($conn, $key_user), login_locked_minutes($conn, $key_ip))) > 0) {
        $error = "Too many wrong attempts. Try again in $m minute" . ($m > 1 ? 's' : '') . '.';
    } else {
        $staff = db_get_row('SELECT * FROM staff WHERE state_govt_id = ? LIMIT 1', 's', preg_replace('/\s+/', '', $username));
        $ok = $staff && $staff['service_status'] === 'Active' && (int)$staff['can_login'] === 1 && !empty($staff['login_password']) && password_verify($password, $staff['login_password']);
        if ($ok) {
            clear_login_attempts($conn, $key_user); clear_login_attempts($conn, $key_ip);
            if (password_needs_rehash($staff['login_password'], PASSWORD_DEFAULT)) db_update('staff', ['login_password' => password_hash($password, PASSWORD_DEFAULT)], ['id' => (int)$staff['id']], 'i');
            db_update('staff', ['last_login_at' => date('Y-m-d H:i:s')], ['id' => (int)$staff['id']], 'i');
            teacher_secure_login($staff);
            $_SESSION['teacher_pw_must_change'] = (int)$staff['pw_must_change'] === 1;
            header('Location: ' . ($_SESSION['teacher_pw_must_change'] ? 'change_password.php?first=1' : 'dashboard.php')); exit();
        }
        register_failed_attempt($conn, $key_user, $MAX_ATTEMPTS, $LOCKOUT_MINUTES);
        register_failed_attempt($conn, $key_ip, $MAX_ATTEMPTS * 4, $LOCKOUT_MINUTES);   // one IP guessing many accounts
        if ($staff && $staff['service_status'] === 'Active' && (int)$staff['can_login'] === 1 && empty($staff['login_password'])) $error = 'No password has been set for this account yet — ask the office.';
        elseif ($staff && ($staff['service_status'] !== 'Active' || (int)$staff['can_login'] !== 1)) $error = 'This account is not allowed to use the portal.';
        else $error = 'Invalid username or password.';
    }
}
$school = db_get_row('SELECT school_name, logo FROM school_settings LIMIT 1') ?: [];
$timeout = isset($_GET['timeout']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teacher Login — <?php echo htmlspecialchars($school['school_name'] ?? 'SchoolMS'); ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{min-height:100vh;background:linear-gradient(135deg,#0f1a2e 0%,#1a3a5c 50%,#0f2a45 100%);display:flex;align-items:center;justify-content:center;font-family:'Segoe UI',system-ui,sans-serif;padding:16px;}
.login-wrap{width:100%;max-width:420px;}
.school-header{text-align:center;margin-bottom:28px;}
.school-header .logo-img{width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid rgba(255,255,255,.25);margin-bottom:10px;}
.school-header .logo-icon{width:72px;height:72px;border-radius:50%;background:rgba(255,255,255,.1);display:inline-flex;align-items:center;justify-content:center;font-size:32px;color:#fff;margin-bottom:10px;}
.school-header h2{color:#fff;font-size:18px;font-weight:700;line-height:1.3;}
.school-header p{color:rgba(255,255,255,.6);font-size:13px;margin-top:4px;}
.card{background:#fff;border-radius:16px;padding:32px 28px;box-shadow:0 25px 60px rgba(0,0,0,.35);}
.card-title{font-size:22px;font-weight:800;color:#0f1a2e;margin-bottom:4px;display:flex;align-items:center;gap:10px;}
.card-title i{color:#1f5b8a;}
.card-sub{font-size:13px;color:#6c7a8a;margin-bottom:24px;}
.alert{padding:11px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:18px;display:flex;align-items:center;gap:8px;}
.alert-danger{background:#fef2f2;color:#991b1b;border:1px solid #fecaca;}
.alert-warning{background:#fffbeb;color:#92400e;border:1px solid #fde68a;}
.fg{margin-bottom:16px;}
.fg label{font-size:13px;font-weight:700;color:#1a2d4a;margin-bottom:6px;display:block;}
.input-wrap{position:relative;}
.input-wrap i.icon{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:#9aabb8;font-size:15px;}
.input-wrap input{width:100%;padding:11px 13px 11px 40px;border:2px solid #e5e7eb;border-radius:9px;font-size:14px;color:#1f2328;transition:all .2s;}
.input-wrap input:focus{outline:none;border-color:#1f5b8a;box-shadow:0 0 0 3px rgba(31,91,138,.12);}
.input-wrap .toggle-pw{position:absolute;right:13px;top:50%;transform:translateY(-50%);cursor:pointer;color:#9aabb8;font-size:15px;border:none;background:none;padding:2px;}
.input-wrap .toggle-pw:hover{color:#1f5b8a;}
.hint{font-size:11px;color:#9aabb8;margin-top:4px;}
.btn-login{width:100%;padding:13px;background:linear-gradient(135deg,#1f5b8a,#003366);color:#fff;border:none;border-radius:9px;font-size:15px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .3s;margin-top:6px;}
.btn-login:hover{background:linear-gradient(135deg,#2d75b0,#004a8f);transform:translateY(-2px);box-shadow:0 6px 20px rgba(31,91,138,.35);}
.footer-note{text-align:center;margin-top:20px;font-size:12px;color:rgba(255,255,255,.5);}
.footer-note a{color:rgba(255,255,255,.75);text-decoration:none;}
.footer-note a:hover{color:#fff;}
@media(max-width:480px){.card{padding:24px 18px;}}
</style>
</head>
<body>
<div class="login-wrap">
    <div class="school-header">
        <?php if(!empty($school['logo'])): ?>
            <img src="../uploads/<?php echo htmlspecialchars($school['logo']); ?>" class="logo-img" alt="Logo">
        <?php else: ?>
            <div class="logo-icon"><i class="fas fa-school"></i></div>
        <?php endif; ?>
        <h2><?php echo htmlspecialchars($school['school_name'] ?? 'School Management System'); ?></h2>
        <p>Teacher Portal</p>
    </div>

    <div class="card">
        <div class="card-title"><i class="fas fa-chalkboard-teacher"></i> Teacher Login</div>
        <div class="card-sub">Sign in with your Govt Employee ID (iOSMS / eHRMS)</div>

        <?php if($timeout): ?>
        <div class="alert alert-warning"><i class="fas fa-clock"></i> Session expired. Please login again.</div>
        <?php endif; ?>

        <?php if($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">
            <?php echo csrf_field(); ?>
            <div class="fg">
                <label>Govt Employee ID</label>
                <div class="input-wrap">
                    <i class="fas fa-id-badge icon"></i>
                    <input type="text" name="username" placeholder="State Govt (iOSMS / eHRMS) employee ID" autocomplete="username" autocapitalize="characters"
                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" autofocus>
                </div>
                <div class="hint">First-time password: Teacher@&lt;your birth year&gt; — you will be asked to change it</div>
            </div>
            <div class="fg">
                <label>Password</label>
                <div class="input-wrap">
                    <i class="fas fa-lock icon"></i>
                    <input type="password" name="password" id="pw" placeholder="Enter your password" autocomplete="current-password">
                    <button type="button" class="toggle-pw" onclick="togglePw()"><i class="fas fa-eye" id="pw-icon"></i></button>
                </div>
            </div>
            <button type="submit" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</button>
        </form>
    </div>

    <div class="footer-note">
        <a href="../admin/login.php"><i class="fas fa-shield-alt"></i> Admin Login</a>
        &nbsp;·&nbsp;
        Forgot password? Contact your administrator.
    </div>
</div>
<script>
function togglePw() {
    var pw = document.getElementById('pw');
    var ic = document.getElementById('pw-icon');
    if(pw.type === 'password') { pw.type = 'text'; ic.className = 'fas fa-eye-slash'; }
    else { pw.type = 'password'; ic.className = 'fas fa-eye'; }
}
</script>
</body>
</html>

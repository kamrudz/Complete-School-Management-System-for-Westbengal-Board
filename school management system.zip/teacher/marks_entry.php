<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/logger.php';
require_once '../includes/staff_helper.php';
require_once '../includes/section_groups.php';
require_once '../includes/user_access.php';
require_once '../includes/exam_helper.php';
if (!ua_can($conn, 'teacher', 'feature_marks_entry')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

/**
 * Marks Entry (V–X summative) for a teacher: the classes, sections and subjects the routine gives them. Each
 * student's marks are saved on their own as soon as a box is left or Absent is ticked (auto-save, see
 * assets/js/marks_autosave.js), through the same marks_save_rows() as the admin page — the same limits, decimals
 * and third-language rule — and only for the students of the teacher's own section (the whole pair in group-wise
 * routine mode).
 */
$tid = (int)$_SESSION['teacher_id'];
$session_id = exam_active_session_id();
$group_wise = get_routine_mode($conn) === 'group_wise';
$exam_classes = exam_classes();   // V–X; XI–XII have their own page

// the teacher's classes, sections and subjects, from the routine of the session
$my_classes = $my_sections = $my_subjects = [];
foreach (db_get_all('SELECT DISTINCT r.class_id, r.section_id, r.subject_id, c.class_name, s.section_name, sub.subject_name
        FROM routine r JOIN classes c ON c.id = r.class_id LEFT JOIN sections s ON s.id = r.section_id LEFT JOIN subjects sub ON sub.id = r.subject_id
        WHERE r.teacher_id = ? AND r.session_id = ? ORDER BY c.sort_order, s.section_name, sub.subject_name', 'ii', $tid, $session_id) as $r) {
    $cid = (int)$r['class_id'];
    if (!isset($exam_classes[$cid])) continue;
    $my_classes[$cid] = $r['class_name'];
    if ($r['section_id']) $my_sections[$cid][(int)$r['section_id']] = $r['section_name'];
    if ($r['subject_id']) $my_subjects[$cid][(int)$r['subject_id']] = $r['subject_name'];
}
if ($group_wise) {   // a section paired with one of the teacher's is taught together, so it is listed too
    foreach ($my_sections as $cid => $secs) foreach (array_keys($secs) as $sid) foreach (get_paired_section_ids($conn, $session_id, $cid, $sid) as $pair) {
        if (!isset($my_sections[$cid][$pair])) $my_sections[$cid][$pair] = (string)(db_get_row('SELECT section_name FROM sections WHERE id = ?', 'i', $pair)['section_name'] ?? '');
    }
}

$exams = [];
foreach (exam_list($session_id) as $e) $exams[(int)$e['id']] = $e;
$pick = fn(string $k) => (int)($_GET[$k] ?? $_POST[$k] ?? 0);
$exam_id = $pick('exam_id'); if (!isset($exams[$exam_id])) $exam_id = 0;
$class_id = $pick('class_id'); if (!isset($my_classes[$class_id])) $class_id = 0;
$section_id = $pick('section_id'); if (!isset($my_sections[$class_id][$section_id])) $section_id = 0;
$subject_id = $pick('subject_id'); if (!isset($my_subjects[$class_id][$subject_id])) $subject_id = 0;

// the sections this grid covers, and the routine must give the teacher this subject in one of them
$covered = $section_id ? ($group_wise ? get_paired_section_ids($conn, $session_id, $class_id, $section_id) : [$section_id]) : [];
$allowed = false;
foreach ($covered as $sid) if ($subject_id && teacher_can_access_class_section($tid, $session_id, $class_id, (int)$sid, $subject_id)) { $allowed = true; break; }
$subject = ($exam_id && $allowed) ? (exam_subjects($session_id, $exam_id, $class_id)[$subject_id] ?? null) : null;
$ready = (bool)$subject;
$listed = [];   // the students of this grid: the covered sections, and for a third language only those who chose it
if ($ready) foreach (exam_students($session_id, $class_id) as $uid => $st) {
    if (in_array($st['section_id'], $covered, true) && exam_student_takes($st, $subject)) $listed[$uid] = $st;
}
$here = 'marks_entry.php?' . http_build_query(['exam_id' => $exam_id, 'class_id' => $class_id, 'section_id' => $section_id, 'subject_id' => $subject_id]);

// auto-save: one student's marks, answered in JSON
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['autosave'])) {
    header('Content-Type: application/json');
    $out = function (array $a) { echo json_encode($a); exit; };
    if (!csrf_check((string)($_POST['csrf_token'] ?? ''))) $out(['ok' => false, 'error' => 'the page has expired — reload it']);
    if (!$ready) $out(['ok' => false, 'error' => 'you cannot enter marks for this subject here']);
    $uid = student_uid_clean($_POST['uid'] ?? '');
    if (!isset($listed[$uid])) $out(['ok' => false, 'error' => 'not a student of your section for this subject']);
    $row = ['written' => (string)($_POST['written'] ?? ''), 'project' => (string)($_POST['project'] ?? ''), 'absent' => !empty($_POST['absent'])];
    $r = marks_save_rows($session_id, $exam_id, $class_id, $subject_id, [$uid => $row], 0, false);
    if (!$r['ok']) $out(['ok' => false, 'error' => $r['errors'][$uid] ?? ($r['errors']['_'] ?? 'not saved')]);
    log_action(0, 'MARK_SAVED', 'marks', $exam_id, null, ['teacher_id' => $tid, 'uid' => $uid, 'class_id' => $class_id, 'subject_id' => $subject_id]
        + ($row['absent'] ? ['absent' => 1] : ['written' => $row['written'], 'project' => $row['project']]));
    $out(['ok' => true, 'cleared' => $r['cleared'] > 0]);
}

// the whole grid at once — only when the browser has no JavaScript (otherwise every row is auto-saved)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_marks'])) {
    verify_csrf_or_die();
    if (!$ready) { $_SESSION['error'] = '⚠️ আপনি এই Subject-এ Marks দেওয়ার অনুমতি রাখেন না।'; header("Location: $here"); exit(); }
    $rows = array_intersect_key((array)($_POST['m'] ?? []), $listed);   // this grid's students only
    $r = marks_save_rows($session_id, $exam_id, $class_id, $subject_id, $rows, 0);
    if ($r['ok']) $_SESSION['success'] = "✅ {$r['saved']} জন student-এর marks save হয়েছে" . ($r['cleared'] ? ", {$r['cleared']} টা মুছে দেওয়া হয়েছে" : '') . '।';
    else $_SESSION['error'] = '⚠️ কিছুই save হয়নি: ' . implode('; ', array_map(fn($k, $v) => ($k === '_' ? '' : "$k: ") . $v, array_keys($r['errors']), $r['errors']));
    header("Location: $here"); exit();
}

$marks = $ready ? exam_marks($session_id, $exam_id, $class_id, $subject_id) : [];
$has_project = $ready && exam_class_has_project($class_id) && $subject['project_full'] > 0;
$stored = function (string $uid) use ($marks, $subject_id, $has_project) {   // what the server has: [written, project, absent]
    $m = $marks[$uid][$subject_id] ?? null;
    if (!$m) return ['', '', 0];
    if ((int)$m['is_absent']) return ['', '', 1];
    return [exam_fmt($m['written_marks']), $has_project ? exam_fmt($m['project_marks']) : '', 0];
};
$show_section_col = count($covered) > 1;
$h = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Marks Entry — Teacher Portal</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;font-size:14px;}
.page-title{color:#003366;font-size:22px;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.page-title .sub{font-size:13px;font-weight:400;color:#6c7a8a;}
.card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;box-shadow:0 2px 10px rgba(0,0,0,.06);padding:20px 22px;margin-bottom:18px;}
.filter-row{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;min-width:140px;flex:1;}
.fg label{font-size:11px;font-weight:700;color:#1a3b55;text-transform:uppercase;letter-spacing:.3px;}
.fg select{padding:8px 10px;border:2px solid #d0dbe8;border-radius:7px;font-size:13px;background:#fff;width:100%;}
.fg select:focus{outline:none;border-color:#003366;}
.btn{display:inline-flex;align-items:center;gap:7px;padding:8px 18px;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;text-decoration:none;transition:all .2s;}
.btn-success{background:#28a745;color:#fff;} .btn-success:hover{background:#218838;}
.info-bar{background:linear-gradient(135deg,#e8f4ff,#f0f8ff);border:1px solid #c9e3ff;border-radius:10px;padding:10px 16px;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:14px;align-items:center;font-size:13px;color:#003366;}
.info-bar strong{color:#003366;} .info-bar i{color:#1f5b8a;}
.badge-fm{background:#003366;color:#fff;padding:3px 12px;border-radius:12px;font-size:11px;font-weight:600;}
.badge-proj{background:#f59e0b;color:#fff;padding:3px 12px;border-radius:12px;font-size:11px;font-weight:600;}
.table-wrap{overflow-x:auto;border-radius:10px;border:1px solid #e5e7eb;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.05);}
table{width:100%;border-collapse:collapse;font-size:13px;min-width:700px;}
thead{background:#003366;color:#fff;position:sticky;top:0;z-index:5;}
thead th{padding:10px 12px;text-align:left;font-size:11px;font-weight:600;white-space:nowrap;}
tbody tr{border-bottom:1px solid #f0f2f5;transition:background .15s;}
tbody tr:hover{background:#f8faff;}
tbody tr.absent-row{background:#fff5f5;}
tbody td{padding:8px 10px;vertical-align:middle;}
.roll-cell{font-weight:700;color:#003366;text-align:center;font-size:14px;}
.name-cell{font-weight:600;color:#1a3b55;}
.bsid-cell{font-size:11px;color:#1f5b8a;}
.mark-input{width:72px;padding:6px 8px;border:2px solid #d0dbe8;border-radius:6px;font-size:14px;text-align:center;font-weight:600;transition:border .2s;}
.mark-input:focus{outline:none;border-color:#003366;box-shadow:0 0 0 3px rgba(0,51,102,.1);}
.mark-input:disabled{background:#f5f5f5;color:#bbb;cursor:not-allowed;}
.mark-input.project-input{border-color:#f59e0b;}
.mark-input.bad{border-color:#dc3545;background:#fff0f0;}
.absent-cb{width:16px;height:16px;cursor:pointer;accent-color:#dc3545;}
.total-cell{font-weight:700;font-size:14px;color:#003366;text-align:center;}
td.sv{font-size:11px;font-weight:700;white-space:nowrap;min-width:60px;}
.sv-saving{color:#8a98a8;} .sv-saved,.sv-cleared{color:#1b7a3a;} .sv-failed,.sv-bad,.sv-offline{color:#b71c1c;white-space:normal !important;}
#svSum{font-size:12.5px;font-weight:700;} #svSum.sv-ok{color:#1b7a3a;} #svSum.sv-left{color:#b71c1c;}
.alert{padding:12px 16px;border-radius:9px;margin-bottom:16px;font-weight:600;display:flex;align-items:center;gap:10px;}
.alert-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
.alert-danger{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
.empty-state{text-align:center;padding:50px 20px;background:#f8f9fa;border-radius:12px;border:2px dashed #d0dbe8;}
.empty-state i{font-size:44px;color:#003366;opacity:.2;}
.empty-state h3{color:#003366;margin-top:12px;}
.empty-state p{color:#6c7a8a;font-size:13px;margin-top:5px;}
.save-bar{margin-top:18px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;}
.no-config{background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:12px 16px;color:#7d5c00;font-size:13px;}
@media(max-width:600px){.fg{min-width:100%;}.save-bar{flex-direction:column;}.mark-input{width:60px;}}
</style>
</head>
<body>
<?php include("navbar.php"); ?>

<div class="page-title">
    <i class="fas fa-pencil-alt"></i> Marks Entry
    <span class="sub">আমার Subject — আমার Class · প্রতিটা ঘর ছাড়লেই save হয়ে যায়</span>
</div>

<?php foreach (['success' => 'check-circle', 'error' => 'exclamation-circle'] as $k => $icon): if (isset($_SESSION[$k])): ?>
<div class="alert alert-<?php echo $k === 'error' ? 'danger' : 'success'; ?>"><i class="fas fa-<?php echo $icon; ?>"></i> <?php echo $h($_SESSION[$k]); unset($_SESSION[$k]); ?></div>
<?php endif; endforeach; ?>

<div class="card">
<form method="GET" id="filterForm">
<div class="filter-row">
    <div class="fg">
        <label><i class="fas fa-file-signature"></i> Exam</label>
        <select name="exam_id" onchange="this.form.submit()">
            <option value="">Select Exam</option>
            <?php foreach ($exams as $id => $ex): ?><option value="<?php echo $id; ?>"<?php echo $id === $exam_id ? ' selected' : ''; ?>><?php echo $h($ex['exam_name']); ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="fg">
        <label><i class="fas fa-chalkboard"></i> Class</label>
        <select name="class_id" onchange="this.form.section_id.value='';this.form.subject_id.value='';this.form.submit()">
            <option value="">Select Class</option>
            <?php foreach ($my_classes as $cid => $cname): ?><option value="<?php echo $cid; ?>"<?php echo $cid === $class_id ? ' selected' : ''; ?>>Class <?php echo $h($cname); ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="fg">
        <label><i class="fas fa-layer-group"></i> Section</label>
        <select name="section_id" onchange="this.form.submit()"<?php echo $class_id ? '' : ' disabled'; ?>>
            <option value="">Select Section</option>
            <?php foreach ($my_sections[$class_id] ?? [] as $sid => $sname): ?><option value="<?php echo $sid; ?>"<?php echo $sid === $section_id ? ' selected' : ''; ?>><?php echo $h($sname); ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="fg">
        <label><i class="fas fa-book"></i> Subject</label>
        <select name="subject_id" onchange="this.form.submit()"<?php echo $class_id ? '' : ' disabled'; ?>>
            <option value="">Select Subject</option>
            <?php foreach ($my_subjects[$class_id] ?? [] as $subid => $subname): ?><option value="<?php echo $subid; ?>"<?php echo $subid === $subject_id ? ' selected' : ''; ?>><?php echo $h($subname); ?></option><?php endforeach; ?>
        </select>
    </div>
</div>
</form>
</div>

<?php if (!$exam_id || !$class_id || !$section_id || !$subject_id): ?>
<div class="empty-state"><i class="fas fa-filter"></i><h3>Filter Select করুন</h3><p>উপরে Exam, Class, Section এবং Subject select করুন।</p></div>
<?php elseif (!$ready): ?>
<div class="no-config"><i class="fas fa-ban"></i> <strong>এই Section-এ এই Subject আপনার routine-এ নেই</strong>, অথবা subject-টা এই ক্লাসের পরীক্ষার তালিকায় নেই। Admin-কে জানান।</div>
<?php elseif (!$subject['configured']): ?>
<div class="no-config"><i class="fas fa-exclamation-triangle"></i> <strong>Marks Configuration নেই!</strong> এই Subject-এর Full Marks/Pass Marks admin এখনো set করেননি। Admin-কে জানান।</div>
<?php elseif (!$listed): ?>
<div class="empty-state"><i class="fas fa-user-graduate"></i><h3>কোনো Student পাওয়া যায়নি</h3><p>এই Section-এ এই subject-এর কোনো Active student নেই<?php echo $subject['tl'] ? ' (third language বেছে নেওয়া ছাত্রই শুধু দেখায়)' : ''; ?>।</p></div>
<?php else: ?>
<div class="info-bar">
    <span><i class="fas fa-file-signature"></i> <strong>Exam:</strong> <?php echo $h($exams[$exam_id]['exam_name']); ?></span>
    <span><i class="fas fa-chalkboard"></i> <strong>Class:</strong> <?php echo $h($my_classes[$class_id]); ?></span>
    <span><i class="fas fa-book"></i> <strong>Subject:</strong> <?php echo $h($subject['name']); ?></span>
    <span><i class="fas fa-users"></i> <strong>Students:</strong> <?php echo count($listed); ?></span>
    <span class="badge-fm">Written FM: <?php echo exam_fmt($subject['written_full']); ?></span>
    <?php if ($has_project): ?><span class="badge-proj">Project FM: <?php echo exam_fmt($subject['project_full']); ?></span><?php endif; ?>
</div>

<form method="POST" id="mf" autocomplete="off">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">
    <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
    <input type="hidden" name="section_id" value="<?php echo $section_id; ?>">
    <input type="hidden" name="subject_id" value="<?php echo $subject_id; ?>">
    <div class="table-wrap">
    <table id="grid">
        <thead><tr>
            <th style="width:40px;">#</th><th>Roll</th><?php if ($show_section_col): ?><th>Section</th><?php endif; ?><th>Student Name</th><th>BS ID</th>
            <th>Written <small>(Max: <?php echo exam_fmt($subject['written_full']); ?>)</small></th>
            <?php if ($has_project): ?><th>Project <small>(Max: <?php echo exam_fmt($subject['project_full']); ?>)</small></th><?php endif; ?>
            <th style="text-align:center;">Total</th><th style="text-align:center;"><i class="fas fa-user-slash"></i> Absent</th><th>Saved</th>
        </tr></thead>
        <tbody>
        <?php $sl = 1; foreach ($listed as $uid => $st): [$w, $p, $ab] = $stored($uid); ?>
        <tr data-uid="<?php echo $h($uid); ?>" data-saved="<?php echo $h(json_encode([$w, $p, $ab])); ?>" class="<?php echo $ab ? 'absent-row' : ''; ?>">
            <td style="color:#6c7a8a;font-size:12px;"><?php echo $sl++; ?></td>
            <td class="roll-cell"><?php echo $h($st['roll']); ?></td>
            <?php if ($show_section_col): ?><td><span style="background:#e8f4ff;color:#003366;padding:2px 10px;border-radius:12px;font-size:11px;font-weight:700;"><?php echo $h($st['section']); ?></span></td><?php endif; ?>
            <td class="name-cell"><?php echo $h($st['name']); ?></td>
            <td class="bsid-cell"><?php echo $h($st['bsid'] !== '' ? $st['bsid'] : '—'); ?></td>
            <td><input type="text" class="mark-input w" name="m[<?php echo $h($uid); ?>][written]" value="<?php echo $h($w); ?>" inputmode="decimal" data-max="<?php echo $subject['written_full']; ?>" placeholder="—"<?php echo $ab ? ' disabled' : ''; ?>></td>
            <?php if ($has_project): ?><td><input type="text" class="mark-input project-input p" name="m[<?php echo $h($uid); ?>][project]" value="<?php echo $h($p); ?>" inputmode="decimal" data-max="<?php echo $subject['project_full']; ?>" placeholder="—"<?php echo $ab ? ' disabled' : ''; ?>></td><?php endif; ?>
            <td class="total-cell tot"></td>
            <td style="text-align:center;"><input type="checkbox" class="absent-cb abx" name="m[<?php echo $h($uid); ?>][absent]" value="1"<?php echo $ab ? ' checked' : ''; ?> title="Absent"></td>
            <td class="sv"></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="save-bar">
        <button type="submit" name="save_marks" value="1" class="btn btn-success"><i class="fas fa-save"></i> Save rows not saved</button>
        <span id="svSum"></span>
        <span style="font-size:12px;color:#6c7a8a;"><i class="fas fa-keyboard"></i> Enter/↓ পরের ছাত্র · ↑ আগের ছাত্র · ফাঁকা = নম্বর নেই · Ctrl+S = না-হওয়া save</span>
    </div>
</form>
<?php endif; ?>

<script>
(function () {
    var rows = Array.prototype.slice.call(document.querySelectorAll('#grid tbody tr'));
    function row(tr) {   // absent, bad numbers and the total of one row
        var w = tr.querySelector('input.w'), p = tr.querySelector('input.p'), ab = tr.querySelector('input.abx').checked, tot = tr.querySelector('.tot');
        tr.classList.toggle('absent-row', ab); w.disabled = ab; if (p) p.disabled = ab;
        [w, p].forEach(function (i) { if (!i) return; var v = i.value.trim(); i.classList.toggle('bad', v !== '' && (!/^\d{1,3}(\.\d{1,2})?$/.test(v) || parseFloat(v) > parseFloat(i.dataset.max))); });
        if (ab) { tot.textContent = 'AB'; return; }
        var wv = w.value.trim(), pv = p ? p.value.trim() : '';
        tot.textContent = wv === '' && pv === '' ? '—' : Math.round(((parseFloat(wv) || 0) + (parseFloat(pv) || 0)) * 100) / 100;
    }
    rows.forEach(function (tr) {
        row(tr);
        tr.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', function () { row(tr); }); i.addEventListener('change', function () { row(tr); }); });
    });
    document.querySelectorAll('#grid input.mark-input').forEach(function (i) {   // Enter / arrows move down and up the same column
        i.addEventListener('keydown', function (e) {
            if (e.key !== 'Enter' && e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
            e.preventDefault();
            var cls = i.classList.contains('w') ? 'w' : 'p', dir = e.key === 'ArrowUp' ? -1 : 1, idx = rows.indexOf(i.closest('tr')) + dir;
            while (idx >= 0 && idx < rows.length) { var n = rows[idx].querySelector('input.' + cls); if (n && !n.disabled) { n.focus(); n.select(); return; } idx += dir; }
            i.blur();
        });
    });
    document.addEventListener('keydown', function (e) {   // Ctrl+S sends every row that is not saved yet
        if (e.ctrlKey && e.key === 's') { e.preventDefault(); var f = document.getElementById('mf'); if (f) f.requestSubmit ? f.requestSubmit() : f.dispatchEvent(new Event('submit', { cancelable: true })); }
    });
})();
</script>
<script src="../assets/js/marks_autosave.js"></script>
</body>
</html>

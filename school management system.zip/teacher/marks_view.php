<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/staff_helper.php';
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_marks_view')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$tid = (int)$_SESSION['teacher_id'];
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active_session['id'] ?? 0);

// My assigned classes
$my_classes = [];
if($session_id > 0) {
    $q = mysqli_query($conn,"SELECT DISTINCT cr.class_id, c.class_name FROM routine cr JOIN classes c ON cr.class_id=c.id WHERE cr.teacher_id='$tid' AND cr.session_id='$session_id' ORDER BY c.sort_order");
    while($r=mysqli_fetch_assoc($q)) $my_classes[] = $r;
}

$sel_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : ($my_classes[0]['class_id'] ?? 0);
$sel_exam  = isset($_GET['exam_id'])  ? (int)$_GET['exam_id']  : 0;

// Exams
$exams = [];
if($session_id > 0) {
    $q = mysqli_query($conn,"SELECT id, exam_name FROM exams WHERE session_id='$session_id' AND exam_type='v-x' ORDER BY exam_order ASC");
    while($r=mysqli_fetch_assoc($q)) $exams[] = $r;
}

// Subjects & marks for this class+exam
$subjects = [];
$marks_data = []; // [student_id][subject_id] = marks
$students_list = [];

if($sel_class > 0 && $sel_exam > 0 && $session_id > 0) {
    // Get exam subjects
    $sq = mysqli_query($conn,"SELECT ecs.subject_id, s.subject_name, esm.total_full_marks, esm.total_pass_marks FROM exam_class_subjects ecs JOIN subjects s ON ecs.subject_id=s.id LEFT JOIN exam_subject_marks esm ON esm.subject_id=ecs.subject_id AND esm.exam_id='$sel_exam' AND esm.class_id='$sel_class' WHERE ecs.session_id='$session_id' AND ecs.class_id='$sel_class' ORDER BY s.subject_name");
    while($r=mysqli_fetch_assoc($sq)) $subjects[] = $r;

    // Students
    $stq = mysqli_query($conn,"SELECT s.id, s.student_name, sah.roll_no FROM students s JOIN student_academic_history sah ON s.id=sah.student_id WHERE sah.session_id='$session_id' AND sah.class_id='$sel_class' AND sah.academic_status='Current' AND s.student_status='Active' ORDER BY CAST(sah.roll_no AS UNSIGNED) ASC");
    while($r=mysqli_fetch_assoc($stq)) $students_list[$r['id']] = $r;

    // Marks
    if(!empty($students_list)) {
        $mq = mysqli_query($conn,"SELECT student_id, subject_id, marks, is_absent FROM marks WHERE session_id='$session_id' AND class_id='$sel_class' AND exam_id='$sel_exam'");
        while($m=mysqli_fetch_assoc($mq)) $marks_data[$m['student_id']][$m['subject_id']] = $m;
    }
}
$class_info = $sel_class ? mysqli_fetch_assoc(mysqli_query($conn,"SELECT class_name FROM classes WHERE id='$sel_class'")) : null;
$exam_info  = $sel_exam  ? mysqli_fetch_assoc(mysqli_query($conn,"SELECT exam_name FROM exams WHERE id='$sel_exam'")) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Marks View</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.filter-bar{background:#fff;border-radius:10px;padding:14px 16px;border:1px solid #e5e7eb;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;}
.fg label{font-size:12px;font-weight:700;color:#1a2d4a;text-transform:uppercase;letter-spacing:.4px;}
.fg select{padding:8px 12px;border:1.5px solid #d0dbe8;border-radius:8px;font-size:13px;min-width:160px;}
.fg select:focus{outline:none;border-color:#1f5b8a;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 16px;border-radius:8px;font-weight:700;font-size:13px;border:none;cursor:pointer;text-decoration:none;transition:.2s;}
.btn-primary{background:#1f5b8a;color:#fff;}
.card{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.04);}
.card-head{padding:10px 16px;background:#003366;color:#fff;font-weight:700;font-size:14px;display:flex;align-items:center;gap:8px;}
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:12px;min-width:600px;}
th{background:#003366;color:#fff;padding:8px 10px;text-align:center;font-size:11px;white-space:nowrap;}
th.left{text-align:left;}
td{padding:7px 10px;border-bottom:1px solid #f0f2f5;text-align:center;vertical-align:middle;}
tr:hover td{background:#f8fbff;}
.roll-badge{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:2px 6px;border-radius:10px;}
.pass{color:#166534;font-weight:700;} .fail{color:#991b1b;font-weight:700;} .absent{color:#92400e;}
.fm-info{font-size:10px;color:rgba(255,255,255,.6);font-weight:400;}
.note-box{background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:12px 16px;font-size:13px;color:#7d5c00;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<h2><i class="fas fa-chart-bar"></i> Marks View</h2>

<div class="note-box"><i class="fas fa-info-circle"></i> This is a read-only view of exam marks. Contact admin to enter or edit marks.</div>

<form class="filter-bar" method="GET">
    <div class="fg">
        <label>Class</label>
        <select name="class_id" onchange="this.form.submit()">
            <option value="">Select Class</option>
            <?php foreach($my_classes as $cl): ?>
            <option value="<?php echo $cl['class_id']; ?>" <?php echo $sel_class==$cl['class_id']?'selected':''; ?>><?php echo htmlspecialchars('Class '.$cl['class_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="fg">
        <label>Exam</label>
        <select name="exam_id" onchange="this.form.submit()">
            <option value="">Select Exam</option>
            <?php foreach($exams as $ex): ?>
            <option value="<?php echo $ex['id']; ?>" <?php echo $sel_exam==$ex['id']?'selected':''; ?>><?php echo htmlspecialchars($ex['exam_name']); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-primary"><i class="fas fa-eye"></i> View</button>
</form>

<?php if($sel_class > 0 && $sel_exam > 0 && !empty($students_list) && !empty($subjects)): ?>
<div class="card">
    <div class="card-head"><i class="fas fa-table"></i>
        Class <?php echo htmlspecialchars($class_info['class_name']??''); ?> —
        <?php echo htmlspecialchars($exam_info['exam_name']??''); ?>
        <span style="margin-left:auto;font-size:13px;font-weight:400;"><?php echo count($students_list); ?> students · <?php echo count($subjects); ?> subjects</span>
    </div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr>
                <th class="left">Roll</th>
                <th class="left">Student Name</th>
                <?php foreach($subjects as $sub): ?>
                <th><?php echo htmlspecialchars($sub['subject_name']); ?><br>
                    <span class="fm-info">FM:<?php echo $sub['total_full_marks']??'-'; ?> PM:<?php echo $sub['total_pass_marks']??'-'; ?></span>
                </th>
                <?php endforeach; ?>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($students_list as $stu):
            $row_total = 0;
        ?>
        <tr>
            <td><span class="roll-badge"><?php echo htmlspecialchars($stu['roll_no']??'-'); ?></span></td>
            <td style="text-align:left;font-weight:600;"><?php echo htmlspecialchars($stu['student_name']); ?></td>
            <?php foreach($subjects as $sub):
                $mk = $marks_data[$stu['id']][$sub['subject_id']] ?? null;
                $obtained = $mk ? (float)$mk['marks'] : null;
                $pass_marks = (float)($sub['total_pass_marks'] ?? 0);
                $is_absent = $mk && $mk['is_absent'] == 1;
                if($obtained !== null && !$is_absent) $row_total += $obtained;
            ?>
            <td>
                <?php if($mk === null): ?>
                    <span style="color:#d0dbe8;">—</span>
                <?php elseif($is_absent): ?>
                    <span class="absent">AB</span>
                <?php else: ?>
                    <span class="<?php echo $obtained >= $pass_marks ? 'pass' : 'fail'; ?>"><?php echo number_format($obtained,0); ?></span>
                <?php endif; ?>
            </td>
            <?php endforeach; ?>
            <td style="font-weight:700;color:#003366;"><?php echo $row_total > 0 ? $row_total : '—'; ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
<?php elseif($sel_class > 0 && $sel_exam > 0): ?>
    <div style="text-align:center;padding:40px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;"><i class="fas fa-chart-bar" style="font-size:36px;display:block;margin-bottom:10px;opacity:.3;"></i>No marks data found</div>
<?php else: ?>
    <div style="text-align:center;padding:50px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;"><i class="fas fa-filter" style="font-size:36px;display:block;margin-bottom:12px;opacity:.3;"></i>Select Class and Exam to view marks</div>
<?php endif; ?>
</body>
</html>

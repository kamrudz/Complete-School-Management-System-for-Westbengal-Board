<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/user_access.php';
require_once '../includes/attendance_helper.php';
if (!ua_can($conn, 'teacher', 'feature_my_attendance')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$tid = (int)$_SESSION['teacher_id'];
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active_session['id'] ?? 0);

$sel_class   = isset($_GET['class_id'])   ? (int)$_GET['class_id']   : 0;
$sel_section = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$sel_date    = isset($_GET['att_date'])   ? $_GET['att_date'] : date('Y-m-d');

// Validate date
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/', $sel_date)) $sel_date = date('Y-m-d');

// My assigned classes (moved up so it can be used to authorize the save below —
// SECURITY FIX, audit finding 3.1: the save handler used to run before this
// check existed, so a teacher could POST any class_id/section_id and write
// attendance for classes they aren't assigned to teach.)
$my_classes = [];
if($session_id > 0) {
    $q = mysqli_query($conn, "
        SELECT DISTINCT cr.class_id, cr.section_id, c.class_name, s.section_name
        FROM routine cr
        JOIN classes c ON cr.class_id = c.id
        LEFT JOIN sections s ON cr.section_id = s.id
        WHERE cr.teacher_id = '$tid' AND cr.session_id = '$session_id'
        ORDER BY c.sort_order, s.section_name
    ");
    while($r = mysqli_fetch_assoc($q)) {
        $my_classes[$r['class_id'].'_'.($r['section_id']??0)] = $r;
    }
}

// SAVE ATTENDANCE
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {
    verify_csrf_or_die();
    $save_class   = (int)($_POST['class_id']   ?? 0);
    $save_section = (int)($_POST['section_id'] ?? 0);
    $save_date    = $_POST['att_date'] ?? date('Y-m-d');
    if(!preg_match('/^\d{4}-\d{2}-\d{2}$/', $save_date)) $save_date = date('Y-m-d');
    // No attendance on Sundays, holidays (holiday list) or future dates — same rule as the admin pages.
    if (($why = attendance_day_block($save_date)) !== '') {
        $_SESSION['error'] = 'Attendance is not taken on this day — ' . $why;
        header("Location: my_attendance.php?class_id=$save_class&section_id=$save_section&att_date=$save_date"); exit();
    }

    // SECURITY FIX: only allow saving attendance for a class/section this
    // teacher is actually assigned to (per the routine table), not whatever
    // class_id/section_id happens to be posted.
    if (!isset($my_classes[$save_class.'_'.$save_section])) {
        http_response_code(403);
        exit('You are not assigned to this class/section.');
    }

    $student_ids = $_POST['student_ids'] ?? [];
    $statuses    = $_POST['status']      ?? [];

    // SECURITY FIX: also restrict to students who are actually enrolled in
    // this class/section this session, so a posted student_ids[] list can't
    // be used to write attendance for students outside this roster.
    $valid_student_ids = [];
    $roster_cond = $save_section > 0 ? "AND sah.section_id='$save_section'" : '';
    $roster_q = mysqli_query($conn, "
        SELECT s.id FROM students s
        JOIN student_academic_history sah ON s.id = sah.student_id
        WHERE sah.session_id = '$session_id' AND sah.class_id = '$save_class'
          AND sah.academic_status = 'Current' AND s.student_status = 'Active'
          $roster_cond
    ");
    while ($r = mysqli_fetch_assoc($roster_q)) { $valid_student_ids[$r['id']] = true; }

    $saved = 0;
    foreach($student_ids as $i => $sid) {
        $sid    = student_uid_clean($sid);
        // Map Late/Holiday → Absent (DB enum শুধু Present/Absent/Leave সাপোর্ট করে)
        $raw_status = $statuses[$i] ?? 'Present';
        $status_map = ['Present'=>'Present','Absent'=>'Absent','Late'=>'Absent','Holiday'=>'Leave'];
        $status = $status_map[$raw_status] ?? 'Present';
        if($sid === '' || !isset($valid_student_ids[$sid])) continue;
        $existing = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT id FROM student_attendance WHERE student_id='$sid' AND attendance_date='$save_date' AND session_id='$session_id'"
        ));
        if($existing) {
            mysqli_query($conn, "UPDATE student_attendance SET status='$status' WHERE id='{$existing['id']}'");
        } else {
            mysqli_query($conn, "INSERT INTO student_attendance (student_id, session_id, class_id, section_id, attendance_date, status) VALUES ('$sid','$session_id','$save_class','$save_section','$save_date','$status')");
        }
        $saved++;
    }
    $_SESSION['success'] = "✅ Attendance saved for $saved student(s) on $save_date.";
    header("Location: my_attendance.php?class_id=$save_class&section_id=$save_section&att_date=$save_date");
    exit();
}

// Load students + existing attendance
$students = [];
if($sel_class > 0 && $session_id > 0) {
    $sec_cond = $sel_section > 0 ? "AND sah.section_id='$sel_section'" : '';
    $q = mysqli_query($conn, "
        SELECT s.id, s.student_name, s.gender, s.photo, sah.roll_no, sec.section_name,
               sa.status AS att_status
        FROM students s
        JOIN student_academic_history sah ON s.id = sah.student_id
        LEFT JOIN sections sec ON sah.section_id = sec.id
        LEFT JOIN student_attendance sa ON sa.student_id = s.id
            AND sa.attendance_date = '$sel_date' AND sa.session_id = '$session_id'
        WHERE sah.session_id = '$session_id' AND sah.class_id = '$sel_class'
          AND sah.academic_status = 'Current' AND s.student_status = 'Active'
          $sec_cond
        ORDER BY CAST(sah.roll_no AS UNSIGNED) ASC
    ");
    while($r = mysqli_fetch_assoc($q)) $students[] = $r;
}

$class_info = $sel_class > 0 ? mysqli_fetch_assoc(mysqli_query($conn, "SELECT class_name FROM classes WHERE id='$sel_class'")) : null;
$section_info = $sel_section > 0 ? mysqli_fetch_assoc(mysqli_query($conn, "SELECT section_name FROM sections WHERE id='$sel_section'")) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Attendance</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.alert{padding:11px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.alert-success{background:#dcfce7;color:#166534;border:1px solid #bbf7d0;}
.alert-danger{background:#fde2e4;color:#9d2630;border:1px solid #f5b5bb;}
.class-tabs{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px;}
.class-tab{padding:7px 16px;border-radius:20px;font-size:13px;font-weight:600;text-decoration:none;border:1.5px solid #d0dbe8;color:#1a3b55;background:#fff;transition:.2s;}
.class-tab:hover,.class-tab.active{background:#003366;color:#fff;border-color:#003366;}
.filter-bar{background:#fff;border-radius:10px;padding:14px 16px;border:1px solid #e5e7eb;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;}
.fg label{font-size:12px;font-weight:700;color:#1a2d4a;text-transform:uppercase;letter-spacing:.4px;}
.fg input,.fg select{padding:8px 12px;border:1.5px solid #d0dbe8;border-radius:8px;font-size:13px;}
.fg input:focus,.fg select:focus{outline:none;border-color:#1f5b8a;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 16px;border-radius:8px;font-weight:700;font-size:13px;border:none;cursor:pointer;text-decoration:none;transition:.2s;}
.btn-primary{background:#1f5b8a;color:#fff;} .btn-primary:hover{background:#003366;}
.btn-success{background:#22c55e;color:#fff;} .btn-success:hover{background:#16a34a;}
.card{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.04);}
.card-head{padding:10px 16px;background:#003366;color:#fff;display:flex;align-items:center;justify-content:space-between;}
.card-head h4{font-size:14px;font-weight:700;display:flex;align-items:center;gap:8px;}
.bulk-bar{padding:10px 14px;background:#f8fafc;border-bottom:1px solid #e5e7eb;display:flex;flex-wrap:wrap;gap:8px;align-items:center;}
.bulk-bar span{font-size:13px;font-weight:600;color:#1a2d4a;margin-right:4px;}
.bulk-btn{padding:5px 14px;border-radius:20px;font-size:12px;font-weight:700;border:1.5px solid;cursor:pointer;transition:.2s;}
.bulk-present{border-color:#22c55e;color:#166534;background:#dcfce7;} .bulk-present:hover{background:#22c55e;color:#fff;}
.bulk-absent{border-color:#ef4444;color:#991b1b;background:#fee2e2;} .bulk-absent:hover{background:#ef4444;color:#fff;}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{background:#f8fafc;padding:8px 12px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;color:#6c7a8a;border-bottom:1px solid #e5e7eb;}
td{padding:8px 12px;border-bottom:1px solid #f0f2f5;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
.roll-badge{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:2px 8px;border-radius:12px;}
.att-radio{display:flex;gap:8px;flex-wrap:wrap;}
.att-radio label{display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid;transition:.2s;}
.att-radio input[type=radio]{display:none;}
.r-present{border-color:#22c55e;color:#166534;} .r-present:has(input:checked){background:#22c55e;color:#fff;}
.r-absent{border-color:#ef4444;color:#991b1b;} .r-absent:has(input:checked){background:#ef4444;color:#fff;}
.r-late{border-color:#f59e0b;color:#92400e;} .r-late:has(input:checked){background:#f59e0b;color:#fff;}
.save-bar{padding:14px 16px;background:#f8fafc;border-top:1px solid #e5e7eb;display:flex;gap:10px;}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<h2><i class="fas fa-clipboard-check"></i> Student Attendance</h2>

<?php if(isset($_SESSION['error'])): ?>
<div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
<?php endif; ?>
<?php if(isset($_SESSION['success'])): ?>
<div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
<?php endif; ?>

<!-- Class Tabs -->
<div class="class-tabs">
    <?php foreach($my_classes as $cl):
        $is_active = ($sel_class == $cl['class_id'] && $sel_section == ($cl['section_id']??0));
    ?>
    <a href="my_attendance.php?class_id=<?php echo $cl['class_id']; ?>&section_id=<?php echo $cl['section_id']??0; ?>&att_date=<?php echo $sel_date; ?>"
       class="class-tab <?php echo $is_active?'active':''; ?>">
        Class <?php echo htmlspecialchars($cl['class_name']); ?>
        <?php if(!empty($cl['section_name'])): ?> - <?php echo htmlspecialchars($cl['section_name']); ?><?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- Date Filter -->
<form class="filter-bar" method="GET">
    <?php if($sel_class): ?><input type="hidden" name="class_id" value="<?php echo $sel_class; ?>">
    <input type="hidden" name="section_id" value="<?php echo $sel_section; ?>"><?php endif; ?>
    <div class="fg">
        <label>Date</label>
        <input type="date" name="att_date" value="<?php echo htmlspecialchars($sel_date); ?>" max="<?php echo date('Y-m-d'); ?>">
    </div>
    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Load</button>
</form>

<?php $block = attendance_day_block($sel_date); if ($block !== ''): ?>
<div class="alert alert-danger"><i class="fas fa-calendar-times"></i> No attendance on <b><?php echo date('d M Y', strtotime($sel_date)); ?></b> — <?php echo htmlspecialchars($block); ?></div>
<?php elseif($sel_class > 0 && !empty($students)): ?>
<form method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="class_id" value="<?php echo $sel_class; ?>">
    <input type="hidden" name="section_id" value="<?php echo $sel_section; ?>">
    <input type="hidden" name="att_date" value="<?php echo htmlspecialchars($sel_date); ?>">

    <div class="card">
        <div class="card-head">
            <h4><i class="fas fa-list"></i>
                Class <?php echo htmlspecialchars($class_info['class_name']??''); ?>
                <?php if($section_info): ?> — <?php echo htmlspecialchars($section_info['section_name']); ?><?php endif; ?>
                — <?php echo date('d M Y', strtotime($sel_date)); ?>
            </h4>
            <span style="font-size:13px;"><?php echo count($students); ?> students</span>
        </div>
        <div class="bulk-bar">
            <span>Bulk Mark:</span>
            <button type="button" class="bulk-btn bulk-present" onclick="bulkMark('Present')"><i class="fas fa-check"></i> All Present</button>
            <button type="button" class="bulk-btn bulk-absent" onclick="bulkMark('Absent')"><i class="fas fa-times"></i> All Absent</button>
        </div>
        <table>
            <thead><tr><th>#</th><th>Roll</th><th>Student Name</th><th>Gender</th><th>Attendance</th></tr></thead>
            <tbody>
            <?php $sl=1; foreach($students as $st): $cur = $st['att_status'] ?: 'Present'; ?>
            <tr>
                <td style="color:#9aabb8;font-size:12px;"><?php echo $sl++; ?></td>
                <td><span class="roll-badge"><?php echo htmlspecialchars($st['roll_no']??'-'); ?></span></td>
                <td style="font-weight:600;"><?php echo htmlspecialchars($st['student_name']); ?></td>
                <td style="font-size:12px;color:#6c7a8a;"><?php echo htmlspecialchars($st['gender']??''); ?></td>
                <td>
                    <input type="hidden" name="student_ids[]" value="<?php echo $st['id']; ?>">
                    <div class="att-radio">
                        <label class="r-present"><input type="radio" name="status[<?php echo $sl-2; ?>]" value="Present" <?php echo $cur==='Present'?'checked':''; ?>> ✓ Present</label>
                        <label class="r-absent"><input type="radio" name="status[<?php echo $sl-2; ?>]" value="Absent" <?php echo $cur==='Absent'?'checked':''; ?>> ✗ Absent</label>
                        <label class="r-late"><input type="radio" name="status[<?php echo $sl-2; ?>]" value="Late" <?php echo $cur==='Late'?'checked':''; ?>> ⏰ Late</label>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <div class="save-bar">
            <button type="submit" name="save_attendance" class="btn btn-success"><i class="fas fa-save"></i> Save Attendance</button>
        </div>
    </div>
</form>
<?php elseif($sel_class > 0): ?>
    <div style="text-align:center;padding:40px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;">
        <i class="fas fa-users" style="font-size:36px;display:block;margin-bottom:10px;opacity:.3;"></i>No students found
    </div>
<?php else: ?>
    <div style="text-align:center;padding:50px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;">
        <i class="fas fa-hand-pointer" style="font-size:36px;display:block;margin-bottom:12px;"></i>Select a class tab above
    </div>
<?php endif; ?>

<script>
function bulkMark(status) {
    var radios = document.querySelectorAll('input[type=radio][value="'+status+'"]');
    radios.forEach(function(r){ r.checked = true; });
}
</script>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/section_groups.php';
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_my_routine')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$tid = (int)$_SESSION['teacher_id'];
$active_session = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1"));
$session_id = (int)($active_session['id'] ?? 0);

$days  = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
$today = date('l');

$routine_mode = get_routine_mode($conn);

$routine = [];
if($session_id > 0) {
    $q = mysqli_query($conn, "
        SELECT cr.*, c.class_name, s.section_name, sub.subject_name, p.period_name, p.start_time, p.end_time
        FROM routine cr
        JOIN classes c ON cr.class_id = c.id
        LEFT JOIN sections s ON cr.section_id = s.id
        LEFT JOIN subjects sub ON cr.subject_id = sub.id
        LEFT JOIN periods p ON cr.period_id = p.id
        WHERE cr.teacher_id = '$tid' AND cr.session_id = '$session_id'
        ORDER BY FIELD(cr.day_name,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'), p.start_time ASC
    ");
    while($r = mysqli_fetch_assoc($q)) {
        $routine[$r['day_name']][] = $r;
    }
}

// group_wise mode: paired section-এর নাম routine-এ দেখানোর জন্য build করো
// e.g. "A" → "A + B" (display only)
$section_pair_label = []; // section_id → display label
if ($routine_mode === 'group_wise' && $session_id > 0) {
    // Collect all unique section_ids from this teacher's routine
    $sec_ids_in_routine = [];
    foreach ($routine as $day_entries) {
        foreach ($day_entries as $entry) {
            if ($entry['section_id']) $sec_ids_in_routine[$entry['section_id']] = true;
        }
    }
    foreach (array_keys($sec_ids_in_routine) as $sid) {
        // Find what class this section belongs to
        $sc = mysqli_fetch_assoc(mysqli_query($conn, "SELECT class_id FROM sections WHERE id='$sid' LIMIT 1"));
        if (!$sc) continue;
        $paired = get_paired_section_ids($conn, $session_id, $sc['class_id'], $sid);
        if (count($paired) > 1) {
            // Build combined label: "A + B"
            $pnames = [];
            foreach ($paired as $psid) {
                $psr = mysqli_fetch_assoc(mysqli_query($conn, "SELECT section_name FROM sections WHERE id='$psid' LIMIT 1"));
                if ($psr) $pnames[] = $psr['section_name'];
            }
            $section_pair_label[$sid] = implode(' + ', $pnames);
        }
    }
}
$school = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM school_settings WHERE id=1"));
$school_name = $school['school_name'] ?? '';
$school_address = $school['school_address'] ?? '';
$school_logo = $school['logo'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Routine</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.day-card{background:#fff;border-radius:10px;border:1px solid #e5e7eb;margin-bottom:14px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.04);}
.day-head{padding:10px 16px;display:flex;align-items:center;gap:10px;font-weight:700;font-size:14px;color:#fff;background:#1f5b8a;}
.day-head.today{background:#003366;border-left:4px solid #f59e0b;}
.day-head .today-badge{background:#f59e0b;color:#fff;font-size:10px;padding:2px 8px;border-radius:20px;font-weight:700;}
.day-empty{padding:12px 16px;color:#9aabb8;font-size:13px;font-style:italic;}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{background:#f8fafc;padding:8px 12px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;color:#6c7a8a;border-bottom:1px solid #e5e7eb;}
td{padding:9px 12px;border-bottom:1px solid #f0f2f5;color:#1f2328;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
.class-tag{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;white-space:nowrap;}
.subj{font-weight:600;color:#0f1a2e;}
@media print {
    body{background:#fff;padding:0;margin:0;}
    .main-navbar-2tier,.nav-toggle,.nav-row1,.nav-row2,nav,h2,.day-tabs,.print-hide{display:none !important;}
    .print-header{display:flex !important;}
    .page-box{box-shadow:none;padding:0;max-width:100%;}
    table{width:100% !important;border-collapse:collapse;font-size:14px !important;}
    thead tr{background:#003366 !important;}
    thead th{background:#003366 !important;color:#fff !important;padding:10px 14px !important;font-size:13px !important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
    tbody td{padding:10px 14px !important;font-size:13px !important;border:1px solid #ccc !important;}
    tbody td:first-child{background:#f0f4f9 !important;font-weight:700 !important;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
    @page{size:A4 landscape;margin:10mm 12mm;}
}
.print-header{display:none;align-items:center;gap:10px;margin-bottom:12px;padding-bottom:8px;border-bottom:2px solid #003366;}
.print-header h1{font-size:17px;color:#003366;text-transform:uppercase;}
.print-header .sub{font-size:12px;color:#333;margin-top:2px;}
.print-header .logo{width:55px;height:55px;object-fit:contain;}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<div class="print-header">
    <?php if(!empty($school_logo)): ?>
    <div style="flex-shrink:0;width:55px;height:55px;display:flex;align-items:center;justify-content:center;">
        <img src="../uploads/<?php echo htmlspecialchars($school_logo); ?>" alt="Logo" style="max-width:55px;max-height:55px;object-fit:contain;">
    </div>
    <?php endif; ?>
    <div style="flex:1;">
        <h1><?php echo htmlspecialchars($school_name ?: 'School Name'); ?></h1>
        <?php if(!empty($school_address)): ?><div style="font-size:10px;color:#333;margin:1px 0;"><?php echo htmlspecialchars($school_address); ?><?php echo !empty($school['established_year']) ? ' · Estd. ' . (int)$school['established_year'] : ''; ?></div><?php endif; ?>
        <div style="font-size:14px;font-weight:700;color:#003366;margin-top:5px;">CLASS ROUTINE — Teacher: <?php echo htmlspecialchars($_SESSION['teacher_name'] ?? $_SESSION['staff_name'] ?? ''); ?> | Session: <?php echo htmlspecialchars($active_session['session_name'] ?? ''); ?></div>
    </div>
</div>
<h2><i class="fas fa-calendar-alt"></i> My Class Routine
    <span style="font-size:13px;font-weight:400;color:#6c7a8a;margin-left:8px;"><?php echo htmlspecialchars($active_session['session_name'] ?? ''); ?></span>
</h2>

<?php if(empty($routine)): ?>
    <div style="text-align:center;padding:50px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;">
        <i class="fas fa-calendar-times" style="font-size:40px;display:block;margin-bottom:12px;"></i>
        No routine assigned yet. Contact admin to set up your class routine.
    </div>
<?php else: ?>
    <?php
    // Collect all periods from routine data
    $all_periods = [];
    foreach($routine as $day_entries) {
        foreach($day_entries as $entry) {
            if(!isset($all_periods[$entry['period_name']])) {
                $all_periods[$entry['period_name']] = [
                    'period_name' => $entry['period_name'],
                    'start_time'  => $entry['start_time'],
                    'end_time'    => $entry['end_time'],
                ];
            }
        }
    }
    // Sort periods by start_time
    usort($all_periods, function($a, $b) {
        return strtotime($a['start_time']) - strtotime($b['start_time']);
    });
    ?>
    <div style="overflow-x:auto;background:#fff;border-radius:10px;border:1px solid #e5e7eb;">
    <table style="width:100%;border-collapse:collapse;font-size:13px;">
        <thead>
            <tr style="background:#003366;color:#fff;">
                <th style="padding:10px 12px;text-align:left;font-size:12px;min-width:100px;"><i class="fas fa-calendar-day"></i> Day</th>
                <?php foreach($all_periods as $p): ?>
                <th style="padding:10px 12px;text-align:center;font-size:12px;white-space:nowrap;">
                    <i class="fas fa-clock"></i> <?php echo htmlspecialchars($p['period_name']); ?>
                    <br><small style="font-weight:400;opacity:.8;">
                        <?php echo $p['start_time'] ? date('h:i A', strtotime($p['start_time'])) : ''; ?>
                        –
                        <?php echo $p['end_time'] ? date('h:i A', strtotime($p['end_time'])) : ''; ?>
                    </small>
                </th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
        <?php foreach($days as $day):
            $is_today = ($day === $today);
        ?>
        <tr style="border-bottom:1px solid #f0f2f5;<?php echo $is_today ? 'background:#f0fff4;' : ''; ?>">
            <td style="padding:10px 12px;font-weight:700;color:#003366;background:<?php echo $is_today ? '#f0fff4' : '#f8f9fa'; ?>;">
                <?php echo $day; ?>
                <?php if($is_today): ?><br><span style="font-size:9px;background:#f59e0b;color:#fff;padding:1px 6px;border-radius:10px;font-weight:700;">TODAY</span><?php endif; ?>
            </td>
            <?php foreach($all_periods as $p):
                // Find entries for this day+period
                $found = [];
                if(!empty($routine[$day])) {
                    foreach($routine[$day] as $entry) {
                        if($entry['period_name'] === $p['period_name']) {
                            $found[] = $entry;
                        }
                    }
                }
            ?>
            <td style="padding:8px 10px;text-align:center;vertical-align:middle;<?php echo $is_today ? 'background:#f0fff4;' : ''; ?>">
                <?php if(!empty($found)): ?>
                    <?php foreach($found as $idx => $entry): ?>
                    <?php if($idx > 0): ?><hr style="border:none;border-top:1px dashed #f59e0b;margin:4px 0;"><?php endif; ?>
                    <div style="font-weight:600;color:#1a3b55;font-size:13px;">
                        <?php
                        $sec_display = $entry['section_name'] ?? '';
                        if ($sec_display && isset($section_pair_label[$entry['section_id']])) {
                            $sec_display = $section_pair_label[$entry['section_id']];
                        }
                        ?>
                        <?php echo htmlspecialchars($entry['class_name'] . ($sec_display ? ' - ' . $sec_display : '')); ?>
                    </div>
                    <div style="font-weight:500;color:#0f1a2e;font-size:12px;margin-top:2px;">
                        <?php echo htmlspecialchars($entry['subject_name'] ?? ''); ?>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span style="color:#c5cdd8;">-</span>
                <?php endif; ?>
            </td>
            <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
<?php endif; ?>
</body>
</html>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/staff_helper.php';
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_my_students')) { header("Location: dashboard.php?msg=access_denied"); exit(); }
$tid = (int)($_SESSION['teacher_id'] ?? 0);
$active_session = db_get_row("SELECT * FROM academic_sessions WHERE status='Active' LIMIT 1");
$session_id = (int)($active_session['id'] ?? 0);

// Get distinct classes assigned to this teacher
$my_classes = [];
if($session_id > 0) {
    $q = mysqli_query($conn, "
        SELECT DISTINCT cr.class_id, cr.section_id, c.class_name, s.section_name
        FROM routine cr
        JOIN classes c ON cr.class_id = c.id
        LEFT JOIN sections s ON cr.section_id = s.id
        WHERE cr.teacher_id = '$tid' AND cr.session_id = '$session_id'
        ORDER BY c.sort_order, s.section_name
    ");
    while($r = mysqli_fetch_assoc($q)) {
        $key = $r['class_id'].'_'.($r['section_id'] ?? 0);
        $my_classes[$key] = $r;
    }
}

$sel_class   = isset($_GET['class_id'])   ? (int)$_GET['class_id']   : 0;
$sel_section = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$search      = trim($_GET['search'] ?? '');

$students = [];
if($sel_class > 0 && $session_id > 0) {
    if (!teacher_can_access_class_section($tid, $session_id, $sel_class, $sel_section)) {
        $_SESSION['error'] = 'You do not have access to that class/section.';
        header('Location: my_students.php'); exit();
    }
    $sql = "SELECT s.id, s.student_name, s.gender, s.banglarshiksha_id, s.photo,
                   sah.roll_no, sec.section_name, g.father_name
            FROM students s
            JOIN student_academic_history sah ON s.id = sah.student_id
            LEFT JOIN sections sec ON sah.section_id = sec.id
            LEFT JOIN guardians g ON s.guardian_id = g.guardian_id
            WHERE sah.session_id = ? AND sah.class_id = ?
              AND sah.academic_status = 'Current' AND s.student_status = 'Active'";
    $types = 'ii'; $params = [$session_id, $sel_class];
    if ($sel_section > 0) { $sql .= ' AND sah.section_id = ?'; $types .= 'i'; $params[] = $sel_section; }
    if ($search !== '') { $sql .= ' AND (s.student_name LIKE ? OR CAST(sah.roll_no AS CHAR) LIKE ?)'; $types .= 'ss'; $like='%'.$search.'%'; $params[]=$like; $params[]=$like; }
    $sql .= ' ORDER BY CAST(sah.roll_no AS UNSIGNED) ASC';
    $students = db_get_all($sql, $types, ...$params);
}

// Class name for header
$class_info = $sel_class > 0 ? db_get_row('SELECT class_name FROM classes WHERE id=?', 'i', $sel_class) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Students</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.filter-bar{background:#fff;border-radius:10px;padding:16px 18px;border:1px solid #e5e7eb;margin-bottom:16px;display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;}
.fg{display:flex;flex-direction:column;gap:4px;}
.fg label{font-size:12px;font-weight:700;color:#1a2d4a;text-transform:uppercase;letter-spacing:.4px;}
.fg select,.fg input{padding:8px 12px;border:1.5px solid #d0dbe8;border-radius:8px;font-size:13px;min-width:150px;}
.fg select:focus,.fg input:focus{outline:none;border-color:#1f5b8a;}
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 18px;border-radius:8px;font-weight:700;font-size:13px;border:none;cursor:pointer;text-decoration:none;transition:.2s;}
.btn-primary{background:#1f5b8a;color:#fff;} .btn-primary:hover{background:#003366;}
.card{background:#fff;border-radius:10px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.04);}
.card-head{padding:10px 16px;background:#003366;color:#fff;display:flex;align-items:center;justify-content:space-between;}
.card-head h4{font-size:14px;font-weight:700;display:flex;align-items:center;gap:8px;}
table{width:100%;border-collapse:collapse;font-size:13px;}
th{background:#f8fafc;padding:8px 12px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;color:#6c7a8a;border-bottom:1px solid #e5e7eb;}
td{padding:9px 12px;border-bottom:1px solid #f0f2f5;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#f8fbff;}
.avatar{width:30px;height:30px;border-radius:50%;object-fit:cover;border:1.5px solid #e5e7eb;}
.avatar-placeholder{width:30px;height:30px;border-radius:50%;background:#e8f4ff;color:#1f5b8a;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;}
.roll-badge{background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:2px 8px;border-radius:12px;}
.gender-m{color:#1565c0;font-weight:600;} .gender-f{color:#c2185b;font-weight:600;}
.class-tabs{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;}
.class-tab{padding:7px 16px;border-radius:20px;font-size:13px;font-weight:600;text-decoration:none;border:1.5px solid #d0dbe8;color:#1a3b55;background:#fff;transition:.2s;}
.class-tab:hover,.class-tab.active{background:#003366;color:#fff;border-color:#003366;}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<h2><i class="fas fa-user-graduate"></i> My Students</h2>

<!-- Class Tabs -->
<?php if(!empty($my_classes)): ?>
<div class="class-tabs">
    <?php foreach($my_classes as $key => $cl):
        $is_active = ($sel_class == $cl['class_id'] && $sel_section == ($cl['section_id'] ?? 0));
    ?>
    <a href="my_students.php?class_id=<?php echo $cl['class_id']; ?>&section_id=<?php echo $cl['section_id'] ?? 0; ?>"
       class="class-tab <?php echo $is_active ? 'active' : ''; ?>">
        Class <?php echo htmlspecialchars($cl['class_name']); ?>
        <?php if(!empty($cl['section_name'])): ?> - <?php echo htmlspecialchars($cl['section_name']); ?><?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Search -->
<?php if($sel_class > 0): ?>
<form class="filter-bar" method="GET">
    <input type="hidden" name="class_id" value="<?php echo $sel_class; ?>">
    <input type="hidden" name="section_id" value="<?php echo $sel_section; ?>">
    <div class="fg">
        <label>Search</label>
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name or Roll No...">
    </div>
    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
    <?php if($search): ?><a href="my_students.php?class_id=<?php echo $sel_class; ?>&section_id=<?php echo $sel_section; ?>" class="btn" style="background:#f0f4f9;color:#6c7a8a;">Clear</a><?php endif; ?>
</form>
<?php endif; ?>

<!-- Student Table -->
<?php if($sel_class > 0): ?>
<div class="card">
    <div class="card-head">
        <h4><i class="fas fa-list"></i>
            Class <?php echo htmlspecialchars($class_info['class_name'] ?? ''); ?>
            <?php if($sel_section > 0): ?> — <?php $sn = mysqli_fetch_assoc(mysqli_query($conn,"SELECT section_name FROM sections WHERE id='$sel_section'")); echo htmlspecialchars($sn['section_name']??''); ?><?php endif; ?>
        </h4>
        <span style="font-size:13px;font-weight:400;"><?php echo count($students); ?> students</span>
    </div>
    <?php if(empty($students)): ?>
        <div style="text-align:center;padding:30px;color:#9aabb8;font-size:13px;"><i class="fas fa-users" style="display:block;font-size:32px;margin-bottom:8px;opacity:.3;"></i> No students found</div>
    <?php else: ?>
    <table>
        <thead>
            <tr><th>#</th><th>Photo</th><th>Roll</th><th>Student Name</th><th>BS ID</th><th>Father Name</th><th>Gender</th><th>Section</th></tr>
        </thead>
        <tbody>
        <?php $sl = 1; foreach($students as $st): ?>
        <tr>
            <td style="color:#9aabb8;font-size:12px;"><?php echo $sl++; ?></td>
            <td>
                <?php if(!empty($st['photo'])): ?>
                    <img src="../uploads/students/<?php echo htmlspecialchars($st['photo']); ?>" class="avatar">
                <?php else: ?>
                    <div class="avatar-placeholder"><?php echo strtoupper(substr($st['student_name'],0,1)); ?></div>
                <?php endif; ?>
            </td>
            <td><span class="roll-badge"><?php echo htmlspecialchars($st['roll_no'] ?? '-'); ?></span></td>
            <td style="font-weight:600;color:#0f1a2e;"><?php echo htmlspecialchars($st['student_name']); ?></td>
            <td style="font-size:12px;color:#1f5b8a;"><?php echo htmlspecialchars($st['banglarshiksha_id'] ?? '-'); ?></td>
            <td style="color:#6c7a8a;"><?php echo htmlspecialchars($st['father_name'] ?? '-'); ?></td>
            <td class="<?php echo $st['gender']==='Female'?'gender-f':'gender-m'; ?>"><?php echo htmlspecialchars($st['gender'] ?? '-'); ?></td>
            <td><?php echo htmlspecialchars($st['section_name'] ?? '-'); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
<?php else: ?>
    <div style="text-align:center;padding:50px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;">
        <i class="fas fa-hand-pointer" style="font-size:36px;display:block;margin-bottom:12px;"></i>
        Select a class from the tabs above to view students
    </div>
<?php endif; ?>
</body>
</html>

<?php
/**
 * teacher/navbar.php — Teacher Portal Navigation
 */
// Partial: the portal pages include this after connecting to the database.
// Requested directly there is no $conn, and the page fatalled with a stack
// trace exposing filesystem paths to anonymous visitors.
if (!isset($conn)) { http_response_code(404); exit; }

require_once '../includes/user_access.php';
$current_page = basename($_SERVER['PHP_SELF']);
$ua_can_teacher = function($key) use ($conn) {
    return ua_can($conn, 'teacher', $key);
};
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
.t-navbar{background:linear-gradient(135deg,#0f1a2e,#1a3a5c);padding:0 18px;border-radius:10px;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;min-height:50px;position:relative;z-index:999;box-shadow:0 4px 16px rgba(0,0,0,.2);}
.t-nav-brand{color:#fff;font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;text-decoration:none;flex-shrink:0;}
.t-nav-brand i{color:#6ea8fe;font-size:18px;}
.t-nav-links{display:flex;align-items:center;gap:2px;flex-wrap:wrap;}
.t-nav-links a{color:#c5d8eb;text-decoration:none;font-size:13px;font-weight:600;padding:7px 13px;border-radius:6px;display:flex;align-items:center;gap:6px;white-space:nowrap;transition:all .2s;}
.t-nav-links a:hover,.t-nav-links a.active{background:rgba(255,255,255,.12);color:#fff;}
.t-nav-links a i{font-size:13px;color:#7a9bbd;}
.t-nav-links a:hover i,.t-nav-links a.active i{color:#fff;}
.t-nav-links a.active{border-bottom:2px solid #6ea8fe;}
.t-nav-right{display:flex;align-items:center;gap:8px;flex-shrink:0;}
.t-nav-user{display:flex;align-items:center;gap:8px;color:#c5d8eb;font-size:13px;font-weight:600;}
.t-nav-user img{width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid rgba(255,255,255,.25);}
.t-nav-user .avatar{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:12px;color:#fff;font-weight:700;}
.t-nav-logout{color:#ef4444;text-decoration:none;font-size:13px;font-weight:600;padding:6px 12px;border-radius:6px;display:flex;align-items:center;gap:5px;transition:.2s;}
.t-nav-logout:hover{background:rgba(239,68,68,.1);}
.t-toggle{display:none;background:none;border:none;color:#fff;font-size:20px;cursor:pointer;padding:4px 8px;}
@media(max-width:900px){
    .t-navbar{flex-wrap:wrap;padding:6px 12px;}
    .t-toggle{display:block;margin-left:auto;}
    .t-nav-links{display:none;width:100%;flex-direction:column;align-items:stretch;padding:4px 0;}
    .t-nav-links.open{display:flex;}
    .t-nav-links a{padding:8px 12px;font-size:14px;}
    .t-nav-right{display:none;}
    .t-nav-right.open{display:flex;width:100%;padding:6px 0;border-top:1px solid rgba(255,255,255,.08);}
}
</style>
<nav class="t-navbar">
    <a href="dashboard.php" class="t-nav-brand"><i class="fas fa-chalkboard-teacher"></i> Teacher Portal</a>

    <button class="t-toggle" onclick="toggleTNav()"><i class="fas fa-bars"></i></button>

    <div class="t-nav-links" id="tNavLinks">
        <a href="dashboard.php" class="<?php echo $current_page==='dashboard.php'?'active':''; ?>">
            <i class="fas fa-th-large"></i> Dashboard
        </a>
        <?php if ($ua_can_teacher('feature_my_routine')): ?>
        <a href="my_routine.php" class="<?php echo $current_page==='my_routine.php'?'active':''; ?>">
            <i class="fas fa-calendar-alt"></i> My Routine
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_my_students')): ?>
        <a href="my_students.php" class="<?php echo $current_page==='my_students.php'?'active':''; ?>">
            <i class="fas fa-user-graduate"></i> My Students
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_my_attendance')): ?>
        <a href="my_attendance.php" class="<?php echo $current_page==='my_attendance.php'?'active':''; ?>">
            <i class="fas fa-clipboard-check"></i> Attendance
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_marks_entry')): ?>
        <a href="marks_entry.php" class="<?php echo $current_page==='marks_entry.php'?'active':''; ?>">
            <i class="fas fa-pencil-alt"></i> Marks Entry
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_hs_marks')): ?>
        <a href="hs_marks_entry.php" class="<?php echo $current_page==='hs_marks_entry.php'?'active':''; ?>">
            <i class="fas fa-graduation-cap"></i> HS Marks
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_marks_view')): ?>
        <a href="marks_view.php" class="<?php echo $current_page==='marks_view.php'?'active':''; ?>">
            <i class="fas fa-chart-bar"></i> Marks View
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_notices')): ?>
        <a href="notices.php" class="<?php echo $current_page==='notices.php'?'active':''; ?>">
            <i class="fas fa-bullhorn"></i> Notices
        </a>
        <?php endif; ?>
        <?php if ($ua_can_teacher('feature_profile_view')): ?>
        <a href="profile.php" class="<?php echo $current_page==='profile.php'?'active':''; ?>">
            <i class="fas fa-user-circle"></i> Profile
        </a>
        <?php endif; ?>
        <?php
        require_once '../includes/library_helper.php';
        if (is_library_staff($conn, $_SESSION['teacher_id'] ?? 0)):
        ?>
        <a href="library_dashboard.php" class="<?php echo in_array($current_page, ['library_dashboard.php','library_issue_scan.php','library_return_scan.php'])?'active':''; ?>">
            <i class="fas fa-book-reader"></i> Library
        </a>
        <?php endif; ?>
    </div>

    <div class="t-nav-right" id="tNavRight">
        <div class="t-nav-user">
            <?php if(!empty($_SESSION['teacher_photo'])): ?>
                <img src="../uploads/staff/<?php echo htmlspecialchars($_SESSION['teacher_photo']); ?>" alt="">
            <?php else: ?>
                <div class="avatar"><?php echo strtoupper(substr($_SESSION['teacher_name']??'T',0,1)); ?></div>
            <?php endif; ?>
            <span><?php echo htmlspecialchars($_SESSION['teacher_name']??'Teacher'); ?></span>
        </div>
        <a href="logout.php" class="t-nav-logout"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>
</nav>
<script>
function toggleTNav(){
    document.getElementById('tNavLinks').classList.toggle('open');
    document.getElementById('tNavRight').classList.toggle('open');
}
</script>

<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_notices')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$notices = mysqli_query($conn, "SELECT * FROM notices ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Notices</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.notice-card{background:#fff;border-radius:10px;border:1px solid #e5e7eb;margin-bottom:12px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.04);transition:transform .2s;}
.notice-card:hover{transform:translateY(-2px);box-shadow:0 6px 18px rgba(0,0,0,.08);}
.nc-head{padding:12px 16px;background:#f8fafc;border-bottom:1px solid #f0f2f5;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:6px;}
.nc-title{font-size:15px;font-weight:700;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.nc-title i{color:#1f5b8a;font-size:14px;}
.nc-date{font-size:12px;color:#9aabb8;background:#f0f4f9;padding:3px 10px;border-radius:20px;}
.nc-body{padding:12px 16px;font-size:13px;color:#374151;line-height:1.7;}
.empty-state{text-align:center;padding:60px;color:#9aabb8;background:#fff;border-radius:10px;border:2px dashed #e5e7eb;}
.empty-state i{font-size:48px;display:block;margin-bottom:14px;opacity:.2;}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<h2><i class="fas fa-bullhorn"></i> Notice Board</h2>

<?php $count = 0; while($n = mysqli_fetch_assoc($notices)): $count++; ?>
<div class="notice-card">
    <div class="nc-head">
        <div class="nc-title"><i class="fas fa-bell"></i> <?php echo htmlspecialchars($n['notice_title'] ?? $n['title'] ?? 'Notice'); ?></div>
        <span class="nc-date"><i class="fas fa-calendar-alt"></i> <?php echo htmlspecialchars($n['notice_date'] ?? $n['created_at'] ?? ''); ?></span>
    </div>
    <div class="nc-body">
        <?php echo nl2br(htmlspecialchars($n['notice_details'] ?? $n['content'] ?? $n['description'] ?? '')); ?>
    </div>
</div>
<?php endwhile; ?>

<?php if($count === 0): ?>
<div class="empty-state">
    <i class="fas fa-bell-slash"></i>
    <p style="font-size:15px;font-weight:600;">No notices yet</p>
    <p style="font-size:13px;margin-top:4px;">Notices posted by admin will appear here</p>
</div>
<?php endif; ?>
</body>
</html>

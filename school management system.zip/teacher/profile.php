<?php
if (!defined('APP_TIMEZONE_SET')) { date_default_timezone_set('Asia/Kolkata'); define('APP_TIMEZONE_SET', true); }
require_once 'auth.php';
require_teacher_login();
include("../includes/db.php");
require_once '../includes/security.php';
require_once '../includes/staff_helper.php';
require_once '../includes/user_access.php';
if (!ua_can($conn, 'teacher', 'feature_profile_view')) { header("Location: dashboard.php?msg=access_denied"); exit(); }

$tid = (int)$_SESSION['teacher_id'];
$staff = staff_get_by_id($tid);
if(!$staff) { echo "Staff not found"; exit(); }

$success = $error = '';
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    verify_csrf_or_die();
    $old_pw  = $_POST['old_password']  ?? '';
    $new_pw  = $_POST['new_password']  ?? '';
    $conf_pw = $_POST['confirm_password'] ?? '';
    if(!password_verify($old_pw, $staff['login_password'] ?? '')) {
        $error = 'Current password is incorrect.';
    } elseif(strlen($new_pw) < 8 || !preg_match('/[A-Za-z]/', $new_pw) || !preg_match('/[0-9]/', $new_pw)) {
        $error = 'New password must be at least 8 characters with a letter and a digit.';
    } elseif($new_pw !== $conf_pw) {
        $error = 'New passwords do not match.';
    } else {
        $hashed = staff_update_password($tid, $new_pw);
        if ($hashed === false) { $error = 'Unable to change password.'; } else {
            $staff['login_password'] = $hashed;
            db_update('staff', ['pw_must_change' => 0, 'pw_changed_at' => date('Y-m-d H:i:s')], ['id' => $tid], 'i'); $_SESSION['teacher_pw_must_change'] = false;
            $success = 'Password changed successfully!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Profile</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{background:#f0f4f9;font-family:'Segoe UI',system-ui,sans-serif;padding:15px 18px;}
h2{color:#0f1a2e;font-size:22px;font-weight:800;margin-bottom:18px;display:flex;align-items:center;gap:10px;}
h2 i{color:#1f5b8a;}
.layout{display:grid;grid-template-columns:280px 1fr;gap:18px;}
.profile-card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;padding:24px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.05);}
.profile-avatar{width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid #e8f4ff;margin:0 auto 14px;}
.profile-avatar-placeholder{width:100px;height:100px;border-radius:50%;background:linear-gradient(135deg,#1f5b8a,#003366);color:#fff;display:flex;align-items:center;justify-content:center;font-size:36px;font-weight:700;margin:0 auto 14px;}
.profile-name{font-size:18px;font-weight:800;color:#0f1a2e;}
.profile-desig{font-size:13px;color:#6c7a8a;margin-top:4px;}
.profile-badge{display:inline-block;background:#e8f4ff;color:#1f5b8a;font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px;margin-top:8px;}
.info-list{margin-top:18px;text-align:left;}
.info-row{display:flex;align-items:flex-start;gap:10px;padding:8px 0;border-bottom:1px solid #f0f2f5;font-size:13px;}
.info-row:last-child{border-bottom:none;}
.info-row i{width:18px;color:#1f5b8a;font-size:13px;margin-top:1px;flex-shrink:0;}
.info-row .lbl{color:#9aabb8;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.3px;display:block;}
.info-row .val{color:#0f1a2e;font-weight:600;}
.right-col{display:flex;flex-direction:column;gap:16px;}
.section-card{background:#fff;border-radius:12px;border:1px solid #e5e7eb;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.05);}
.sc-head{padding:12px 18px;background:#f8fafc;border-bottom:1px solid #e5e7eb;font-weight:700;font-size:14px;color:#0f1a2e;display:flex;align-items:center;gap:8px;}
.sc-head i{color:#1f5b8a;}
.sc-body{padding:18px;}
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.dg-item .lbl{font-size:11px;font-weight:700;color:#9aabb8;text-transform:uppercase;letter-spacing:.3px;}
.dg-item .val{font-size:13px;font-weight:600;color:#0f1a2e;margin-top:2px;}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;font-weight:600;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
.alert-success{background:#dcfce7;color:#166534;border:1px solid #bbf7d0;}
.alert-danger{background:#fee2e2;color:#991b1b;border:1px solid #fecaca;}
.fg{margin-bottom:14px;}
.fg label{font-size:13px;font-weight:700;color:#1a2d4a;margin-bottom:5px;display:block;}
.fg input{width:100%;padding:10px 12px;border:1.5px solid #d0dbe8;border-radius:8px;font-size:13px;}
.fg input:focus{outline:none;border-color:#1f5b8a;box-shadow:0 0 0 3px rgba(31,91,138,.1);}
.btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:8px;font-weight:700;font-size:13px;border:none;cursor:pointer;transition:.2s;}
.btn-primary{background:#1f5b8a;color:#fff;} .btn-primary:hover{background:#003366;}
@media(max-width:768px){.layout{grid-template-columns:1fr;} .detail-grid{grid-template-columns:1fr;}}
</style>
</head>
<body>
<?php include('navbar.php'); ?>
<h2><i class="fas fa-user-circle"></i> My Profile</h2>

<div class="layout">
    <!-- Left: Profile Card -->
    <div class="profile-card">
        <?php if(!empty($staff['photo'])): ?>
            <img src="../uploads/staff/<?php echo htmlspecialchars($staff['photo']); ?>" class="profile-avatar" alt="Photo">
        <?php else: ?>
            <div class="profile-avatar-placeholder"><?php echo strtoupper(substr($staff['staff_name'],0,1)); ?></div>
        <?php endif; ?>
        <div class="profile-name"><?php echo htmlspecialchars($staff['staff_name']); ?></div>
        <div class="profile-desig"><?php echo htmlspecialchars($staff['designation'] ?? ''); ?></div>
        <div class="profile-badge"><i class="fas fa-id-badge"></i> <?php echo htmlspecialchars($staff['employee_id'] ?? ''); ?></div>

        <div class="info-list">
            <div class="info-row"><i class="fas fa-book"></i><div><span class="lbl">Subject</span><span class="val"><?php echo htmlspecialchars($staff['subject_name'] ?? '-'); ?></span></div></div>
            <div class="info-row"><i class="fas fa-graduation-cap"></i><div><span class="lbl">Qualification</span><span class="val"><?php echo htmlspecialchars($staff['qualification'] ?? '-'); ?></span></div></div>
            <div class="info-row"><i class="fas fa-phone"></i><div><span class="lbl">Mobile</span><span class="val"><?php echo htmlspecialchars($staff['mobile'] ?? '-'); ?></span></div></div>
            <div class="info-row"><i class="fas fa-envelope"></i><div><span class="lbl">Email</span><span class="val"><?php echo htmlspecialchars($staff['email'] ?? '-'); ?></span></div></div>
            <div class="info-row"><i class="fas fa-tint"></i><div><span class="lbl">Blood Group</span><span class="val"><?php echo htmlspecialchars($staff['blood_group'] ?? '-'); ?></span></div></div>
        </div>
    </div>

    <!-- Right: Details + Password -->
    <div class="right-col">
        <!-- Personal Details -->
        <div class="section-card">
            <div class="sc-head"><i class="fas fa-user"></i> Personal Information</div>
            <div class="sc-body">
                <div class="detail-grid">
                    <div class="dg-item"><div class="lbl">Date of Birth</div><div class="val"><?php echo $staff['date_of_birth'] ? date('d M Y', strtotime($staff['date_of_birth'])) : '-'; ?></div></div>
                    <div class="dg-item"><div class="lbl">Gender</div><div class="val"><?php echo htmlspecialchars($staff['gender'] ?? '-'); ?></div></div>
                    <div class="dg-item"><div class="lbl">Date of Joining</div><div class="val"><?php echo $staff['date_of_joining'] ? date('d M Y', strtotime($staff['date_of_joining'])) : '-'; ?></div></div>
                    <div class="dg-item"><div class="lbl">Department</div><div class="val"><?php echo htmlspecialchars($staff['department'] ?? '-'); ?></div></div>
                    <div class="dg-item"><div class="lbl">Academic Section</div><div class="val"><?php echo htmlspecialchars($staff['academic_section'] ?? '-'); ?></div></div>
                    <div class="dg-item"><div class="lbl">Service Status</div><div class="val"><?php echo htmlspecialchars($staff['service_status'] ?? '-'); ?></div></div>
                    <div class="dg-item" style="grid-column:1/-1"><div class="lbl">Present Address</div><div class="val"><?php echo htmlspecialchars($staff['present_address'] ?? '-'); ?></div></div>
                </div>
            </div>
        </div>

        <!-- Change Password -->
        <div class="section-card">
            <div class="sc-head"><i class="fas fa-key"></i> Change Password</div>
            <div class="sc-body">
                <?php if($success): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?></div><?php endif; ?>
                <?php if($error):   ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?></div><?php endif; ?>
                <form method="POST" style="max-width:400px;">
                    <?php echo csrf_field(); ?>
                    <div class="fg"><label>Current Password</label><input type="password" name="old_password" placeholder="Enter current password"></div>
                    <div class="fg"><label>New Password</label><input type="password" name="new_password" placeholder="Min 8 characters, a letter and a digit"></div>
                    <div class="fg"><label>Confirm New Password</label><input type="password" name="confirm_password" placeholder="Repeat new password"></div>
                    <button type="submit" name="change_password" class="btn btn-primary"><i class="fas fa-save"></i> Update Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>

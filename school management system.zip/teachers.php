<?php
require_once __DIR__ . '/includes/site.php';

/** The teachers, subject by subject. Only what site_teachers() reads ever reaches this page. */
$d = site_data();
$teachers = site_teachers();
$by_subject = [];
foreach ($teachers as $t) $by_subject[$t['subject']][] = $t;
ksort($by_subject);

site_page('Our teachers', 'teachers.php', 'The teachers of ' . $d['name'] . ' — who teaches which subject, their qualifications, and since when.');
site_band('Our teachers', count($teachers) . ' teachers across ' . count($by_subject) . ' subjects — who teaches what, and since when.');
?>
<section class="sec">
    <div class="wrap">
        <?php if ($d['hoi'] !== ''): ?>
        <div class="hoi reveal">
            <?php echo $d['hoi_photo'] !== '' ? '<img class="avatar" src="' . h($d['hoi_photo']) . '" alt="' . h($d['hoi']) . '">' : site_avatar($d['hoi']); ?>
            <div>
                <span class="kick">Head of the Institution</span>
                <h2><?php echo h(site_title_case($d['hoi'])); ?></h2>
                <?php if ($d['message'] !== ''): ?><p style="color:var(--muted);margin:0"><?php echo h(mb_substr($d['message'], 0, 260)); ?><?php echo mb_strlen($d['message']) > 260 ? '…' : ''; ?></p><?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!$teachers): ?>
            <div class="panel"><div class="empty"><i class="fas fa-chalkboard-user"></i>The list of teachers will appear here soon.</div></div>
        <?php else: ?>
        <div class="tools">
            <label class="search"><span class="sr-only">Find a teacher or a subject</span><i class="fas fa-magnifying-glass"></i>
                <input type="search" data-filter placeholder="Find a teacher or a subject — e.g. Mathematics" autocomplete="off"></label>
        </div>
        <div class="chips" style="margin-bottom:8px">
            <?php foreach ($by_subject as $subject => $list): ?>
                <a href="#<?php echo h('s-' . preg_replace('/[^a-z0-9]+/', '-', strtolower($subject))); ?>"><?php echo h($subject); ?> <span style="opacity:.6"><?php echo count($list); ?></span></a>
            <?php endforeach; ?>
        </div>

        <?php foreach ($by_subject as $subject => $list): ?>
        <div data-group>
            <div class="subject-head" id="<?php echo h('s-' . preg_replace('/[^a-z0-9]+/', '-', strtolower($subject))); ?>">
                <h3><?php echo h($subject); ?></h3><span><?php echo count($list); ?> teacher<?php echo count($list) === 1 ? '' : 's'; ?></span>
            </div>
            <div class="tgrid">
                <?php foreach ($list as $t): ?>
                <article class="tcard" data-find="<?php echo h(mb_strtolower($t['staff_name'] . ' ' . $t['subject'] . ' ' . $t['post'] . ' ' . $t['qualification'])); ?>">
                    <?php echo site_avatar($t['staff_name'], $t['photo_url']); ?>
                    <h3><?php echo h(site_title_case($t['staff_name'])); ?></h3>
                    <div class="post"><?php echo h($t['post']); ?></div>
                    <span class="subj"><?php echo h($t['subject']); ?></span>
                    <div class="meta">
                        <?php if (trim((string)$t['qualification']) !== ''): ?><div><i class="fas fa-graduation-cap"></i><?php echo h($t['qualification']); ?></div><?php endif; ?>
                        <?php if ((int)$t['since']): ?><div><i class="fas fa-clock-rotate-left"></i>With us since <?php echo (int)$t['since']; ?></div><?php endif; ?>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <div class="panel" data-none style="display:none;margin-top:20px"><div class="empty"><i class="fas fa-magnifying-glass"></i>No teacher or subject by that name.</div></div>
        <?php endif; ?>
    </div>
</section>
<?php site_footer();
